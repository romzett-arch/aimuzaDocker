const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
  try {
    const authHeader = req.headers.get("Authorization");
    let userId = null;
    let isInternalCall = false;
    // Check if this is an internal call (from suno-callback) with service key
    if (authHeader === `Bearer ${supabaseServiceKey}`) {
      isInternalCall = true;
      console.log("Internal service call detected");
    } else if (authHeader?.startsWith("Bearer ")) {
      // User JWT - validate and get user
      const userClient = createClient(supabaseUrl, supabaseAnonKey, {
        global: {
          headers: {
            Authorization: authHeader
          }
        }
      });
      const token = authHeader.replace("Bearer ", "");
      const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
      if (claimsError || !claimsData?.claims) {
        return new Response(JSON.stringify({
          error: "Unauthorized"
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      userId = claimsData.claims.sub;
      console.log(`User call from: ${userId}`);
    } else {
      return new Response(JSON.stringify({
        error: "Unauthorized - missing auth"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const body = await req.json();
    const { track_id, suno_task_id, suno_audio_id, author } = body;
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    if (!SUNO_API_KEY) {
      throw new Error("SUNO_API_KEY is not configured");
    }
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    console.log(`Generating music video for track: ${track_id}, suno_task_id: ${suno_task_id}, suno_audio_id: ${suno_audio_id}`);
    // Get track info to verify ownership and get suno_audio_id if not provided
    const { data: track, error: trackError } = await supabase.from("tracks").select("id, user_id, suno_audio_id, title, description").eq("id", track_id).single();
    if (trackError || !track) {
      throw new Error("Track not found");
    }
    // If user call, verify ownership
    if (!isInternalCall && track.user_id !== userId) {
      return new Response(JSON.stringify({
        error: "Access denied - not your track"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Use provided suno_audio_id or get from track
    const audioId = suno_audio_id || track.suno_audio_id;
    // Extract task_id from track description (format: [task_id: xxx])
    let taskId = suno_task_id;
    if (!taskId && track.description) {
      const taskIdMatch = track.description.match(/\[task_id:\s*([^\]]+)\]/);
      if (taskIdMatch) {
        taskId = taskIdMatch[1].trim();
        console.log(`Extracted task_id from description: ${taskId}`);
      }
    }
    // Validate we have required parameters - Suno API requires taskId
    if (!taskId) {
      throw new Error("Track has no Suno task ID for video generation");
    }
    // Get addon service price
    const { data: addonService } = await supabase.from("addon_services").select("id, price_rub").eq("name", "short_video").single();
    if (!addonService) {
      throw new Error("Video addon service not found");
    }
    const price = addonService.price_rub;
    // If user call (not internal from addon processing), check balance and deduct
    if (!isInternalCall && userId) {
      // Check user balance
      const { data: profile, error: profileError } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
      if (profileError || !profile) {
        throw new Error("User profile not found");
      }
      if ((profile.balance || 0) < price) {
        return new Response(JSON.stringify({
          error: "Insufficient balance",
          required: price,
          current: profile.balance
        }), {
          status: 402,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Deduct balance
      const newBalance = (profile.balance || 0) - price;
      const { error: deductError } = await supabase.from("profiles").update({
        balance: newBalance
      }).eq("user_id", userId);
      if (deductError) {
        throw new Error("Failed to deduct balance");
      }
      // Log transaction
      await supabase.from("balance_transactions").insert({
        user_id: userId,
        amount: -price,
        balance_after: newBalance,
        type: "video",
        description: "Промо-видео",
        reference_id: track_id,
        reference_type: "track"
      });
      // Create track_addon record
      await supabase.from("track_addons").insert({
        track_id: track_id,
        addon_service_id: addonService.id,
        status: "processing",
        result_url: JSON.stringify({
          status: "starting"
        })
      });
    }
    // Build callback URL for Suno
    const callbackUrl = `${supabaseUrl}/functions/v1/suno-video-callback`;
    // Request music video generation from Suno API
    // According to Suno docs, both taskId and audioId can be provided
    // taskId is required, audioId is optional but more specific
    const requestBody = {
      callBackUrl: callbackUrl,
      taskId: taskId
    };
    // Add audioId if available (more specific)
    if (audioId) {
      requestBody.audioId = audioId;
    }
    if (author) {
      requestBody.author = author;
    }
    console.log("Requesting Suno music video:", JSON.stringify(requestBody));
    const response = await fetch("https://api.sunoapi.org/api/v1/mp4/generate", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${SUNO_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(requestBody)
    });
    const responseText = await response.text();
    console.log("Suno video response:", response.status, responseText);
    let data;
    try {
      data = JSON.parse(responseText);
    } catch  {
      throw new Error(`Invalid JSON response from Suno: ${responseText}`);
    }
    // Handle "Mp4 record already exists" - means video is already generated
    // Try to fetch the existing video URL
    if (data.code !== 200 && data.msg?.includes("Mp4 record already exists")) {
      console.log("Video already exists, fetching status...");
      // Try to get existing video via status API
      const statusResponse = await fetch(`https://api.sunoapi.org/api/v1/mp4/query?taskId=${taskId}`, {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${SUNO_API_KEY}`,
          "Content-Type": "application/json"
        }
      });
      const statusText = await statusResponse.text();
      console.log("Suno video status response:", statusResponse.status, statusText);
      let statusData;
      try {
        statusData = JSON.parse(statusText);
      } catch  {
        // If status API fails, refund and error
        if (!isInternalCall && userId) {
          const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
          await supabase.from("profiles").update({
            balance: (currentProfile?.balance || 0) + price
          }).eq("user_id", userId);
        }
        throw new Error("Video already exists but failed to fetch URL");
      }
      if (statusData.code === 200 && statusData.data) {
        // Video exists - extract URL
        const videoUrl = statusData.data.video_url || statusData.data.mp4_url || statusData.data.url;
        if (videoUrl) {
          console.log(`Found existing video: ${videoUrl}`);
          // Refund user since video already exists
          if (!isInternalCall && userId) {
            const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
            await supabase.from("profiles").update({
              balance: (currentProfile?.balance || 0) + price
            }).eq("user_id", userId);
          }
          // Update addon to completed with existing URL
          await supabase.from("track_addons").update({
            status: "completed",
            result_url: videoUrl,
            updated_at: new Date().toISOString()
          }).eq("track_id", track_id).eq("addon_service_id", addonService.id);
          return new Response(JSON.stringify({
            success: true,
            video_url: videoUrl,
            message: "Video already exists",
            already_exists: true
          }), {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json"
            }
          });
        }
      }
      // Refund and error if we couldn't get video URL
      if (!isInternalCall && userId) {
        const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
        await supabase.from("profiles").update({
          balance: (currentProfile?.balance || 0) + price
        }).eq("user_id", userId);
      }
      throw new Error("Video exists but could not retrieve URL");
    }
    if (!response.ok) {
      // Refund if user call
      if (!isInternalCall && userId) {
        const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
        await supabase.from("profiles").update({
          balance: (currentProfile?.balance || 0) + price
        }).eq("user_id", userId);
        await supabase.from("track_addons").update({
          status: "failed",
          result_url: JSON.stringify({
            error: "Suno API error"
          })
        }).eq("track_id", track_id).eq("addon_service_id", addonService.id);
      }
      throw new Error(`Suno API error: ${response.status} - ${responseText}`);
    }
    if (data.code !== 200) {
      // Refund if user call
      if (!isInternalCall && userId) {
        const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
        await supabase.from("profiles").update({
          balance: (currentProfile?.balance || 0) + price
        }).eq("user_id", userId);
        await supabase.from("track_addons").update({
          status: "failed",
          result_url: JSON.stringify({
            error: data.msg
          })
        }).eq("track_id", track_id).eq("addon_service_id", addonService.id);
      }
      throw new Error(`Suno API error: ${data.msg || "Unknown error"}`);
    }
    const videoTaskId = data.data?.taskId;
    if (!videoTaskId) {
      throw new Error("No video taskId received from Suno");
    }
    console.log(`Video generation started, Suno video task ID: ${videoTaskId}`);
    // Update the track_addons table with processing status and video task ID
    const { error: updateError } = await supabase.from("track_addons").update({
      status: "processing",
      result_url: JSON.stringify({
        video_task_id: videoTaskId,
        track_id: track_id,
        suno_audio_id: audioId || null,
        status: "processing"
      }),
      updated_at: new Date().toISOString()
    }).eq("track_id", track_id).eq("addon_service_id", addonService.id);
    if (updateError) {
      console.error("Update addon error:", updateError);
    }
    return new Response(JSON.stringify({
      success: true,
      video_task_id: videoTaskId,
      message: "Music video generation started"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("generate-short-video error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9nZW5lcmF0ZS1zaG9ydC12aWRlby50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICBjb25zdCBzdXBhYmFzZUFub25LZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSE7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBsZXQgdXNlcklkOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgICBsZXQgaXNJbnRlcm5hbENhbGwgPSBmYWxzZTtcblxuICAgIC8vIENoZWNrIGlmIHRoaXMgaXMgYW4gaW50ZXJuYWwgY2FsbCAoZnJvbSBzdW5vLWNhbGxiYWNrKSB3aXRoIHNlcnZpY2Uga2V5XG4gICAgaWYgKGF1dGhIZWFkZXIgPT09IGBCZWFyZXIgJHtzdXBhYmFzZVNlcnZpY2VLZXl9YCkge1xuICAgICAgaXNJbnRlcm5hbENhbGwgPSB0cnVlO1xuICAgICAgY29uc29sZS5sb2coXCJJbnRlcm5hbCBzZXJ2aWNlIGNhbGwgZGV0ZWN0ZWRcIik7XG4gICAgfSBlbHNlIGlmIChhdXRoSGVhZGVyPy5zdGFydHNXaXRoKFwiQmVhcmVyIFwiKSkge1xuICAgICAgLy8gVXNlciBKV1QgLSB2YWxpZGF0ZSBhbmQgZ2V0IHVzZXJcbiAgICAgIGNvbnN0IHVzZXJDbGllbnQgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlQW5vbktleSwge1xuICAgICAgICBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfVxuICAgICAgfSk7XG4gICAgICBcbiAgICAgIGNvbnN0IHRva2VuID0gYXV0aEhlYWRlci5yZXBsYWNlKFwiQmVhcmVyIFwiLCBcIlwiKTtcbiAgICAgIGNvbnN0IHsgZGF0YTogY2xhaW1zRGF0YSwgZXJyb3I6IGNsYWltc0Vycm9yIH0gPSBhd2FpdCB1c2VyQ2xpZW50LmF1dGguZ2V0Q2xhaW1zKHRva2VuKTtcbiAgICAgIFxuICAgICAgaWYgKGNsYWltc0Vycm9yIHx8ICFjbGFpbXNEYXRhPy5jbGFpbXMpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgXG4gICAgICB1c2VySWQgPSBjbGFpbXNEYXRhLmNsYWltcy5zdWIgYXMgc3RyaW5nO1xuICAgICAgY29uc29sZS5sb2coYFVzZXIgY2FsbCBmcm9tOiAke3VzZXJJZH1gKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWQgLSBtaXNzaW5nIGF1dGhcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnN0IHsgdHJhY2tfaWQsIHN1bm9fdGFza19pZCwgc3Vub19hdWRpb19pZCwgYXV0aG9yIH0gPSBib2R5O1xuICAgIFxuICAgIGNvbnN0IFNVTk9fQVBJX0tFWSA9IERlbm8uZW52LmdldChcIlNVTk9fQVBJX0tFWVwiKTtcbiAgICBpZiAoIVNVTk9fQVBJX0tFWSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiU1VOT19BUElfS0VZIGlzIG5vdCBjb25maWd1cmVkXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgY29uc29sZS5sb2coYEdlbmVyYXRpbmcgbXVzaWMgdmlkZW8gZm9yIHRyYWNrOiAke3RyYWNrX2lkfSwgc3Vub190YXNrX2lkOiAke3N1bm9fdGFza19pZH0sIHN1bm9fYXVkaW9faWQ6ICR7c3Vub19hdWRpb19pZH1gKTtcblxuICAgIC8vIEdldCB0cmFjayBpbmZvIHRvIHZlcmlmeSBvd25lcnNoaXAgYW5kIGdldCBzdW5vX2F1ZGlvX2lkIGlmIG5vdCBwcm92aWRlZFxuICAgIGNvbnN0IHsgZGF0YTogdHJhY2ssIGVycm9yOiB0cmFja0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgIC5zZWxlY3QoXCJpZCwgdXNlcl9pZCwgc3Vub19hdWRpb19pZCwgdGl0bGUsIGRlc2NyaXB0aW9uXCIpXG4gICAgICAuZXEoXCJpZFwiLCB0cmFja19pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICh0cmFja0Vycm9yIHx8ICF0cmFjaykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVHJhY2sgbm90IGZvdW5kXCIpO1xuICAgIH1cblxuICAgIC8vIElmIHVzZXIgY2FsbCwgdmVyaWZ5IG93bmVyc2hpcFxuICAgIGlmICghaXNJbnRlcm5hbENhbGwgJiYgdHJhY2sudXNlcl9pZCAhPT0gdXNlcklkKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkFjY2VzcyBkZW5pZWQgLSBub3QgeW91ciB0cmFja1wiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gVXNlIHByb3ZpZGVkIHN1bm9fYXVkaW9faWQgb3IgZ2V0IGZyb20gdHJhY2tcbiAgICBjb25zdCBhdWRpb0lkID0gc3Vub19hdWRpb19pZCB8fCB0cmFjay5zdW5vX2F1ZGlvX2lkO1xuICAgIFxuICAgIC8vIEV4dHJhY3QgdGFza19pZCBmcm9tIHRyYWNrIGRlc2NyaXB0aW9uIChmb3JtYXQ6IFt0YXNrX2lkOiB4eHhdKVxuICAgIGxldCB0YXNrSWQgPSBzdW5vX3Rhc2tfaWQ7XG4gICAgaWYgKCF0YXNrSWQgJiYgdHJhY2suZGVzY3JpcHRpb24pIHtcbiAgICAgIGNvbnN0IHRhc2tJZE1hdGNoID0gdHJhY2suZGVzY3JpcHRpb24ubWF0Y2goL1xcW3Rhc2tfaWQ6XFxzKihbXlxcXV0rKVxcXS8pO1xuICAgICAgaWYgKHRhc2tJZE1hdGNoKSB7XG4gICAgICAgIHRhc2tJZCA9IHRhc2tJZE1hdGNoWzFdLnRyaW0oKTtcbiAgICAgICAgY29uc29sZS5sb2coYEV4dHJhY3RlZCB0YXNrX2lkIGZyb20gZGVzY3JpcHRpb246ICR7dGFza0lkfWApO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIHdlIGhhdmUgcmVxdWlyZWQgcGFyYW1ldGVycyAtIFN1bm8gQVBJIHJlcXVpcmVzIHRhc2tJZFxuICAgIGlmICghdGFza0lkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUcmFjayBoYXMgbm8gU3VubyB0YXNrIElEIGZvciB2aWRlbyBnZW5lcmF0aW9uXCIpO1xuICAgIH1cblxuICAgIC8vIEdldCBhZGRvbiBzZXJ2aWNlIHByaWNlXG4gICAgY29uc3QgeyBkYXRhOiBhZGRvblNlcnZpY2UgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImFkZG9uX3NlcnZpY2VzXCIpXG4gICAgICAuc2VsZWN0KFwiaWQsIHByaWNlX3J1YlwiKVxuICAgICAgLmVxKFwibmFtZVwiLCBcInNob3J0X3ZpZGVvXCIpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoIWFkZG9uU2VydmljZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVmlkZW8gYWRkb24gc2VydmljZSBub3QgZm91bmRcIik7XG4gICAgfVxuXG4gICAgY29uc3QgcHJpY2UgPSBhZGRvblNlcnZpY2UucHJpY2VfcnViO1xuXG4gICAgLy8gSWYgdXNlciBjYWxsIChub3QgaW50ZXJuYWwgZnJvbSBhZGRvbiBwcm9jZXNzaW5nKSwgY2hlY2sgYmFsYW5jZSBhbmQgZGVkdWN0XG4gICAgaWYgKCFpc0ludGVybmFsQ2FsbCAmJiB1c2VySWQpIHtcbiAgICAgIC8vIENoZWNrIHVzZXIgYmFsYW5jZVxuICAgICAgY29uc3QgeyBkYXRhOiBwcm9maWxlLCBlcnJvcjogcHJvZmlsZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKVxuICAgICAgICAuc2luZ2xlKCk7XG5cbiAgICAgIGlmIChwcm9maWxlRXJyb3IgfHwgIXByb2ZpbGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVXNlciBwcm9maWxlIG5vdCBmb3VuZFwiKTtcbiAgICAgIH1cblxuICAgICAgaWYgKChwcm9maWxlLmJhbGFuY2UgfHwgMCkgPCBwcmljZSkge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiSW5zdWZmaWNpZW50IGJhbGFuY2VcIiwgcmVxdWlyZWQ6IHByaWNlLCBjdXJyZW50OiBwcm9maWxlLmJhbGFuY2UgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDQwMiwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIC8vIERlZHVjdCBiYWxhbmNlXG4gICAgICBjb25zdCBuZXdCYWxhbmNlID0gKHByb2ZpbGUuYmFsYW5jZSB8fCAwKSAtIHByaWNlO1xuICAgICAgY29uc3QgeyBlcnJvcjogZGVkdWN0RXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IG5ld0JhbGFuY2UgfSlcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuXG4gICAgICBpZiAoZGVkdWN0RXJyb3IpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGRlZHVjdCBiYWxhbmNlXCIpO1xuICAgICAgfVxuXG4gICAgICAvLyBMb2cgdHJhbnNhY3Rpb25cbiAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oXCJiYWxhbmNlX3RyYW5zYWN0aW9uc1wiKS5pbnNlcnQoe1xuICAgICAgICB1c2VyX2lkOiB1c2VySWQsXG4gICAgICAgIGFtb3VudDogLXByaWNlLFxuICAgICAgICBiYWxhbmNlX2FmdGVyOiBuZXdCYWxhbmNlLFxuICAgICAgICB0eXBlOiBcInZpZGVvXCIsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcItCf0YDQvtC80L4t0LLQuNC00LXQvlwiLFxuICAgICAgICByZWZlcmVuY2VfaWQ6IHRyYWNrX2lkLFxuICAgICAgICByZWZlcmVuY2VfdHlwZTogXCJ0cmFja1wiLFxuICAgICAgfSk7XG5cbiAgICAgIC8vIENyZWF0ZSB0cmFja19hZGRvbiByZWNvcmRcbiAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgIC5pbnNlcnQoe1xuICAgICAgICAgIHRyYWNrX2lkOiB0cmFja19pZCxcbiAgICAgICAgICBhZGRvbl9zZXJ2aWNlX2lkOiBhZGRvblNlcnZpY2UuaWQsXG4gICAgICAgICAgc3RhdHVzOiBcInByb2Nlc3NpbmdcIixcbiAgICAgICAgICByZXN1bHRfdXJsOiBKU09OLnN0cmluZ2lmeSh7IHN0YXR1czogXCJzdGFydGluZ1wiIH0pLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBCdWlsZCBjYWxsYmFjayBVUkwgZm9yIFN1bm9cbiAgICBjb25zdCBjYWxsYmFja1VybCA9IGAke3N1cGFiYXNlVXJsfS9mdW5jdGlvbnMvdjEvc3Vuby12aWRlby1jYWxsYmFja2A7XG5cbiAgICAvLyBSZXF1ZXN0IG11c2ljIHZpZGVvIGdlbmVyYXRpb24gZnJvbSBTdW5vIEFQSVxuICAgIC8vIEFjY29yZGluZyB0byBTdW5vIGRvY3MsIGJvdGggdGFza0lkIGFuZCBhdWRpb0lkIGNhbiBiZSBwcm92aWRlZFxuICAgIC8vIHRhc2tJZCBpcyByZXF1aXJlZCwgYXVkaW9JZCBpcyBvcHRpb25hbCBidXQgbW9yZSBzcGVjaWZpY1xuICAgIGNvbnN0IHJlcXVlc3RCb2R5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHtcbiAgICAgIGNhbGxCYWNrVXJsOiBjYWxsYmFja1VybCxcbiAgICAgIHRhc2tJZDogdGFza0lkLCAvLyBSZXF1aXJlZFxuICAgIH07XG5cbiAgICAvLyBBZGQgYXVkaW9JZCBpZiBhdmFpbGFibGUgKG1vcmUgc3BlY2lmaWMpXG4gICAgaWYgKGF1ZGlvSWQpIHtcbiAgICAgIHJlcXVlc3RCb2R5LmF1ZGlvSWQgPSBhdWRpb0lkO1xuICAgIH1cbiAgICBcbiAgICBpZiAoYXV0aG9yKSB7XG4gICAgICByZXF1ZXN0Qm9keS5hdXRob3IgPSBhdXRob3I7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coXCJSZXF1ZXN0aW5nIFN1bm8gbXVzaWMgdmlkZW86XCIsIEpTT04uc3RyaW5naWZ5KHJlcXVlc3RCb2R5KSk7XG5cbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFwiaHR0cHM6Ly9hcGkuc3Vub2FwaS5vcmcvYXBpL3YxL21wNC9nZW5lcmF0ZVwiLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NVTk9fQVBJX0tFWX1gLFxuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShyZXF1ZXN0Qm9keSksXG4gICAgfSk7XG5cbiAgICBjb25zdCByZXNwb25zZVRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgY29uc29sZS5sb2coXCJTdW5vIHZpZGVvIHJlc3BvbnNlOlwiLCByZXNwb25zZS5zdGF0dXMsIHJlc3BvbnNlVGV4dCk7XG5cbiAgICBsZXQgZGF0YTtcbiAgICB0cnkge1xuICAgICAgZGF0YSA9IEpTT04ucGFyc2UocmVzcG9uc2VUZXh0KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBKU09OIHJlc3BvbnNlIGZyb20gU3VubzogJHtyZXNwb25zZVRleHR9YCk7XG4gICAgfVxuXG4gICAgLy8gSGFuZGxlIFwiTXA0IHJlY29yZCBhbHJlYWR5IGV4aXN0c1wiIC0gbWVhbnMgdmlkZW8gaXMgYWxyZWFkeSBnZW5lcmF0ZWRcbiAgICAvLyBUcnkgdG8gZmV0Y2ggdGhlIGV4aXN0aW5nIHZpZGVvIFVSTFxuICAgIGlmIChkYXRhLmNvZGUgIT09IDIwMCAmJiBkYXRhLm1zZz8uaW5jbHVkZXMoXCJNcDQgcmVjb3JkIGFscmVhZHkgZXhpc3RzXCIpKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIlZpZGVvIGFscmVhZHkgZXhpc3RzLCBmZXRjaGluZyBzdGF0dXMuLi5cIik7XG4gICAgICBcbiAgICAgIC8vIFRyeSB0byBnZXQgZXhpc3RpbmcgdmlkZW8gdmlhIHN0YXR1cyBBUElcbiAgICAgIGNvbnN0IHN0YXR1c1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2goYGh0dHBzOi8vYXBpLnN1bm9hcGkub3JnL2FwaS92MS9tcDQvcXVlcnk/dGFza0lkPSR7dGFza0lkfWAsIHtcbiAgICAgICAgbWV0aG9kOiBcIkdFVFwiLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgICAgXG4gICAgICBjb25zdCBzdGF0dXNUZXh0ID0gYXdhaXQgc3RhdHVzUmVzcG9uc2UudGV4dCgpO1xuICAgICAgY29uc29sZS5sb2coXCJTdW5vIHZpZGVvIHN0YXR1cyByZXNwb25zZTpcIiwgc3RhdHVzUmVzcG9uc2Uuc3RhdHVzLCBzdGF0dXNUZXh0KTtcbiAgICAgIFxuICAgICAgbGV0IHN0YXR1c0RhdGE7XG4gICAgICB0cnkge1xuICAgICAgICBzdGF0dXNEYXRhID0gSlNPTi5wYXJzZShzdGF0dXNUZXh0KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBJZiBzdGF0dXMgQVBJIGZhaWxzLCByZWZ1bmQgYW5kIGVycm9yXG4gICAgICAgIGlmICghaXNJbnRlcm5hbENhbGwgJiYgdXNlcklkKSB7XG4gICAgICAgICAgY29uc3QgeyBkYXRhOiBjdXJyZW50UHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZClcbiAgICAgICAgICAgIC5zaW5nbGUoKTtcbiAgICAgICAgICBcbiAgICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IChjdXJyZW50UHJvZmlsZT8uYmFsYW5jZSB8fCAwKSArIHByaWNlIH0pXG4gICAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVmlkZW8gYWxyZWFkeSBleGlzdHMgYnV0IGZhaWxlZCB0byBmZXRjaCBVUkxcIik7XG4gICAgICB9XG4gICAgICBcbiAgICAgIGlmIChzdGF0dXNEYXRhLmNvZGUgPT09IDIwMCAmJiBzdGF0dXNEYXRhLmRhdGEpIHtcbiAgICAgICAgLy8gVmlkZW8gZXhpc3RzIC0gZXh0cmFjdCBVUkxcbiAgICAgICAgY29uc3QgdmlkZW9VcmwgPSBzdGF0dXNEYXRhLmRhdGEudmlkZW9fdXJsIHx8IHN0YXR1c0RhdGEuZGF0YS5tcDRfdXJsIHx8IHN0YXR1c0RhdGEuZGF0YS51cmw7XG4gICAgICAgIFxuICAgICAgICBpZiAodmlkZW9VcmwpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgRm91bmQgZXhpc3RpbmcgdmlkZW86ICR7dmlkZW9Vcmx9YCk7XG4gICAgICAgICAgXG4gICAgICAgICAgLy8gUmVmdW5kIHVzZXIgc2luY2UgdmlkZW8gYWxyZWFkeSBleGlzdHNcbiAgICAgICAgICBpZiAoIWlzSW50ZXJuYWxDYWxsICYmIHVzZXJJZCkge1xuICAgICAgICAgICAgY29uc3QgeyBkYXRhOiBjdXJyZW50UHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgICAgICAuc2VsZWN0KFwiYmFsYW5jZVwiKVxuICAgICAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZClcbiAgICAgICAgICAgICAgLnNpbmdsZSgpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiAoY3VycmVudFByb2ZpbGU/LmJhbGFuY2UgfHwgMCkgKyBwcmljZSB9KVxuICAgICAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIFxuICAgICAgICAgIC8vIFVwZGF0ZSBhZGRvbiB0byBjb21wbGV0ZWQgd2l0aCBleGlzdGluZyBVUkxcbiAgICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgICAgLmZyb20oXCJ0cmFja19hZGRvbnNcIilcbiAgICAgICAgICAgIC51cGRhdGUoeyBcbiAgICAgICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLCBcbiAgICAgICAgICAgICAgcmVzdWx0X3VybDogdmlkZW9VcmwsXG4gICAgICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5lcShcInRyYWNrX2lkXCIsIHRyYWNrX2lkKVxuICAgICAgICAgICAgLmVxKFwiYWRkb25fc2VydmljZV9pZFwiLCBhZGRvblNlcnZpY2UuaWQpO1xuICAgICAgICAgIFxuICAgICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICAgIHZpZGVvX3VybDogdmlkZW9VcmwsXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IFwiVmlkZW8gYWxyZWFkeSBleGlzdHNcIixcbiAgICAgICAgICAgICAgYWxyZWFkeV9leGlzdHM6IHRydWUsXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIFJlZnVuZCBhbmQgZXJyb3IgaWYgd2UgY291bGRuJ3QgZ2V0IHZpZGVvIFVSTFxuICAgICAgaWYgKCFpc0ludGVybmFsQ2FsbCAmJiB1c2VySWQpIHtcbiAgICAgICAgY29uc3QgeyBkYXRhOiBjdXJyZW50UHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgLnNlbGVjdChcImJhbGFuY2VcIilcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZClcbiAgICAgICAgICAuc2luZ2xlKCk7XG4gICAgICAgIFxuICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogKGN1cnJlbnRQcm9maWxlPy5iYWxhbmNlIHx8IDApICsgcHJpY2UgfSlcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZCk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJWaWRlbyBleGlzdHMgYnV0IGNvdWxkIG5vdCByZXRyaWV2ZSBVUkxcIik7XG4gICAgfVxuXG4gICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgLy8gUmVmdW5kIGlmIHVzZXIgY2FsbFxuICAgICAgaWYgKCFpc0ludGVybmFsQ2FsbCAmJiB1c2VySWQpIHtcbiAgICAgICAgY29uc3QgeyBkYXRhOiBjdXJyZW50UHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgLnNlbGVjdChcImJhbGFuY2VcIilcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZClcbiAgICAgICAgICAuc2luZ2xlKCk7XG5cbiAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IChjdXJyZW50UHJvZmlsZT8uYmFsYW5jZSB8fCAwKSArIHByaWNlIH0pXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuICAgICAgICBcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwiZmFpbGVkXCIsIHJlc3VsdF91cmw6IEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiU3VubyBBUEkgZXJyb3JcIiB9KSB9KVxuICAgICAgICAgIC5lcShcInRyYWNrX2lkXCIsIHRyYWNrX2lkKVxuICAgICAgICAgIC5lcShcImFkZG9uX3NlcnZpY2VfaWRcIiwgYWRkb25TZXJ2aWNlLmlkKTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBFcnJvcihgU3VubyBBUEkgZXJyb3I6ICR7cmVzcG9uc2Uuc3RhdHVzfSAtICR7cmVzcG9uc2VUZXh0fWApO1xuICAgIH1cblxuICAgIGlmIChkYXRhLmNvZGUgIT09IDIwMCkge1xuICAgICAgLy8gUmVmdW5kIGlmIHVzZXIgY2FsbFxuICAgICAgaWYgKCFpc0ludGVybmFsQ2FsbCAmJiB1c2VySWQpIHtcbiAgICAgICAgY29uc3QgeyBkYXRhOiBjdXJyZW50UHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgLnNlbGVjdChcImJhbGFuY2VcIilcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZClcbiAgICAgICAgICAuc2luZ2xlKCk7XG4gICAgICAgIFxuICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogKGN1cnJlbnRQcm9maWxlPy5iYWxhbmNlIHx8IDApICsgcHJpY2UgfSlcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZCk7XG4gICAgICAgIFxuICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJmYWlsZWRcIiwgcmVzdWx0X3VybDogSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogZGF0YS5tc2cgfSkgfSlcbiAgICAgICAgICAuZXEoXCJ0cmFja19pZFwiLCB0cmFja19pZClcbiAgICAgICAgICAuZXEoXCJhZGRvbl9zZXJ2aWNlX2lkXCIsIGFkZG9uU2VydmljZS5pZCk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFN1bm8gQVBJIGVycm9yOiAke2RhdGEubXNnIHx8IFwiVW5rbm93biBlcnJvclwifWApO1xuICAgIH1cblxuICAgIGNvbnN0IHZpZGVvVGFza0lkID0gZGF0YS5kYXRhPy50YXNrSWQ7XG4gICAgaWYgKCF2aWRlb1Rhc2tJZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gdmlkZW8gdGFza0lkIHJlY2VpdmVkIGZyb20gU3Vub1wiKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgVmlkZW8gZ2VuZXJhdGlvbiBzdGFydGVkLCBTdW5vIHZpZGVvIHRhc2sgSUQ6ICR7dmlkZW9UYXNrSWR9YCk7XG5cbiAgICAvLyBVcGRhdGUgdGhlIHRyYWNrX2FkZG9ucyB0YWJsZSB3aXRoIHByb2Nlc3Npbmcgc3RhdHVzIGFuZCB2aWRlbyB0YXNrIElEXG4gICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgLnVwZGF0ZSh7XG4gICAgICAgIHN0YXR1czogXCJwcm9jZXNzaW5nXCIsXG4gICAgICAgIHJlc3VsdF91cmw6IEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgdmlkZW9fdGFza19pZDogdmlkZW9UYXNrSWQsXG4gICAgICAgICAgdHJhY2tfaWQ6IHRyYWNrX2lkLFxuICAgICAgICAgIHN1bm9fYXVkaW9faWQ6IGF1ZGlvSWQgfHwgbnVsbCxcbiAgICAgICAgICBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiXG4gICAgICAgIH0pLFxuICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9KVxuICAgICAgLmVxKFwidHJhY2tfaWRcIiwgdHJhY2tfaWQpXG4gICAgICAuZXEoXCJhZGRvbl9zZXJ2aWNlX2lkXCIsIGFkZG9uU2VydmljZS5pZCk7XG5cbiAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJVcGRhdGUgYWRkb24gZXJyb3I6XCIsIHVwZGF0ZUVycm9yKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICB2aWRlb190YXNrX2lkOiB2aWRlb1Rhc2tJZCxcbiAgICAgICAgbWVzc2FnZTogXCJNdXNpYyB2aWRlbyBnZW5lcmF0aW9uIHN0YXJ0ZWRcIixcbiAgICAgIH0pLFxuICAgICAge1xuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgfVxuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcImdlbmVyYXRlLXNob3J0LXZpZGVvIGVycm9yOlwiLCBlcnJvcik7XG4gICAgXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIGVycm9yOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiLFxuICAgICAgfSksXG4gICAgICB7XG4gICAgICAgIHN0YXR1czogNTAwLFxuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0VBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUN4QyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFFckMsSUFBSTtJQUNGLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxTQUF3QjtJQUM1QixJQUFJLGlCQUFpQjtJQUVyQiwwRUFBMEU7SUFDMUUsSUFBSSxlQUFlLENBQUMsT0FBTyxFQUFFLG1CQUFtQixDQUFDLEVBQUU7TUFDakQsaUJBQWlCO01BQ2pCLFFBQVEsR0FBRyxDQUFDO0lBQ2QsT0FBTyxJQUFJLFlBQVksV0FBVyxZQUFZO01BQzVDLG1DQUFtQztNQUNuQyxNQUFNLGFBQWEsYUFBYSxhQUFhLGlCQUFpQjtRQUM1RCxRQUFRO1VBQUUsU0FBUztZQUFFLGVBQWU7VUFBVztRQUFFO01BQ25EO01BRUEsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7TUFDNUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxXQUFXLElBQUksQ0FBQyxTQUFTLENBQUM7TUFFakYsSUFBSSxlQUFlLENBQUMsWUFBWSxRQUFRO1FBQ3RDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUFlLElBQ3ZDO1VBQUUsUUFBUTtVQUFLLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUVuRjtNQUVBLFNBQVMsV0FBVyxNQUFNLENBQUMsR0FBRztNQUM5QixRQUFRLEdBQUcsQ0FBQyxDQUFDLGdCQUFnQixFQUFFLE9BQU8sQ0FBQztJQUN6QyxPQUFPO01BQ0wsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQThCLElBQ3REO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtJQUMzQixNQUFNLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsTUFBTSxFQUFFLEdBQUc7SUFFMUQsTUFBTSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNsQyxJQUFJLENBQUMsY0FBYztNQUNqQixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0MsUUFBUSxHQUFHLENBQUMsQ0FBQyxrQ0FBa0MsRUFBRSxTQUFTLGdCQUFnQixFQUFFLGFBQWEsaUJBQWlCLEVBQUUsY0FBYyxDQUFDO0lBRTNILDJFQUEyRTtJQUMzRSxNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxVQUFVLEVBQUUsR0FBRyxNQUFNLFNBQzlDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxrREFDUCxFQUFFLENBQUMsTUFBTSxVQUNULE1BQU07SUFFVCxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsaUNBQWlDO0lBQ2pDLElBQUksQ0FBQyxrQkFBa0IsTUFBTSxPQUFPLEtBQUssUUFBUTtNQUMvQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBaUMsSUFDekQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsK0NBQStDO0lBQy9DLE1BQU0sVUFBVSxpQkFBaUIsTUFBTSxhQUFhO0lBRXBELGtFQUFrRTtJQUNsRSxJQUFJLFNBQVM7SUFDYixJQUFJLENBQUMsVUFBVSxNQUFNLFdBQVcsRUFBRTtNQUNoQyxNQUFNLGNBQWMsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDO01BQzVDLElBQUksYUFBYTtRQUNmLFNBQVMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxJQUFJO1FBQzVCLFFBQVEsR0FBRyxDQUFDLENBQUMsb0NBQW9DLEVBQUUsT0FBTyxDQUFDO01BQzdEO0lBQ0Y7SUFFQSxrRUFBa0U7SUFDbEUsSUFBSSxDQUFDLFFBQVE7TUFDWCxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLDBCQUEwQjtJQUMxQixNQUFNLEVBQUUsTUFBTSxZQUFZLEVBQUUsR0FBRyxNQUFNLFNBQ2xDLElBQUksQ0FBQyxrQkFDTCxNQUFNLENBQUMsaUJBQ1AsRUFBRSxDQUFDLFFBQVEsZUFDWCxNQUFNO0lBRVQsSUFBSSxDQUFDLGNBQWM7TUFDakIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLFFBQVEsYUFBYSxTQUFTO0lBRXBDLDhFQUE4RTtJQUM5RSxJQUFJLENBQUMsa0JBQWtCLFFBQVE7TUFDN0IscUJBQXFCO01BQ3JCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbEQsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsUUFDZCxNQUFNO01BRVQsSUFBSSxnQkFBZ0IsQ0FBQyxTQUFTO1FBQzVCLE1BQU0sSUFBSSxNQUFNO01BQ2xCO01BRUEsSUFBSSxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSSxPQUFPO1FBQ2xDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztVQUF3QixVQUFVO1VBQU8sU0FBUyxRQUFRLE9BQU87UUFBQyxJQUMxRjtVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSxpQkFBaUI7TUFDakIsTUFBTSxhQUFhLENBQUMsUUFBUSxPQUFPLElBQUksQ0FBQyxJQUFJO01BQzVDLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1FBQUUsU0FBUztNQUFXLEdBQzdCLEVBQUUsQ0FBQyxXQUFXO01BRWpCLElBQUksYUFBYTtRQUNmLE1BQU0sSUFBSSxNQUFNO01BQ2xCO01BRUEsa0JBQWtCO01BQ2xCLE1BQU0sU0FBUyxJQUFJLENBQUMsd0JBQXdCLE1BQU0sQ0FBQztRQUNqRCxTQUFTO1FBQ1QsUUFBUSxDQUFDO1FBQ1QsZUFBZTtRQUNmLE1BQU07UUFDTixhQUFhO1FBQ2IsY0FBYztRQUNkLGdCQUFnQjtNQUNsQjtNQUVBLDRCQUE0QjtNQUM1QixNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztRQUNOLFVBQVU7UUFDVixrQkFBa0IsYUFBYSxFQUFFO1FBQ2pDLFFBQVE7UUFDUixZQUFZLEtBQUssU0FBUyxDQUFDO1VBQUUsUUFBUTtRQUFXO01BQ2xEO0lBQ0o7SUFFQSw4QkFBOEI7SUFDOUIsTUFBTSxjQUFjLENBQUMsRUFBRSxZQUFZLGlDQUFpQyxDQUFDO0lBRXJFLCtDQUErQztJQUMvQyxrRUFBa0U7SUFDbEUsNERBQTREO0lBQzVELE1BQU0sY0FBdUM7TUFDM0MsYUFBYTtNQUNiLFFBQVE7SUFDVjtJQUVBLDJDQUEyQztJQUMzQyxJQUFJLFNBQVM7TUFDWCxZQUFZLE9BQU8sR0FBRztJQUN4QjtJQUVBLElBQUksUUFBUTtNQUNWLFlBQVksTUFBTSxHQUFHO0lBQ3ZCO0lBRUEsUUFBUSxHQUFHLENBQUMsZ0NBQWdDLEtBQUssU0FBUyxDQUFDO0lBRTNELE1BQU0sV0FBVyxNQUFNLE1BQU0sK0NBQStDO01BQzFFLFFBQVE7TUFDUixTQUFTO1FBQ1AsaUJBQWlCLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQztRQUN6QyxnQkFBZ0I7TUFDbEI7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO0lBQ3ZCO0lBRUEsTUFBTSxlQUFlLE1BQU0sU0FBUyxJQUFJO0lBQ3hDLFFBQVEsR0FBRyxDQUFDLHdCQUF3QixTQUFTLE1BQU0sRUFBRTtJQUVyRCxJQUFJO0lBQ0osSUFBSTtNQUNGLE9BQU8sS0FBSyxLQUFLLENBQUM7SUFDcEIsRUFBRSxPQUFNO01BQ04sTUFBTSxJQUFJLE1BQU0sQ0FBQyxpQ0FBaUMsRUFBRSxhQUFhLENBQUM7SUFDcEU7SUFFQSx3RUFBd0U7SUFDeEUsc0NBQXNDO0lBQ3RDLElBQUksS0FBSyxJQUFJLEtBQUssT0FBTyxLQUFLLEdBQUcsRUFBRSxTQUFTLDhCQUE4QjtNQUN4RSxRQUFRLEdBQUcsQ0FBQztNQUVaLDJDQUEyQztNQUMzQyxNQUFNLGlCQUFpQixNQUFNLE1BQU0sQ0FBQyxnREFBZ0QsRUFBRSxPQUFPLENBQUMsRUFBRTtRQUM5RixRQUFRO1FBQ1IsU0FBUztVQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7VUFDekMsZ0JBQWdCO1FBQ2xCO01BQ0Y7TUFFQSxNQUFNLGFBQWEsTUFBTSxlQUFlLElBQUk7TUFDNUMsUUFBUSxHQUFHLENBQUMsK0JBQStCLGVBQWUsTUFBTSxFQUFFO01BRWxFLElBQUk7TUFDSixJQUFJO1FBQ0YsYUFBYSxLQUFLLEtBQUssQ0FBQztNQUMxQixFQUFFLE9BQU07UUFDTix3Q0FBd0M7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixRQUFRO1VBQzdCLE1BQU0sRUFBRSxNQUFNLGNBQWMsRUFBRSxHQUFHLE1BQU0sU0FDcEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsUUFDZCxNQUFNO1VBRVQsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztZQUFFLFNBQVMsQ0FBQyxnQkFBZ0IsV0FBVyxDQUFDLElBQUk7VUFBTSxHQUN6RCxFQUFFLENBQUMsV0FBVztRQUNuQjtRQUNBLE1BQU0sSUFBSSxNQUFNO01BQ2xCO01BRUEsSUFBSSxXQUFXLElBQUksS0FBSyxPQUFPLFdBQVcsSUFBSSxFQUFFO1FBQzlDLDZCQUE2QjtRQUM3QixNQUFNLFdBQVcsV0FBVyxJQUFJLENBQUMsU0FBUyxJQUFJLFdBQVcsSUFBSSxDQUFDLE9BQU8sSUFBSSxXQUFXLElBQUksQ0FBQyxHQUFHO1FBRTVGLElBQUksVUFBVTtVQUNaLFFBQVEsR0FBRyxDQUFDLENBQUMsc0JBQXNCLEVBQUUsU0FBUyxDQUFDO1VBRS9DLHlDQUF5QztVQUN6QyxJQUFJLENBQUMsa0JBQWtCLFFBQVE7WUFDN0IsTUFBTSxFQUFFLE1BQU0sY0FBYyxFQUFFLEdBQUcsTUFBTSxTQUNwQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxRQUNkLE1BQU07WUFFVCxNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO2NBQUUsU0FBUyxDQUFDLGdCQUFnQixXQUFXLENBQUMsSUFBSTtZQUFNLEdBQ3pELEVBQUUsQ0FBQyxXQUFXO1VBQ25CO1VBRUEsOENBQThDO1VBQzlDLE1BQU0sU0FDSCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO1lBQ04sUUFBUTtZQUNSLFlBQVk7WUFDWixZQUFZLElBQUksT0FBTyxXQUFXO1VBQ3BDLEdBQ0MsRUFBRSxDQUFDLFlBQVksVUFDZixFQUFFLENBQUMsb0JBQW9CLGFBQWEsRUFBRTtVQUV6QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztZQUNiLFNBQVM7WUFDVCxXQUFXO1lBQ1gsU0FBUztZQUNULGdCQUFnQjtVQUNsQixJQUNBO1lBQ0UsU0FBUztjQUFFLEdBQUcsV0FBVztjQUFFLGdCQUFnQjtZQUFtQjtVQUNoRTtRQUVKO01BQ0Y7TUFFQSxnREFBZ0Q7TUFDaEQsSUFBSSxDQUFDLGtCQUFrQixRQUFRO1FBQzdCLE1BQU0sRUFBRSxNQUFNLGNBQWMsRUFBRSxHQUFHLE1BQU0sU0FDcEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsUUFDZCxNQUFNO1FBRVQsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztVQUFFLFNBQVMsQ0FBQyxnQkFBZ0IsV0FBVyxDQUFDLElBQUk7UUFBTSxHQUN6RCxFQUFFLENBQUMsV0FBVztNQUNuQjtNQUNBLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLHNCQUFzQjtNQUN0QixJQUFJLENBQUMsa0JBQWtCLFFBQVE7UUFDN0IsTUFBTSxFQUFFLE1BQU0sY0FBYyxFQUFFLEdBQUcsTUFBTSxTQUNwQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxRQUNkLE1BQU07UUFFVCxNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1VBQUUsU0FBUyxDQUFDLGdCQUFnQixXQUFXLENBQUMsSUFBSTtRQUFNLEdBQ3pELEVBQUUsQ0FBQyxXQUFXO1FBRWpCLE1BQU0sU0FDSCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO1VBQUUsUUFBUTtVQUFVLFlBQVksS0FBSyxTQUFTLENBQUM7WUFBRSxPQUFPO1VBQWlCO1FBQUcsR0FDbkYsRUFBRSxDQUFDLFlBQVksVUFDZixFQUFFLENBQUMsb0JBQW9CLGFBQWEsRUFBRTtNQUMzQztNQUNBLE1BQU0sSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxNQUFNLENBQUMsR0FBRyxFQUFFLGFBQWEsQ0FBQztJQUN4RTtJQUVBLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSztNQUNyQixzQkFBc0I7TUFDdEIsSUFBSSxDQUFDLGtCQUFrQixRQUFRO1FBQzdCLE1BQU0sRUFBRSxNQUFNLGNBQWMsRUFBRSxHQUFHLE1BQU0sU0FDcEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsUUFDZCxNQUFNO1FBRVQsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztVQUFFLFNBQVMsQ0FBQyxnQkFBZ0IsV0FBVyxDQUFDLElBQUk7UUFBTSxHQUN6RCxFQUFFLENBQUMsV0FBVztRQUVqQixNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztVQUFFLFFBQVE7VUFBVSxZQUFZLEtBQUssU0FBUyxDQUFDO1lBQUUsT0FBTyxLQUFLLEdBQUc7VUFBQztRQUFHLEdBQzNFLEVBQUUsQ0FBQyxZQUFZLFVBQ2YsRUFBRSxDQUFDLG9CQUFvQixhQUFhLEVBQUU7TUFDM0M7TUFDQSxNQUFNLElBQUksTUFBTSxDQUFDLGdCQUFnQixFQUFFLEtBQUssR0FBRyxJQUFJLGdCQUFnQixDQUFDO0lBQ2xFO0lBRUEsTUFBTSxjQUFjLEtBQUssSUFBSSxFQUFFO0lBQy9CLElBQUksQ0FBQyxhQUFhO01BQ2hCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyw4Q0FBOEMsRUFBRSxZQUFZLENBQUM7SUFFMUUseUVBQXlFO0lBQ3pFLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztNQUNOLFFBQVE7TUFDUixZQUFZLEtBQUssU0FBUyxDQUFDO1FBQ3pCLGVBQWU7UUFDZixVQUFVO1FBQ1YsZUFBZSxXQUFXO1FBQzFCLFFBQVE7TUFDVjtNQUNBLFlBQVksSUFBSSxPQUFPLFdBQVc7SUFDcEMsR0FDQyxFQUFFLENBQUMsWUFBWSxVQUNmLEVBQUUsQ0FBQyxvQkFBb0IsYUFBYSxFQUFFO0lBRXpDLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLHVCQUF1QjtJQUN2QztJQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULGVBQWU7TUFDZixTQUFTO0lBQ1gsSUFDQTtNQUNFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFDaEU7RUFFSixFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLCtCQUErQjtJQUU3QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ2xELElBQ0E7TUFDRSxRQUFRO01BQ1IsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUNoRTtFQUVKO0FBQ0YifQ==
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
// Human-readable error messages for Suno error codes (Russian)
// Official Suno API error codes:
// 400 - Invalid Parameters, 401 - Unauthorized, 403 - Forbidden (moderation)
// 404 - Not Found, 405 - Rate Limited, 413 - Content Too Large
// 429 - Insufficient Credits, 455 - Maintenance, 500/503 - Server errors
function getSunoErrorMessage(code, originalMessage) {
  // First, check for specific error message patterns (more accurate than code)
  if (originalMessage) {
    const lowerMsg = originalMessage.toLowerCase();
    if (lowerMsg.includes("matches existing work") || lowerMsg.includes("existing work of art") || lowerMsg.includes("copyright") || lowerMsg.includes("protected content")) {
      return {
        short: "Контент защищён авторским правом",
        full: "Загруженный аудиофайл или текст распознан как существующее произведение. Попробуйте использовать оригинальный контент."
      };
    }
    if (lowerMsg.includes("moderation") || lowerMsg.includes("sensitive") || lowerMsg.includes("inappropriate") || lowerMsg.includes("prohibited")) {
      return {
        short: "Контент не прошёл модерацию",
        full: "Текст или описание содержит запрещённые слова. Измените содержимое и попробуйте снова."
      };
    }
    if (lowerMsg.includes("too long") || lowerMsg.includes("too large") || lowerMsg.includes("exceeds")) {
      return {
        short: "Превышен лимит символов",
        full: "Описание, стиль или текст песни слишком длинные. Сократите текст и попробуйте снова."
      };
    }
    if (lowerMsg.includes("credit") || lowerMsg.includes("balance") || lowerMsg.includes("insufficient")) {
      return {
        short: "Недостаточно кредитов Suno",
        full: "На аккаунте Suno недостаточно кредитов для генерации. Обратитесь в поддержку."
      };
    }
  }
  const errorMessages = {
    400: {
      short: "Неверные параметры запроса",
      full: "Проверьте введённые данные и попробуйте снова."
    },
    401: {
      short: "Ошибка авторизации",
      full: "Проблема с авторизацией в сервисе Suno. Обратитесь в поддержку."
    },
    403: {
      short: "Контент заблокирован",
      full: "Запрос содержит запрещённый контент. Измените текст или описание."
    },
    404: {
      short: "Ресурс не найден",
      full: "Запрашиваемый ресурс не найден. Попробуйте ещё раз."
    },
    405: {
      short: "Превышена частота запросов",
      full: "Слишком много запросов. Подождите несколько минут."
    },
    413: {
      short: "Превышен лимит символов",
      full: "Текст слишком длинный (макс. ~3000 символов для lyrics). Сократите и попробуйте снова."
    },
    429: {
      short: "Недостаточно кредитов",
      full: "На аккаунте Suno недостаточно кредитов. Обратитесь в поддержку."
    },
    455: {
      short: "Сервис на обслуживании",
      full: "Suno проходит техническое обслуживание. Попробуйте позже."
    },
    500: {
      short: "Ошибка сервера Suno",
      full: "Внутренняя ошибка на сервере Suno. Попробуйте позже."
    },
    503: {
      short: "Сервис недоступен",
      full: "Suno временно перегружен. Попробуйте позже."
    }
  };
  if (errorMessages[code]) {
    return errorMessages[code];
  }
  return {
    short: `Ошибка генерации (код ${code})`,
    full: originalMessage || `Произошла ошибка при генерации. Код: ${code}`
  };
}
// Map artist names to genre/style descriptions (Suno doesn't allow artist names)
const artistToStyleMap = {
  "Drake": "moody trap hip-hop with melodic hooks",
  "The Weeknd": "dark synth-pop R&B with falsetto vocals",
  "Taylor Swift": "catchy pop-country with storytelling lyrics",
  "Ed Sheeran": "acoustic pop folk with romantic themes",
  "Billie Eilish": "dark minimalist pop with whispered vocals",
  "Ariana Grande": "powerful pop R&B with high vocals",
  "Dua Lipa": "disco-influenced dance pop",
  "Bad Bunny": "reggaeton latin trap with urban beats",
  "Post Malone": "melodic hip-hop rock fusion",
  "Kendrick Lamar": "conscious lyrical hip-hop",
  "Beyoncé": "powerful R&B pop with soulful vocals",
  "BTS": "K-pop with dynamic choreography vibes",
  "Harry Styles": "70s inspired soft rock pop",
  "Doja Cat": "playful rap-pop with catchy hooks",
  "SZA": "neo-soul R&B with vulnerable lyrics",
  "Travis Scott": "atmospheric auto-tune trap",
  "Olivia Rodrigo": "emotional pop-rock with teen angst",
  "Lana Del Rey": "cinematic dreamy baroque pop",
  "Kanye West": "experimental hip-hop with gospel influences",
  "Bruno Mars": "funk pop with retro grooves",
  "Adele": "powerful ballads with soulful vocals",
  "Rihanna": "dancehall-influenced pop R&B",
  "Justin Bieber": "pop R&B with tropical influences",
  "Lady Gaga": "theatrical electro-pop",
  "Shakira": "latin pop with world music fusion",
  "Coldplay": "anthemic alternative rock with atmospheric synths",
  "Imagine Dragons": "arena rock with electronic elements",
  "Twenty One Pilots": "alternative hip-hop with electronic elements",
  "Maroon 5": "pop rock with funky grooves",
  "OneRepublic": "orchestral pop rock with uplifting themes"
};
// Convert artist name to safe style description
function convertArtistToStyle(artistName) {
  if (artistToStyleMap[artistName]) {
    return artistToStyleMap[artistName];
  }
  const lowerName = artistName.toLowerCase();
  for (const [artist, style] of Object.entries(artistToStyleMap)){
    if (artist.toLowerCase() === lowerName) {
      return style;
    }
  }
  return "contemporary pop with modern production";
}
// Clean style string to remove artist names
function cleanStyleForSuno(style) {
  if (!style) return "";
  let cleanedStyle = style;
  for (const artistName of Object.keys(artistToStyleMap)){
    const regex = new RegExp(`${artistName}\\s*style`, "gi");
    if (regex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(regex, convertArtistToStyle(artistName));
    }
    const standaloneRegex = new RegExp(`\\b${artistName}\\b`, "gi");
    if (standaloneRegex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(standaloneRegex, convertArtistToStyle(artistName));
    }
  }
  cleanedStyle = cleanedStyle.replace(/,\s*,/g, ",").replace(/\s+/g, " ").trim();
  return cleanedStyle;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    // Also create admin client for creating notifications
    const supabaseAdmin = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // P0 FIX: Check if user is blocked before allowing generation
    const { data: isBlocked } = await supabaseAdmin.rpc("is_user_blocked", {
      p_user_id: user.id
    });
    if (isBlocked) {
      return new Response(JSON.stringify({
        error: "Ваш аккаунт заблокирован. Генерация недоступна."
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { trackId, prompt, lyrics, style, title, instrumental, audioReferenceUrl } = await req.json();
    if (!trackId || !prompt) {
      return new Response(JSON.stringify({
        error: "Missing required fields: trackId, prompt"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Starting generation for track ${trackId} by user ${user.id}`);
    console.log(`Original prompt: ${prompt}`);
    console.log(`Original style: ${style}`);
    console.log(`Instrumental: ${instrumental}`);
    console.log(`Audio reference URL: ${audioReferenceUrl || 'none'}`);
    // Clean the style to remove artist names
    const cleanedStyle = cleanStyleForSuno(style || "");
    console.log(`Cleaned style: ${cleanedStyle}`);
    // Update track status to processing
    const { error: updateError } = await supabaseClient.from("tracks").update({
      status: "processing",
      error_message: null
    }).eq("id", trackId).eq("user_id", user.id);
    if (updateError) {
      console.error("Failed to update track status:", updateError);
    }
    // Build the Suno API payload according to documentation
    const hasLyrics = !!lyrics && lyrics.trim().length > 0;
    const hasStyle = !!cleanedStyle && cleanedStyle.trim().length > 0;
    const hasPrompt = !!prompt && prompt.trim().length > 0;
    const useCustomMode = hasLyrics || hasStyle;
    // Clean the prompt (description) as well
    const cleanedPrompt = cleanStyleForSuno(prompt || "");
    console.log(`Cleaned prompt (description): ${cleanedPrompt}`);
    // Build callback URL with secret for security
    // Use SUNO_CALLBACK_URL if set (should be public URL), otherwise fall back to SUPABASE_URL
    const callbackSecret = Deno.env.get("SUNO_CALLBACK_SECRET");
    const explicitCallbackUrl = Deno.env.get("SUNO_CALLBACK_URL");
    const baseCallbackUrl = explicitCallbackUrl || `${Deno.env.get("SUPABASE_URL")}/functions/v1/suno-callback`;
    const callBackUrl = callbackSecret ? `${baseCallbackUrl}${baseCallbackUrl.includes('?') ? '&' : '?'}secret=${encodeURIComponent(callbackSecret)}` : baseCallbackUrl;
    console.log(`Callback URL: ${callBackUrl}`);
    const sunoPayload = {
      model: "V4",
      customMode: useCustomMode,
      instrumental: instrumental || false,
      callBackUrl
    };
    if (useCustomMode) {
      // prompt field = lyrics (if present) or description
      sunoPayload.prompt = hasLyrics ? lyrics : prompt;
      // CRITICAL: style field should ONLY contain genre/vocal/style tags - NOT the description!
      // Suno has a strict 200 character limit on style field
      // Description goes in the prompt, not in style
      let finalStyle = cleanedStyle || "pop";
      // Truncate style to 200 chars max (Suno limit)
      if (finalStyle.length > 200) {
        // Keep the most important tags (first ones) and cut at comma boundary
        const parts = finalStyle.split(", ");
        let truncated = "";
        for (const part of parts){
          if ((truncated + ", " + part).length <= 200) {
            truncated = truncated ? truncated + ", " + part : part;
          } else {
            break;
          }
        }
        finalStyle = truncated || finalStyle.slice(0, 200);
        console.log(`Style truncated from ${cleanedStyle.length} to ${finalStyle.length} chars`);
      }
      sunoPayload.style = finalStyle;
      sunoPayload.title = title || "Untitled";
      console.log(`Final style for Suno (${sunoPayload.style.length} chars): ${sunoPayload.style}`);
    } else {
      sunoPayload.prompt = prompt.slice(0, 400);
    }
    // Determine which endpoint to use
    let sunoEndpoint = `${SUNO_API_BASE}/api/v1/generate`;
    // If audio reference is provided, use upload-cover endpoint instead
    if (audioReferenceUrl) {
      sunoEndpoint = `${SUNO_API_BASE}/api/v1/generate/upload-cover`;
      sunoPayload.uploadUrl = audioReferenceUrl;
      console.log("Using upload-cover endpoint with audio reference");
    }
    console.log("Sending to Suno API:", JSON.stringify(sunoPayload));
    console.log("Endpoint:", sunoEndpoint);
    const sunoResponse = await fetch(sunoEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify(sunoPayload)
    });
    const sunoData = await sunoResponse.json();
    console.log("Suno API response:", JSON.stringify(sunoData));
    if (!sunoResponse.ok || sunoData.code !== 200) {
      const rawErrorMessage = sunoData.msg || "Failed to start generation";
      const errorCode = sunoData.code || sunoResponse.status || 500;
      // Get human-readable Russian error message
      const errorInfo = getSunoErrorMessage(errorCode, rawErrorMessage);
      const russianErrorMessage = errorInfo.short;
      console.error(`Suno API error (${errorCode}): ${rawErrorMessage} -> ${russianErrorMessage}`);
      // Update track status to failed with Russian error message
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: russianErrorMessage
      }).eq("id", trackId).eq("user_id", user.id);
      // Get all tracks with this base title to find paired track
      const { data: allTracks } = await supabaseClient.from("tracks").select("id").eq("user_id", user.id).in("status", [
        "pending",
        "processing"
      ]);
      const trackIds = allTracks?.map((t)=>t.id) || [
        trackId
      ];
      // Refund: update generation_logs to failed and return balance
      const { data: logs } = await supabaseClient.from("generation_logs").select("id, cost_rub").in("track_id", trackIds).eq("user_id", user.id).eq("status", "pending");
      let totalRefund = 0;
      if (logs && logs.length > 0) {
        totalRefund = logs.reduce((sum, log)=>sum + (log.cost_rub || 0), 0);
        // Mark logs as failed
        await supabaseClient.from("generation_logs").update({
          status: "failed"
        }).in("id", logs.map((l)=>l.id));
        // Refund the balance
        if (totalRefund > 0) {
          const { data: profile } = await supabaseClient.from("profiles").select("balance").eq("user_id", user.id).single();
          if (profile) {
            const newBalance = (profile.balance || 0) + totalRefund;
            await supabaseClient.from("profiles").update({
              balance: newBalance
            }).eq("user_id", user.id);
            // Log refund transaction
            await supabaseClient.from("balance_transactions").insert({
              user_id: user.id,
              amount: totalRefund,
              balance_after: newBalance,
              type: "refund",
              description: `Возврат за неудачную генерацию`,
              reference_id: trackId,
              reference_type: "track",
              metadata: {
                error: russianErrorMessage
              }
            });
            console.log(`Refunded ${totalRefund} to user ${user.id}`);
          }
        }
      }
      // Also mark other pending tracks as failed
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: russianErrorMessage
      }).eq("user_id", user.id).in("status", [
        "pending",
        "processing"
      ]);
      // Create notification for refund with Russian error explanation
      if (totalRefund > 0) {
        await supabaseAdmin.from("notifications").insert({
          user_id: user.id,
          type: "refund",
          title: `Ошибка: ${russianErrorMessage}`,
          message: `${errorInfo.full}\n\nВам возвращено ${totalRefund} ₽`,
          target_type: "track",
          target_id: trackId
        });
      }
      return new Response(JSON.stringify({
        error: russianErrorMessage,
        details: errorInfo.full,
        refunded: totalRefund > 0,
        refundAmount: totalRefund
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const taskId = sunoData.data?.taskId;
    console.log(`Generation started with task ID: ${taskId}`);
    // CRITICAL: Store task_id in description for ONLY the current track pair (v1 and v2)
    // This is essential for the callback to match results to the correct tracks
    // DO NOT update other pending tracks - they have their own task_id from their own generation!
    if (taskId) {
      // Get the current track's info including created_at to find its pair
      const { data: currentTrack } = await supabaseClient.from("tracks").select("id, title, description, created_at").eq("id", trackId).single();
      if (currentTrack) {
        // Find the paired track: same base title, same user, created within 5 seconds
        const baseTitle = (currentTrack.title || "").replace(/\s*\(v\d+\)$/, "").trim();
        const createdAt = new Date(currentTrack.created_at);
        const windowStart = new Date(createdAt.getTime() - 5000).toISOString();
        const windowEnd = new Date(createdAt.getTime() + 5000).toISOString();
        const { data: pairedTracks } = await supabaseClient.from("tracks").select("id, title, description, created_at").eq("user_id", user.id).gte("created_at", windowStart).lte("created_at", windowEnd);
        const filtered = pairedTracks?.filter((t)=>{
          const tBaseTitle = (t.title || "").replace(/\s*\(v\d+\)$/, "").trim();
          return tBaseTitle === baseTitle;
        }) || [];
        // CRITICAL FIX: empty array is truthy, so check .length explicitly
        const tracksToUpdate = filtered.length > 0 ? filtered : [
          currentTrack
        ];
        console.log(`Found ${tracksToUpdate.length} tracks in pair to update with task_id (filtered: ${filtered.length}, paired: ${pairedTracks?.length || 0})`);
        for (const track of tracksToUpdate){
          // IMPORTANT: Only update if this track doesn't already have a task_id
          // This prevents overwriting task_id from a different generation
          if (track.description?.includes("[task_id:")) {
            console.log(`Track ${track.id} (${track.title}) already has task_id, skipping to prevent overwrite`);
            continue;
          }
          // Append task_id to description (preserve existing content)
          const existingDesc = track.description || "";
          const newDesc = existingDesc ? `${existingDesc}\n\n[task_id: ${taskId}]` : `[task_id: ${taskId}]`;
          await supabaseClient.from("tracks").update({
            description: newDesc
          }).eq("id", track.id);
          console.log(`Stored task_id ${taskId} in track ${track.id} (${track.title})`);
        }
      } else {
        // Fallback: at least update the current track
        const newDesc = `[task_id: ${taskId}]`;
        await supabaseClient.from("tracks").update({
          description: newDesc
        }).eq("id", trackId);
        console.log(`Stored task_id ${taskId} in track ${trackId} (fallback)`);
      }
    }
    return new Response(JSON.stringify({
      success: true,
      taskId,
      message: "Generation started successfully"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in suno-generate:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: "Произошла непредвиденная ошибка. Попробуйте позже."
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9zdW5vLWdlbmVyYXRlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5jb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG5jb25zdCBTVU5PX0FQSV9CQVNFID0gXCJodHRwczovL2FwaWJveC5lcndlaW1hLmFpXCI7XG5cbi8vIEh1bWFuLXJlYWRhYmxlIGVycm9yIG1lc3NhZ2VzIGZvciBTdW5vIGVycm9yIGNvZGVzIChSdXNzaWFuKVxuLy8gT2ZmaWNpYWwgU3VubyBBUEkgZXJyb3IgY29kZXM6XG4vLyA0MDAgLSBJbnZhbGlkIFBhcmFtZXRlcnMsIDQwMSAtIFVuYXV0aG9yaXplZCwgNDAzIC0gRm9yYmlkZGVuIChtb2RlcmF0aW9uKVxuLy8gNDA0IC0gTm90IEZvdW5kLCA0MDUgLSBSYXRlIExpbWl0ZWQsIDQxMyAtIENvbnRlbnQgVG9vIExhcmdlXG4vLyA0MjkgLSBJbnN1ZmZpY2llbnQgQ3JlZGl0cywgNDU1IC0gTWFpbnRlbmFuY2UsIDUwMC81MDMgLSBTZXJ2ZXIgZXJyb3JzXG5mdW5jdGlvbiBnZXRTdW5vRXJyb3JNZXNzYWdlKGNvZGU6IG51bWJlciwgb3JpZ2luYWxNZXNzYWdlPzogc3RyaW5nKTogeyBzaG9ydDogc3RyaW5nOyBmdWxsOiBzdHJpbmcgfSB7XG4gIC8vIEZpcnN0LCBjaGVjayBmb3Igc3BlY2lmaWMgZXJyb3IgbWVzc2FnZSBwYXR0ZXJucyAobW9yZSBhY2N1cmF0ZSB0aGFuIGNvZGUpXG4gIGlmIChvcmlnaW5hbE1lc3NhZ2UpIHtcbiAgICBjb25zdCBsb3dlck1zZyA9IG9yaWdpbmFsTWVzc2FnZS50b0xvd2VyQ2FzZSgpO1xuICAgIFxuICAgIGlmIChsb3dlck1zZy5pbmNsdWRlcyhcIm1hdGNoZXMgZXhpc3Rpbmcgd29ya1wiKSB8fCBcbiAgICAgICAgbG93ZXJNc2cuaW5jbHVkZXMoXCJleGlzdGluZyB3b3JrIG9mIGFydFwiKSB8fFxuICAgICAgICBsb3dlck1zZy5pbmNsdWRlcyhcImNvcHlyaWdodFwiKSB8fFxuICAgICAgICBsb3dlck1zZy5pbmNsdWRlcyhcInByb3RlY3RlZCBjb250ZW50XCIpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzaG9ydDogXCLQmtC+0L3RgtC10L3RgiDQt9Cw0YnQuNGJ0ZHQvSDQsNCy0YLQvtGA0YHQutC40Lwg0L/RgNCw0LLQvtC8XCIsXG4gICAgICAgIGZ1bGw6IFwi0JfQsNCz0YDRg9C20LXQvdC90YvQuSDQsNGD0LTQuNC+0YTQsNC50Lsg0LjQu9C4INGC0LXQutGB0YIg0YDQsNGB0L/QvtC30L3QsNC9INC60LDQuiDRgdGD0YnQtdGB0YLQstGD0Y7RidC10LUg0L/RgNC+0LjQt9Cy0LXQtNC10L3QuNC1LiDQn9C+0L/RgNC+0LHRg9C50YLQtSDQuNGB0L/QvtC70YzQt9C+0LLQsNGC0Ywg0L7RgNC40LPQuNC90LDQu9GM0L3Ri9C5INC60L7QvdGC0LXQvdGCLlwiXG4gICAgICB9O1xuICAgIH1cbiAgICBcbiAgICBpZiAobG93ZXJNc2cuaW5jbHVkZXMoXCJtb2RlcmF0aW9uXCIpIHx8IFxuICAgICAgICBsb3dlck1zZy5pbmNsdWRlcyhcInNlbnNpdGl2ZVwiKSB8fCBcbiAgICAgICAgbG93ZXJNc2cuaW5jbHVkZXMoXCJpbmFwcHJvcHJpYXRlXCIpIHx8XG4gICAgICAgIGxvd2VyTXNnLmluY2x1ZGVzKFwicHJvaGliaXRlZFwiKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2hvcnQ6IFwi0JrQvtC90YLQtdC90YIg0L3QtSDQv9GA0L7RiNGR0Lsg0LzQvtC00LXRgNCw0YbQuNGOXCIsXG4gICAgICAgIGZ1bGw6IFwi0KLQtdC60YHRgiDQuNC70Lgg0L7Qv9C40YHQsNC90LjQtSDRgdC+0LTQtdGA0LbQuNGCINC30LDQv9GA0LXRidGR0L3QvdGL0LUg0YHQu9C+0LLQsC4g0JjQt9C80LXQvdC40YLQtSDRgdC+0LTQtdGA0LbQuNC80L7QtSDQuCDQv9C+0L/RgNC+0LHRg9C50YLQtSDRgdC90L7QstCwLlwiXG4gICAgICB9O1xuICAgIH1cbiAgICBcbiAgICBpZiAobG93ZXJNc2cuaW5jbHVkZXMoXCJ0b28gbG9uZ1wiKSB8fCBsb3dlck1zZy5pbmNsdWRlcyhcInRvbyBsYXJnZVwiKSB8fCBsb3dlck1zZy5pbmNsdWRlcyhcImV4Y2VlZHNcIikpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHNob3J0OiBcItCf0YDQtdCy0YvRiNC10L0g0LvQuNC80LjRgiDRgdC40LzQstC+0LvQvtCyXCIsXG4gICAgICAgIGZ1bGw6IFwi0J7Qv9C40YHQsNC90LjQtSwg0YHRgtC40LvRjCDQuNC70Lgg0YLQtdC60YHRgiDQv9C10YHQvdC4INGB0LvQuNGI0LrQvtC8INC00LvQuNC90L3Ri9C1LiDQodC+0LrRgNCw0YLQuNGC0LUg0YLQtdC60YHRgiDQuCDQv9C+0L/RgNC+0LHRg9C50YLQtSDRgdC90L7QstCwLlwiXG4gICAgICB9O1xuICAgIH1cbiAgICBcbiAgICBpZiAobG93ZXJNc2cuaW5jbHVkZXMoXCJjcmVkaXRcIikgfHwgbG93ZXJNc2cuaW5jbHVkZXMoXCJiYWxhbmNlXCIpIHx8IGxvd2VyTXNnLmluY2x1ZGVzKFwiaW5zdWZmaWNpZW50XCIpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzaG9ydDogXCLQndC10LTQvtGB0YLQsNGC0L7Rh9C90L4g0LrRgNC10LTQuNGC0L7QsiBTdW5vXCIsXG4gICAgICAgIGZ1bGw6IFwi0J3QsCDQsNC60LrQsNGD0L3RgtC1IFN1bm8g0L3QtdC00L7RgdGC0LDRgtC+0YfQvdC+INC60YDQtdC00LjRgtC+0LIg0LTQu9GPINCz0LXQvdC10YDQsNGG0LjQuC4g0J7QsdGA0LDRgtC40YLQtdGB0Ywg0LIg0L/QvtC00LTQtdGA0LbQutGDLlwiXG4gICAgICB9O1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGVycm9yTWVzc2FnZXM6IFJlY29yZDxudW1iZXIsIHsgc2hvcnQ6IHN0cmluZzsgZnVsbDogc3RyaW5nIH0+ID0ge1xuICAgIDQwMDogeyBzaG9ydDogXCLQndC10LLQtdGA0L3Ri9C1INC/0LDRgNCw0LzQtdGC0YDRiyDQt9Cw0L/RgNC+0YHQsFwiLCBmdWxsOiBcItCf0YDQvtCy0LXRgNGM0YLQtSDQstCy0LXQtNGR0L3QvdGL0LUg0LTQsNC90L3Ri9C1INC4INC/0L7Qv9GA0L7QsdGD0LnRgtC1INGB0L3QvtCy0LAuXCIgfSxcbiAgICA0MDE6IHsgc2hvcnQ6IFwi0J7RiNC40LHQutCwINCw0LLRgtC+0YDQuNC30LDRhtC40LhcIiwgZnVsbDogXCLQn9GA0L7QsdC70LXQvNCwINGBINCw0LLRgtC+0YDQuNC30LDRhtC40LXQuSDQsiDRgdC10YDQstC40YHQtSBTdW5vLiDQntCx0YDQsNGC0LjRgtC10YHRjCDQsiDQv9C+0LTQtNC10YDQttC60YMuXCIgfSxcbiAgICA0MDM6IHsgc2hvcnQ6IFwi0JrQvtC90YLQtdC90YIg0LfQsNCx0LvQvtC60LjRgNC+0LLQsNC9XCIsIGZ1bGw6IFwi0JfQsNC/0YDQvtGBINGB0L7QtNC10YDQttC40YIg0LfQsNC/0YDQtdGJ0ZHQvdC90YvQuSDQutC+0L3RgtC10L3Rgi4g0JjQt9C80LXQvdC40YLQtSDRgtC10LrRgdGCINC40LvQuCDQvtC/0LjRgdCw0L3QuNC1LlwiIH0sXG4gICAgNDA0OiB7IHNob3J0OiBcItCg0LXRgdGD0YDRgSDQvdC1INC90LDQudC00LXQvVwiLCBmdWxsOiBcItCX0LDQv9GA0LDRiNC40LLQsNC10LzRi9C5INGA0LXRgdGD0YDRgSDQvdC1INC90LDQudC00LXQvS4g0J/QvtC/0YDQvtCx0YPQudGC0LUg0LXRidGRINGA0LDQty5cIiB9LFxuICAgIDQwNTogeyBzaG9ydDogXCLQn9GA0LXQstGL0YjQtdC90LAg0YfQsNGB0YLQvtGC0LAg0LfQsNC/0YDQvtGB0L7QslwiLCBmdWxsOiBcItCh0LvQuNGI0LrQvtC8INC80L3QvtCz0L4g0LfQsNC/0YDQvtGB0L7Qsi4g0J/QvtC00L7QttC00LjRgtC1INC90LXRgdC60L7Qu9GM0LrQviDQvNC40L3Rg9GCLlwiIH0sXG4gICAgNDEzOiB7IHNob3J0OiBcItCf0YDQtdCy0YvRiNC10L0g0LvQuNC80LjRgiDRgdC40LzQstC+0LvQvtCyXCIsIGZ1bGw6IFwi0KLQtdC60YHRgiDRgdC70LjRiNC60L7QvCDQtNC70LjQvdC90YvQuSAo0LzQsNC60YEuIH4zMDAwINGB0LjQvNCy0L7Qu9C+0LIg0LTQu9GPIGx5cmljcykuINCh0L7QutGA0LDRgtC40YLQtSDQuCDQv9C+0L/RgNC+0LHRg9C50YLQtSDRgdC90L7QstCwLlwiIH0sXG4gICAgNDI5OiB7IHNob3J0OiBcItCd0LXQtNC+0YHRgtCw0YLQvtGH0L3QviDQutGA0LXQtNC40YLQvtCyXCIsIGZ1bGw6IFwi0J3QsCDQsNC60LrQsNGD0L3RgtC1IFN1bm8g0L3QtdC00L7RgdGC0LDRgtC+0YfQvdC+INC60YDQtdC00LjRgtC+0LIuINCe0LHRgNCw0YLQuNGC0LXRgdGMINCyINC/0L7QtNC00LXRgNC20LrRgy5cIiB9LFxuICAgIDQ1NTogeyBzaG9ydDogXCLQodC10YDQstC40YEg0L3QsCDQvtCx0YHQu9GD0LbQuNCy0LDQvdC40LhcIiwgZnVsbDogXCJTdW5vINC/0YDQvtGF0L7QtNC40YIg0YLQtdGF0L3QuNGH0LXRgdC60L7QtSDQvtCx0YHQu9GD0LbQuNCy0LDQvdC40LUuINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC/0L7Qt9C20LUuXCIgfSxcbiAgICA1MDA6IHsgc2hvcnQ6IFwi0J7RiNC40LHQutCwINGB0LXRgNCy0LXRgNCwIFN1bm9cIiwgZnVsbDogXCLQktC90YPRgtGA0LXQvdC90Y/RjyDQvtGI0LjQsdC60LAg0L3QsCDRgdC10YDQstC10YDQtSBTdW5vLiDQn9C+0L/RgNC+0LHRg9C50YLQtSDQv9C+0LfQttC1LlwiIH0sXG4gICAgNTAzOiB7IHNob3J0OiBcItCh0LXRgNCy0LjRgSDQvdC10LTQvtGB0YLRg9C/0LXQvVwiLCBmdWxsOiBcIlN1bm8g0LLRgNC10LzQtdC90L3QviDQv9C10YDQtdCz0YDRg9C20LXQvS4g0J/QvtC/0YDQvtCx0YPQudGC0LUg0L/QvtC30LbQtS5cIiB9XG4gIH07XG4gIFxuICBpZiAoZXJyb3JNZXNzYWdlc1tjb2RlXSkge1xuICAgIHJldHVybiBlcnJvck1lc3NhZ2VzW2NvZGVdO1xuICB9XG4gIFxuICByZXR1cm4ge1xuICAgIHNob3J0OiBg0J7RiNC40LHQutCwINCz0LXQvdC10YDQsNGG0LjQuCAo0LrQvtC0ICR7Y29kZX0pYCxcbiAgICBmdWxsOiBvcmlnaW5hbE1lc3NhZ2UgfHwgYNCf0YDQvtC40LfQvtGI0LvQsCDQvtGI0LjQsdC60LAg0L/RgNC4INCz0LXQvdC10YDQsNGG0LjQuC4g0JrQvtC0OiAke2NvZGV9YFxuICB9O1xufVxuXG4vLyBNYXAgYXJ0aXN0IG5hbWVzIHRvIGdlbnJlL3N0eWxlIGRlc2NyaXB0aW9ucyAoU3VubyBkb2Vzbid0IGFsbG93IGFydGlzdCBuYW1lcylcbmNvbnN0IGFydGlzdFRvU3R5bGVNYXA6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIFwiRHJha2VcIjogXCJtb29keSB0cmFwIGhpcC1ob3Agd2l0aCBtZWxvZGljIGhvb2tzXCIsXG4gIFwiVGhlIFdlZWtuZFwiOiBcImRhcmsgc3ludGgtcG9wIFImQiB3aXRoIGZhbHNldHRvIHZvY2Fsc1wiLFxuICBcIlRheWxvciBTd2lmdFwiOiBcImNhdGNoeSBwb3AtY291bnRyeSB3aXRoIHN0b3J5dGVsbGluZyBseXJpY3NcIixcbiAgXCJFZCBTaGVlcmFuXCI6IFwiYWNvdXN0aWMgcG9wIGZvbGsgd2l0aCByb21hbnRpYyB0aGVtZXNcIixcbiAgXCJCaWxsaWUgRWlsaXNoXCI6IFwiZGFyayBtaW5pbWFsaXN0IHBvcCB3aXRoIHdoaXNwZXJlZCB2b2NhbHNcIixcbiAgXCJBcmlhbmEgR3JhbmRlXCI6IFwicG93ZXJmdWwgcG9wIFImQiB3aXRoIGhpZ2ggdm9jYWxzXCIsXG4gIFwiRHVhIExpcGFcIjogXCJkaXNjby1pbmZsdWVuY2VkIGRhbmNlIHBvcFwiLFxuICBcIkJhZCBCdW5ueVwiOiBcInJlZ2dhZXRvbiBsYXRpbiB0cmFwIHdpdGggdXJiYW4gYmVhdHNcIixcbiAgXCJQb3N0IE1hbG9uZVwiOiBcIm1lbG9kaWMgaGlwLWhvcCByb2NrIGZ1c2lvblwiLFxuICBcIktlbmRyaWNrIExhbWFyXCI6IFwiY29uc2Npb3VzIGx5cmljYWwgaGlwLWhvcFwiLFxuICBcIkJleW9uY8OpXCI6IFwicG93ZXJmdWwgUiZCIHBvcCB3aXRoIHNvdWxmdWwgdm9jYWxzXCIsXG4gIFwiQlRTXCI6IFwiSy1wb3Agd2l0aCBkeW5hbWljIGNob3Jlb2dyYXBoeSB2aWJlc1wiLFxuICBcIkhhcnJ5IFN0eWxlc1wiOiBcIjcwcyBpbnNwaXJlZCBzb2Z0IHJvY2sgcG9wXCIsXG4gIFwiRG9qYSBDYXRcIjogXCJwbGF5ZnVsIHJhcC1wb3Agd2l0aCBjYXRjaHkgaG9va3NcIixcbiAgXCJTWkFcIjogXCJuZW8tc291bCBSJkIgd2l0aCB2dWxuZXJhYmxlIGx5cmljc1wiLFxuICBcIlRyYXZpcyBTY290dFwiOiBcImF0bW9zcGhlcmljIGF1dG8tdHVuZSB0cmFwXCIsXG4gIFwiT2xpdmlhIFJvZHJpZ29cIjogXCJlbW90aW9uYWwgcG9wLXJvY2sgd2l0aCB0ZWVuIGFuZ3N0XCIsXG4gIFwiTGFuYSBEZWwgUmV5XCI6IFwiY2luZW1hdGljIGRyZWFteSBiYXJvcXVlIHBvcFwiLFxuICBcIkthbnllIFdlc3RcIjogXCJleHBlcmltZW50YWwgaGlwLWhvcCB3aXRoIGdvc3BlbCBpbmZsdWVuY2VzXCIsXG4gIFwiQnJ1bm8gTWFyc1wiOiBcImZ1bmsgcG9wIHdpdGggcmV0cm8gZ3Jvb3Zlc1wiLFxuICBcIkFkZWxlXCI6IFwicG93ZXJmdWwgYmFsbGFkcyB3aXRoIHNvdWxmdWwgdm9jYWxzXCIsXG4gIFwiUmloYW5uYVwiOiBcImRhbmNlaGFsbC1pbmZsdWVuY2VkIHBvcCBSJkJcIixcbiAgXCJKdXN0aW4gQmllYmVyXCI6IFwicG9wIFImQiB3aXRoIHRyb3BpY2FsIGluZmx1ZW5jZXNcIixcbiAgXCJMYWR5IEdhZ2FcIjogXCJ0aGVhdHJpY2FsIGVsZWN0cm8tcG9wXCIsXG4gIFwiU2hha2lyYVwiOiBcImxhdGluIHBvcCB3aXRoIHdvcmxkIG11c2ljIGZ1c2lvblwiLFxuICBcIkNvbGRwbGF5XCI6IFwiYW50aGVtaWMgYWx0ZXJuYXRpdmUgcm9jayB3aXRoIGF0bW9zcGhlcmljIHN5bnRoc1wiLFxuICBcIkltYWdpbmUgRHJhZ29uc1wiOiBcImFyZW5hIHJvY2sgd2l0aCBlbGVjdHJvbmljIGVsZW1lbnRzXCIsXG4gIFwiVHdlbnR5IE9uZSBQaWxvdHNcIjogXCJhbHRlcm5hdGl2ZSBoaXAtaG9wIHdpdGggZWxlY3Ryb25pYyBlbGVtZW50c1wiLFxuICBcIk1hcm9vbiA1XCI6IFwicG9wIHJvY2sgd2l0aCBmdW5reSBncm9vdmVzXCIsXG4gIFwiT25lUmVwdWJsaWNcIjogXCJvcmNoZXN0cmFsIHBvcCByb2NrIHdpdGggdXBsaWZ0aW5nIHRoZW1lc1wiLFxufTtcblxuLy8gQ29udmVydCBhcnRpc3QgbmFtZSB0byBzYWZlIHN0eWxlIGRlc2NyaXB0aW9uXG5mdW5jdGlvbiBjb252ZXJ0QXJ0aXN0VG9TdHlsZShhcnRpc3ROYW1lOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoYXJ0aXN0VG9TdHlsZU1hcFthcnRpc3ROYW1lXSkge1xuICAgIHJldHVybiBhcnRpc3RUb1N0eWxlTWFwW2FydGlzdE5hbWVdO1xuICB9XG4gIFxuICBjb25zdCBsb3dlck5hbWUgPSBhcnRpc3ROYW1lLnRvTG93ZXJDYXNlKCk7XG4gIGZvciAoY29uc3QgW2FydGlzdCwgc3R5bGVdIG9mIE9iamVjdC5lbnRyaWVzKGFydGlzdFRvU3R5bGVNYXApKSB7XG4gICAgaWYgKGFydGlzdC50b0xvd2VyQ2FzZSgpID09PSBsb3dlck5hbWUpIHtcbiAgICAgIHJldHVybiBzdHlsZTtcbiAgICB9XG4gIH1cbiAgXG4gIHJldHVybiBcImNvbnRlbXBvcmFyeSBwb3Agd2l0aCBtb2Rlcm4gcHJvZHVjdGlvblwiO1xufVxuXG4vLyBDbGVhbiBzdHlsZSBzdHJpbmcgdG8gcmVtb3ZlIGFydGlzdCBuYW1lc1xuZnVuY3Rpb24gY2xlYW5TdHlsZUZvclN1bm8oc3R5bGU6IHN0cmluZyk6IHN0cmluZyB7XG4gIGlmICghc3R5bGUpIHJldHVybiBcIlwiO1xuICBcbiAgbGV0IGNsZWFuZWRTdHlsZSA9IHN0eWxlO1xuICBcbiAgZm9yIChjb25zdCBhcnRpc3ROYW1lIG9mIE9iamVjdC5rZXlzKGFydGlzdFRvU3R5bGVNYXApKSB7XG4gICAgY29uc3QgcmVnZXggPSBuZXcgUmVnRXhwKGAke2FydGlzdE5hbWV9XFxcXHMqc3R5bGVgLCBcImdpXCIpO1xuICAgIGlmIChyZWdleC50ZXN0KGNsZWFuZWRTdHlsZSkpIHtcbiAgICAgIGNsZWFuZWRTdHlsZSA9IGNsZWFuZWRTdHlsZS5yZXBsYWNlKHJlZ2V4LCBjb252ZXJ0QXJ0aXN0VG9TdHlsZShhcnRpc3ROYW1lKSk7XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHN0YW5kYWxvbmVSZWdleCA9IG5ldyBSZWdFeHAoYFxcXFxiJHthcnRpc3ROYW1lfVxcXFxiYCwgXCJnaVwiKTtcbiAgICBpZiAoc3RhbmRhbG9uZVJlZ2V4LnRlc3QoY2xlYW5lZFN0eWxlKSkge1xuICAgICAgY2xlYW5lZFN0eWxlID0gY2xlYW5lZFN0eWxlLnJlcGxhY2Uoc3RhbmRhbG9uZVJlZ2V4LCBjb252ZXJ0QXJ0aXN0VG9TdHlsZShhcnRpc3ROYW1lKSk7XG4gICAgfVxuICB9XG4gIFxuICBjbGVhbmVkU3R5bGUgPSBjbGVhbmVkU3R5bGUucmVwbGFjZSgvLFxccyosL2csIFwiLFwiKS5yZXBsYWNlKC9cXHMrL2csIFwiIFwiKS50cmltKCk7XG4gIFxuICByZXR1cm4gY2xlYW5lZFN0eWxlO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk5vIGF1dGhvcml6YXRpb24gaGVhZGVyXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZUNsaWVudCA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikgPz8gXCJcIixcbiAgICAgIHsgZ2xvYmFsOiB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYXV0aEhlYWRlciB9IH0gfVxuICAgICk7XG5cbiAgICAvLyBBbHNvIGNyZWF0ZSBhZG1pbiBjbGllbnQgZm9yIGNyZWF0aW5nIG5vdGlmaWNhdGlvbnNcbiAgICBjb25zdCBzdXBhYmFzZUFkbWluID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpID8/IFwiXCIsXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpID8/IFwiXCJcbiAgICApO1xuXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IHVzZXJFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnQuYXV0aC5nZXRVc2VyKCk7XG4gICAgaWYgKHVzZXJFcnJvciB8fCAhdXNlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIFAwIEZJWDogQ2hlY2sgaWYgdXNlciBpcyBibG9ja2VkIGJlZm9yZSBhbGxvd2luZyBnZW5lcmF0aW9uXG4gICAgY29uc3QgeyBkYXRhOiBpc0Jsb2NrZWQgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW4ucnBjKFwiaXNfdXNlcl9ibG9ja2VkXCIsIHsgcF91c2VyX2lkOiB1c2VyLmlkIH0pO1xuICAgIGlmIChpc0Jsb2NrZWQpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0JLQsNGIINCw0LrQutCw0YPQvdGCINC30LDQsdC70L7QutC40YDQvtCy0LDQvS4g0JPQtdC90LXRgNCw0YbQuNGPINC90LXQtNC+0YHRgtGD0L/QvdCwLlwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgeyB0cmFja0lkLCBwcm9tcHQsIGx5cmljcywgc3R5bGUsIHRpdGxlLCBpbnN0cnVtZW50YWwsIGF1ZGlvUmVmZXJlbmNlVXJsIH0gPSBhd2FpdCByZXEuanNvbigpO1xuXG4gICAgaWYgKCF0cmFja0lkIHx8ICFwcm9tcHQpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiTWlzc2luZyByZXF1aXJlZCBmaWVsZHM6IHRyYWNrSWQsIHByb21wdFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFN0YXJ0aW5nIGdlbmVyYXRpb24gZm9yIHRyYWNrICR7dHJhY2tJZH0gYnkgdXNlciAke3VzZXIuaWR9YCk7XG4gICAgY29uc29sZS5sb2coYE9yaWdpbmFsIHByb21wdDogJHtwcm9tcHR9YCk7XG4gICAgY29uc29sZS5sb2coYE9yaWdpbmFsIHN0eWxlOiAke3N0eWxlfWApO1xuICAgIGNvbnNvbGUubG9nKGBJbnN0cnVtZW50YWw6ICR7aW5zdHJ1bWVudGFsfWApO1xuICAgIGNvbnNvbGUubG9nKGBBdWRpbyByZWZlcmVuY2UgVVJMOiAke2F1ZGlvUmVmZXJlbmNlVXJsIHx8ICdub25lJ31gKTtcblxuICAgIC8vIENsZWFuIHRoZSBzdHlsZSB0byByZW1vdmUgYXJ0aXN0IG5hbWVzXG4gICAgY29uc3QgY2xlYW5lZFN0eWxlID0gY2xlYW5TdHlsZUZvclN1bm8oc3R5bGUgfHwgXCJcIik7XG4gICAgY29uc29sZS5sb2coYENsZWFuZWQgc3R5bGU6ICR7Y2xlYW5lZFN0eWxlfWApO1xuXG4gICAgLy8gVXBkYXRlIHRyYWNrIHN0YXR1cyB0byBwcm9jZXNzaW5nXG4gICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJwcm9jZXNzaW5nXCIsIGVycm9yX21lc3NhZ2U6IG51bGwgfSlcbiAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpO1xuXG4gICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSB0cmFjayBzdGF0dXM6XCIsIHVwZGF0ZUVycm9yKTtcbiAgICB9XG5cbiAgICAvLyBCdWlsZCB0aGUgU3VubyBBUEkgcGF5bG9hZCBhY2NvcmRpbmcgdG8gZG9jdW1lbnRhdGlvblxuICAgIGNvbnN0IGhhc0x5cmljcyA9ICEhbHlyaWNzICYmIGx5cmljcy50cmltKCkubGVuZ3RoID4gMDtcbiAgICBjb25zdCBoYXNTdHlsZSA9ICEhY2xlYW5lZFN0eWxlICYmIGNsZWFuZWRTdHlsZS50cmltKCkubGVuZ3RoID4gMDtcbiAgICBjb25zdCBoYXNQcm9tcHQgPSAhIXByb21wdCAmJiBwcm9tcHQudHJpbSgpLmxlbmd0aCA+IDA7XG4gICAgY29uc3QgdXNlQ3VzdG9tTW9kZSA9IGhhc0x5cmljcyB8fCBoYXNTdHlsZTtcblxuICAgIC8vIENsZWFuIHRoZSBwcm9tcHQgKGRlc2NyaXB0aW9uKSBhcyB3ZWxsXG4gICAgY29uc3QgY2xlYW5lZFByb21wdCA9IGNsZWFuU3R5bGVGb3JTdW5vKHByb21wdCB8fCBcIlwiKTtcbiAgICBjb25zb2xlLmxvZyhgQ2xlYW5lZCBwcm9tcHQgKGRlc2NyaXB0aW9uKTogJHtjbGVhbmVkUHJvbXB0fWApO1xuXG4gICAgLy8gQnVpbGQgY2FsbGJhY2sgVVJMIHdpdGggc2VjcmV0IGZvciBzZWN1cml0eVxuICAgIC8vIFVzZSBTVU5PX0NBTExCQUNLX1VSTCBpZiBzZXQgKHNob3VsZCBiZSBwdWJsaWMgVVJMKSwgb3RoZXJ3aXNlIGZhbGwgYmFjayB0byBTVVBBQkFTRV9VUkxcbiAgICBjb25zdCBjYWxsYmFja1NlY3JldCA9IERlbm8uZW52LmdldChcIlNVTk9fQ0FMTEJBQ0tfU0VDUkVUXCIpO1xuICAgIGNvbnN0IGV4cGxpY2l0Q2FsbGJhY2tVcmwgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0NBTExCQUNLX1VSTFwiKTtcbiAgICBjb25zdCBiYXNlQ2FsbGJhY2tVcmwgPSBleHBsaWNpdENhbGxiYWNrVXJsIHx8IGAke0Rlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKX0vZnVuY3Rpb25zL3YxL3N1bm8tY2FsbGJhY2tgO1xuICAgIGNvbnN0IGNhbGxCYWNrVXJsID0gY2FsbGJhY2tTZWNyZXQgXG4gICAgICA/IGAke2Jhc2VDYWxsYmFja1VybH0ke2Jhc2VDYWxsYmFja1VybC5pbmNsdWRlcygnPycpID8gJyYnIDogJz8nfXNlY3JldD0ke2VuY29kZVVSSUNvbXBvbmVudChjYWxsYmFja1NlY3JldCl9YFxuICAgICAgOiBiYXNlQ2FsbGJhY2tVcmw7XG4gICAgY29uc29sZS5sb2coYENhbGxiYWNrIFVSTDogJHtjYWxsQmFja1VybH1gKTtcblxuICAgIGNvbnN0IHN1bm9QYXlsb2FkOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge1xuICAgICAgbW9kZWw6IFwiVjRcIixcbiAgICAgIGN1c3RvbU1vZGU6IHVzZUN1c3RvbU1vZGUsXG4gICAgICBpbnN0cnVtZW50YWw6IGluc3RydW1lbnRhbCB8fCBmYWxzZSxcbiAgICAgIGNhbGxCYWNrVXJsLFxuICAgIH07XG5cbiAgICBpZiAodXNlQ3VzdG9tTW9kZSkge1xuICAgICAgLy8gcHJvbXB0IGZpZWxkID0gbHlyaWNzIChpZiBwcmVzZW50KSBvciBkZXNjcmlwdGlvblxuICAgICAgc3Vub1BheWxvYWQucHJvbXB0ID0gaGFzTHlyaWNzID8gbHlyaWNzIDogcHJvbXB0O1xuICAgICAgXG4gICAgICAvLyBDUklUSUNBTDogc3R5bGUgZmllbGQgc2hvdWxkIE9OTFkgY29udGFpbiBnZW5yZS92b2NhbC9zdHlsZSB0YWdzIC0gTk9UIHRoZSBkZXNjcmlwdGlvbiFcbiAgICAgIC8vIFN1bm8gaGFzIGEgc3RyaWN0IDIwMCBjaGFyYWN0ZXIgbGltaXQgb24gc3R5bGUgZmllbGRcbiAgICAgIC8vIERlc2NyaXB0aW9uIGdvZXMgaW4gdGhlIHByb21wdCwgbm90IGluIHN0eWxlXG4gICAgICBsZXQgZmluYWxTdHlsZSA9IGNsZWFuZWRTdHlsZSB8fCBcInBvcFwiO1xuICAgICAgXG4gICAgICAvLyBUcnVuY2F0ZSBzdHlsZSB0byAyMDAgY2hhcnMgbWF4IChTdW5vIGxpbWl0KVxuICAgICAgaWYgKGZpbmFsU3R5bGUubGVuZ3RoID4gMjAwKSB7XG4gICAgICAgIC8vIEtlZXAgdGhlIG1vc3QgaW1wb3J0YW50IHRhZ3MgKGZpcnN0IG9uZXMpIGFuZCBjdXQgYXQgY29tbWEgYm91bmRhcnlcbiAgICAgICAgY29uc3QgcGFydHMgPSBmaW5hbFN0eWxlLnNwbGl0KFwiLCBcIik7XG4gICAgICAgIGxldCB0cnVuY2F0ZWQgPSBcIlwiO1xuICAgICAgICBmb3IgKGNvbnN0IHBhcnQgb2YgcGFydHMpIHtcbiAgICAgICAgICBpZiAoKHRydW5jYXRlZCArIFwiLCBcIiArIHBhcnQpLmxlbmd0aCA8PSAyMDApIHtcbiAgICAgICAgICAgIHRydW5jYXRlZCA9IHRydW5jYXRlZCA/IHRydW5jYXRlZCArIFwiLCBcIiArIHBhcnQgOiBwYXJ0O1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZmluYWxTdHlsZSA9IHRydW5jYXRlZCB8fCBmaW5hbFN0eWxlLnNsaWNlKDAsIDIwMCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBTdHlsZSB0cnVuY2F0ZWQgZnJvbSAke2NsZWFuZWRTdHlsZS5sZW5ndGh9IHRvICR7ZmluYWxTdHlsZS5sZW5ndGh9IGNoYXJzYCk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIHN1bm9QYXlsb2FkLnN0eWxlID0gZmluYWxTdHlsZTtcbiAgICAgIHN1bm9QYXlsb2FkLnRpdGxlID0gdGl0bGUgfHwgXCJVbnRpdGxlZFwiO1xuICAgICAgXG4gICAgICBjb25zb2xlLmxvZyhgRmluYWwgc3R5bGUgZm9yIFN1bm8gKCR7c3Vub1BheWxvYWQuc3R5bGUubGVuZ3RofSBjaGFycyk6ICR7c3Vub1BheWxvYWQuc3R5bGV9YCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN1bm9QYXlsb2FkLnByb21wdCA9IHByb21wdC5zbGljZSgwLCA0MDApO1xuICAgIH1cblxuICAgIC8vIERldGVybWluZSB3aGljaCBlbmRwb2ludCB0byB1c2VcbiAgICBsZXQgc3Vub0VuZHBvaW50ID0gYCR7U1VOT19BUElfQkFTRX0vYXBpL3YxL2dlbmVyYXRlYDtcbiAgICBcbiAgICAvLyBJZiBhdWRpbyByZWZlcmVuY2UgaXMgcHJvdmlkZWQsIHVzZSB1cGxvYWQtY292ZXIgZW5kcG9pbnQgaW5zdGVhZFxuICAgIGlmIChhdWRpb1JlZmVyZW5jZVVybCkge1xuICAgICAgc3Vub0VuZHBvaW50ID0gYCR7U1VOT19BUElfQkFTRX0vYXBpL3YxL2dlbmVyYXRlL3VwbG9hZC1jb3ZlcmA7XG4gICAgICBzdW5vUGF5bG9hZC51cGxvYWRVcmwgPSBhdWRpb1JlZmVyZW5jZVVybDtcbiAgICAgIGNvbnNvbGUubG9nKFwiVXNpbmcgdXBsb2FkLWNvdmVyIGVuZHBvaW50IHdpdGggYXVkaW8gcmVmZXJlbmNlXCIpO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKFwiU2VuZGluZyB0byBTdW5vIEFQSTpcIiwgSlNPTi5zdHJpbmdpZnkoc3Vub1BheWxvYWQpKTtcbiAgICBjb25zb2xlLmxvZyhcIkVuZHBvaW50OlwiLCBzdW5vRW5kcG9pbnQpO1xuXG4gICAgY29uc3Qgc3Vub1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2goc3Vub0VuZHBvaW50LCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShzdW5vUGF5bG9hZCksXG4gICAgfSk7XG5cbiAgICBjb25zdCBzdW5vRGF0YSA9IGF3YWl0IHN1bm9SZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJTdW5vIEFQSSByZXNwb25zZTpcIiwgSlNPTi5zdHJpbmdpZnkoc3Vub0RhdGEpKTtcblxuICAgIGlmICghc3Vub1Jlc3BvbnNlLm9rIHx8IHN1bm9EYXRhLmNvZGUgIT09IDIwMCkge1xuICAgICAgY29uc3QgcmF3RXJyb3JNZXNzYWdlID0gc3Vub0RhdGEubXNnIHx8IFwiRmFpbGVkIHRvIHN0YXJ0IGdlbmVyYXRpb25cIjtcbiAgICAgIGNvbnN0IGVycm9yQ29kZSA9IHN1bm9EYXRhLmNvZGUgfHwgc3Vub1Jlc3BvbnNlLnN0YXR1cyB8fCA1MDA7XG4gICAgICBcbiAgICAgIC8vIEdldCBodW1hbi1yZWFkYWJsZSBSdXNzaWFuIGVycm9yIG1lc3NhZ2VcbiAgICAgIGNvbnN0IGVycm9ySW5mbyA9IGdldFN1bm9FcnJvck1lc3NhZ2UoZXJyb3JDb2RlLCByYXdFcnJvck1lc3NhZ2UpO1xuICAgICAgY29uc3QgcnVzc2lhbkVycm9yTWVzc2FnZSA9IGVycm9ySW5mby5zaG9ydDtcbiAgICAgIFxuICAgICAgY29uc29sZS5lcnJvcihgU3VubyBBUEkgZXJyb3IgKCR7ZXJyb3JDb2RlfSk6ICR7cmF3RXJyb3JNZXNzYWdlfSAtPiAke3J1c3NpYW5FcnJvck1lc3NhZ2V9YCk7XG4gICAgICBcbiAgICAgIC8vIFVwZGF0ZSB0cmFjayBzdGF0dXMgdG8gZmFpbGVkIHdpdGggUnVzc2lhbiBlcnJvciBtZXNzYWdlXG4gICAgICBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAudXBkYXRlKHsgXG4gICAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLFxuICAgICAgICAgIGVycm9yX21lc3NhZ2U6IHJ1c3NpYW5FcnJvck1lc3NhZ2VcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZClcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcblxuICAgICAgLy8gR2V0IGFsbCB0cmFja3Mgd2l0aCB0aGlzIGJhc2UgdGl0bGUgdG8gZmluZCBwYWlyZWQgdHJhY2tcbiAgICAgIGNvbnN0IHsgZGF0YTogYWxsVHJhY2tzIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAuc2VsZWN0KFwiaWRcIilcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKVxuICAgICAgICAuaW4oXCJzdGF0dXNcIiwgW1wicGVuZGluZ1wiLCBcInByb2Nlc3NpbmdcIl0pO1xuXG4gICAgICBjb25zdCB0cmFja0lkcyA9IGFsbFRyYWNrcz8ubWFwKHQgPT4gdC5pZCkgfHwgW3RyYWNrSWRdO1xuXG4gICAgICAvLyBSZWZ1bmQ6IHVwZGF0ZSBnZW5lcmF0aW9uX2xvZ3MgdG8gZmFpbGVkIGFuZCByZXR1cm4gYmFsYW5jZVxuICAgICAgY29uc3QgeyBkYXRhOiBsb2dzIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAuZnJvbShcImdlbmVyYXRpb25fbG9nc1wiKVxuICAgICAgICAuc2VsZWN0KFwiaWQsIGNvc3RfcnViXCIpXG4gICAgICAgIC5pbihcInRyYWNrX2lkXCIsIHRyYWNrSWRzKVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpXG4gICAgICAgIC5lcShcInN0YXR1c1wiLCBcInBlbmRpbmdcIik7XG5cbiAgICAgIGxldCB0b3RhbFJlZnVuZCA9IDA7XG4gICAgICBpZiAobG9ncyAmJiBsb2dzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgdG90YWxSZWZ1bmQgPSBsb2dzLnJlZHVjZSgoc3VtLCBsb2cpID0+IHN1bSArIChsb2cuY29zdF9ydWIgfHwgMCksIDApO1xuICAgICAgICBcbiAgICAgICAgLy8gTWFyayBsb2dzIGFzIGZhaWxlZFxuICAgICAgICBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAgIC5mcm9tKFwiZ2VuZXJhdGlvbl9sb2dzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJmYWlsZWRcIiB9KVxuICAgICAgICAgIC5pbihcImlkXCIsIGxvZ3MubWFwKGwgPT4gbC5pZCkpO1xuXG4gICAgICAgIC8vIFJlZnVuZCB0aGUgYmFsYW5jZVxuICAgICAgICBpZiAodG90YWxSZWZ1bmQgPiAwKSB7XG4gICAgICAgICAgY29uc3QgeyBkYXRhOiBwcm9maWxlIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgICAgLnNlbGVjdChcImJhbGFuY2VcIilcbiAgICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgICAgICAgIC5zaW5nbGUoKTtcblxuICAgICAgICAgIGlmIChwcm9maWxlKSB7XG4gICAgICAgICAgICBjb25zdCBuZXdCYWxhbmNlID0gKHByb2ZpbGUuYmFsYW5jZSB8fCAwKSArIHRvdGFsUmVmdW5kO1xuICAgICAgICAgICAgYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogbmV3QmFsYW5jZSB9KVxuICAgICAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBMb2cgcmVmdW5kIHRyYW5zYWN0aW9uXG4gICAgICAgICAgICBhd2FpdCBzdXBhYmFzZUNsaWVudC5mcm9tKFwiYmFsYW5jZV90cmFuc2FjdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgdXNlcl9pZDogdXNlci5pZCxcbiAgICAgICAgICAgICAgYW1vdW50OiB0b3RhbFJlZnVuZCxcbiAgICAgICAgICAgICAgYmFsYW5jZV9hZnRlcjogbmV3QmFsYW5jZSxcbiAgICAgICAgICAgICAgdHlwZTogXCJyZWZ1bmRcIixcbiAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGDQktC+0LfQstGA0LDRgiDQt9CwINC90LXRg9C00LDRh9C90YPRjiDQs9C10L3QtdGA0LDRhtC40Y5gLFxuICAgICAgICAgICAgICByZWZlcmVuY2VfaWQ6IHRyYWNrSWQsXG4gICAgICAgICAgICAgIHJlZmVyZW5jZV90eXBlOiBcInRyYWNrXCIsXG4gICAgICAgICAgICAgIG1ldGFkYXRhOiB7IGVycm9yOiBydXNzaWFuRXJyb3JNZXNzYWdlIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgY29uc29sZS5sb2coYFJlZnVuZGVkICR7dG90YWxSZWZ1bmR9IHRvIHVzZXIgJHt1c2VyLmlkfWApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBBbHNvIG1hcmsgb3RoZXIgcGVuZGluZyB0cmFja3MgYXMgZmFpbGVkXG4gICAgICBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAudXBkYXRlKHsgc3RhdHVzOiBcImZhaWxlZFwiLCBlcnJvcl9tZXNzYWdlOiBydXNzaWFuRXJyb3JNZXNzYWdlIH0pXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgICAgLmluKFwic3RhdHVzXCIsIFtcInBlbmRpbmdcIiwgXCJwcm9jZXNzaW5nXCJdKTtcblxuICAgICAgLy8gQ3JlYXRlIG5vdGlmaWNhdGlvbiBmb3IgcmVmdW5kIHdpdGggUnVzc2lhbiBlcnJvciBleHBsYW5hdGlvblxuICAgICAgaWYgKHRvdGFsUmVmdW5kID4gMCkge1xuICAgICAgICBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgLmZyb20oXCJub3RpZmljYXRpb25zXCIpXG4gICAgICAgICAgLmluc2VydCh7XG4gICAgICAgICAgICB1c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgICAgICAgdHlwZTogXCJyZWZ1bmRcIixcbiAgICAgICAgICAgIHRpdGxlOiBg0J7RiNC40LHQutCwOiAke3J1c3NpYW5FcnJvck1lc3NhZ2V9YCxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGAke2Vycm9ySW5mby5mdWxsfVxcblxcbtCS0LDQvCDQstC+0LfQstGA0LDRidC10L3QviAke3RvdGFsUmVmdW5kfSDigr1gLFxuICAgICAgICAgICAgdGFyZ2V0X3R5cGU6IFwidHJhY2tcIixcbiAgICAgICAgICAgIHRhcmdldF9pZDogdHJhY2tJZCxcbiAgICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBlcnJvcjogcnVzc2lhbkVycm9yTWVzc2FnZSxcbiAgICAgICAgICBkZXRhaWxzOiBlcnJvckluZm8uZnVsbCxcbiAgICAgICAgICByZWZ1bmRlZDogdG90YWxSZWZ1bmQgPiAwLFxuICAgICAgICAgIHJlZnVuZEFtb3VudDogdG90YWxSZWZ1bmRcbiAgICAgICAgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB0YXNrSWQgPSBzdW5vRGF0YS5kYXRhPy50YXNrSWQ7XG4gICAgY29uc29sZS5sb2coYEdlbmVyYXRpb24gc3RhcnRlZCB3aXRoIHRhc2sgSUQ6ICR7dGFza0lkfWApO1xuXG4gICAgLy8gQ1JJVElDQUw6IFN0b3JlIHRhc2tfaWQgaW4gZGVzY3JpcHRpb24gZm9yIE9OTFkgdGhlIGN1cnJlbnQgdHJhY2sgcGFpciAodjEgYW5kIHYyKVxuICAgIC8vIFRoaXMgaXMgZXNzZW50aWFsIGZvciB0aGUgY2FsbGJhY2sgdG8gbWF0Y2ggcmVzdWx0cyB0byB0aGUgY29ycmVjdCB0cmFja3NcbiAgICAvLyBETyBOT1QgdXBkYXRlIG90aGVyIHBlbmRpbmcgdHJhY2tzIC0gdGhleSBoYXZlIHRoZWlyIG93biB0YXNrX2lkIGZyb20gdGhlaXIgb3duIGdlbmVyYXRpb24hXG4gICAgaWYgKHRhc2tJZCkge1xuICAgICAgLy8gR2V0IHRoZSBjdXJyZW50IHRyYWNrJ3MgaW5mbyBpbmNsdWRpbmcgY3JlYXRlZF9hdCB0byBmaW5kIGl0cyBwYWlyXG4gICAgICBjb25zdCB7IGRhdGE6IGN1cnJlbnRUcmFjayB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnNlbGVjdChcImlkLCB0aXRsZSwgZGVzY3JpcHRpb24sIGNyZWF0ZWRfYXRcIilcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZClcbiAgICAgICAgLnNpbmdsZSgpO1xuICAgICAgXG4gICAgICBpZiAoY3VycmVudFRyYWNrKSB7XG4gICAgICAgIC8vIEZpbmQgdGhlIHBhaXJlZCB0cmFjazogc2FtZSBiYXNlIHRpdGxlLCBzYW1lIHVzZXIsIGNyZWF0ZWQgd2l0aGluIDUgc2Vjb25kc1xuICAgICAgICBjb25zdCBiYXNlVGl0bGUgPSAoY3VycmVudFRyYWNrLnRpdGxlIHx8IFwiXCIpLnJlcGxhY2UoL1xccypcXCh2XFxkK1xcKSQvLCBcIlwiKS50cmltKCk7XG4gICAgICAgIGNvbnN0IGNyZWF0ZWRBdCA9IG5ldyBEYXRlKGN1cnJlbnRUcmFjay5jcmVhdGVkX2F0KTtcbiAgICAgICAgY29uc3Qgd2luZG93U3RhcnQgPSBuZXcgRGF0ZShjcmVhdGVkQXQuZ2V0VGltZSgpIC0gNTAwMCkudG9JU09TdHJpbmcoKTtcbiAgICAgICAgY29uc3Qgd2luZG93RW5kID0gbmV3IERhdGUoY3JlYXRlZEF0LmdldFRpbWUoKSArIDUwMDApLnRvSVNPU3RyaW5nKCk7XG4gICAgICAgIFxuICAgICAgICBjb25zdCB7IGRhdGE6IHBhaXJlZFRyYWNrcyB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgIC5zZWxlY3QoXCJpZCwgdGl0bGUsIGRlc2NyaXB0aW9uLCBjcmVhdGVkX2F0XCIpXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKVxuICAgICAgICAgIC5ndGUoXCJjcmVhdGVkX2F0XCIsIHdpbmRvd1N0YXJ0KVxuICAgICAgICAgIC5sdGUoXCJjcmVhdGVkX2F0XCIsIHdpbmRvd0VuZCk7XG4gICAgICAgIFxuICAgICAgICBjb25zdCBmaWx0ZXJlZCA9IHBhaXJlZFRyYWNrcz8uZmlsdGVyKHQgPT4ge1xuICAgICAgICAgIGNvbnN0IHRCYXNlVGl0bGUgPSAodC50aXRsZSB8fCBcIlwiKS5yZXBsYWNlKC9cXHMqXFwodlxcZCtcXCkkLywgXCJcIikudHJpbSgpO1xuICAgICAgICAgIHJldHVybiB0QmFzZVRpdGxlID09PSBiYXNlVGl0bGU7XG4gICAgICAgIH0pIHx8IFtdO1xuICAgICAgICBcbiAgICAgICAgLy8gQ1JJVElDQUwgRklYOiBlbXB0eSBhcnJheSBpcyB0cnV0aHksIHNvIGNoZWNrIC5sZW5ndGggZXhwbGljaXRseVxuICAgICAgICBjb25zdCB0cmFja3NUb1VwZGF0ZSA9IGZpbHRlcmVkLmxlbmd0aCA+IDAgPyBmaWx0ZXJlZCA6IFtjdXJyZW50VHJhY2tdO1xuICAgICAgICBcbiAgICAgICAgY29uc29sZS5sb2coYEZvdW5kICR7dHJhY2tzVG9VcGRhdGUubGVuZ3RofSB0cmFja3MgaW4gcGFpciB0byB1cGRhdGUgd2l0aCB0YXNrX2lkIChmaWx0ZXJlZDogJHtmaWx0ZXJlZC5sZW5ndGh9LCBwYWlyZWQ6ICR7cGFpcmVkVHJhY2tzPy5sZW5ndGggfHwgMH0pYCk7XG4gICAgICAgIFxuICAgICAgICBmb3IgKGNvbnN0IHRyYWNrIG9mIHRyYWNrc1RvVXBkYXRlKSB7XG4gICAgICAgICAgLy8gSU1QT1JUQU5UOiBPbmx5IHVwZGF0ZSBpZiB0aGlzIHRyYWNrIGRvZXNuJ3QgYWxyZWFkeSBoYXZlIGEgdGFza19pZFxuICAgICAgICAgIC8vIFRoaXMgcHJldmVudHMgb3ZlcndyaXRpbmcgdGFza19pZCBmcm9tIGEgZGlmZmVyZW50IGdlbmVyYXRpb25cbiAgICAgICAgICBpZiAodHJhY2suZGVzY3JpcHRpb24/LmluY2x1ZGVzKFwiW3Rhc2tfaWQ6XCIpKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgVHJhY2sgJHt0cmFjay5pZH0gKCR7dHJhY2sudGl0bGV9KSBhbHJlYWR5IGhhcyB0YXNrX2lkLCBza2lwcGluZyB0byBwcmV2ZW50IG92ZXJ3cml0ZWApO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIFxuICAgICAgICAgIC8vIEFwcGVuZCB0YXNrX2lkIHRvIGRlc2NyaXB0aW9uIChwcmVzZXJ2ZSBleGlzdGluZyBjb250ZW50KVxuICAgICAgICAgIGNvbnN0IGV4aXN0aW5nRGVzYyA9IHRyYWNrLmRlc2NyaXB0aW9uIHx8IFwiXCI7XG4gICAgICAgICAgY29uc3QgbmV3RGVzYyA9IGV4aXN0aW5nRGVzYyBcbiAgICAgICAgICAgID8gYCR7ZXhpc3RpbmdEZXNjfVxcblxcblt0YXNrX2lkOiAke3Rhc2tJZH1dYFxuICAgICAgICAgICAgOiBgW3Rhc2tfaWQ6ICR7dGFza0lkfV1gO1xuICAgICAgICAgIFxuICAgICAgICAgIGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgICAgLnVwZGF0ZSh7IGRlc2NyaXB0aW9uOiBuZXdEZXNjIH0pXG4gICAgICAgICAgICAuZXEoXCJpZFwiLCB0cmFjay5pZCk7XG4gICAgICAgICAgXG4gICAgICAgICAgY29uc29sZS5sb2coYFN0b3JlZCB0YXNrX2lkICR7dGFza0lkfSBpbiB0cmFjayAke3RyYWNrLmlkfSAoJHt0cmFjay50aXRsZX0pYCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZhbGxiYWNrOiBhdCBsZWFzdCB1cGRhdGUgdGhlIGN1cnJlbnQgdHJhY2tcbiAgICAgICAgY29uc3QgbmV3RGVzYyA9IGBbdGFza19pZDogJHt0YXNrSWR9XWA7XG4gICAgICAgIFxuICAgICAgICBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IGRlc2NyaXB0aW9uOiBuZXdEZXNjIH0pXG4gICAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZCk7XG4gICAgICAgIFxuICAgICAgICBjb25zb2xlLmxvZyhgU3RvcmVkIHRhc2tfaWQgJHt0YXNrSWR9IGluIHRyYWNrICR7dHJhY2tJZH0gKGZhbGxiYWNrKWApO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgdGFza0lkLFxuICAgICAgICBtZXNzYWdlOiBcIkdlbmVyYXRpb24gc3RhcnRlZCBzdWNjZXNzZnVsbHlcIiBcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIHN1bm8tZ2VuZXJhdGU6XCIsIGVycm9yKTtcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCf0YDQvtC40LfQvtGI0LvQsCDQvdC10L/RgNC10LTQstC40LTQtdC90L3QsNGPINC+0YjQuNCx0LrQsC4g0J/QvtC/0YDQvtCx0YPQudGC0LUg0L/QvtC30LbQtS5cIiB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pOyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBQ25GLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDbEMsTUFBTSxnQkFBZ0I7QUFFdEIsK0RBQStEO0FBQy9ELGlDQUFpQztBQUNqQyw2RUFBNkU7QUFDN0UsK0RBQStEO0FBQy9ELHlFQUF5RTtBQUN6RSxTQUFTLG9CQUFvQixJQUFZLEVBQUUsZUFBd0I7RUFDakUsNkVBQTZFO0VBQzdFLElBQUksaUJBQWlCO0lBQ25CLE1BQU0sV0FBVyxnQkFBZ0IsV0FBVztJQUU1QyxJQUFJLFNBQVMsUUFBUSxDQUFDLDRCQUNsQixTQUFTLFFBQVEsQ0FBQywyQkFDbEIsU0FBUyxRQUFRLENBQUMsZ0JBQ2xCLFNBQVMsUUFBUSxDQUFDLHNCQUFzQjtNQUMxQyxPQUFPO1FBQ0wsT0FBTztRQUNQLE1BQU07TUFDUjtJQUNGO0lBRUEsSUFBSSxTQUFTLFFBQVEsQ0FBQyxpQkFDbEIsU0FBUyxRQUFRLENBQUMsZ0JBQ2xCLFNBQVMsUUFBUSxDQUFDLG9CQUNsQixTQUFTLFFBQVEsQ0FBQyxlQUFlO01BQ25DLE9BQU87UUFDTCxPQUFPO1FBQ1AsTUFBTTtNQUNSO0lBQ0Y7SUFFQSxJQUFJLFNBQVMsUUFBUSxDQUFDLGVBQWUsU0FBUyxRQUFRLENBQUMsZ0JBQWdCLFNBQVMsUUFBUSxDQUFDLFlBQVk7TUFDbkcsT0FBTztRQUNMLE9BQU87UUFDUCxNQUFNO01BQ1I7SUFDRjtJQUVBLElBQUksU0FBUyxRQUFRLENBQUMsYUFBYSxTQUFTLFFBQVEsQ0FBQyxjQUFjLFNBQVMsUUFBUSxDQUFDLGlCQUFpQjtNQUNwRyxPQUFPO1FBQ0wsT0FBTztRQUNQLE1BQU07TUFDUjtJQUNGO0VBQ0Y7RUFFQSxNQUFNLGdCQUFpRTtJQUNyRSxLQUFLO01BQUUsT0FBTztNQUE4QixNQUFNO0lBQWlEO0lBQ25HLEtBQUs7TUFBRSxPQUFPO01BQXNCLE1BQU07SUFBa0U7SUFDNUcsS0FBSztNQUFFLE9BQU87TUFBd0IsTUFBTTtJQUFvRTtJQUNoSCxLQUFLO01BQUUsT0FBTztNQUFvQixNQUFNO0lBQXNEO0lBQzlGLEtBQUs7TUFBRSxPQUFPO01BQThCLE1BQU07SUFBcUQ7SUFDdkcsS0FBSztNQUFFLE9BQU87TUFBMkIsTUFBTTtJQUF5RjtJQUN4SSxLQUFLO01BQUUsT0FBTztNQUF5QixNQUFNO0lBQWtFO0lBQy9HLEtBQUs7TUFBRSxPQUFPO01BQTBCLE1BQU07SUFBNEQ7SUFDMUcsS0FBSztNQUFFLE9BQU87TUFBdUIsTUFBTTtJQUF1RDtJQUNsRyxLQUFLO01BQUUsT0FBTztNQUFxQixNQUFNO0lBQThDO0VBQ3pGO0VBRUEsSUFBSSxhQUFhLENBQUMsS0FBSyxFQUFFO0lBQ3ZCLE9BQU8sYUFBYSxDQUFDLEtBQUs7RUFDNUI7RUFFQSxPQUFPO0lBQ0wsT0FBTyxDQUFDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLE1BQU0sbUJBQW1CLENBQUMscUNBQXFDLEVBQUUsS0FBSyxDQUFDO0VBQ3pFO0FBQ0Y7QUFFQSxpRkFBaUY7QUFDakYsTUFBTSxtQkFBMkM7RUFDL0MsU0FBUztFQUNULGNBQWM7RUFDZCxnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLGlCQUFpQjtFQUNqQixpQkFBaUI7RUFDakIsWUFBWTtFQUNaLGFBQWE7RUFDYixlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxPQUFPO0VBQ1AsZ0JBQWdCO0VBQ2hCLFlBQVk7RUFDWixPQUFPO0VBQ1AsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLGNBQWM7RUFDZCxTQUFTO0VBQ1QsV0FBVztFQUNYLGlCQUFpQjtFQUNqQixhQUFhO0VBQ2IsV0FBVztFQUNYLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIscUJBQXFCO0VBQ3JCLFlBQVk7RUFDWixlQUFlO0FBQ2pCO0FBRUEsZ0RBQWdEO0FBQ2hELFNBQVMscUJBQXFCLFVBQWtCO0VBQzlDLElBQUksZ0JBQWdCLENBQUMsV0FBVyxFQUFFO0lBQ2hDLE9BQU8sZ0JBQWdCLENBQUMsV0FBVztFQUNyQztFQUVBLE1BQU0sWUFBWSxXQUFXLFdBQVc7RUFDeEMsS0FBSyxNQUFNLENBQUMsUUFBUSxNQUFNLElBQUksT0FBTyxPQUFPLENBQUMsa0JBQW1CO0lBQzlELElBQUksT0FBTyxXQUFXLE9BQU8sV0FBVztNQUN0QyxPQUFPO0lBQ1Q7RUFDRjtFQUVBLE9BQU87QUFDVDtBQUVBLDRDQUE0QztBQUM1QyxTQUFTLGtCQUFrQixLQUFhO0VBQ3RDLElBQUksQ0FBQyxPQUFPLE9BQU87RUFFbkIsSUFBSSxlQUFlO0VBRW5CLEtBQUssTUFBTSxjQUFjLE9BQU8sSUFBSSxDQUFDLGtCQUFtQjtJQUN0RCxNQUFNLFFBQVEsSUFBSSxPQUFPLENBQUMsRUFBRSxXQUFXLFNBQVMsQ0FBQyxFQUFFO0lBQ25ELElBQUksTUFBTSxJQUFJLENBQUMsZUFBZTtNQUM1QixlQUFlLGFBQWEsT0FBTyxDQUFDLE9BQU8scUJBQXFCO0lBQ2xFO0lBRUEsTUFBTSxrQkFBa0IsSUFBSSxPQUFPLENBQUMsR0FBRyxFQUFFLFdBQVcsR0FBRyxDQUFDLEVBQUU7SUFDMUQsSUFBSSxnQkFBZ0IsSUFBSSxDQUFDLGVBQWU7TUFDdEMsZUFBZSxhQUFhLE9BQU8sQ0FBQyxpQkFBaUIscUJBQXFCO0lBQzVFO0VBQ0Y7RUFFQSxlQUFlLGFBQWEsT0FBTyxDQUFDLFVBQVUsS0FBSyxPQUFPLENBQUMsUUFBUSxLQUFLLElBQUk7RUFFNUUsT0FBTztBQUNUO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEwQixJQUNsRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGlCQUFpQixhQUNyQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFDckM7TUFBRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQUU7SUFHdkQsc0RBQXNEO0lBQ3RELE1BQU0sZ0JBQWdCLGFBQ3BCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFDaEMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdDQUFnQztJQUcvQyxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxPQUFPO0lBQzlFLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWUsSUFDdkM7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsOERBQThEO0lBQzlELE1BQU0sRUFBRSxNQUFNLFNBQVMsRUFBRSxHQUFHLE1BQU0sY0FBYyxHQUFHLENBQUMsbUJBQW1CO01BQUUsV0FBVyxLQUFLLEVBQUU7SUFBQztJQUM1RixJQUFJLFdBQVc7TUFDYixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBa0QsSUFDMUU7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLEdBQUcsTUFBTSxJQUFJLElBQUk7SUFFakcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRO01BQ3ZCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEyQyxJQUNuRTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDhCQUE4QixFQUFFLFFBQVEsU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7SUFDekUsUUFBUSxHQUFHLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLENBQUM7SUFDeEMsUUFBUSxHQUFHLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxNQUFNLENBQUM7SUFDdEMsUUFBUSxHQUFHLENBQUMsQ0FBQyxjQUFjLEVBQUUsYUFBYSxDQUFDO0lBQzNDLFFBQVEsR0FBRyxDQUFDLENBQUMscUJBQXFCLEVBQUUscUJBQXFCLE9BQU8sQ0FBQztJQUVqRSx5Q0FBeUM7SUFDekMsTUFBTSxlQUFlLGtCQUFrQixTQUFTO0lBQ2hELFFBQVEsR0FBRyxDQUFDLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQztJQUU1QyxvQ0FBb0M7SUFDcEMsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxlQUNsQyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7TUFBRSxRQUFRO01BQWMsZUFBZTtJQUFLLEdBQ25ELEVBQUUsQ0FBQyxNQUFNLFNBQ1QsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFO0lBRXhCLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLGtDQUFrQztJQUNsRDtJQUVBLHdEQUF3RDtJQUN4RCxNQUFNLFlBQVksQ0FBQyxDQUFDLFVBQVUsT0FBTyxJQUFJLEdBQUcsTUFBTSxHQUFHO0lBQ3JELE1BQU0sV0FBVyxDQUFDLENBQUMsZ0JBQWdCLGFBQWEsSUFBSSxHQUFHLE1BQU0sR0FBRztJQUNoRSxNQUFNLFlBQVksQ0FBQyxDQUFDLFVBQVUsT0FBTyxJQUFJLEdBQUcsTUFBTSxHQUFHO0lBQ3JELE1BQU0sZ0JBQWdCLGFBQWE7SUFFbkMseUNBQXlDO0lBQ3pDLE1BQU0sZ0JBQWdCLGtCQUFrQixVQUFVO0lBQ2xELFFBQVEsR0FBRyxDQUFDLENBQUMsOEJBQThCLEVBQUUsY0FBYyxDQUFDO0lBRTVELDhDQUE4QztJQUM5QywyRkFBMkY7SUFDM0YsTUFBTSxpQkFBaUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ3BDLE1BQU0sc0JBQXNCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN6QyxNQUFNLGtCQUFrQix1QkFBdUIsQ0FBQyxFQUFFLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsMkJBQTJCLENBQUM7SUFDM0csTUFBTSxjQUFjLGlCQUNoQixDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsZ0JBQWdCLFFBQVEsQ0FBQyxPQUFPLE1BQU0sSUFBSSxPQUFPLEVBQUUsbUJBQW1CLGdCQUFnQixDQUFDLEdBQzVHO0lBQ0osUUFBUSxHQUFHLENBQUMsQ0FBQyxjQUFjLEVBQUUsWUFBWSxDQUFDO0lBRTFDLE1BQU0sY0FBbUM7TUFDdkMsT0FBTztNQUNQLFlBQVk7TUFDWixjQUFjLGdCQUFnQjtNQUM5QjtJQUNGO0lBRUEsSUFBSSxlQUFlO01BQ2pCLG9EQUFvRDtNQUNwRCxZQUFZLE1BQU0sR0FBRyxZQUFZLFNBQVM7TUFFMUMsMEZBQTBGO01BQzFGLHVEQUF1RDtNQUN2RCwrQ0FBK0M7TUFDL0MsSUFBSSxhQUFhLGdCQUFnQjtNQUVqQywrQ0FBK0M7TUFDL0MsSUFBSSxXQUFXLE1BQU0sR0FBRyxLQUFLO1FBQzNCLHNFQUFzRTtRQUN0RSxNQUFNLFFBQVEsV0FBVyxLQUFLLENBQUM7UUFDL0IsSUFBSSxZQUFZO1FBQ2hCLEtBQUssTUFBTSxRQUFRLE1BQU87VUFDeEIsSUFBSSxDQUFDLFlBQVksT0FBTyxJQUFJLEVBQUUsTUFBTSxJQUFJLEtBQUs7WUFDM0MsWUFBWSxZQUFZLFlBQVksT0FBTyxPQUFPO1VBQ3BELE9BQU87WUFDTDtVQUNGO1FBQ0Y7UUFDQSxhQUFhLGFBQWEsV0FBVyxLQUFLLENBQUMsR0FBRztRQUM5QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLGFBQWEsTUFBTSxDQUFDLElBQUksRUFBRSxXQUFXLE1BQU0sQ0FBQyxNQUFNLENBQUM7TUFDekY7TUFFQSxZQUFZLEtBQUssR0FBRztNQUNwQixZQUFZLEtBQUssR0FBRyxTQUFTO01BRTdCLFFBQVEsR0FBRyxDQUFDLENBQUMsc0JBQXNCLEVBQUUsWUFBWSxLQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxZQUFZLEtBQUssQ0FBQyxDQUFDO0lBQzlGLE9BQU87TUFDTCxZQUFZLE1BQU0sR0FBRyxPQUFPLEtBQUssQ0FBQyxHQUFHO0lBQ3ZDO0lBRUEsa0NBQWtDO0lBQ2xDLElBQUksZUFBZSxDQUFDLEVBQUUsY0FBYyxnQkFBZ0IsQ0FBQztJQUVyRCxvRUFBb0U7SUFDcEUsSUFBSSxtQkFBbUI7TUFDckIsZUFBZSxDQUFDLEVBQUUsY0FBYyw2QkFBNkIsQ0FBQztNQUM5RCxZQUFZLFNBQVMsR0FBRztNQUN4QixRQUFRLEdBQUcsQ0FBQztJQUNkO0lBRUEsUUFBUSxHQUFHLENBQUMsd0JBQXdCLEtBQUssU0FBUyxDQUFDO0lBQ25ELFFBQVEsR0FBRyxDQUFDLGFBQWE7SUFFekIsTUFBTSxlQUFlLE1BQU0sTUFBTSxjQUFjO01BQzdDLFFBQVE7TUFDUixTQUFTO1FBQ1AsZ0JBQWdCO1FBQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO0lBQ3ZCO0lBRUEsTUFBTSxXQUFXLE1BQU0sYUFBYSxJQUFJO0lBQ3hDLFFBQVEsR0FBRyxDQUFDLHNCQUFzQixLQUFLLFNBQVMsQ0FBQztJQUVqRCxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksU0FBUyxJQUFJLEtBQUssS0FBSztNQUM3QyxNQUFNLGtCQUFrQixTQUFTLEdBQUcsSUFBSTtNQUN4QyxNQUFNLFlBQVksU0FBUyxJQUFJLElBQUksYUFBYSxNQUFNLElBQUk7TUFFMUQsMkNBQTJDO01BQzNDLE1BQU0sWUFBWSxvQkFBb0IsV0FBVztNQUNqRCxNQUFNLHNCQUFzQixVQUFVLEtBQUs7TUFFM0MsUUFBUSxLQUFLLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxVQUFVLEdBQUcsRUFBRSxnQkFBZ0IsSUFBSSxFQUFFLG9CQUFvQixDQUFDO01BRTNGLDJEQUEyRDtNQUMzRCxNQUFNLGVBQ0gsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sUUFBUTtRQUNSLGVBQWU7TUFDakIsR0FDQyxFQUFFLENBQUMsTUFBTSxTQUNULEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRTtNQUV4QiwyREFBMkQ7TUFDM0QsTUFBTSxFQUFFLE1BQU0sU0FBUyxFQUFFLEdBQUcsTUFBTSxlQUMvQixJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsTUFDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsRUFBRSxDQUFDLFVBQVU7UUFBQztRQUFXO09BQWE7TUFFekMsTUFBTSxXQUFXLFdBQVcsSUFBSSxDQUFBLElBQUssRUFBRSxFQUFFLEtBQUs7UUFBQztPQUFRO01BRXZELDhEQUE4RDtNQUM5RCxNQUFNLEVBQUUsTUFBTSxJQUFJLEVBQUUsR0FBRyxNQUFNLGVBQzFCLElBQUksQ0FBQyxtQkFDTCxNQUFNLENBQUMsZ0JBQ1AsRUFBRSxDQUFDLFlBQVksVUFDZixFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsRUFBRSxDQUFDLFVBQVU7TUFFaEIsSUFBSSxjQUFjO01BQ2xCLElBQUksUUFBUSxLQUFLLE1BQU0sR0FBRyxHQUFHO1FBQzNCLGNBQWMsS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLE1BQVEsTUFBTSxDQUFDLElBQUksUUFBUSxJQUFJLENBQUMsR0FBRztRQUVuRSxzQkFBc0I7UUFDdEIsTUFBTSxlQUNILElBQUksQ0FBQyxtQkFDTCxNQUFNLENBQUM7VUFBRSxRQUFRO1FBQVMsR0FDMUIsRUFBRSxDQUFDLE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQSxJQUFLLEVBQUUsRUFBRTtRQUU5QixxQkFBcUI7UUFDckIsSUFBSSxjQUFjLEdBQUc7VUFDbkIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxlQUM3QixJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtVQUVULElBQUksU0FBUztZQUNYLE1BQU0sYUFBYSxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSTtZQUM1QyxNQUFNLGVBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO2NBQUUsU0FBUztZQUFXLEdBQzdCLEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRTtZQUV4Qix5QkFBeUI7WUFDekIsTUFBTSxlQUFlLElBQUksQ0FBQyx3QkFBd0IsTUFBTSxDQUFDO2NBQ3ZELFNBQVMsS0FBSyxFQUFFO2NBQ2hCLFFBQVE7Y0FDUixlQUFlO2NBQ2YsTUFBTTtjQUNOLGFBQWEsQ0FBQyw4QkFBOEIsQ0FBQztjQUM3QyxjQUFjO2NBQ2QsZ0JBQWdCO2NBQ2hCLFVBQVU7Z0JBQUUsT0FBTztjQUFvQjtZQUN6QztZQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsU0FBUyxFQUFFLFlBQVksU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDMUQ7UUFDRjtNQUNGO01BRUEsMkNBQTJDO01BQzNDLE1BQU0sZUFDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7UUFBRSxRQUFRO1FBQVUsZUFBZTtNQUFvQixHQUM5RCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsRUFBRSxDQUFDLFVBQVU7UUFBQztRQUFXO09BQWE7TUFFekMsZ0VBQWdFO01BQ2hFLElBQUksY0FBYyxHQUFHO1FBQ25CLE1BQU0sY0FDSCxJQUFJLENBQUMsaUJBQ0wsTUFBTSxDQUFDO1VBQ04sU0FBUyxLQUFLLEVBQUU7VUFDaEIsTUFBTTtVQUNOLE9BQU8sQ0FBQyxRQUFRLEVBQUUsb0JBQW9CLENBQUM7VUFDdkMsU0FBUyxDQUFDLEVBQUUsVUFBVSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsWUFBWSxFQUFFLENBQUM7VUFDL0QsYUFBYTtVQUNiLFdBQVc7UUFDYjtNQUNKO01BRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixPQUFPO1FBQ1AsU0FBUyxVQUFVLElBQUk7UUFDdkIsVUFBVSxjQUFjO1FBQ3hCLGNBQWM7TUFDaEIsSUFDQTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFNBQVMsU0FBUyxJQUFJLEVBQUU7SUFDOUIsUUFBUSxHQUFHLENBQUMsQ0FBQyxpQ0FBaUMsRUFBRSxPQUFPLENBQUM7SUFFeEQscUZBQXFGO0lBQ3JGLDRFQUE0RTtJQUM1RSw4RkFBOEY7SUFDOUYsSUFBSSxRQUFRO01BQ1YscUVBQXFFO01BQ3JFLE1BQU0sRUFBRSxNQUFNLFlBQVksRUFBRSxHQUFHLE1BQU0sZUFDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLHNDQUNQLEVBQUUsQ0FBQyxNQUFNLFNBQ1QsTUFBTTtNQUVULElBQUksY0FBYztRQUNoQiw4RUFBOEU7UUFDOUUsTUFBTSxZQUFZLENBQUMsYUFBYSxLQUFLLElBQUksRUFBRSxFQUFFLE9BQU8sQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJO1FBQzdFLE1BQU0sWUFBWSxJQUFJLEtBQUssYUFBYSxVQUFVO1FBQ2xELE1BQU0sY0FBYyxJQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssTUFBTSxXQUFXO1FBQ3BFLE1BQU0sWUFBWSxJQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssTUFBTSxXQUFXO1FBRWxFLE1BQU0sRUFBRSxNQUFNLFlBQVksRUFBRSxHQUFHLE1BQU0sZUFDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLHNDQUNQLEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRSxFQUNyQixHQUFHLENBQUMsY0FBYyxhQUNsQixHQUFHLENBQUMsY0FBYztRQUVyQixNQUFNLFdBQVcsY0FBYyxPQUFPLENBQUE7VUFDcEMsTUFBTSxhQUFhLENBQUMsRUFBRSxLQUFLLElBQUksRUFBRSxFQUFFLE9BQU8sQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJO1VBQ25FLE9BQU8sZUFBZTtRQUN4QixNQUFNLEVBQUU7UUFFUixtRUFBbUU7UUFDbkUsTUFBTSxpQkFBaUIsU0FBUyxNQUFNLEdBQUcsSUFBSSxXQUFXO1VBQUM7U0FBYTtRQUV0RSxRQUFRLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxlQUFlLE1BQU0sQ0FBQyxrREFBa0QsRUFBRSxTQUFTLE1BQU0sQ0FBQyxVQUFVLEVBQUUsY0FBYyxVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBRXZKLEtBQUssTUFBTSxTQUFTLGVBQWdCO1VBQ2xDLHNFQUFzRTtVQUN0RSxnRUFBZ0U7VUFDaEUsSUFBSSxNQUFNLFdBQVcsRUFBRSxTQUFTLGNBQWM7WUFDNUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sS0FBSyxDQUFDLG9EQUFvRCxDQUFDO1lBQ25HO1VBQ0Y7VUFFQSw0REFBNEQ7VUFDNUQsTUFBTSxlQUFlLE1BQU0sV0FBVyxJQUFJO1VBQzFDLE1BQU0sVUFBVSxlQUNaLENBQUMsRUFBRSxhQUFhLGNBQWMsRUFBRSxPQUFPLENBQUMsQ0FBQyxHQUN6QyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQztVQUUxQixNQUFNLGVBQ0gsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1lBQUUsYUFBYTtVQUFRLEdBQzlCLEVBQUUsQ0FBQyxNQUFNLE1BQU0sRUFBRTtVQUVwQixRQUFRLEdBQUcsQ0FBQyxDQUFDLGVBQWUsRUFBRSxPQUFPLFVBQVUsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQzlFO01BQ0YsT0FBTztRQUNMLDhDQUE4QztRQUM5QyxNQUFNLFVBQVUsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxlQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztVQUFFLGFBQWE7UUFBUSxHQUM5QixFQUFFLENBQUMsTUFBTTtRQUVaLFFBQVEsR0FBRyxDQUFDLENBQUMsZUFBZSxFQUFFLE9BQU8sVUFBVSxFQUFFLFFBQVEsV0FBVyxDQUFDO01BQ3ZFO0lBQ0Y7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVDtNQUNBLFNBQVM7SUFDWCxJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsMkJBQTJCO0lBQ3pDLE1BQU0sZUFBZSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUM5RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBcUQsSUFDN0U7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
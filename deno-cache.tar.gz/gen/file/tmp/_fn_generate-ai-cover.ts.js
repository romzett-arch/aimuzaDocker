const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Style presets for AI cover generation
const stylePrompts = {
  abstract: "Abstract modern art style with flowing shapes, vibrant color gradients, dynamic composition",
  neon: "Neon cyberpunk aesthetic with glowing lights, dark background, electric blue and pink colors, futuristic city vibes",
  minimal: "Minimalist design with clean lines, geometric shapes, limited color palette, elegant simplicity",
  retro: "Retro 80s synthwave style with sunset gradients, palm trees silhouettes, grid patterns, VHS aesthetic",
  nature: "Organic natural elements, forest or ocean imagery, ethereal atmosphere, dreamy soft lighting",
  space: "Cosmic space theme with galaxies, nebulas, stars, planets, deep purple and blue cosmic colors",
  grunge: "Dark grunge aesthetic with textures, distressed elements, moody atmosphere, industrial feel",
  pop_art: "Bold pop art style with bright colors, comic book dots, strong outlines, Andy Warhol inspired",
  watercolor: "Soft watercolor painting style with flowing colors, artistic brushstrokes, delicate textures",
  futuristic: "Futuristic high-tech design with holographic elements, chrome surfaces, AI-generated patterns"
};
const moodPrompts = {
  energetic: "high energy, dynamic movement, explosive, powerful",
  calm: "peaceful, serene, tranquil, meditative",
  dark: "mysterious, shadowy, intense, dramatic",
  bright: "cheerful, uplifting, sunny, optimistic",
  melancholic: "emotional, nostalgic, bittersweet, thoughtful",
  aggressive: "fierce, bold, raw, powerful impact"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Verify user
    const supabaseClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY"), {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { track_id, track_title, genre, style = "abstract", mood = "energetic", custom_prompt, color_scheme, include_text = false } = await req.json();
    if (!track_id) {
      return new Response(JSON.stringify({
        error: "track_id is required"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Generating AI cover for track: ${track_id}, style: ${style}, mood: ${mood}`);
    // Build the comprehensive prompt
    const styleDescription = stylePrompts[style] || stylePrompts.abstract;
    const moodDescription = moodPrompts[mood] || moodPrompts.energetic;
    let prompt = `Create a stunning, professional album cover art (1024x1024 pixels) for a music track.

Track Information:
- Title: "${track_title || 'Untitled'}"
- Genre: ${genre || "electronic music"}

Visual Style: ${styleDescription}
Mood & Atmosphere: ${moodDescription}
${color_scheme ? `Color Palette: ${color_scheme}` : ""}

Requirements:
- Ultra high resolution, professional quality
- Modern, visually striking design suitable for music streaming platforms
- Square 1:1 aspect ratio album artwork
- No text or typography on the image
- Rich details and artistic composition
- Should evoke emotions matching the music style

${custom_prompt ? `Additional creative direction: ${custom_prompt}` : ""}

Create artwork that would stand out on Spotify, Apple Music, and other streaming platforms.`;
    console.log("Prompt:", prompt);
    // Call Lovable AI with image generation
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "google/gemini-3-pro-image-preview",
        messages: [
          {
            role: "user",
            content: prompt
          }
        ],
        modalities: [
          "image",
          "text"
        ]
      })
    });
    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      if (response.status === 429) {
        return new Response(JSON.stringify({
          error: "Rate limit exceeded. Please try again later."
        }), {
          status: 429,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({
          error: "Payment required. Please add funds to your workspace."
        }), {
          status: 402,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      throw new Error(`AI gateway error: ${response.status}`);
    }
    const data = await response.json();
    const imageUrl = data.choices?.[0]?.message?.images?.[0]?.image_url?.url;
    if (!imageUrl) {
      console.error("No image in response:", JSON.stringify(data));
      throw new Error("No image generated by AI");
    }
    console.log("AI cover generated successfully");
    // Upload the base64 image to Supabase Storage
    const base64Data = imageUrl.replace(/^data:image\/\w+;base64,/, "");
    const imageBuffer = Uint8Array.from(atob(base64Data), (c)=>c.charCodeAt(0));
    const fileName = `ai-covers/${track_id}-${Date.now()}.png`;
    const { data: uploadData, error: uploadError } = await supabase.storage.from("tracks").upload(fileName, imageBuffer, {
      contentType: "image/png",
      upsert: true
    });
    if (uploadError) {
      console.error("Storage upload error:", uploadError);
      throw new Error("Failed to upload AI cover to storage");
    }
    const { data: publicUrl } = supabase.storage.from("tracks").getPublicUrl(fileName);
    // Store in gallery_items for user's gallery
    await supabase.from("gallery_items").insert({
      user_id: user.id,
      track_id: track_id,
      type: "ai_cover",
      url: publicUrl.publicUrl,
      title: `AI Cover - ${track_title || 'Untitled'}`,
      prompt: prompt,
      style: style,
      is_public: false
    });
    console.log("Cover saved to gallery:", publicUrl.publicUrl);
    return new Response(JSON.stringify({
      success: true,
      cover_url: publicUrl.publicUrl,
      style: style,
      mood: mood,
      message: "AI cover generated successfully"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("generate-ai-cover error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9nZW5lcmF0ZS1haS1jb3Zlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuLy8gU3R5bGUgcHJlc2V0cyBmb3IgQUkgY292ZXIgZ2VuZXJhdGlvblxuY29uc3Qgc3R5bGVQcm9tcHRzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICBhYnN0cmFjdDogXCJBYnN0cmFjdCBtb2Rlcm4gYXJ0IHN0eWxlIHdpdGggZmxvd2luZyBzaGFwZXMsIHZpYnJhbnQgY29sb3IgZ3JhZGllbnRzLCBkeW5hbWljIGNvbXBvc2l0aW9uXCIsXG4gIG5lb246IFwiTmVvbiBjeWJlcnB1bmsgYWVzdGhldGljIHdpdGggZ2xvd2luZyBsaWdodHMsIGRhcmsgYmFja2dyb3VuZCwgZWxlY3RyaWMgYmx1ZSBhbmQgcGluayBjb2xvcnMsIGZ1dHVyaXN0aWMgY2l0eSB2aWJlc1wiLFxuICBtaW5pbWFsOiBcIk1pbmltYWxpc3QgZGVzaWduIHdpdGggY2xlYW4gbGluZXMsIGdlb21ldHJpYyBzaGFwZXMsIGxpbWl0ZWQgY29sb3IgcGFsZXR0ZSwgZWxlZ2FudCBzaW1wbGljaXR5XCIsXG4gIHJldHJvOiBcIlJldHJvIDgwcyBzeW50aHdhdmUgc3R5bGUgd2l0aCBzdW5zZXQgZ3JhZGllbnRzLCBwYWxtIHRyZWVzIHNpbGhvdWV0dGVzLCBncmlkIHBhdHRlcm5zLCBWSFMgYWVzdGhldGljXCIsXG4gIG5hdHVyZTogXCJPcmdhbmljIG5hdHVyYWwgZWxlbWVudHMsIGZvcmVzdCBvciBvY2VhbiBpbWFnZXJ5LCBldGhlcmVhbCBhdG1vc3BoZXJlLCBkcmVhbXkgc29mdCBsaWdodGluZ1wiLFxuICBzcGFjZTogXCJDb3NtaWMgc3BhY2UgdGhlbWUgd2l0aCBnYWxheGllcywgbmVidWxhcywgc3RhcnMsIHBsYW5ldHMsIGRlZXAgcHVycGxlIGFuZCBibHVlIGNvc21pYyBjb2xvcnNcIixcbiAgZ3J1bmdlOiBcIkRhcmsgZ3J1bmdlIGFlc3RoZXRpYyB3aXRoIHRleHR1cmVzLCBkaXN0cmVzc2VkIGVsZW1lbnRzLCBtb29keSBhdG1vc3BoZXJlLCBpbmR1c3RyaWFsIGZlZWxcIixcbiAgcG9wX2FydDogXCJCb2xkIHBvcCBhcnQgc3R5bGUgd2l0aCBicmlnaHQgY29sb3JzLCBjb21pYyBib29rIGRvdHMsIHN0cm9uZyBvdXRsaW5lcywgQW5keSBXYXJob2wgaW5zcGlyZWRcIixcbiAgd2F0ZXJjb2xvcjogXCJTb2Z0IHdhdGVyY29sb3IgcGFpbnRpbmcgc3R5bGUgd2l0aCBmbG93aW5nIGNvbG9ycywgYXJ0aXN0aWMgYnJ1c2hzdHJva2VzLCBkZWxpY2F0ZSB0ZXh0dXJlc1wiLFxuICBmdXR1cmlzdGljOiBcIkZ1dHVyaXN0aWMgaGlnaC10ZWNoIGRlc2lnbiB3aXRoIGhvbG9ncmFwaGljIGVsZW1lbnRzLCBjaHJvbWUgc3VyZmFjZXMsIEFJLWdlbmVyYXRlZCBwYXR0ZXJuc1wiLFxufTtcblxuY29uc3QgbW9vZFByb21wdHM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIGVuZXJnZXRpYzogXCJoaWdoIGVuZXJneSwgZHluYW1pYyBtb3ZlbWVudCwgZXhwbG9zaXZlLCBwb3dlcmZ1bFwiLFxuICBjYWxtOiBcInBlYWNlZnVsLCBzZXJlbmUsIHRyYW5xdWlsLCBtZWRpdGF0aXZlXCIsXG4gIGRhcms6IFwibXlzdGVyaW91cywgc2hhZG93eSwgaW50ZW5zZSwgZHJhbWF0aWNcIixcbiAgYnJpZ2h0OiBcImNoZWVyZnVsLCB1cGxpZnRpbmcsIHN1bm55LCBvcHRpbWlzdGljXCIsXG4gIG1lbGFuY2hvbGljOiBcImVtb3Rpb25hbCwgbm9zdGFsZ2ljLCBiaXR0ZXJzd2VldCwgdGhvdWdodGZ1bFwiLFxuICBhZ2dyZXNzaXZlOiBcImZpZXJjZSwgYm9sZCwgcmF3LCBwb3dlcmZ1bCBpbXBhY3RcIixcbn07XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiTm8gYXV0aG9yaXphdGlvbiBoZWFkZXJcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBjb25zdCBMT1ZBQkxFX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJMT1ZBQkxFX0FQSV9LRVlcIik7XG5cbiAgICBpZiAoIUxPVkFCTEVfQVBJX0tFWSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTE9WQUJMRV9BUElfS0VZIGlzIG5vdCBjb25maWd1cmVkXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgLy8gVmVyaWZ5IHVzZXJcbiAgICBjb25zdCBzdXBhYmFzZUNsaWVudCA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikhLCB7XG4gICAgICBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfSxcbiAgICB9KTtcbiAgICBcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9LCBlcnJvcjogdXNlckVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudC5hdXRoLmdldFVzZXIoKTtcbiAgICBpZiAodXNlckVycm9yIHx8ICF1c2VyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgeyBcbiAgICAgIHRyYWNrX2lkLCBcbiAgICAgIHRyYWNrX3RpdGxlLCBcbiAgICAgIGdlbnJlLFxuICAgICAgc3R5bGUgPSBcImFic3RyYWN0XCIsXG4gICAgICBtb29kID0gXCJlbmVyZ2V0aWNcIixcbiAgICAgIGN1c3RvbV9wcm9tcHQsXG4gICAgICBjb2xvcl9zY2hlbWUsXG4gICAgICBpbmNsdWRlX3RleHQgPSBmYWxzZSxcbiAgICB9ID0gYXdhaXQgcmVxLmpzb24oKTtcblxuICAgIGlmICghdHJhY2tfaWQpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwidHJhY2tfaWQgaXMgcmVxdWlyZWRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBHZW5lcmF0aW5nIEFJIGNvdmVyIGZvciB0cmFjazogJHt0cmFja19pZH0sIHN0eWxlOiAke3N0eWxlfSwgbW9vZDogJHttb29kfWApO1xuXG4gICAgLy8gQnVpbGQgdGhlIGNvbXByZWhlbnNpdmUgcHJvbXB0XG4gICAgY29uc3Qgc3R5bGVEZXNjcmlwdGlvbiA9IHN0eWxlUHJvbXB0c1tzdHlsZV0gfHwgc3R5bGVQcm9tcHRzLmFic3RyYWN0O1xuICAgIGNvbnN0IG1vb2REZXNjcmlwdGlvbiA9IG1vb2RQcm9tcHRzW21vb2RdIHx8IG1vb2RQcm9tcHRzLmVuZXJnZXRpYztcbiAgICBcbiAgICBsZXQgcHJvbXB0ID0gYENyZWF0ZSBhIHN0dW5uaW5nLCBwcm9mZXNzaW9uYWwgYWxidW0gY292ZXIgYXJ0ICgxMDI0eDEwMjQgcGl4ZWxzKSBmb3IgYSBtdXNpYyB0cmFjay5cblxuVHJhY2sgSW5mb3JtYXRpb246XG4tIFRpdGxlOiBcIiR7dHJhY2tfdGl0bGUgfHwgJ1VudGl0bGVkJ31cIlxuLSBHZW5yZTogJHtnZW5yZSB8fCBcImVsZWN0cm9uaWMgbXVzaWNcIn1cblxuVmlzdWFsIFN0eWxlOiAke3N0eWxlRGVzY3JpcHRpb259XG5Nb29kICYgQXRtb3NwaGVyZTogJHttb29kRGVzY3JpcHRpb259XG4ke2NvbG9yX3NjaGVtZSA/IGBDb2xvciBQYWxldHRlOiAke2NvbG9yX3NjaGVtZX1gIDogXCJcIn1cblxuUmVxdWlyZW1lbnRzOlxuLSBVbHRyYSBoaWdoIHJlc29sdXRpb24sIHByb2Zlc3Npb25hbCBxdWFsaXR5XG4tIE1vZGVybiwgdmlzdWFsbHkgc3RyaWtpbmcgZGVzaWduIHN1aXRhYmxlIGZvciBtdXNpYyBzdHJlYW1pbmcgcGxhdGZvcm1zXG4tIFNxdWFyZSAxOjEgYXNwZWN0IHJhdGlvIGFsYnVtIGFydHdvcmtcbi0gTm8gdGV4dCBvciB0eXBvZ3JhcGh5IG9uIHRoZSBpbWFnZVxuLSBSaWNoIGRldGFpbHMgYW5kIGFydGlzdGljIGNvbXBvc2l0aW9uXG4tIFNob3VsZCBldm9rZSBlbW90aW9ucyBtYXRjaGluZyB0aGUgbXVzaWMgc3R5bGVcblxuJHtjdXN0b21fcHJvbXB0ID8gYEFkZGl0aW9uYWwgY3JlYXRpdmUgZGlyZWN0aW9uOiAke2N1c3RvbV9wcm9tcHR9YCA6IFwiXCJ9XG5cbkNyZWF0ZSBhcnR3b3JrIHRoYXQgd291bGQgc3RhbmQgb3V0IG9uIFNwb3RpZnksIEFwcGxlIE11c2ljLCBhbmQgb3RoZXIgc3RyZWFtaW5nIHBsYXRmb3Jtcy5gO1xuXG4gICAgY29uc29sZS5sb2coXCJQcm9tcHQ6XCIsIHByb21wdCk7XG5cbiAgICAvLyBDYWxsIExvdmFibGUgQUkgd2l0aCBpbWFnZSBnZW5lcmF0aW9uXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcImh0dHBzOi8vYWkuZ2F0ZXdheS5sb3ZhYmxlLmRldi92MS9jaGF0L2NvbXBsZXRpb25zXCIsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtMT1ZBQkxFX0FQSV9LRVl9YCxcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBtb2RlbDogXCJnb29nbGUvZ2VtaW5pLTMtcHJvLWltYWdlLXByZXZpZXdcIixcbiAgICAgICAgbWVzc2FnZXM6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICByb2xlOiBcInVzZXJcIixcbiAgICAgICAgICAgIGNvbnRlbnQ6IHByb21wdCxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBtb2RhbGl0aWVzOiBbXCJpbWFnZVwiLCBcInRleHRcIl0sXG4gICAgICB9KSxcbiAgICB9KTtcblxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIGNvbnN0IGVycm9yVGV4dCA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJBSSBnYXRld2F5IGVycm9yOlwiLCByZXNwb25zZS5zdGF0dXMsIGVycm9yVGV4dCk7XG4gICAgICBcbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQyOSkge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiUmF0ZSBsaW1pdCBleGNlZWRlZC4gUGxlYXNlIHRyeSBhZ2FpbiBsYXRlci5cIiB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNDI5LCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQwMikge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiUGF5bWVudCByZXF1aXJlZC4gUGxlYXNlIGFkZCBmdW5kcyB0byB5b3VyIHdvcmtzcGFjZS5cIiB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNDAyLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBFcnJvcihgQUkgZ2F0ZXdheSBlcnJvcjogJHtyZXNwb25zZS5zdGF0dXN9YCk7XG4gICAgfVxuXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zdCBpbWFnZVVybCA9IGRhdGEuY2hvaWNlcz8uWzBdPy5tZXNzYWdlPy5pbWFnZXM/LlswXT8uaW1hZ2VfdXJsPy51cmw7XG5cbiAgICBpZiAoIWltYWdlVXJsKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiTm8gaW1hZ2UgaW4gcmVzcG9uc2U6XCIsIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vIGltYWdlIGdlbmVyYXRlZCBieSBBSVwiKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhcIkFJIGNvdmVyIGdlbmVyYXRlZCBzdWNjZXNzZnVsbHlcIik7XG5cbiAgICAvLyBVcGxvYWQgdGhlIGJhc2U2NCBpbWFnZSB0byBTdXBhYmFzZSBTdG9yYWdlXG4gICAgY29uc3QgYmFzZTY0RGF0YSA9IGltYWdlVXJsLnJlcGxhY2UoL15kYXRhOmltYWdlXFwvXFx3KztiYXNlNjQsLywgXCJcIik7XG4gICAgY29uc3QgaW1hZ2VCdWZmZXIgPSBVaW50OEFycmF5LmZyb20oYXRvYihiYXNlNjREYXRhKSwgKGMpID0+IGMuY2hhckNvZGVBdCgwKSk7XG4gICAgXG4gICAgY29uc3QgZmlsZU5hbWUgPSBgYWktY292ZXJzLyR7dHJhY2tfaWR9LSR7RGF0ZS5ub3coKX0ucG5nYDtcbiAgICBcbiAgICBjb25zdCB7IGRhdGE6IHVwbG9hZERhdGEsIGVycm9yOiB1cGxvYWRFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2Uuc3RvcmFnZVxuICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgIC51cGxvYWQoZmlsZU5hbWUsIGltYWdlQnVmZmVyLCB7XG4gICAgICAgIGNvbnRlbnRUeXBlOiBcImltYWdlL3BuZ1wiLFxuICAgICAgICB1cHNlcnQ6IHRydWUsXG4gICAgICB9KTtcblxuICAgIGlmICh1cGxvYWRFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIlN0b3JhZ2UgdXBsb2FkIGVycm9yOlwiLCB1cGxvYWRFcnJvcik7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gdXBsb2FkIEFJIGNvdmVyIHRvIHN0b3JhZ2VcIik7XG4gICAgfVxuXG4gICAgY29uc3QgeyBkYXRhOiBwdWJsaWNVcmwgfSA9IHN1cGFiYXNlLnN0b3JhZ2VcbiAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAuZ2V0UHVibGljVXJsKGZpbGVOYW1lKTtcblxuICAgIC8vIFN0b3JlIGluIGdhbGxlcnlfaXRlbXMgZm9yIHVzZXIncyBnYWxsZXJ5XG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcImdhbGxlcnlfaXRlbXNcIikuaW5zZXJ0KHtcbiAgICAgIHVzZXJfaWQ6IHVzZXIuaWQsXG4gICAgICB0cmFja19pZDogdHJhY2tfaWQsXG4gICAgICB0eXBlOiBcImFpX2NvdmVyXCIsXG4gICAgICB1cmw6IHB1YmxpY1VybC5wdWJsaWNVcmwsXG4gICAgICB0aXRsZTogYEFJIENvdmVyIC0gJHt0cmFja190aXRsZSB8fCAnVW50aXRsZWQnfWAsXG4gICAgICBwcm9tcHQ6IHByb21wdCxcbiAgICAgIHN0eWxlOiBzdHlsZSxcbiAgICAgIGlzX3B1YmxpYzogZmFsc2UsXG4gICAgfSk7XG5cbiAgICBjb25zb2xlLmxvZyhcIkNvdmVyIHNhdmVkIHRvIGdhbGxlcnk6XCIsIHB1YmxpY1VybC5wdWJsaWNVcmwpO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgY292ZXJfdXJsOiBwdWJsaWNVcmwucHVibGljVXJsLFxuICAgICAgICBzdHlsZTogc3R5bGUsXG4gICAgICAgIG1vb2Q6IG1vb2QsXG4gICAgICAgIG1lc3NhZ2U6IFwiQUkgY292ZXIgZ2VuZXJhdGVkIHN1Y2Nlc3NmdWxseVwiLFxuICAgICAgfSksXG4gICAgICB7XG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9XG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiZ2VuZXJhdGUtYWktY292ZXIgZXJyb3I6XCIsIGVycm9yKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgZXJyb3I6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCIsXG4gICAgICB9KSxcbiAgICAgIHtcbiAgICAgICAgc3RhdHVzOiA1MDAsXG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSx3Q0FBd0M7QUFDeEMsTUFBTSxlQUF1QztFQUMzQyxVQUFVO0VBQ1YsTUFBTTtFQUNOLFNBQVM7RUFDVCxPQUFPO0VBQ1AsUUFBUTtFQUNSLE9BQU87RUFDUCxRQUFRO0VBQ1IsU0FBUztFQUNULFlBQVk7RUFDWixZQUFZO0FBQ2Q7QUFFQSxNQUFNLGNBQXNDO0VBQzFDLFdBQVc7RUFDWCxNQUFNO0VBQ04sTUFBTTtFQUNOLFFBQVE7RUFDUixhQUFhO0VBQ2IsWUFBWTtBQUNkO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEwQixJQUNsRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFFckMsSUFBSSxDQUFDLGlCQUFpQjtNQUNwQixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0MsY0FBYztJQUNkLE1BQU0saUJBQWlCLGFBQWEsYUFBYSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsc0JBQXVCO01BQ25GLFFBQVE7UUFBRSxTQUFTO1VBQUUsZUFBZTtRQUFXO01BQUU7SUFDbkQ7SUFFQSxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxPQUFPO0lBQzlFLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWUsSUFDdkM7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxFQUNKLFFBQVEsRUFDUixXQUFXLEVBQ1gsS0FBSyxFQUNMLFFBQVEsVUFBVSxFQUNsQixPQUFPLFdBQVcsRUFDbEIsYUFBYSxFQUNiLFlBQVksRUFDWixlQUFlLEtBQUssRUFDckIsR0FBRyxNQUFNLElBQUksSUFBSTtJQUVsQixJQUFJLENBQUMsVUFBVTtNQUNiLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF1QixJQUMvQztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLCtCQUErQixFQUFFLFNBQVMsU0FBUyxFQUFFLE1BQU0sUUFBUSxFQUFFLEtBQUssQ0FBQztJQUV4RixpQ0FBaUM7SUFDakMsTUFBTSxtQkFBbUIsWUFBWSxDQUFDLE1BQU0sSUFBSSxhQUFhLFFBQVE7SUFDckUsTUFBTSxrQkFBa0IsV0FBVyxDQUFDLEtBQUssSUFBSSxZQUFZLFNBQVM7SUFFbEUsSUFBSSxTQUFTLENBQUM7OztVQUdSLEVBQUUsZUFBZSxXQUFXO1NBQzdCLEVBQUUsU0FBUyxtQkFBbUI7O2NBRXpCLEVBQUUsaUJBQWlCO21CQUNkLEVBQUUsZ0JBQWdCO0FBQ3JDLEVBQUUsZUFBZSxDQUFDLGVBQWUsRUFBRSxhQUFhLENBQUMsR0FBRyxHQUFHOzs7Ozs7Ozs7O0FBVXZELEVBQUUsZ0JBQWdCLENBQUMsK0JBQStCLEVBQUUsY0FBYyxDQUFDLEdBQUcsR0FBRzs7MkZBRWtCLENBQUM7SUFFeEYsUUFBUSxHQUFHLENBQUMsV0FBVztJQUV2Qix3Q0FBd0M7SUFDeEMsTUFBTSxXQUFXLE1BQU0sTUFBTSxzREFBc0Q7TUFDakYsUUFBUTtNQUNSLFNBQVM7UUFDUCxlQUFlLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDO1FBQzFDLGdCQUFnQjtNQUNsQjtNQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7UUFDbkIsT0FBTztRQUNQLFVBQVU7VUFDUjtZQUNFLE1BQU07WUFDTixTQUFTO1VBQ1g7U0FDRDtRQUNELFlBQVk7VUFBQztVQUFTO1NBQU87TUFDL0I7SUFDRjtJQUVBLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRTtNQUNoQixNQUFNLFlBQVksTUFBTSxTQUFTLElBQUk7TUFDckMsUUFBUSxLQUFLLENBQUMscUJBQXFCLFNBQVMsTUFBTSxFQUFFO01BRXBELElBQUksU0FBUyxNQUFNLEtBQUssS0FBSztRQUMzQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBK0MsSUFDdkU7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BQ0EsSUFBSSxTQUFTLE1BQU0sS0FBSyxLQUFLO1FBQzNCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUF3RCxJQUNoRjtVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFDQSxNQUFNLElBQUksTUFBTSxDQUFDLGtCQUFrQixFQUFFLFNBQVMsTUFBTSxDQUFDLENBQUM7SUFDeEQ7SUFFQSxNQUFNLE9BQU8sTUFBTSxTQUFTLElBQUk7SUFDaEMsTUFBTSxXQUFXLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRSxFQUFFLFNBQVMsUUFBUSxDQUFDLEVBQUUsRUFBRSxXQUFXO0lBRXJFLElBQUksQ0FBQyxVQUFVO01BQ2IsUUFBUSxLQUFLLENBQUMseUJBQXlCLEtBQUssU0FBUyxDQUFDO01BQ3RELE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsUUFBUSxHQUFHLENBQUM7SUFFWiw4Q0FBOEM7SUFDOUMsTUFBTSxhQUFhLFNBQVMsT0FBTyxDQUFDLDRCQUE0QjtJQUNoRSxNQUFNLGNBQWMsV0FBVyxJQUFJLENBQUMsS0FBSyxhQUFhLENBQUMsSUFBTSxFQUFFLFVBQVUsQ0FBQztJQUUxRSxNQUFNLFdBQVcsQ0FBQyxVQUFVLEVBQUUsU0FBUyxDQUFDLEVBQUUsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBRTFELE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FBUyxPQUFPLENBQ3BFLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxVQUFVLGFBQWE7TUFDN0IsYUFBYTtNQUNiLFFBQVE7SUFDVjtJQUVGLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLHlCQUF5QjtNQUN2QyxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sRUFBRSxNQUFNLFNBQVMsRUFBRSxHQUFHLFNBQVMsT0FBTyxDQUN6QyxJQUFJLENBQUMsVUFDTCxZQUFZLENBQUM7SUFFaEIsNENBQTRDO0lBQzVDLE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztNQUMxQyxTQUFTLEtBQUssRUFBRTtNQUNoQixVQUFVO01BQ1YsTUFBTTtNQUNOLEtBQUssVUFBVSxTQUFTO01BQ3hCLE9BQU8sQ0FBQyxXQUFXLEVBQUUsZUFBZSxXQUFXLENBQUM7TUFDaEQsUUFBUTtNQUNSLE9BQU87TUFDUCxXQUFXO0lBQ2I7SUFFQSxRQUFRLEdBQUcsQ0FBQywyQkFBMkIsVUFBVSxTQUFTO0lBRTFELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULFdBQVcsVUFBVSxTQUFTO01BQzlCLE9BQU87TUFDUCxNQUFNO01BQ04sU0FBUztJQUNYLElBQ0E7TUFDRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQ2hFO0VBRUosRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFDMUMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsT0FBTyxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUNsRCxJQUNBO01BQ0UsUUFBUTtNQUNSLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFDaEU7RUFFSjtBQUNGIn0=
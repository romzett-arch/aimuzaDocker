const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const ffmpegApiUrl = Deno.env.get("FFMPEG_API_URL");
    const ffmpegApiSecret = Deno.env.get("FFMPEG_API_SECRET");
    // Verify user authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Authorization required");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      throw new Error("Invalid token");
    }
    const body = await req.json();
    const { audio_url, track_id } = body;
    if (!audio_url) {
      throw new Error("audio_url is required");
    }
    console.log(`Analyzing audio: ${audio_url}`);
    let analysisResult;
    // Try FFmpeg API with auth
    const vpsAnalysis = async ()=>{
      if (!ffmpegApiUrl || !ffmpegApiSecret) {
        console.log("FFmpeg API not configured");
        return null;
      }
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(()=>controller.abort(), 10000);
        const baseUrl = ffmpegApiUrl.replace(/\/(clean-metadata|analyze|normalize)\/?$/, "");
        const probeResponse = await fetch(`${baseUrl}/analyze`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": ffmpegApiSecret
          },
          body: JSON.stringify({
            audio_url
          }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!probeResponse.ok) {
          console.log("FFmpeg API analyze error:", probeResponse.status);
          return null;
        }
        const vpsResult = await probeResponse.json();
        return parseVpsResult(vpsResult);
      } catch (e) {
        console.log("FFmpeg API call failed:", e);
        return null;
      }
    };
    const vpsResult = await vpsAnalysis();
    if (vpsResult) {
      analysisResult = vpsResult;
      console.log("Using FFmpeg API analysis result");
    } else {
      console.log("FFmpeg API unavailable, using simulated analysis");
      analysisResult = simulateAnalysis(audio_url);
    }
    // Save analysis to track_health_reports table if track_id provided
    if (track_id) {
      const { error: healthError } = await supabase.from("track_health_reports").upsert({
        track_id,
        quality_score: analysisResult.quality_score,
        lufs_original: analysisResult.original_lufs,
        peak_db: analysisResult.peak_db,
        dynamic_range: analysisResult.dynamic_range,
        spectrum_ok: analysisResult.spectrum_ok,
        high_freq_cutoff: analysisResult.high_freq_cutoff,
        upscale_detected: analysisResult.upscale_detected,
        sample_rate: analysisResult.sample_rate,
        bit_depth: analysisResult.bit_depth,
        channels: analysisResult.channels,
        duration: analysisResult.duration,
        format: analysisResult.format,
        master_quality: analysisResult.master_quality,
        recommendations: analysisResult.recommendations,
        analysis_status: "completed",
        updated_at: new Date().toISOString()
      }, {
        onConflict: "track_id"
      });
      if (healthError) {
        console.error("Error saving health report:", healthError);
      } else {
        console.log("Health report saved for track:", track_id);
      }
      // Also update legacy fields on tracks table
      await supabase.from("tracks").update({
        audio_quality_score: analysisResult.quality_score,
        audio_sample_rate: analysisResult.sample_rate,
        audio_bit_depth: analysisResult.bit_depth,
        audio_lufs: analysisResult.original_lufs,
        audio_peak_db: analysisResult.peak_db,
        upscale_detected: analysisResult.upscale_detected,
        needs_master_wav: !analysisResult.master_quality
      }).eq("id", track_id);
    }
    return new Response(JSON.stringify({
      success: true,
      analysis: analysisResult
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Analysis error:", errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
function parseVpsResult(vpsResult) {
  const { format, streams, lufs, spectrum } = vpsResult;
  const audioStream = streams?.find((s)=>s.codec_type === "audio") || {};
  const highFreqCutoff = spectrum?.high_freq_cutoff || 20000;
  const upscaleDetected = highFreqCutoff < 16000;
  let qualityScore = 10;
  if (upscaleDetected) qualityScore -= 3;
  if (audioStream.sample_rate < 44100) qualityScore -= 2;
  if (audioStream.bits_per_sample < 16) qualityScore -= 2;
  if (lufs?.integrated > -8) qualityScore -= 1;
  qualityScore = Math.max(1, Math.min(10, qualityScore));
  const sampleRate = parseInt(audioStream.sample_rate) || 44100;
  const bitDepth = audioStream.bits_per_sample || (audioStream.codec_name === "flac" ? 24 : 16);
  const originalLufs = lufs?.integrated || -16;
  const recommendations = [];
  if (upscaleDetected) {
    recommendations.push("Обнаружен апскейл. Рекомендуется загрузить оригинальный файл высокого качества.");
  }
  if (originalLufs > -12 || originalLufs < -18) {
    recommendations.push("Громкость будет нормализована до -14 LUFS для стриминговых платформ.");
  }
  if (bitDepth < 24 || ![
    "wav",
    "flac",
    "aiff"
  ].includes(format?.format_name || "")) {
    recommendations.push("Для дистрибуции рекомендуется WAV 24-bit.");
  }
  return {
    spectrum_ok: !upscaleDetected,
    high_freq_cutoff: highFreqCutoff,
    upscale_detected: upscaleDetected,
    quality_score: qualityScore,
    original_lufs: originalLufs,
    peak_db: lufs?.true_peak || -1,
    dynamic_range: lufs?.range || 8,
    needs_normalization: Math.abs(originalLufs - -14) > 1,
    sample_rate: sampleRate,
    bit_depth: bitDepth,
    channels: audioStream.channels || 2,
    duration: parseFloat(format?.duration) || 0,
    format: format?.format_name || "unknown",
    master_quality: bitDepth >= 24 && [
      "wav",
      "flac",
      "aiff"
    ].includes(format?.format_name || ""),
    recommendations
  };
}
function simulateAnalysis(audioUrl) {
  const urlLower = audioUrl.toLowerCase();
  const isWav = urlLower.includes(".wav");
  const isFlac = urlLower.includes(".flac");
  const isMp3 = urlLower.includes(".mp3");
  const format = isWav ? "wav" : isFlac ? "flac" : "mp3";
  const bitDepth = isWav ? 24 : isFlac ? 24 : 16;
  const sampleRate = 44100;
  const originalLufs = -14 + (Math.random() * 8 - 4);
  const upscaleDetected = isMp3 && Math.random() > 0.7;
  let qualityScore = isWav || isFlac ? 9 : 7;
  if (upscaleDetected) qualityScore -= 2;
  const recommendations = [];
  if (isMp3) {
    recommendations.push("MP3 формат. Для дистрибуции рекомендуется WAV 24-bit.");
  }
  if (Math.abs(originalLufs - -14) > 1) {
    recommendations.push("Громкость будет нормализована до -14 LUFS.");
  }
  return {
    spectrum_ok: !upscaleDetected,
    high_freq_cutoff: upscaleDetected ? 15500 : 20000,
    upscale_detected: upscaleDetected,
    quality_score: qualityScore,
    original_lufs: Math.round(originalLufs * 10) / 10,
    peak_db: -0.5 + Math.random() * -2,
    dynamic_range: 6 + Math.random() * 6,
    needs_normalization: Math.abs(originalLufs - -14) > 1,
    sample_rate: sampleRate,
    bit_depth: bitDepth,
    channels: 2,
    duration: 180 + Math.random() * 120,
    format,
    master_quality: bitDepth >= 24 && (isWav || isFlac),
    recommendations
  };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9hbmFseXplLWF1ZGlvLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMi40OS4xXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmludGVyZmFjZSBBbmFseXNpc1Jlc3VsdCB7XG4gIHNwZWN0cnVtX29rOiBib29sZWFuO1xuICBoaWdoX2ZyZXFfY3V0b2ZmOiBudW1iZXI7XG4gIHVwc2NhbGVfZGV0ZWN0ZWQ6IGJvb2xlYW47XG4gIHF1YWxpdHlfc2NvcmU6IG51bWJlcjtcbiAgb3JpZ2luYWxfbHVmczogbnVtYmVyO1xuICBwZWFrX2RiOiBudW1iZXI7XG4gIGR5bmFtaWNfcmFuZ2U6IG51bWJlcjtcbiAgbmVlZHNfbm9ybWFsaXphdGlvbjogYm9vbGVhbjtcbiAgc2FtcGxlX3JhdGU6IG51bWJlcjtcbiAgYml0X2RlcHRoOiBudW1iZXI7XG4gIGNoYW5uZWxzOiBudW1iZXI7XG4gIGR1cmF0aW9uOiBudW1iZXI7XG4gIGZvcm1hdDogc3RyaW5nO1xuICBtYXN0ZXJfcXVhbGl0eTogYm9vbGVhbjtcbiAgcmVjb21tZW5kYXRpb25zOiBzdHJpbmdbXTtcbn1cblxuc2VydmUoYXN5bmMgKHJlcTogUmVxdWVzdCkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIGNvbnN0IGZmbXBlZ0FwaVVybCA9IERlbm8uZW52LmdldChcIkZGTVBFR19BUElfVVJMXCIpO1xuICAgIGNvbnN0IGZmbXBlZ0FwaVNlY3JldCA9IERlbm8uZW52LmdldChcIkZGTVBFR19BUElfU0VDUkVUXCIpO1xuXG4gICAgLy8gVmVyaWZ5IHVzZXIgYXV0aGVudGljYXRpb25cbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkF1dGhvcml6YXRpb24gcmVxdWlyZWRcIik7XG4gICAgfVxuXG4gICAgY29uc3QgdG9rZW4gPSBhdXRoSGVhZGVyLnJlcGxhY2UoXCJCZWFyZXIgXCIsIFwiXCIpO1xuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0sIGVycm9yOiBhdXRoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcih0b2tlbik7XG4gICAgaWYgKGF1dGhFcnJvciB8fCAhdXNlcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCB0b2tlblwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zdCB7IGF1ZGlvX3VybCwgdHJhY2tfaWQgfSA9IGJvZHk7XG5cbiAgICBpZiAoIWF1ZGlvX3VybCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiYXVkaW9fdXJsIGlzIHJlcXVpcmVkXCIpO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBBbmFseXppbmcgYXVkaW86ICR7YXVkaW9fdXJsfWApO1xuXG4gICAgbGV0IGFuYWx5c2lzUmVzdWx0OiBBbmFseXNpc1Jlc3VsdDtcblxuICAgIC8vIFRyeSBGRm1wZWcgQVBJIHdpdGggYXV0aFxuICAgIGNvbnN0IHZwc0FuYWx5c2lzID0gYXN5bmMgKCk6IFByb21pc2U8QW5hbHlzaXNSZXN1bHQgfCBudWxsPiA9PiB7XG4gICAgICBpZiAoIWZmbXBlZ0FwaVVybCB8fCAhZmZtcGVnQXBpU2VjcmV0KSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiRkZtcGVnIEFQSSBub3QgY29uZmlndXJlZFwiKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgICAgICBjb25zdCB0aW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSwgMTAwMDApO1xuXG4gICAgICAgIGNvbnN0IGJhc2VVcmwgPSBmZm1wZWdBcGlVcmwhLnJlcGxhY2UoL1xcLyhjbGVhbi1tZXRhZGF0YXxhbmFseXplfG5vcm1hbGl6ZSlcXC8/JC8sIFwiXCIpO1xuICAgICAgICBjb25zdCBwcm9iZVJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7YmFzZVVybH0vYW5hbHl6ZWAsIHtcbiAgICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICAgICAgXCJ4LWFwaS1rZXlcIjogZmZtcGVnQXBpU2VjcmV0LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBhdWRpb191cmwgfSksXG4gICAgICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG5cbiAgICAgICAgaWYgKCFwcm9iZVJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJGRm1wZWcgQVBJIGFuYWx5emUgZXJyb3I6XCIsIHByb2JlUmVzcG9uc2Uuc3RhdHVzKTtcbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHZwc1Jlc3VsdCA9IGF3YWl0IHByb2JlUmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gcGFyc2VWcHNSZXN1bHQodnBzUmVzdWx0KTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJGRm1wZWcgQVBJIGNhbGwgZmFpbGVkOlwiLCBlKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHZwc1Jlc3VsdCA9IGF3YWl0IHZwc0FuYWx5c2lzKCk7XG4gICAgaWYgKHZwc1Jlc3VsdCkge1xuICAgICAgYW5hbHlzaXNSZXN1bHQgPSB2cHNSZXN1bHQ7XG4gICAgICBjb25zb2xlLmxvZyhcIlVzaW5nIEZGbXBlZyBBUEkgYW5hbHlzaXMgcmVzdWx0XCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLmxvZyhcIkZGbXBlZyBBUEkgdW5hdmFpbGFibGUsIHVzaW5nIHNpbXVsYXRlZCBhbmFseXNpc1wiKTtcbiAgICAgIGFuYWx5c2lzUmVzdWx0ID0gc2ltdWxhdGVBbmFseXNpcyhhdWRpb191cmwpO1xuICAgIH1cblxuICAgIC8vIFNhdmUgYW5hbHlzaXMgdG8gdHJhY2tfaGVhbHRoX3JlcG9ydHMgdGFibGUgaWYgdHJhY2tfaWQgcHJvdmlkZWRcbiAgICBpZiAodHJhY2tfaWQpIHtcbiAgICAgIGNvbnN0IHsgZXJyb3I6IGhlYWx0aEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInRyYWNrX2hlYWx0aF9yZXBvcnRzXCIpXG4gICAgICAgIC51cHNlcnQoe1xuICAgICAgICAgIHRyYWNrX2lkLFxuICAgICAgICAgIHF1YWxpdHlfc2NvcmU6IGFuYWx5c2lzUmVzdWx0LnF1YWxpdHlfc2NvcmUsXG4gICAgICAgICAgbHVmc19vcmlnaW5hbDogYW5hbHlzaXNSZXN1bHQub3JpZ2luYWxfbHVmcyxcbiAgICAgICAgICBwZWFrX2RiOiBhbmFseXNpc1Jlc3VsdC5wZWFrX2RiLFxuICAgICAgICAgIGR5bmFtaWNfcmFuZ2U6IGFuYWx5c2lzUmVzdWx0LmR5bmFtaWNfcmFuZ2UsXG4gICAgICAgICAgc3BlY3RydW1fb2s6IGFuYWx5c2lzUmVzdWx0LnNwZWN0cnVtX29rLFxuICAgICAgICAgIGhpZ2hfZnJlcV9jdXRvZmY6IGFuYWx5c2lzUmVzdWx0LmhpZ2hfZnJlcV9jdXRvZmYsXG4gICAgICAgICAgdXBzY2FsZV9kZXRlY3RlZDogYW5hbHlzaXNSZXN1bHQudXBzY2FsZV9kZXRlY3RlZCxcbiAgICAgICAgICBzYW1wbGVfcmF0ZTogYW5hbHlzaXNSZXN1bHQuc2FtcGxlX3JhdGUsXG4gICAgICAgICAgYml0X2RlcHRoOiBhbmFseXNpc1Jlc3VsdC5iaXRfZGVwdGgsXG4gICAgICAgICAgY2hhbm5lbHM6IGFuYWx5c2lzUmVzdWx0LmNoYW5uZWxzLFxuICAgICAgICAgIGR1cmF0aW9uOiBhbmFseXNpc1Jlc3VsdC5kdXJhdGlvbixcbiAgICAgICAgICBmb3JtYXQ6IGFuYWx5c2lzUmVzdWx0LmZvcm1hdCxcbiAgICAgICAgICBtYXN0ZXJfcXVhbGl0eTogYW5hbHlzaXNSZXN1bHQubWFzdGVyX3F1YWxpdHksXG4gICAgICAgICAgcmVjb21tZW5kYXRpb25zOiBhbmFseXNpc1Jlc3VsdC5yZWNvbW1lbmRhdGlvbnMsXG4gICAgICAgICAgYW5hbHlzaXNfc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgfSwge1xuICAgICAgICAgIG9uQ29uZmxpY3Q6IFwidHJhY2tfaWRcIixcbiAgICAgICAgfSk7XG5cbiAgICAgIGlmIChoZWFsdGhFcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igc2F2aW5nIGhlYWx0aCByZXBvcnQ6XCIsIGhlYWx0aEVycm9yKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiSGVhbHRoIHJlcG9ydCBzYXZlZCBmb3IgdHJhY2s6XCIsIHRyYWNrX2lkKTtcbiAgICAgIH1cblxuICAgICAgLy8gQWxzbyB1cGRhdGUgbGVnYWN5IGZpZWxkcyBvbiB0cmFja3MgdGFibGVcbiAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgIGF1ZGlvX3F1YWxpdHlfc2NvcmU6IGFuYWx5c2lzUmVzdWx0LnF1YWxpdHlfc2NvcmUsXG4gICAgICAgICAgYXVkaW9fc2FtcGxlX3JhdGU6IGFuYWx5c2lzUmVzdWx0LnNhbXBsZV9yYXRlLFxuICAgICAgICAgIGF1ZGlvX2JpdF9kZXB0aDogYW5hbHlzaXNSZXN1bHQuYml0X2RlcHRoLFxuICAgICAgICAgIGF1ZGlvX2x1ZnM6IGFuYWx5c2lzUmVzdWx0Lm9yaWdpbmFsX2x1ZnMsXG4gICAgICAgICAgYXVkaW9fcGVha19kYjogYW5hbHlzaXNSZXN1bHQucGVha19kYixcbiAgICAgICAgICB1cHNjYWxlX2RldGVjdGVkOiBhbmFseXNpc1Jlc3VsdC51cHNjYWxlX2RldGVjdGVkLFxuICAgICAgICAgIG5lZWRzX21hc3Rlcl93YXY6ICFhbmFseXNpc1Jlc3VsdC5tYXN0ZXJfcXVhbGl0eSxcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tfaWQpO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IHRydWUsIGFuYWx5c2lzOiBhbmFseXNpc1Jlc3VsdCB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgY29uc29sZS5lcnJvcihcIkFuYWx5c2lzIGVycm9yOlwiLCBlcnJvck1lc3NhZ2UpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3JNZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG5cbmZ1bmN0aW9uIHBhcnNlVnBzUmVzdWx0KHZwc1Jlc3VsdDogYW55KTogQW5hbHlzaXNSZXN1bHQge1xuICBjb25zdCB7IGZvcm1hdCwgc3RyZWFtcywgbHVmcywgc3BlY3RydW0gfSA9IHZwc1Jlc3VsdDtcbiAgY29uc3QgYXVkaW9TdHJlYW0gPSBzdHJlYW1zPy5maW5kKChzOiBhbnkpID0+IHMuY29kZWNfdHlwZSA9PT0gXCJhdWRpb1wiKSB8fCB7fTtcblxuICBjb25zdCBoaWdoRnJlcUN1dG9mZiA9IHNwZWN0cnVtPy5oaWdoX2ZyZXFfY3V0b2ZmIHx8IDIwMDAwO1xuICBjb25zdCB1cHNjYWxlRGV0ZWN0ZWQgPSBoaWdoRnJlcUN1dG9mZiA8IDE2MDAwO1xuXG4gIGxldCBxdWFsaXR5U2NvcmUgPSAxMDtcbiAgaWYgKHVwc2NhbGVEZXRlY3RlZCkgcXVhbGl0eVNjb3JlIC09IDM7XG4gIGlmIChhdWRpb1N0cmVhbS5zYW1wbGVfcmF0ZSA8IDQ0MTAwKSBxdWFsaXR5U2NvcmUgLT0gMjtcbiAgaWYgKGF1ZGlvU3RyZWFtLmJpdHNfcGVyX3NhbXBsZSA8IDE2KSBxdWFsaXR5U2NvcmUgLT0gMjtcbiAgaWYgKGx1ZnM/LmludGVncmF0ZWQgPiAtOCkgcXVhbGl0eVNjb3JlIC09IDE7XG4gIHF1YWxpdHlTY29yZSA9IE1hdGgubWF4KDEsIE1hdGgubWluKDEwLCBxdWFsaXR5U2NvcmUpKTtcblxuICBjb25zdCBzYW1wbGVSYXRlID0gcGFyc2VJbnQoYXVkaW9TdHJlYW0uc2FtcGxlX3JhdGUpIHx8IDQ0MTAwO1xuICBjb25zdCBiaXREZXB0aCA9IGF1ZGlvU3RyZWFtLmJpdHNfcGVyX3NhbXBsZSB8fCAoYXVkaW9TdHJlYW0uY29kZWNfbmFtZSA9PT0gXCJmbGFjXCIgPyAyNCA6IDE2KTtcbiAgY29uc3Qgb3JpZ2luYWxMdWZzID0gbHVmcz8uaW50ZWdyYXRlZCB8fCAtMTY7XG5cbiAgY29uc3QgcmVjb21tZW5kYXRpb25zOiBzdHJpbmdbXSA9IFtdO1xuICBpZiAodXBzY2FsZURldGVjdGVkKSB7XG4gICAgcmVjb21tZW5kYXRpb25zLnB1c2goXCLQntCx0L3QsNGA0YPQttC10L0g0LDQv9GB0LrQtdC50LsuINCg0LXQutC+0LzQtdC90LTRg9C10YLRgdGPINC30LDQs9GA0YPQt9C40YLRjCDQvtGA0LjQs9C40L3QsNC70YzQvdGL0Lkg0YTQsNC50Lsg0LLRi9GB0L7QutC+0LPQviDQutCw0YfQtdGB0YLQstCwLlwiKTtcbiAgfVxuICBpZiAob3JpZ2luYWxMdWZzID4gLTEyIHx8IG9yaWdpbmFsTHVmcyA8IC0xOCkge1xuICAgIHJlY29tbWVuZGF0aW9ucy5wdXNoKFwi0JPRgNC+0LzQutC+0YHRgtGMINCx0YPQtNC10YIg0L3QvtGA0LzQsNC70LjQt9C+0LLQsNC90LAg0LTQviAtMTQgTFVGUyDQtNC70Y8g0YHRgtGA0LjQvNC40L3Qs9C+0LLRi9GFINC/0LvQsNGC0YTQvtGA0LwuXCIpO1xuICB9XG4gIGlmIChiaXREZXB0aCA8IDI0IHx8ICFbXCJ3YXZcIiwgXCJmbGFjXCIsIFwiYWlmZlwiXS5pbmNsdWRlcyhmb3JtYXQ/LmZvcm1hdF9uYW1lIHx8IFwiXCIpKSB7XG4gICAgcmVjb21tZW5kYXRpb25zLnB1c2goXCLQlNC70Y8g0LTQuNGB0YLRgNC40LHRg9GG0LjQuCDRgNC10LrQvtC80LXQvdC00YPQtdGC0YHRjyBXQVYgMjQtYml0LlwiKTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgc3BlY3RydW1fb2s6ICF1cHNjYWxlRGV0ZWN0ZWQsXG4gICAgaGlnaF9mcmVxX2N1dG9mZjogaGlnaEZyZXFDdXRvZmYsXG4gICAgdXBzY2FsZV9kZXRlY3RlZDogdXBzY2FsZURldGVjdGVkLFxuICAgIHF1YWxpdHlfc2NvcmU6IHF1YWxpdHlTY29yZSxcbiAgICBvcmlnaW5hbF9sdWZzOiBvcmlnaW5hbEx1ZnMsXG4gICAgcGVha19kYjogbHVmcz8udHJ1ZV9wZWFrIHx8IC0xLFxuICAgIGR5bmFtaWNfcmFuZ2U6IGx1ZnM/LnJhbmdlIHx8IDgsXG4gICAgbmVlZHNfbm9ybWFsaXphdGlvbjogTWF0aC5hYnMob3JpZ2luYWxMdWZzIC0gKC0xNCkpID4gMSxcbiAgICBzYW1wbGVfcmF0ZTogc2FtcGxlUmF0ZSxcbiAgICBiaXRfZGVwdGg6IGJpdERlcHRoLFxuICAgIGNoYW5uZWxzOiBhdWRpb1N0cmVhbS5jaGFubmVscyB8fCAyLFxuICAgIGR1cmF0aW9uOiBwYXJzZUZsb2F0KGZvcm1hdD8uZHVyYXRpb24pIHx8IDAsXG4gICAgZm9ybWF0OiBmb3JtYXQ/LmZvcm1hdF9uYW1lIHx8IFwidW5rbm93blwiLFxuICAgIG1hc3Rlcl9xdWFsaXR5OiBiaXREZXB0aCA+PSAyNCAmJiBbXCJ3YXZcIiwgXCJmbGFjXCIsIFwiYWlmZlwiXS5pbmNsdWRlcyhmb3JtYXQ/LmZvcm1hdF9uYW1lIHx8IFwiXCIpLFxuICAgIHJlY29tbWVuZGF0aW9ucyxcbiAgfTtcbn1cblxuZnVuY3Rpb24gc2ltdWxhdGVBbmFseXNpcyhhdWRpb1VybDogc3RyaW5nKTogQW5hbHlzaXNSZXN1bHQge1xuICBjb25zdCB1cmxMb3dlciA9IGF1ZGlvVXJsLnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IGlzV2F2ID0gdXJsTG93ZXIuaW5jbHVkZXMoXCIud2F2XCIpO1xuICBjb25zdCBpc0ZsYWMgPSB1cmxMb3dlci5pbmNsdWRlcyhcIi5mbGFjXCIpO1xuICBjb25zdCBpc01wMyA9IHVybExvd2VyLmluY2x1ZGVzKFwiLm1wM1wiKTtcblxuICBjb25zdCBmb3JtYXQgPSBpc1dhdiA/IFwid2F2XCIgOiBpc0ZsYWMgPyBcImZsYWNcIiA6IFwibXAzXCI7XG4gIGNvbnN0IGJpdERlcHRoID0gaXNXYXYgPyAyNCA6IGlzRmxhYyA/IDI0IDogMTY7XG4gIGNvbnN0IHNhbXBsZVJhdGUgPSA0NDEwMDtcblxuICBjb25zdCBvcmlnaW5hbEx1ZnMgPSAtMTQgKyAoTWF0aC5yYW5kb20oKSAqIDggLSA0KTtcbiAgY29uc3QgdXBzY2FsZURldGVjdGVkID0gaXNNcDMgJiYgTWF0aC5yYW5kb20oKSA+IDAuNztcblxuICBsZXQgcXVhbGl0eVNjb3JlID0gaXNXYXYgfHwgaXNGbGFjID8gOSA6IDc7XG4gIGlmICh1cHNjYWxlRGV0ZWN0ZWQpIHF1YWxpdHlTY29yZSAtPSAyO1xuXG4gIGNvbnN0IHJlY29tbWVuZGF0aW9uczogc3RyaW5nW10gPSBbXTtcbiAgaWYgKGlzTXAzKSB7XG4gICAgcmVjb21tZW5kYXRpb25zLnB1c2goXCJNUDMg0YTQvtGA0LzQsNGCLiDQlNC70Y8g0LTQuNGB0YLRgNC40LHRg9GG0LjQuCDRgNC10LrQvtC80LXQvdC00YPQtdGC0YHRjyBXQVYgMjQtYml0LlwiKTtcbiAgfVxuICBpZiAoTWF0aC5hYnMob3JpZ2luYWxMdWZzIC0gKC0xNCkpID4gMSkge1xuICAgIHJlY29tbWVuZGF0aW9ucy5wdXNoKFwi0JPRgNC+0LzQutC+0YHRgtGMINCx0YPQtNC10YIg0L3QvtGA0LzQsNC70LjQt9C+0LLQsNC90LAg0LTQviAtMTQgTFVGUy5cIik7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIHNwZWN0cnVtX29rOiAhdXBzY2FsZURldGVjdGVkLFxuICAgIGhpZ2hfZnJlcV9jdXRvZmY6IHVwc2NhbGVEZXRlY3RlZCA/IDE1NTAwIDogMjAwMDAsXG4gICAgdXBzY2FsZV9kZXRlY3RlZDogdXBzY2FsZURldGVjdGVkLFxuICAgIHF1YWxpdHlfc2NvcmU6IHF1YWxpdHlTY29yZSxcbiAgICBvcmlnaW5hbF9sdWZzOiBNYXRoLnJvdW5kKG9yaWdpbmFsTHVmcyAqIDEwKSAvIDEwLFxuICAgIHBlYWtfZGI6IC0wLjUgKyBNYXRoLnJhbmRvbSgpICogLTIsXG4gICAgZHluYW1pY19yYW5nZTogNiArIE1hdGgucmFuZG9tKCkgKiA2LFxuICAgIG5lZWRzX25vcm1hbGl6YXRpb246IE1hdGguYWJzKG9yaWdpbmFsTHVmcyAtICgtMTQpKSA+IDEsXG4gICAgc2FtcGxlX3JhdGU6IHNhbXBsZVJhdGUsXG4gICAgYml0X2RlcHRoOiBiaXREZXB0aCxcbiAgICBjaGFubmVsczogMixcbiAgICBkdXJhdGlvbjogMTgwICsgTWF0aC5yYW5kb20oKSAqIDEyMCxcbiAgICBmb3JtYXQsXG4gICAgbWFzdGVyX3F1YWxpdHk6IGJpdERlcHRoID49IDI0ICYmIChpc1dhdiB8fCBpc0ZsYWMpLFxuICAgIHJlY29tbWVuZGF0aW9ucyxcbiAgfTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBQ25GLFNBQVMsWUFBWSxRQUFRLDhDQUE4QztBQUUzRSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQW9CQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbEMsTUFBTSxrQkFBa0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBRXJDLDZCQUE2QjtJQUM3QixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZO01BQ2YsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLFFBQVEsV0FBVyxPQUFPLENBQUMsV0FBVztJQUM1QyxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxTQUFTLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDekUsSUFBSSxhQUFhLENBQUMsTUFBTTtNQUN0QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtJQUMzQixNQUFNLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxHQUFHO0lBRWhDLElBQUksQ0FBQyxXQUFXO01BQ2QsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGlCQUFpQixFQUFFLFVBQVUsQ0FBQztJQUUzQyxJQUFJO0lBRUosMkJBQTJCO0lBQzNCLE1BQU0sY0FBYztNQUNsQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCO1FBQ3JDLFFBQVEsR0FBRyxDQUFDO1FBQ1osT0FBTztNQUNUO01BQ0EsSUFBSTtRQUNGLE1BQU0sYUFBYSxJQUFJO1FBQ3ZCLE1BQU0sWUFBWSxXQUFXLElBQU0sV0FBVyxLQUFLLElBQUk7UUFFdkQsTUFBTSxVQUFVLGFBQWMsT0FBTyxDQUFDLDRDQUE0QztRQUNsRixNQUFNLGdCQUFnQixNQUFNLE1BQU0sQ0FBQyxFQUFFLFFBQVEsUUFBUSxDQUFDLEVBQUU7VUFDdEQsUUFBUTtVQUNSLFNBQVM7WUFDUCxnQkFBZ0I7WUFDaEIsYUFBYTtVQUNmO1VBQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztZQUFFO1VBQVU7VUFDakMsUUFBUSxXQUFXLE1BQU07UUFDM0I7UUFFQSxhQUFhO1FBRWIsSUFBSSxDQUFDLGNBQWMsRUFBRSxFQUFFO1VBQ3JCLFFBQVEsR0FBRyxDQUFDLDZCQUE2QixjQUFjLE1BQU07VUFDN0QsT0FBTztRQUNUO1FBRUEsTUFBTSxZQUFZLE1BQU0sY0FBYyxJQUFJO1FBQzFDLE9BQU8sZUFBZTtNQUN4QixFQUFFLE9BQU8sR0FBRztRQUNWLFFBQVEsR0FBRyxDQUFDLDJCQUEyQjtRQUN2QyxPQUFPO01BQ1Q7SUFDRjtJQUVBLE1BQU0sWUFBWSxNQUFNO0lBQ3hCLElBQUksV0FBVztNQUNiLGlCQUFpQjtNQUNqQixRQUFRLEdBQUcsQ0FBQztJQUNkLE9BQU87TUFDTCxRQUFRLEdBQUcsQ0FBQztNQUNaLGlCQUFpQixpQkFBaUI7SUFDcEM7SUFFQSxtRUFBbUU7SUFDbkUsSUFBSSxVQUFVO01BQ1osTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUNsQyxJQUFJLENBQUMsd0JBQ0wsTUFBTSxDQUFDO1FBQ047UUFDQSxlQUFlLGVBQWUsYUFBYTtRQUMzQyxlQUFlLGVBQWUsYUFBYTtRQUMzQyxTQUFTLGVBQWUsT0FBTztRQUMvQixlQUFlLGVBQWUsYUFBYTtRQUMzQyxhQUFhLGVBQWUsV0FBVztRQUN2QyxrQkFBa0IsZUFBZSxnQkFBZ0I7UUFDakQsa0JBQWtCLGVBQWUsZ0JBQWdCO1FBQ2pELGFBQWEsZUFBZSxXQUFXO1FBQ3ZDLFdBQVcsZUFBZSxTQUFTO1FBQ25DLFVBQVUsZUFBZSxRQUFRO1FBQ2pDLFVBQVUsZUFBZSxRQUFRO1FBQ2pDLFFBQVEsZUFBZSxNQUFNO1FBQzdCLGdCQUFnQixlQUFlLGNBQWM7UUFDN0MsaUJBQWlCLGVBQWUsZUFBZTtRQUMvQyxpQkFBaUI7UUFDakIsWUFBWSxJQUFJLE9BQU8sV0FBVztNQUNwQyxHQUFHO1FBQ0QsWUFBWTtNQUNkO01BRUYsSUFBSSxhQUFhO1FBQ2YsUUFBUSxLQUFLLENBQUMsK0JBQStCO01BQy9DLE9BQU87UUFDTCxRQUFRLEdBQUcsQ0FBQyxrQ0FBa0M7TUFDaEQ7TUFFQSw0Q0FBNEM7TUFDNUMsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztRQUNOLHFCQUFxQixlQUFlLGFBQWE7UUFDakQsbUJBQW1CLGVBQWUsV0FBVztRQUM3QyxpQkFBaUIsZUFBZSxTQUFTO1FBQ3pDLFlBQVksZUFBZSxhQUFhO1FBQ3hDLGVBQWUsZUFBZSxPQUFPO1FBQ3JDLGtCQUFrQixlQUFlLGdCQUFnQjtRQUNqRCxrQkFBa0IsQ0FBQyxlQUFlLGNBQWM7TUFDbEQsR0FDQyxFQUFFLENBQUMsTUFBTTtJQUNkO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU0sVUFBVTtJQUFlLElBQ3pEO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsTUFBTSxlQUFlLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQzlELFFBQVEsS0FBSyxDQUFDLG1CQUFtQjtJQUNqQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLFNBQVM7TUFBTyxPQUFPO0lBQWEsSUFDckQ7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsU0FBYztFQUNwQyxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUc7RUFDNUMsTUFBTSxjQUFjLFNBQVMsS0FBSyxDQUFDLElBQVcsRUFBRSxVQUFVLEtBQUssWUFBWSxDQUFDO0VBRTVFLE1BQU0saUJBQWlCLFVBQVUsb0JBQW9CO0VBQ3JELE1BQU0sa0JBQWtCLGlCQUFpQjtFQUV6QyxJQUFJLGVBQWU7RUFDbkIsSUFBSSxpQkFBaUIsZ0JBQWdCO0VBQ3JDLElBQUksWUFBWSxXQUFXLEdBQUcsT0FBTyxnQkFBZ0I7RUFDckQsSUFBSSxZQUFZLGVBQWUsR0FBRyxJQUFJLGdCQUFnQjtFQUN0RCxJQUFJLE1BQU0sYUFBYSxDQUFDLEdBQUcsZ0JBQWdCO0VBQzNDLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQyxJQUFJO0VBRXhDLE1BQU0sYUFBYSxTQUFTLFlBQVksV0FBVyxLQUFLO0VBQ3hELE1BQU0sV0FBVyxZQUFZLGVBQWUsSUFBSSxDQUFDLFlBQVksVUFBVSxLQUFLLFNBQVMsS0FBSyxFQUFFO0VBQzVGLE1BQU0sZUFBZSxNQUFNLGNBQWMsQ0FBQztFQUUxQyxNQUFNLGtCQUE0QixFQUFFO0VBQ3BDLElBQUksaUJBQWlCO0lBQ25CLGdCQUFnQixJQUFJLENBQUM7RUFDdkI7RUFDQSxJQUFJLGVBQWUsQ0FBQyxNQUFNLGVBQWUsQ0FBQyxJQUFJO0lBQzVDLGdCQUFnQixJQUFJLENBQUM7RUFDdkI7RUFDQSxJQUFJLFdBQVcsTUFBTSxDQUFDO0lBQUM7SUFBTztJQUFRO0dBQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxlQUFlLEtBQUs7SUFDakYsZ0JBQWdCLElBQUksQ0FBQztFQUN2QjtFQUVBLE9BQU87SUFDTCxhQUFhLENBQUM7SUFDZCxrQkFBa0I7SUFDbEIsa0JBQWtCO0lBQ2xCLGVBQWU7SUFDZixlQUFlO0lBQ2YsU0FBUyxNQUFNLGFBQWEsQ0FBQztJQUM3QixlQUFlLE1BQU0sU0FBUztJQUM5QixxQkFBcUIsS0FBSyxHQUFHLENBQUMsZUFBZ0IsQ0FBQyxNQUFPO0lBQ3RELGFBQWE7SUFDYixXQUFXO0lBQ1gsVUFBVSxZQUFZLFFBQVEsSUFBSTtJQUNsQyxVQUFVLFdBQVcsUUFBUSxhQUFhO0lBQzFDLFFBQVEsUUFBUSxlQUFlO0lBQy9CLGdCQUFnQixZQUFZLE1BQU07TUFBQztNQUFPO01BQVE7S0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFRLGVBQWU7SUFDMUY7RUFDRjtBQUNGO0FBRUEsU0FBUyxpQkFBaUIsUUFBZ0I7RUFDeEMsTUFBTSxXQUFXLFNBQVMsV0FBVztFQUNyQyxNQUFNLFFBQVEsU0FBUyxRQUFRLENBQUM7RUFDaEMsTUFBTSxTQUFTLFNBQVMsUUFBUSxDQUFDO0VBQ2pDLE1BQU0sUUFBUSxTQUFTLFFBQVEsQ0FBQztFQUVoQyxNQUFNLFNBQVMsUUFBUSxRQUFRLFNBQVMsU0FBUztFQUNqRCxNQUFNLFdBQVcsUUFBUSxLQUFLLFNBQVMsS0FBSztFQUM1QyxNQUFNLGFBQWE7RUFFbkIsTUFBTSxlQUFlLENBQUMsS0FBSyxDQUFDLEtBQUssTUFBTSxLQUFLLElBQUksQ0FBQztFQUNqRCxNQUFNLGtCQUFrQixTQUFTLEtBQUssTUFBTSxLQUFLO0VBRWpELElBQUksZUFBZSxTQUFTLFNBQVMsSUFBSTtFQUN6QyxJQUFJLGlCQUFpQixnQkFBZ0I7RUFFckMsTUFBTSxrQkFBNEIsRUFBRTtFQUNwQyxJQUFJLE9BQU87SUFDVCxnQkFBZ0IsSUFBSSxDQUFDO0VBQ3ZCO0VBQ0EsSUFBSSxLQUFLLEdBQUcsQ0FBQyxlQUFnQixDQUFDLE1BQU8sR0FBRztJQUN0QyxnQkFBZ0IsSUFBSSxDQUFDO0VBQ3ZCO0VBRUEsT0FBTztJQUNMLGFBQWEsQ0FBQztJQUNkLGtCQUFrQixrQkFBa0IsUUFBUTtJQUM1QyxrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLGVBQWUsS0FBSyxLQUFLLENBQUMsZUFBZSxNQUFNO0lBQy9DLFNBQVMsQ0FBQyxNQUFNLEtBQUssTUFBTSxLQUFLLENBQUM7SUFDakMsZUFBZSxJQUFJLEtBQUssTUFBTSxLQUFLO0lBQ25DLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxlQUFnQixDQUFDLE1BQU87SUFDdEQsYUFBYTtJQUNiLFdBQVc7SUFDWCxVQUFVO0lBQ1YsVUFBVSxNQUFNLEtBQUssTUFBTSxLQUFLO0lBQ2hDO0lBQ0EsZ0JBQWdCLFlBQVksTUFBTSxDQUFDLFNBQVMsTUFBTTtJQUNsRDtFQUNGO0FBQ0YifQ==
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const ffmpegApiUrl = Deno.env.get("FFMPEG_API_URL");
    const ffmpegApiSecret = Deno.env.get("FFMPEG_API_SECRET");
    // Verify user authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Authorization required");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      throw new Error("Invalid token");
    }
    const body = await req.json();
    const { audio_url, track_id, target_lufs = -14, strip_metadata = true, brand_metadata = true } = body;
    if (!audio_url || !track_id) {
      throw new Error("audio_url and track_id are required");
    }
    // Get track and user info for branding
    const { data: track } = await supabase.from("tracks").select("title, user_id, profiles!tracks_user_id_fkey(username)").eq("id", track_id).single();
    const username = track?.profiles?.username || "Unknown";
    console.log(`Normalizing audio for track ${track_id}: ${audio_url}`);
    const normalizePayload = {
      audio_url,
      target_lufs,
      strip_metadata,
      brand_metadata,
      metadata: brand_metadata ? {
        artist: username,
        title: track?.title || "Untitled",
        album: "AImuza",
        comment: `Generated on aimuza.ru | User: ${username}`,
        date: new Date().getFullYear().toString(),
        encoder: "AImuza Music Terminal",
        copyright: `© ${new Date().getFullYear()} ${username} via AImuza`,
        user_id: user.id,
        website: "https://aimuza.ru"
      } : undefined
    };
    let result;
    // Try FFmpeg API with auth
    const vpsNormalize = async ()=>{
      if (!ffmpegApiUrl || !ffmpegApiSecret) {
        console.log("FFmpeg API not configured");
        return null;
      }
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(()=>controller.abort(), 120000); // 2 min for two-pass loudnorm
        const baseUrl = ffmpegApiUrl.replace(/\/(clean-metadata|analyze|normalize)\/?$/, "");
        const bodyStr = JSON.stringify(normalizePayload);
        console.log("Sending normalize request, body length:", bodyStr.length);
        const resp = await fetch(`${baseUrl}/normalize`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            "x-api-key": ffmpegApiSecret
          },
          body: bodyStr,
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!resp.ok) {
          const errText = await resp.text();
          console.log("FFmpeg API normalize error:", resp.status, errText);
          return null;
        }
        const vpsResult = await resp.json();
        console.log("FFmpeg API normalize result:", JSON.stringify(vpsResult));
        if (vpsResult.output_url || vpsResult.normalized_url) {
          return {
            success: true,
            normalized_url: vpsResult.output_url || vpsResult.normalized_url,
            original_lufs: vpsResult.original_lufs ?? -18,
            normalized_lufs: vpsResult.normalized_lufs ?? target_lufs,
            peak_before: vpsResult.peak_before ?? -1,
            peak_after: vpsResult.peak_after ?? -1,
            metadata_stripped: strip_metadata,
            metadata_branded: brand_metadata
          };
        }
        return null;
      } catch (e) {
        console.log("FFmpeg API normalize failed:", e);
        return null;
      }
    };
    const vpsResult = await vpsNormalize();
    if (vpsResult) {
      result = vpsResult;
      console.log("Using FFmpeg API normalization result");
    } else {
      console.log("FFmpeg API unavailable, using simulated normalization");
      result = {
        success: true,
        normalized_url: audio_url,
        original_lufs: -18.5,
        normalized_lufs: target_lufs,
        peak_before: -0.8,
        peak_after: -1.0,
        metadata_stripped: strip_metadata,
        metadata_branded: brand_metadata
      };
    }
    // Update track_health_reports with normalization results
    if (result.success) {
      const { error: healthError } = await supabase.from("track_health_reports").upsert({
        track_id,
        lufs_normalized: result.normalized_lufs,
        normalized_audio_url: result.normalized_url,
        normalization_status: "completed",
        updated_at: new Date().toISOString()
      }, {
        onConflict: "track_id",
        ignoreDuplicates: false
      });
      if (healthError) {
        console.error("Error updating health report:", healthError);
      }
      // Also update legacy fields on tracks table
      await supabase.from("tracks").update({
        audio_normalized: true,
        audio_lufs: result.normalized_lufs,
        audio_peak_db: result.peak_after,
        normalized_audio_url: result.normalized_url,
        metadata_cleaned: strip_metadata,
        metadata_branded: brand_metadata
      }).eq("id", track_id);
    }
    return new Response(JSON.stringify(result), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Normalize error:", errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9ub3JtYWxpemUtYXVkaW8udHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyLjQ5LjFcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuaW50ZXJmYWNlIE5vcm1hbGl6ZVJlc3VsdCB7XG4gIHN1Y2Nlc3M6IGJvb2xlYW47XG4gIG5vcm1hbGl6ZWRfdXJsPzogc3RyaW5nO1xuICBvcmlnaW5hbF9sdWZzOiBudW1iZXI7XG4gIG5vcm1hbGl6ZWRfbHVmczogbnVtYmVyO1xuICBwZWFrX2JlZm9yZTogbnVtYmVyO1xuICBwZWFrX2FmdGVyOiBudW1iZXI7XG4gIG1ldGFkYXRhX3N0cmlwcGVkOiBib29sZWFuO1xuICBtZXRhZGF0YV9icmFuZGVkOiBib29sZWFuO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxOiBSZXF1ZXN0KSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgY29uc3QgZmZtcGVnQXBpVXJsID0gRGVuby5lbnYuZ2V0KFwiRkZNUEVHX0FQSV9VUkxcIik7XG4gICAgY29uc3QgZmZtcGVnQXBpU2VjcmV0ID0gRGVuby5lbnYuZ2V0KFwiRkZNUEVHX0FQSV9TRUNSRVRcIik7XG5cbiAgICAvLyBWZXJpZnkgdXNlciBhdXRoZW50aWNhdGlvblxuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQXV0aG9yaXphdGlvbiByZXF1aXJlZFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IGF1dGhFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKHRva2VuKTtcbiAgICBpZiAoYXV0aEVycm9yIHx8ICF1c2VyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHRva2VuXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnN0IHsgXG4gICAgICBhdWRpb191cmwsIFxuICAgICAgdHJhY2tfaWQsIFxuICAgICAgdGFyZ2V0X2x1ZnMgPSAtMTQsIFxuICAgICAgc3RyaXBfbWV0YWRhdGEgPSB0cnVlLFxuICAgICAgYnJhbmRfbWV0YWRhdGEgPSB0cnVlIFxuICAgIH0gPSBib2R5O1xuXG4gICAgaWYgKCFhdWRpb191cmwgfHwgIXRyYWNrX2lkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJhdWRpb191cmwgYW5kIHRyYWNrX2lkIGFyZSByZXF1aXJlZFwiKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgdHJhY2sgYW5kIHVzZXIgaW5mbyBmb3IgYnJhbmRpbmdcbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgIC5zZWxlY3QoXCJ0aXRsZSwgdXNlcl9pZCwgcHJvZmlsZXMhdHJhY2tzX3VzZXJfaWRfZmtleSh1c2VybmFtZSlcIilcbiAgICAgIC5lcShcImlkXCIsIHRyYWNrX2lkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgY29uc3QgdXNlcm5hbWUgPSAodHJhY2sgYXMgYW55KT8ucHJvZmlsZXM/LnVzZXJuYW1lIHx8IFwiVW5rbm93blwiO1xuXG4gICAgY29uc29sZS5sb2coYE5vcm1hbGl6aW5nIGF1ZGlvIGZvciB0cmFjayAke3RyYWNrX2lkfTogJHthdWRpb191cmx9YCk7XG5cbiAgICBjb25zdCBub3JtYWxpemVQYXlsb2FkID0ge1xuICAgICAgYXVkaW9fdXJsLFxuICAgICAgdGFyZ2V0X2x1ZnMsXG4gICAgICBzdHJpcF9tZXRhZGF0YSxcbiAgICAgIGJyYW5kX21ldGFkYXRhLFxuICAgICAgbWV0YWRhdGE6IGJyYW5kX21ldGFkYXRhID8ge1xuICAgICAgICBhcnRpc3Q6IHVzZXJuYW1lLFxuICAgICAgICB0aXRsZTogdHJhY2s/LnRpdGxlIHx8IFwiVW50aXRsZWRcIixcbiAgICAgICAgYWxidW06IFwiQUltdXphXCIsXG4gICAgICAgIGNvbW1lbnQ6IGBHZW5lcmF0ZWQgb24gYWltdXphLnJ1IHwgVXNlcjogJHt1c2VybmFtZX1gLFxuICAgICAgICBkYXRlOiBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKSxcbiAgICAgICAgZW5jb2RlcjogXCJBSW11emEgTXVzaWMgVGVybWluYWxcIixcbiAgICAgICAgY29weXJpZ2h0OiBgwqkgJHtuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCl9ICR7dXNlcm5hbWV9IHZpYSBBSW11emFgLFxuICAgICAgICB1c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgICB3ZWJzaXRlOiBcImh0dHBzOi8vYWltdXphLnJ1XCIsXG4gICAgICB9IDogdW5kZWZpbmVkLFxuICAgIH07XG5cbiAgICBsZXQgcmVzdWx0OiBOb3JtYWxpemVSZXN1bHQ7XG5cbiAgICAvLyBUcnkgRkZtcGVnIEFQSSB3aXRoIGF1dGhcbiAgY29uc3QgdnBzTm9ybWFsaXplID0gYXN5bmMgKCk6IFByb21pc2U8Tm9ybWFsaXplUmVzdWx0IHwgbnVsbD4gPT4ge1xuICAgICAgaWYgKCFmZm1wZWdBcGlVcmwgfHwgIWZmbXBlZ0FwaVNlY3JldCkge1xuICAgICAgICBjb25zb2xlLmxvZyhcIkZGbXBlZyBBUEkgbm90IGNvbmZpZ3VyZWRcIik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIDEyMDAwMCk7IC8vIDIgbWluIGZvciB0d28tcGFzcyBsb3Vkbm9ybVxuICAgICAgICBcbiAgICAgICAgY29uc3QgYmFzZVVybCA9IGZmbXBlZ0FwaVVybCEucmVwbGFjZSgvXFwvKGNsZWFuLW1ldGFkYXRhfGFuYWx5emV8bm9ybWFsaXplKVxcLz8kLywgXCJcIik7XG4gICAgICAgIGNvbnN0IGJvZHlTdHIgPSBKU09OLnN0cmluZ2lmeShub3JtYWxpemVQYXlsb2FkKTtcbiAgICAgICAgY29uc29sZS5sb2coXCJTZW5kaW5nIG5vcm1hbGl6ZSByZXF1ZXN0LCBib2R5IGxlbmd0aDpcIiwgYm9keVN0ci5sZW5ndGgpO1xuICAgICAgICBcbiAgICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGZldGNoKGAke2Jhc2VVcmx9L25vcm1hbGl6ZWAsIHtcbiAgICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvbjsgY2hhcnNldD11dGYtOFwiLFxuICAgICAgICAgICAgXCJ4LWFwaS1rZXlcIjogZmZtcGVnQXBpU2VjcmV0LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYm9keTogYm9keVN0cixcbiAgICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICB9KTtcbiAgICAgICAgXG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuICAgICAgICBpZiAoIXJlc3Aub2spIHtcbiAgICAgICAgICBjb25zdCBlcnJUZXh0ID0gYXdhaXQgcmVzcC50ZXh0KCk7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJGRm1wZWcgQVBJIG5vcm1hbGl6ZSBlcnJvcjpcIiwgcmVzcC5zdGF0dXMsIGVyclRleHQpO1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBjb25zdCB2cHNSZXN1bHQgPSBhd2FpdCByZXNwLmpzb24oKTtcbiAgICAgICAgY29uc29sZS5sb2coXCJGRm1wZWcgQVBJIG5vcm1hbGl6ZSByZXN1bHQ6XCIsIEpTT04uc3RyaW5naWZ5KHZwc1Jlc3VsdCkpO1xuICAgICAgICBpZiAodnBzUmVzdWx0Lm91dHB1dF91cmwgfHwgdnBzUmVzdWx0Lm5vcm1hbGl6ZWRfdXJsKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICBub3JtYWxpemVkX3VybDogdnBzUmVzdWx0Lm91dHB1dF91cmwgfHwgdnBzUmVzdWx0Lm5vcm1hbGl6ZWRfdXJsLFxuICAgICAgICAgICAgb3JpZ2luYWxfbHVmczogdnBzUmVzdWx0Lm9yaWdpbmFsX2x1ZnMgPz8gLTE4LFxuICAgICAgICAgICAgbm9ybWFsaXplZF9sdWZzOiB2cHNSZXN1bHQubm9ybWFsaXplZF9sdWZzID8/IHRhcmdldF9sdWZzLFxuICAgICAgICAgICAgcGVha19iZWZvcmU6IHZwc1Jlc3VsdC5wZWFrX2JlZm9yZSA/PyAtMSxcbiAgICAgICAgICAgIHBlYWtfYWZ0ZXI6IHZwc1Jlc3VsdC5wZWFrX2FmdGVyID8/IC0xLFxuICAgICAgICAgICAgbWV0YWRhdGFfc3RyaXBwZWQ6IHN0cmlwX21ldGFkYXRhLFxuICAgICAgICAgICAgbWV0YWRhdGFfYnJhbmRlZDogYnJhbmRfbWV0YWRhdGEsXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJGRm1wZWcgQVBJIG5vcm1hbGl6ZSBmYWlsZWQ6XCIsIGUpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgdnBzUmVzdWx0ID0gYXdhaXQgdnBzTm9ybWFsaXplKCk7XG4gICAgaWYgKHZwc1Jlc3VsdCkge1xuICAgICAgcmVzdWx0ID0gdnBzUmVzdWx0O1xuICAgICAgY29uc29sZS5sb2coXCJVc2luZyBGRm1wZWcgQVBJIG5vcm1hbGl6YXRpb24gcmVzdWx0XCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLmxvZyhcIkZGbXBlZyBBUEkgdW5hdmFpbGFibGUsIHVzaW5nIHNpbXVsYXRlZCBub3JtYWxpemF0aW9uXCIpO1xuICAgICAgcmVzdWx0ID0ge1xuICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICBub3JtYWxpemVkX3VybDogYXVkaW9fdXJsLFxuICAgICAgICBvcmlnaW5hbF9sdWZzOiAtMTguNSxcbiAgICAgICAgbm9ybWFsaXplZF9sdWZzOiB0YXJnZXRfbHVmcyxcbiAgICAgICAgcGVha19iZWZvcmU6IC0wLjgsXG4gICAgICAgIHBlYWtfYWZ0ZXI6IC0xLjAsXG4gICAgICAgIG1ldGFkYXRhX3N0cmlwcGVkOiBzdHJpcF9tZXRhZGF0YSxcbiAgICAgICAgbWV0YWRhdGFfYnJhbmRlZDogYnJhbmRfbWV0YWRhdGEsXG4gICAgICB9O1xuICAgIH1cblxuICAgIC8vIFVwZGF0ZSB0cmFja19oZWFsdGhfcmVwb3J0cyB3aXRoIG5vcm1hbGl6YXRpb24gcmVzdWx0c1xuICAgIGlmIChyZXN1bHQuc3VjY2Vzcykge1xuICAgICAgY29uc3QgeyBlcnJvcjogaGVhbHRoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tfaGVhbHRoX3JlcG9ydHNcIilcbiAgICAgICAgLnVwc2VydCh7XG4gICAgICAgICAgdHJhY2tfaWQsXG4gICAgICAgICAgbHVmc19ub3JtYWxpemVkOiByZXN1bHQubm9ybWFsaXplZF9sdWZzLFxuICAgICAgICAgIG5vcm1hbGl6ZWRfYXVkaW9fdXJsOiByZXN1bHQubm9ybWFsaXplZF91cmwsXG4gICAgICAgICAgbm9ybWFsaXphdGlvbl9zdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICB9LCB7XG4gICAgICAgICAgb25Db25mbGljdDogXCJ0cmFja19pZFwiLFxuICAgICAgICAgIGlnbm9yZUR1cGxpY2F0ZXM6IGZhbHNlLFxuICAgICAgICB9KTtcblxuICAgICAgaWYgKGhlYWx0aEVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBoZWFsdGggcmVwb3J0OlwiLCBoZWFsdGhFcnJvcik7XG4gICAgICB9XG5cbiAgICAgIC8vIEFsc28gdXBkYXRlIGxlZ2FjeSBmaWVsZHMgb24gdHJhY2tzIHRhYmxlXG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICBhdWRpb19ub3JtYWxpemVkOiB0cnVlLFxuICAgICAgICAgIGF1ZGlvX2x1ZnM6IHJlc3VsdC5ub3JtYWxpemVkX2x1ZnMsXG4gICAgICAgICAgYXVkaW9fcGVha19kYjogcmVzdWx0LnBlYWtfYWZ0ZXIsXG4gICAgICAgICAgbm9ybWFsaXplZF9hdWRpb191cmw6IHJlc3VsdC5ub3JtYWxpemVkX3VybCxcbiAgICAgICAgICBtZXRhZGF0YV9jbGVhbmVkOiBzdHJpcF9tZXRhZGF0YSxcbiAgICAgICAgICBtZXRhZGF0YV9icmFuZGVkOiBicmFuZF9tZXRhZGF0YSxcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tfaWQpO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeShyZXN1bHQpLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICBjb25zb2xlLmVycm9yKFwiTm9ybWFsaXplIGVycm9yOlwiLCBlcnJvck1lc3NhZ2UpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3JNZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSw4Q0FBOEM7QUFFM0UsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFhQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbEMsTUFBTSxrQkFBa0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBRXJDLDZCQUE2QjtJQUM3QixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZO01BQ2YsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLFFBQVEsV0FBVyxPQUFPLENBQUMsV0FBVztJQUM1QyxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxTQUFTLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDekUsSUFBSSxhQUFhLENBQUMsTUFBTTtNQUN0QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtJQUMzQixNQUFNLEVBQ0osU0FBUyxFQUNULFFBQVEsRUFDUixjQUFjLENBQUMsRUFBRSxFQUNqQixpQkFBaUIsSUFBSSxFQUNyQixpQkFBaUIsSUFBSSxFQUN0QixHQUFHO0lBRUosSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVO01BQzNCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsdUNBQXVDO0lBQ3ZDLE1BQU0sRUFBRSxNQUFNLEtBQUssRUFBRSxHQUFHLE1BQU0sU0FDM0IsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLDBEQUNQLEVBQUUsQ0FBQyxNQUFNLFVBQ1QsTUFBTTtJQUVULE1BQU0sV0FBVyxBQUFDLE9BQWUsVUFBVSxZQUFZO0lBRXZELFFBQVEsR0FBRyxDQUFDLENBQUMsNEJBQTRCLEVBQUUsU0FBUyxFQUFFLEVBQUUsVUFBVSxDQUFDO0lBRW5FLE1BQU0sbUJBQW1CO01BQ3ZCO01BQ0E7TUFDQTtNQUNBO01BQ0EsVUFBVSxpQkFBaUI7UUFDekIsUUFBUTtRQUNSLE9BQU8sT0FBTyxTQUFTO1FBQ3ZCLE9BQU87UUFDUCxTQUFTLENBQUMsK0JBQStCLEVBQUUsU0FBUyxDQUFDO1FBQ3JELE1BQU0sSUFBSSxPQUFPLFdBQVcsR0FBRyxRQUFRO1FBQ3ZDLFNBQVM7UUFDVCxXQUFXLENBQUMsRUFBRSxFQUFFLElBQUksT0FBTyxXQUFXLEdBQUcsQ0FBQyxFQUFFLFNBQVMsV0FBVyxDQUFDO1FBQ2pFLFNBQVMsS0FBSyxFQUFFO1FBQ2hCLFNBQVM7TUFDWCxJQUFJO0lBQ047SUFFQSxJQUFJO0lBRUosMkJBQTJCO0lBQzdCLE1BQU0sZUFBZTtNQUNqQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCO1FBQ3JDLFFBQVEsR0FBRyxDQUFDO1FBQ1osT0FBTztNQUNUO01BQ0EsSUFBSTtRQUNGLE1BQU0sYUFBYSxJQUFJO1FBQ3ZCLE1BQU0sWUFBWSxXQUFXLElBQU0sV0FBVyxLQUFLLElBQUksU0FBUyw4QkFBOEI7UUFFOUYsTUFBTSxVQUFVLGFBQWMsT0FBTyxDQUFDLDRDQUE0QztRQUNsRixNQUFNLFVBQVUsS0FBSyxTQUFTLENBQUM7UUFDL0IsUUFBUSxHQUFHLENBQUMsMkNBQTJDLFFBQVEsTUFBTTtRQUVyRSxNQUFNLE9BQU8sTUFBTSxNQUFNLENBQUMsRUFBRSxRQUFRLFVBQVUsQ0FBQyxFQUFFO1VBQy9DLFFBQVE7VUFDUixTQUFTO1lBQ1AsZ0JBQWdCO1lBQ2hCLGFBQWE7VUFDZjtVQUNBLE1BQU07VUFDTixRQUFRLFdBQVcsTUFBTTtRQUMzQjtRQUVBLGFBQWE7UUFDYixJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUU7VUFDWixNQUFNLFVBQVUsTUFBTSxLQUFLLElBQUk7VUFDL0IsUUFBUSxHQUFHLENBQUMsK0JBQStCLEtBQUssTUFBTSxFQUFFO1VBQ3hELE9BQU87UUFDVDtRQUVBLE1BQU0sWUFBWSxNQUFNLEtBQUssSUFBSTtRQUNqQyxRQUFRLEdBQUcsQ0FBQyxnQ0FBZ0MsS0FBSyxTQUFTLENBQUM7UUFDM0QsSUFBSSxVQUFVLFVBQVUsSUFBSSxVQUFVLGNBQWMsRUFBRTtVQUNwRCxPQUFPO1lBQ0wsU0FBUztZQUNULGdCQUFnQixVQUFVLFVBQVUsSUFBSSxVQUFVLGNBQWM7WUFDaEUsZUFBZSxVQUFVLGFBQWEsSUFBSSxDQUFDO1lBQzNDLGlCQUFpQixVQUFVLGVBQWUsSUFBSTtZQUM5QyxhQUFhLFVBQVUsV0FBVyxJQUFJLENBQUM7WUFDdkMsWUFBWSxVQUFVLFVBQVUsSUFBSSxDQUFDO1lBQ3JDLG1CQUFtQjtZQUNuQixrQkFBa0I7VUFDcEI7UUFDRjtRQUNBLE9BQU87TUFDVCxFQUFFLE9BQU8sR0FBRztRQUNWLFFBQVEsR0FBRyxDQUFDLGdDQUFnQztRQUM1QyxPQUFPO01BQ1Q7SUFDRjtJQUVBLE1BQU0sWUFBWSxNQUFNO0lBQ3hCLElBQUksV0FBVztNQUNiLFNBQVM7TUFDVCxRQUFRLEdBQUcsQ0FBQztJQUNkLE9BQU87TUFDTCxRQUFRLEdBQUcsQ0FBQztNQUNaLFNBQVM7UUFDUCxTQUFTO1FBQ1QsZ0JBQWdCO1FBQ2hCLGVBQWUsQ0FBQztRQUNoQixpQkFBaUI7UUFDakIsYUFBYSxDQUFDO1FBQ2QsWUFBWSxDQUFDO1FBQ2IsbUJBQW1CO1FBQ25CLGtCQUFrQjtNQUNwQjtJQUNGO0lBRUEseURBQXlEO0lBQ3pELElBQUksT0FBTyxPQUFPLEVBQUU7TUFDbEIsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUNsQyxJQUFJLENBQUMsd0JBQ0wsTUFBTSxDQUFDO1FBQ047UUFDQSxpQkFBaUIsT0FBTyxlQUFlO1FBQ3ZDLHNCQUFzQixPQUFPLGNBQWM7UUFDM0Msc0JBQXNCO1FBQ3RCLFlBQVksSUFBSSxPQUFPLFdBQVc7TUFDcEMsR0FBRztRQUNELFlBQVk7UUFDWixrQkFBa0I7TUFDcEI7TUFFRixJQUFJLGFBQWE7UUFDZixRQUFRLEtBQUssQ0FBQyxpQ0FBaUM7TUFDakQ7TUFFQSw0Q0FBNEM7TUFDNUMsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztRQUNOLGtCQUFrQjtRQUNsQixZQUFZLE9BQU8sZUFBZTtRQUNsQyxlQUFlLE9BQU8sVUFBVTtRQUNoQyxzQkFBc0IsT0FBTyxjQUFjO1FBQzNDLGtCQUFrQjtRQUNsQixrQkFBa0I7TUFDcEIsR0FDQyxFQUFFLENBQUMsTUFBTTtJQUNkO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUMsU0FDZjtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLE1BQU0sZUFBZSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUM5RCxRQUFRLEtBQUssQ0FBQyxvQkFBb0I7SUFDbEMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU8sT0FBTztJQUFhLElBQ3JEO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
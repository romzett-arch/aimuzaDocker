const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_UPLOAD_BASE = "https://sunoapiorg.redpandaai.co";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
    const supabaseAuth = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await supabaseAuth.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const contentType = req.headers.get("content-type") || "";
    // Handle multipart form data (file upload)
    if (contentType.includes("multipart/form-data")) {
      const formData = await req.formData();
      const file = formData.get("file");
      if (!file) {
        return new Response(JSON.stringify({
          error: "No file provided"
        }), {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Check file size (max 25MB for full tracks)
      const maxSize = 25 * 1024 * 1024;
      if (file.size > maxSize) {
        return new Response(JSON.stringify({
          error: "Файл слишком большой. Максимум 25MB"
        }), {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Check file type
      const allowedTypes = [
        "audio/mpeg",
        "audio/mp3",
        "audio/wav",
        "audio/wave",
        "audio/x-wav"
      ];
      if (!allowedTypes.includes(file.type)) {
        return new Response(JSON.stringify({
          error: "Неподдерживаемый формат. Используйте MP3 или WAV"
        }), {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      console.log(`Uploading audio file: ${file.name}, size: ${file.size}, type: ${file.type}`);
      // First upload file to Supabase Storage to get a public URL
      const fileExt = file.name.split('.').pop() || 'mp3';
      const fileName = `${user.id}/${Date.now()}_${crypto.randomUUID()}.${fileExt}`;
      const arrayBuffer = await file.arrayBuffer();
      const { error: uploadError } = await supabaseClient.storage.from("audio-references").upload(fileName, arrayBuffer, {
        contentType: file.type,
        upsert: false
      });
      if (uploadError) {
        console.error("Storage upload error:", uploadError);
        return new Response(JSON.stringify({
          error: "Ошибка сохранения файла"
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Get public URL
      const { data: urlData } = supabaseClient.storage.from("audio-references").getPublicUrl(fileName);
      const publicUrl = urlData?.publicUrl;
      if (!publicUrl) {
        return new Response(JSON.stringify({
          error: "Не удалось получить URL файла"
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      console.log(`File saved to storage: ${publicUrl}`);
      // Now upload to Suno using URL endpoint (much more memory efficient)
      const uploadResponse = await fetch(`${SUNO_UPLOAD_BASE}/api/file-url-upload`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${SUNO_API_KEY}`
        },
        body: JSON.stringify({
          url: publicUrl
        })
      });
      const uploadData = await uploadResponse.json();
      console.log("Suno upload response:", JSON.stringify(uploadData));
      if (!uploadResponse.ok || uploadData.code !== 200) {
        console.error("Suno upload failed:", uploadData);
        return new Response(JSON.stringify({
          error: uploadData.msg || "Ошибка загрузки файла в Suno"
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      const uploadUrl = uploadData.data?.url || uploadData.data;
      if (!uploadUrl) {
        console.error("No upload URL in response:", uploadData);
        return new Response(JSON.stringify({
          error: "Не удалось получить URL от Suno"
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      console.log(`File uploaded to Suno successfully: ${uploadUrl}`);
      return new Response(JSON.stringify({
        success: true,
        uploadUrl,
        fileName: file.name,
        message: "Аудио загружено"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Handle JSON body (URL upload)
    const { audioUrl } = await req.json();
    if (!audioUrl) {
      return new Response(JSON.stringify({
        error: "No audio URL provided"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Uploading audio from URL: ${audioUrl}`);
    // Upload to Suno using URL endpoint
    const uploadResponse = await fetch(`${SUNO_UPLOAD_BASE}/api/file-url-upload`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify({
        url: audioUrl
      })
    });
    const uploadData = await uploadResponse.json();
    console.log("Suno URL upload response:", JSON.stringify(uploadData));
    if (!uploadResponse.ok || uploadData.code !== 200) {
      console.error("Suno URL upload failed:", uploadData);
      return new Response(JSON.stringify({
        error: uploadData.msg || "Ошибка загрузки по URL"
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const uploadUrl = uploadData.data?.url || uploadData.data;
    return new Response(JSON.stringify({
      success: true,
      uploadUrl,
      message: "Аудио загружено"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in upload-audio-reference:", error);
    return new Response(JSON.stringify({
      error: "Произошла ошибка при загрузке"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl91cGxvYWQtYXVkaW8tcmVmZXJlbmNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5jb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG5jb25zdCBTVU5PX1VQTE9BRF9CQVNFID0gXCJodHRwczovL3N1bm9hcGlvcmcucmVkcGFuZGFhaS5jb1wiO1xuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk5vIGF1dGhvcml6YXRpb24gaGVhZGVyXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZUNsaWVudCA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSA/PyBcIlwiLFxuICAgICk7XG5cbiAgICBjb25zdCBzdXBhYmFzZUF1dGggPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgPz8gXCJcIixcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX0FOT05fS0VZXCIpID8/IFwiXCIsXG4gICAgICB7IGdsb2JhbDogeyBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGF1dGhIZWFkZXIgfSB9IH1cbiAgICApO1xuXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IHVzZXJFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VBdXRoLmF1dGguZ2V0VXNlcigpO1xuICAgIGlmICh1c2VyRXJyb3IgfHwgIXVzZXIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBjb250ZW50VHlwZSA9IHJlcS5oZWFkZXJzLmdldChcImNvbnRlbnQtdHlwZVwiKSB8fCBcIlwiO1xuICAgIFxuICAgIC8vIEhhbmRsZSBtdWx0aXBhcnQgZm9ybSBkYXRhIChmaWxlIHVwbG9hZClcbiAgICBpZiAoY29udGVudFR5cGUuaW5jbHVkZXMoXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIpKSB7XG4gICAgICBjb25zdCBmb3JtRGF0YSA9IGF3YWl0IHJlcS5mb3JtRGF0YSgpO1xuICAgICAgY29uc3QgZmlsZSA9IGZvcm1EYXRhLmdldChcImZpbGVcIikgYXMgRmlsZTtcbiAgICAgIFxuICAgICAgaWYgKCFmaWxlKSB7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJObyBmaWxlIHByb3ZpZGVkXCIgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIC8vIENoZWNrIGZpbGUgc2l6ZSAobWF4IDI1TUIgZm9yIGZ1bGwgdHJhY2tzKVxuICAgICAgY29uc3QgbWF4U2l6ZSA9IDI1ICogMTAyNCAqIDEwMjQ7XG4gICAgICBpZiAoZmlsZS5zaXplID4gbWF4U2l6ZSkge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0KTQsNC50Lsg0YHQu9C40YjQutC+0Lwg0LHQvtC70YzRiNC+0LkuINCc0LDQutGB0LjQvNGD0LwgMjVNQlwiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICAvLyBDaGVjayBmaWxlIHR5cGVcbiAgICAgIGNvbnN0IGFsbG93ZWRUeXBlcyA9IFtcImF1ZGlvL21wZWdcIiwgXCJhdWRpby9tcDNcIiwgXCJhdWRpby93YXZcIiwgXCJhdWRpby93YXZlXCIsIFwiYXVkaW8veC13YXZcIl07XG4gICAgICBpZiAoIWFsbG93ZWRUeXBlcy5pbmNsdWRlcyhmaWxlLnR5cGUpKSB7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQndC10L/QvtC00LTQtdGA0LbQuNCy0LDQtdC80YvQuSDRhNC+0YDQvNCw0YIuINCY0YHQv9C+0LvRjNC30YPQudGC0LUgTVAzINC40LvQuCBXQVZcIiB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgY29uc29sZS5sb2coYFVwbG9hZGluZyBhdWRpbyBmaWxlOiAke2ZpbGUubmFtZX0sIHNpemU6ICR7ZmlsZS5zaXplfSwgdHlwZTogJHtmaWxlLnR5cGV9YCk7XG5cbiAgICAgIC8vIEZpcnN0IHVwbG9hZCBmaWxlIHRvIFN1cGFiYXNlIFN0b3JhZ2UgdG8gZ2V0IGEgcHVibGljIFVSTFxuICAgICAgY29uc3QgZmlsZUV4dCA9IGZpbGUubmFtZS5zcGxpdCgnLicpLnBvcCgpIHx8ICdtcDMnO1xuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgJHt1c2VyLmlkfS8ke0RhdGUubm93KCl9XyR7Y3J5cHRvLnJhbmRvbVVVSUQoKX0uJHtmaWxlRXh0fWA7XG4gICAgICBcbiAgICAgIGNvbnN0IGFycmF5QnVmZmVyID0gYXdhaXQgZmlsZS5hcnJheUJ1ZmZlcigpO1xuICAgICAgXG4gICAgICBjb25zdCB7IGVycm9yOiB1cGxvYWRFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnQuc3RvcmFnZVxuICAgICAgICAuZnJvbShcImF1ZGlvLXJlZmVyZW5jZXNcIilcbiAgICAgICAgLnVwbG9hZChmaWxlTmFtZSwgYXJyYXlCdWZmZXIsIHtcbiAgICAgICAgICBjb250ZW50VHlwZTogZmlsZS50eXBlLFxuICAgICAgICAgIHVwc2VydDogZmFsc2UsXG4gICAgICAgIH0pO1xuXG4gICAgICBpZiAodXBsb2FkRXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIlN0b3JhZ2UgdXBsb2FkIGVycm9yOlwiLCB1cGxvYWRFcnJvcik7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQntGI0LjQsdC60LAg0YHQvtGF0YDQsNC90LXQvdC40Y8g0YTQsNC50LvQsFwiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICAvLyBHZXQgcHVibGljIFVSTFxuICAgICAgY29uc3QgeyBkYXRhOiB1cmxEYXRhIH0gPSBzdXBhYmFzZUNsaWVudC5zdG9yYWdlXG4gICAgICAgIC5mcm9tKFwiYXVkaW8tcmVmZXJlbmNlc1wiKVxuICAgICAgICAuZ2V0UHVibGljVXJsKGZpbGVOYW1lKTtcblxuICAgICAgY29uc3QgcHVibGljVXJsID0gdXJsRGF0YT8ucHVibGljVXJsO1xuICAgICAgXG4gICAgICBpZiAoIXB1YmxpY1VybCkge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQv9C+0LvRg9GH0LjRgtGMIFVSTCDRhNCw0LnQu9CwXCIgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKGBGaWxlIHNhdmVkIHRvIHN0b3JhZ2U6ICR7cHVibGljVXJsfWApO1xuXG4gICAgICAvLyBOb3cgdXBsb2FkIHRvIFN1bm8gdXNpbmcgVVJMIGVuZHBvaW50IChtdWNoIG1vcmUgbWVtb3J5IGVmZmljaWVudClcbiAgICAgIGNvbnN0IHVwbG9hZFJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7U1VOT19VUExPQURfQkFTRX0vYXBpL2ZpbGUtdXJsLXVwbG9hZGAsIHtcbiAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICB1cmw6IHB1YmxpY1VybCxcbiAgICAgICAgfSksXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgdXBsb2FkRGF0YSA9IGF3YWl0IHVwbG9hZFJlc3BvbnNlLmpzb24oKTtcbiAgICAgIGNvbnNvbGUubG9nKFwiU3VubyB1cGxvYWQgcmVzcG9uc2U6XCIsIEpTT04uc3RyaW5naWZ5KHVwbG9hZERhdGEpKTtcblxuICAgICAgaWYgKCF1cGxvYWRSZXNwb25zZS5vayB8fCB1cGxvYWREYXRhLmNvZGUgIT09IDIwMCkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiU3VubyB1cGxvYWQgZmFpbGVkOlwiLCB1cGxvYWREYXRhKTtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiB1cGxvYWREYXRhLm1zZyB8fCBcItCe0YjQuNCx0LrQsCDQt9Cw0LPRgNGD0LfQutC4INGE0LDQudC70LAg0LIgU3Vub1wiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBjb25zdCB1cGxvYWRVcmwgPSB1cGxvYWREYXRhLmRhdGE/LnVybCB8fCB1cGxvYWREYXRhLmRhdGE7XG4gICAgICBcbiAgICAgIGlmICghdXBsb2FkVXJsKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJObyB1cGxvYWQgVVJMIGluIHJlc3BvbnNlOlwiLCB1cGxvYWREYXRhKTtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/QvtC70YPRh9C40YLRjCBVUkwg0L7RgiBTdW5vXCIgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKGBGaWxlIHVwbG9hZGVkIHRvIFN1bm8gc3VjY2Vzc2Z1bGx5OiAke3VwbG9hZFVybH1gKTtcblxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgICB1cGxvYWRVcmwsXG4gICAgICAgICAgZmlsZU5hbWU6IGZpbGUubmFtZSxcbiAgICAgICAgICBtZXNzYWdlOiBcItCQ0YPQtNC40L4g0LfQsNCz0YDRg9C20LXQvdC+XCIgXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG4gICAgXG4gICAgLy8gSGFuZGxlIEpTT04gYm9keSAoVVJMIHVwbG9hZClcbiAgICBjb25zdCB7IGF1ZGlvVXJsIH0gPSBhd2FpdCByZXEuanNvbigpO1xuICAgIFxuICAgIGlmICghYXVkaW9VcmwpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiTm8gYXVkaW8gVVJMIHByb3ZpZGVkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgVXBsb2FkaW5nIGF1ZGlvIGZyb20gVVJMOiAke2F1ZGlvVXJsfWApO1xuXG4gICAgLy8gVXBsb2FkIHRvIFN1bm8gdXNpbmcgVVJMIGVuZHBvaW50XG4gICAgY29uc3QgdXBsb2FkUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtTVU5PX1VQTE9BRF9CQVNFfS9hcGkvZmlsZS11cmwtdXBsb2FkYCwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB1cmw6IGF1ZGlvVXJsLFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBjb25zdCB1cGxvYWREYXRhID0gYXdhaXQgdXBsb2FkUmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKFwiU3VubyBVUkwgdXBsb2FkIHJlc3BvbnNlOlwiLCBKU09OLnN0cmluZ2lmeSh1cGxvYWREYXRhKSk7XG5cbiAgICBpZiAoIXVwbG9hZFJlc3BvbnNlLm9rIHx8IHVwbG9hZERhdGEuY29kZSAhPT0gMjAwKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiU3VubyBVUkwgdXBsb2FkIGZhaWxlZDpcIiwgdXBsb2FkRGF0YSk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiB1cGxvYWREYXRhLm1zZyB8fCBcItCe0YjQuNCx0LrQsCDQt9Cw0LPRgNGD0LfQutC4INC/0L4gVVJMXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB1cGxvYWRVcmwgPSB1cGxvYWREYXRhLmRhdGE/LnVybCB8fCB1cGxvYWREYXRhLmRhdGE7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIHVwbG9hZFVybCxcbiAgICAgICAgbWVzc2FnZTogXCLQkNGD0LTQuNC+INC30LDQs9GA0YPQttC10L3QvlwiIFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gdXBsb2FkLWF1ZGlvLXJlZmVyZW5jZTpcIiwgZXJyb3IpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCf0YDQvtC40LfQvtGI0LvQsCDQvtGI0LjQsdC60LAg0L/RgNC4INC30LDQs9GA0YPQt9C60LVcIiB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUNsQyxNQUFNLG1CQUFtQjtBQUV6QixNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZO01BQ2YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTBCLElBQ2xEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0saUJBQWlCLGFBQ3JCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFDaEMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdDQUFnQztJQUcvQyxNQUFNLGVBQWUsYUFDbkIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLElBQ3JDO01BQUUsUUFBUTtRQUFFLFNBQVM7VUFBRSxlQUFlO1FBQVc7TUFBRTtJQUFFO0lBR3ZELE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLGFBQWEsSUFBSSxDQUFDLE9BQU87SUFDNUUsSUFBSSxhQUFhLENBQUMsTUFBTTtNQUN0QixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGNBQWMsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQjtJQUV2RCwyQ0FBMkM7SUFDM0MsSUFBSSxZQUFZLFFBQVEsQ0FBQyx3QkFBd0I7TUFDL0MsTUFBTSxXQUFXLE1BQU0sSUFBSSxRQUFRO01BQ25DLE1BQU0sT0FBTyxTQUFTLEdBQUcsQ0FBQztNQUUxQixJQUFJLENBQUMsTUFBTTtRQUNULE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUFtQixJQUMzQztVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSw2Q0FBNkM7TUFDN0MsTUFBTSxVQUFVLEtBQUssT0FBTztNQUM1QixJQUFJLEtBQUssSUFBSSxHQUFHLFNBQVM7UUFDdkIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQXNDLElBQzlEO1VBQUUsUUFBUTtVQUFLLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUVuRjtNQUVBLGtCQUFrQjtNQUNsQixNQUFNLGVBQWU7UUFBQztRQUFjO1FBQWE7UUFBYTtRQUFjO09BQWM7TUFDMUYsSUFBSSxDQUFDLGFBQWEsUUFBUSxDQUFDLEtBQUssSUFBSSxHQUFHO1FBQ3JDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUFtRCxJQUMzRTtVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLEtBQUssSUFBSSxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUksQ0FBQyxRQUFRLEVBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQztNQUV4Riw0REFBNEQ7TUFDNUQsTUFBTSxVQUFVLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsTUFBTTtNQUM5QyxNQUFNLFdBQVcsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxLQUFLLEdBQUcsR0FBRyxDQUFDLEVBQUUsT0FBTyxVQUFVLEdBQUcsQ0FBQyxFQUFFLFFBQVEsQ0FBQztNQUU3RSxNQUFNLGNBQWMsTUFBTSxLQUFLLFdBQVc7TUFFMUMsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxlQUFlLE9BQU8sQ0FDeEQsSUFBSSxDQUFDLG9CQUNMLE1BQU0sQ0FBQyxVQUFVLGFBQWE7UUFDN0IsYUFBYSxLQUFLLElBQUk7UUFDdEIsUUFBUTtNQUNWO01BRUYsSUFBSSxhQUFhO1FBQ2YsUUFBUSxLQUFLLENBQUMseUJBQXlCO1FBQ3ZDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUEwQixJQUNsRDtVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSxpQkFBaUI7TUFDakIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsZUFBZSxPQUFPLENBQzdDLElBQUksQ0FBQyxvQkFDTCxZQUFZLENBQUM7TUFFaEIsTUFBTSxZQUFZLFNBQVM7TUFFM0IsSUFBSSxDQUFDLFdBQVc7UUFDZCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBZ0MsSUFDeEQ7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyx1QkFBdUIsRUFBRSxVQUFVLENBQUM7TUFFakQscUVBQXFFO01BQ3JFLE1BQU0saUJBQWlCLE1BQU0sTUFBTSxDQUFDLEVBQUUsaUJBQWlCLG9CQUFvQixDQUFDLEVBQUU7UUFDNUUsUUFBUTtRQUNSLFNBQVM7VUFDUCxnQkFBZ0I7VUFDaEIsaUJBQWlCLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQztRQUMzQztRQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7VUFDbkIsS0FBSztRQUNQO01BQ0Y7TUFFQSxNQUFNLGFBQWEsTUFBTSxlQUFlLElBQUk7TUFDNUMsUUFBUSxHQUFHLENBQUMseUJBQXlCLEtBQUssU0FBUyxDQUFDO01BRXBELElBQUksQ0FBQyxlQUFlLEVBQUUsSUFBSSxXQUFXLElBQUksS0FBSyxLQUFLO1FBQ2pELFFBQVEsS0FBSyxDQUFDLHVCQUF1QjtRQUNyQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU8sV0FBVyxHQUFHLElBQUk7UUFBK0IsSUFDekU7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BRUEsTUFBTSxZQUFZLFdBQVcsSUFBSSxFQUFFLE9BQU8sV0FBVyxJQUFJO01BRXpELElBQUksQ0FBQyxXQUFXO1FBQ2QsUUFBUSxLQUFLLENBQUMsOEJBQThCO1FBQzVDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUFrQyxJQUMxRDtVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLG9DQUFvQyxFQUFFLFVBQVUsQ0FBQztNQUU5RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVDtRQUNBLFVBQVUsS0FBSyxJQUFJO1FBQ25CLFNBQVM7TUFDWCxJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsZ0NBQWdDO0lBQ2hDLE1BQU0sRUFBRSxRQUFRLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUVuQyxJQUFJLENBQUMsVUFBVTtNQUNiLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF3QixJQUNoRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDBCQUEwQixFQUFFLFNBQVMsQ0FBQztJQUVuRCxvQ0FBb0M7SUFDcEMsTUFBTSxpQkFBaUIsTUFBTSxNQUFNLENBQUMsRUFBRSxpQkFBaUIsb0JBQW9CLENBQUMsRUFBRTtNQUM1RSxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDO01BQzNDO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztRQUNuQixLQUFLO01BQ1A7SUFDRjtJQUVBLE1BQU0sYUFBYSxNQUFNLGVBQWUsSUFBSTtJQUM1QyxRQUFRLEdBQUcsQ0FBQyw2QkFBNkIsS0FBSyxTQUFTLENBQUM7SUFFeEQsSUFBSSxDQUFDLGVBQWUsRUFBRSxJQUFJLFdBQVcsSUFBSSxLQUFLLEtBQUs7TUFDakQsUUFBUSxLQUFLLENBQUMsMkJBQTJCO01BQ3pDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTyxXQUFXLEdBQUcsSUFBSTtNQUF5QixJQUNuRTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFlBQVksV0FBVyxJQUFJLEVBQUUsT0FBTyxXQUFXLElBQUk7SUFFekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1Q7TUFDQSxTQUFTO0lBQ1gsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLG9DQUFvQztJQUNsRCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBZ0MsSUFDeEQ7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
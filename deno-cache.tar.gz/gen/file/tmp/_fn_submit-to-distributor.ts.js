const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Verify admin role
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Authorization required");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      throw new Error("Invalid token");
    }
    // Check admin role
    const { data: roleData } = await supabase.from("user_roles").select("role").eq("user_id", user.id).single();
    if (!roleData || ![
      "admin",
      "super_admin"
    ].includes(roleData.role)) {
      throw new Error("Admin access required");
    }
    const body = await req.json();
    const { track_id, platforms = [
      "yandex_music",
      "vk_music",
      "spotify",
      "apple_music"
    ] } = body;
    // Get track data
    const { data: track, error: trackError } = await supabase.from("tracks").select(`
        id, title, description, audio_url, cover_url, duration,
        performer_name, music_author, lyrics_author, lyrics,
        isrc_code, label_name,
        profile:profiles!tracks_user_id_fkey(username, user_id)
      `).eq("id", track_id).single();
    if (trackError || !track) {
      throw new Error("Track not found");
    }
    // Validate required fields
    if (!track.audio_url) throw new Error("Audio URL is required");
    if (!track.cover_url) throw new Error("Cover URL is required");
    if (!track.performer_name) throw new Error("Performer name is required");
    // Generate ISRC if not exists
    let isrcCode = track.isrc_code;
    if (!isrcCode) {
      // Format: RU-NFA-YY-NNNNN (Нотафея label code)
      const year = new Date().getFullYear().toString().slice(-2);
      const randomNum = Math.floor(Math.random() * 99999).toString().padStart(5, "0");
      isrcCode = `RUNFA${year}${randomNum}`;
      await supabase.from("tracks").update({
        isrc_code: isrcCode
      }).eq("id", track_id);
    }
    // ============================================
    // PLACEHOLDER: Здесь будет интеграция с дистрибьютором
    // Например: Believe, DistroKid API, или российский дистрибьютор
    // ============================================
    // Формируем данные для дистрибьютора
    const distributionPayload = {
      isrc: isrcCode,
      title: track.title,
      artist: track.performer_name,
      composer: track.music_author || track.performer_name,
      lyricist: track.lyrics_author,
      label: track.label_name || "Нота-Фея",
      genre: "Electronic",
      audio_url: track.audio_url,
      cover_url: track.cover_url,
      duration_seconds: track.duration,
      lyrics: track.lyrics,
      release_date: new Date().toISOString().split("T")[0],
      platforms: platforms
    };
    console.log("Distribution payload prepared:", JSON.stringify(distributionPayload, null, 2));
    // TODO: Отправка в API дистрибьютора
    // const distributorResponse = await fetch("https://api.distributor.ru/submit", {
    //   method: "POST",
    //   headers: { "Authorization": `Bearer ${Deno.env.get("DISTRIBUTOR_API_KEY")}` },
    //   body: JSON.stringify(distributionPayload),
    // });
    // Update track status
    await supabase.from("tracks").update({
      distribution_status: "submitted",
      distribution_platforms: platforms,
      distribution_submitted_at: new Date().toISOString()
    }).eq("id", track_id);
    // Log the action
    console.log(`Track ${track_id} submitted for distribution to: ${platforms.join(", ")}`);
    return new Response(JSON.stringify({
      success: true,
      message: "Track submitted for distribution",
      isrc_code: isrcCode,
      platforms: platforms
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Distribution error:", errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9zdWJtaXQtdG8tZGlzdHJpYnV0b3IudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyLjQ5LjFcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuaW50ZXJmYWNlIERpc3RyaWJ1dGlvblJlcXVlc3Qge1xuICB0cmFja19pZDogc3RyaW5nO1xuICBwbGF0Zm9ybXM/OiBzdHJpbmdbXTtcbn1cblxuc2VydmUoYXN5bmMgKHJlcTogUmVxdWVzdCkgPT4ge1xuICAvLyBIYW5kbGUgQ09SUyBwcmVmbGlnaHRcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlU2VydmljZUtleSk7XG5cbiAgICAvLyBWZXJpZnkgYWRtaW4gcm9sZVxuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQXV0aG9yaXphdGlvbiByZXF1aXJlZFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IGF1dGhFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKHRva2VuKTtcbiAgICBpZiAoYXV0aEVycm9yIHx8ICF1c2VyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHRva2VuXCIpO1xuICAgIH1cblxuICAgIC8vIENoZWNrIGFkbWluIHJvbGVcbiAgICBjb25zdCB7IGRhdGE6IHJvbGVEYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJ1c2VyX3JvbGVzXCIpXG4gICAgICAuc2VsZWN0KFwicm9sZVwiKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKCFyb2xlRGF0YSB8fCAhW1wiYWRtaW5cIiwgXCJzdXBlcl9hZG1pblwiXS5pbmNsdWRlcyhyb2xlRGF0YS5yb2xlKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQWRtaW4gYWNjZXNzIHJlcXVpcmVkXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IGJvZHk6IERpc3RyaWJ1dGlvblJlcXVlc3QgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnN0IHsgdHJhY2tfaWQsIHBsYXRmb3JtcyA9IFtcInlhbmRleF9tdXNpY1wiLCBcInZrX211c2ljXCIsIFwic3BvdGlmeVwiLCBcImFwcGxlX211c2ljXCJdIH0gPSBib2R5O1xuXG4gICAgLy8gR2V0IHRyYWNrIGRhdGFcbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrLCBlcnJvcjogdHJhY2tFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAuc2VsZWN0KGBcbiAgICAgICAgaWQsIHRpdGxlLCBkZXNjcmlwdGlvbiwgYXVkaW9fdXJsLCBjb3Zlcl91cmwsIGR1cmF0aW9uLFxuICAgICAgICBwZXJmb3JtZXJfbmFtZSwgbXVzaWNfYXV0aG9yLCBseXJpY3NfYXV0aG9yLCBseXJpY3MsXG4gICAgICAgIGlzcmNfY29kZSwgbGFiZWxfbmFtZSxcbiAgICAgICAgcHJvZmlsZTpwcm9maWxlcyF0cmFja3NfdXNlcl9pZF9ma2V5KHVzZXJuYW1lLCB1c2VyX2lkKVxuICAgICAgYClcbiAgICAgIC5lcShcImlkXCIsIHRyYWNrX2lkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKHRyYWNrRXJyb3IgfHwgIXRyYWNrKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUcmFjayBub3QgZm91bmRcIik7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgcmVxdWlyZWQgZmllbGRzXG4gICAgaWYgKCF0cmFjay5hdWRpb191cmwpIHRocm93IG5ldyBFcnJvcihcIkF1ZGlvIFVSTCBpcyByZXF1aXJlZFwiKTtcbiAgICBpZiAoIXRyYWNrLmNvdmVyX3VybCkgdGhyb3cgbmV3IEVycm9yKFwiQ292ZXIgVVJMIGlzIHJlcXVpcmVkXCIpO1xuICAgIGlmICghdHJhY2sucGVyZm9ybWVyX25hbWUpIHRocm93IG5ldyBFcnJvcihcIlBlcmZvcm1lciBuYW1lIGlzIHJlcXVpcmVkXCIpO1xuXG4gICAgLy8gR2VuZXJhdGUgSVNSQyBpZiBub3QgZXhpc3RzXG4gICAgbGV0IGlzcmNDb2RlID0gdHJhY2suaXNyY19jb2RlO1xuICAgIGlmICghaXNyY0NvZGUpIHtcbiAgICAgIC8vIEZvcm1hdDogUlUtTkZBLVlZLU5OTk5OICjQndC+0YLQsNGE0LXRjyBsYWJlbCBjb2RlKVxuICAgICAgY29uc3QgeWVhciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKS50b1N0cmluZygpLnNsaWNlKC0yKTtcbiAgICAgIGNvbnN0IHJhbmRvbU51bSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDk5OTk5KS50b1N0cmluZygpLnBhZFN0YXJ0KDUsIFwiMFwiKTtcbiAgICAgIGlzcmNDb2RlID0gYFJVTkZBJHt5ZWFyfSR7cmFuZG9tTnVtfWA7XG5cbiAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgIC51cGRhdGUoeyBpc3JjX2NvZGU6IGlzcmNDb2RlIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHRyYWNrX2lkKTtcbiAgICB9XG5cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIC8vIFBMQUNFSE9MREVSOiDQl9C00LXRgdGMINCx0YPQtNC10YIg0LjQvdGC0LXQs9GA0LDRhtC40Y8g0YEg0LTQuNGB0YLRgNC40LHRjNGO0YLQvtGA0L7QvFxuICAgIC8vINCd0LDQv9GA0LjQvNC10YA6IEJlbGlldmUsIERpc3Ryb0tpZCBBUEksINC40LvQuCDRgNC+0YHRgdC40LnRgdC60LjQuSDQtNC40YHRgtGA0LjQsdGM0Y7RgtC+0YBcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIFxuICAgIC8vINCk0L7RgNC80LjRgNGD0LXQvCDQtNCw0L3QvdGL0LUg0LTQu9GPINC00LjRgdGC0YDQuNCx0YzRjtGC0L7RgNCwXG4gICAgY29uc3QgZGlzdHJpYnV0aW9uUGF5bG9hZCA9IHtcbiAgICAgIGlzcmM6IGlzcmNDb2RlLFxuICAgICAgdGl0bGU6IHRyYWNrLnRpdGxlLFxuICAgICAgYXJ0aXN0OiB0cmFjay5wZXJmb3JtZXJfbmFtZSxcbiAgICAgIGNvbXBvc2VyOiB0cmFjay5tdXNpY19hdXRob3IgfHwgdHJhY2sucGVyZm9ybWVyX25hbWUsXG4gICAgICBseXJpY2lzdDogdHJhY2subHlyaWNzX2F1dGhvcixcbiAgICAgIGxhYmVsOiB0cmFjay5sYWJlbF9uYW1lIHx8IFwi0J3QvtGC0LAt0KTQtdGPXCIsXG4gICAgICBnZW5yZTogXCJFbGVjdHJvbmljXCIsIC8vIFRPRE86IEdldCBmcm9tIHRyYWNrXG4gICAgICBhdWRpb191cmw6IHRyYWNrLmF1ZGlvX3VybCxcbiAgICAgIGNvdmVyX3VybDogdHJhY2suY292ZXJfdXJsLFxuICAgICAgZHVyYXRpb25fc2Vjb25kczogdHJhY2suZHVyYXRpb24sXG4gICAgICBseXJpY3M6IHRyYWNrLmx5cmljcyxcbiAgICAgIHJlbGVhc2VfZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcbiAgICAgIHBsYXRmb3JtczogcGxhdGZvcm1zLFxuICAgIH07XG5cbiAgICBjb25zb2xlLmxvZyhcIkRpc3RyaWJ1dGlvbiBwYXlsb2FkIHByZXBhcmVkOlwiLCBKU09OLnN0cmluZ2lmeShkaXN0cmlidXRpb25QYXlsb2FkLCBudWxsLCAyKSk7XG5cbiAgICAvLyBUT0RPOiDQntGC0L/RgNCw0LLQutCwINCyIEFQSSDQtNC40YHRgtGA0LjQsdGM0Y7RgtC+0YDQsFxuICAgIC8vIGNvbnN0IGRpc3RyaWJ1dG9yUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcImh0dHBzOi8vYXBpLmRpc3RyaWJ1dG9yLnJ1L3N1Ym1pdFwiLCB7XG4gICAgLy8gICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgIC8vICAgaGVhZGVyczogeyBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke0Rlbm8uZW52LmdldChcIkRJU1RSSUJVVE9SX0FQSV9LRVlcIil9YCB9LFxuICAgIC8vICAgYm9keTogSlNPTi5zdHJpbmdpZnkoZGlzdHJpYnV0aW9uUGF5bG9hZCksXG4gICAgLy8gfSk7XG5cbiAgICAvLyBVcGRhdGUgdHJhY2sgc3RhdHVzXG4gICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAudXBkYXRlKHtcbiAgICAgICAgZGlzdHJpYnV0aW9uX3N0YXR1czogXCJzdWJtaXR0ZWRcIixcbiAgICAgICAgZGlzdHJpYnV0aW9uX3BsYXRmb3JtczogcGxhdGZvcm1zLFxuICAgICAgICBkaXN0cmlidXRpb25fc3VibWl0dGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9KVxuICAgICAgLmVxKFwiaWRcIiwgdHJhY2tfaWQpO1xuXG4gICAgLy8gTG9nIHRoZSBhY3Rpb25cbiAgICBjb25zb2xlLmxvZyhgVHJhY2sgJHt0cmFja19pZH0gc3VibWl0dGVkIGZvciBkaXN0cmlidXRpb24gdG86ICR7cGxhdGZvcm1zLmpvaW4oXCIsIFwiKX1gKTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgIG1lc3NhZ2U6IFwiVHJhY2sgc3VibWl0dGVkIGZvciBkaXN0cmlidXRpb25cIixcbiAgICAgICAgaXNyY19jb2RlOiBpc3JjQ29kZSxcbiAgICAgICAgcGxhdGZvcm1zOiBwbGF0Zm9ybXMsXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgY29uc29sZS5lcnJvcihcIkRpc3RyaWJ1dGlvbiBlcnJvcjpcIiwgZXJyb3JNZXNzYWdlKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGVycm9yTWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEsOENBQThDO0FBRTNFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBT0EsTUFBTSxPQUFPO0VBQ1gsd0JBQXdCO0VBQ3hCLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDakMsTUFBTSxxQkFBcUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ3hDLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0Msb0JBQW9CO0lBQ3BCLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVk7TUFDZixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sUUFBUSxXQUFXLE9BQU8sQ0FBQyxXQUFXO0lBQzVDLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLFNBQVMsSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUN6RSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsbUJBQW1CO0lBQ25CLE1BQU0sRUFBRSxNQUFNLFFBQVEsRUFBRSxHQUFHLE1BQU0sU0FDOUIsSUFBSSxDQUFDLGNBQ0wsTUFBTSxDQUFDLFFBQ1AsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFLEVBQ3JCLE1BQU07SUFFVCxJQUFJLENBQUMsWUFBWSxDQUFDO01BQUM7TUFBUztLQUFjLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxHQUFHO01BQ2xFLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxPQUE0QixNQUFNLElBQUksSUFBSTtJQUNoRCxNQUFNLEVBQUUsUUFBUSxFQUFFLFlBQVk7TUFBQztNQUFnQjtNQUFZO01BQVc7S0FBYyxFQUFFLEdBQUc7SUFFekYsaUJBQWlCO0lBQ2pCLE1BQU0sRUFBRSxNQUFNLEtBQUssRUFBRSxPQUFPLFVBQVUsRUFBRSxHQUFHLE1BQU0sU0FDOUMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLENBQUM7Ozs7O01BS1QsQ0FBQyxFQUNBLEVBQUUsQ0FBQyxNQUFNLFVBQ1QsTUFBTTtJQUVULElBQUksY0FBYyxDQUFDLE9BQU87TUFDeEIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSwyQkFBMkI7SUFDM0IsSUFBSSxDQUFDLE1BQU0sU0FBUyxFQUFFLE1BQU0sSUFBSSxNQUFNO0lBQ3RDLElBQUksQ0FBQyxNQUFNLFNBQVMsRUFBRSxNQUFNLElBQUksTUFBTTtJQUN0QyxJQUFJLENBQUMsTUFBTSxjQUFjLEVBQUUsTUFBTSxJQUFJLE1BQU07SUFFM0MsOEJBQThCO0lBQzlCLElBQUksV0FBVyxNQUFNLFNBQVM7SUFDOUIsSUFBSSxDQUFDLFVBQVU7TUFDYiwrQ0FBK0M7TUFDL0MsTUFBTSxPQUFPLElBQUksT0FBTyxXQUFXLEdBQUcsUUFBUSxHQUFHLEtBQUssQ0FBQyxDQUFDO01BQ3hELE1BQU0sWUFBWSxLQUFLLEtBQUssQ0FBQyxLQUFLLE1BQU0sS0FBSyxPQUFPLFFBQVEsR0FBRyxRQUFRLENBQUMsR0FBRztNQUMzRSxXQUFXLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxVQUFVLENBQUM7TUFFckMsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztRQUFFLFdBQVc7TUFBUyxHQUM3QixFQUFFLENBQUMsTUFBTTtJQUNkO0lBRUEsK0NBQStDO0lBQy9DLHVEQUF1RDtJQUN2RCxnRUFBZ0U7SUFDaEUsK0NBQStDO0lBRS9DLHFDQUFxQztJQUNyQyxNQUFNLHNCQUFzQjtNQUMxQixNQUFNO01BQ04sT0FBTyxNQUFNLEtBQUs7TUFDbEIsUUFBUSxNQUFNLGNBQWM7TUFDNUIsVUFBVSxNQUFNLFlBQVksSUFBSSxNQUFNLGNBQWM7TUFDcEQsVUFBVSxNQUFNLGFBQWE7TUFDN0IsT0FBTyxNQUFNLFVBQVUsSUFBSTtNQUMzQixPQUFPO01BQ1AsV0FBVyxNQUFNLFNBQVM7TUFDMUIsV0FBVyxNQUFNLFNBQVM7TUFDMUIsa0JBQWtCLE1BQU0sUUFBUTtNQUNoQyxRQUFRLE1BQU0sTUFBTTtNQUNwQixjQUFjLElBQUksT0FBTyxXQUFXLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO01BQ3BELFdBQVc7SUFDYjtJQUVBLFFBQVEsR0FBRyxDQUFDLGtDQUFrQyxLQUFLLFNBQVMsQ0FBQyxxQkFBcUIsTUFBTTtJQUV4RixxQ0FBcUM7SUFDckMsaUZBQWlGO0lBQ2pGLG9CQUFvQjtJQUNwQixtRkFBbUY7SUFDbkYsK0NBQStDO0lBQy9DLE1BQU07SUFFTixzQkFBc0I7SUFDdEIsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztNQUNOLHFCQUFxQjtNQUNyQix3QkFBd0I7TUFDeEIsMkJBQTJCLElBQUksT0FBTyxXQUFXO0lBQ25ELEdBQ0MsRUFBRSxDQUFDLE1BQU07SUFFWixpQkFBaUI7SUFDakIsUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxnQ0FBZ0MsRUFBRSxVQUFVLElBQUksQ0FBQyxNQUFNLENBQUM7SUFFdEYsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsU0FBUztNQUNULFdBQVc7TUFDWCxXQUFXO0lBQ2IsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLE1BQU0sZUFBZSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUM5RCxRQUFRLEtBQUssQ0FBQyx1QkFBdUI7SUFDckMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU8sT0FBTztJQUFhLElBQ3JEO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
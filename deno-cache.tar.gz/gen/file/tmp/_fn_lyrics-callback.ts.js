const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const payload = await req.json();
    console.log("Lyrics callback received:", JSON.stringify(payload));
    // Return the generated lyrics
    // This callback will contain the generated text
    const { code, data } = payload;
    if (code === 200 && data) {
      console.log("Lyrics generated successfully:", data);
    // Lyrics are returned in the callback, can be stored or returned to user
    }
    return new Response(JSON.stringify({
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in lyrics-callback:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9seXJpY3MtY2FsbGJhY2sudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBwYXlsb2FkID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhcIkx5cmljcyBjYWxsYmFjayByZWNlaXZlZDpcIiwgSlNPTi5zdHJpbmdpZnkocGF5bG9hZCkpO1xuXG4gICAgLy8gUmV0dXJuIHRoZSBnZW5lcmF0ZWQgbHlyaWNzXG4gICAgLy8gVGhpcyBjYWxsYmFjayB3aWxsIGNvbnRhaW4gdGhlIGdlbmVyYXRlZCB0ZXh0XG4gICAgY29uc3QgeyBjb2RlLCBkYXRhIH0gPSBwYXlsb2FkO1xuXG4gICAgaWYgKGNvZGUgPT09IDIwMCAmJiBkYXRhKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIkx5cmljcyBnZW5lcmF0ZWQgc3VjY2Vzc2Z1bGx5OlwiLCBkYXRhKTtcbiAgICAgIC8vIEx5cmljcyBhcmUgcmV0dXJuZWQgaW4gdGhlIGNhbGxiYWNrLCBjYW4gYmUgc3RvcmVkIG9yIHJldHVybmVkIHRvIHVzZXJcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSB9KSwge1xuICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gbHlyaWNzLWNhbGxiYWNrOlwiLCBlcnJvcik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IG1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBR25GLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxVQUFVLE1BQU0sSUFBSSxJQUFJO0lBQzlCLFFBQVEsR0FBRyxDQUFDLDZCQUE2QixLQUFLLFNBQVMsQ0FBQztJQUV4RCw4QkFBOEI7SUFDOUIsZ0RBQWdEO0lBQ2hELE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUc7SUFFdkIsSUFBSSxTQUFTLE9BQU8sTUFBTTtNQUN4QixRQUFRLEdBQUcsQ0FBQyxrQ0FBa0M7SUFDOUMseUVBQXlFO0lBQzNFO0lBRUEsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO0lBQUssSUFBSTtNQUNyRCxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQ2hFO0VBQ0YsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDZCQUE2QjtJQUMzQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
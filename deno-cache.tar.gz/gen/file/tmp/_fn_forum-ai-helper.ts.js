const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const AGENT_ACCESS_ID = "0846d064-4950-4d79-a54c-62ba315cdb34";
const SERVICE_NAMES = {
  spell_check: "forum_spell_check",
  expand_topic: "forum_expand_topic",
  expand_to_topic: "forum_expand_topic",
  expand_reply: "forum_expand_reply",
  improve_text: "forum_improve_text",
  summarize_thread: "forum_summarize_thread",
  suggest_arguments: "forum_suggest_arguments",
  auto_tags: "forum_auto_tags"
};
const DEFAULT_PRICES = {
  spell_check: 3,
  expand_topic: 5,
  expand_to_topic: 5,
  expand_reply: 5,
  improve_text: 4,
  summarize_thread: 3,
  suggest_arguments: 4,
  auto_tags: 0
};
const MESSAGES = {
  spell_check: "Текст проверен!",
  expand_topic: "Тезисы развёрнуты!",
  expand_to_topic: "Тема сгенерирована!",
  expand_reply: "Ответ развёрнут!",
  improve_text: "Текст улучшен!",
  summarize_thread: "Резюме готово!",
  suggest_arguments: "Аргументы готовы!",
  auto_tags: "Теги сгенерированы!"
};
const TAG_COLORS = [
  "#6366f1",
  "#10b981",
  "#f59e0b",
  "#ec4899",
  "#ef4444",
  "#8b5cf6",
  "#06b6d4",
  "#a855f7",
  "#14b8a6",
  "#f97316",
  "#84cc16",
  "#0ea5e9",
  "#d946ef",
  "#22c55e",
  "#e11d48",
  "#7c3aed",
  "#0891b2",
  "#c026d3",
  "#16a34a",
  "#ea580c"
];
function buildPrompts(mode, text, topicTitle, topicContent, threadPosts) {
  const topicContext = topicTitle ? `Тема обсуждения: "${topicTitle}"` : "";
  const contentContext = topicContent ? `\nКонтекст темы: ${topicContent.replace(/<[^>]*>/g, "").slice(0, 500)}` : "";
  switch(mode){
    case "spell_check":
      return {
        systemPrompt: `Ты профессиональный корректор текста. Твоя задача — исправить орфографические, грамматические и пунктуационные ошибки в тексте.

Правила:
- Исправь все орфографические ошибки
- Исправь грамматические ошибки
- Расставь правильную пунктуацию
- Сохрани оригинальное форматирование (переносы строк, абзацы)
- Сохрани стиль и тон автора
- НЕ меняй смысл текста
- НЕ переписывай предложения, если они грамматически верны
- НЕ добавляй и НЕ удаляй контент
- Если текст написан без ошибок — верни его как есть
- Отвечай ТОЛЬКО исправленным текстом, без пояснений и комментариев`,
        userPrompt: `Проверь и исправь ошибки в этом тексте:\n\n${text}`
      };
    case "expand_to_topic":
      return {
        systemPrompt: `Ты опытный участник музыкального форума. Пользователь даёт тебе набор тезисов — ты должен:
1. Придумать короткий, цепляющий заголовок для темы (до 100 символов)
2. Развернуть тезисы в полноценный структурированный пост
3. Подобрать до 3 наиболее подходящих тегов из списка

Доступные теги (выбирай ТОЛЬКО из этого списка, используй точные значения name):
discussion, tutorial, question, showcase, bug-report, feature-request, tip, ai-generation, mixing, lyrics, beats, collab

Формат ответа — строго JSON:
{"title": "заголовок темы", "content": "текст поста", "tags": ["tag1", "tag2"]}

Правила для контента:
- Развей каждый тезис в полноценный абзац
- Используй разговорный, но грамотный стиль общения на форуме
- Сохрани все идеи и мысли автора
- Добавь уместные вопросы к сообществу
- НЕ используй канцелярит и шаблонные фразы
- Пиши живо и естественно
- Длина: 3-6 абзацев
- Разделяй абзацы двойным переносом строки

Правила для заголовка:
- Краткий, интригующий, без кликбейта
- На русском языке

Правила для тегов:
- Выбирай от 1 до 3 тегов, максимально релевантных содержанию
- Используй ТОЛЬКО имена из предоставленного списка

Отвечай ТОЛЬКО валидным JSON, без markdown-обёрток.`,
        userPrompt: `Развей эти тезисы в полноценную тему для форума:\n\n${text}`
      };
    case "expand_reply":
      return {
        systemPrompt: `Ты опытный участник музыкального форума. Развей краткие тезисы в полноценный ответ на тему.

Правила:
- Развей каждый тезис в полноценный абзац
- Добавь логические связки между идеями
- Используй разговорный, но грамотный стиль общения на форуме
- Сохрани все идеи и мысли автора
- Добавь уместные вопросы и реакции на тему обсуждения
- НЕ используй канцелярит и шаблонные фразы
- НЕ добавляй заголовки — только текст ответа
- Пиши живо и естественно, как реальный человек
- Длина: 2-5 абзацев
- Отвечай ТОЛЬКО текстом ответа, без пояснений`,
        userPrompt: `${topicContext}${contentContext}\n\nРазвей эти тезисы в полноценный ответ:\n\n${text}`
      };
    case "improve_text":
      return {
        systemPrompt: `Ты литературный редактор. Улучши текст поста на форуме.

Правила:
- Улучши стиль и читаемость
- Исправь орфографию и пунктуацию
- Сделай текст более структурированным
- Сохрани ВСЕ оригинальные мысли и смысл
- НЕ добавляй новые идеи от себя
- НЕ сокращай текст существенно
- Сохрани тон автора (если неформальный — оставь неформальным)
- НЕ используй канцелярит
- Отвечай ТОЛЬКО улучшенным текстом, без пояснений`,
        userPrompt: `Улучши этот текст:\n\n${text}`
      };
    case "summarize_thread":
      return {
        systemPrompt: `Ты аналитик форумных дискуссий. Создай краткое, информативное резюме обсуждения в теме.

Правила:
- Выдели основные точки зрения и аргументы
- Укажи ключевые идеи каждой стороны дискуссии
- Если есть консенсус — отметь это
- Если есть разногласия — обозначь позиции
- Формат: 3-5 пунктов, коротко и по делу
- Используй маркированный список
- Добавь одно предложение в конце: «Что ещё не обсудили / какие вопросы остались»
- Отвечай ТОЛЬКО резюме, без вступлений и пояснений`,
        userPrompt: `${topicContext}${contentContext}\n\nПосты в дискуссии:\n${threadPosts || "(постов пока нет)"}`
      };
    case "suggest_arguments":
      return {
        systemPrompt: `Ты помощник для написания ответов на музыкальном форуме. Проанализируй тему и предложи аргументы/идеи для ответа.

Правила:
- Предложи 3-5 чётких тезисов для ответа
- Учитывай контекст темы и уже написанные ответы
- Каждый тезис — 1-2 предложения
- Предлагай разные углы зрения
- Учитывай специфику музыкального сообщества
- Формат: нумерованный список
- Отвечай ТОЛЬКО списком тезисов, без вступлений`,
        userPrompt: `${topicContext}${contentContext}\n\nУже написанные ответы:\n${threadPosts || "(ответов пока нет)"}\n\nПредложи идеи для ответа.`
      };
    case "auto_tags":
      return {
        systemPrompt: `Ты SEO-специалист музыкального форума. Твоя задача — извлечь из заголовка и текста темы КОНКРЕТНЫЕ ключевые слова, которые точно описывают содержание ИМЕННО ЭТОЙ темы.

КРИТИЧЕСКИ ВАЖНО — РЕЛЕВАНТНОСТЬ:
- Каждый тег ОБЯЗАН напрямую соответствовать тому, о чём написано в заголовке и тексте
- Если тема про горячие клавиши — теги должны быть про горячие клавиши, советы, лайфхаки
- Если тема про сведение вокала — теги должны быть про сведение, вокал, микширование  
- НИКОГДА не добавляй теги про сведение, биты, тексты, коллаб, если тема НЕ об этом
- НЕ генерируй шаблонные музыкальные теги, которые не связаны с конкретным текстом
- Перечитай заголовок ещё раз перед ответом и убедись, что КАЖДЫЙ тег описывает содержание

Правила:
- Сгенерируй от 2 до 4 тегов (лучше меньше, но точнее)
- Каждый тег: 1-3 слова на русском
- Slug: латиницей, через дефис, lowercase, транслитерация русского названия
- Не используй слишком общие теги: "музыка", "форум", "обсуждение", "вопрос"
- Теги должны быть полезны для SEO-кластеризации: пользователь, ищущий эту тему в Google, мог бы найти её по этим тегам

Формат ответа — строго JSON массив:
[{"slug": "goryachie-klavishi", "name_ru": "Горячие клавиши"}, {"slug": "sovety-novichkam", "name_ru": "Советы новичкам"}]

Отвечай ТОЛЬКО валидным JSON массивом, без markdown-обёрток и пояснений.`,
        userPrompt: `Заголовок темы: "${topicTitle || ""}"\n\nТекст темы:\n${text || topicContent || "(текст отсутствует)"}`
      };
    default:
      // expand_topic (legacy)
      return {
        systemPrompt: `Ты опытный участник музыкального форума. Развей краткие тезисы в полноценный пост.

Правила:
- Развей каждый тезис в полноценный абзац
- Добавь логические связки
- Используй разговорный, но грамотный стиль
- Сохрани все идеи автора
- НЕ добавляй заголовки и разметку — только текст
- Длина: 3-6 абзацев
- Отвечай ТОЛЬКО текстом поста, без пояснений`,
        userPrompt: `${topicContext}${contentContext}\n\nРазвей эти тезисы в полноценный пост:\n\n${text}`
      };
  }
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "Необходима авторизация"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
    const token = authHeader.replace("Bearer ", "");
    const { data, error: authError } = await supabase.auth.getClaims(token);
    if (authError || !data?.claims?.sub) {
      console.error("Auth error:", authError);
      return new Response(JSON.stringify({
        error: "Неверный токен авторизации"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const user_id = data.claims.sub;
    const { mode, text, topicTitle, topicContent, threadPosts, topicId } = await req.json();
    console.log(`[forum-ai-helper] mode=${mode}, user=${user_id}, textLen=${text?.length || 0}`);
    const TIMEWEB_TOKEN = Deno.env.get("TIMEWEB_AGENT_TOKEN");
    if (!TIMEWEB_TOKEN) {
      throw new Error("TIMEWEB_AGENT_TOKEN not configured");
    }
    // Get service price from addon_services
    const serviceName = SERVICE_NAMES[mode];
    if (!serviceName) {
      return new Response(JSON.stringify({
        error: `Неизвестный режим: ${mode}`
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { data: service } = await supabase.from("addon_services").select("price_rub, is_active").eq("name", serviceName).maybeSingle();
    if (service && !service.is_active) {
      return new Response(JSON.stringify({
        error: "Эта функция временно отключена"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const price = service?.price_rub ?? DEFAULT_PRICES[mode];
    const isFreeMode = price === 0;
    let profile = null;
    let newBalance = 0;
    if (!isFreeMode) {
      // Check balance
      const { data: profileData } = await supabase.from("profiles").select("balance").eq("user_id", user_id).maybeSingle();
      profile = profileData;
      if (!profile || (profile.balance || 0) < price) {
        return new Response(JSON.stringify({
          error: "Недостаточно средств на балансе",
          required: price,
          balance: profile?.balance || 0
        }), {
          status: 402,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Deduct balance
      newBalance = (profile.balance || 0) - price;
      const { error: balanceError } = await supabase.from("profiles").update({
        balance: newBalance
      }).eq("user_id", user_id);
      if (balanceError) {
        throw new Error("Ошибка списания баланса");
      }
      // Log transaction
      await supabase.from("balance_transactions").insert({
        user_id: user_id,
        amount: -price,
        balance_after: newBalance,
        type: "forum_ai",
        description: `Форум AI: ${MESSAGES[mode] || mode}`,
        metadata: {
          mode,
          topicTitle
        }
      });
    }
    const { systemPrompt, userPrompt } = buildPrompts(mode, text, topicTitle, topicContent, threadPosts);
    // Call Timeweb Agent API
    const apiUrl = `https://agent.timeweb.cloud/api/v1/cloud-ai/agents/${AGENT_ACCESS_ID}/v1/chat/completions`;
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${TIMEWEB_TOKEN}`,
        "x-proxy-source": "lovable-app"
      },
      body: JSON.stringify({
        model: "deepseek-v3",
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: userPrompt
          }
        ],
        temperature: mode === "spell_check" || mode === "auto_tags" ? 0.1 : 0.7
      })
    });
    console.log(`[forum-ai-helper] Timeweb response status: ${response.status}`);
    if (!response.ok) {
      // Refund on API error (only if paid)
      if (!isFreeMode && profile) {
        await supabase.from("profiles").update({
          balance: profile.balance
        }).eq("user_id", user_id);
      }
      const errorText = await response.text();
      console.error("[forum-ai-helper] Timeweb API error:", response.status, errorText);
      throw new Error("Ошибка API — попробуйте позже");
    }
    const result = await response.json();
    const generatedContent = result.choices?.[0]?.message?.content;
    if (!generatedContent) {
      if (!isFreeMode && profile) {
        await supabase.from("profiles").update({
          balance: profile.balance
        }).eq("user_id", user_id);
      }
      throw new Error("Не удалось обработать текст");
    }
    // ── auto_tags: parse, create tags, link to topic ──
    if (mode === "auto_tags") {
      try {
        let cleanJson = generatedContent.trim();
        // Remove markdown fences
        cleanJson = cleanJson.replace(/```json\s*/gi, "").replace(/```\s*/g, "").trim();
        // Find JSON array boundaries
        const arrStart = cleanJson.indexOf("[");
        const arrEnd = cleanJson.lastIndexOf("]");
        if (arrStart !== -1 && arrEnd !== -1) {
          cleanJson = cleanJson.substring(arrStart, arrEnd + 1);
        }
        // Fix common issues
        cleanJson = cleanJson.replace(/,\s*]/g, "]").replace(/[\x00-\x1F\x7F]/g, "");
        const tags = JSON.parse(cleanJson);
        console.log(`[forum-ai-helper] auto_tags parsed ${tags.length} tags:`, tags);
        if (!Array.isArray(tags) || tags.length === 0) {
          return new Response(JSON.stringify({
            success: true,
            tags: [],
            mode,
            message: "Нет подходящих тегов"
          }), {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json"
            }
          });
        }
        const createdTagIds = [];
        const createdTags = [];
        for (const tag of tags.slice(0, 5)){
          if (!tag.slug || !tag.name_ru) continue;
          const slug = tag.slug.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 50);
          const nameRu = tag.name_ru.trim().slice(0, 50);
          if (!slug || !nameRu) continue;
          // Check if tag exists by slug
          const { data: existing } = await supabase.from("forum_tags").select("id, name, name_ru, color").eq("name", slug).maybeSingle();
          if (existing) {
            createdTagIds.push(existing.id);
            createdTags.push(existing);
            // Increment usage_count
            await supabase.from("forum_tags").update({
              usage_count: existing.usage_count ? existing.usage_count + 1 : 1
            }).eq("id", existing.id);
          } else {
            const color = TAG_COLORS[Math.floor(Math.random() * TAG_COLORS.length)];
            const { data: newTag, error: tagError } = await supabase.from("forum_tags").insert({
              name: slug,
              name_ru: nameRu,
              color,
              usage_count: 1
            }).select("id, name, name_ru, color").single();
            if (tagError) {
              console.error(`[forum-ai-helper] Error creating tag "${slug}":`, tagError);
              continue;
            }
            createdTagIds.push(newTag.id);
            createdTags.push(newTag);
          }
        }
        // Link tags to topic
        if (topicId && createdTagIds.length > 0) {
          // Get existing tags for this topic
          const { data: existingLinks } = await supabase.from("forum_topic_tags").select("tag_id").eq("topic_id", topicId);
          const existingTagIds = new Set((existingLinks || []).map((l)=>l.tag_id));
          const newLinks = createdTagIds.filter((id)=>!existingTagIds.has(id)).slice(0, 5 - existingTagIds.size) // max 5 total tags per topic
          .map((tag_id)=>({
              topic_id: topicId,
              tag_id
            }));
          if (newLinks.length > 0) {
            const { error: linkError } = await supabase.from("forum_topic_tags").insert(newLinks);
            if (linkError) {
              console.error("[forum-ai-helper] Error linking tags:", linkError);
            }
          }
          console.log(`[forum-ai-helper] Linked ${newLinks.length} auto-tags to topic ${topicId}`);
        }
        return new Response(JSON.stringify({
          success: true,
          tags: createdTags,
          mode,
          message: MESSAGES[mode]
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      } catch (parseErr) {
        console.error("[forum-ai-helper] auto_tags parse error:", parseErr, "raw:", generatedContent);
        return new Response(JSON.stringify({
          success: true,
          tags: [],
          mode,
          message: "Не удалось распознать теги"
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
    }
    // For expand_to_topic, parse JSON to extract title + content
    if (mode === "expand_to_topic") {
      try {
        let cleanJson = generatedContent.trim();
        cleanJson = cleanJson.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
        const parsed = JSON.parse(cleanJson);
        return new Response(JSON.stringify({
          success: true,
          title: (parsed.title || "").trim(),
          content: (parsed.content || "").trim(),
          suggestedTags: Array.isArray(parsed.tags) ? parsed.tags : [],
          mode,
          price,
          message: MESSAGES[mode]
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      } catch  {
        const lines = generatedContent.trim().split("\n");
        const fallbackTitle = lines[0].replace(/^["#*]+|["#*]+$/g, "").trim();
        const fallbackContent = lines.slice(1).join("\n").trim();
        return new Response(JSON.stringify({
          success: true,
          title: fallbackTitle,
          content: fallbackContent || generatedContent.trim(),
          suggestedTags: [],
          mode,
          price,
          message: MESSAGES[mode]
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
    }
    return new Response(JSON.stringify({
      success: true,
      result: generatedContent.trim(),
      mode,
      price,
      message: MESSAGES[mode]
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("[forum-ai-helper] Error:", error);
    const message = error instanceof Error ? error.message : "Неизвестная ошибка";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9mb3J1bS1haS1oZWxwZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6XG4gICAgXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxudHlwZSBNb2RlID1cbiAgfCBcInNwZWxsX2NoZWNrXCJcbiAgfCBcImV4cGFuZF90b3BpY1wiXG4gIHwgXCJleHBhbmRfdG9fdG9waWNcIlxuICB8IFwiZXhwYW5kX3JlcGx5XCJcbiAgfCBcImltcHJvdmVfdGV4dFwiXG4gIHwgXCJzdW1tYXJpemVfdGhyZWFkXCJcbiAgfCBcInN1Z2dlc3RfYXJndW1lbnRzXCJcbiAgfCBcImF1dG9fdGFnc1wiO1xuXG5jb25zdCBBR0VOVF9BQ0NFU1NfSUQgPSBcIjA4NDZkMDY0LTQ5NTAtNGQ3OS1hNTRjLTYyYmEzMTVjZGIzNFwiO1xuXG5jb25zdCBTRVJWSUNFX05BTUVTOiBSZWNvcmQ8TW9kZSwgc3RyaW5nPiA9IHtcbiAgc3BlbGxfY2hlY2s6IFwiZm9ydW1fc3BlbGxfY2hlY2tcIixcbiAgZXhwYW5kX3RvcGljOiBcImZvcnVtX2V4cGFuZF90b3BpY1wiLFxuICBleHBhbmRfdG9fdG9waWM6IFwiZm9ydW1fZXhwYW5kX3RvcGljXCIsXG4gIGV4cGFuZF9yZXBseTogXCJmb3J1bV9leHBhbmRfcmVwbHlcIixcbiAgaW1wcm92ZV90ZXh0OiBcImZvcnVtX2ltcHJvdmVfdGV4dFwiLFxuICBzdW1tYXJpemVfdGhyZWFkOiBcImZvcnVtX3N1bW1hcml6ZV90aHJlYWRcIixcbiAgc3VnZ2VzdF9hcmd1bWVudHM6IFwiZm9ydW1fc3VnZ2VzdF9hcmd1bWVudHNcIixcbiAgYXV0b190YWdzOiBcImZvcnVtX2F1dG9fdGFnc1wiLFxufTtcblxuY29uc3QgREVGQVVMVF9QUklDRVM6IFJlY29yZDxNb2RlLCBudW1iZXI+ID0ge1xuICBzcGVsbF9jaGVjazogMyxcbiAgZXhwYW5kX3RvcGljOiA1LFxuICBleHBhbmRfdG9fdG9waWM6IDUsXG4gIGV4cGFuZF9yZXBseTogNSxcbiAgaW1wcm92ZV90ZXh0OiA0LFxuICBzdW1tYXJpemVfdGhyZWFkOiAzLFxuICBzdWdnZXN0X2FyZ3VtZW50czogNCxcbiAgYXV0b190YWdzOiAwLCAvLyBGcmVlIGZvciBTRU9cbn07XG5cbmNvbnN0IE1FU1NBR0VTOiBSZWNvcmQ8TW9kZSwgc3RyaW5nPiA9IHtcbiAgc3BlbGxfY2hlY2s6IFwi0KLQtdC60YHRgiDQv9GA0L7QstC10YDQtdC9IVwiLFxuICBleHBhbmRfdG9waWM6IFwi0KLQtdC30LjRgdGLINGA0LDQt9Cy0ZHRgNC90YPRgtGLIVwiLFxuICBleHBhbmRfdG9fdG9waWM6IFwi0KLQtdC80LAg0YHQs9C10L3QtdGA0LjRgNC+0LLQsNC90LAhXCIsXG4gIGV4cGFuZF9yZXBseTogXCLQntGC0LLQtdGCINGA0LDQt9Cy0ZHRgNC90YPRgiFcIixcbiAgaW1wcm92ZV90ZXh0OiBcItCi0LXQutGB0YIg0YPQu9GD0YfRiNC10L0hXCIsXG4gIHN1bW1hcml6ZV90aHJlYWQ6IFwi0KDQtdC30Y7QvNC1INCz0L7RgtC+0LLQviFcIixcbiAgc3VnZ2VzdF9hcmd1bWVudHM6IFwi0JDRgNCz0YPQvNC10L3RgtGLINCz0L7RgtC+0LLRiyFcIixcbiAgYXV0b190YWdzOiBcItCi0LXQs9C4INGB0LPQtdC90LXRgNC40YDQvtCy0LDQvdGLIVwiLFxufTtcblxuY29uc3QgVEFHX0NPTE9SUyA9IFtcbiAgXCIjNjM2NmYxXCIsIFwiIzEwYjk4MVwiLCBcIiNmNTllMGJcIiwgXCIjZWM0ODk5XCIsIFwiI2VmNDQ0NFwiLFxuICBcIiM4YjVjZjZcIiwgXCIjMDZiNmQ0XCIsIFwiI2E4NTVmN1wiLCBcIiMxNGI4YTZcIiwgXCIjZjk3MzE2XCIsXG4gIFwiIzg0Y2MxNlwiLCBcIiMwZWE1ZTlcIiwgXCIjZDk0NmVmXCIsIFwiIzIyYzU1ZVwiLCBcIiNlMTFkNDhcIixcbiAgXCIjN2MzYWVkXCIsIFwiIzA4OTFiMlwiLCBcIiNjMDI2ZDNcIiwgXCIjMTZhMzRhXCIsIFwiI2VhNTgwY1wiLFxuXTtcblxuZnVuY3Rpb24gYnVpbGRQcm9tcHRzKFxuICBtb2RlOiBNb2RlLFxuICB0ZXh0OiBzdHJpbmcgfCB1bmRlZmluZWQsXG4gIHRvcGljVGl0bGU6IHN0cmluZyB8IHVuZGVmaW5lZCxcbiAgdG9waWNDb250ZW50OiBzdHJpbmcgfCB1bmRlZmluZWQsXG4gIHRocmVhZFBvc3RzOiBzdHJpbmcgfCB1bmRlZmluZWQsXG4pOiB7IHN5c3RlbVByb21wdDogc3RyaW5nOyB1c2VyUHJvbXB0OiBzdHJpbmcgfSB7XG4gIGNvbnN0IHRvcGljQ29udGV4dCA9IHRvcGljVGl0bGUgPyBg0KLQtdC80LAg0L7QsdGB0YPQttC00LXQvdC40Y86IFwiJHt0b3BpY1RpdGxlfVwiYCA6IFwiXCI7XG4gIGNvbnN0IGNvbnRlbnRDb250ZXh0ID0gdG9waWNDb250ZW50XG4gICAgPyBgXFxu0JrQvtC90YLQtdC60YHRgiDRgtC10LzRizogJHt0b3BpY0NvbnRlbnQucmVwbGFjZSgvPFtePl0qPi9nLCBcIlwiKS5zbGljZSgwLCA1MDApfWBcbiAgICA6IFwiXCI7XG5cbiAgc3dpdGNoIChtb2RlKSB7XG4gICAgY2FzZSBcInNwZWxsX2NoZWNrXCI6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzeXN0ZW1Qcm9tcHQ6IGDQotGLINC/0YDQvtGE0LXRgdGB0LjQvtC90LDQu9GM0L3Ri9C5INC60L7RgNGA0LXQutGC0L7RgCDRgtC10LrRgdGC0LAuINCi0LLQvtGPINC30LDQtNCw0YfQsCDigJQg0LjRgdC/0YDQsNCy0LjRgtGMINC+0YDRhNC+0LPRgNCw0YTQuNGH0LXRgdC60LjQtSwg0LPRgNCw0LzQvNCw0YLQuNGH0LXRgdC60LjQtSDQuCDQv9GD0L3QutGC0YPQsNGG0LjQvtC90L3Ri9C1INC+0YjQuNCx0LrQuCDQsiDRgtC10LrRgdGC0LUuXG5cbtCf0YDQsNCy0LjQu9CwOlxuLSDQmNGB0L/RgNCw0LLRjCDQstGB0LUg0L7RgNGE0L7Qs9GA0LDRhNC40YfQtdGB0LrQuNC1INC+0YjQuNCx0LrQuFxuLSDQmNGB0L/RgNCw0LLRjCDQs9GA0LDQvNC80LDRgtC40YfQtdGB0LrQuNC1INC+0YjQuNCx0LrQuFxuLSDQoNCw0YHRgdGC0LDQstGMINC/0YDQsNCy0LjQu9GM0L3Rg9GOINC/0YPQvdC60YLRg9Cw0YbQuNGOXG4tINCh0L7RhdGA0LDQvdC4INC+0YDQuNCz0LjQvdCw0LvRjNC90L7QtSDRhNC+0YDQvNCw0YLQuNGA0L7QstCw0L3QuNC1ICjQv9C10YDQtdC90L7RgdGLINGB0YLRgNC+0LosINCw0LHQt9Cw0YbRiylcbi0g0KHQvtGF0YDQsNC90Lgg0YHRgtC40LvRjCDQuCDRgtC+0L0g0LDQstGC0L7RgNCwXG4tINCd0JUg0LzQtdC90Y/QuSDRgdC80YvRgdC7INGC0LXQutGB0YLQsFxuLSDQndCVINC/0LXRgNC10L/QuNGB0YvQstCw0Lkg0L/RgNC10LTQu9C+0LbQtdC90LjRjywg0LXRgdC70Lgg0L7QvdC4INCz0YDQsNC80LzQsNGC0LjRh9C10YHQutC4INCy0LXRgNC90Ytcbi0g0J3QlSDQtNC+0LHQsNCy0LvRj9C5INC4INCd0JUg0YPQtNCw0LvRj9C5INC60L7QvdGC0LXQvdGCXG4tINCV0YHQu9C4INGC0LXQutGB0YIg0L3QsNC/0LjRgdCw0L0g0LHQtdC3INC+0YjQuNCx0L7QuiDigJQg0LLQtdGA0L3QuCDQtdCz0L4g0LrQsNC6INC10YHRgtGMXG4tINCe0YLQstC10YfQsNC5INCi0J7Qm9Cs0JrQniDQuNGB0L/RgNCw0LLQu9C10L3QvdGL0Lwg0YLQtdC60YHRgtC+0LwsINCx0LXQtyDQv9C+0Y/RgdC90LXQvdC40Lkg0Lgg0LrQvtC80LzQtdC90YLQsNGA0LjQtdCyYCxcbiAgICAgICAgdXNlclByb21wdDogYNCf0YDQvtCy0LXRgNGMINC4INC40YHQv9GA0LDQstGMINC+0YjQuNCx0LrQuCDQsiDRjdGC0L7QvCDRgtC10LrRgdGC0LU6XFxuXFxuJHt0ZXh0fWAsXG4gICAgICB9O1xuXG4gICAgY2FzZSBcImV4cGFuZF90b190b3BpY1wiOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3lzdGVtUHJvbXB0OiBg0KLRiyDQvtC/0YvRgtC90YvQuSDRg9GH0LDRgdGC0L3QuNC6INC80YPQt9GL0LrQsNC70YzQvdC+0LPQviDRhNC+0YDRg9C80LAuINCf0L7Qu9GM0LfQvtCy0LDRgtC10LvRjCDQtNCw0ZHRgiDRgtC10LHQtSDQvdCw0LHQvtGAINGC0LXQt9C40YHQvtCyIOKAlCDRgtGLINC00L7Qu9C20LXQvTpcbjEuINCf0YDQuNC00YPQvNCw0YLRjCDQutC+0YDQvtGC0LrQuNC5LCDRhtC10L/Qu9GP0Y7RidC40Lkg0LfQsNCz0L7Qu9C+0LLQvtC6INC00LvRjyDRgtC10LzRiyAo0LTQviAxMDAg0YHQuNC80LLQvtC70L7QsilcbjIuINCg0LDQt9Cy0LXRgNC90YPRgtGMINGC0LXQt9C40YHRiyDQsiDQv9C+0LvQvdC+0YbQtdC90L3Ri9C5INGB0YLRgNGD0LrRgtGD0YDQuNGA0L7QstCw0L3QvdGL0Lkg0L/QvtGB0YJcbjMuINCf0L7QtNC+0LHRgNCw0YLRjCDQtNC+IDMg0L3QsNC40LHQvtC70LXQtSDQv9C+0LTRhdC+0LTRj9GJ0LjRhSDRgtC10LPQvtCyINC40Lcg0YHQv9C40YHQutCwXG5cbtCU0L7RgdGC0YPQv9C90YvQtSDRgtC10LPQuCAo0LLRi9Cx0LjRgNCw0Lkg0KLQntCb0KzQmtCeINC40Lcg0Y3RgtC+0LPQviDRgdC/0LjRgdC60LAsINC40YHQv9C+0LvRjNC30YPQuSDRgtC+0YfQvdGL0LUg0LfQvdCw0YfQtdC90LjRjyBuYW1lKTpcbmRpc2N1c3Npb24sIHR1dG9yaWFsLCBxdWVzdGlvbiwgc2hvd2Nhc2UsIGJ1Zy1yZXBvcnQsIGZlYXR1cmUtcmVxdWVzdCwgdGlwLCBhaS1nZW5lcmF0aW9uLCBtaXhpbmcsIGx5cmljcywgYmVhdHMsIGNvbGxhYlxuXG7QpNC+0YDQvNCw0YIg0L7RgtCy0LXRgtCwIOKAlCDRgdGC0YDQvtCz0L4gSlNPTjpcbntcInRpdGxlXCI6IFwi0LfQsNCz0L7Qu9C+0LLQvtC6INGC0LXQvNGLXCIsIFwiY29udGVudFwiOiBcItGC0LXQutGB0YIg0L/QvtGB0YLQsFwiLCBcInRhZ3NcIjogW1widGFnMVwiLCBcInRhZzJcIl19XG5cbtCf0YDQsNCy0LjQu9CwINC00LvRjyDQutC+0L3RgtC10L3RgtCwOlxuLSDQoNCw0LfQstC10Lkg0LrQsNC20LTRi9C5INGC0LXQt9C40YEg0LIg0L/QvtC70L3QvtGG0LXQvdC90YvQuSDQsNCx0LfQsNGGXG4tINCY0YHQv9C+0LvRjNC30YPQuSDRgNCw0LfQs9C+0LLQvtGA0L3Ri9C5LCDQvdC+INCz0YDQsNC80L7RgtC90YvQuSDRgdGC0LjQu9GMINC+0LHRidC10L3QuNGPINC90LAg0YTQvtGA0YPQvNC1XG4tINCh0L7RhdGA0LDQvdC4INCy0YHQtSDQuNC00LXQuCDQuCDQvNGL0YHQu9C4INCw0LLRgtC+0YDQsFxuLSDQlNC+0LHQsNCy0Ywg0YPQvNC10YHRgtC90YvQtSDQstC+0L/RgNC+0YHRiyDQuiDRgdC+0L7QsdGJ0LXRgdGC0LLRg1xuLSDQndCVINC40YHQv9C+0LvRjNC30YPQuSDQutCw0L3RhtC10LvRj9GA0LjRgiDQuCDRiNCw0LHQu9C+0L3QvdGL0LUg0YTRgNCw0LfRi1xuLSDQn9C40YjQuCDQttC40LLQviDQuCDQtdGB0YLQtdGB0YLQstC10L3QvdC+XG4tINCU0LvQuNC90LA6IDMtNiDQsNCx0LfQsNGG0LXQslxuLSDQoNCw0LfQtNC10LvRj9C5INCw0LHQt9Cw0YbRiyDQtNCy0L7QudC90YvQvCDQv9C10YDQtdC90L7RgdC+0Lwg0YHRgtGA0L7QutC4XG5cbtCf0YDQsNCy0LjQu9CwINC00LvRjyDQt9Cw0LPQvtC70L7QstC60LA6XG4tINCa0YDQsNGC0LrQuNC5LCDQuNC90YLRgNC40LPRg9GO0YnQuNC5LCDQsdC10Lcg0LrQu9C40LrQsdC10LnRgtCwXG4tINCd0LAg0YDRg9GB0YHQutC+0Lwg0Y/Qt9GL0LrQtVxuXG7Qn9GA0LDQstC40LvQsCDQtNC70Y8g0YLQtdCz0L7Qsjpcbi0g0JLRi9Cx0LjRgNCw0Lkg0L7RgiAxINC00L4gMyDRgtC10LPQvtCyLCDQvNCw0LrRgdC40LzQsNC70YzQvdC+INGA0LXQu9C10LLQsNC90YLQvdGL0YUg0YHQvtC00LXRgNC20LDQvdC40Y5cbi0g0JjRgdC/0L7Qu9GM0LfRg9C5INCi0J7Qm9Cs0JrQniDQuNC80LXQvdCwINC40Lcg0L/RgNC10LTQvtGB0YLQsNCy0LvQtdC90L3QvtCz0L4g0YHQv9C40YHQutCwXG5cbtCe0YLQstC10YfQsNC5INCi0J7Qm9Cs0JrQniDQstCw0LvQuNC00L3Ri9C8IEpTT04sINCx0LXQtyBtYXJrZG93bi3QvtCx0ZHRgNGC0L7Qui5gLFxuICAgICAgICB1c2VyUHJvbXB0OiBg0KDQsNC30LLQtdC5INGN0YLQuCDRgtC10LfQuNGB0Ysg0LIg0L/QvtC70L3QvtGG0LXQvdC90YPRjiDRgtC10LzRgyDQtNC70Y8g0YTQvtGA0YPQvNCwOlxcblxcbiR7dGV4dH1gLFxuICAgICAgfTtcblxuICAgIGNhc2UgXCJleHBhbmRfcmVwbHlcIjpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN5c3RlbVByb21wdDogYNCi0Ysg0L7Qv9GL0YLQvdGL0Lkg0YPRh9Cw0YHRgtC90LjQuiDQvNGD0LfRi9C60LDQu9GM0L3QvtCz0L4g0YTQvtGA0YPQvNCwLiDQoNCw0LfQstC10Lkg0LrRgNCw0YLQutC40LUg0YLQtdC30LjRgdGLINCyINC/0L7Qu9C90L7RhtC10L3QvdGL0Lkg0L7RgtCy0LXRgiDQvdCwINGC0LXQvNGDLlxuXG7Qn9GA0LDQstC40LvQsDpcbi0g0KDQsNC30LLQtdC5INC60LDQttC00YvQuSDRgtC10LfQuNGBINCyINC/0L7Qu9C90L7RhtC10L3QvdGL0Lkg0LDQsdC30LDRhlxuLSDQlNC+0LHQsNCy0Ywg0LvQvtCz0LjRh9C10YHQutC40LUg0YHQstGP0LfQutC4INC80LXQttC00YMg0LjQtNC10Y/QvNC4XG4tINCY0YHQv9C+0LvRjNC30YPQuSDRgNCw0LfQs9C+0LLQvtGA0L3Ri9C5LCDQvdC+INCz0YDQsNC80L7RgtC90YvQuSDRgdGC0LjQu9GMINC+0LHRidC10L3QuNGPINC90LAg0YTQvtGA0YPQvNC1XG4tINCh0L7RhdGA0LDQvdC4INCy0YHQtSDQuNC00LXQuCDQuCDQvNGL0YHQu9C4INCw0LLRgtC+0YDQsFxuLSDQlNC+0LHQsNCy0Ywg0YPQvNC10YHRgtC90YvQtSDQstC+0L/RgNC+0YHRiyDQuCDRgNC10LDQutGG0LjQuCDQvdCwINGC0LXQvNGDINC+0LHRgdGD0LbQtNC10L3QuNGPXG4tINCd0JUg0LjRgdC/0L7Qu9GM0LfRg9C5INC60LDQvdGG0LXQu9GP0YDQuNGCINC4INGI0LDQsdC70L7QvdC90YvQtSDRhNGA0LDQt9GLXG4tINCd0JUg0LTQvtCx0LDQstC70Y/QuSDQt9Cw0LPQvtC70L7QstC60Lgg4oCUINGC0L7Qu9GM0LrQviDRgtC10LrRgdGCINC+0YLQstC10YLQsFxuLSDQn9C40YjQuCDQttC40LLQviDQuCDQtdGB0YLQtdGB0YLQstC10L3QvdC+LCDQutCw0Log0YDQtdCw0LvRjNC90YvQuSDRh9C10LvQvtCy0LXQulxuLSDQlNC70LjQvdCwOiAyLTUg0LDQsdC30LDRhtC10LJcbi0g0J7RgtCy0LXRh9Cw0Lkg0KLQntCb0KzQmtCeINGC0LXQutGB0YLQvtC8INC+0YLQstC10YLQsCwg0LHQtdC3INC/0L7Rj9GB0L3QtdC90LjQuWAsXG4gICAgICAgIHVzZXJQcm9tcHQ6IGAke3RvcGljQ29udGV4dH0ke2NvbnRlbnRDb250ZXh0fVxcblxcbtCg0LDQt9Cy0LXQuSDRjdGC0Lgg0YLQtdC30LjRgdGLINCyINC/0L7Qu9C90L7RhtC10L3QvdGL0Lkg0L7RgtCy0LXRgjpcXG5cXG4ke3RleHR9YCxcbiAgICAgIH07XG5cbiAgICBjYXNlIFwiaW1wcm92ZV90ZXh0XCI6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzeXN0ZW1Qcm9tcHQ6IGDQotGLINC70LjRgtC10YDQsNGC0YPRgNC90YvQuSDRgNC10LTQsNC60YLQvtGALiDQo9C70YPRh9GI0Lgg0YLQtdC60YHRgiDQv9C+0YHRgtCwINC90LAg0YTQvtGA0YPQvNC1LlxuXG7Qn9GA0LDQstC40LvQsDpcbi0g0KPQu9GD0YfRiNC4INGB0YLQuNC70Ywg0Lgg0YfQuNGC0LDQtdC80L7RgdGC0Yxcbi0g0JjRgdC/0YDQsNCy0Ywg0L7RgNGE0L7Qs9GA0LDRhNC40Y4g0Lgg0L/Rg9C90LrRgtGD0LDRhtC40Y5cbi0g0KHQtNC10LvQsNC5INGC0LXQutGB0YIg0LHQvtC70LXQtSDRgdGC0YDRg9C60YLRg9GA0LjRgNC+0LLQsNC90L3Ri9C8XG4tINCh0L7RhdGA0LDQvdC4INCS0KHQlSDQvtGA0LjQs9C40L3QsNC70YzQvdGL0LUg0LzRi9GB0LvQuCDQuCDRgdC80YvRgdC7XG4tINCd0JUg0LTQvtCx0LDQstC70Y/QuSDQvdC+0LLRi9C1INC40LTQtdC4INC+0YIg0YHQtdCx0Y9cbi0g0J3QlSDRgdC+0LrRgNCw0YnQsNC5INGC0LXQutGB0YIg0YHRg9GJ0LXRgdGC0LLQtdC90L3QvlxuLSDQodC+0YXRgNCw0L3QuCDRgtC+0L0g0LDQstGC0L7RgNCwICjQtdGB0LvQuCDQvdC10YTQvtGA0LzQsNC70YzQvdGL0Lkg4oCUINC+0YHRgtCw0LLRjCDQvdC10YTQvtGA0LzQsNC70YzQvdGL0LwpXG4tINCd0JUg0LjRgdC/0L7Qu9GM0LfRg9C5INC60LDQvdGG0LXQu9GP0YDQuNGCXG4tINCe0YLQstC10YfQsNC5INCi0J7Qm9Cs0JrQniDRg9C70YPRh9GI0LXQvdC90YvQvCDRgtC10LrRgdGC0L7QvCwg0LHQtdC3INC/0L7Rj9GB0L3QtdC90LjQuWAsXG4gICAgICAgIHVzZXJQcm9tcHQ6IGDQo9C70YPRh9GI0Lgg0Y3RgtC+0YIg0YLQtdC60YHRgjpcXG5cXG4ke3RleHR9YCxcbiAgICAgIH07XG5cbiAgICBjYXNlIFwic3VtbWFyaXplX3RocmVhZFwiOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3lzdGVtUHJvbXB0OiBg0KLRiyDQsNC90LDQu9C40YLQuNC6INGE0L7RgNGD0LzQvdGL0YUg0LTQuNGB0LrRg9GB0YHQuNC5LiDQodC+0LfQtNCw0Lkg0LrRgNCw0YLQutC+0LUsINC40L3RhNC+0YDQvNCw0YLQuNCy0L3QvtC1INGA0LXQt9GO0LzQtSDQvtCx0YHRg9C20LTQtdC90LjRjyDQsiDRgtC10LzQtS5cblxu0J/RgNCw0LLQuNC70LA6XG4tINCS0YvQtNC10LvQuCDQvtGB0L3QvtCy0L3Ri9C1INGC0L7Rh9C60Lgg0LfRgNC10L3QuNGPINC4INCw0YDQs9GD0LzQtdC90YLRi1xuLSDQo9C60LDQttC4INC60LvRjtGH0LXQstGL0LUg0LjQtNC10Lgg0LrQsNC20LTQvtC5INGB0YLQvtGA0L7QvdGLINC00LjRgdC60YPRgdGB0LjQuFxuLSDQldGB0LvQuCDQtdGB0YLRjCDQutC+0L3RgdC10L3RgdGD0YEg4oCUINC+0YLQvNC10YLRjCDRjdGC0L5cbi0g0JXRgdC70Lgg0LXRgdGC0Ywg0YDQsNC30L3QvtCz0LvQsNGB0LjRjyDigJQg0L7QsdC+0LfQvdCw0YfRjCDQv9C+0LfQuNGG0LjQuFxuLSDQpNC+0YDQvNCw0YI6IDMtNSDQv9GD0L3QutGC0L7Qsiwg0LrQvtGA0L7RgtC60L4g0Lgg0L/QviDQtNC10LvRg1xuLSDQmNGB0L/QvtC70YzQt9GD0Lkg0LzQsNGA0LrQuNGA0L7QstCw0L3QvdGL0Lkg0YHQv9C40YHQvtC6XG4tINCU0L7QsdCw0LLRjCDQvtC00L3QviDQv9GA0LXQtNC70L7QttC10L3QuNC1INCyINC60L7QvdGG0LU6IMKr0KfRgtC+INC10YnRkSDQvdC1INC+0LHRgdGD0LTQuNC70LggLyDQutCw0LrQuNC1INCy0L7Qv9GA0L7RgdGLINC+0YHRgtCw0LvQuNGB0YzCu1xuLSDQntGC0LLQtdGH0LDQuSDQotCe0JvQrNCa0J4g0YDQtdC30Y7QvNC1LCDQsdC10Lcg0LLRgdGC0YPQv9C70LXQvdC40Lkg0Lgg0L/QvtGP0YHQvdC10L3QuNC5YCxcbiAgICAgICAgdXNlclByb21wdDogYCR7dG9waWNDb250ZXh0fSR7Y29udGVudENvbnRleHR9XFxuXFxu0J/QvtGB0YLRiyDQsiDQtNC40YHQutGD0YHRgdC40Lg6XFxuJHt0aHJlYWRQb3N0cyB8fCBcIijQv9C+0YHRgtC+0LIg0L/QvtC60LAg0L3QtdGCKVwifWAsXG4gICAgICB9O1xuXG4gICAgY2FzZSBcInN1Z2dlc3RfYXJndW1lbnRzXCI6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzeXN0ZW1Qcm9tcHQ6IGDQotGLINC/0L7QvNC+0YnQvdC40Log0LTQu9GPINC90LDQv9C40YHQsNC90LjRjyDQvtGC0LLQtdGC0L7QsiDQvdCwINC80YPQt9GL0LrQsNC70YzQvdC+0Lwg0YTQvtGA0YPQvNC1LiDQn9GA0L7QsNC90LDQu9C40LfQuNGA0YPQuSDRgtC10LzRgyDQuCDQv9GA0LXQtNC70L7QttC4INCw0YDQs9GD0LzQtdC90YLRiy/QuNC00LXQuCDQtNC70Y8g0L7RgtCy0LXRgtCwLlxuXG7Qn9GA0LDQstC40LvQsDpcbi0g0J/RgNC10LTQu9C+0LbQuCAzLTUg0YfRkdGC0LrQuNGFINGC0LXQt9C40YHQvtCyINC00LvRjyDQvtGC0LLQtdGC0LBcbi0g0KPRh9C40YLRi9Cy0LDQuSDQutC+0L3RgtC10LrRgdGCINGC0LXQvNGLINC4INGD0LbQtSDQvdCw0L/QuNGB0LDQvdC90YvQtSDQvtGC0LLQtdGC0Ytcbi0g0JrQsNC20LTRi9C5INGC0LXQt9C40YEg4oCUIDEtMiDQv9GA0LXQtNC70L7QttC10L3QuNGPXG4tINCf0YDQtdC00LvQsNCz0LDQuSDRgNCw0LfQvdGL0LUg0YPQs9C70Ysg0LfRgNC10L3QuNGPXG4tINCj0YfQuNGC0YvQstCw0Lkg0YHQv9C10YbQuNGE0LjQutGDINC80YPQt9GL0LrQsNC70YzQvdC+0LPQviDRgdC+0L7QsdGJ0LXRgdGC0LLQsFxuLSDQpNC+0YDQvNCw0YI6INC90YPQvNC10YDQvtCy0LDQvdC90YvQuSDRgdC/0LjRgdC+0Lpcbi0g0J7RgtCy0LXRh9Cw0Lkg0KLQntCb0KzQmtCeINGB0L/QuNGB0LrQvtC8INGC0LXQt9C40YHQvtCyLCDQsdC10Lcg0LLRgdGC0YPQv9C70LXQvdC40LlgLFxuICAgICAgICB1c2VyUHJvbXB0OiBgJHt0b3BpY0NvbnRleHR9JHtjb250ZW50Q29udGV4dH1cXG5cXG7Qo9C20LUg0L3QsNC/0LjRgdCw0L3QvdGL0LUg0L7RgtCy0LXRgtGLOlxcbiR7dGhyZWFkUG9zdHMgfHwgXCIo0L7RgtCy0LXRgtC+0LIg0L/QvtC60LAg0L3QtdGCKVwifVxcblxcbtCf0YDQtdC00LvQvtC20Lgg0LjQtNC10Lgg0LTQu9GPINC+0YLQstC10YLQsC5gLFxuICAgICAgfTtcblxuICAgIGNhc2UgXCJhdXRvX3RhZ3NcIjpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN5c3RlbVByb21wdDogYNCi0YsgU0VPLdGB0L/QtdGG0LjQsNC70LjRgdGCINC80YPQt9GL0LrQsNC70YzQvdC+0LPQviDRhNC+0YDRg9C80LAuINCi0LLQvtGPINC30LDQtNCw0YfQsCDigJQg0LjQt9Cy0LvQtdGH0Ywg0LjQtyDQt9Cw0LPQvtC70L7QstC60LAg0Lgg0YLQtdC60YHRgtCwINGC0LXQvNGLINCa0J7QndCa0KDQldCi0J3Qq9CVINC60LvRjtGH0LXQstGL0LUg0YHQu9C+0LLQsCwg0LrQvtGC0L7RgNGL0LUg0YLQvtGH0L3QviDQvtC/0LjRgdGL0LLQsNGO0YIg0YHQvtC00LXRgNC20LDQvdC40LUg0JjQnNCV0J3QndCeINCt0KLQntCZINGC0LXQvNGLLlxuXG7QmtCg0JjQotCY0KfQldCh0JrQmCDQktCQ0JbQndCeIOKAlCDQoNCV0JvQldCS0JDQndCi0J3QntCh0KLQrDpcbi0g0JrQsNC20LTRi9C5INGC0LXQsyDQntCR0K/Ql9CQ0J0g0L3QsNC/0YDRj9C80YPRjiDRgdC+0L7RgtCy0LXRgtGB0YLQstC+0LLQsNGC0Ywg0YLQvtC80YMsINC+INGH0ZHQvCDQvdCw0L/QuNGB0LDQvdC+INCyINC30LDQs9C+0LvQvtCy0LrQtSDQuCDRgtC10LrRgdGC0LVcbi0g0JXRgdC70Lgg0YLQtdC80LAg0L/RgNC+INCz0L7RgNGP0YfQuNC1INC60LvQsNCy0LjRiNC4IOKAlCDRgtC10LPQuCDQtNC+0LvQttC90Ysg0LHRi9GC0Ywg0L/RgNC+INCz0L7RgNGP0YfQuNC1INC60LvQsNCy0LjRiNC4LCDRgdC+0LLQtdGC0YssINC70LDQudGE0YXQsNC60Lhcbi0g0JXRgdC70Lgg0YLQtdC80LAg0L/RgNC+INGB0LLQtdC00LXQvdC40LUg0LLQvtC60LDQu9CwIOKAlCDRgtC10LPQuCDQtNC+0LvQttC90Ysg0LHRi9GC0Ywg0L/RgNC+INGB0LLQtdC00LXQvdC40LUsINCy0L7QutCw0LssINC80LjQutGI0LjRgNC+0LLQsNC90LjQtSAgXG4tINCd0JjQmtCe0JPQlNCQINC90LUg0LTQvtCx0LDQstC70Y/QuSDRgtC10LPQuCDQv9GA0L4g0YHQstC10LTQtdC90LjQtSwg0LHQuNGC0YssINGC0LXQutGB0YLRiywg0LrQvtC70LvQsNCxLCDQtdGB0LvQuCDRgtC10LzQsCDQndCVINC+0LEg0Y3RgtC+0Lxcbi0g0J3QlSDQs9C10L3QtdGA0LjRgNGD0Lkg0YjQsNCx0LvQvtC90L3Ri9C1INC80YPQt9GL0LrQsNC70YzQvdGL0LUg0YLQtdCz0LgsINC60L7RgtC+0YDRi9C1INC90LUg0YHQstGP0LfQsNC90Ysg0YEg0LrQvtC90LrRgNC10YLQvdGL0Lwg0YLQtdC60YHRgtC+0Lxcbi0g0J/QtdGA0LXRh9C40YLQsNC5INC30LDQs9C+0LvQvtCy0L7QuiDQtdGJ0ZEg0YDQsNC3INC/0LXRgNC10LQg0L7RgtCy0LXRgtC+0Lwg0Lgg0YPQsdC10LTQuNGB0YwsINGH0YLQviDQmtCQ0JbQlNCr0Jkg0YLQtdCzINC+0L/QuNGB0YvQstCw0LXRgiDRgdC+0LTQtdGA0LbQsNC90LjQtVxuXG7Qn9GA0LDQstC40LvQsDpcbi0g0KHQs9C10L3QtdGA0LjRgNGD0Lkg0L7RgiAyINC00L4gNCDRgtC10LPQvtCyICjQu9GD0YfRiNC1INC80LXQvdGM0YjQtSwg0L3QviDRgtC+0YfQvdC10LUpXG4tINCa0LDQttC00YvQuSDRgtC10LM6IDEtMyDRgdC70L7QstCwINC90LAg0YDRg9GB0YHQutC+0Lxcbi0gU2x1Zzog0LvQsNGC0LjQvdC40YbQtdC5LCDRh9C10YDQtdC3INC00LXRhNC40YEsIGxvd2VyY2FzZSwg0YLRgNCw0L3RgdC70LjRgtC10YDQsNGG0LjRjyDRgNGD0YHRgdC60L7Qs9C+INC90LDQt9Cy0LDQvdC40Y9cbi0g0J3QtSDQuNGB0L/QvtC70YzQt9GD0Lkg0YHQu9C40YjQutC+0Lwg0L7QsdGJ0LjQtSDRgtC10LPQuDogXCLQvNGD0LfRi9C60LBcIiwgXCLRhNC+0YDRg9C8XCIsIFwi0L7QsdGB0YPQttC00LXQvdC40LVcIiwgXCLQstC+0L/RgNC+0YFcIlxuLSDQotC10LPQuCDQtNC+0LvQttC90Ysg0LHRi9GC0Ywg0L/QvtC70LXQt9C90Ysg0LTQu9GPIFNFTy3QutC70LDRgdGC0LXRgNC40LfQsNGG0LjQuDog0L/QvtC70YzQt9C+0LLQsNGC0LXQu9GMLCDQuNGJ0YPRidC40Lkg0Y3RgtGDINGC0LXQvNGDINCyIEdvb2dsZSwg0LzQvtCzINCx0Ysg0L3QsNC50YLQuCDQtdGRINC/0L4g0Y3RgtC40Lwg0YLQtdCz0LDQvFxuXG7QpNC+0YDQvNCw0YIg0L7RgtCy0LXRgtCwIOKAlCDRgdGC0YDQvtCz0L4gSlNPTiDQvNCw0YHRgdC40LI6XG5be1wic2x1Z1wiOiBcImdvcnlhY2hpZS1rbGF2aXNoaVwiLCBcIm5hbWVfcnVcIjogXCLQk9C+0YDRj9GH0LjQtSDQutC70LDQstC40YjQuFwifSwge1wic2x1Z1wiOiBcInNvdmV0eS1ub3ZpY2hrYW1cIiwgXCJuYW1lX3J1XCI6IFwi0KHQvtCy0LXRgtGLINC90L7QstC40YfQutCw0LxcIn1dXG5cbtCe0YLQstC10YfQsNC5INCi0J7Qm9Cs0JrQniDQstCw0LvQuNC00L3Ri9C8IEpTT04g0LzQsNGB0YHQuNCy0L7QvCwg0LHQtdC3IG1hcmtkb3duLdC+0LHRkdGA0YLQvtC6INC4INC/0L7Rj9GB0L3QtdC90LjQuS5gLFxuICAgICAgICB1c2VyUHJvbXB0OiBg0JfQsNCz0L7Qu9C+0LLQvtC6INGC0LXQvNGLOiBcIiR7dG9waWNUaXRsZSB8fCBcIlwifVwiXFxuXFxu0KLQtdC60YHRgiDRgtC10LzRizpcXG4ke3RleHQgfHwgdG9waWNDb250ZW50IHx8IFwiKNGC0LXQutGB0YIg0L7RgtGB0YPRgtGB0YLQstGD0LXRgilcIn1gLFxuICAgICAgfTtcblxuICAgIGRlZmF1bHQ6XG4gICAgICAvLyBleHBhbmRfdG9waWMgKGxlZ2FjeSlcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN5c3RlbVByb21wdDogYNCi0Ysg0L7Qv9GL0YLQvdGL0Lkg0YPRh9Cw0YHRgtC90LjQuiDQvNGD0LfRi9C60LDQu9GM0L3QvtCz0L4g0YTQvtGA0YPQvNCwLiDQoNCw0LfQstC10Lkg0LrRgNCw0YLQutC40LUg0YLQtdC30LjRgdGLINCyINC/0L7Qu9C90L7RhtC10L3QvdGL0Lkg0L/QvtGB0YIuXG5cbtCf0YDQsNCy0LjQu9CwOlxuLSDQoNCw0LfQstC10Lkg0LrQsNC20LTRi9C5INGC0LXQt9C40YEg0LIg0L/QvtC70L3QvtGG0LXQvdC90YvQuSDQsNCx0LfQsNGGXG4tINCU0L7QsdCw0LLRjCDQu9C+0LPQuNGH0LXRgdC60LjQtSDRgdCy0Y/Qt9C60Lhcbi0g0JjRgdC/0L7Qu9GM0LfRg9C5INGA0LDQt9Cz0L7QstC+0YDQvdGL0LksINC90L4g0LPRgNCw0LzQvtGC0L3Ri9C5INGB0YLQuNC70Yxcbi0g0KHQvtGF0YDQsNC90Lgg0LLRgdC1INC40LTQtdC4INCw0LLRgtC+0YDQsFxuLSDQndCVINC00L7QsdCw0LLQu9GP0Lkg0LfQsNCz0L7Qu9C+0LLQutC4INC4INGA0LDQt9C80LXRgtC60YMg4oCUINGC0L7Qu9GM0LrQviDRgtC10LrRgdGCXG4tINCU0LvQuNC90LA6IDMtNiDQsNCx0LfQsNGG0LXQslxuLSDQntGC0LLQtdGH0LDQuSDQotCe0JvQrNCa0J4g0YLQtdC60YHRgtC+0Lwg0L/QvtGB0YLQsCwg0LHQtdC3INC/0L7Rj9GB0L3QtdC90LjQuWAsXG4gICAgICAgIHVzZXJQcm9tcHQ6IGAke3RvcGljQ29udGV4dH0ke2NvbnRlbnRDb250ZXh0fVxcblxcbtCg0LDQt9Cy0LXQuSDRjdGC0Lgg0YLQtdC30LjRgdGLINCyINC/0L7Qu9C90L7RhtC10L3QvdGL0Lkg0L/QvtGB0YI6XFxuXFxuJHt0ZXh0fWAsXG4gICAgICB9O1xuICB9XG59XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXI/LnN0YXJ0c1dpdGgoXCJCZWFyZXIgXCIpKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LXQvtCx0YXQvtC00LjQvNCwINCw0LLRgtC+0YDQuNC30LDRhtC40Y9cIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpISxcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhXG4gICAgKTtcblxuICAgIGNvbnN0IHRva2VuID0gYXV0aEhlYWRlci5yZXBsYWNlKFwiQmVhcmVyIFwiLCBcIlwiKTtcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yOiBhdXRoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0Q2xhaW1zKHRva2VuKTtcblxuICAgIGlmIChhdXRoRXJyb3IgfHwgIWRhdGE/LmNsYWltcz8uc3ViKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiQXV0aCBlcnJvcjpcIiwgYXV0aEVycm9yKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0J3QtdCy0LXRgNC90YvQuSDRgtC+0LrQtdC9INCw0LLRgtC+0YDQuNC30LDRhtC40LhcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHVzZXJfaWQgPSBkYXRhLmNsYWltcy5zdWIgYXMgc3RyaW5nO1xuICAgIGNvbnN0IHsgbW9kZSwgdGV4dCwgdG9waWNUaXRsZSwgdG9waWNDb250ZW50LCB0aHJlYWRQb3N0cywgdG9waWNJZCB9ID0gYXdhaXQgcmVxLmpzb24oKSBhcyB7XG4gICAgICBtb2RlOiBNb2RlO1xuICAgICAgdGV4dD86IHN0cmluZztcbiAgICAgIHRvcGljVGl0bGU/OiBzdHJpbmc7XG4gICAgICB0b3BpY0NvbnRlbnQ/OiBzdHJpbmc7XG4gICAgICB0aHJlYWRQb3N0cz86IHN0cmluZztcbiAgICAgIHRvcGljSWQ/OiBzdHJpbmc7XG4gICAgfTtcblxuICAgIGNvbnNvbGUubG9nKGBbZm9ydW0tYWktaGVscGVyXSBtb2RlPSR7bW9kZX0sIHVzZXI9JHt1c2VyX2lkfSwgdGV4dExlbj0ke3RleHQ/Lmxlbmd0aCB8fCAwfWApO1xuXG4gICAgY29uc3QgVElNRVdFQl9UT0tFTiA9IERlbm8uZW52LmdldChcIlRJTUVXRUJfQUdFTlRfVE9LRU5cIik7XG4gICAgaWYgKCFUSU1FV0VCX1RPS0VOKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUSU1FV0VCX0FHRU5UX1RPS0VOIG5vdCBjb25maWd1cmVkXCIpO1xuICAgIH1cblxuICAgIC8vIEdldCBzZXJ2aWNlIHByaWNlIGZyb20gYWRkb25fc2VydmljZXNcbiAgICBjb25zdCBzZXJ2aWNlTmFtZSA9IFNFUlZJQ0VfTkFNRVNbbW9kZV07XG4gICAgaWYgKCFzZXJ2aWNlTmFtZSkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogYNCd0LXQuNC30LLQtdGB0YLQvdGL0Lkg0YDQtdC20LjQvDogJHttb2RlfWAgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB7IGRhdGE6IHNlcnZpY2UgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImFkZG9uX3NlcnZpY2VzXCIpXG4gICAgICAuc2VsZWN0KFwicHJpY2VfcnViLCBpc19hY3RpdmVcIilcbiAgICAgIC5lcShcIm5hbWVcIiwgc2VydmljZU5hbWUpXG4gICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgIGlmIChzZXJ2aWNlICYmICFzZXJ2aWNlLmlzX2FjdGl2ZSkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQrdGC0LAg0YTRg9C90LrRhtC40Y8g0LLRgNC10LzQtdC90L3QviDQvtGC0LrQu9GO0YfQtdC90LBcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMywgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHByaWNlID0gc2VydmljZT8ucHJpY2VfcnViID8/IERFRkFVTFRfUFJJQ0VTW21vZGVdO1xuICAgIGNvbnN0IGlzRnJlZU1vZGUgPSBwcmljZSA9PT0gMDtcblxuICAgIGxldCBwcm9maWxlOiB7IGJhbGFuY2U6IG51bWJlciB9IHwgbnVsbCA9IG51bGw7XG4gICAgbGV0IG5ld0JhbGFuY2UgPSAwO1xuXG4gICAgaWYgKCFpc0ZyZWVNb2RlKSB7XG4gICAgICAvLyBDaGVjayBiYWxhbmNlXG4gICAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGVEYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcl9pZClcbiAgICAgICAgLm1heWJlU2luZ2xlKCk7XG4gICAgICBwcm9maWxlID0gcHJvZmlsZURhdGE7XG5cbiAgICAgIGlmICghcHJvZmlsZSB8fCAocHJvZmlsZS5iYWxhbmNlIHx8IDApIDwgcHJpY2UpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LXQtNC+0YHRgtCw0YLQvtGH0L3QviDRgdGA0LXQtNGB0YLQsiDQvdCwINCx0LDQu9Cw0L3RgdC1XCIsIHJlcXVpcmVkOiBwcmljZSwgYmFsYW5jZTogcHJvZmlsZT8uYmFsYW5jZSB8fCAwIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA0MDIsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICAvLyBEZWR1Y3QgYmFsYW5jZVxuICAgICAgbmV3QmFsYW5jZSA9IChwcm9maWxlLmJhbGFuY2UgfHwgMCkgLSBwcmljZTtcbiAgICAgIGNvbnN0IHsgZXJyb3I6IGJhbGFuY2VFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogbmV3QmFsYW5jZSB9KVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJfaWQpO1xuXG4gICAgICBpZiAoYmFsYW5jZUVycm9yKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcItCe0YjQuNCx0LrQsCDRgdC/0LjRgdCw0L3QuNGPINCx0LDQu9Cw0L3RgdCwXCIpO1xuICAgICAgfVxuXG4gICAgICAvLyBMb2cgdHJhbnNhY3Rpb25cbiAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oXCJiYWxhbmNlX3RyYW5zYWN0aW9uc1wiKS5pbnNlcnQoe1xuICAgICAgICB1c2VyX2lkOiB1c2VyX2lkLFxuICAgICAgICBhbW91bnQ6IC1wcmljZSxcbiAgICAgICAgYmFsYW5jZV9hZnRlcjogbmV3QmFsYW5jZSxcbiAgICAgICAgdHlwZTogXCJmb3J1bV9haVwiLFxuICAgICAgICBkZXNjcmlwdGlvbjogYNCk0L7RgNGD0LwgQUk6ICR7TUVTU0FHRVNbbW9kZV0gfHwgbW9kZX1gLFxuICAgICAgICBtZXRhZGF0YTogeyBtb2RlLCB0b3BpY1RpdGxlIH0sXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBjb25zdCB7IHN5c3RlbVByb21wdCwgdXNlclByb21wdCB9ID0gYnVpbGRQcm9tcHRzKG1vZGUsIHRleHQsIHRvcGljVGl0bGUsIHRvcGljQ29udGVudCwgdGhyZWFkUG9zdHMpO1xuXG4gICAgLy8gQ2FsbCBUaW1ld2ViIEFnZW50IEFQSVxuICAgIGNvbnN0IGFwaVVybCA9IGBodHRwczovL2FnZW50LnRpbWV3ZWIuY2xvdWQvYXBpL3YxL2Nsb3VkLWFpL2FnZW50cy8ke0FHRU5UX0FDQ0VTU19JRH0vdjEvY2hhdC9jb21wbGV0aW9uc2A7XG5cbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGFwaVVybCwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtUSU1FV0VCX1RPS0VOfWAsXG4gICAgICAgIFwieC1wcm94eS1zb3VyY2VcIjogXCJsb3ZhYmxlLWFwcFwiLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgbW9kZWw6IFwiZGVlcHNlZWstdjNcIixcbiAgICAgICAgbWVzc2FnZXM6IFtcbiAgICAgICAgICB7IHJvbGU6IFwic3lzdGVtXCIsIGNvbnRlbnQ6IHN5c3RlbVByb21wdCB9LFxuICAgICAgICAgIHsgcm9sZTogXCJ1c2VyXCIsIGNvbnRlbnQ6IHVzZXJQcm9tcHQgfSxcbiAgICAgICAgXSxcbiAgICAgICAgdGVtcGVyYXR1cmU6IG1vZGUgPT09IFwic3BlbGxfY2hlY2tcIiB8fCBtb2RlID09PSBcImF1dG9fdGFnc1wiID8gMC4xIDogMC43LFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWFpLWhlbHBlcl0gVGltZXdlYiByZXNwb25zZSBzdGF0dXM6ICR7cmVzcG9uc2Uuc3RhdHVzfWApO1xuXG4gICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgLy8gUmVmdW5kIG9uIEFQSSBlcnJvciAob25seSBpZiBwYWlkKVxuICAgICAgaWYgKCFpc0ZyZWVNb2RlICYmIHByb2ZpbGUpIHtcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IHByb2ZpbGUuYmFsYW5jZSB9KVxuICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcl9pZCk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGVycm9yVGV4dCA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJbZm9ydW0tYWktaGVscGVyXSBUaW1ld2ViIEFQSSBlcnJvcjpcIiwgcmVzcG9uc2Uuc3RhdHVzLCBlcnJvclRleHQpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwi0J7RiNC40LHQutCwIEFQSSDigJQg0L/QvtC/0YDQvtCx0YPQudGC0LUg0L/QvtC30LbQtVwiKTtcbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgY29uc3QgZ2VuZXJhdGVkQ29udGVudCA9IHJlc3VsdC5jaG9pY2VzPy5bMF0/Lm1lc3NhZ2U/LmNvbnRlbnQ7XG5cbiAgICBpZiAoIWdlbmVyYXRlZENvbnRlbnQpIHtcbiAgICAgIGlmICghaXNGcmVlTW9kZSAmJiBwcm9maWxlKSB7XG4gICAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBwcm9maWxlLmJhbGFuY2UgfSlcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJfaWQpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQvtCx0YDQsNCx0L7RgtCw0YLRjCDRgtC10LrRgdGCXCIpO1xuICAgIH1cblxuICAgIC8vIOKUgOKUgCBhdXRvX3RhZ3M6IHBhcnNlLCBjcmVhdGUgdGFncywgbGluayB0byB0b3BpYyDilIDilIBcbiAgICBpZiAobW9kZSA9PT0gXCJhdXRvX3RhZ3NcIikge1xuICAgICAgdHJ5IHtcbiAgICAgICAgbGV0IGNsZWFuSnNvbiA9IGdlbmVyYXRlZENvbnRlbnQudHJpbSgpO1xuICAgICAgICAvLyBSZW1vdmUgbWFya2Rvd24gZmVuY2VzXG4gICAgICAgIGNsZWFuSnNvbiA9IGNsZWFuSnNvbi5yZXBsYWNlKC9gYGBqc29uXFxzKi9naSwgXCJcIikucmVwbGFjZSgvYGBgXFxzKi9nLCBcIlwiKS50cmltKCk7XG4gICAgICAgIC8vIEZpbmQgSlNPTiBhcnJheSBib3VuZGFyaWVzXG4gICAgICAgIGNvbnN0IGFyclN0YXJ0ID0gY2xlYW5Kc29uLmluZGV4T2YoXCJbXCIpO1xuICAgICAgICBjb25zdCBhcnJFbmQgPSBjbGVhbkpzb24ubGFzdEluZGV4T2YoXCJdXCIpO1xuICAgICAgICBpZiAoYXJyU3RhcnQgIT09IC0xICYmIGFyckVuZCAhPT0gLTEpIHtcbiAgICAgICAgICBjbGVhbkpzb24gPSBjbGVhbkpzb24uc3Vic3RyaW5nKGFyclN0YXJ0LCBhcnJFbmQgKyAxKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBGaXggY29tbW9uIGlzc3Vlc1xuICAgICAgICBjbGVhbkpzb24gPSBjbGVhbkpzb25cbiAgICAgICAgICAucmVwbGFjZSgvLFxccypdL2csIFwiXVwiKVxuICAgICAgICAgIC5yZXBsYWNlKC9bXFx4MDAtXFx4MUZcXHg3Rl0vZywgXCJcIik7XG5cbiAgICAgICAgY29uc3QgdGFnczogeyBzbHVnOiBzdHJpbmc7IG5hbWVfcnU6IHN0cmluZyB9W10gPSBKU09OLnBhcnNlKGNsZWFuSnNvbik7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbZm9ydW0tYWktaGVscGVyXSBhdXRvX3RhZ3MgcGFyc2VkICR7dGFncy5sZW5ndGh9IHRhZ3M6YCwgdGFncyk7XG5cbiAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KHRhZ3MpIHx8IHRhZ3MubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSwgdGFnczogW10sIG1vZGUsIG1lc3NhZ2U6IFwi0J3QtdGCINC/0L7QtNGF0L7QtNGP0YnQuNGFINGC0LXQs9C+0LJcIiB9KSxcbiAgICAgICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGNyZWF0ZWRUYWdJZHM6IHN0cmluZ1tdID0gW107XG4gICAgICAgIGNvbnN0IGNyZWF0ZWRUYWdzOiB7IGlkOiBzdHJpbmc7IG5hbWU6IHN0cmluZzsgbmFtZV9ydTogc3RyaW5nOyBjb2xvcjogc3RyaW5nIH1bXSA9IFtdO1xuXG4gICAgICAgIGZvciAoY29uc3QgdGFnIG9mIHRhZ3Muc2xpY2UoMCwgNSkpIHtcbiAgICAgICAgICBpZiAoIXRhZy5zbHVnIHx8ICF0YWcubmFtZV9ydSkgY29udGludWU7XG5cbiAgICAgICAgICBjb25zdCBzbHVnID0gdGFnLnNsdWcudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bXmEtejAtOS1dL2csIFwiXCIpLnNsaWNlKDAsIDUwKTtcbiAgICAgICAgICBjb25zdCBuYW1lUnUgPSB0YWcubmFtZV9ydS50cmltKCkuc2xpY2UoMCwgNTApO1xuICAgICAgICAgIGlmICghc2x1ZyB8fCAhbmFtZVJ1KSBjb250aW51ZTtcblxuICAgICAgICAgIC8vIENoZWNrIGlmIHRhZyBleGlzdHMgYnkgc2x1Z1xuICAgICAgICAgIGNvbnN0IHsgZGF0YTogZXhpc3RpbmcgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgICAuZnJvbShcImZvcnVtX3RhZ3NcIilcbiAgICAgICAgICAgIC5zZWxlY3QoXCJpZCwgbmFtZSwgbmFtZV9ydSwgY29sb3JcIilcbiAgICAgICAgICAgIC5lcShcIm5hbWVcIiwgc2x1ZylcbiAgICAgICAgICAgIC5tYXliZVNpbmdsZSgpO1xuXG4gICAgICAgICAgaWYgKGV4aXN0aW5nKSB7XG4gICAgICAgICAgICBjcmVhdGVkVGFnSWRzLnB1c2goZXhpc3RpbmcuaWQpO1xuICAgICAgICAgICAgY3JlYXRlZFRhZ3MucHVzaChleGlzdGluZyk7XG4gICAgICAgICAgICAvLyBJbmNyZW1lbnQgdXNhZ2VfY291bnRcbiAgICAgICAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgICAgIC5mcm9tKFwiZm9ydW1fdGFnc1wiKVxuICAgICAgICAgICAgICAudXBkYXRlKHsgdXNhZ2VfY291bnQ6IChleGlzdGluZyBhcyBhbnkpLnVzYWdlX2NvdW50ID8gKGV4aXN0aW5nIGFzIGFueSkudXNhZ2VfY291bnQgKyAxIDogMSB9KVxuICAgICAgICAgICAgICAuZXEoXCJpZFwiLCBleGlzdGluZy5pZCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGNvbG9yID0gVEFHX0NPTE9SU1tNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBUQUdfQ09MT1JTLmxlbmd0aCldO1xuICAgICAgICAgICAgY29uc3QgeyBkYXRhOiBuZXdUYWcsIGVycm9yOiB0YWdFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAgICAgLmZyb20oXCJmb3J1bV90YWdzXCIpXG4gICAgICAgICAgICAgIC5pbnNlcnQoeyBuYW1lOiBzbHVnLCBuYW1lX3J1OiBuYW1lUnUsIGNvbG9yLCB1c2FnZV9jb3VudDogMSB9KVxuICAgICAgICAgICAgICAuc2VsZWN0KFwiaWQsIG5hbWUsIG5hbWVfcnUsIGNvbG9yXCIpXG4gICAgICAgICAgICAgIC5zaW5nbGUoKTtcblxuICAgICAgICAgICAgaWYgKHRhZ0Vycm9yKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFtmb3J1bS1haS1oZWxwZXJdIEVycm9yIGNyZWF0aW5nIHRhZyBcIiR7c2x1Z31cIjpgLCB0YWdFcnJvcik7XG4gICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY3JlYXRlZFRhZ0lkcy5wdXNoKG5ld1RhZy5pZCk7XG4gICAgICAgICAgICBjcmVhdGVkVGFncy5wdXNoKG5ld1RhZyk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gTGluayB0YWdzIHRvIHRvcGljXG4gICAgICAgIGlmICh0b3BpY0lkICYmIGNyZWF0ZWRUYWdJZHMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIC8vIEdldCBleGlzdGluZyB0YWdzIGZvciB0aGlzIHRvcGljXG4gICAgICAgICAgY29uc3QgeyBkYXRhOiBleGlzdGluZ0xpbmtzIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgICAgLmZyb20oXCJmb3J1bV90b3BpY190YWdzXCIpXG4gICAgICAgICAgICAuc2VsZWN0KFwidGFnX2lkXCIpXG4gICAgICAgICAgICAuZXEoXCJ0b3BpY19pZFwiLCB0b3BpY0lkKTtcblxuICAgICAgICAgIGNvbnN0IGV4aXN0aW5nVGFnSWRzID0gbmV3IFNldCgoZXhpc3RpbmdMaW5rcyB8fCBbXSkubWFwKChsOiBhbnkpID0+IGwudGFnX2lkKSk7XG4gICAgICAgICAgY29uc3QgbmV3TGlua3MgPSBjcmVhdGVkVGFnSWRzXG4gICAgICAgICAgICAuZmlsdGVyKGlkID0+ICFleGlzdGluZ1RhZ0lkcy5oYXMoaWQpKVxuICAgICAgICAgICAgLnNsaWNlKDAsIDUgLSBleGlzdGluZ1RhZ0lkcy5zaXplKSAvLyBtYXggNSB0b3RhbCB0YWdzIHBlciB0b3BpY1xuICAgICAgICAgICAgLm1hcCh0YWdfaWQgPT4gKHsgdG9waWNfaWQ6IHRvcGljSWQsIHRhZ19pZCB9KSk7XG5cbiAgICAgICAgICBpZiAobmV3TGlua3MubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgY29uc3QgeyBlcnJvcjogbGlua0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgICAgICAuZnJvbShcImZvcnVtX3RvcGljX3RhZ3NcIilcbiAgICAgICAgICAgICAgLmluc2VydChuZXdMaW5rcyk7XG4gICAgICAgICAgICBpZiAobGlua0Vycm9yKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJbZm9ydW0tYWktaGVscGVyXSBFcnJvciBsaW5raW5nIHRhZ3M6XCIsIGxpbmtFcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnNvbGUubG9nKGBbZm9ydW0tYWktaGVscGVyXSBMaW5rZWQgJHtuZXdMaW5rcy5sZW5ndGh9IGF1dG8tdGFncyB0byB0b3BpYyAke3RvcGljSWR9YCk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICB0YWdzOiBjcmVhdGVkVGFncyxcbiAgICAgICAgICAgIG1vZGUsXG4gICAgICAgICAgICBtZXNzYWdlOiBNRVNTQUdFU1ttb2RlXSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfSBjYXRjaCAocGFyc2VFcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIltmb3J1bS1haS1oZWxwZXJdIGF1dG9fdGFncyBwYXJzZSBlcnJvcjpcIiwgcGFyc2VFcnIsIFwicmF3OlwiLCBnZW5lcmF0ZWRDb250ZW50KTtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IHRydWUsIHRhZ3M6IFtdLCBtb2RlLCBtZXNzYWdlOiBcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0YDQsNGB0L/QvtC30L3QsNGC0Ywg0YLQtdCz0LhcIiB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIEZvciBleHBhbmRfdG9fdG9waWMsIHBhcnNlIEpTT04gdG8gZXh0cmFjdCB0aXRsZSArIGNvbnRlbnRcbiAgICBpZiAobW9kZSA9PT0gXCJleHBhbmRfdG9fdG9waWNcIikge1xuICAgICAgdHJ5IHtcbiAgICAgICAgbGV0IGNsZWFuSnNvbiA9IGdlbmVyYXRlZENvbnRlbnQudHJpbSgpO1xuICAgICAgICBjbGVhbkpzb24gPSBjbGVhbkpzb24ucmVwbGFjZSgvXmBgYCg/Ompzb24pP1xccyovaSwgXCJcIikucmVwbGFjZSgvXFxzKmBgYCQvLCBcIlwiKTtcbiAgICAgICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShjbGVhbkpzb24pO1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICB0aXRsZTogKHBhcnNlZC50aXRsZSB8fCBcIlwiKS50cmltKCksXG4gICAgICAgICAgICBjb250ZW50OiAocGFyc2VkLmNvbnRlbnQgfHwgXCJcIikudHJpbSgpLFxuICAgICAgICAgICAgc3VnZ2VzdGVkVGFnczogQXJyYXkuaXNBcnJheShwYXJzZWQudGFncykgPyBwYXJzZWQudGFncyA6IFtdLFxuICAgICAgICAgICAgbW9kZSxcbiAgICAgICAgICAgIHByaWNlLFxuICAgICAgICAgICAgbWVzc2FnZTogTUVTU0FHRVNbbW9kZV0sXG4gICAgICAgICAgfSksXG4gICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBjb25zdCBsaW5lcyA9IGdlbmVyYXRlZENvbnRlbnQudHJpbSgpLnNwbGl0KFwiXFxuXCIpO1xuICAgICAgICBjb25zdCBmYWxsYmFja1RpdGxlID0gbGluZXNbMF0ucmVwbGFjZSgvXltcIiMqXSt8W1wiIypdKyQvZywgXCJcIikudHJpbSgpO1xuICAgICAgICBjb25zdCBmYWxsYmFja0NvbnRlbnQgPSBsaW5lcy5zbGljZSgxKS5qb2luKFwiXFxuXCIpLnRyaW0oKTtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgdGl0bGU6IGZhbGxiYWNrVGl0bGUsXG4gICAgICAgICAgICBjb250ZW50OiBmYWxsYmFja0NvbnRlbnQgfHwgZ2VuZXJhdGVkQ29udGVudC50cmltKCksXG4gICAgICAgICAgICBzdWdnZXN0ZWRUYWdzOiBbXSxcbiAgICAgICAgICAgIG1vZGUsXG4gICAgICAgICAgICBwcmljZSxcbiAgICAgICAgICAgIG1lc3NhZ2U6IE1FU1NBR0VTW21vZGVdLFxuICAgICAgICAgIH0pLFxuICAgICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgcmVzdWx0OiBnZW5lcmF0ZWRDb250ZW50LnRyaW0oKSxcbiAgICAgICAgbW9kZSxcbiAgICAgICAgcHJpY2UsXG4gICAgICAgIG1lc3NhZ2U6IE1FU1NBR0VTW21vZGVdLFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XG4gICAgY29uc29sZS5lcnJvcihcIltmb3J1bS1haS1oZWxwZXJdIEVycm9yOlwiLCBlcnJvcik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCLQndC10LjQt9Cy0LXRgdGC0L3QsNGPINC+0YjQuNCx0LrQsFwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBtZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FDRTtBQUNKO0FBWUEsTUFBTSxrQkFBa0I7QUFFeEIsTUFBTSxnQkFBc0M7RUFDMUMsYUFBYTtFQUNiLGNBQWM7RUFDZCxpQkFBaUI7RUFDakIsY0FBYztFQUNkLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLFdBQVc7QUFDYjtBQUVBLE1BQU0saUJBQXVDO0VBQzNDLGFBQWE7RUFDYixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGNBQWM7RUFDZCxjQUFjO0VBQ2Qsa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQixXQUFXO0FBQ2I7QUFFQSxNQUFNLFdBQWlDO0VBQ3JDLGFBQWE7RUFDYixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGNBQWM7RUFDZCxjQUFjO0VBQ2Qsa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQixXQUFXO0FBQ2I7QUFFQSxNQUFNLGFBQWE7RUFDakI7RUFBVztFQUFXO0VBQVc7RUFBVztFQUM1QztFQUFXO0VBQVc7RUFBVztFQUFXO0VBQzVDO0VBQVc7RUFBVztFQUFXO0VBQVc7RUFDNUM7RUFBVztFQUFXO0VBQVc7RUFBVztDQUM3QztBQUVELFNBQVMsYUFDUCxJQUFVLEVBQ1YsSUFBd0IsRUFDeEIsVUFBOEIsRUFDOUIsWUFBZ0MsRUFDaEMsV0FBK0I7RUFFL0IsTUFBTSxlQUFlLGFBQWEsQ0FBQyxrQkFBa0IsRUFBRSxXQUFXLENBQUMsQ0FBQyxHQUFHO0VBQ3ZFLE1BQU0saUJBQWlCLGVBQ25CLENBQUMsaUJBQWlCLEVBQUUsYUFBYSxPQUFPLENBQUMsWUFBWSxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUN4RTtFQUVKLE9BQVE7SUFDTixLQUFLO01BQ0gsT0FBTztRQUNMLGNBQWMsQ0FBQzs7Ozs7Ozs7Ozs7O21FQVk0QyxDQUFDO1FBQzVELFlBQVksQ0FBQywyQ0FBMkMsRUFBRSxLQUFLLENBQUM7TUFDbEU7SUFFRixLQUFLO01BQ0gsT0FBTztRQUNMLGNBQWMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7bURBNkI0QixDQUFDO1FBQzVDLFlBQVksQ0FBQyxvREFBb0QsRUFBRSxLQUFLLENBQUM7TUFDM0U7SUFFRixLQUFLO01BQ0gsT0FBTztRQUNMLGNBQWMsQ0FBQzs7Ozs7Ozs7Ozs7OzhDQVl1QixDQUFDO1FBQ3ZDLFlBQVksQ0FBQyxFQUFFLGFBQWEsRUFBRSxlQUFlLDhDQUE4QyxFQUFFLEtBQUssQ0FBQztNQUNyRztJQUVGLEtBQUs7TUFDSCxPQUFPO1FBQ0wsY0FBYyxDQUFDOzs7Ozs7Ozs7OztrREFXMkIsQ0FBQztRQUMzQyxZQUFZLENBQUMsc0JBQXNCLEVBQUUsS0FBSyxDQUFDO01BQzdDO0lBRUYsS0FBSztNQUNILE9BQU87UUFDTCxjQUFjLENBQUM7Ozs7Ozs7Ozs7bURBVTRCLENBQUM7UUFDNUMsWUFBWSxDQUFDLEVBQUUsYUFBYSxFQUFFLGVBQWUsd0JBQXdCLEVBQUUsZUFBZSxvQkFBb0IsQ0FBQztNQUM3RztJQUVGLEtBQUs7TUFDSCxPQUFPO1FBQ0wsY0FBYyxDQUFDOzs7Ozs7Ozs7Z0RBU3lCLENBQUM7UUFDekMsWUFBWSxDQUFDLEVBQUUsYUFBYSxFQUFFLGVBQWUsNEJBQTRCLEVBQUUsZUFBZSxxQkFBcUIsNkJBQTZCLENBQUM7TUFDL0k7SUFFRixLQUFLO01BQ0gsT0FBTztRQUNMLGNBQWMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7d0VBb0JpRCxDQUFDO1FBQ2pFLFlBQVksQ0FBQyxpQkFBaUIsRUFBRSxjQUFjLEdBQUcsa0JBQWtCLEVBQUUsUUFBUSxnQkFBZ0Isc0JBQXNCLENBQUM7TUFDdEg7SUFFRjtNQUNFLHdCQUF3QjtNQUN4QixPQUFPO1FBQ0wsY0FBYyxDQUFDOzs7Ozs7Ozs7NkNBU3NCLENBQUM7UUFDdEMsWUFBWSxDQUFDLEVBQUUsYUFBYSxFQUFFLGVBQWUsNkNBQTZDLEVBQUUsS0FBSyxDQUFDO01BQ3BHO0VBQ0o7QUFDRjtBQUVBLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVksV0FBVyxZQUFZO01BQ3RDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF5QixJQUNqRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFdBQVcsYUFDZixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsaUJBQ2IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBR2YsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBRWpFLElBQUksYUFBYSxDQUFDLE1BQU0sUUFBUSxLQUFLO01BQ25DLFFBQVEsS0FBSyxDQUFDLGVBQWU7TUFDN0IsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTZCLElBQ3JEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sVUFBVSxLQUFLLE1BQU0sQ0FBQyxHQUFHO0lBQy9CLE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxZQUFZLEVBQUUsV0FBVyxFQUFFLE9BQU8sRUFBRSxHQUFHLE1BQU0sSUFBSSxJQUFJO0lBU3JGLFFBQVEsR0FBRyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxPQUFPLEVBQUUsUUFBUSxVQUFVLEVBQUUsTUFBTSxVQUFVLEVBQUUsQ0FBQztJQUUzRixNQUFNLGdCQUFnQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLGVBQWU7TUFDbEIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSx3Q0FBd0M7SUFDeEMsTUFBTSxjQUFjLGFBQWEsQ0FBQyxLQUFLO0lBQ3ZDLElBQUksQ0FBQyxhQUFhO01BQ2hCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTyxDQUFDLG1CQUFtQixFQUFFLEtBQUssQ0FBQztNQUFDLElBQ3JEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxHQUFHLE1BQU0sU0FDN0IsSUFBSSxDQUFDLGtCQUNMLE1BQU0sQ0FBQyx3QkFDUCxFQUFFLENBQUMsUUFBUSxhQUNYLFdBQVc7SUFFZCxJQUFJLFdBQVcsQ0FBQyxRQUFRLFNBQVMsRUFBRTtNQUNqQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBaUMsSUFDekQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxRQUFRLFNBQVMsYUFBYSxjQUFjLENBQUMsS0FBSztJQUN4RCxNQUFNLGFBQWEsVUFBVTtJQUU3QixJQUFJLFVBQXNDO0lBQzFDLElBQUksYUFBYTtJQUVqQixJQUFJLENBQUMsWUFBWTtNQUNmLGdCQUFnQjtNQUNoQixNQUFNLEVBQUUsTUFBTSxXQUFXLEVBQUUsR0FBRyxNQUFNLFNBQ2pDLElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQyxXQUNQLEVBQUUsQ0FBQyxXQUFXLFNBQ2QsV0FBVztNQUNkLFVBQVU7TUFFVixJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSSxPQUFPO1FBQzlDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztVQUFtQyxVQUFVO1VBQU8sU0FBUyxTQUFTLFdBQVc7UUFBRSxJQUMzRztVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSxpQkFBaUI7TUFDakIsYUFBYSxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSTtNQUN0QyxNQUFNLEVBQUUsT0FBTyxZQUFZLEVBQUUsR0FBRyxNQUFNLFNBQ25DLElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztRQUFFLFNBQVM7TUFBVyxHQUM3QixFQUFFLENBQUMsV0FBVztNQUVqQixJQUFJLGNBQWM7UUFDaEIsTUFBTSxJQUFJLE1BQU07TUFDbEI7TUFFQSxrQkFBa0I7TUFDbEIsTUFBTSxTQUFTLElBQUksQ0FBQyx3QkFBd0IsTUFBTSxDQUFDO1FBQ2pELFNBQVM7UUFDVCxRQUFRLENBQUM7UUFDVCxlQUFlO1FBQ2YsTUFBTTtRQUNOLGFBQWEsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUM7UUFDbEQsVUFBVTtVQUFFO1VBQU07UUFBVztNQUMvQjtJQUNGO0lBRUEsTUFBTSxFQUFFLFlBQVksRUFBRSxVQUFVLEVBQUUsR0FBRyxhQUFhLE1BQU0sTUFBTSxZQUFZLGNBQWM7SUFFeEYseUJBQXlCO0lBQ3pCLE1BQU0sU0FBUyxDQUFDLG1EQUFtRCxFQUFFLGdCQUFnQixvQkFBb0IsQ0FBQztJQUUxRyxNQUFNLFdBQVcsTUFBTSxNQUFNLFFBQVE7TUFDbkMsUUFBUTtNQUNSLFNBQVM7UUFDUCxnQkFBZ0I7UUFDaEIsZUFBZSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUM7UUFDeEMsa0JBQWtCO01BQ3BCO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztRQUNuQixPQUFPO1FBQ1AsVUFBVTtVQUNSO1lBQUUsTUFBTTtZQUFVLFNBQVM7VUFBYTtVQUN4QztZQUFFLE1BQU07WUFBUSxTQUFTO1VBQVc7U0FDckM7UUFDRCxhQUFhLFNBQVMsaUJBQWlCLFNBQVMsY0FBYyxNQUFNO01BQ3RFO0lBQ0Y7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDJDQUEyQyxFQUFFLFNBQVMsTUFBTSxDQUFDLENBQUM7SUFFM0UsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLHFDQUFxQztNQUNyQyxJQUFJLENBQUMsY0FBYyxTQUFTO1FBQzFCLE1BQU0sU0FDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7VUFBRSxTQUFTLFFBQVEsT0FBTztRQUFDLEdBQ2xDLEVBQUUsQ0FBQyxXQUFXO01BQ25CO01BRUEsTUFBTSxZQUFZLE1BQU0sU0FBUyxJQUFJO01BQ3JDLFFBQVEsS0FBSyxDQUFDLHdDQUF3QyxTQUFTLE1BQU0sRUFBRTtNQUN2RSxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sU0FBUyxNQUFNLFNBQVMsSUFBSTtJQUNsQyxNQUFNLG1CQUFtQixPQUFPLE9BQU8sRUFBRSxDQUFDLEVBQUUsRUFBRSxTQUFTO0lBRXZELElBQUksQ0FBQyxrQkFBa0I7TUFDckIsSUFBSSxDQUFDLGNBQWMsU0FBUztRQUMxQixNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1VBQUUsU0FBUyxRQUFRLE9BQU87UUFBQyxHQUNsQyxFQUFFLENBQUMsV0FBVztNQUNuQjtNQUNBLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEscURBQXFEO0lBQ3JELElBQUksU0FBUyxhQUFhO01BQ3hCLElBQUk7UUFDRixJQUFJLFlBQVksaUJBQWlCLElBQUk7UUFDckMseUJBQXlCO1FBQ3pCLFlBQVksVUFBVSxPQUFPLENBQUMsZ0JBQWdCLElBQUksT0FBTyxDQUFDLFdBQVcsSUFBSSxJQUFJO1FBQzdFLDZCQUE2QjtRQUM3QixNQUFNLFdBQVcsVUFBVSxPQUFPLENBQUM7UUFDbkMsTUFBTSxTQUFTLFVBQVUsV0FBVyxDQUFDO1FBQ3JDLElBQUksYUFBYSxDQUFDLEtBQUssV0FBVyxDQUFDLEdBQUc7VUFDcEMsWUFBWSxVQUFVLFNBQVMsQ0FBQyxVQUFVLFNBQVM7UUFDckQ7UUFDQSxvQkFBb0I7UUFDcEIsWUFBWSxVQUNULE9BQU8sQ0FBQyxVQUFVLEtBQ2xCLE9BQU8sQ0FBQyxvQkFBb0I7UUFFL0IsTUFBTSxPQUE0QyxLQUFLLEtBQUssQ0FBQztRQUM3RCxRQUFRLEdBQUcsQ0FBQyxDQUFDLG1DQUFtQyxFQUFFLEtBQUssTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBRXZFLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxTQUFTLEtBQUssTUFBTSxLQUFLLEdBQUc7VUFDN0MsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7WUFBRSxTQUFTO1lBQU0sTUFBTSxFQUFFO1lBQUU7WUFBTSxTQUFTO1VBQXVCLElBQ2hGO1lBQUUsU0FBUztjQUFFLEdBQUcsV0FBVztjQUFFLGdCQUFnQjtZQUFtQjtVQUFFO1FBRXRFO1FBRUEsTUFBTSxnQkFBMEIsRUFBRTtRQUNsQyxNQUFNLGNBQThFLEVBQUU7UUFFdEYsS0FBSyxNQUFNLE9BQU8sS0FBSyxLQUFLLENBQUMsR0FBRyxHQUFJO1VBQ2xDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksT0FBTyxFQUFFO1VBRS9CLE1BQU0sT0FBTyxJQUFJLElBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsSUFBSSxLQUFLLENBQUMsR0FBRztVQUN4RSxNQUFNLFNBQVMsSUFBSSxPQUFPLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxHQUFHO1VBQzNDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUTtVQUV0Qiw4QkFBOEI7VUFDOUIsTUFBTSxFQUFFLE1BQU0sUUFBUSxFQUFFLEdBQUcsTUFBTSxTQUM5QixJQUFJLENBQUMsY0FDTCxNQUFNLENBQUMsNEJBQ1AsRUFBRSxDQUFDLFFBQVEsTUFDWCxXQUFXO1VBRWQsSUFBSSxVQUFVO1lBQ1osY0FBYyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQzlCLFlBQVksSUFBSSxDQUFDO1lBQ2pCLHdCQUF3QjtZQUN4QixNQUFNLFNBQ0gsSUFBSSxDQUFDLGNBQ0wsTUFBTSxDQUFDO2NBQUUsYUFBYSxBQUFDLFNBQWlCLFdBQVcsR0FBRyxBQUFDLFNBQWlCLFdBQVcsR0FBRyxJQUFJO1lBQUUsR0FDNUYsRUFBRSxDQUFDLE1BQU0sU0FBUyxFQUFFO1VBQ3pCLE9BQU87WUFDTCxNQUFNLFFBQVEsVUFBVSxDQUFDLEtBQUssS0FBSyxDQUFDLEtBQUssTUFBTSxLQUFLLFdBQVcsTUFBTSxFQUFFO1lBQ3ZFLE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLFFBQVEsRUFBRSxHQUFHLE1BQU0sU0FDN0MsSUFBSSxDQUFDLGNBQ0wsTUFBTSxDQUFDO2NBQUUsTUFBTTtjQUFNLFNBQVM7Y0FBUTtjQUFPLGFBQWE7WUFBRSxHQUM1RCxNQUFNLENBQUMsNEJBQ1AsTUFBTTtZQUVULElBQUksVUFBVTtjQUNaLFFBQVEsS0FBSyxDQUFDLENBQUMsc0NBQXNDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRTtjQUNqRTtZQUNGO1lBQ0EsY0FBYyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQzVCLFlBQVksSUFBSSxDQUFDO1VBQ25CO1FBQ0Y7UUFFQSxxQkFBcUI7UUFDckIsSUFBSSxXQUFXLGNBQWMsTUFBTSxHQUFHLEdBQUc7VUFDdkMsbUNBQW1DO1VBQ25DLE1BQU0sRUFBRSxNQUFNLGFBQWEsRUFBRSxHQUFHLE1BQU0sU0FDbkMsSUFBSSxDQUFDLG9CQUNMLE1BQU0sQ0FBQyxVQUNQLEVBQUUsQ0FBQyxZQUFZO1VBRWxCLE1BQU0saUJBQWlCLElBQUksSUFBSSxDQUFDLGlCQUFpQixFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsSUFBVyxFQUFFLE1BQU07VUFDN0UsTUFBTSxXQUFXLGNBQ2QsTUFBTSxDQUFDLENBQUEsS0FBTSxDQUFDLGVBQWUsR0FBRyxDQUFDLEtBQ2pDLEtBQUssQ0FBQyxHQUFHLElBQUksZUFBZSxJQUFJLEVBQUUsNkJBQTZCO1dBQy9ELEdBQUcsQ0FBQyxDQUFBLFNBQVUsQ0FBQztjQUFFLFVBQVU7Y0FBUztZQUFPLENBQUM7VUFFL0MsSUFBSSxTQUFTLE1BQU0sR0FBRyxHQUFHO1lBQ3ZCLE1BQU0sRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FDaEMsSUFBSSxDQUFDLG9CQUNMLE1BQU0sQ0FBQztZQUNWLElBQUksV0FBVztjQUNiLFFBQVEsS0FBSyxDQUFDLHlDQUF5QztZQUN6RDtVQUNGO1VBQ0EsUUFBUSxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBRSxTQUFTLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxRQUFRLENBQUM7UUFDekY7UUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUNiLFNBQVM7VUFDVCxNQUFNO1VBQ047VUFDQSxTQUFTLFFBQVEsQ0FBQyxLQUFLO1FBQ3pCLElBQ0E7VUFBRSxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFdEUsRUFBRSxPQUFPLFVBQVU7UUFDakIsUUFBUSxLQUFLLENBQUMsNENBQTRDLFVBQVUsUUFBUTtRQUM1RSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLFNBQVM7VUFBTSxNQUFNLEVBQUU7VUFBRTtVQUFNLFNBQVM7UUFBNkIsSUFDdEY7VUFBRSxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFdEU7SUFDRjtJQUVBLDZEQUE2RDtJQUM3RCxJQUFJLFNBQVMsbUJBQW1CO01BQzlCLElBQUk7UUFDRixJQUFJLFlBQVksaUJBQWlCLElBQUk7UUFDckMsWUFBWSxVQUFVLE9BQU8sQ0FBQyxxQkFBcUIsSUFBSSxPQUFPLENBQUMsV0FBVztRQUMxRSxNQUFNLFNBQVMsS0FBSyxLQUFLLENBQUM7UUFDMUIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsT0FBTyxDQUFDLE9BQU8sS0FBSyxJQUFJLEVBQUUsRUFBRSxJQUFJO1VBQ2hDLFNBQVMsQ0FBQyxPQUFPLE9BQU8sSUFBSSxFQUFFLEVBQUUsSUFBSTtVQUNwQyxlQUFlLE1BQU0sT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJLE9BQU8sSUFBSSxHQUFHLEVBQUU7VUFDNUQ7VUFDQTtVQUNBLFNBQVMsUUFBUSxDQUFDLEtBQUs7UUFDekIsSUFDQTtVQUFFLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUV0RSxFQUFFLE9BQU07UUFDTixNQUFNLFFBQVEsaUJBQWlCLElBQUksR0FBRyxLQUFLLENBQUM7UUFDNUMsTUFBTSxnQkFBZ0IsS0FBSyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsb0JBQW9CLElBQUksSUFBSTtRQUNuRSxNQUFNLGtCQUFrQixNQUFNLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLElBQUk7UUFDdEQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsT0FBTztVQUNQLFNBQVMsbUJBQW1CLGlCQUFpQixJQUFJO1VBQ2pELGVBQWUsRUFBRTtVQUNqQjtVQUNBO1VBQ0EsU0FBUyxRQUFRLENBQUMsS0FBSztRQUN6QixJQUNBO1VBQUUsU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRXRFO0lBQ0Y7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxRQUFRLGlCQUFpQixJQUFJO01BQzdCO01BQ0E7TUFDQSxTQUFTLFFBQVEsQ0FBQyxLQUFLO0lBQ3pCLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEUsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDRCQUE0QjtJQUMxQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
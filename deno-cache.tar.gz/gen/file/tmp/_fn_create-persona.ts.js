const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { personaId, trackId, name, description, avatarUrl, styleTags, isPublic } = await req.json();
    console.log(`Creating persona for user ${user.id}, track ${trackId}`);
    if (!trackId || !name) {
      return new Response(JSON.stringify({
        error: "Missing required fields: trackId, name"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Get track info to extract taskId and audioId
    const { data: track, error: trackError } = await supabaseClient.from("tracks").select("id, title, description, status, suno_audio_id").eq("id", trackId).eq("user_id", user.id).single();
    if (trackError || !track) {
      console.error("Track not found:", trackError);
      return new Response(JSON.stringify({
        error: "Трек не найден"
      }), {
        status: 404,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Allow "ready" or "completed" status
    if (track.status !== "ready" && track.status !== "completed") {
      return new Response(JSON.stringify({
        error: "Трек должен быть полностью сгенерирован для создания персоны"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Extract taskId from track description (stored in format [task_id: {taskId}])
    const taskIdMatch = track.description?.match(/\[task_id:\s*([^\]]+)\]/);
    const taskId = taskIdMatch ? taskIdMatch[1].trim() : null;
    // Get audioId from track (stored as suno_audio_id)
    const audioId = track.suno_audio_id;
    if (!taskId || !audioId) {
      console.error(`Missing Suno IDs for track ${trackId}: taskId=${taskId}, audioId=${audioId}`);
      return new Response(JSON.stringify({
        error: "Для этого трека недоступна функция создания персоны. Трек был создан до добавления этой функции."
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Found Suno IDs: taskId=${taskId}, audioId=${audioId}`);
    // Call Suno API to create persona
    const sunoPayload = {
      taskId,
      audioId,
      name: name.trim(),
      description: description?.trim() || `Голос из трека "${track.title}"`
    };
    console.log("Sending to Suno API:", JSON.stringify(sunoPayload));
    const sunoResponse = await fetch(`${SUNO_API_BASE}/api/v1/generate/generate-persona`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify(sunoPayload)
    });
    const sunoData = await sunoResponse.json();
    console.log("Suno API response:", JSON.stringify(sunoData));
    if (!sunoResponse.ok || sunoData.code !== 200) {
      const errorMessage = sunoData.msg || "Failed to create persona";
      console.error(`Suno API error: ${errorMessage}`);
      // Update persona status to failed if it exists
      if (personaId) {
        await supabaseClient.from("personas").update({
          status: "failed"
        }).eq("id", personaId).eq("user_id", user.id);
      }
      return new Response(JSON.stringify({
        error: `Ошибка Suno: ${errorMessage}`
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Extract persona ID from response
    const sunoPersonaId = sunoData.data?.personaId || sunoData.data?.id;
    if (!sunoPersonaId) {
      console.error("No persona ID in Suno response:", sunoData);
      return new Response(JSON.stringify({
        error: "Suno не вернул ID персоны"
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Persona created with Suno ID: ${sunoPersonaId}`);
    // If personaId provided, update existing record
    // Otherwise create new record
    let savedPersona;
    if (personaId) {
      const { data, error } = await supabaseClient.from("personas").update({
        suno_persona_id: sunoPersonaId,
        status: "ready",
        updated_at: new Date().toISOString()
      }).eq("id", personaId).eq("user_id", user.id).select().single();
      if (error) {
        console.error("Failed to update persona:", error);
      }
      savedPersona = data;
    } else {
      const { data, error } = await supabaseClient.from("personas").insert({
        user_id: user.id,
        name: name.trim(),
        avatar_url: avatarUrl || null,
        source_track_id: trackId,
        clip_start_time: 0,
        clip_end_time: 30,
        description: description?.trim() || null,
        style_tags: styleTags?.trim() || null,
        is_public: isPublic || false,
        suno_persona_id: sunoPersonaId,
        status: "ready"
      }).select().single();
      if (error) {
        console.error("Failed to create persona record:", error);
      }
      savedPersona = data;
    }
    return new Response(JSON.stringify({
      success: true,
      personaId: savedPersona?.id,
      sunoPersonaId,
      message: "Персона успешно создана"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in create-persona:", error);
    return new Response(JSON.stringify({
      error: "Произошла непредвиденная ошибка"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9jcmVhdGUtcGVyc29uYS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuY29uc3QgU1VOT19BUElfS0VZID0gRGVuby5lbnYuZ2V0KFwiU1VOT19BUElfS0VZXCIpO1xuY29uc3QgU1VOT19BUElfQkFTRSA9IFwiaHR0cHM6Ly9hcGlib3guZXJ3ZWltYS5haVwiO1xuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk5vIGF1dGhvcml6YXRpb24gaGVhZGVyXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZUNsaWVudCA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikgPz8gXCJcIixcbiAgICAgIHsgZ2xvYmFsOiB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYXV0aEhlYWRlciB9IH0gfVxuICAgICk7XG5cbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9LCBlcnJvcjogdXNlckVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudC5hdXRoLmdldFVzZXIoKTtcbiAgICBpZiAodXNlckVycm9yIHx8ICF1c2VyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgeyBcbiAgICAgIHBlcnNvbmFJZCxcbiAgICAgIHRyYWNrSWQsIFxuICAgICAgbmFtZSwgXG4gICAgICBkZXNjcmlwdGlvbixcbiAgICAgIGF2YXRhclVybCxcbiAgICAgIHN0eWxlVGFncyxcbiAgICAgIGlzUHVibGljXG4gICAgfSA9IGF3YWl0IHJlcS5qc29uKCk7XG5cbiAgICBjb25zb2xlLmxvZyhgQ3JlYXRpbmcgcGVyc29uYSBmb3IgdXNlciAke3VzZXIuaWR9LCB0cmFjayAke3RyYWNrSWR9YCk7XG5cbiAgICBpZiAoIXRyYWNrSWQgfHwgIW5hbWUpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiTWlzc2luZyByZXF1aXJlZCBmaWVsZHM6IHRyYWNrSWQsIG5hbWVcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIEdldCB0cmFjayBpbmZvIHRvIGV4dHJhY3QgdGFza0lkIGFuZCBhdWRpb0lkXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjaywgZXJyb3I6IHRyYWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLnNlbGVjdChcImlkLCB0aXRsZSwgZGVzY3JpcHRpb24sIHN0YXR1cywgc3Vub19hdWRpb19pZFwiKVxuICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZClcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICh0cmFja0Vycm9yIHx8ICF0cmFjaykge1xuICAgICAgY29uc29sZS5lcnJvcihcIlRyYWNrIG5vdCBmb3VuZDpcIiwgdHJhY2tFcnJvcik7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCi0YDQtdC6INC90LUg0L3QsNC50LTQtdC9XCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDQsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBBbGxvdyBcInJlYWR5XCIgb3IgXCJjb21wbGV0ZWRcIiBzdGF0dXNcbiAgICBpZiAodHJhY2suc3RhdHVzICE9PSBcInJlYWR5XCIgJiYgdHJhY2suc3RhdHVzICE9PSBcImNvbXBsZXRlZFwiKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCi0YDQtdC6INC00L7Qu9C20LXQvSDQsdGL0YLRjCDQv9C+0LvQvdC+0YHRgtGM0Y4g0YHQs9C10L3QtdGA0LjRgNC+0LLQsNC9INC00LvRjyDRgdC+0LfQtNCw0L3QuNGPINC/0LXRgNGB0L7QvdGLXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBFeHRyYWN0IHRhc2tJZCBmcm9tIHRyYWNrIGRlc2NyaXB0aW9uIChzdG9yZWQgaW4gZm9ybWF0IFt0YXNrX2lkOiB7dGFza0lkfV0pXG4gICAgY29uc3QgdGFza0lkTWF0Y2ggPSB0cmFjay5kZXNjcmlwdGlvbj8ubWF0Y2goL1xcW3Rhc2tfaWQ6XFxzKihbXlxcXV0rKVxcXS8pO1xuICAgIGNvbnN0IHRhc2tJZCA9IHRhc2tJZE1hdGNoID8gdGFza0lkTWF0Y2hbMV0udHJpbSgpIDogbnVsbDtcblxuICAgIC8vIEdldCBhdWRpb0lkIGZyb20gdHJhY2sgKHN0b3JlZCBhcyBzdW5vX2F1ZGlvX2lkKVxuICAgIGNvbnN0IGF1ZGlvSWQgPSB0cmFjay5zdW5vX2F1ZGlvX2lkO1xuXG4gICAgaWYgKCF0YXNrSWQgfHwgIWF1ZGlvSWQpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYE1pc3NpbmcgU3VubyBJRHMgZm9yIHRyYWNrICR7dHJhY2tJZH06IHRhc2tJZD0ke3Rhc2tJZH0sIGF1ZGlvSWQ9JHthdWRpb0lkfWApO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQlNC70Y8g0Y3RgtC+0LPQviDRgtGA0LXQutCwINC90LXQtNC+0YHRgtGD0L/QvdCwINGE0YPQvdC60YbQuNGPINGB0L7Qt9C00LDQvdC40Y8g0L/QtdGA0YHQvtC90YsuINCi0YDQtdC6INCx0YvQuyDRgdC+0LfQtNCw0L0g0LTQviDQtNC+0LHQsNCy0LvQtdC90LjRjyDRjdGC0L7QuSDRhNGD0L3QutGG0LjQuC5cIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBGb3VuZCBTdW5vIElEczogdGFza0lkPSR7dGFza0lkfSwgYXVkaW9JZD0ke2F1ZGlvSWR9YCk7XG5cbiAgICAvLyBDYWxsIFN1bm8gQVBJIHRvIGNyZWF0ZSBwZXJzb25hXG4gICAgY29uc3Qgc3Vub1BheWxvYWQgPSB7XG4gICAgICB0YXNrSWQsXG4gICAgICBhdWRpb0lkLFxuICAgICAgbmFtZTogbmFtZS50cmltKCksXG4gICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24/LnRyaW0oKSB8fCBg0JPQvtC70L7RgSDQuNC3INGC0YDQtdC60LAgXCIke3RyYWNrLnRpdGxlfVwiYFxuICAgIH07XG5cbiAgICBjb25zb2xlLmxvZyhcIlNlbmRpbmcgdG8gU3VubyBBUEk6XCIsIEpTT04uc3RyaW5naWZ5KHN1bm9QYXlsb2FkKSk7XG5cbiAgICBjb25zdCBzdW5vUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtTVU5PX0FQSV9CQVNFfS9hcGkvdjEvZ2VuZXJhdGUvZ2VuZXJhdGUtcGVyc29uYWAsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NVTk9fQVBJX0tFWX1gLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHN1bm9QYXlsb2FkKSxcbiAgICB9KTtcblxuICAgIGNvbnN0IHN1bm9EYXRhID0gYXdhaXQgc3Vub1Jlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhcIlN1bm8gQVBJIHJlc3BvbnNlOlwiLCBKU09OLnN0cmluZ2lmeShzdW5vRGF0YSkpO1xuXG4gICAgaWYgKCFzdW5vUmVzcG9uc2Uub2sgfHwgc3Vub0RhdGEuY29kZSAhPT0gMjAwKSB7XG4gICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBzdW5vRGF0YS5tc2cgfHwgXCJGYWlsZWQgdG8gY3JlYXRlIHBlcnNvbmFcIjtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYFN1bm8gQVBJIGVycm9yOiAke2Vycm9yTWVzc2FnZX1gKTtcbiAgICAgIFxuICAgICAgLy8gVXBkYXRlIHBlcnNvbmEgc3RhdHVzIHRvIGZhaWxlZCBpZiBpdCBleGlzdHNcbiAgICAgIGlmIChwZXJzb25hSWQpIHtcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgICAuZnJvbShcInBlcnNvbmFzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJmYWlsZWRcIiB9KVxuICAgICAgICAgIC5lcShcImlkXCIsIHBlcnNvbmFJZClcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBg0J7RiNC40LHQutCwIFN1bm86ICR7ZXJyb3JNZXNzYWdlfWAgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBFeHRyYWN0IHBlcnNvbmEgSUQgZnJvbSByZXNwb25zZVxuICAgIGNvbnN0IHN1bm9QZXJzb25hSWQgPSBzdW5vRGF0YS5kYXRhPy5wZXJzb25hSWQgfHwgc3Vub0RhdGEuZGF0YT8uaWQ7XG4gICAgXG4gICAgaWYgKCFzdW5vUGVyc29uYUlkKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiTm8gcGVyc29uYSBJRCBpbiBTdW5vIHJlc3BvbnNlOlwiLCBzdW5vRGF0YSk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlN1bm8g0L3QtSDQstC10YDQvdGD0LsgSUQg0L/QtdGA0YHQvtC90YtcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBQZXJzb25hIGNyZWF0ZWQgd2l0aCBTdW5vIElEOiAke3N1bm9QZXJzb25hSWR9YCk7XG5cbiAgICAvLyBJZiBwZXJzb25hSWQgcHJvdmlkZWQsIHVwZGF0ZSBleGlzdGluZyByZWNvcmRcbiAgICAvLyBPdGhlcndpc2UgY3JlYXRlIG5ldyByZWNvcmRcbiAgICBsZXQgc2F2ZWRQZXJzb25hO1xuICAgIFxuICAgIGlmIChwZXJzb25hSWQpIHtcbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgIC5mcm9tKFwicGVyc29uYXNcIilcbiAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgc3Vub19wZXJzb25hX2lkOiBzdW5vUGVyc29uYUlkLFxuICAgICAgICAgIHN0YXR1czogXCJyZWFkeVwiLFxuICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxuICAgICAgICB9KVxuICAgICAgICAuZXEoXCJpZFwiLCBwZXJzb25hSWQpXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgICAgLnNlbGVjdCgpXG4gICAgICAgIC5zaW5nbGUoKTtcbiAgICAgIFxuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIHBlcnNvbmE6XCIsIGVycm9yKTtcbiAgICAgIH1cbiAgICAgIHNhdmVkUGVyc29uYSA9IGRhdGE7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgIC5mcm9tKFwicGVyc29uYXNcIilcbiAgICAgICAgLmluc2VydCh7XG4gICAgICAgICAgdXNlcl9pZDogdXNlci5pZCxcbiAgICAgICAgICBuYW1lOiBuYW1lLnRyaW0oKSxcbiAgICAgICAgICBhdmF0YXJfdXJsOiBhdmF0YXJVcmwgfHwgbnVsbCxcbiAgICAgICAgICBzb3VyY2VfdHJhY2tfaWQ6IHRyYWNrSWQsXG4gICAgICAgICAgY2xpcF9zdGFydF90aW1lOiAwLFxuICAgICAgICAgIGNsaXBfZW5kX3RpbWU6IDMwLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbj8udHJpbSgpIHx8IG51bGwsXG4gICAgICAgICAgc3R5bGVfdGFnczogc3R5bGVUYWdzPy50cmltKCkgfHwgbnVsbCxcbiAgICAgICAgICBpc19wdWJsaWM6IGlzUHVibGljIHx8IGZhbHNlLFxuICAgICAgICAgIHN1bm9fcGVyc29uYV9pZDogc3Vub1BlcnNvbmFJZCxcbiAgICAgICAgICBzdGF0dXM6IFwicmVhZHlcIlxuICAgICAgICB9KVxuICAgICAgICAuc2VsZWN0KClcbiAgICAgICAgLnNpbmdsZSgpO1xuICAgICAgXG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBjcmVhdGUgcGVyc29uYSByZWNvcmQ6XCIsIGVycm9yKTtcbiAgICAgIH1cbiAgICAgIHNhdmVkUGVyc29uYSA9IGRhdGE7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICBwZXJzb25hSWQ6IHNhdmVkUGVyc29uYT8uaWQsXG4gICAgICAgIHN1bm9QZXJzb25hSWQsXG4gICAgICAgIG1lc3NhZ2U6IFwi0J/QtdGA0YHQvtC90LAg0YPRgdC/0LXRiNC90L4g0YHQvtC30LTQsNC90LBcIiBcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIGNyZWF0ZS1wZXJzb25hOlwiLCBlcnJvcik7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0J/RgNC+0LjQt9C+0YjQu9CwINC90LXQv9GA0LXQtNCy0LjQtNC10L3QvdCw0Y8g0L7RiNC40LHQutCwXCIgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBQ25GLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDbEMsTUFBTSxnQkFBZ0I7QUFFdEIsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEwQixJQUNsRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGlCQUFpQixhQUNyQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFDckM7TUFBRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQUU7SUFHdkQsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sZUFBZSxJQUFJLENBQUMsT0FBTztJQUM5RSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFlLElBQ3ZDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sRUFDSixTQUFTLEVBQ1QsT0FBTyxFQUNQLElBQUksRUFDSixXQUFXLEVBQ1gsU0FBUyxFQUNULFNBQVMsRUFDVCxRQUFRLEVBQ1QsR0FBRyxNQUFNLElBQUksSUFBSTtJQUVsQixRQUFRLEdBQUcsQ0FBQyxDQUFDLDBCQUEwQixFQUFFLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUM7SUFFcEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNO01BQ3JCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF5QyxJQUNqRTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSwrQ0FBK0M7SUFDL0MsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxlQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsaURBQ1AsRUFBRSxDQUFDLE1BQU0sU0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtJQUVULElBQUksY0FBYyxDQUFDLE9BQU87TUFDeEIsUUFBUSxLQUFLLENBQUMsb0JBQW9CO01BQ2xDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFpQixJQUN6QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxzQ0FBc0M7SUFDdEMsSUFBSSxNQUFNLE1BQU0sS0FBSyxXQUFXLE1BQU0sTUFBTSxLQUFLLGFBQWE7TUFDNUQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQStELElBQ3ZGO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLCtFQUErRTtJQUMvRSxNQUFNLGNBQWMsTUFBTSxXQUFXLEVBQUUsTUFBTTtJQUM3QyxNQUFNLFNBQVMsY0FBYyxXQUFXLENBQUMsRUFBRSxDQUFDLElBQUksS0FBSztJQUVyRCxtREFBbUQ7SUFDbkQsTUFBTSxVQUFVLE1BQU0sYUFBYTtJQUVuQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVM7TUFDdkIsUUFBUSxLQUFLLENBQUMsQ0FBQywyQkFBMkIsRUFBRSxRQUFRLFNBQVMsRUFBRSxPQUFPLFVBQVUsRUFBRSxRQUFRLENBQUM7TUFDM0YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQW1HLElBQzNIO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsT0FBTyxVQUFVLEVBQUUsUUFBUSxDQUFDO0lBRWxFLGtDQUFrQztJQUNsQyxNQUFNLGNBQWM7TUFDbEI7TUFDQTtNQUNBLE1BQU0sS0FBSyxJQUFJO01BQ2YsYUFBYSxhQUFhLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDdkU7SUFFQSxRQUFRLEdBQUcsQ0FBQyx3QkFBd0IsS0FBSyxTQUFTLENBQUM7SUFFbkQsTUFBTSxlQUFlLE1BQU0sTUFBTSxDQUFDLEVBQUUsY0FBYyxpQ0FBaUMsQ0FBQyxFQUFFO01BQ3BGLFFBQVE7TUFDUixTQUFTO1FBQ1AsZ0JBQWdCO1FBQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO0lBQ3ZCO0lBRUEsTUFBTSxXQUFXLE1BQU0sYUFBYSxJQUFJO0lBQ3hDLFFBQVEsR0FBRyxDQUFDLHNCQUFzQixLQUFLLFNBQVMsQ0FBQztJQUVqRCxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksU0FBUyxJQUFJLEtBQUssS0FBSztNQUM3QyxNQUFNLGVBQWUsU0FBUyxHQUFHLElBQUk7TUFDckMsUUFBUSxLQUFLLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLENBQUM7TUFFL0MsK0NBQStDO01BQy9DLElBQUksV0FBVztRQUNiLE1BQU0sZUFDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7VUFBRSxRQUFRO1FBQVMsR0FDMUIsRUFBRSxDQUFDLE1BQU0sV0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUU7TUFDMUI7TUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU8sQ0FBQyxhQUFhLEVBQUUsYUFBYSxDQUFDO01BQUMsSUFDdkQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsbUNBQW1DO0lBQ25DLE1BQU0sZ0JBQWdCLFNBQVMsSUFBSSxFQUFFLGFBQWEsU0FBUyxJQUFJLEVBQUU7SUFFakUsSUFBSSxDQUFDLGVBQWU7TUFDbEIsUUFBUSxLQUFLLENBQUMsbUNBQW1DO01BQ2pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE0QixJQUNwRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDhCQUE4QixFQUFFLGNBQWMsQ0FBQztJQUU1RCxnREFBZ0Q7SUFDaEQsOEJBQThCO0lBQzlCLElBQUk7SUFFSixJQUFJLFdBQVc7TUFDYixNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sZUFDM0IsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1FBQ04saUJBQWlCO1FBQ2pCLFFBQVE7UUFDUixZQUFZLElBQUksT0FBTyxXQUFXO01BQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sV0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTSxHQUNOLE1BQU07TUFFVCxJQUFJLE9BQU87UUFDVCxRQUFRLEtBQUssQ0FBQyw2QkFBNkI7TUFDN0M7TUFDQSxlQUFlO0lBQ2pCLE9BQU87TUFDTCxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sZUFDM0IsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1FBQ04sU0FBUyxLQUFLLEVBQUU7UUFDaEIsTUFBTSxLQUFLLElBQUk7UUFDZixZQUFZLGFBQWE7UUFDekIsaUJBQWlCO1FBQ2pCLGlCQUFpQjtRQUNqQixlQUFlO1FBQ2YsYUFBYSxhQUFhLFVBQVU7UUFDcEMsWUFBWSxXQUFXLFVBQVU7UUFDakMsV0FBVyxZQUFZO1FBQ3ZCLGlCQUFpQjtRQUNqQixRQUFRO01BQ1YsR0FDQyxNQUFNLEdBQ04sTUFBTTtNQUVULElBQUksT0FBTztRQUNULFFBQVEsS0FBSyxDQUFDLG9DQUFvQztNQUNwRDtNQUNBLGVBQWU7SUFDakI7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxXQUFXLGNBQWM7TUFDekI7TUFDQSxTQUFTO0lBQ1gsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLDRCQUE0QjtJQUMxQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBa0MsSUFDMUQ7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
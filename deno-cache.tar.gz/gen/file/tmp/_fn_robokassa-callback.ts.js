const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const ROBOKASSA_PASSWORD2 = Deno.env.get("ROBOKASSA_PASSWORD2") || "";
async function createMD5(str) {
  const encoder = new TextEncoder();
  const data = encoder.encode(str);
  // Use crypto.subtle for MD5 - fail securely if not available
  const hashBuffer = await crypto.subtle.digest('MD5', data).catch((error)=>{
    console.error("MD5 digest failed:", error);
    return null;
  });
  if (!hashBuffer) {
    // Fail securely - do not use weak fallback
    throw new Error("MD5 hashing is not supported in this environment. Cannot verify payment signature.");
  }
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b)=>b.toString(16).padStart(2, '0')).join('');
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Parse form data or query params
    let outSum, invId, signatureValue;
    if (req.method === "POST") {
      const formData = await req.formData().catch(()=>null);
      if (formData) {
        outSum = formData.get("OutSum")?.toString() || "";
        invId = formData.get("InvId")?.toString() || "";
        signatureValue = formData.get("SignatureValue")?.toString() || "";
      } else {
        const body = await req.json();
        outSum = body.OutSum;
        invId = body.InvId;
        signatureValue = body.SignatureValue;
      }
    } else {
      const url = new URL(req.url);
      outSum = url.searchParams.get("OutSum") || "";
      invId = url.searchParams.get("InvId") || "";
      signatureValue = url.searchParams.get("SignatureValue") || "";
    }
    console.log("Robokassa callback:", {
      outSum,
      invId,
      signatureValue
    });
    // Verify signature: OutSum:InvId:Password2
    const expectedSignature = await createMD5(`${outSum}:${invId}:${ROBOKASSA_PASSWORD2}`);
    if (signatureValue.toLowerCase() !== expectedSignature.toLowerCase()) {
      console.error("Invalid signature", {
        expected: expectedSignature,
        received: signatureValue
      });
      return new Response("bad sign", {
        status: 400
      });
    }
    // Find payment by external_id
    const { data: payment, error: findError } = await supabase.from("payments").select("*").eq("external_id", invId).eq("payment_system", "robokassa").single();
    if (findError || !payment) {
      console.error("Payment not found:", invId);
      return new Response("bad", {
        status: 404
      });
    }
    // Update payment status
    const { error: updateError } = await supabase.from("payments").update({
      status: "completed",
      updated_at: new Date().toISOString()
    }).eq("id", payment.id);
    if (updateError) {
      console.error("Error updating payment:", updateError);
      return new Response("bad", {
        status: 500
      });
    }
    // Add balance to user profile
    const { data: profile, error: profileError } = await supabase.from("profiles").select("balance").eq("user_id", payment.user_id).single();
    if (!profileError && profile) {
      const newBalance = (profile.balance || 0) + payment.amount;
      await supabase.from("profiles").update({
        balance: newBalance
      }).eq("user_id", payment.user_id);
      // Log topup transaction
      await supabase.from("balance_transactions").insert({
        user_id: payment.user_id,
        amount: payment.amount,
        balance_after: newBalance,
        type: "topup",
        description: `Пополнение баланса (Робокасса)`,
        reference_id: payment.id,
        reference_type: "payment"
      });
    }
    console.log("Payment completed:", payment.id);
    // Return OK for Robokassa
    return new Response(`OK${invId}`, {
      headers: {
        "Content-Type": "text/plain"
      },
      status: 200
    });
  } catch (error) {
    console.error("Robokassa callback error:", error);
    return new Response("bad", {
      status: 500
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9yb2Jva2Fzc2EtY2FsbGJhY2sudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmNvbnN0IFJPQk9LQVNTQV9QQVNTV09SRDIgPSBEZW5vLmVudi5nZXQoXCJST0JPS0FTU0FfUEFTU1dPUkQyXCIpIHx8IFwiXCI7XG5cbmFzeW5jIGZ1bmN0aW9uIGNyZWF0ZU1ENShzdHI6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGVuY29kZXIgPSBuZXcgVGV4dEVuY29kZXIoKTtcbiAgY29uc3QgZGF0YSA9IGVuY29kZXIuZW5jb2RlKHN0cik7XG4gIFxuICAvLyBVc2UgY3J5cHRvLnN1YnRsZSBmb3IgTUQ1IC0gZmFpbCBzZWN1cmVseSBpZiBub3QgYXZhaWxhYmxlXG4gIGNvbnN0IGhhc2hCdWZmZXIgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnTUQ1JywgZGF0YSkuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgY29uc29sZS5lcnJvcihcIk1ENSBkaWdlc3QgZmFpbGVkOlwiLCBlcnJvcik7XG4gICAgcmV0dXJuIG51bGw7XG4gIH0pO1xuICBcbiAgaWYgKCFoYXNoQnVmZmVyKSB7XG4gICAgLy8gRmFpbCBzZWN1cmVseSAtIGRvIG5vdCB1c2Ugd2VhayBmYWxsYmFja1xuICAgIHRocm93IG5ldyBFcnJvcihcIk1ENSBoYXNoaW5nIGlzIG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBlbnZpcm9ubWVudC4gQ2Fubm90IHZlcmlmeSBwYXltZW50IHNpZ25hdHVyZS5cIik7XG4gIH1cbiAgXG4gIGNvbnN0IGhhc2hBcnJheSA9IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoaGFzaEJ1ZmZlcikpO1xuICByZXR1cm4gaGFzaEFycmF5Lm1hcChiID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpLmpvaW4oJycpO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgLy8gUGFyc2UgZm9ybSBkYXRhIG9yIHF1ZXJ5IHBhcmFtc1xuICAgIGxldCBvdXRTdW06IHN0cmluZywgaW52SWQ6IHN0cmluZywgc2lnbmF0dXJlVmFsdWU6IHN0cmluZztcblxuICAgIGlmIChyZXEubWV0aG9kID09PSBcIlBPU1RcIikge1xuICAgICAgY29uc3QgZm9ybURhdGEgPSBhd2FpdCByZXEuZm9ybURhdGEoKS5jYXRjaCgoKSA9PiBudWxsKTtcbiAgICAgIGlmIChmb3JtRGF0YSkge1xuICAgICAgICBvdXRTdW0gPSBmb3JtRGF0YS5nZXQoXCJPdXRTdW1cIik/LnRvU3RyaW5nKCkgfHwgXCJcIjtcbiAgICAgICAgaW52SWQgPSBmb3JtRGF0YS5nZXQoXCJJbnZJZFwiKT8udG9TdHJpbmcoKSB8fCBcIlwiO1xuICAgICAgICBzaWduYXR1cmVWYWx1ZSA9IGZvcm1EYXRhLmdldChcIlNpZ25hdHVyZVZhbHVlXCIpPy50b1N0cmluZygpIHx8IFwiXCI7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICAgICAgb3V0U3VtID0gYm9keS5PdXRTdW07XG4gICAgICAgIGludklkID0gYm9keS5JbnZJZDtcbiAgICAgICAgc2lnbmF0dXJlVmFsdWUgPSBib2R5LlNpZ25hdHVyZVZhbHVlO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHJlcS51cmwpO1xuICAgICAgb3V0U3VtID0gdXJsLnNlYXJjaFBhcmFtcy5nZXQoXCJPdXRTdW1cIikgfHwgXCJcIjtcbiAgICAgIGludklkID0gdXJsLnNlYXJjaFBhcmFtcy5nZXQoXCJJbnZJZFwiKSB8fCBcIlwiO1xuICAgICAgc2lnbmF0dXJlVmFsdWUgPSB1cmwuc2VhcmNoUGFyYW1zLmdldChcIlNpZ25hdHVyZVZhbHVlXCIpIHx8IFwiXCI7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coXCJSb2Jva2Fzc2EgY2FsbGJhY2s6XCIsIHsgb3V0U3VtLCBpbnZJZCwgc2lnbmF0dXJlVmFsdWUgfSk7XG5cbiAgICAvLyBWZXJpZnkgc2lnbmF0dXJlOiBPdXRTdW06SW52SWQ6UGFzc3dvcmQyXG4gICAgY29uc3QgZXhwZWN0ZWRTaWduYXR1cmUgPSBhd2FpdCBjcmVhdGVNRDUoYCR7b3V0U3VtfToke2ludklkfToke1JPQk9LQVNTQV9QQVNTV09SRDJ9YCk7XG4gICAgXG4gICAgaWYgKHNpZ25hdHVyZVZhbHVlLnRvTG93ZXJDYXNlKCkgIT09IGV4cGVjdGVkU2lnbmF0dXJlLnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJJbnZhbGlkIHNpZ25hdHVyZVwiLCB7IGV4cGVjdGVkOiBleHBlY3RlZFNpZ25hdHVyZSwgcmVjZWl2ZWQ6IHNpZ25hdHVyZVZhbHVlIH0pO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcImJhZCBzaWduXCIsIHsgc3RhdHVzOiA0MDAgfSk7XG4gICAgfVxuXG4gICAgLy8gRmluZCBwYXltZW50IGJ5IGV4dGVybmFsX2lkXG4gICAgY29uc3QgeyBkYXRhOiBwYXltZW50LCBlcnJvcjogZmluZEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwYXltZW50c1wiKVxuICAgICAgLnNlbGVjdChcIipcIilcbiAgICAgIC5lcShcImV4dGVybmFsX2lkXCIsIGludklkKVxuICAgICAgLmVxKFwicGF5bWVudF9zeXN0ZW1cIiwgXCJyb2Jva2Fzc2FcIilcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmIChmaW5kRXJyb3IgfHwgIXBheW1lbnQpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJQYXltZW50IG5vdCBmb3VuZDpcIiwgaW52SWQpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcImJhZFwiLCB7IHN0YXR1czogNDA0IH0pO1xuICAgIH1cblxuICAgIC8vIFVwZGF0ZSBwYXltZW50IHN0YXR1c1xuICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwYXltZW50c1wiKVxuICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxuICAgICAgfSlcbiAgICAgIC5lcShcImlkXCIsIHBheW1lbnQuaWQpO1xuXG4gICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgcGF5bWVudDpcIiwgdXBkYXRlRXJyb3IpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcImJhZFwiLCB7IHN0YXR1czogNTAwIH0pO1xuICAgIH1cblxuICAgIC8vIEFkZCBiYWxhbmNlIHRvIHVzZXIgcHJvZmlsZVxuICAgIGNvbnN0IHsgZGF0YTogcHJvZmlsZSwgZXJyb3I6IHByb2ZpbGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHBheW1lbnQudXNlcl9pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICghcHJvZmlsZUVycm9yICYmIHByb2ZpbGUpIHtcbiAgICAgIGNvbnN0IG5ld0JhbGFuY2UgPSAocHJvZmlsZS5iYWxhbmNlIHx8IDApICsgcGF5bWVudC5hbW91bnQ7XG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBuZXdCYWxhbmNlIH0pXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgcGF5bWVudC51c2VyX2lkKTtcblxuICAgICAgLy8gTG9nIHRvcHVwIHRyYW5zYWN0aW9uXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwiYmFsYW5jZV90cmFuc2FjdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogcGF5bWVudC51c2VyX2lkLFxuICAgICAgICBhbW91bnQ6IHBheW1lbnQuYW1vdW50LFxuICAgICAgICBiYWxhbmNlX2FmdGVyOiBuZXdCYWxhbmNlLFxuICAgICAgICB0eXBlOiBcInRvcHVwXCIsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBg0J/QvtC/0L7Qu9C90LXQvdC40LUg0LHQsNC70LDQvdGB0LAgKNCg0L7QsdC+0LrQsNGB0YHQsClgLFxuICAgICAgICByZWZlcmVuY2VfaWQ6IHBheW1lbnQuaWQsXG4gICAgICAgIHJlZmVyZW5jZV90eXBlOiBcInBheW1lbnRcIixcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKFwiUGF5bWVudCBjb21wbGV0ZWQ6XCIsIHBheW1lbnQuaWQpO1xuXG4gICAgLy8gUmV0dXJuIE9LIGZvciBSb2Jva2Fzc2FcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKGBPSyR7aW52SWR9YCwge1xuICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcInRleHQvcGxhaW5cIiB9LFxuICAgICAgc3RhdHVzOiAyMDAsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIlJvYm9rYXNzYSBjYWxsYmFjayBlcnJvcjpcIiwgZXJyb3IpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXCJiYWRcIiwgeyBzdGF0dXM6IDUwMCB9KTtcbiAgfVxufSk7Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxzQkFBc0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLDBCQUEwQjtBQUVuRSxlQUFlLFVBQVUsR0FBVztFQUNsQyxNQUFNLFVBQVUsSUFBSTtFQUNwQixNQUFNLE9BQU8sUUFBUSxNQUFNLENBQUM7RUFFNUIsNkRBQTZEO0VBQzdELE1BQU0sYUFBYSxNQUFNLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLE1BQU0sS0FBSyxDQUFDLENBQUM7SUFDaEUsUUFBUSxLQUFLLENBQUMsc0JBQXNCO0lBQ3BDLE9BQU87RUFDVDtFQUVBLElBQUksQ0FBQyxZQUFZO0lBQ2YsMkNBQTJDO0lBQzNDLE1BQU0sSUFBSSxNQUFNO0VBQ2xCO0VBRUEsTUFBTSxZQUFZLE1BQU0sSUFBSSxDQUFDLElBQUksV0FBVztFQUM1QyxPQUFPLFVBQVUsR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBQ2xFO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDeEMsTUFBTSxXQUFXLGFBQWEsYUFBYTtJQUUzQyxrQ0FBa0M7SUFDbEMsSUFBSSxRQUFnQixPQUFlO0lBRW5DLElBQUksSUFBSSxNQUFNLEtBQUssUUFBUTtNQUN6QixNQUFNLFdBQVcsTUFBTSxJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBTTtNQUNsRCxJQUFJLFVBQVU7UUFDWixTQUFTLFNBQVMsR0FBRyxDQUFDLFdBQVcsY0FBYztRQUMvQyxRQUFRLFNBQVMsR0FBRyxDQUFDLFVBQVUsY0FBYztRQUM3QyxpQkFBaUIsU0FBUyxHQUFHLENBQUMsbUJBQW1CLGNBQWM7TUFDakUsT0FBTztRQUNMLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtRQUMzQixTQUFTLEtBQUssTUFBTTtRQUNwQixRQUFRLEtBQUssS0FBSztRQUNsQixpQkFBaUIsS0FBSyxjQUFjO01BQ3RDO0lBQ0YsT0FBTztNQUNMLE1BQU0sTUFBTSxJQUFJLElBQUksSUFBSSxHQUFHO01BQzNCLFNBQVMsSUFBSSxZQUFZLENBQUMsR0FBRyxDQUFDLGFBQWE7TUFDM0MsUUFBUSxJQUFJLFlBQVksQ0FBQyxHQUFHLENBQUMsWUFBWTtNQUN6QyxpQkFBaUIsSUFBSSxZQUFZLENBQUMsR0FBRyxDQUFDLHFCQUFxQjtJQUM3RDtJQUVBLFFBQVEsR0FBRyxDQUFDLHVCQUF1QjtNQUFFO01BQVE7TUFBTztJQUFlO0lBRW5FLDJDQUEyQztJQUMzQyxNQUFNLG9CQUFvQixNQUFNLFVBQVUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFLG9CQUFvQixDQUFDO0lBRXJGLElBQUksZUFBZSxXQUFXLE9BQU8sa0JBQWtCLFdBQVcsSUFBSTtNQUNwRSxRQUFRLEtBQUssQ0FBQyxxQkFBcUI7UUFBRSxVQUFVO1FBQW1CLFVBQVU7TUFBZTtNQUMzRixPQUFPLElBQUksU0FBUyxZQUFZO1FBQUUsUUFBUTtNQUFJO0lBQ2hEO0lBRUEsOEJBQThCO0lBQzlCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FDL0MsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLEtBQ1AsRUFBRSxDQUFDLGVBQWUsT0FDbEIsRUFBRSxDQUFDLGtCQUFrQixhQUNyQixNQUFNO0lBRVQsSUFBSSxhQUFhLENBQUMsU0FBUztNQUN6QixRQUFRLEtBQUssQ0FBQyxzQkFBc0I7TUFDcEMsT0FBTyxJQUFJLFNBQVMsT0FBTztRQUFFLFFBQVE7TUFBSTtJQUMzQztJQUVBLHdCQUF3QjtJQUN4QixNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLFNBQ2xDLElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztNQUNOLFFBQVE7TUFDUixZQUFZLElBQUksT0FBTyxXQUFXO0lBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sUUFBUSxFQUFFO0lBRXRCLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLDJCQUEyQjtNQUN6QyxPQUFPLElBQUksU0FBUyxPQUFPO1FBQUUsUUFBUTtNQUFJO0lBQzNDO0lBRUEsOEJBQThCO0lBQzlCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbEQsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsUUFBUSxPQUFPLEVBQzdCLE1BQU07SUFFVCxJQUFJLENBQUMsZ0JBQWdCLFNBQVM7TUFDNUIsTUFBTSxhQUFhLENBQUMsUUFBUSxPQUFPLElBQUksQ0FBQyxJQUFJLFFBQVEsTUFBTTtNQUMxRCxNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1FBQUUsU0FBUztNQUFXLEdBQzdCLEVBQUUsQ0FBQyxXQUFXLFFBQVEsT0FBTztNQUVoQyx3QkFBd0I7TUFDeEIsTUFBTSxTQUFTLElBQUksQ0FBQyx3QkFBd0IsTUFBTSxDQUFDO1FBQ2pELFNBQVMsUUFBUSxPQUFPO1FBQ3hCLFFBQVEsUUFBUSxNQUFNO1FBQ3RCLGVBQWU7UUFDZixNQUFNO1FBQ04sYUFBYSxDQUFDLDhCQUE4QixDQUFDO1FBQzdDLGNBQWMsUUFBUSxFQUFFO1FBQ3hCLGdCQUFnQjtNQUNsQjtJQUNGO0lBRUEsUUFBUSxHQUFHLENBQUMsc0JBQXNCLFFBQVEsRUFBRTtJQUU1QywwQkFBMEI7SUFDMUIsT0FBTyxJQUFJLFNBQVMsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUU7TUFDaEMsU0FBUztRQUFFLGdCQUFnQjtNQUFhO01BQ3hDLFFBQVE7SUFDVjtFQUNGLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsNkJBQTZCO0lBQzNDLE9BQU8sSUFBSSxTQUFTLE9BQU87TUFBRSxRQUFRO0lBQUk7RUFDM0M7QUFDRiJ9
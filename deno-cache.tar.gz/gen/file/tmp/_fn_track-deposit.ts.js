const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Генерация SHA-256 хеша
async function generateHash(data) {
  const encoder = new TextEncoder();
  const dataBuffer = encoder.encode(data);
  const hashBuffer = await crypto.subtle.digest("SHA-256", dataBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b)=>b.toString(16).padStart(2, "0")).join("");
}
// Переписываем старые Supabase URL на текущий API (после миграции storage на aimuza.ru)
function resolveAudioUrl(url) {
  const supabaseUrl = Deno.env.get("SUPABASE_URL") || "https://aimuza.ru";
  const oldSupabase = /https:\/\/[a-z]+\.supabase\.co/;
  if (oldSupabase.test(url)) {
    const path = new URL(url).pathname;
    return `${supabaseUrl}${path}`;
  }
  return url;
}
// Получаем хеш аудиофайла
async function getAudioHash(audioUrl) {
  const resolvedUrl = resolveAudioUrl(audioUrl);
  try {
    const response = await fetch(resolvedUrl);
    const buffer = await response.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest("SHA-256", buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b)=>b.toString(16).padStart(2, "0")).join("");
  } catch (error) {
    console.error("Error fetching audio for hash:", error);
    throw new Error("Не удалось получить аудиофайл для хеширования");
  }
}
// OpenTimestamps — API ожидает 32 байта (binary), не hex-строку
async function submitToOpenTimestamps(hashHex) {
  const hashBytes = new Uint8Array(hashHex.match(/.{2}/g).map((b)=>parseInt(b, 16)));
  const calendars = [
    "https://a.pool.opentimestamps.org/digest",
    "https://b.pool.opentimestamps.org/digest",
    "https://finney.calendar.eternitywall.com/digest"
  ];
  for (const calendar of calendars){
    try {
      const resp = await fetch(calendar, {
        method: "POST",
        headers: {
          "Content-Type": "application/octet-stream",
          Accept: "application/vnd.opentimestamps.v1"
        },
        body: hashBytes
      });
      if (resp.ok) {
        return `ots_${Date.now()}`;
      }
    } catch (e) {
      console.log(`[OTS] ${calendar} failed:`, e);
    }
  }
  return `ots_pending_${hashHex.substring(0, 16)}`;
}
// n'RIS API интеграция
async function submitToNris(track, hash, apiKey, apiUrl) {
  if (!apiKey) {
    throw new Error("API ключ n'RIS не настроен");
  }
  try {
    const response = await fetch(`${apiUrl}/deposits`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        type: "audio",
        title: track.title,
        author: track.performer_name || track.profiles?.username,
        hash: hash,
        metadata: {
          duration: track.duration,
          genre: track.genre?.name_ru,
          created_at: track.created_at,
          lyrics_author: track.lyrics_author,
          music_author: track.music_author
        }
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`n'RIS API error: ${error}`);
    }
    const result = await response.json();
    return {
      depositId: result.deposit_id || result.id,
      certificateUrl: result.certificate_url
    };
  } catch (error) {
    console.error("n'RIS error:", error);
    throw error;
  }
}
// IRMA API интеграция
async function submitToIrma(track, hash, apiKey, apiUrl) {
  if (!apiKey) {
    throw new Error("API ключ IRMA не настроен");
  }
  try {
    const response = await fetch(`${apiUrl}/register`, {
      method: "POST",
      headers: {
        "X-API-Key": apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        work_type: "music",
        title: track.title,
        creators: [
          {
            role: "author",
            name: track.performer_name || track.profiles?.username
          },
          ...track.music_author ? [
            {
              role: "composer",
              name: track.music_author
            }
          ] : [],
          ...track.lyrics_author ? [
            {
              role: "lyricist",
              name: track.lyrics_author
            }
          ] : []
        ],
        file_hash: hash,
        additional_info: {
          duration_seconds: track.duration,
          genre: track.genre?.name_ru
        }
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`IRMA API error: ${error}`);
    }
    const result = await response.json();
    return {
      depositId: result.registration_id || result.id,
      certificateUrl: result.certificate_url
    };
  } catch (error) {
    console.error("IRMA error:", error);
    throw error;
  }
}
// Генерация PDF сертификата
async function generatePdfCertificate(supabase, track, hash, depositId, authorData) {
  const publicBase = Deno.env.get("BASE_URL") || "https://aimuza.ru";
  const verifyUrl = `${publicBase}/verify?hash=${encodeURIComponent(hash)}`;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(verifyUrl)}`;
  const certificateData = {
    title: "Авторское свидетельство",
    trackTitle: track.title || "Без названия",
    performer: authorData.performer_name || "Не указан",
    musicAuthor: authorData.music_author || "",
    lyricsAuthor: authorData.lyrics_author || "",
    fileHash: hash,
    depositId: depositId,
    depositDate: new Date().toISOString(),
    platform: "aimuza.ru",
    label: "Лейбл НОТА - ФЕЯ",
    labelFull: 'ООО "Музыкальный лейбл НОТА-ФЕЯ"',
    verifyUrl,
    qrCodeUrl
  };
  const formattedDate = new Date(certificateData.depositDate).toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
  // HTML сертификат с QR-кодом и стилями для печати
  const htmlContent = `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Сертификат депонирования - ${certificateData.trackTitle}</title>
  <style>
    @media print {
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .no-print { display: none !important; }
      @page { size: A4; margin: 15mm; }
    }
    
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body { 
      font-family: 'Times New Roman', 'Georgia', serif; 
      padding: 40px; 
      max-width: 800px; 
      margin: 0 auto; 
      background: #fff;
      color: #1a1a1a;
      line-height: 1.5;
    }
    
    .certificate {
      border: 3px double #2c3e50;
      padding: 40px;
      background: linear-gradient(135deg, #fefefe 0%, #f8f9fa 100%);
      position: relative;
    }
    
    .certificate::before {
      content: '';
      position: absolute;
      top: 10px;
      left: 10px;
      right: 10px;
      bottom: 10px;
      border: 1px solid #bdc3c7;
      pointer-events: none;
    }
    
    .header { 
      text-align: center; 
      border-bottom: 2px solid #2c3e50; 
      padding-bottom: 25px; 
      margin-bottom: 30px; 
    }
    
    .logo-section {
      margin-bottom: 15px;
    }
    
    .label-name {
      font-size: 14px;
      color: #555;
      font-weight: 500;
      letter-spacing: 1px;
      margin-bottom: 5px;
    }
    
    .website {
      font-size: 18px;
      color: #2c3e50;
      font-weight: bold;
      letter-spacing: 2px;
    }
    
    .title { 
      font-size: 32px; 
      font-weight: bold; 
      color: #1a1a1a; 
      text-transform: uppercase;
      letter-spacing: 3px;
      margin-top: 20px;
    }
    
    .subtitle { 
      font-size: 16px; 
      color: #666; 
      margin-top: 10px;
      font-style: italic;
    }
    
    .content {
      display: grid;
      gap: 18px;
    }
    
    .section { 
      display: grid;
      grid-template-columns: 180px 1fr;
      align-items: start;
      gap: 15px;
    }
    
    .label { 
      font-weight: bold; 
      color: #2c3e50;
      font-size: 14px;
      padding-top: 10px;
    }
    
    .value { 
      padding: 12px 15px; 
      background: #fff; 
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 15px;
      box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .hash { 
      font-family: 'Courier New', monospace; 
      font-size: 11px; 
      word-break: break-all;
      color: #555;
      letter-spacing: 0.5px;
    }
    
    .seal { 
      text-align: center; 
      margin: 35px 0 25px; 
    }
    
    .seal-container {
      display: inline-block;
      position: relative;
    }
    
    .seal-text { 
      display: inline-block; 
      padding: 20px 35px; 
      border: 4px double #2c3e50; 
      border-radius: 50%;
      font-size: 14px;
      font-weight: bold;
      color: #2c3e50;
      text-align: center;
      line-height: 1.4;
      background: linear-gradient(135deg, #fff 0%, #f0f0f0 100%);
    }
    
    .qr-section {
      text-align: center;
      margin: 25px 0 20px;
      padding: 15px;
      border: 1px dashed #bdc3c7;
      border-radius: 8px;
      background: #fafafa;
    }
    .qr-caption {
      font-size: 11px;
      color: #666;
      margin-bottom: 10px;
    }
    .qr-link { display: inline-block; }
    .qr-image { display: block; width: 120px; height: 120px; margin: 0 auto; }
    
    .footer { 
      margin-top: 30px; 
      padding-top: 20px; 
      border-top: 2px solid #2c3e50; 
      font-size: 12px; 
      color: #666; 
      text-align: center;
      line-height: 1.8;
    }
    
    .footer p {
      margin: 5px 0;
    }
    
    .footer .platform {
      font-weight: bold;
      color: #2c3e50;
      font-size: 14px;
      margin-top: 15px;
    }
    
    .print-btn {
      display: block;
      margin: 20px auto;
      padding: 12px 30px;
      background: #2c3e50;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      font-family: inherit;
    }
    
    .print-btn:hover {
      background: #1a252f;
    }
  </style>
</head>
<body>
  <button class="print-btn no-print" onclick="window.print()">📄 Сохранить как PDF / Распечатать</button>
  
    <div class="certificate">
    <div class="header">
      <div class="logo-section">
        <div class="label-name">${certificateData.label}</div>
        <div class="website">сайт ${certificateData.platform}</div>
      </div>
      <div class="title">АВТОРСКОЕ СВИДЕТЕЛЬСТВО</div>
      <div class="subtitle">Музыкальное произведение</div>
    </div>
    
    <div class="content">
      <div class="section">
        <div class="label">Название произведения:</div>
        <div class="value">${certificateData.trackTitle}</div>
      </div>
      
      <div class="section">
        <div class="label">Исполнитель:</div>
        <div class="value">${certificateData.performer}</div>
      </div>
      
      ${certificateData.musicAuthor ? `<div class="section">
        <div class="label">Автор музыки:</div>
        <div class="value">${certificateData.musicAuthor}</div>
      </div>` : ''}
      
      ${certificateData.lyricsAuthor ? `<div class="section">
        <div class="label">Автор текста:</div>
        <div class="value">${certificateData.lyricsAuthor}</div>
      </div>` : ''}
      
      <div class="section">
        <div class="label">Цифровой отпечаток (SHA-256):</div>
        <div class="value hash">${certificateData.fileHash}</div>
      </div>
      
      <div class="section">
        <div class="label">Идентификатор:</div>
        <div class="value">${certificateData.depositId}</div>
      </div>
      
      <div class="section">
        <div class="label">Дата регистрации:</div>
        <div class="value">${formattedDate}</div>
      </div>
    </div>
    
    <div class="seal">
      <div class="seal-container">
        <div class="seal-text">НОТА-ФЕЯ<br/>✓ Verified</div>
      </div>
    </div>
    
    <div class="qr-section">
      <p class="qr-caption">Проверка подлинности — отсканируйте QR-код</p>
      <a href="${certificateData.verifyUrl}" target="_blank" rel="noopener" class="qr-link">
        <img src="${certificateData.qrCodeUrl}" alt="QR-код для проверки" class="qr-image" />
      </a>
    </div>
    
    <div class="footer">
      <p>Данное свидетельство подтверждает факт существования произведения на указанную дату.</p>
      <p>Цифровой отпечаток позволяет однозначно идентифицировать оригинальный файл.</p>
      <p class="platform">${certificateData.labelFull} • сайт ${certificateData.platform}</p>
    </div>
  </div>
</body>
</html>`;
  // Сохраняем HTML как файл с правильной кодировкой для скачивания
  const fileName = `certificate_${depositId}.html`;
  const safeTitle = (track.title || "Без названия").replace(/[^a-zA-Zа-яА-ЯёЁ0-9\s]/g, '_').trim();
  const htmlBytes = new TextEncoder().encode(htmlContent);
  // Создаём Blob с правильным content-type
  const blob = new Blob([
    htmlBytes
  ], {
    type: "text/html;charset=utf-8"
  });
  const { error: uploadError } = await supabase.storage.from("certificates").upload(fileName, blob, {
    contentType: "text/html;charset=utf-8",
    cacheControl: "3600",
    upsert: true
  });
  if (uploadError) {
    console.error("Error uploading certificate:", uploadError);
    throw new Error("Не удалось сохранить сертификат");
  }
  // URL сертификата (публичный — для открытия в браузере; ?download= для скачивания)
  const publicPath = `/storage/v1/object/public/certificates/${fileName}`;
  const downloadName = `Авторское_свидетельство_${safeTitle}.html`;
  return `${publicBase}${publicPath}?download=${encodeURIComponent(downloadName)}`;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Получаем пользователя
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Не авторизован");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    // Клиент с JWT пользователя — для RLS (auth.uid() = user_id при INSERT/DELETE)
    const userSupabase = createClient(supabaseUrl, supabaseServiceKey, {
      global: {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    });
    if (authError || !user) {
      throw new Error("Не авторизован");
    }
    const { trackId, method, authorData } = await req.json();
    console.log(`Deposit request: track=${trackId}, method=${method}, user=${user.id}`);
    // Получаем трек (audio_url, master_audio_url, normalized_audio_url — любой доступный URL)
    const { data: track, error: trackError } = await supabase.from("tracks").select(`
        id, title, audio_url, master_audio_url, normalized_audio_url, duration, created_at,
        performer_name, music_author, lyrics_author, user_id,
        genre:genres(name_ru)
      `).eq("id", trackId).eq("user_id", user.id).single();
    // Получаем username отдельно
    const { data: profile } = await supabase.from("profiles").select("username").eq("user_id", user.id).single();
    const username = profile?.username || "Unknown";
    // Используем данные автора из запроса или из трека
    const effectiveAuthorData = {
      performer_name: authorData?.performer_name || track?.performer_name || username,
      music_author: authorData?.music_author || track?.music_author || "",
      lyrics_author: authorData?.lyrics_author || track?.lyrics_author || ""
    };
    if (trackError || !track) {
      throw new Error("Трек не найден или не принадлежит вам");
    }
    // Fallback: файл может физически лежать в tracks/audio/{id}.mp3, но URL в БД пустой
    const baseUrl = supabaseUrl || "https://aimuza.ru";
    const audioUrl = track.audio_url || track.master_audio_url || track.normalized_audio_url || `${baseUrl}/storage/v1/object/public/tracks/audio/${trackId}.mp3`;
    // Проверяем существующее депонирование
    const { data: existingDeposit } = await supabase.from("track_deposits").select("id, status").eq("track_id", trackId).eq("method", method).single();
    if (existingDeposit) {
      if (existingDeposit.status === "completed") {
        throw new Error("Трек уже депонирован этим методом");
      }
      // Удаляем failed или processing записи (userSupabase для RLS)
      await userSupabase.from("track_deposits").delete().eq("id", existingDeposit.id);
    }
    // Получаем настройки
    const { data: settings } = await supabase.from("settings").select("key, value").in("key", [
      `deposit_price_${method}`,
      "nris_api_key",
      "nris_api_url",
      "irma_api_key",
      "irma_api_url"
    ]);
    const settingsMap = new Map(settings?.map((s)=>[
        s.key,
        s.value
      ]) || []);
    const priceKey = `deposit_price_${method}`;
    const priceValue = settingsMap.get(priceKey);
    const price = parseInt(priceValue || "0", 10);
    console.log(`Deposit pricing: key=${priceKey}, rawValue=${priceValue}, parsedPrice=${price}`);
    // Проверяем баланс если платно
    if (price > 0) {
      const { data: userProfile, error: profileError } = await supabase.from("profiles").select("balance").eq("user_id", user.id).single();
      console.log(`User balance check: balance=${userProfile?.balance}, price=${price}, error=${profileError?.message}`);
      if (!userProfile || userProfile.balance < price) {
        throw new Error(`Недостаточно средств. Требуется: ${price} ₽, баланс: ${userProfile?.balance || 0} ₽`);
      }
      // Списываем средства
      const newBalance = userProfile.balance - price;
      console.log(`Deducting balance: ${userProfile.balance} - ${price} = ${newBalance}`);
      const { error: updateError } = await supabase.from("profiles").update({
        balance: newBalance
      }).eq("user_id", user.id);
      if (updateError) {
        console.error("Balance update error:", updateError);
        throw new Error("Ошибка списания средств");
      }
      console.log(`Balance updated successfully for user ${user.id}`);
    } else {
      console.log(`Deposit is free for method ${method}`);
    }
    // Генерируем хеш аудио
    console.log("Generating audio hash...", {
      urlLen: audioUrl.length
    });
    const fileHash = await getAudioHash(audioUrl);
    // Генерируем хеш метаданных
    const metadataHash = await generateHash(JSON.stringify({
      title: track.title,
      performer: effectiveAuthorData.performer_name,
      musicAuthor: effectiveAuthorData.music_author,
      lyricsAuthor: effectiveAuthorData.lyrics_author,
      duration: track.duration,
      fileHash,
      timestamp: new Date().toISOString()
    }));
    // Создаём запись депонирования (userSupabase для RLS: auth.uid() = user_id)
    const depositId = crypto.randomUUID();
    const { error: insertError } = await userSupabase.from("track_deposits").upsert({
      id: depositId,
      track_id: trackId,
      user_id: user.id,
      method,
      status: "processing",
      file_hash: fileHash,
      metadata_hash: metadataHash,
      performer_name: effectiveAuthorData.performer_name,
      lyrics_author: effectiveAuthorData.lyrics_author
    });
    if (insertError) {
      console.error("Insert error:", insertError);
      const msg = insertError?.message || insertError?.details || "Не удалось создать запись депонирования";
      throw new Error(typeof msg === "string" ? msg : "Не удалось создать запись депонирования");
    }
    let result = {};
    try {
      switch(method){
        case "internal":
          // Внутренний реестр - просто сохраняем хеши
          result.certificateUrl = await generatePdfCertificate(supabase, track, fileHash, depositId, effectiveAuthorData);
          break;
        case "pdf":
          // Генерация PDF сертификата
          result.certificateUrl = await generatePdfCertificate(supabase, track, fileHash, depositId, effectiveAuthorData);
          break;
        case "blockchain":
          // OpenTimestamps
          result.blockchainTxId = await submitToOpenTimestamps(fileHash);
          result.certificateUrl = await generatePdfCertificate(supabase, track, fileHash, depositId, effectiveAuthorData);
          break;
        case "nris":
          const nrisResult = await submitToNris(track, fileHash, settingsMap.get("nris_api_key") || "", settingsMap.get("nris_api_url") || "https://api.nris.ru/v1");
          result.externalDepositId = nrisResult.depositId;
          result.externalCertificateUrl = nrisResult.certificateUrl;
          break;
        case "irma":
          const irmaResult = await submitToIrma(track, fileHash, settingsMap.get("irma_api_key") || "", settingsMap.get("irma_api_url") || "https://api.irma.ru/v1");
          result.externalDepositId = irmaResult.depositId;
          result.externalCertificateUrl = irmaResult.certificateUrl;
          break;
      }
      // Обновляем статус на completed (userSupabase для RLS)
      await userSupabase.from("track_deposits").update({
        status: "completed",
        completed_at: new Date().toISOString(),
        certificate_url: result.certificateUrl,
        blockchain_tx_id: result.blockchainTxId,
        external_deposit_id: result.externalDepositId,
        external_certificate_url: result.externalCertificateUrl
      }).eq("id", depositId);
      // Создаём уведомление (userSupabase для RLS)
      await userSupabase.from("notifications").insert({
        user_id: user.id,
        type: "system",
        title: "Депонирование завершено",
        message: `Трек "${track.title}" успешно депонирован`,
        target_type: "track",
        target_id: trackId
      });
      console.log(`Deposit completed: ${depositId}`);
      return new Response(JSON.stringify({
        success: true,
        depositId,
        ...result
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    } catch (processError) {
      const error = processError;
      console.error("Process error:", error);
      // Обновляем статус на failed (userSupabase для RLS)
      await userSupabase.from("track_deposits").update({
        status: "failed",
        error_message: error.message || "Unknown error"
      }).eq("id", depositId);
      // Возвращаем средства если были списаны
      if (price > 0) {
        const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", user.id).single();
        if (currentProfile) {
          await supabase.from("profiles").update({
            balance: currentProfile.balance + price
          }).eq("user_id", user.id);
        }
      }
      throw error;
    }
  } catch (error) {
    console.error("Deposit error:", error);
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl90cmFjay1kZXBvc2l0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5pbnRlcmZhY2UgQXV0aG9yRGF0YSB7XG4gIHBlcmZvcm1lcl9uYW1lOiBzdHJpbmc7XG4gIG11c2ljX2F1dGhvcjogc3RyaW5nO1xuICBseXJpY3NfYXV0aG9yOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBEZXBvc2l0UmVxdWVzdCB7XG4gIHRyYWNrSWQ6IHN0cmluZztcbiAgbWV0aG9kOiBcImludGVybmFsXCIgfCBcInBkZlwiIHwgXCJibG9ja2NoYWluXCIgfCBcIm5yaXNcIiB8IFwiaXJtYVwiO1xuICBhdXRob3JEYXRhPzogQXV0aG9yRGF0YTtcbn1cblxuaW50ZXJmYWNlIERlcG9zaXRFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgbWVzc2FnZTogc3RyaW5nO1xufVxuXG4vLyDQk9C10L3QtdGA0LDRhtC40Y8gU0hBLTI1NiDRhdC10YjQsFxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVIYXNoKGRhdGE6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGVuY29kZXIgPSBuZXcgVGV4dEVuY29kZXIoKTtcbiAgY29uc3QgZGF0YUJ1ZmZlciA9IGVuY29kZXIuZW5jb2RlKGRhdGEpO1xuICBjb25zdCBoYXNoQnVmZmVyID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoXCJTSEEtMjU2XCIsIGRhdGFCdWZmZXIpO1xuICBjb25zdCBoYXNoQXJyYXkgPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGhhc2hCdWZmZXIpKTtcbiAgcmV0dXJuIGhhc2hBcnJheS5tYXAoYiA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCBcIjBcIikpLmpvaW4oXCJcIik7XG59XG5cbi8vINCf0LXRgNC10L/QuNGB0YvQstCw0LXQvCDRgdGC0LDRgNGL0LUgU3VwYWJhc2UgVVJMINC90LAg0YLQtdC60YPRidC40LkgQVBJICjQv9C+0YHQu9C1INC80LjQs9GA0LDRhtC40Lggc3RvcmFnZSDQvdCwIGFpbXV6YS5ydSlcbmZ1bmN0aW9uIHJlc29sdmVBdWRpb1VybCh1cmw6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpIHx8IFwiaHR0cHM6Ly9haW11emEucnVcIjtcbiAgY29uc3Qgb2xkU3VwYWJhc2UgPSAvaHR0cHM6XFwvXFwvW2Etel0rXFwuc3VwYWJhc2VcXC5jby87XG4gIGlmIChvbGRTdXBhYmFzZS50ZXN0KHVybCkpIHtcbiAgICBjb25zdCBwYXRoID0gbmV3IFVSTCh1cmwpLnBhdGhuYW1lO1xuICAgIHJldHVybiBgJHtzdXBhYmFzZVVybH0ke3BhdGh9YDtcbiAgfVxuICByZXR1cm4gdXJsO1xufVxuXG4vLyDQn9C+0LvRg9GH0LDQtdC8INGF0LXRiCDQsNGD0LTQuNC+0YTQsNC50LvQsFxuYXN5bmMgZnVuY3Rpb24gZ2V0QXVkaW9IYXNoKGF1ZGlvVXJsOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCByZXNvbHZlZFVybCA9IHJlc29sdmVBdWRpb1VybChhdWRpb1VybCk7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChyZXNvbHZlZFVybCk7XG4gICAgY29uc3QgYnVmZmVyID0gYXdhaXQgcmVzcG9uc2UuYXJyYXlCdWZmZXIoKTtcbiAgICBjb25zdCBoYXNoQnVmZmVyID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoXCJTSEEtMjU2XCIsIGJ1ZmZlcik7XG4gICAgY29uc3QgaGFzaEFycmF5ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShoYXNoQnVmZmVyKSk7XG4gICAgcmV0dXJuIGhhc2hBcnJheS5tYXAoYiA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCBcIjBcIikpLmpvaW4oXCJcIik7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGF1ZGlvIGZvciBoYXNoOlwiLCBlcnJvcik7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQv9C+0LvRg9GH0LjRgtGMINCw0YPQtNC40L7RhNCw0LnQuyDQtNC70Y8g0YXQtdGI0LjRgNC+0LLQsNC90LjRj1wiKTtcbiAgfVxufVxuXG4vLyBPcGVuVGltZXN0YW1wcyDigJQgQVBJINC+0LbQuNC00LDQtdGCIDMyINCx0LDQudGC0LAgKGJpbmFyeSksINC90LUgaGV4LdGB0YLRgNC+0LrRg1xuYXN5bmMgZnVuY3Rpb24gc3VibWl0VG9PcGVuVGltZXN0YW1wcyhoYXNoSGV4OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBoYXNoQnl0ZXMgPSBuZXcgVWludDhBcnJheShcbiAgICBoYXNoSGV4Lm1hdGNoKC8uezJ9L2cpIS5tYXAoKGIpID0+IHBhcnNlSW50KGIsIDE2KSlcbiAgKTtcbiAgY29uc3QgY2FsZW5kYXJzID0gW1xuICAgIFwiaHR0cHM6Ly9hLnBvb2wub3BlbnRpbWVzdGFtcHMub3JnL2RpZ2VzdFwiLFxuICAgIFwiaHR0cHM6Ly9iLnBvb2wub3BlbnRpbWVzdGFtcHMub3JnL2RpZ2VzdFwiLFxuICAgIFwiaHR0cHM6Ly9maW5uZXkuY2FsZW5kYXIuZXRlcm5pdHl3YWxsLmNvbS9kaWdlc3RcIixcbiAgXTtcbiAgZm9yIChjb25zdCBjYWxlbmRhciBvZiBjYWxlbmRhcnMpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGZldGNoKGNhbGVuZGFyLCB7XG4gICAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL29jdGV0LXN0cmVhbVwiLFxuICAgICAgICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi92bmQub3BlbnRpbWVzdGFtcHMudjFcIixcbiAgICAgICAgfSxcbiAgICAgICAgYm9keTogaGFzaEJ5dGVzLFxuICAgICAgfSk7XG4gICAgICBpZiAocmVzcC5vaykge1xuICAgICAgICByZXR1cm4gYG90c18ke0RhdGUubm93KCl9YDtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmxvZyhgW09UU10gJHtjYWxlbmRhcn0gZmFpbGVkOmAsIGUpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gYG90c19wZW5kaW5nXyR7aGFzaEhleC5zdWJzdHJpbmcoMCwgMTYpfWA7XG59XG5cbi8vIG4nUklTIEFQSSDQuNC90YLQtdCz0YDQsNGG0LjRj1xuYXN5bmMgZnVuY3Rpb24gc3VibWl0VG9OcmlzKFxuICB0cmFjazogYW55LFxuICBoYXNoOiBzdHJpbmcsXG4gIGFwaUtleTogc3RyaW5nLFxuICBhcGlVcmw6IHN0cmluZ1xuKTogUHJvbWlzZTx7IGRlcG9zaXRJZDogc3RyaW5nOyBjZXJ0aWZpY2F0ZVVybD86IHN0cmluZyB9PiB7XG4gIGlmICghYXBpS2V5KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiQVBJINC60LvRjtGHIG4nUklTINC90LUg0L3QsNGB0YLRgNC+0LXQvVwiKTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHthcGlVcmx9L2RlcG9zaXRzYCwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHthcGlLZXl9YCxcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0eXBlOiBcImF1ZGlvXCIsXG4gICAgICAgIHRpdGxlOiB0cmFjay50aXRsZSxcbiAgICAgICAgYXV0aG9yOiB0cmFjay5wZXJmb3JtZXJfbmFtZSB8fCB0cmFjay5wcm9maWxlcz8udXNlcm5hbWUsXG4gICAgICAgIGhhc2g6IGhhc2gsXG4gICAgICAgIG1ldGFkYXRhOiB7XG4gICAgICAgICAgZHVyYXRpb246IHRyYWNrLmR1cmF0aW9uLFxuICAgICAgICAgIGdlbnJlOiB0cmFjay5nZW5yZT8ubmFtZV9ydSxcbiAgICAgICAgICBjcmVhdGVkX2F0OiB0cmFjay5jcmVhdGVkX2F0LFxuICAgICAgICAgIGx5cmljc19hdXRob3I6IHRyYWNrLmx5cmljc19hdXRob3IsXG4gICAgICAgICAgbXVzaWNfYXV0aG9yOiB0cmFjay5tdXNpY19hdXRob3IsXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICB9KTtcblxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIGNvbnN0IGVycm9yID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBuJ1JJUyBBUEkgZXJyb3I6ICR7ZXJyb3J9YCk7XG4gICAgfVxuXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgIHJldHVybiB7XG4gICAgICBkZXBvc2l0SWQ6IHJlc3VsdC5kZXBvc2l0X2lkIHx8IHJlc3VsdC5pZCxcbiAgICAgIGNlcnRpZmljYXRlVXJsOiByZXN1bHQuY2VydGlmaWNhdGVfdXJsLFxuICAgIH07XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIm4nUklTIGVycm9yOlwiLCBlcnJvcik7XG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cbn1cblxuLy8gSVJNQSBBUEkg0LjQvdGC0LXQs9GA0LDRhtC40Y9cbmFzeW5jIGZ1bmN0aW9uIHN1Ym1pdFRvSXJtYShcbiAgdHJhY2s6IGFueSxcbiAgaGFzaDogc3RyaW5nLFxuICBhcGlLZXk6IHN0cmluZyxcbiAgYXBpVXJsOiBzdHJpbmdcbik6IFByb21pc2U8eyBkZXBvc2l0SWQ6IHN0cmluZzsgY2VydGlmaWNhdGVVcmw/OiBzdHJpbmcgfT4ge1xuICBpZiAoIWFwaUtleSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkFQSSDQutC70Y7RhyBJUk1BINC90LUg0L3QsNGB0YLRgNC+0LXQvVwiKTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHthcGlVcmx9L3JlZ2lzdGVyYCwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJYLUFQSS1LZXlcIjogYXBpS2V5LFxuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHdvcmtfdHlwZTogXCJtdXNpY1wiLFxuICAgICAgICB0aXRsZTogdHJhY2sudGl0bGUsXG4gICAgICAgIGNyZWF0b3JzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgcm9sZTogXCJhdXRob3JcIixcbiAgICAgICAgICAgIG5hbWU6IHRyYWNrLnBlcmZvcm1lcl9uYW1lIHx8IHRyYWNrLnByb2ZpbGVzPy51c2VybmFtZSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIC4uLih0cmFjay5tdXNpY19hdXRob3IgPyBbeyByb2xlOiBcImNvbXBvc2VyXCIsIG5hbWU6IHRyYWNrLm11c2ljX2F1dGhvciB9XSA6IFtdKSxcbiAgICAgICAgICAuLi4odHJhY2subHlyaWNzX2F1dGhvciA/IFt7IHJvbGU6IFwibHlyaWNpc3RcIiwgbmFtZTogdHJhY2subHlyaWNzX2F1dGhvciB9XSA6IFtdKSxcbiAgICAgICAgXSxcbiAgICAgICAgZmlsZV9oYXNoOiBoYXNoLFxuICAgICAgICBhZGRpdGlvbmFsX2luZm86IHtcbiAgICAgICAgICBkdXJhdGlvbl9zZWNvbmRzOiB0cmFjay5kdXJhdGlvbixcbiAgICAgICAgICBnZW5yZTogdHJhY2suZ2VucmU/Lm5hbWVfcnUsXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICB9KTtcblxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIGNvbnN0IGVycm9yID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBJUk1BIEFQSSBlcnJvcjogJHtlcnJvcn1gKTtcbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIGRlcG9zaXRJZDogcmVzdWx0LnJlZ2lzdHJhdGlvbl9pZCB8fCByZXN1bHQuaWQsXG4gICAgICBjZXJ0aWZpY2F0ZVVybDogcmVzdWx0LmNlcnRpZmljYXRlX3VybCxcbiAgICB9O1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJJUk1BIGVycm9yOlwiLCBlcnJvcik7XG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cbn1cblxuLy8g0JPQtdC90LXRgNCw0YbQuNGPIFBERiDRgdC10YDRgtC40YTQuNC60LDRgtCwXG5hc3luYyBmdW5jdGlvbiBnZW5lcmF0ZVBkZkNlcnRpZmljYXRlKFxuICBzdXBhYmFzZTogYW55LFxuICB0cmFjazogYW55LFxuICBoYXNoOiBzdHJpbmcsXG4gIGRlcG9zaXRJZDogc3RyaW5nLFxuICBhdXRob3JEYXRhOiB7IHBlcmZvcm1lcl9uYW1lOiBzdHJpbmc7IG11c2ljX2F1dGhvcjogc3RyaW5nOyBseXJpY3NfYXV0aG9yOiBzdHJpbmcgfVxuKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc3QgcHVibGljQmFzZSA9IERlbm8uZW52LmdldChcIkJBU0VfVVJMXCIpIHx8IFwiaHR0cHM6Ly9haW11emEucnVcIjtcbiAgY29uc3QgdmVyaWZ5VXJsID0gYCR7cHVibGljQmFzZX0vdmVyaWZ5P2hhc2g9JHtlbmNvZGVVUklDb21wb25lbnQoaGFzaCl9YDtcbiAgY29uc3QgcXJDb2RlVXJsID0gYGh0dHBzOi8vYXBpLnFyc2VydmVyLmNvbS92MS9jcmVhdGUtcXItY29kZS8/c2l6ZT0xMjB4MTIwJmRhdGE9JHtlbmNvZGVVUklDb21wb25lbnQodmVyaWZ5VXJsKX1gO1xuXG4gIGNvbnN0IGNlcnRpZmljYXRlRGF0YSA9IHtcbiAgICB0aXRsZTogXCLQkNCy0YLQvtGA0YHQutC+0LUg0YHQstC40LTQtdGC0LXQu9GM0YHRgtCy0L5cIixcbiAgICB0cmFja1RpdGxlOiB0cmFjay50aXRsZSB8fCBcItCR0LXQtyDQvdCw0LfQstCw0L3QuNGPXCIsXG4gICAgcGVyZm9ybWVyOiBhdXRob3JEYXRhLnBlcmZvcm1lcl9uYW1lIHx8IFwi0J3QtSDRg9C60LDQt9Cw0L1cIixcbiAgICBtdXNpY0F1dGhvcjogYXV0aG9yRGF0YS5tdXNpY19hdXRob3IgfHwgXCJcIixcbiAgICBseXJpY3NBdXRob3I6IGF1dGhvckRhdGEubHlyaWNzX2F1dGhvciB8fCBcIlwiLFxuICAgIGZpbGVIYXNoOiBoYXNoLFxuICAgIGRlcG9zaXRJZDogZGVwb3NpdElkLFxuICAgIGRlcG9zaXREYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgcGxhdGZvcm06IFwiYWltdXphLnJ1XCIsXG4gICAgbGFiZWw6IFwi0JvQtdC50LHQuyDQndCe0KLQkCAtINCk0JXQr1wiLFxuICAgIGxhYmVsRnVsbDogJ9Ce0J7QniBcItCc0YPQt9GL0LrQsNC70YzQvdGL0Lkg0LvQtdC50LHQuyDQndCe0KLQkC3QpNCV0K9cIicsXG4gICAgdmVyaWZ5VXJsLFxuICAgIHFyQ29kZVVybCxcbiAgfTtcblxuICBjb25zdCBmb3JtYXR0ZWREYXRlID0gbmV3IERhdGUoY2VydGlmaWNhdGVEYXRhLmRlcG9zaXREYXRlKS50b0xvY2FsZVN0cmluZygncnUtUlUnLCB7XG4gICAgZGF5OiAnMi1kaWdpdCcsXG4gICAgbW9udGg6ICcyLWRpZ2l0JywgXG4gICAgeWVhcjogJ251bWVyaWMnLFxuICAgIGhvdXI6ICcyLWRpZ2l0JyxcbiAgICBtaW51dGU6ICcyLWRpZ2l0JyxcbiAgICBzZWNvbmQ6ICcyLWRpZ2l0J1xuICB9KTtcblxuICAvLyBIVE1MINGB0LXRgNGC0LjRhNC40LrQsNGCINGBIFFSLdC60L7QtNC+0Lwg0Lgg0YHRgtC40LvRj9C80Lgg0LTQu9GPINC/0LXRh9Cw0YLQuFxuICBjb25zdCBodG1sQ29udGVudCA9IGA8IURPQ1RZUEUgaHRtbD5cbjxodG1sIGxhbmc9XCJydVwiPlxuPGhlYWQ+XG4gIDxtZXRhIGNoYXJzZXQ9XCJVVEYtOFwiPlxuICA8bWV0YSBuYW1lPVwidmlld3BvcnRcIiBjb250ZW50PVwid2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEuMFwiPlxuICA8dGl0bGU+0KHQtdGA0YLQuNGE0LjQutCw0YIg0LTQtdC/0L7QvdC40YDQvtCy0LDQvdC40Y8gLSAke2NlcnRpZmljYXRlRGF0YS50cmFja1RpdGxlfTwvdGl0bGU+XG4gIDxzdHlsZT5cbiAgICBAbWVkaWEgcHJpbnQge1xuICAgICAgYm9keSB7IC13ZWJraXQtcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdDsgcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdDsgfVxuICAgICAgLm5vLXByaW50IHsgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50OyB9XG4gICAgICBAcGFnZSB7IHNpemU6IEE0OyBtYXJnaW46IDE1bW07IH1cbiAgICB9XG4gICAgXG4gICAgKiB7IGJveC1zaXppbmc6IGJvcmRlci1ib3g7IG1hcmdpbjogMDsgcGFkZGluZzogMDsgfVxuICAgIFxuICAgIGJvZHkgeyBcbiAgICAgIGZvbnQtZmFtaWx5OiAnVGltZXMgTmV3IFJvbWFuJywgJ0dlb3JnaWEnLCBzZXJpZjsgXG4gICAgICBwYWRkaW5nOiA0MHB4OyBcbiAgICAgIG1heC13aWR0aDogODAwcHg7IFxuICAgICAgbWFyZ2luOiAwIGF1dG87IFxuICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICAgIGNvbG9yOiAjMWExYTFhO1xuICAgICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICB9XG4gICAgXG4gICAgLmNlcnRpZmljYXRlIHtcbiAgICAgIGJvcmRlcjogM3B4IGRvdWJsZSAjMmMzZTUwO1xuICAgICAgcGFkZGluZzogNDBweDtcbiAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICNmZWZlZmUgMCUsICNmOGY5ZmEgMTAwJSk7XG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgfVxuICAgIFxuICAgIC5jZXJ0aWZpY2F0ZTo6YmVmb3JlIHtcbiAgICAgIGNvbnRlbnQ6ICcnO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgdG9wOiAxMHB4O1xuICAgICAgbGVmdDogMTBweDtcbiAgICAgIHJpZ2h0OiAxMHB4O1xuICAgICAgYm90dG9tOiAxMHB4O1xuICAgICAgYm9yZGVyOiAxcHggc29saWQgI2JkYzNjNztcbiAgICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgIH1cbiAgICBcbiAgICAuaGVhZGVyIHsgXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7IFxuICAgICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICMyYzNlNTA7IFxuICAgICAgcGFkZGluZy1ib3R0b206IDI1cHg7IFxuICAgICAgbWFyZ2luLWJvdHRvbTogMzBweDsgXG4gICAgfVxuICAgIFxuICAgIC5sb2dvLXNlY3Rpb24ge1xuICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgICB9XG4gICAgXG4gICAgLmxhYmVsLW5hbWUge1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgY29sb3I6ICM1NTU7XG4gICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcbiAgICB9XG4gICAgXG4gICAgLndlYnNpdGUge1xuICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgY29sb3I6ICMyYzNlNTA7XG4gICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAycHg7XG4gICAgfVxuICAgIFxuICAgIC50aXRsZSB7IFxuICAgICAgZm9udC1zaXplOiAzMnB4OyBcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkOyBcbiAgICAgIGNvbG9yOiAjMWExYTFhOyBcbiAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICBsZXR0ZXItc3BhY2luZzogM3B4O1xuICAgICAgbWFyZ2luLXRvcDogMjBweDtcbiAgICB9XG4gICAgXG4gICAgLnN1YnRpdGxlIHsgXG4gICAgICBmb250LXNpemU6IDE2cHg7IFxuICAgICAgY29sb3I6ICM2NjY7IFxuICAgICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICB9XG4gICAgXG4gICAgLmNvbnRlbnQge1xuICAgICAgZGlzcGxheTogZ3JpZDtcbiAgICAgIGdhcDogMThweDtcbiAgICB9XG4gICAgXG4gICAgLnNlY3Rpb24geyBcbiAgICAgIGRpc3BsYXk6IGdyaWQ7XG4gICAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDE4MHB4IDFmcjtcbiAgICAgIGFsaWduLWl0ZW1zOiBzdGFydDtcbiAgICAgIGdhcDogMTVweDtcbiAgICB9XG4gICAgXG4gICAgLmxhYmVsIHsgXG4gICAgICBmb250LXdlaWdodDogYm9sZDsgXG4gICAgICBjb2xvcjogIzJjM2U1MDtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIHBhZGRpbmctdG9wOiAxMHB4O1xuICAgIH1cbiAgICBcbiAgICAudmFsdWUgeyBcbiAgICAgIHBhZGRpbmc6IDEycHggMTVweDsgXG4gICAgICBiYWNrZ3JvdW5kOiAjZmZmOyBcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XG4gICAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICBib3gtc2hhZG93OiBpbnNldCAwIDFweCAzcHggcmdiYSgwLDAsMCwwLjA1KTtcbiAgICB9XG4gICAgXG4gICAgLmhhc2ggeyBcbiAgICAgIGZvbnQtZmFtaWx5OiAnQ291cmllciBOZXcnLCBtb25vc3BhY2U7IFxuICAgICAgZm9udC1zaXplOiAxMXB4OyBcbiAgICAgIHdvcmQtYnJlYWs6IGJyZWFrLWFsbDtcbiAgICAgIGNvbG9yOiAjNTU1O1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDAuNXB4O1xuICAgIH1cbiAgICBcbiAgICAuc2VhbCB7IFxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyOyBcbiAgICAgIG1hcmdpbjogMzVweCAwIDI1cHg7IFxuICAgIH1cbiAgICBcbiAgICAuc2VhbC1jb250YWluZXIge1xuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIH1cbiAgICBcbiAgICAuc2VhbC10ZXh0IHsgXG4gICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7IFxuICAgICAgcGFkZGluZzogMjBweCAzNXB4OyBcbiAgICAgIGJvcmRlcjogNHB4IGRvdWJsZSAjMmMzZTUwOyBcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgY29sb3I6ICMyYzNlNTA7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICBsaW5lLWhlaWdodDogMS40O1xuICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgI2ZmZiAwJSwgI2YwZjBmMCAxMDAlKTtcbiAgICB9XG4gICAgXG4gICAgLnFyLXNlY3Rpb24ge1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgbWFyZ2luOiAyNXB4IDAgMjBweDtcbiAgICAgIHBhZGRpbmc6IDE1cHg7XG4gICAgICBib3JkZXI6IDFweCBkYXNoZWQgI2JkYzNjNztcbiAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICAgIGJhY2tncm91bmQ6ICNmYWZhZmE7XG4gICAgfVxuICAgIC5xci1jYXB0aW9uIHtcbiAgICAgIGZvbnQtc2l6ZTogMTFweDtcbiAgICAgIGNvbG9yOiAjNjY2O1xuICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICB9XG4gICAgLnFyLWxpbmsgeyBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7IH1cbiAgICAucXItaW1hZ2UgeyBkaXNwbGF5OiBibG9jazsgd2lkdGg6IDEyMHB4OyBoZWlnaHQ6IDEyMHB4OyBtYXJnaW46IDAgYXV0bzsgfVxuICAgIFxuICAgIC5mb290ZXIgeyBcbiAgICAgIG1hcmdpbi10b3A6IDMwcHg7IFxuICAgICAgcGFkZGluZy10b3A6IDIwcHg7IFxuICAgICAgYm9yZGVyLXRvcDogMnB4IHNvbGlkICMyYzNlNTA7IFxuICAgICAgZm9udC1zaXplOiAxMnB4OyBcbiAgICAgIGNvbG9yOiAjNjY2OyBcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgIGxpbmUtaGVpZ2h0OiAxLjg7XG4gICAgfVxuICAgIFxuICAgIC5mb290ZXIgcCB7XG4gICAgICBtYXJnaW46IDVweCAwO1xuICAgIH1cbiAgICBcbiAgICAuZm9vdGVyIC5wbGF0Zm9ybSB7XG4gICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgIGNvbG9yOiAjMmMzZTUwO1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgbWFyZ2luLXRvcDogMTVweDtcbiAgICB9XG4gICAgXG4gICAgLnByaW50LWJ0biB7XG4gICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgIG1hcmdpbjogMjBweCBhdXRvO1xuICAgICAgcGFkZGluZzogMTJweCAzMHB4O1xuICAgICAgYmFja2dyb3VuZDogIzJjM2U1MDtcbiAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgYm9yZGVyOiBub25lO1xuICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgZm9udC1mYW1pbHk6IGluaGVyaXQ7XG4gICAgfVxuICAgIFxuICAgIC5wcmludC1idG46aG92ZXIge1xuICAgICAgYmFja2dyb3VuZDogIzFhMjUyZjtcbiAgICB9XG4gIDwvc3R5bGU+XG48L2hlYWQ+XG48Ym9keT5cbiAgPGJ1dHRvbiBjbGFzcz1cInByaW50LWJ0biBuby1wcmludFwiIG9uY2xpY2s9XCJ3aW5kb3cucHJpbnQoKVwiPvCfk4Qg0KHQvtGF0YDQsNC90LjRgtGMINC60LDQuiBQREYgLyDQoNCw0YHQv9C10YfQsNGC0LDRgtGMPC9idXR0b24+XG4gIFxuICAgIDxkaXYgY2xhc3M9XCJjZXJ0aWZpY2F0ZVwiPlxuICAgIDxkaXYgY2xhc3M9XCJoZWFkZXJcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJsb2dvLXNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxhYmVsLW5hbWVcIj4ke2NlcnRpZmljYXRlRGF0YS5sYWJlbH08L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cIndlYnNpdGVcIj7RgdCw0LnRgiAke2NlcnRpZmljYXRlRGF0YS5wbGF0Zm9ybX08L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInRpdGxlXCI+0JDQktCi0J7QoNCh0JrQntCVINCh0JLQmNCU0JXQotCV0JvQrNCh0KLQktCePC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwic3VidGl0bGVcIj7QnNGD0LfRi9C60LDQu9GM0L3QvtC1INC/0YDQvtC40LfQstC10LTQtdC90LjQtTwvZGl2PlxuICAgIDwvZGl2PlxuICAgIFxuICAgIDxkaXYgY2xhc3M9XCJjb250ZW50XCI+XG4gICAgICA8ZGl2IGNsYXNzPVwic2VjdGlvblwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwibGFiZWxcIj7QndCw0LfQstCw0L3QuNC1INC/0YDQvtC40LfQstC10LTQtdC90LjRjzo8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInZhbHVlXCI+JHtjZXJ0aWZpY2F0ZURhdGEudHJhY2tUaXRsZX08L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgXG4gICAgICA8ZGl2IGNsYXNzPVwic2VjdGlvblwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwibGFiZWxcIj7QmNGB0L/QvtC70L3QuNGC0LXQu9GMOjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwidmFsdWVcIj4ke2NlcnRpZmljYXRlRGF0YS5wZXJmb3JtZXJ9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIFxuICAgICAgJHtjZXJ0aWZpY2F0ZURhdGEubXVzaWNBdXRob3IgPyBgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+0JDQstGC0L7RgCDQvNGD0LfRi9C60Lg6PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ2YWx1ZVwiPiR7Y2VydGlmaWNhdGVEYXRhLm11c2ljQXV0aG9yfTwvZGl2PlxuICAgICAgPC9kaXY+YCA6ICcnfVxuICAgICAgXG4gICAgICAke2NlcnRpZmljYXRlRGF0YS5seXJpY3NBdXRob3IgPyBgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+0JDQstGC0L7RgCDRgtC10LrRgdGC0LA6PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ2YWx1ZVwiPiR7Y2VydGlmaWNhdGVEYXRhLmx5cmljc0F1dGhvcn08L2Rpdj5cbiAgICAgIDwvZGl2PmAgOiAnJ31cbiAgICAgIFxuICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+0KbQuNGE0YDQvtCy0L7QuSDQvtGC0L/QtdGH0LDRgtC+0LogKFNIQS0yNTYpOjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwidmFsdWUgaGFzaFwiPiR7Y2VydGlmaWNhdGVEYXRhLmZpbGVIYXNofTwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICBcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbFwiPtCY0LTQtdC90YLQuNGE0LjQutCw0YLQvtGAOjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwidmFsdWVcIj4ke2NlcnRpZmljYXRlRGF0YS5kZXBvc2l0SWR9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIFxuICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+0JTQsNGC0LAg0YDQtdCz0LjRgdGC0YDQsNGG0LjQuDo8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInZhbHVlXCI+JHtmb3JtYXR0ZWREYXRlfTwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgXG4gICAgPGRpdiBjbGFzcz1cInNlYWxcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzZWFsLWNvbnRhaW5lclwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwic2VhbC10ZXh0XCI+0J3QntCi0JAt0KTQldCvPGJyLz7inJMgVmVyaWZpZWQ8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIFxuICAgIDxkaXYgY2xhc3M9XCJxci1zZWN0aW9uXCI+XG4gICAgICA8cCBjbGFzcz1cInFyLWNhcHRpb25cIj7Qn9GA0L7QstC10YDQutCwINC/0L7QtNC70LjQvdC90L7RgdGC0Lgg4oCUINC+0YLRgdC60LDQvdC40YDRg9C50YLQtSBRUi3QutC+0LQ8L3A+XG4gICAgICA8YSBocmVmPVwiJHtjZXJ0aWZpY2F0ZURhdGEudmVyaWZ5VXJsfVwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCIgY2xhc3M9XCJxci1saW5rXCI+XG4gICAgICAgIDxpbWcgc3JjPVwiJHtjZXJ0aWZpY2F0ZURhdGEucXJDb2RlVXJsfVwiIGFsdD1cIlFSLdC60L7QtCDQtNC70Y8g0L/RgNC+0LLQtdGA0LrQuFwiIGNsYXNzPVwicXItaW1hZ2VcIiAvPlxuICAgICAgPC9hPlxuICAgIDwvZGl2PlxuICAgIFxuICAgIDxkaXYgY2xhc3M9XCJmb290ZXJcIj5cbiAgICAgIDxwPtCU0LDQvdC90L7QtSDRgdCy0LjQtNC10YLQtdC70YzRgdGC0LLQviDQv9C+0LTRgtCy0LXRgNC20LTQsNC10YIg0YTQsNC60YIg0YHRg9GJ0LXRgdGC0LLQvtCy0LDQvdC40Y8g0L/RgNC+0LjQt9Cy0LXQtNC10L3QuNGPINC90LAg0YPQutCw0LfQsNC90L3Rg9GOINC00LDRgtGDLjwvcD5cbiAgICAgIDxwPtCm0LjRhNGA0L7QstC+0Lkg0L7RgtC/0LXRh9Cw0YLQvtC6INC/0L7Qt9Cy0L7Qu9GP0LXRgiDQvtC00L3QvtC30L3QsNGH0L3QviDQuNC00LXQvdGC0LjRhNC40YbQuNGA0L7QstCw0YLRjCDQvtGA0LjQs9C40L3QsNC70YzQvdGL0Lkg0YTQsNC50LsuPC9wPlxuICAgICAgPHAgY2xhc3M9XCJwbGF0Zm9ybVwiPiR7Y2VydGlmaWNhdGVEYXRhLmxhYmVsRnVsbH0g4oCiINGB0LDQudGCICR7Y2VydGlmaWNhdGVEYXRhLnBsYXRmb3JtfTwvcD5cbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG48L2JvZHk+XG48L2h0bWw+YDtcblxuICAvLyDQodC+0YXRgNCw0L3Rj9C10LwgSFRNTCDQutCw0Log0YTQsNC50Lsg0YEg0L/RgNCw0LLQuNC70YzQvdC+0Lkg0LrQvtC00LjRgNC+0LLQutC+0Lkg0LTQu9GPINGB0LrQsNGH0LjQstCw0L3QuNGPXG4gIGNvbnN0IGZpbGVOYW1lID0gYGNlcnRpZmljYXRlXyR7ZGVwb3NpdElkfS5odG1sYDtcbiAgY29uc3Qgc2FmZVRpdGxlID0gKHRyYWNrLnRpdGxlIHx8IFwi0JHQtdC3INC90LDQt9Cy0LDQvdC40Y9cIikucmVwbGFjZSgvW15hLXpBLVrQsC3Rj9CQLdCv0ZHQgTAtOVxcc10vZywgJ18nKS50cmltKCk7XG4gIGNvbnN0IGh0bWxCeXRlcyA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShodG1sQ29udGVudCk7XG4gIFxuICAvLyDQodC+0LfQtNCw0ZHQvCBCbG9iINGBINC/0YDQsNCy0LjQu9GM0L3Ri9C8IGNvbnRlbnQtdHlwZVxuICBjb25zdCBibG9iID0gbmV3IEJsb2IoW2h0bWxCeXRlc10sIHsgdHlwZTogXCJ0ZXh0L2h0bWw7Y2hhcnNldD11dGYtOFwiIH0pO1xuICBcbiAgY29uc3QgeyBlcnJvcjogdXBsb2FkRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLnN0b3JhZ2VcbiAgICAuZnJvbShcImNlcnRpZmljYXRlc1wiKVxuICAgIC51cGxvYWQoZmlsZU5hbWUsIGJsb2IsIHtcbiAgICAgIGNvbnRlbnRUeXBlOiBcInRleHQvaHRtbDtjaGFyc2V0PXV0Zi04XCIsXG4gICAgICBjYWNoZUNvbnRyb2w6IFwiMzYwMFwiLFxuICAgICAgdXBzZXJ0OiB0cnVlLFxuICAgIH0pO1xuXG4gIGlmICh1cGxvYWRFcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGxvYWRpbmcgY2VydGlmaWNhdGU6XCIsIHVwbG9hZEVycm9yKTtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7RhdGA0LDQvdC40YLRjCDRgdC10YDRgtC40YTQuNC60LDRglwiKTtcbiAgfVxuXG4gIC8vIFVSTCDRgdC10YDRgtC40YTQuNC60LDRgtCwICjQv9GD0LHQu9C40YfQvdGL0Lkg4oCUINC00LvRjyDQvtGC0LrRgNGL0YLQuNGPINCyINCx0YDQsNGD0LfQtdGA0LU7ID9kb3dubG9hZD0g0LTQu9GPINGB0LrQsNGH0LjQstCw0L3QuNGPKVxuICBjb25zdCBwdWJsaWNQYXRoID0gYC9zdG9yYWdlL3YxL29iamVjdC9wdWJsaWMvY2VydGlmaWNhdGVzLyR7ZmlsZU5hbWV9YDtcbiAgY29uc3QgZG93bmxvYWROYW1lID0gYNCQ0LLRgtC+0YDRgdC60L7QtV/RgdCy0LjQtNC10YLQtdC70YzRgdGC0LLQvl8ke3NhZmVUaXRsZX0uaHRtbGA7XG4gIHJldHVybiBgJHtwdWJsaWNCYXNlfSR7cHVibGljUGF0aH0/ZG93bmxvYWQ9JHtlbmNvZGVVUklDb21wb25lbnQoZG93bmxvYWROYW1lKX1gO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgLy8g0J/QvtC70YPRh9Cw0LXQvCDQv9C+0LvRjNC30L7QstCw0YLQtdC70Y9cbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0LDQstGC0L7RgNC40LfQvtCy0LDQvVwiKTtcbiAgICB9XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IGF1dGhFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKHRva2VuKTtcblxuICAgIC8vINCa0LvQuNC10L3RgiDRgSBKV1Qg0L/QvtC70YzQt9C+0LLQsNGC0LXQu9GPIOKAlCDQtNC70Y8gUkxTIChhdXRoLnVpZCgpID0gdXNlcl9pZCDQv9GA0LggSU5TRVJUL0RFTEVURSlcbiAgICBjb25zdCB1c2VyU3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlU2VydmljZUtleSwge1xuICAgICAgZ2xvYmFsOiB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAgfSB9LFxuICAgIH0pO1xuICAgIFxuICAgIGlmIChhdXRoRXJyb3IgfHwgIXVzZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0LDQstGC0L7RgNC40LfQvtCy0LDQvVwiKTtcbiAgICB9XG5cbiAgICBjb25zdCB7IHRyYWNrSWQsIG1ldGhvZCwgYXV0aG9yRGF0YSB9OiBEZXBvc2l0UmVxdWVzdCA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coYERlcG9zaXQgcmVxdWVzdDogdHJhY2s9JHt0cmFja0lkfSwgbWV0aG9kPSR7bWV0aG9kfSwgdXNlcj0ke3VzZXIuaWR9YCk7XG5cbiAgICAvLyDQn9C+0LvRg9GH0LDQtdC8INGC0YDQtdC6IChhdWRpb191cmwsIG1hc3Rlcl9hdWRpb191cmwsIG5vcm1hbGl6ZWRfYXVkaW9fdXJsIOKAlCDQu9GO0LHQvtC5INC00L7RgdGC0YPQv9C90YvQuSBVUkwpXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjaywgZXJyb3I6IHRyYWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLnNlbGVjdChgXG4gICAgICAgIGlkLCB0aXRsZSwgYXVkaW9fdXJsLCBtYXN0ZXJfYXVkaW9fdXJsLCBub3JtYWxpemVkX2F1ZGlvX3VybCwgZHVyYXRpb24sIGNyZWF0ZWRfYXQsXG4gICAgICAgIHBlcmZvcm1lcl9uYW1lLCBtdXNpY19hdXRob3IsIGx5cmljc19hdXRob3IsIHVzZXJfaWQsXG4gICAgICAgIGdlbnJlOmdlbnJlcyhuYW1lX3J1KVxuICAgICAgYClcbiAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICAvLyDQn9C+0LvRg9GH0LDQtdC8IHVzZXJuYW1lINC+0YLQtNC10LvRjNC90L5cbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAuc2VsZWN0KFwidXNlcm5hbWVcIilcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGNvbnN0IHVzZXJuYW1lID0gcHJvZmlsZT8udXNlcm5hbWUgfHwgXCJVbmtub3duXCI7XG5cbiAgICAvLyDQmNGB0L/QvtC70YzQt9GD0LXQvCDQtNCw0L3QvdGL0LUg0LDQstGC0L7RgNCwINC40Lcg0LfQsNC/0YDQvtGB0LAg0LjQu9C4INC40Lcg0YLRgNC10LrQsFxuICAgIGNvbnN0IGVmZmVjdGl2ZUF1dGhvckRhdGEgPSB7XG4gICAgICBwZXJmb3JtZXJfbmFtZTogYXV0aG9yRGF0YT8ucGVyZm9ybWVyX25hbWUgfHwgdHJhY2s/LnBlcmZvcm1lcl9uYW1lIHx8IHVzZXJuYW1lLFxuICAgICAgbXVzaWNfYXV0aG9yOiBhdXRob3JEYXRhPy5tdXNpY19hdXRob3IgfHwgdHJhY2s/Lm11c2ljX2F1dGhvciB8fCBcIlwiLFxuICAgICAgbHlyaWNzX2F1dGhvcjogYXV0aG9yRGF0YT8ubHlyaWNzX2F1dGhvciB8fCB0cmFjaz8ubHlyaWNzX2F1dGhvciB8fCBcIlwiLFxuICAgIH07XG5cbiAgICBpZiAodHJhY2tFcnJvciB8fCAhdHJhY2spIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCi0YDQtdC6INC90LUg0L3QsNC50LTQtdC9INC40LvQuCDQvdC1INC/0YDQuNC90LDQtNC70LXQttC40YIg0LLQsNC8XCIpO1xuICAgIH1cblxuICAgIC8vIEZhbGxiYWNrOiDRhNCw0LnQuyDQvNC+0LbQtdGCINGE0LjQt9C40YfQtdGB0LrQuCDQu9C10LbQsNGC0Ywg0LIgdHJhY2tzL2F1ZGlvL3tpZH0ubXAzLCDQvdC+IFVSTCDQsiDQkdCUINC/0YPRgdGC0L7QuVxuICAgIGNvbnN0IGJhc2VVcmwgPSBzdXBhYmFzZVVybCB8fCBcImh0dHBzOi8vYWltdXphLnJ1XCI7XG4gICAgY29uc3QgYXVkaW9VcmwgPSB0cmFjay5hdWRpb191cmwgfHwgdHJhY2subWFzdGVyX2F1ZGlvX3VybCB8fCB0cmFjay5ub3JtYWxpemVkX2F1ZGlvX3VybFxuICAgICAgfHwgYCR7YmFzZVVybH0vc3RvcmFnZS92MS9vYmplY3QvcHVibGljL3RyYWNrcy9hdWRpby8ke3RyYWNrSWR9Lm1wM2A7XG5cbiAgICAvLyDQn9GA0L7QstC10YDRj9C10Lwg0YHRg9GJ0LXRgdGC0LLRg9GO0YnQtdC1INC00LXQv9C+0L3QuNGA0L7QstCw0L3QuNC1XG4gICAgY29uc3QgeyBkYXRhOiBleGlzdGluZ0RlcG9zaXQgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInRyYWNrX2RlcG9zaXRzXCIpXG4gICAgICAuc2VsZWN0KFwiaWQsIHN0YXR1c1wiKVxuICAgICAgLmVxKFwidHJhY2tfaWRcIiwgdHJhY2tJZClcbiAgICAgIC5lcShcIm1ldGhvZFwiLCBtZXRob2QpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoZXhpc3RpbmdEZXBvc2l0KSB7XG4gICAgICBpZiAoZXhpc3RpbmdEZXBvc2l0LnN0YXR1cyA9PT0gXCJjb21wbGV0ZWRcIikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCLQotGA0LXQuiDRg9C20LUg0LTQtdC/0L7QvdC40YDQvtCy0LDQvSDRjdGC0LjQvCDQvNC10YLQvtC00L7QvFwiKTtcbiAgICAgIH1cbiAgICAgIC8vINCj0LTQsNC70Y/QtdC8IGZhaWxlZCDQuNC70LggcHJvY2Vzc2luZyDQt9Cw0L/QuNGB0LggKHVzZXJTdXBhYmFzZSDQtNC70Y8gUkxTKVxuICAgICAgYXdhaXQgdXNlclN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tfZGVwb3NpdHNcIilcbiAgICAgICAgLmRlbGV0ZSgpXG4gICAgICAgIC5lcShcImlkXCIsIGV4aXN0aW5nRGVwb3NpdC5pZCk7XG4gICAgfVxuXG4gICAgLy8g0J/QvtC70YPRh9Cw0LXQvCDQvdCw0YHRgtGA0L7QudC60LhcbiAgICBjb25zdCB7IGRhdGE6IHNldHRpbmdzIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJzZXR0aW5nc1wiKVxuICAgICAgLnNlbGVjdChcImtleSwgdmFsdWVcIilcbiAgICAgIC5pbihcImtleVwiLCBbXG4gICAgICAgIGBkZXBvc2l0X3ByaWNlXyR7bWV0aG9kfWAsXG4gICAgICAgIFwibnJpc19hcGlfa2V5XCIsXG4gICAgICAgIFwibnJpc19hcGlfdXJsXCIsXG4gICAgICAgIFwiaXJtYV9hcGlfa2V5XCIsIFxuICAgICAgICBcImlybWFfYXBpX3VybFwiLFxuICAgICAgXSk7XG5cbiAgICBjb25zdCBzZXR0aW5nc01hcCA9IG5ldyBNYXAoc2V0dGluZ3M/Lm1hcChzID0+IFtzLmtleSwgcy52YWx1ZV0pIHx8IFtdKTtcbiAgICBjb25zdCBwcmljZUtleSA9IGBkZXBvc2l0X3ByaWNlXyR7bWV0aG9kfWA7XG4gICAgY29uc3QgcHJpY2VWYWx1ZSA9IHNldHRpbmdzTWFwLmdldChwcmljZUtleSk7XG4gICAgY29uc3QgcHJpY2UgPSBwYXJzZUludChwcmljZVZhbHVlIHx8IFwiMFwiLCAxMCk7XG4gICAgXG4gICAgY29uc29sZS5sb2coYERlcG9zaXQgcHJpY2luZzoga2V5PSR7cHJpY2VLZXl9LCByYXdWYWx1ZT0ke3ByaWNlVmFsdWV9LCBwYXJzZWRQcmljZT0ke3ByaWNlfWApO1xuXG4gICAgLy8g0J/RgNC+0LLQtdGA0Y/QtdC8INCx0LDQu9Cw0L3RgSDQtdGB0LvQuCDQv9C70LDRgtC90L5cbiAgICBpZiAocHJpY2UgPiAwKSB7XG4gICAgICBjb25zdCB7IGRhdGE6IHVzZXJQcm9maWxlLCBlcnJvcjogcHJvZmlsZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgICAgLnNpbmdsZSgpO1xuXG4gICAgICBjb25zb2xlLmxvZyhgVXNlciBiYWxhbmNlIGNoZWNrOiBiYWxhbmNlPSR7dXNlclByb2ZpbGU/LmJhbGFuY2V9LCBwcmljZT0ke3ByaWNlfSwgZXJyb3I9JHtwcm9maWxlRXJyb3I/Lm1lc3NhZ2V9YCk7XG5cbiAgICAgIGlmICghdXNlclByb2ZpbGUgfHwgdXNlclByb2ZpbGUuYmFsYW5jZSA8IHByaWNlKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihg0J3QtdC00L7RgdGC0LDRgtC+0YfQvdC+INGB0YDQtdC00YHRgtCyLiDQotGA0LXQsdGD0LXRgtGB0Y86ICR7cHJpY2V9IOKCvSwg0LHQsNC70LDQvdGBOiAke3VzZXJQcm9maWxlPy5iYWxhbmNlIHx8IDB9IOKCvWApO1xuICAgICAgfVxuXG4gICAgICAvLyDQodC/0LjRgdGL0LLQsNC10Lwg0YHRgNC10LTRgdGC0LLQsFxuICAgICAgY29uc3QgbmV3QmFsYW5jZSA9IHVzZXJQcm9maWxlLmJhbGFuY2UgLSBwcmljZTtcbiAgICAgIGNvbnNvbGUubG9nKGBEZWR1Y3RpbmcgYmFsYW5jZTogJHt1c2VyUHJvZmlsZS5iYWxhbmNlfSAtICR7cHJpY2V9ID0gJHtuZXdCYWxhbmNlfWApO1xuICAgICAgXG4gICAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogbmV3QmFsYW5jZSB9KVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpO1xuICAgICAgXG4gICAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkJhbGFuY2UgdXBkYXRlIGVycm9yOlwiLCB1cGRhdGVFcnJvcik7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcItCe0YjQuNCx0LrQsCDRgdC/0LjRgdCw0L3QuNGPINGB0YDQtdC00YHRgtCyXCIpO1xuICAgICAgfVxuICAgICAgXG4gICAgICBjb25zb2xlLmxvZyhgQmFsYW5jZSB1cGRhdGVkIHN1Y2Nlc3NmdWxseSBmb3IgdXNlciAke3VzZXIuaWR9YCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnNvbGUubG9nKGBEZXBvc2l0IGlzIGZyZWUgZm9yIG1ldGhvZCAke21ldGhvZH1gKTtcbiAgICB9XG5cbiAgICAvLyDQk9C10L3QtdGA0LjRgNGD0LXQvCDRhdC10Ygg0LDRg9C00LjQvlxuICAgIGNvbnNvbGUubG9nKFwiR2VuZXJhdGluZyBhdWRpbyBoYXNoLi4uXCIsIHsgdXJsTGVuOiBhdWRpb1VybC5sZW5ndGggfSk7XG4gICAgY29uc3QgZmlsZUhhc2ggPSBhd2FpdCBnZXRBdWRpb0hhc2goYXVkaW9VcmwpO1xuICAgIFxuICAgIC8vINCT0LXQvdC10YDQuNGA0YPQtdC8INGF0LXRiCDQvNC10YLQsNC00LDQvdC90YvRhVxuICAgIGNvbnN0IG1ldGFkYXRhSGFzaCA9IGF3YWl0IGdlbmVyYXRlSGFzaChKU09OLnN0cmluZ2lmeSh7XG4gICAgICB0aXRsZTogdHJhY2sudGl0bGUsXG4gICAgICBwZXJmb3JtZXI6IGVmZmVjdGl2ZUF1dGhvckRhdGEucGVyZm9ybWVyX25hbWUsXG4gICAgICBtdXNpY0F1dGhvcjogZWZmZWN0aXZlQXV0aG9yRGF0YS5tdXNpY19hdXRob3IsXG4gICAgICBseXJpY3NBdXRob3I6IGVmZmVjdGl2ZUF1dGhvckRhdGEubHlyaWNzX2F1dGhvcixcbiAgICAgIGR1cmF0aW9uOiB0cmFjay5kdXJhdGlvbixcbiAgICAgIGZpbGVIYXNoLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfSkpO1xuXG4gICAgLy8g0KHQvtC30LTQsNGR0Lwg0LfQsNC/0LjRgdGMINC00LXQv9C+0L3QuNGA0L7QstCw0L3QuNGPICh1c2VyU3VwYWJhc2Ug0LTQu9GPIFJMUzogYXV0aC51aWQoKSA9IHVzZXJfaWQpXG4gICAgY29uc3QgZGVwb3NpdElkID0gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICBjb25zdCB7IGVycm9yOiBpbnNlcnRFcnJvciB9ID0gYXdhaXQgdXNlclN1cGFiYXNlXG4gICAgICAuZnJvbShcInRyYWNrX2RlcG9zaXRzXCIpXG4gICAgICAudXBzZXJ0KHtcbiAgICAgICAgaWQ6IGRlcG9zaXRJZCxcbiAgICAgICAgdHJhY2tfaWQ6IHRyYWNrSWQsXG4gICAgICAgIHVzZXJfaWQ6IHVzZXIuaWQsXG4gICAgICAgIG1ldGhvZCxcbiAgICAgICAgc3RhdHVzOiBcInByb2Nlc3NpbmdcIixcbiAgICAgICAgZmlsZV9oYXNoOiBmaWxlSGFzaCxcbiAgICAgICAgbWV0YWRhdGFfaGFzaDogbWV0YWRhdGFIYXNoLFxuICAgICAgICBwZXJmb3JtZXJfbmFtZTogZWZmZWN0aXZlQXV0aG9yRGF0YS5wZXJmb3JtZXJfbmFtZSxcbiAgICAgICAgbHlyaWNzX2F1dGhvcjogZWZmZWN0aXZlQXV0aG9yRGF0YS5seXJpY3NfYXV0aG9yLFxuICAgICAgfSk7XG5cbiAgICBpZiAoaW5zZXJ0RXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJJbnNlcnQgZXJyb3I6XCIsIGluc2VydEVycm9yKTtcbiAgICAgIGNvbnN0IG1zZyA9IGluc2VydEVycm9yPy5tZXNzYWdlIHx8IGluc2VydEVycm9yPy5kZXRhaWxzIHx8IFwi0J3QtSDRg9C00LDQu9C+0YHRjCDRgdC+0LfQtNCw0YLRjCDQt9Cw0L/QuNGB0Ywg0LTQtdC/0L7QvdC40YDQvtCy0LDQvdC40Y9cIjtcbiAgICAgIHRocm93IG5ldyBFcnJvcih0eXBlb2YgbXNnID09PSBcInN0cmluZ1wiID8gbXNnIDogXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7Qt9C00LDRgtGMINC30LDQv9C40YHRjCDQtNC10L/QvtC90LjRgNC+0LLQsNC90LjRj1wiKTtcbiAgICB9XG5cbiAgICBsZXQgcmVzdWx0OiB7XG4gICAgICBjZXJ0aWZpY2F0ZVVybD86IHN0cmluZztcbiAgICAgIGJsb2NrY2hhaW5UeElkPzogc3RyaW5nO1xuICAgICAgZXh0ZXJuYWxEZXBvc2l0SWQ/OiBzdHJpbmc7XG4gICAgICBleHRlcm5hbENlcnRpZmljYXRlVXJsPzogc3RyaW5nO1xuICAgIH0gPSB7fTtcblxuICAgIHRyeSB7XG4gICAgICBzd2l0Y2ggKG1ldGhvZCkge1xuICAgICAgICBjYXNlIFwiaW50ZXJuYWxcIjpcbiAgICAgICAgICAvLyDQktC90YPRgtGA0LXQvdC90LjQuSDRgNC10LXRgdGC0YAgLSDQv9GA0L7RgdGC0L4g0YHQvtGF0YDQsNC90Y/QtdC8INGF0LXRiNC4XG4gICAgICAgICAgcmVzdWx0LmNlcnRpZmljYXRlVXJsID0gYXdhaXQgZ2VuZXJhdGVQZGZDZXJ0aWZpY2F0ZShcbiAgICAgICAgICAgIHN1cGFiYXNlLCB0cmFjaywgZmlsZUhhc2gsIGRlcG9zaXRJZCwgZWZmZWN0aXZlQXV0aG9yRGF0YVxuICAgICAgICAgICk7XG4gICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgY2FzZSBcInBkZlwiOlxuICAgICAgICAgIC8vINCT0LXQvdC10YDQsNGG0LjRjyBQREYg0YHQtdGA0YLQuNGE0LjQutCw0YLQsFxuICAgICAgICAgIHJlc3VsdC5jZXJ0aWZpY2F0ZVVybCA9IGF3YWl0IGdlbmVyYXRlUGRmQ2VydGlmaWNhdGUoXG4gICAgICAgICAgICBzdXBhYmFzZSwgdHJhY2ssIGZpbGVIYXNoLCBkZXBvc2l0SWQsIGVmZmVjdGl2ZUF1dGhvckRhdGFcbiAgICAgICAgICApO1xuICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgXCJibG9ja2NoYWluXCI6XG4gICAgICAgICAgLy8gT3BlblRpbWVzdGFtcHNcbiAgICAgICAgICByZXN1bHQuYmxvY2tjaGFpblR4SWQgPSBhd2FpdCBzdWJtaXRUb09wZW5UaW1lc3RhbXBzKGZpbGVIYXNoKTtcbiAgICAgICAgICByZXN1bHQuY2VydGlmaWNhdGVVcmwgPSBhd2FpdCBnZW5lcmF0ZVBkZkNlcnRpZmljYXRlKFxuICAgICAgICAgICAgc3VwYWJhc2UsIHRyYWNrLCBmaWxlSGFzaCwgZGVwb3NpdElkLCBlZmZlY3RpdmVBdXRob3JEYXRhXG4gICAgICAgICAgKTtcbiAgICAgICAgICBicmVhaztcblxuICAgICAgICBjYXNlIFwibnJpc1wiOlxuICAgICAgICAgIGNvbnN0IG5yaXNSZXN1bHQgPSBhd2FpdCBzdWJtaXRUb05yaXMoXG4gICAgICAgICAgICB0cmFjayxcbiAgICAgICAgICAgIGZpbGVIYXNoLFxuICAgICAgICAgICAgc2V0dGluZ3NNYXAuZ2V0KFwibnJpc19hcGlfa2V5XCIpIHx8IFwiXCIsXG4gICAgICAgICAgICBzZXR0aW5nc01hcC5nZXQoXCJucmlzX2FwaV91cmxcIikgfHwgXCJodHRwczovL2FwaS5ucmlzLnJ1L3YxXCJcbiAgICAgICAgICApO1xuICAgICAgICAgIHJlc3VsdC5leHRlcm5hbERlcG9zaXRJZCA9IG5yaXNSZXN1bHQuZGVwb3NpdElkO1xuICAgICAgICAgIHJlc3VsdC5leHRlcm5hbENlcnRpZmljYXRlVXJsID0gbnJpc1Jlc3VsdC5jZXJ0aWZpY2F0ZVVybDtcbiAgICAgICAgICBicmVhaztcblxuICAgICAgICBjYXNlIFwiaXJtYVwiOlxuICAgICAgICAgIGNvbnN0IGlybWFSZXN1bHQgPSBhd2FpdCBzdWJtaXRUb0lybWEoXG4gICAgICAgICAgICB0cmFjayxcbiAgICAgICAgICAgIGZpbGVIYXNoLFxuICAgICAgICAgICAgc2V0dGluZ3NNYXAuZ2V0KFwiaXJtYV9hcGlfa2V5XCIpIHx8IFwiXCIsXG4gICAgICAgICAgICBzZXR0aW5nc01hcC5nZXQoXCJpcm1hX2FwaV91cmxcIikgfHwgXCJodHRwczovL2FwaS5pcm1hLnJ1L3YxXCJcbiAgICAgICAgICApO1xuICAgICAgICAgIHJlc3VsdC5leHRlcm5hbERlcG9zaXRJZCA9IGlybWFSZXN1bHQuZGVwb3NpdElkO1xuICAgICAgICAgIHJlc3VsdC5leHRlcm5hbENlcnRpZmljYXRlVXJsID0gaXJtYVJlc3VsdC5jZXJ0aWZpY2F0ZVVybDtcbiAgICAgICAgICBicmVhaztcbiAgICAgIH1cblxuICAgICAgLy8g0J7QsdC90L7QstC70Y/QtdC8INGB0YLQsNGC0YPRgSDQvdCwIGNvbXBsZXRlZCAodXNlclN1cGFiYXNlINC00LvRjyBSTFMpXG4gICAgICBhd2FpdCB1c2VyU3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJ0cmFja19kZXBvc2l0c1wiKVxuICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgY29tcGxldGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgY2VydGlmaWNhdGVfdXJsOiByZXN1bHQuY2VydGlmaWNhdGVVcmwsXG4gICAgICAgICAgYmxvY2tjaGFpbl90eF9pZDogcmVzdWx0LmJsb2NrY2hhaW5UeElkLFxuICAgICAgICAgIGV4dGVybmFsX2RlcG9zaXRfaWQ6IHJlc3VsdC5leHRlcm5hbERlcG9zaXRJZCxcbiAgICAgICAgICBleHRlcm5hbF9jZXJ0aWZpY2F0ZV91cmw6IHJlc3VsdC5leHRlcm5hbENlcnRpZmljYXRlVXJsLFxuICAgICAgICB9KVxuICAgICAgICAuZXEoXCJpZFwiLCBkZXBvc2l0SWQpO1xuXG4gICAgICAvLyDQodC+0LfQtNCw0ZHQvCDRg9Cy0LXQtNC+0LzQu9C10L3QuNC1ICh1c2VyU3VwYWJhc2Ug0LTQu9GPIFJMUylcbiAgICAgIGF3YWl0IHVzZXJTdXBhYmFzZS5mcm9tKFwibm90aWZpY2F0aW9uc1wiKS5pbnNlcnQoe1xuICAgICAgICB1c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgICB0eXBlOiBcInN5c3RlbVwiLFxuICAgICAgICB0aXRsZTogXCLQlNC10L/QvtC90LjRgNC+0LLQsNC90LjQtSDQt9Cw0LLQtdGA0YjQtdC90L5cIixcbiAgICAgICAgbWVzc2FnZTogYNCi0YDQtdC6IFwiJHt0cmFjay50aXRsZX1cIiDRg9GB0L/QtdGI0L3QviDQtNC10L/QvtC90LjRgNC+0LLQsNC9YCxcbiAgICAgICAgdGFyZ2V0X3R5cGU6IFwidHJhY2tcIixcbiAgICAgICAgdGFyZ2V0X2lkOiB0cmFja0lkLFxuICAgICAgfSk7XG5cbiAgICAgIGNvbnNvbGUubG9nKGBEZXBvc2l0IGNvbXBsZXRlZDogJHtkZXBvc2l0SWR9YCk7XG5cbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgIGRlcG9zaXRJZCxcbiAgICAgICAgICAuLi5yZXN1bHQsXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcblxuICAgIH0gY2F0Y2ggKHByb2Nlc3NFcnJvcjogdW5rbm93bikge1xuICAgICAgY29uc3QgZXJyb3IgPSBwcm9jZXNzRXJyb3IgYXMgRGVwb3NpdEVycm9yO1xuICAgICAgY29uc29sZS5lcnJvcihcIlByb2Nlc3MgZXJyb3I6XCIsIGVycm9yKTtcbiAgICAgIFxuICAgICAgLy8g0J7QsdC90L7QstC70Y/QtdC8INGB0YLQsNGC0YPRgSDQvdCwIGZhaWxlZCAodXNlclN1cGFiYXNlINC00LvRjyBSTFMpXG4gICAgICBhd2FpdCB1c2VyU3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJ0cmFja19kZXBvc2l0c1wiKVxuICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICBzdGF0dXM6IFwiZmFpbGVkXCIsXG4gICAgICAgICAgZXJyb3JfbWVzc2FnZTogZXJyb3IubWVzc2FnZSB8fCBcIlVua25vd24gZXJyb3JcIixcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgZGVwb3NpdElkKTtcblxuICAgICAgLy8g0JLQvtC30LLRgNCw0YnQsNC10Lwg0YHRgNC10LTRgdGC0LLQsCDQtdGB0LvQuCDQsdGL0LvQuCDRgdC/0LjRgdCw0L3Ri1xuICAgICAgaWYgKHByaWNlID4gMCkge1xuICAgICAgICBjb25zdCB7IGRhdGE6IGN1cnJlbnRQcm9maWxlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAuc2VsZWN0KFwiYmFsYW5jZVwiKVxuICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgICAgICAuc2luZ2xlKCk7XG4gICAgICAgIFxuICAgICAgICBpZiAoY3VycmVudFByb2ZpbGUpIHtcbiAgICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IGN1cnJlbnRQcm9maWxlLmJhbGFuY2UgKyBwcmljZSB9KVxuICAgICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG5cbiAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJEZXBvc2l0IGVycm9yOlwiLCBlcnJvcik7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBQ25GLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQWtCQSx5QkFBeUI7QUFDekIsZUFBZSxhQUFhLElBQVk7RUFDdEMsTUFBTSxVQUFVLElBQUk7RUFDcEIsTUFBTSxhQUFhLFFBQVEsTUFBTSxDQUFDO0VBQ2xDLE1BQU0sYUFBYSxNQUFNLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXO0VBQ3pELE1BQU0sWUFBWSxNQUFNLElBQUksQ0FBQyxJQUFJLFdBQVc7RUFDNUMsT0FBTyxVQUFVLEdBQUcsQ0FBQyxDQUFBLElBQUssRUFBRSxRQUFRLENBQUMsSUFBSSxRQUFRLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUNsRTtBQUVBLHdGQUF3RjtBQUN4RixTQUFTLGdCQUFnQixHQUFXO0VBQ2xDLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CO0VBQ3BELE1BQU0sY0FBYztFQUNwQixJQUFJLFlBQVksSUFBSSxDQUFDLE1BQU07SUFDekIsTUFBTSxPQUFPLElBQUksSUFBSSxLQUFLLFFBQVE7SUFDbEMsT0FBTyxDQUFDLEVBQUUsWUFBWSxFQUFFLEtBQUssQ0FBQztFQUNoQztFQUNBLE9BQU87QUFDVDtBQUVBLDBCQUEwQjtBQUMxQixlQUFlLGFBQWEsUUFBZ0I7RUFDMUMsTUFBTSxjQUFjLGdCQUFnQjtFQUNwQyxJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTTtJQUM3QixNQUFNLFNBQVMsTUFBTSxTQUFTLFdBQVc7SUFDekMsTUFBTSxhQUFhLE1BQU0sT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVc7SUFDekQsTUFBTSxZQUFZLE1BQU0sSUFBSSxDQUFDLElBQUksV0FBVztJQUM1QyxPQUFPLFVBQVUsR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0VBQ2xFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsa0NBQWtDO0lBQ2hELE1BQU0sSUFBSSxNQUFNO0VBQ2xCO0FBQ0Y7QUFFQSxnRUFBZ0U7QUFDaEUsZUFBZSx1QkFBdUIsT0FBZTtFQUNuRCxNQUFNLFlBQVksSUFBSSxXQUNwQixRQUFRLEtBQUssQ0FBQyxTQUFVLEdBQUcsQ0FBQyxDQUFDLElBQU0sU0FBUyxHQUFHO0VBRWpELE1BQU0sWUFBWTtJQUNoQjtJQUNBO0lBQ0E7R0FDRDtFQUNELEtBQUssTUFBTSxZQUFZLFVBQVc7SUFDaEMsSUFBSTtNQUNGLE1BQU0sT0FBTyxNQUFNLE1BQU0sVUFBVTtRQUNqQyxRQUFRO1FBQ1IsU0FBUztVQUNQLGdCQUFnQjtVQUNoQixRQUFRO1FBQ1Y7UUFDQSxNQUFNO01BQ1I7TUFDQSxJQUFJLEtBQUssRUFBRSxFQUFFO1FBQ1gsT0FBTyxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUcsR0FBRyxDQUFDO01BQzVCO0lBQ0YsRUFBRSxPQUFPLEdBQUc7TUFDVixRQUFRLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxTQUFTLFFBQVEsQ0FBQyxFQUFFO0lBQzNDO0VBQ0Y7RUFDQSxPQUFPLENBQUMsWUFBWSxFQUFFLFFBQVEsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDO0FBQ2xEO0FBRUEsdUJBQXVCO0FBQ3ZCLGVBQWUsYUFDYixLQUFVLEVBQ1YsSUFBWSxFQUNaLE1BQWMsRUFDZCxNQUFjO0VBRWQsSUFBSSxDQUFDLFFBQVE7SUFDWCxNQUFNLElBQUksTUFBTTtFQUNsQjtFQUVBLElBQUk7SUFDRixNQUFNLFdBQVcsTUFBTSxNQUFNLENBQUMsRUFBRSxPQUFPLFNBQVMsQ0FBQyxFQUFFO01BQ2pELFFBQVE7TUFDUixTQUFTO1FBQ1AsaUJBQWlCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQztRQUNuQyxnQkFBZ0I7TUFDbEI7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQ25CLE1BQU07UUFDTixPQUFPLE1BQU0sS0FBSztRQUNsQixRQUFRLE1BQU0sY0FBYyxJQUFJLE1BQU0sUUFBUSxFQUFFO1FBQ2hELE1BQU07UUFDTixVQUFVO1VBQ1IsVUFBVSxNQUFNLFFBQVE7VUFDeEIsT0FBTyxNQUFNLEtBQUssRUFBRTtVQUNwQixZQUFZLE1BQU0sVUFBVTtVQUM1QixlQUFlLE1BQU0sYUFBYTtVQUNsQyxjQUFjLE1BQU0sWUFBWTtRQUNsQztNQUNGO0lBQ0Y7SUFFQSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7TUFDaEIsTUFBTSxRQUFRLE1BQU0sU0FBUyxJQUFJO01BQ2pDLE1BQU0sSUFBSSxNQUFNLENBQUMsaUJBQWlCLEVBQUUsTUFBTSxDQUFDO0lBQzdDO0lBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0lBQ2xDLE9BQU87TUFDTCxXQUFXLE9BQU8sVUFBVSxJQUFJLE9BQU8sRUFBRTtNQUN6QyxnQkFBZ0IsT0FBTyxlQUFlO0lBQ3hDO0VBQ0YsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyxnQkFBZ0I7SUFDOUIsTUFBTTtFQUNSO0FBQ0Y7QUFFQSxzQkFBc0I7QUFDdEIsZUFBZSxhQUNiLEtBQVUsRUFDVixJQUFZLEVBQ1osTUFBYyxFQUNkLE1BQWM7RUFFZCxJQUFJLENBQUMsUUFBUTtJQUNYLE1BQU0sSUFBSSxNQUFNO0VBQ2xCO0VBRUEsSUFBSTtJQUNGLE1BQU0sV0FBVyxNQUFNLE1BQU0sQ0FBQyxFQUFFLE9BQU8sU0FBUyxDQUFDLEVBQUU7TUFDakQsUUFBUTtNQUNSLFNBQVM7UUFDUCxhQUFhO1FBQ2IsZ0JBQWdCO01BQ2xCO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztRQUNuQixXQUFXO1FBQ1gsT0FBTyxNQUFNLEtBQUs7UUFDbEIsVUFBVTtVQUNSO1lBQ0UsTUFBTTtZQUNOLE1BQU0sTUFBTSxjQUFjLElBQUksTUFBTSxRQUFRLEVBQUU7VUFDaEQ7YUFDSSxNQUFNLFlBQVksR0FBRztZQUFDO2NBQUUsTUFBTTtjQUFZLE1BQU0sTUFBTSxZQUFZO1lBQUM7V0FBRSxHQUFHLEVBQUU7YUFDMUUsTUFBTSxhQUFhLEdBQUc7WUFBQztjQUFFLE1BQU07Y0FBWSxNQUFNLE1BQU0sYUFBYTtZQUFDO1dBQUUsR0FBRyxFQUFFO1NBQ2pGO1FBQ0QsV0FBVztRQUNYLGlCQUFpQjtVQUNmLGtCQUFrQixNQUFNLFFBQVE7VUFDaEMsT0FBTyxNQUFNLEtBQUssRUFBRTtRQUN0QjtNQUNGO0lBQ0Y7SUFFQSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7TUFDaEIsTUFBTSxRQUFRLE1BQU0sU0FBUyxJQUFJO01BQ2pDLE1BQU0sSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDO0lBQzVDO0lBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0lBQ2xDLE9BQU87TUFDTCxXQUFXLE9BQU8sZUFBZSxJQUFJLE9BQU8sRUFBRTtNQUM5QyxnQkFBZ0IsT0FBTyxlQUFlO0lBQ3hDO0VBQ0YsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyxlQUFlO0lBQzdCLE1BQU07RUFDUjtBQUNGO0FBRUEsNEJBQTRCO0FBQzVCLGVBQWUsdUJBQ2IsUUFBYSxFQUNiLEtBQVUsRUFDVixJQUFZLEVBQ1osU0FBaUIsRUFDakIsVUFBbUY7RUFFbkYsTUFBTSxhQUFhLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxlQUFlO0VBQy9DLE1BQU0sWUFBWSxDQUFDLEVBQUUsV0FBVyxhQUFhLEVBQUUsbUJBQW1CLE1BQU0sQ0FBQztFQUN6RSxNQUFNLFlBQVksQ0FBQyw4REFBOEQsRUFBRSxtQkFBbUIsV0FBVyxDQUFDO0VBRWxILE1BQU0sa0JBQWtCO0lBQ3RCLE9BQU87SUFDUCxZQUFZLE1BQU0sS0FBSyxJQUFJO0lBQzNCLFdBQVcsV0FBVyxjQUFjLElBQUk7SUFDeEMsYUFBYSxXQUFXLFlBQVksSUFBSTtJQUN4QyxjQUFjLFdBQVcsYUFBYSxJQUFJO0lBQzFDLFVBQVU7SUFDVixXQUFXO0lBQ1gsYUFBYSxJQUFJLE9BQU8sV0FBVztJQUNuQyxVQUFVO0lBQ1YsT0FBTztJQUNQLFdBQVc7SUFDWDtJQUNBO0VBQ0Y7RUFFQSxNQUFNLGdCQUFnQixJQUFJLEtBQUssZ0JBQWdCLFdBQVcsRUFBRSxjQUFjLENBQUMsU0FBUztJQUNsRixLQUFLO0lBQ0wsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNO0lBQ04sUUFBUTtJQUNSLFFBQVE7RUFDVjtFQUVBLGtEQUFrRDtFQUNsRCxNQUFNLGNBQWMsQ0FBQzs7Ozs7b0NBS2EsRUFBRSxnQkFBZ0IsVUFBVSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnQ0F3TWpDLEVBQUUsZ0JBQWdCLEtBQUssQ0FBQztrQ0FDdEIsRUFBRSxnQkFBZ0IsUUFBUSxDQUFDOzs7Ozs7Ozs7MkJBU2xDLEVBQUUsZ0JBQWdCLFVBQVUsQ0FBQzs7Ozs7MkJBSzdCLEVBQUUsZ0JBQWdCLFNBQVMsQ0FBQzs7O01BR2pELEVBQUUsZ0JBQWdCLFdBQVcsR0FBRyxDQUFDOzsyQkFFWixFQUFFLGdCQUFnQixXQUFXLENBQUM7WUFDN0MsQ0FBQyxHQUFHLEdBQUc7O01BRWIsRUFBRSxnQkFBZ0IsWUFBWSxHQUFHLENBQUM7OzJCQUViLEVBQUUsZ0JBQWdCLFlBQVksQ0FBQztZQUM5QyxDQUFDLEdBQUcsR0FBRzs7OztnQ0FJYSxFQUFFLGdCQUFnQixRQUFRLENBQUM7Ozs7OzJCQUtoQyxFQUFFLGdCQUFnQixTQUFTLENBQUM7Ozs7OzJCQUs1QixFQUFFLGNBQWM7Ozs7Ozs7Ozs7OztlQVk1QixFQUFFLGdCQUFnQixTQUFTLENBQUM7a0JBQ3pCLEVBQUUsZ0JBQWdCLFNBQVMsQ0FBQzs7Ozs7OzswQkFPcEIsRUFBRSxnQkFBZ0IsU0FBUyxDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsUUFBUSxDQUFDOzs7O09BSWxGLENBQUM7RUFFTixpRUFBaUU7RUFDakUsTUFBTSxXQUFXLENBQUMsWUFBWSxFQUFFLFVBQVUsS0FBSyxDQUFDO0VBQ2hELE1BQU0sWUFBWSxDQUFDLE1BQU0sS0FBSyxJQUFJLGNBQWMsRUFBRSxPQUFPLENBQUMsMkJBQTJCLEtBQUssSUFBSTtFQUM5RixNQUFNLFlBQVksSUFBSSxjQUFjLE1BQU0sQ0FBQztFQUUzQyx5Q0FBeUM7RUFDekMsTUFBTSxPQUFPLElBQUksS0FBSztJQUFDO0dBQVUsRUFBRTtJQUFFLE1BQU07RUFBMEI7RUFFckUsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUFTLE9BQU8sQ0FDbEQsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyxVQUFVLE1BQU07SUFDdEIsYUFBYTtJQUNiLGNBQWM7SUFDZCxRQUFRO0VBQ1Y7RUFFRixJQUFJLGFBQWE7SUFDZixRQUFRLEtBQUssQ0FBQyxnQ0FBZ0M7SUFDOUMsTUFBTSxJQUFJLE1BQU07RUFDbEI7RUFFQSxtRkFBbUY7RUFDbkYsTUFBTSxhQUFhLENBQUMsdUNBQXVDLEVBQUUsU0FBUyxDQUFDO0VBQ3ZFLE1BQU0sZUFBZSxDQUFDLHdCQUF3QixFQUFFLFVBQVUsS0FBSyxDQUFDO0VBQ2hFLE9BQU8sQ0FBQyxFQUFFLFdBQVcsRUFBRSxXQUFXLFVBQVUsRUFBRSxtQkFBbUIsY0FBYyxDQUFDO0FBQ2xGO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDeEMsTUFBTSxXQUFXLGFBQWEsYUFBYTtJQUUzQyx3QkFBd0I7SUFDeEIsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBRXpFLCtFQUErRTtJQUMvRSxNQUFNLGVBQWUsYUFBYSxhQUFhLG9CQUFvQjtNQUNqRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWUsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDO1FBQUM7TUFBRTtJQUMxRDtJQUVBLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsR0FBbUIsTUFBTSxJQUFJLElBQUk7SUFDdEUsUUFBUSxHQUFHLENBQUMsQ0FBQyx1QkFBdUIsRUFBRSxRQUFRLFNBQVMsRUFBRSxPQUFPLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0lBRWxGLDBGQUEwRjtJQUMxRixNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxVQUFVLEVBQUUsR0FBRyxNQUFNLFNBQzlDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxDQUFDOzs7O01BSVQsQ0FBQyxFQUNBLEVBQUUsQ0FBQyxNQUFNLFNBQ1QsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFLEVBQ3JCLE1BQU07SUFFVCw2QkFBNkI7SUFDN0IsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxTQUM3QixJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsWUFDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtJQUVULE1BQU0sV0FBVyxTQUFTLFlBQVk7SUFFdEMsbURBQW1EO0lBQ25ELE1BQU0sc0JBQXNCO01BQzFCLGdCQUFnQixZQUFZLGtCQUFrQixPQUFPLGtCQUFrQjtNQUN2RSxjQUFjLFlBQVksZ0JBQWdCLE9BQU8sZ0JBQWdCO01BQ2pFLGVBQWUsWUFBWSxpQkFBaUIsT0FBTyxpQkFBaUI7SUFDdEU7SUFFQSxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsb0ZBQW9GO0lBQ3BGLE1BQU0sVUFBVSxlQUFlO0lBQy9CLE1BQU0sV0FBVyxNQUFNLFNBQVMsSUFBSSxNQUFNLGdCQUFnQixJQUFJLE1BQU0sb0JBQW9CLElBQ25GLENBQUMsRUFBRSxRQUFRLHVDQUF1QyxFQUFFLFFBQVEsSUFBSSxDQUFDO0lBRXRFLHVDQUF1QztJQUN2QyxNQUFNLEVBQUUsTUFBTSxlQUFlLEVBQUUsR0FBRyxNQUFNLFNBQ3JDLElBQUksQ0FBQyxrQkFDTCxNQUFNLENBQUMsY0FDUCxFQUFFLENBQUMsWUFBWSxTQUNmLEVBQUUsQ0FBQyxVQUFVLFFBQ2IsTUFBTTtJQUVULElBQUksaUJBQWlCO01BQ25CLElBQUksZ0JBQWdCLE1BQU0sS0FBSyxhQUFhO1FBQzFDLE1BQU0sSUFBSSxNQUFNO01BQ2xCO01BQ0EsOERBQThEO01BQzlELE1BQU0sYUFDSCxJQUFJLENBQUMsa0JBQ0wsTUFBTSxHQUNOLEVBQUUsQ0FBQyxNQUFNLGdCQUFnQixFQUFFO0lBQ2hDO0lBRUEscUJBQXFCO0lBQ3JCLE1BQU0sRUFBRSxNQUFNLFFBQVEsRUFBRSxHQUFHLE1BQU0sU0FDOUIsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLGNBQ1AsRUFBRSxDQUFDLE9BQU87TUFDVCxDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUM7TUFDekI7TUFDQTtNQUNBO01BQ0E7S0FDRDtJQUVILE1BQU0sY0FBYyxJQUFJLElBQUksVUFBVSxJQUFJLENBQUEsSUFBSztRQUFDLEVBQUUsR0FBRztRQUFFLEVBQUUsS0FBSztPQUFDLEtBQUssRUFBRTtJQUN0RSxNQUFNLFdBQVcsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDO0lBQzFDLE1BQU0sYUFBYSxZQUFZLEdBQUcsQ0FBQztJQUNuQyxNQUFNLFFBQVEsU0FBUyxjQUFjLEtBQUs7SUFFMUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxTQUFTLFdBQVcsRUFBRSxXQUFXLGNBQWMsRUFBRSxNQUFNLENBQUM7SUFFNUYsK0JBQStCO0lBQy9CLElBQUksUUFBUSxHQUFHO01BQ2IsTUFBTSxFQUFFLE1BQU0sV0FBVyxFQUFFLE9BQU8sWUFBWSxFQUFFLEdBQUcsTUFBTSxTQUN0RCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtNQUVULFFBQVEsR0FBRyxDQUFDLENBQUMsNEJBQTRCLEVBQUUsYUFBYSxRQUFRLFFBQVEsRUFBRSxNQUFNLFFBQVEsRUFBRSxjQUFjLFFBQVEsQ0FBQztNQUVqSCxJQUFJLENBQUMsZUFBZSxZQUFZLE9BQU8sR0FBRyxPQUFPO1FBQy9DLE1BQU0sSUFBSSxNQUFNLENBQUMsaUNBQWlDLEVBQUUsTUFBTSxZQUFZLEVBQUUsYUFBYSxXQUFXLEVBQUUsRUFBRSxDQUFDO01BQ3ZHO01BRUEscUJBQXFCO01BQ3JCLE1BQU0sYUFBYSxZQUFZLE9BQU8sR0FBRztNQUN6QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLG1CQUFtQixFQUFFLFlBQVksT0FBTyxDQUFDLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxXQUFXLENBQUM7TUFFbEYsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUNsQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7UUFBRSxTQUFTO01BQVcsR0FDN0IsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFO01BRXhCLElBQUksYUFBYTtRQUNmLFFBQVEsS0FBSyxDQUFDLHlCQUF5QjtRQUN2QyxNQUFNLElBQUksTUFBTTtNQUNsQjtNQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsc0NBQXNDLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUNoRSxPQUFPO01BQ0wsUUFBUSxHQUFHLENBQUMsQ0FBQywyQkFBMkIsRUFBRSxPQUFPLENBQUM7SUFDcEQ7SUFFQSx1QkFBdUI7SUFDdkIsUUFBUSxHQUFHLENBQUMsNEJBQTRCO01BQUUsUUFBUSxTQUFTLE1BQU07SUFBQztJQUNsRSxNQUFNLFdBQVcsTUFBTSxhQUFhO0lBRXBDLDRCQUE0QjtJQUM1QixNQUFNLGVBQWUsTUFBTSxhQUFhLEtBQUssU0FBUyxDQUFDO01BQ3JELE9BQU8sTUFBTSxLQUFLO01BQ2xCLFdBQVcsb0JBQW9CLGNBQWM7TUFDN0MsYUFBYSxvQkFBb0IsWUFBWTtNQUM3QyxjQUFjLG9CQUFvQixhQUFhO01BQy9DLFVBQVUsTUFBTSxRQUFRO01BQ3hCO01BQ0EsV0FBVyxJQUFJLE9BQU8sV0FBVztJQUNuQztJQUVBLDRFQUE0RTtJQUM1RSxNQUFNLFlBQVksT0FBTyxVQUFVO0lBQ25DLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sYUFDbEMsSUFBSSxDQUFDLGtCQUNMLE1BQU0sQ0FBQztNQUNOLElBQUk7TUFDSixVQUFVO01BQ1YsU0FBUyxLQUFLLEVBQUU7TUFDaEI7TUFDQSxRQUFRO01BQ1IsV0FBVztNQUNYLGVBQWU7TUFDZixnQkFBZ0Isb0JBQW9CLGNBQWM7TUFDbEQsZUFBZSxvQkFBb0IsYUFBYTtJQUNsRDtJQUVGLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLGlCQUFpQjtNQUMvQixNQUFNLE1BQU0sYUFBYSxXQUFXLGFBQWEsV0FBVztNQUM1RCxNQUFNLElBQUksTUFBTSxPQUFPLFFBQVEsV0FBVyxNQUFNO0lBQ2xEO0lBRUEsSUFBSSxTQUtBLENBQUM7SUFFTCxJQUFJO01BQ0YsT0FBUTtRQUNOLEtBQUs7VUFDSCw0Q0FBNEM7VUFDNUMsT0FBTyxjQUFjLEdBQUcsTUFBTSx1QkFDNUIsVUFBVSxPQUFPLFVBQVUsV0FBVztVQUV4QztRQUVGLEtBQUs7VUFDSCw0QkFBNEI7VUFDNUIsT0FBTyxjQUFjLEdBQUcsTUFBTSx1QkFDNUIsVUFBVSxPQUFPLFVBQVUsV0FBVztVQUV4QztRQUVGLEtBQUs7VUFDSCxpQkFBaUI7VUFDakIsT0FBTyxjQUFjLEdBQUcsTUFBTSx1QkFBdUI7VUFDckQsT0FBTyxjQUFjLEdBQUcsTUFBTSx1QkFDNUIsVUFBVSxPQUFPLFVBQVUsV0FBVztVQUV4QztRQUVGLEtBQUs7VUFDSCxNQUFNLGFBQWEsTUFBTSxhQUN2QixPQUNBLFVBQ0EsWUFBWSxHQUFHLENBQUMsbUJBQW1CLElBQ25DLFlBQVksR0FBRyxDQUFDLG1CQUFtQjtVQUVyQyxPQUFPLGlCQUFpQixHQUFHLFdBQVcsU0FBUztVQUMvQyxPQUFPLHNCQUFzQixHQUFHLFdBQVcsY0FBYztVQUN6RDtRQUVGLEtBQUs7VUFDSCxNQUFNLGFBQWEsTUFBTSxhQUN2QixPQUNBLFVBQ0EsWUFBWSxHQUFHLENBQUMsbUJBQW1CLElBQ25DLFlBQVksR0FBRyxDQUFDLG1CQUFtQjtVQUVyQyxPQUFPLGlCQUFpQixHQUFHLFdBQVcsU0FBUztVQUMvQyxPQUFPLHNCQUFzQixHQUFHLFdBQVcsY0FBYztVQUN6RDtNQUNKO01BRUEsdURBQXVEO01BQ3ZELE1BQU0sYUFDSCxJQUFJLENBQUMsa0JBQ0wsTUFBTSxDQUFDO1FBQ04sUUFBUTtRQUNSLGNBQWMsSUFBSSxPQUFPLFdBQVc7UUFDcEMsaUJBQWlCLE9BQU8sY0FBYztRQUN0QyxrQkFBa0IsT0FBTyxjQUFjO1FBQ3ZDLHFCQUFxQixPQUFPLGlCQUFpQjtRQUM3QywwQkFBMEIsT0FBTyxzQkFBc0I7TUFDekQsR0FDQyxFQUFFLENBQUMsTUFBTTtNQUVaLDZDQUE2QztNQUM3QyxNQUFNLGFBQWEsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7UUFDOUMsU0FBUyxLQUFLLEVBQUU7UUFDaEIsTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTLENBQUMsTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDLHFCQUFxQixDQUFDO1FBQ3BELGFBQWE7UUFDYixXQUFXO01BQ2I7TUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLG1CQUFtQixFQUFFLFVBQVUsQ0FBQztNQUU3QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVDtRQUNBLEdBQUcsTUFBTTtNQUNYLElBQ0E7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFHdEUsRUFBRSxPQUFPLGNBQXVCO01BQzlCLE1BQU0sUUFBUTtNQUNkLFFBQVEsS0FBSyxDQUFDLGtCQUFrQjtNQUVoQyxvREFBb0Q7TUFDcEQsTUFBTSxhQUNILElBQUksQ0FBQyxrQkFDTCxNQUFNLENBQUM7UUFDTixRQUFRO1FBQ1IsZUFBZSxNQUFNLE9BQU8sSUFBSTtNQUNsQyxHQUNDLEVBQUUsQ0FBQyxNQUFNO01BRVosd0NBQXdDO01BQ3hDLElBQUksUUFBUSxHQUFHO1FBQ2IsTUFBTSxFQUFFLE1BQU0sY0FBYyxFQUFFLEdBQUcsTUFBTSxTQUNwQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtRQUVULElBQUksZ0JBQWdCO1VBQ2xCLE1BQU0sU0FDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7WUFBRSxTQUFTLGVBQWUsT0FBTyxHQUFHO1VBQU0sR0FDakQsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFO1FBQzFCO01BQ0Y7TUFFQSxNQUFNO0lBQ1I7RUFFRixFQUFFLE9BQU8sT0FBWTtJQUNuQixRQUFRLEtBQUssQ0FBQyxrQkFBa0I7SUFDaEMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPLE1BQU0sT0FBTztJQUFDLElBQ3RDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
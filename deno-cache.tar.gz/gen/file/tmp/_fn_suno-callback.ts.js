const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
// Background task helper — fire-and-forget pattern
// (EdgeRuntime.waitUntil is NOT available in this Deno server)
function runInBackground(taskName, promise) {
  promise.catch((err)=>console.error(`[Background: ${taskName}] Error:`, err));
}
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Helper function to download file and upload to Supabase Storage
async function copyFileToStorage(supabaseAdmin, externalUrl, bucket, filePath) {
  try {
    console.log(`Downloading file from: ${externalUrl}`);
    const response = await fetch(externalUrl);
    if (!response.ok) {
      console.error(`Failed to download: ${response.status} ${response.statusText}`);
      return null;
    }
    const blob = await response.blob();
    const arrayBuffer = await blob.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);
    console.log(`Downloaded ${uint8Array.length} bytes, uploading to ${bucket}/${filePath}`);
    const { error: uploadError } = await supabaseAdmin.storage.from(bucket).upload(filePath, uint8Array, {
      contentType: blob.type || "application/octet-stream",
      upsert: true
    });
    if (uploadError) {
      console.error(`Upload error:`, uploadError);
      return null;
    }
    // Build public URL using BASE_URL (not internal SUPABASE_URL which is http://api:3000)
    const baseUrl = Deno.env.get("BASE_URL") || "https://aimuza.ru";
    const publicUrl = `${baseUrl}/storage/v1/object/public/${bucket}/${filePath}`;
    console.log(`File uploaded successfully: ${publicUrl}`);
    return publicUrl;
  } catch (err) {
    console.error(`Error copying file to storage:`, err);
    return null;
  }
}
// Timeweb Agent API configuration for AI classification
const TIMEWEB_AGENT_ACCESS_ID = '0846d064-4950-4d79-a54c-62ba315cdb34';
// AI Classification function - determines genre, vocal type, template, artist style
// Uses Timeweb Agent API (GPT-4)
async function classifyTrackWithAI(supabaseAdmin, trackId, style, lyrics) {
  try {
    console.log(`Starting AI classification for track ${trackId}`);
    const TIMEWEB_TOKEN = Deno.env.get("TIMEWEB_AGENT_TOKEN");
    if (!TIMEWEB_TOKEN) {
      console.error("TIMEWEB_AGENT_TOKEN not configured, skipping classification");
      return;
    }
    // Fetch all available options from database
    const [genresRes, vocalTypesRes, templatesRes, artistStylesRes] = await Promise.all([
      supabaseAdmin.from("genres").select("id, name, name_ru").order("sort_order"),
      supabaseAdmin.from("vocal_types").select("id, name, name_ru, description").eq("is_active", true).order("sort_order"),
      supabaseAdmin.from("templates").select("id, name, description").eq("is_active", true).order("sort_order"),
      supabaseAdmin.from("artist_styles").select("id, name, description").eq("is_active", true).order("sort_order")
    ]);
    const genres = genresRes.data || [];
    const vocalTypes = vocalTypesRes.data || [];
    const templates = templatesRes.data || [];
    const artistStyles = artistStylesRes.data || [];
    if (genres.length === 0) {
      console.log("No genres in database, skipping classification");
      return;
    }
    // Build the classification prompt
    const genresList = genres.map((g)=>`- id: "${g.id}", name: "${g.name}" (${g.name_ru})`).join("\n");
    const vocalTypesList = vocalTypes.map((v)=>`- id: "${v.id}", name: "${v.name}" (${v.name_ru})${v.description ? ` - ${v.description}` : ""}`).join("\n");
    const templatesList = templates.length > 0 ? templates.map((t)=>`- id: "${t.id}", name: "${t.name}"${t.description ? ` - ${t.description}` : ""}`).join("\n") : "Нет доступных шаблонов";
    const artistStylesList = artistStyles.length > 0 ? artistStyles.map((a)=>`- id: "${a.id}", name: "${a.name}"${a.description ? ` - ${a.description}` : ""}`).join("\n") : "Нет доступных стилей артистов";
    const prompt = `Ты — музыкальный классификатор. Проанализируй стиль и лирику трека.
Выбери ОДИН наиболее подходящий вариант из каждой категории.

ЖАНРЫ (обязательно выбери один):
${genresList}

ТИПЫ ВОКАЛА (обязательно выбери один):
${vocalTypesList}

ШАБЛОНЫ (опционально, выбери если подходит):
${templatesList}

СТИЛИ АРТИСТОВ (опционально, выбери если есть явное сходство):
${artistStylesList}

---
СТИЛЬ ТРЕКА: ${style || "Не указан"}
ЛИРИКА: ${lyrics ? lyrics.substring(0, 1000) : "Инструментал (без текста)"}
---

Правила:
1. genre_id - ОБЯЗАТЕЛЕН, выбери наиболее близкий жанр
2. vocal_type_id - ОБЯЗАТЕЛЕН. Если нет лирики, выбери "instrumental"
3. template_id - только если трек явно соответствует шаблону, иначе null
4. artist_style_id - только если стиль явно похож на конкретного артиста, иначе null

Верни ТОЛЬКО JSON без markdown:
{"genre_id": "...", "vocal_type_id": "...", "template_id": "..." или null, "artist_style_id": "..." или null}`;
    const apiUrl = `https://agent.timeweb.cloud/api/v1/cloud-ai/agents/${TIMEWEB_AGENT_ACCESS_ID}/v1/chat/completions`;
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${TIMEWEB_TOKEN}`,
        "Content-Type": "application/json",
        "x-proxy-source": "lovable-app"
      },
      body: JSON.stringify({
        model: "deepseek-v3",
        messages: [
          {
            role: "system",
            content: "Ты музыкальный классификатор. Отвечай только JSON."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.3
      })
    });
    if (!response.ok) {
      console.error(`AI classification failed: ${response.status}`);
      return;
    }
    const result = await response.json();
    const content = result.choices?.[0]?.message?.content;
    if (!content) {
      console.error("No content in AI response");
      return;
    }
    console.log(`AI classification response: ${content}`);
    // Parse JSON response (handle potential markdown wrapper)
    let classification;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        classification = JSON.parse(jsonMatch[0]);
      } else {
        classification = JSON.parse(content);
      }
    } catch (parseErr) {
      console.error("Failed to parse AI classification:", parseErr);
      return;
    }
    // Validate IDs exist in our data
    const validGenreId = genres.find((g)=>g.id === classification.genre_id)?.id || null;
    const validVocalTypeId = vocalTypes.find((v)=>v.id === classification.vocal_type_id)?.id || null;
    const validTemplateId = classification.template_id ? templates.find((t)=>t.id === classification.template_id)?.id || null : null;
    const validArtistStyleId = classification.artist_style_id ? artistStyles.find((a)=>a.id === classification.artist_style_id)?.id || null : null;
    // Update track with classification
    const updateData = {};
    if (validGenreId) updateData.genre_id = validGenreId;
    if (validVocalTypeId) updateData.vocal_type_id = validVocalTypeId;
    if (validTemplateId) updateData.template_id = validTemplateId;
    if (validArtistStyleId) updateData.artist_style_id = validArtistStyleId;
    if (Object.keys(updateData).length > 0) {
      const { error: updateErr } = await supabaseAdmin.from("tracks").update(updateData).eq("id", trackId);
      if (updateErr) {
        console.error("Failed to update track classification:", updateErr);
      } else {
        console.log(`Track ${trackId} classified: genre=${validGenreId}, vocal=${validVocalTypeId}, template=${validTemplateId}, artist=${validArtistStyleId}`);
      }
    }
  } catch (err) {
    console.error("Error in AI classification:", err);
  }
}
// Function to process addon services after track is completed
async function processTrackAddons(supabaseAdmin, trackId, trackTitle, coverUrl, audioUrl, sunoTaskId, sunoAudioId) {
  try {
    // Get pending addons for this track
    const { data: trackAddons, error: addonsError } = await supabaseAdmin.from("track_addons").select(`
        id,
        addon_service_id,
        status,
        addon_service:addon_services(name, name_ru)
      `).eq("track_id", trackId).eq("status", "pending");
    if (addonsError) {
      console.error("Error fetching track addons:", addonsError);
      return;
    }
    if (!trackAddons || trackAddons.length === 0) {
      console.log(`No pending addons for track ${trackId}`);
      return;
    }
    console.log(`Processing ${trackAddons.length} addons for track ${trackId}`);
    // Get track genre for better AI generation
    const { data: track } = await supabaseAdmin.from("tracks").select("genre_id, genres(name)").eq("id", trackId).single();
    const genreData = track?.genres;
    const genreName = genreData?.name || "electronic";
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    for (const addon of trackAddons){
      const addonServiceData = addon.addon_service;
      const addonName = addonServiceData?.name;
      console.log(`Processing addon: ${addonName} for track ${trackId}`);
      // Update status to processing
      await supabaseAdmin.from("track_addons").update({
        status: "processing",
        updated_at: new Date().toISOString()
      }).eq("id", addon.id);
      let functionName = null;
      let requestBody = {
        track_id: trackId,
        track_title: trackTitle,
        genre: genreName
      };
      if (addonName === "large_cover") {
        functionName = "generate-hd-cover";
        requestBody.original_cover_url = coverUrl;
      } else if (addonName === "short_video") {
        functionName = "generate-short-video";
        requestBody.cover_url = coverUrl;
        // For Suno music video generation, we need the task_id and audio_id
        if (sunoTaskId) {
          requestBody.suno_task_id = sunoTaskId;
        }
        if (sunoAudioId) {
          requestBody.suno_audio_id = sunoAudioId;
        }
      } else if (addonName === "ringtone") {
        functionName = "generate-ringtone";
        requestBody.audio_url = audioUrl;
      }
      if (functionName) {
        try {
          // Call the edge function directly using fetch
          const response = await fetch(`${SUPABASE_URL}/functions/v1/${functionName}`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${SUPABASE_SERVICE_KEY}`
            },
            body: JSON.stringify(requestBody)
          });
          const result = await response.json();
          console.log(`${functionName} result for track ${trackId}:`, result);
          if (!result.success) {
            // Mark as failed
            await supabaseAdmin.from("track_addons").update({
              status: "failed",
              updated_at: new Date().toISOString()
            }).eq("id", addon.id);
          }
        // Note: successful result_url update is handled by the edge function itself
        } catch (fnError) {
          console.error(`Error calling ${functionName}:`, fnError);
          await supabaseAdmin.from("track_addons").update({
            status: "failed",
            updated_at: new Date().toISOString()
          }).eq("id", addon.id);
        }
      } else {
        console.log(`Unknown addon type: ${addonName}, marking as failed`);
        await supabaseAdmin.from("track_addons").update({
          status: "failed",
          updated_at: new Date().toISOString()
        }).eq("id", addon.id);
      }
    }
  } catch (error) {
    console.error("Error processing track addons:", error);
  }
}
// ─── Trigger Suno Cover Generation ──────────────────────────────────
// After music is generated, request personalized cover art via Suno Cover API
// Docs: https://docs.sunoapi.org/suno-api/cover-suno
async function triggerCoverGeneration(supabaseAdmin, musicTaskId, matchedTrackIds) {
  try {
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    const SUNO_API_BASE = "https://apibox.erweima.ai";
    const callbackSecret = Deno.env.get("SUNO_CALLBACK_SECRET");
    const baseUrl = Deno.env.get("BASE_URL") || "https://aimuza.ru";
    if (!SUNO_API_KEY) {
      console.error("SUNO_API_KEY not set, skipping cover generation");
      return;
    }
    // Build cover callback URL
    const coverCallbackUrl = callbackSecret ? `${baseUrl}/functions/v1/suno-cover-callback?secret=${encodeURIComponent(callbackSecret)}` : `${baseUrl}/functions/v1/suno-cover-callback`;
    console.log(`Triggering Suno cover generation for music task ${musicTaskId}`);
    console.log(`Cover callback URL: ${coverCallbackUrl}`);
    // Call Suno Cover API
    // Try primary path first, then fallback
    const paths = [
      "/api/v1/suno/cover/generate",
      "/api/v1/cover/generate"
    ];
    let coverResponse = null;
    let coverData = null;
    for (const path of paths){
      try {
        const url = `${SUNO_API_BASE}${path}`;
        console.log(`Trying cover API: ${url}`);
        coverResponse = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${SUNO_API_KEY}`
          },
          body: JSON.stringify({
            taskId: musicTaskId,
            callBackUrl: coverCallbackUrl
          })
        });
        coverData = await coverResponse.json();
        console.log(`Cover API response (${path}):`, JSON.stringify(coverData));
        // If not a 404 (wrong path), we found the right endpoint
        if (coverResponse.status !== 404) break;
      } catch (fetchErr) {
        console.error(`Cover API fetch error (${path}):`, fetchErr);
      }
    }
    if (!coverData || coverData.code !== 200 && coverData.code !== 400) {
      console.error(`Cover API failed: ${JSON.stringify(coverData)}`);
      return;
    }
    // code 400 = cover already generated for this task (returns existing taskId)
    const coverTaskId = coverData.data?.taskId;
    if (!coverTaskId) {
      console.error("No coverTaskId in response");
      return;
    }
    console.log(`Cover generation started, cover_task_id: ${coverTaskId}`);
    // Store cover_task_id in matched tracks for callback matching
    for (const trackId of matchedTrackIds){
      const { data: track } = await supabaseAdmin.from("tracks").select("description").eq("id", trackId).single();
      if (track) {
        // Only add if not already present
        if (!track.description?.includes(`[cover_task_id: ${coverTaskId}]`)) {
          const newDesc = track.description ? `${track.description}\n\n[cover_task_id: ${coverTaskId}]` : `[cover_task_id: ${coverTaskId}]`;
          await supabaseAdmin.from("tracks").update({
            description: newDesc
          }).eq("id", trackId);
          console.log(`Stored cover_task_id ${coverTaskId} in track ${trackId}`);
        }
      }
    }
  } catch (err) {
    console.error("Error triggering cover generation:", err);
  }
}
// Human-readable error messages for Suno error codes
// Official Suno API error codes reference:
// 400 - Invalid Parameters
// 401 - Unauthorized
// 403 - Forbidden (moderation/copyright)
// 404 - Not Found
// 405 - Rate Limited (API frequency)
// 413 - Content Too Large (prompt/lyrics too long)
// 429 - Insufficient Credits
// 455 - Maintenance
// 500/503 - Server errors
function getSunoErrorMessage(code, originalMessage) {
  // First, check for specific error message patterns (more accurate than just code)
  if (originalMessage) {
    const lowerMsg = originalMessage.toLowerCase();
    // Copyright/content matching detection
    if (lowerMsg.includes("matches existing work") || lowerMsg.includes("existing work of art") || lowerMsg.includes("copyright") || lowerMsg.includes("protected content")) {
      return {
        short: "Контент защищён авторским правом",
        full: "Загруженный аудиофайл или текст распознан как существующее произведение. Система защиты авторских прав Suno заблокировала генерацию. Попробуйте использовать оригинальный контент."
      };
    }
    // Moderation/sensitive content
    if (lowerMsg.includes("moderation") || lowerMsg.includes("sensitive") || lowerMsg.includes("inappropriate") || lowerMsg.includes("prohibited")) {
      return {
        short: "Контент не прошёл модерацию",
        full: "Текст или описание содержит запрещённые слова или фразы. Измените содержимое и попробуйте снова."
      };
    }
    // Audio fetch issues
    if (lowerMsg.includes("fetch") && lowerMsg.includes("audio")) {
      return {
        short: "Не удалось получить аудиофайл",
        full: "Сервер не смог загрузить ваш аудиофайл. Проверьте, что файл доступен и попробуйте снова."
      };
    }
    // Content too long (can come in message too)
    if (lowerMsg.includes("too long") || lowerMsg.includes("too large") || lowerMsg.includes("exceeds")) {
      return {
        short: "Превышен лимит символов",
        full: "Описание, стиль или текст песни слишком длинные. Сократите текст и попробуйте снова."
      };
    }
    // Credits issues
    if (lowerMsg.includes("credit") || lowerMsg.includes("balance") || lowerMsg.includes("insufficient")) {
      return {
        short: "Недостаточно кредитов Suno",
        full: "На аккаунте Suno недостаточно кредитов для генерации. Обратитесь в поддержку."
      };
    }
  }
  // Fallback to code-based messages
  const errorMessages = {
    400: {
      short: "Неверные параметры запроса",
      full: "Параметры генерации некорректны. Проверьте введённые данные и попробуйте снова."
    },
    401: {
      short: "Ошибка авторизации",
      full: "Проблема с авторизацией в сервисе Suno. Обратитесь в поддержку."
    },
    403: {
      short: "Контент заблокирован модерацией",
      full: "Ваш запрос содержит запрещённый контент или нарушает правила использования Suno. Измените текст или описание."
    },
    404: {
      short: "Ресурс не найден",
      full: "Запрашиваемый ресурс не найден. Попробуйте ещё раз."
    },
    405: {
      short: "Превышена частота запросов",
      full: "Слишком много запросов к API. Подождите несколько минут и попробуйте снова."
    },
    413: {
      short: "Превышен лимит символов",
      full: "Описание, стиль или текст песни слишком длинные для обработки. Сократите текст (макс. ~3000 символов для lyrics, ~200 для style) и попробуйте снова."
    },
    429: {
      short: "Недостаточно кредитов",
      full: "На аккаунте Suno недостаточно кредитов для генерации. Обратитесь в поддержку."
    },
    455: {
      short: "Сервис на обслуживании",
      full: "Сервис Suno проходит техническое обслуживание. Попробуйте позже."
    },
    500: {
      short: "Внутренняя ошибка сервера",
      full: "Произошла внутренняя ошибка на сервере Suno. Попробуйте позже."
    },
    503: {
      short: "Сервис временно недоступен",
      full: "Сервис Suno временно перегружен или на обслуживании. Попробуйте позже."
    }
  };
  if (errorMessages[code]) {
    return errorMessages[code];
  }
  return {
    short: `Ошибка генерации (код ${code})`,
    full: originalMessage || `Произошла ошибка при генерации. Код ошибки: ${code}. Попробуйте позже или обратитесь в поддержку.`
  };
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // Verify callback authenticity using secret token
    const callbackSecret = Deno.env.get("SUNO_CALLBACK_SECRET");
    if (callbackSecret) {
      // Check for secret in header or query parameter
      const url = new URL(req.url);
      const headerToken = req.headers.get("x-callback-secret") || req.headers.get("authorization")?.replace("Bearer ", "");
      const queryToken = url.searchParams.get("secret");
      if (headerToken !== callbackSecret && queryToken !== callbackSecret) {
        console.error("Invalid callback secret provided");
        return new Response(JSON.stringify({
          error: "Unauthorized"
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      console.log("Callback secret verified successfully");
    } else {
      console.warn("SUNO_CALLBACK_SECRET not configured - callback verification skipped");
    }
    const supabaseAdmin = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
    const callbackData = await req.json();
    console.log("Received Suno callback:", JSON.stringify(callbackData));
    // Handle the nested data structure from Suno API
    // The structure is: { code: 200, data: { callbackType: "complete", data: [...tracks], task_id: "..." }, msg: "..." }
    const tracks = callbackData?.data?.data || callbackData?.data || [];
    const taskId = callbackData?.data?.task_id;
    const callbackType = callbackData?.data?.callbackType;
    const responseCode = callbackData?.code;
    const errorMessage = callbackData?.msg;
    console.log(`Callback type: ${callbackType}, Task ID: ${taskId}, Code: ${responseCode}, Tracks count: ${tracks.length}`);
    // Handle failed callbacks - check for error codes OR explicit failure types
    // Suno may return code 413 with callbackType "complete" when audio can't be fetched
    const isError = responseCode !== 200 || callbackType === "fail" || callbackType === "error" || callbackType === "failed";
    if (isError) {
      console.log(`Received error callback for task ${taskId} - code: ${responseCode}, type: ${callbackType}`);
      // Get human-readable error message
      const errorInfo = getSunoErrorMessage(responseCode || 500, errorMessage || callbackData?.data?.fail_reason);
      const failReason = errorInfo.short;
      // Find tracks that match this task_id first, then fall back to recent pending tracks
      let tracksToFail = [];
      // Try to find tracks by taskId in description metadata
      if (taskId) {
        const { data: taskTracks } = await supabaseAdmin.from("tracks").select("id, user_id, description").in("status", [
          "processing",
          "pending"
        ]).ilike("description", `%${taskId}%`).limit(2);
        if (taskTracks && taskTracks.length > 0) {
          tracksToFail = taskTracks;
          console.log(`Found ${taskTracks.length} tracks matching task_id ${taskId}`);
        }
      }
      // Fall back to recent pending tracks if no task match
      if (tracksToFail.length === 0) {
        const { data: pendingTracks } = await supabaseAdmin.from("tracks").select("id, user_id").in("status", [
          "processing",
          "pending"
        ]).order("created_at", {
          ascending: false
        }).limit(5);
        if (pendingTracks && pendingTracks.length > 0) {
          tracksToFail = pendingTracks;
        }
      }
      if (tracksToFail.length > 0) {
        for (const track of tracksToFail){
          await supabaseAdmin.from("tracks").update({
            status: "failed",
            error_message: failReason
          }).eq("id", track.id);
          // Get generation log to find cost
          const { data: genLog } = await supabaseAdmin.from("generation_logs").select("cost_rub").eq("track_id", track.id).single();
          // Refund ₽ to user
          if (genLog && genLog.cost_rub > 0) {
            const { data: profile } = await supabaseAdmin.from("profiles").select("balance").eq("user_id", track.user_id).single();
            if (profile) {
              const newBalance = (profile.balance || 0) + genLog.cost_rub;
              await supabaseAdmin.from("profiles").update({
                balance: newBalance
              }).eq("user_id", track.user_id);
              // Log refund transaction
              await supabaseAdmin.from("balance_transactions").insert({
                user_id: track.user_id,
                amount: genLog.cost_rub,
                balance_after: newBalance,
                type: "refund",
                description: `Возврат за генерацию: ${failReason}`,
                reference_id: track.id,
                reference_type: "track"
              });
              console.log(`Refunded ${genLog.cost_rub} ₽ to user ${track.user_id}`);
              // Create notification for refund with error explanation
              await supabaseAdmin.from("notifications").insert({
                user_id: track.user_id,
                type: "refund",
                title: `Ошибка: ${failReason}`,
                message: `${errorInfo.full}\n\nВам возвращено ${genLog.cost_rub} ₽`,
                target_type: "track",
                target_id: track.id
              });
            }
          }
          // Update generation log status to failed
          await supabaseAdmin.from("generation_logs").update({
            status: "failed"
          }).eq("track_id", track.id);
        }
        console.log(`Marked ${tracksToFail.length} tracks as failed with refunds`);
      }
      return new Response(JSON.stringify({
        received: true,
        message: "Failure callback processed with refunds"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (!Array.isArray(tracks) || tracks.length === 0) {
      console.log("No tracks in callback data");
      return new Response(JSON.stringify({
        received: true,
        message: "No tracks to process"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Process "complete" (all tracks ready) and "first" (first track ready) callbacks
    // Skip "text" callbacks (only lyrics generated, no audio yet)
    if (callbackType !== "complete" && callbackType !== "first") {
      console.log(`Skipping callback type: ${callbackType} (waiting for audio)`);
      return new Response(JSON.stringify({
        received: true,
        message: `Callback type ${callbackType} acknowledged`
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const isPartialCallback = callbackType === "first";
    if (isPartialCallback) {
      console.log(`Processing partial callback (first) — will only update tracks that have audio_url`);
    }
    // CRITICAL: First, find tracks that match this specific task_id
    // This prevents cross-user track mixing when multiple generations are pending
    let matchedTracks = [];
    if (taskId) {
      const { data: taskTracks, error: taskFindError } = await supabaseAdmin.from("tracks").select("id, title, description, lyrics, user_id, status").in("status", [
        "processing",
        "pending"
      ]).ilike("description", `%[task_id: ${taskId}]%`).order("created_at", {
        ascending: true
      }).limit(2);
      if (taskFindError) {
        console.error("Error finding tracks by task_id:", taskFindError);
      } else if (taskTracks && taskTracks.length > 0) {
        matchedTracks = taskTracks;
        console.log(`Found ${taskTracks.length} tracks matching task_id ${taskId}`);
      }
    }
    // If no task_id match, log a warning but DO NOT fall back to random pending tracks
    // This is critical to prevent cross-user track mixing
    if (matchedTracks.length === 0) {
      console.warn(`No tracks found matching task_id ${taskId}. Callback will be ignored to prevent cross-user mixing.`);
      console.warn(`Callback data had ${tracks.length} audio tracks, but no matching DB records.`);
      return new Response(JSON.stringify({
        received: true,
        warning: "No matching tracks found for task_id",
        task_id: taskId
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    let updatedCount = 0;
    // Create a copy of matched tracks for safe iteration (avoid mutation issues)
    const tracksToProcess = [
      ...matchedTracks
    ];
    // Track which indices have been processed
    const processedIndices = new Set();
    // Suno returns 2 versions per generation request
    // Match them to our v1/v2 track pairs by order (first Suno result -> v1, second -> v2)
    for(let i = 0; i < tracks.length; i++){
      const track = tracks[i];
      const { id: sunoAudioId, audio_url, source_audio_url, stream_audio_url, image_url, source_image_url, duration, title: sunoTitle } = track;
      const audioUrl = audio_url || source_audio_url || stream_audio_url;
      const coverUrl = image_url || source_image_url;
      if (!audioUrl) {
        console.log("Track has no audio URL, skipping");
        continue;
      }
      // Match by index: first Suno result -> first matched track (v1), second -> second (v2)
      // Use the original array copy, not the mutated one
      const trackToUpdate = tracksToProcess[i];
      // Safety check: ensure we're updating the right user's track
      if (!trackToUpdate) {
        console.log(`No matched track at index ${i} for Suno result: ${sunoTitle}`);
        continue;
      }
      // Skip if already processed (shouldn't happen, but be safe)
      if (processedIndices.has(i)) {
        console.log(`Track at index ${i} already processed, skipping`);
        continue;
      }
      processedIndices.add(i);
      console.log(`Updating track ${trackToUpdate.id} (${trackToUpdate.title}) with audio: ${audioUrl}`);
      // Copy files to Supabase Storage for permanent storage
      let finalAudioUrl = audioUrl;
      let finalCoverUrl = coverUrl;
      // Copy audio file to Storage
      try {
        const audioFileName = `${trackToUpdate.id}.mp3`;
        const storedAudioUrl = await copyFileToStorage(supabaseAdmin, audioUrl, "tracks", `audio/${audioFileName}`);
        if (storedAudioUrl) {
          finalAudioUrl = storedAudioUrl;
          console.log(`Audio copied to storage: ${finalAudioUrl}`);
        } else {
          console.log(`Failed to copy audio, using original URL`);
        }
      } catch (audioErr) {
        console.error(`Error copying audio:`, audioErr);
      }
      // Copy cover image to Storage
      if (coverUrl) {
        try {
          const coverFileName = `${trackToUpdate.id}.jpg`;
          const storedCoverUrl = await copyFileToStorage(supabaseAdmin, coverUrl, "tracks", `covers/${coverFileName}`);
          if (storedCoverUrl) {
            finalCoverUrl = storedCoverUrl;
            console.log(`Cover copied to storage: ${finalCoverUrl}`);
          } else {
            console.log(`Failed to copy cover, using original URL`);
          }
        } catch (coverErr) {
          console.error(`Error copying cover:`, coverErr);
        }
      }
      const { error: updateError } = await supabaseAdmin.from("tracks").update({
        audio_url: finalAudioUrl,
        cover_url: finalCoverUrl || null,
        duration: duration ? Math.round(duration) : null,
        status: "completed",
        // Store Suno audio ID for persona creation
        suno_audio_id: sunoAudioId || null,
        // Store suno_task_id in description for reference (append to existing)
        description: trackToUpdate.description ? `${trackToUpdate.description}\n\n[task_id: ${taskId}]` : `[task_id: ${taskId}]`
      }).eq("id", trackToUpdate.id);
      if (updateError) {
        console.error("Error updating track:", updateError);
      } else {
        console.log(`Track ${trackToUpdate.id} updated successfully with Storage URLs`);
        updatedCount++;
        // Update generation log status
        await supabaseAdmin.from("generation_logs").update({
          status: "completed"
        }).eq("track_id", trackToUpdate.id);
        // Process addon services for this track (pass taskId and audioId for Suno video generation)
        await processTrackAddons(supabaseAdmin, trackToUpdate.id, trackToUpdate.title || "Untitled", finalCoverUrl, finalAudioUrl, taskId, sunoAudioId);
        // AI Classification - run in background to not block response
        // Extract style from track description (before task_id was appended)
        const originalDescription = trackToUpdate.description?.replace(/\n\n\[task_id:.*\]$/, "") || null;
        const trackLyrics = trackToUpdate.lyrics || null;
        runInBackground(`classifyTrack-${trackToUpdate.id}`, classifyTrackWithAI(supabaseAdmin, trackToUpdate.id, originalDescription, trackLyrics));
      }
    }
    // ─── Trigger Suno Cover Generation (background) ────────────────
    // After all music tracks are updated, request personalized cover art
    // This runs in background so we don't delay the callback response
    // Only trigger on "complete" callback (not "first") to avoid premature cover generation
    if (updatedCount > 0 && taskId && !isPartialCallback) {
      const trackIdsForCover = tracksToProcess.filter((t)=>processedIndices.has(tracksToProcess.indexOf(t))).map((t)=>t.id);
      if (trackIdsForCover.length > 0) {
        runInBackground(`coverGeneration-${taskId}`, triggerCoverGeneration(supabaseAdmin, taskId, trackIdsForCover));
      }
    }
    return new Response(JSON.stringify({
      success: true,
      updated: updatedCount
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in suno-callback:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9zdW5vLWNhbGxiYWNrLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCwgU3VwYWJhc2VDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuLy8gQmFja2dyb3VuZCB0YXNrIGhlbHBlciDigJQgZmlyZS1hbmQtZm9yZ2V0IHBhdHRlcm5cbi8vIChFZGdlUnVudGltZS53YWl0VW50aWwgaXMgTk9UIGF2YWlsYWJsZSBpbiB0aGlzIERlbm8gc2VydmVyKVxuZnVuY3Rpb24gcnVuSW5CYWNrZ3JvdW5kKHRhc2tOYW1lOiBzdHJpbmcsIHByb21pc2U6IFByb21pc2U8dW5rbm93bj4pOiB2b2lkIHtcbiAgcHJvbWlzZS5jYXRjaChlcnIgPT4gY29uc29sZS5lcnJvcihgW0JhY2tncm91bmQ6ICR7dGFza05hbWV9XSBFcnJvcjpgLCBlcnIpKTtcbn1cblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuLy8gSGVscGVyIGZ1bmN0aW9uIHRvIGRvd25sb2FkIGZpbGUgYW5kIHVwbG9hZCB0byBTdXBhYmFzZSBTdG9yYWdlXG5hc3luYyBmdW5jdGlvbiBjb3B5RmlsZVRvU3RvcmFnZShcbiAgc3VwYWJhc2VBZG1pbjogU3VwYWJhc2VDbGllbnQsXG4gIGV4dGVybmFsVXJsOiBzdHJpbmcsXG4gIGJ1Y2tldDogc3RyaW5nLFxuICBmaWxlUGF0aDogc3RyaW5nXG4pOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgdHJ5IHtcbiAgICBjb25zb2xlLmxvZyhgRG93bmxvYWRpbmcgZmlsZSBmcm9tOiAke2V4dGVybmFsVXJsfWApO1xuICAgIFxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goZXh0ZXJuYWxVcmwpO1xuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEZhaWxlZCB0byBkb3dubG9hZDogJHtyZXNwb25zZS5zdGF0dXN9ICR7cmVzcG9uc2Uuc3RhdHVzVGV4dH1gKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwb25zZS5ibG9iKCk7XG4gICAgY29uc3QgYXJyYXlCdWZmZXIgPSBhd2FpdCBibG9iLmFycmF5QnVmZmVyKCk7XG4gICAgY29uc3QgdWludDhBcnJheSA9IG5ldyBVaW50OEFycmF5KGFycmF5QnVmZmVyKTtcbiAgICBcbiAgICBjb25zb2xlLmxvZyhgRG93bmxvYWRlZCAke3VpbnQ4QXJyYXkubGVuZ3RofSBieXRlcywgdXBsb2FkaW5nIHRvICR7YnVja2V0fS8ke2ZpbGVQYXRofWApO1xuXG4gICAgY29uc3QgeyBlcnJvcjogdXBsb2FkRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW4uc3RvcmFnZVxuICAgICAgLmZyb20oYnVja2V0KVxuICAgICAgLnVwbG9hZChmaWxlUGF0aCwgdWludDhBcnJheSwge1xuICAgICAgICBjb250ZW50VHlwZTogYmxvYi50eXBlIHx8IFwiYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtXCIsXG4gICAgICAgIHVwc2VydDogdHJ1ZSxcbiAgICAgIH0pO1xuXG4gICAgaWYgKHVwbG9hZEVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBVcGxvYWQgZXJyb3I6YCwgdXBsb2FkRXJyb3IpO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgLy8gQnVpbGQgcHVibGljIFVSTCB1c2luZyBCQVNFX1VSTCAobm90IGludGVybmFsIFNVUEFCQVNFX1VSTCB3aGljaCBpcyBodHRwOi8vYXBpOjMwMDApXG4gICAgY29uc3QgYmFzZVVybCA9IERlbm8uZW52LmdldChcIkJBU0VfVVJMXCIpIHx8IFwiaHR0cHM6Ly9haW11emEucnVcIjtcbiAgICBjb25zdCBwdWJsaWNVcmwgPSBgJHtiYXNlVXJsfS9zdG9yYWdlL3YxL29iamVjdC9wdWJsaWMvJHtidWNrZXR9LyR7ZmlsZVBhdGh9YDtcblxuICAgIGNvbnNvbGUubG9nKGBGaWxlIHVwbG9hZGVkIHN1Y2Nlc3NmdWxseTogJHtwdWJsaWNVcmx9YCk7XG4gICAgcmV0dXJuIHB1YmxpY1VybDtcbiAgICBcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcihgRXJyb3IgY29weWluZyBmaWxlIHRvIHN0b3JhZ2U6YCwgZXJyKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG4vLyBUaW1ld2ViIEFnZW50IEFQSSBjb25maWd1cmF0aW9uIGZvciBBSSBjbGFzc2lmaWNhdGlvblxuY29uc3QgVElNRVdFQl9BR0VOVF9BQ0NFU1NfSUQgPSAnMDg0NmQwNjQtNDk1MC00ZDc5LWE1NGMtNjJiYTMxNWNkYjM0JztcblxuLy8gQUkgQ2xhc3NpZmljYXRpb24gZnVuY3Rpb24gLSBkZXRlcm1pbmVzIGdlbnJlLCB2b2NhbCB0eXBlLCB0ZW1wbGF0ZSwgYXJ0aXN0IHN0eWxlXG4vLyBVc2VzIFRpbWV3ZWIgQWdlbnQgQVBJIChHUFQtNClcbmFzeW5jIGZ1bmN0aW9uIGNsYXNzaWZ5VHJhY2tXaXRoQUkoXG4gIHN1cGFiYXNlQWRtaW46IFN1cGFiYXNlQ2xpZW50LFxuICB0cmFja0lkOiBzdHJpbmcsXG4gIHN0eWxlOiBzdHJpbmcgfCBudWxsLFxuICBseXJpY3M6IHN0cmluZyB8IG51bGxcbikge1xuICB0cnkge1xuICAgIGNvbnNvbGUubG9nKGBTdGFydGluZyBBSSBjbGFzc2lmaWNhdGlvbiBmb3IgdHJhY2sgJHt0cmFja0lkfWApO1xuICAgIFxuICAgIGNvbnN0IFRJTUVXRUJfVE9LRU4gPSBEZW5vLmVudi5nZXQoXCJUSU1FV0VCX0FHRU5UX1RPS0VOXCIpO1xuICAgIGlmICghVElNRVdFQl9UT0tFTikge1xuICAgICAgY29uc29sZS5lcnJvcihcIlRJTUVXRUJfQUdFTlRfVE9LRU4gbm90IGNvbmZpZ3VyZWQsIHNraXBwaW5nIGNsYXNzaWZpY2F0aW9uXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBcbiAgICAvLyBGZXRjaCBhbGwgYXZhaWxhYmxlIG9wdGlvbnMgZnJvbSBkYXRhYmFzZVxuICAgIGNvbnN0IFtnZW5yZXNSZXMsIHZvY2FsVHlwZXNSZXMsIHRlbXBsYXRlc1JlcywgYXJ0aXN0U3R5bGVzUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgIHN1cGFiYXNlQWRtaW4uZnJvbShcImdlbnJlc1wiKS5zZWxlY3QoXCJpZCwgbmFtZSwgbmFtZV9ydVwiKS5vcmRlcihcInNvcnRfb3JkZXJcIiksXG4gICAgICBzdXBhYmFzZUFkbWluLmZyb20oXCJ2b2NhbF90eXBlc1wiKS5zZWxlY3QoXCJpZCwgbmFtZSwgbmFtZV9ydSwgZGVzY3JpcHRpb25cIikuZXEoXCJpc19hY3RpdmVcIiwgdHJ1ZSkub3JkZXIoXCJzb3J0X29yZGVyXCIpLFxuICAgICAgc3VwYWJhc2VBZG1pbi5mcm9tKFwidGVtcGxhdGVzXCIpLnNlbGVjdChcImlkLCBuYW1lLCBkZXNjcmlwdGlvblwiKS5lcShcImlzX2FjdGl2ZVwiLCB0cnVlKS5vcmRlcihcInNvcnRfb3JkZXJcIiksXG4gICAgICBzdXBhYmFzZUFkbWluLmZyb20oXCJhcnRpc3Rfc3R5bGVzXCIpLnNlbGVjdChcImlkLCBuYW1lLCBkZXNjcmlwdGlvblwiKS5lcShcImlzX2FjdGl2ZVwiLCB0cnVlKS5vcmRlcihcInNvcnRfb3JkZXJcIiksXG4gICAgXSk7XG4gICAgXG4gICAgY29uc3QgZ2VucmVzID0gZ2VucmVzUmVzLmRhdGEgfHwgW107XG4gICAgY29uc3Qgdm9jYWxUeXBlcyA9IHZvY2FsVHlwZXNSZXMuZGF0YSB8fCBbXTtcbiAgICBjb25zdCB0ZW1wbGF0ZXMgPSB0ZW1wbGF0ZXNSZXMuZGF0YSB8fCBbXTtcbiAgICBjb25zdCBhcnRpc3RTdHlsZXMgPSBhcnRpc3RTdHlsZXNSZXMuZGF0YSB8fCBbXTtcbiAgICBcbiAgICBpZiAoZ2VucmVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgY29uc29sZS5sb2coXCJObyBnZW5yZXMgaW4gZGF0YWJhc2UsIHNraXBwaW5nIGNsYXNzaWZpY2F0aW9uXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBcbiAgICAvLyBCdWlsZCB0aGUgY2xhc3NpZmljYXRpb24gcHJvbXB0XG4gICAgY29uc3QgZ2VucmVzTGlzdCA9IGdlbnJlcy5tYXAoZyA9PiBgLSBpZDogXCIke2cuaWR9XCIsIG5hbWU6IFwiJHtnLm5hbWV9XCIgKCR7Zy5uYW1lX3J1fSlgKS5qb2luKFwiXFxuXCIpO1xuICAgIGNvbnN0IHZvY2FsVHlwZXNMaXN0ID0gdm9jYWxUeXBlcy5tYXAodiA9PiBgLSBpZDogXCIke3YuaWR9XCIsIG5hbWU6IFwiJHt2Lm5hbWV9XCIgKCR7di5uYW1lX3J1fSkke3YuZGVzY3JpcHRpb24gPyBgIC0gJHt2LmRlc2NyaXB0aW9ufWAgOiBcIlwifWApLmpvaW4oXCJcXG5cIik7XG4gICAgY29uc3QgdGVtcGxhdGVzTGlzdCA9IHRlbXBsYXRlcy5sZW5ndGggPiAwIFxuICAgICAgPyB0ZW1wbGF0ZXMubWFwKHQgPT4gYC0gaWQ6IFwiJHt0LmlkfVwiLCBuYW1lOiBcIiR7dC5uYW1lfVwiJHt0LmRlc2NyaXB0aW9uID8gYCAtICR7dC5kZXNjcmlwdGlvbn1gIDogXCJcIn1gKS5qb2luKFwiXFxuXCIpXG4gICAgICA6IFwi0J3QtdGCINC00L7RgdGC0YPQv9C90YvRhSDRiNCw0LHQu9C+0L3QvtCyXCI7XG4gICAgY29uc3QgYXJ0aXN0U3R5bGVzTGlzdCA9IGFydGlzdFN0eWxlcy5sZW5ndGggPiAwXG4gICAgICA/IGFydGlzdFN0eWxlcy5tYXAoYSA9PiBgLSBpZDogXCIke2EuaWR9XCIsIG5hbWU6IFwiJHthLm5hbWV9XCIke2EuZGVzY3JpcHRpb24gPyBgIC0gJHthLmRlc2NyaXB0aW9ufWAgOiBcIlwifWApLmpvaW4oXCJcXG5cIilcbiAgICAgIDogXCLQndC10YIg0LTQvtGB0YLRg9C/0L3Ri9GFINGB0YLQuNC70LXQuSDQsNGA0YLQuNGB0YLQvtCyXCI7XG4gICAgXG4gICAgY29uc3QgcHJvbXB0ID0gYNCi0Ysg4oCUINC80YPQt9GL0LrQsNC70YzQvdGL0Lkg0LrQu9Cw0YHRgdC40YTQuNC60LDRgtC+0YAuINCf0YDQvtCw0L3QsNC70LjQt9C40YDRg9C5INGB0YLQuNC70Ywg0Lgg0LvQuNGA0LjQutGDINGC0YDQtdC60LAuXG7QktGL0LHQtdGA0Lgg0J7QlNCY0J0g0L3QsNC40LHQvtC70LXQtSDQv9C+0LTRhdC+0LTRj9GJ0LjQuSDQstCw0YDQuNCw0L3RgiDQuNC3INC60LDQttC00L7QuSDQutCw0YLQtdCz0L7RgNC40LguXG5cbtCW0JDQndCg0KsgKNC+0LHRj9C30LDRgtC10LvRjNC90L4g0LLRi9Cx0LXRgNC4INC+0LTQuNC9KTpcbiR7Z2VucmVzTGlzdH1cblxu0KLQmNCf0Ksg0JLQntCa0JDQm9CQICjQvtCx0Y/Qt9Cw0YLQtdC70YzQvdC+INCy0YvQsdC10YDQuCDQvtC00LjQvSk6XG4ke3ZvY2FsVHlwZXNMaXN0fVxuXG7QqNCQ0JHQm9Ce0J3QqyAo0L7Qv9GG0LjQvtC90LDQu9GM0L3Qviwg0LLRi9Cx0LXRgNC4INC10YHQu9C4INC/0L7QtNGF0L7QtNC40YIpOlxuJHt0ZW1wbGF0ZXNMaXN0fVxuXG7QodCi0JjQm9CYINCQ0KDQotCY0KHQotCe0JIgKNC+0L/RhtC40L7QvdCw0LvRjNC90L4sINCy0YvQsdC10YDQuCDQtdGB0LvQuCDQtdGB0YLRjCDRj9Cy0L3QvtC1INGB0YXQvtC00YHRgtCy0L4pOlxuJHthcnRpc3RTdHlsZXNMaXN0fVxuXG4tLS1cbtCh0KLQmNCb0Kwg0KLQoNCV0JrQkDogJHtzdHlsZSB8fCBcItCd0LUg0YPQutCw0LfQsNC9XCJ9XG7Qm9CY0KDQmNCa0JA6ICR7bHlyaWNzID8gbHlyaWNzLnN1YnN0cmluZygwLCAxMDAwKSA6IFwi0JjQvdGB0YLRgNGD0LzQtdC90YLQsNC7ICjQsdC10Lcg0YLQtdC60YHRgtCwKVwifVxuLS0tXG5cbtCf0YDQsNCy0LjQu9CwOlxuMS4gZ2VucmVfaWQgLSDQntCR0K/Ql9CQ0KLQldCb0JXQnSwg0LLRi9Cx0LXRgNC4INC90LDQuNCx0L7Qu9C10LUg0LHQu9C40LfQutC40Lkg0LbQsNC90YBcbjIuIHZvY2FsX3R5cGVfaWQgLSDQntCR0K/Ql9CQ0KLQldCb0JXQnS4g0JXRgdC70Lgg0L3QtdGCINC70LjRgNC40LrQuCwg0LLRi9Cx0LXRgNC4IFwiaW5zdHJ1bWVudGFsXCJcbjMuIHRlbXBsYXRlX2lkIC0g0YLQvtC70YzQutC+INC10YHQu9C4INGC0YDQtdC6INGP0LLQvdC+INGB0L7QvtGC0LLQtdGC0YHRgtCy0YPQtdGCINGI0LDQsdC70L7QvdGDLCDQuNC90LDRh9C1IG51bGxcbjQuIGFydGlzdF9zdHlsZV9pZCAtINGC0L7Qu9GM0LrQviDQtdGB0LvQuCDRgdGC0LjQu9GMINGP0LLQvdC+INC/0L7RhdC+0LYg0L3QsCDQutC+0L3QutGA0LXRgtC90L7Qs9C+INCw0YDRgtC40YHRgtCwLCDQuNC90LDRh9C1IG51bGxcblxu0JLQtdGA0L3QuCDQotCe0JvQrNCa0J4gSlNPTiDQsdC10LcgbWFya2Rvd246XG57XCJnZW5yZV9pZFwiOiBcIi4uLlwiLCBcInZvY2FsX3R5cGVfaWRcIjogXCIuLi5cIiwgXCJ0ZW1wbGF0ZV9pZFwiOiBcIi4uLlwiINC40LvQuCBudWxsLCBcImFydGlzdF9zdHlsZV9pZFwiOiBcIi4uLlwiINC40LvQuCBudWxsfWA7XG5cbiAgICBjb25zdCBhcGlVcmwgPSBgaHR0cHM6Ly9hZ2VudC50aW1ld2ViLmNsb3VkL2FwaS92MS9jbG91ZC1haS9hZ2VudHMvJHtUSU1FV0VCX0FHRU5UX0FDQ0VTU19JRH0vdjEvY2hhdC9jb21wbGV0aW9uc2A7XG4gICAgXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtUSU1FV0VCX1RPS0VOfWAsXG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBcIngtcHJveHktc291cmNlXCI6IFwibG92YWJsZS1hcHBcIixcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIG1vZGVsOiBcImRlZXBzZWVrLXYzXCIsXG4gICAgICAgIG1lc3NhZ2VzOiBbXG4gICAgICAgICAgeyByb2xlOiBcInN5c3RlbVwiLCBjb250ZW50OiBcItCi0Ysg0LzRg9C30YvQutCw0LvRjNC90YvQuSDQutC70LDRgdGB0LjRhNC40LrQsNGC0L7RgC4g0J7RgtCy0LXRh9Cw0Lkg0YLQvtC70YzQutC+IEpTT04uXCIgfSxcbiAgICAgICAgICB7IHJvbGU6IFwidXNlclwiLCBjb250ZW50OiBwcm9tcHQgfVxuICAgICAgICBdLFxuICAgICAgICB0ZW1wZXJhdHVyZTogMC4zLFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBBSSBjbGFzc2lmaWNhdGlvbiBmYWlsZWQ6ICR7cmVzcG9uc2Uuc3RhdHVzfWApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zdCBjb250ZW50ID0gcmVzdWx0LmNob2ljZXM/LlswXT8ubWVzc2FnZT8uY29udGVudDtcbiAgICBcbiAgICBpZiAoIWNvbnRlbnQpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJObyBjb250ZW50IGluIEFJIHJlc3BvbnNlXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBcbiAgICBjb25zb2xlLmxvZyhgQUkgY2xhc3NpZmljYXRpb24gcmVzcG9uc2U6ICR7Y29udGVudH1gKTtcbiAgICBcbiAgICAvLyBQYXJzZSBKU09OIHJlc3BvbnNlIChoYW5kbGUgcG90ZW50aWFsIG1hcmtkb3duIHdyYXBwZXIpXG4gICAgbGV0IGNsYXNzaWZpY2F0aW9uO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBqc29uTWF0Y2ggPSBjb250ZW50Lm1hdGNoKC9cXHtbXFxzXFxTXSpcXH0vKTtcbiAgICAgIGlmIChqc29uTWF0Y2gpIHtcbiAgICAgICAgY2xhc3NpZmljYXRpb24gPSBKU09OLnBhcnNlKGpzb25NYXRjaFswXSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjbGFzc2lmaWNhdGlvbiA9IEpTT04ucGFyc2UoY29udGVudCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAocGFyc2VFcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gcGFyc2UgQUkgY2xhc3NpZmljYXRpb246XCIsIHBhcnNlRXJyKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgXG4gICAgLy8gVmFsaWRhdGUgSURzIGV4aXN0IGluIG91ciBkYXRhXG4gICAgY29uc3QgdmFsaWRHZW5yZUlkID0gZ2VucmVzLmZpbmQoZyA9PiBnLmlkID09PSBjbGFzc2lmaWNhdGlvbi5nZW5yZV9pZCk/LmlkIHx8IG51bGw7XG4gICAgY29uc3QgdmFsaWRWb2NhbFR5cGVJZCA9IHZvY2FsVHlwZXMuZmluZCh2ID0+IHYuaWQgPT09IGNsYXNzaWZpY2F0aW9uLnZvY2FsX3R5cGVfaWQpPy5pZCB8fCBudWxsO1xuICAgIGNvbnN0IHZhbGlkVGVtcGxhdGVJZCA9IGNsYXNzaWZpY2F0aW9uLnRlbXBsYXRlX2lkIFxuICAgICAgPyB0ZW1wbGF0ZXMuZmluZCh0ID0+IHQuaWQgPT09IGNsYXNzaWZpY2F0aW9uLnRlbXBsYXRlX2lkKT8uaWQgfHwgbnVsbCBcbiAgICAgIDogbnVsbDtcbiAgICBjb25zdCB2YWxpZEFydGlzdFN0eWxlSWQgPSBjbGFzc2lmaWNhdGlvbi5hcnRpc3Rfc3R5bGVfaWQgXG4gICAgICA/IGFydGlzdFN0eWxlcy5maW5kKGEgPT4gYS5pZCA9PT0gY2xhc3NpZmljYXRpb24uYXJ0aXN0X3N0eWxlX2lkKT8uaWQgfHwgbnVsbCBcbiAgICAgIDogbnVsbDtcbiAgICBcbiAgICAvLyBVcGRhdGUgdHJhY2sgd2l0aCBjbGFzc2lmaWNhdGlvblxuICAgIGNvbnN0IHVwZGF0ZURhdGE6IFJlY29yZDxzdHJpbmcsIHN0cmluZyB8IG51bGw+ID0ge307XG4gICAgaWYgKHZhbGlkR2VucmVJZCkgdXBkYXRlRGF0YS5nZW5yZV9pZCA9IHZhbGlkR2VucmVJZDtcbiAgICBpZiAodmFsaWRWb2NhbFR5cGVJZCkgdXBkYXRlRGF0YS52b2NhbF90eXBlX2lkID0gdmFsaWRWb2NhbFR5cGVJZDtcbiAgICBpZiAodmFsaWRUZW1wbGF0ZUlkKSB1cGRhdGVEYXRhLnRlbXBsYXRlX2lkID0gdmFsaWRUZW1wbGF0ZUlkO1xuICAgIGlmICh2YWxpZEFydGlzdFN0eWxlSWQpIHVwZGF0ZURhdGEuYXJ0aXN0X3N0eWxlX2lkID0gdmFsaWRBcnRpc3RTdHlsZUlkO1xuICAgIFxuICAgIGlmIChPYmplY3Qua2V5cyh1cGRhdGVEYXRhKS5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnIgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnVwZGF0ZSh1cGRhdGVEYXRhKVxuICAgICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKTtcbiAgICAgIFxuICAgICAgaWYgKHVwZGF0ZUVycikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSB0cmFjayBjbGFzc2lmaWNhdGlvbjpcIiwgdXBkYXRlRXJyKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBUcmFjayAke3RyYWNrSWR9IGNsYXNzaWZpZWQ6IGdlbnJlPSR7dmFsaWRHZW5yZUlkfSwgdm9jYWw9JHt2YWxpZFZvY2FsVHlwZUlkfSwgdGVtcGxhdGU9JHt2YWxpZFRlbXBsYXRlSWR9LCBhcnRpc3Q9JHt2YWxpZEFydGlzdFN0eWxlSWR9YCk7XG4gICAgICB9XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gQUkgY2xhc3NpZmljYXRpb246XCIsIGVycik7XG4gIH1cbn1cblxuLy8gRnVuY3Rpb24gdG8gcHJvY2VzcyBhZGRvbiBzZXJ2aWNlcyBhZnRlciB0cmFjayBpcyBjb21wbGV0ZWRcbmFzeW5jIGZ1bmN0aW9uIHByb2Nlc3NUcmFja0FkZG9ucyhcbiAgc3VwYWJhc2VBZG1pbjogU3VwYWJhc2VDbGllbnQsXG4gIHRyYWNrSWQ6IHN0cmluZyxcbiAgdHJhY2tUaXRsZTogc3RyaW5nLFxuICBjb3ZlclVybDogc3RyaW5nIHwgbnVsbCxcbiAgYXVkaW9Vcmw6IHN0cmluZyB8IG51bGwsXG4gIHN1bm9UYXNrSWQ/OiBzdHJpbmcsXG4gIHN1bm9BdWRpb0lkPzogc3RyaW5nXG4pIHtcbiAgdHJ5IHtcbiAgICAvLyBHZXQgcGVuZGluZyBhZGRvbnMgZm9yIHRoaXMgdHJhY2tcbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrQWRkb25zLCBlcnJvcjogYWRkb25zRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAuc2VsZWN0KGBcbiAgICAgICAgaWQsXG4gICAgICAgIGFkZG9uX3NlcnZpY2VfaWQsXG4gICAgICAgIHN0YXR1cyxcbiAgICAgICAgYWRkb25fc2VydmljZTphZGRvbl9zZXJ2aWNlcyhuYW1lLCBuYW1lX3J1KVxuICAgICAgYClcbiAgICAgIC5lcShcInRyYWNrX2lkXCIsIHRyYWNrSWQpXG4gICAgICAuZXEoXCJzdGF0dXNcIiwgXCJwZW5kaW5nXCIpO1xuXG4gICAgaWYgKGFkZG9uc0Vycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdHJhY2sgYWRkb25zOlwiLCBhZGRvbnNFcnJvcik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKCF0cmFja0FkZG9ucyB8fCB0cmFja0FkZG9ucy5sZW5ndGggPT09IDApIHtcbiAgICAgIGNvbnNvbGUubG9nKGBObyBwZW5kaW5nIGFkZG9ucyBmb3IgdHJhY2sgJHt0cmFja0lkfWApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBQcm9jZXNzaW5nICR7dHJhY2tBZGRvbnMubGVuZ3RofSBhZGRvbnMgZm9yIHRyYWNrICR7dHJhY2tJZH1gKTtcblxuICAgIC8vIEdldCB0cmFjayBnZW5yZSBmb3IgYmV0dGVyIEFJIGdlbmVyYXRpb25cbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLnNlbGVjdChcImdlbnJlX2lkLCBnZW5yZXMobmFtZSlcIilcbiAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBjb25zdCBnZW5yZURhdGEgPSAodHJhY2s/LmdlbnJlcyBhcyB1bmtub3duKSBhcyB7IG5hbWU6IHN0cmluZyB9IHwgbnVsbDtcbiAgICBjb25zdCBnZW5yZU5hbWUgPSBnZW5yZURhdGE/Lm5hbWUgfHwgXCJlbGVjdHJvbmljXCI7XG5cbiAgICBjb25zdCBTVVBBQkFTRV9VUkwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IFNVUEFCQVNFX1NFUlZJQ0VfS0VZID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSFcblxuICAgIGZvciAoY29uc3QgYWRkb24gb2YgdHJhY2tBZGRvbnMpIHtcbiAgICAgIGNvbnN0IGFkZG9uU2VydmljZURhdGEgPSAoYWRkb24uYWRkb25fc2VydmljZSBhcyB1bmtub3duKSBhcyB7IG5hbWU6IHN0cmluZzsgbmFtZV9ydTogc3RyaW5nIH0gfCBudWxsO1xuICAgICAgY29uc3QgYWRkb25OYW1lID0gYWRkb25TZXJ2aWNlRGF0YT8ubmFtZTtcbiAgICAgIGNvbnNvbGUubG9nKGBQcm9jZXNzaW5nIGFkZG9uOiAke2FkZG9uTmFtZX0gZm9yIHRyYWNrICR7dHJhY2tJZH1gKTtcblxuICAgICAgLy8gVXBkYXRlIHN0YXR1cyB0byBwcm9jZXNzaW5nXG4gICAgICBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiLCB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgYWRkb24uaWQpO1xuXG4gICAgICBsZXQgZnVuY3Rpb25OYW1lOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgICAgIGxldCByZXF1ZXN0Qm9keTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICAgIHRyYWNrX2lkOiB0cmFja0lkLFxuICAgICAgICB0cmFja190aXRsZTogdHJhY2tUaXRsZSxcbiAgICAgICAgZ2VucmU6IGdlbnJlTmFtZSxcbiAgICAgIH07XG4gICAgICBcbiAgICAgIGlmIChhZGRvbk5hbWUgPT09IFwibGFyZ2VfY292ZXJcIikge1xuICAgICAgICBmdW5jdGlvbk5hbWUgPSBcImdlbmVyYXRlLWhkLWNvdmVyXCI7XG4gICAgICAgIHJlcXVlc3RCb2R5Lm9yaWdpbmFsX2NvdmVyX3VybCA9IGNvdmVyVXJsO1xuICAgICAgfSBlbHNlIGlmIChhZGRvbk5hbWUgPT09IFwic2hvcnRfdmlkZW9cIikge1xuICAgICAgICBmdW5jdGlvbk5hbWUgPSBcImdlbmVyYXRlLXNob3J0LXZpZGVvXCI7XG4gICAgICAgIHJlcXVlc3RCb2R5LmNvdmVyX3VybCA9IGNvdmVyVXJsO1xuICAgICAgICAvLyBGb3IgU3VubyBtdXNpYyB2aWRlbyBnZW5lcmF0aW9uLCB3ZSBuZWVkIHRoZSB0YXNrX2lkIGFuZCBhdWRpb19pZFxuICAgICAgICBpZiAoc3Vub1Rhc2tJZCkge1xuICAgICAgICAgIHJlcXVlc3RCb2R5LnN1bm9fdGFza19pZCA9IHN1bm9UYXNrSWQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN1bm9BdWRpb0lkKSB7XG4gICAgICAgICAgcmVxdWVzdEJvZHkuc3Vub19hdWRpb19pZCA9IHN1bm9BdWRpb0lkO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGFkZG9uTmFtZSA9PT0gXCJyaW5ndG9uZVwiKSB7XG4gICAgICAgIGZ1bmN0aW9uTmFtZSA9IFwiZ2VuZXJhdGUtcmluZ3RvbmVcIjtcbiAgICAgICAgcmVxdWVzdEJvZHkuYXVkaW9fdXJsID0gYXVkaW9Vcmw7XG4gICAgICB9XG5cbiAgICAgIGlmIChmdW5jdGlvbk5hbWUpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAvLyBDYWxsIHRoZSBlZGdlIGZ1bmN0aW9uIGRpcmVjdGx5IHVzaW5nIGZldGNoXG4gICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtTVVBBQkFTRV9VUkx9L2Z1bmN0aW9ucy92MS8ke2Z1bmN0aW9uTmFtZX1gLCB7XG4gICAgICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVVBBQkFTRV9TRVJWSUNFX0tFWX1gLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlcXVlc3RCb2R5KSxcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgJHtmdW5jdGlvbk5hbWV9IHJlc3VsdCBmb3IgdHJhY2sgJHt0cmFja0lkfTpgLCByZXN1bHQpO1xuXG4gICAgICAgICAgaWYgKCFyZXN1bHQuc3VjY2Vzcykge1xuICAgICAgICAgICAgLy8gTWFyayBhcyBmYWlsZWRcbiAgICAgICAgICAgIGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgICAgICAgLmZyb20oXCJ0cmFja19hZGRvbnNcIilcbiAgICAgICAgICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIiwgXG4gICAgICAgICAgICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIFxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAuZXEoXCJpZFwiLCBhZGRvbi5pZCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIE5vdGU6IHN1Y2Nlc3NmdWwgcmVzdWx0X3VybCB1cGRhdGUgaXMgaGFuZGxlZCBieSB0aGUgZWRnZSBmdW5jdGlvbiBpdHNlbGZcbiAgICAgICAgfSBjYXRjaCAoZm5FcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNhbGxpbmcgJHtmdW5jdGlvbk5hbWV9OmAsIGZuRXJyb3IpO1xuICAgICAgICAgIGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgICAgICAudXBkYXRlKHsgXG4gICAgICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIiwgXG4gICAgICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSBcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuZXEoXCJpZFwiLCBhZGRvbi5pZCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBVbmtub3duIGFkZG9uIHR5cGU6ICR7YWRkb25OYW1lfSwgbWFya2luZyBhcyBmYWlsZWRgKTtcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLCBcbiAgICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSBcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5lcShcImlkXCIsIGFkZG9uLmlkKTtcbiAgICAgIH1cbiAgICB9XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIHByb2Nlc3NpbmcgdHJhY2sgYWRkb25zOlwiLCBlcnJvcik7XG4gIH1cbn1cblxuLy8g4pSA4pSA4pSAIFRyaWdnZXIgU3VubyBDb3ZlciBHZW5lcmF0aW9uIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gQWZ0ZXIgbXVzaWMgaXMgZ2VuZXJhdGVkLCByZXF1ZXN0IHBlcnNvbmFsaXplZCBjb3ZlciBhcnQgdmlhIFN1bm8gQ292ZXIgQVBJXG4vLyBEb2NzOiBodHRwczovL2RvY3Muc3Vub2FwaS5vcmcvc3Vuby1hcGkvY292ZXItc3Vub1xuYXN5bmMgZnVuY3Rpb24gdHJpZ2dlckNvdmVyR2VuZXJhdGlvbihcbiAgc3VwYWJhc2VBZG1pbjogU3VwYWJhc2VDbGllbnQsXG4gIG11c2ljVGFza0lkOiBzdHJpbmcsXG4gIG1hdGNoZWRUcmFja0lkczogc3RyaW5nW11cbikge1xuICB0cnkge1xuICAgIGNvbnN0IFNVTk9fQVBJX0tFWSA9IERlbm8uZW52LmdldChcIlNVTk9fQVBJX0tFWVwiKTtcbiAgICBjb25zdCBTVU5PX0FQSV9CQVNFID0gXCJodHRwczovL2FwaWJveC5lcndlaW1hLmFpXCI7XG4gICAgY29uc3QgY2FsbGJhY2tTZWNyZXQgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0NBTExCQUNLX1NFQ1JFVFwiKTtcbiAgICBjb25zdCBiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiQkFTRV9VUkxcIikgfHwgXCJodHRwczovL2FpbXV6YS5ydVwiO1xuXG4gICAgaWYgKCFTVU5PX0FQSV9LRVkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJTVU5PX0FQSV9LRVkgbm90IHNldCwgc2tpcHBpbmcgY292ZXIgZ2VuZXJhdGlvblwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBCdWlsZCBjb3ZlciBjYWxsYmFjayBVUkxcbiAgICBjb25zdCBjb3ZlckNhbGxiYWNrVXJsID0gY2FsbGJhY2tTZWNyZXRcbiAgICAgID8gYCR7YmFzZVVybH0vZnVuY3Rpb25zL3YxL3N1bm8tY292ZXItY2FsbGJhY2s/c2VjcmV0PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNhbGxiYWNrU2VjcmV0KX1gXG4gICAgICA6IGAke2Jhc2VVcmx9L2Z1bmN0aW9ucy92MS9zdW5vLWNvdmVyLWNhbGxiYWNrYDtcblxuICAgIGNvbnNvbGUubG9nKGBUcmlnZ2VyaW5nIFN1bm8gY292ZXIgZ2VuZXJhdGlvbiBmb3IgbXVzaWMgdGFzayAke211c2ljVGFza0lkfWApO1xuICAgIGNvbnNvbGUubG9nKGBDb3ZlciBjYWxsYmFjayBVUkw6ICR7Y292ZXJDYWxsYmFja1VybH1gKTtcblxuICAgIC8vIENhbGwgU3VubyBDb3ZlciBBUElcbiAgICAvLyBUcnkgcHJpbWFyeSBwYXRoIGZpcnN0LCB0aGVuIGZhbGxiYWNrXG4gICAgY29uc3QgcGF0aHMgPSBbXG4gICAgICBcIi9hcGkvdjEvc3Vuby9jb3Zlci9nZW5lcmF0ZVwiLFxuICAgICAgXCIvYXBpL3YxL2NvdmVyL2dlbmVyYXRlXCIsXG4gICAgXTtcblxuICAgIGxldCBjb3ZlclJlc3BvbnNlID0gbnVsbDtcbiAgICBsZXQgY292ZXJEYXRhID0gbnVsbDtcblxuICAgIGZvciAoY29uc3QgcGF0aCBvZiBwYXRocykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7U1VOT19BUElfQkFTRX0ke3BhdGh9YDtcbiAgICAgICAgY29uc29sZS5sb2coYFRyeWluZyBjb3ZlciBBUEk6ICR7dXJsfWApO1xuXG4gICAgICAgIGNvdmVyUmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgIHRhc2tJZDogbXVzaWNUYXNrSWQsXG4gICAgICAgICAgICBjYWxsQmFja1VybDogY292ZXJDYWxsYmFja1VybCxcbiAgICAgICAgICB9KSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY292ZXJEYXRhID0gYXdhaXQgY292ZXJSZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBDb3ZlciBBUEkgcmVzcG9uc2UgKCR7cGF0aH0pOmAsIEpTT04uc3RyaW5naWZ5KGNvdmVyRGF0YSkpO1xuXG4gICAgICAgIC8vIElmIG5vdCBhIDQwNCAod3JvbmcgcGF0aCksIHdlIGZvdW5kIHRoZSByaWdodCBlbmRwb2ludFxuICAgICAgICBpZiAoY292ZXJSZXNwb25zZS5zdGF0dXMgIT09IDQwNCkgYnJlYWs7XG4gICAgICB9IGNhdGNoIChmZXRjaEVycikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBDb3ZlciBBUEkgZmV0Y2ggZXJyb3IgKCR7cGF0aH0pOmAsIGZldGNoRXJyKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoIWNvdmVyRGF0YSB8fCAoY292ZXJEYXRhLmNvZGUgIT09IDIwMCAmJiBjb3ZlckRhdGEuY29kZSAhPT0gNDAwKSkge1xuICAgICAgY29uc29sZS5lcnJvcihgQ292ZXIgQVBJIGZhaWxlZDogJHtKU09OLnN0cmluZ2lmeShjb3ZlckRhdGEpfWApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIGNvZGUgNDAwID0gY292ZXIgYWxyZWFkeSBnZW5lcmF0ZWQgZm9yIHRoaXMgdGFzayAocmV0dXJucyBleGlzdGluZyB0YXNrSWQpXG4gICAgY29uc3QgY292ZXJUYXNrSWQgPSBjb3ZlckRhdGEuZGF0YT8udGFza0lkO1xuICAgIGlmICghY292ZXJUYXNrSWQpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJObyBjb3ZlclRhc2tJZCBpbiByZXNwb25zZVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgQ292ZXIgZ2VuZXJhdGlvbiBzdGFydGVkLCBjb3Zlcl90YXNrX2lkOiAke2NvdmVyVGFza0lkfWApO1xuXG4gICAgLy8gU3RvcmUgY292ZXJfdGFza19pZCBpbiBtYXRjaGVkIHRyYWNrcyBmb3IgY2FsbGJhY2sgbWF0Y2hpbmdcbiAgICBmb3IgKGNvbnN0IHRyYWNrSWQgb2YgbWF0Y2hlZFRyYWNrSWRzKSB7XG4gICAgICBjb25zdCB7IGRhdGE6IHRyYWNrIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgIC5zZWxlY3QoXCJkZXNjcmlwdGlvblwiKVxuICAgICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKVxuICAgICAgICAuc2luZ2xlKCk7XG5cbiAgICAgIGlmICh0cmFjaykge1xuICAgICAgICAvLyBPbmx5IGFkZCBpZiBub3QgYWxyZWFkeSBwcmVzZW50XG4gICAgICAgIGlmICghdHJhY2suZGVzY3JpcHRpb24/LmluY2x1ZGVzKGBbY292ZXJfdGFza19pZDogJHtjb3ZlclRhc2tJZH1dYCkpIHtcbiAgICAgICAgICBjb25zdCBuZXdEZXNjID0gdHJhY2suZGVzY3JpcHRpb25cbiAgICAgICAgICAgID8gYCR7dHJhY2suZGVzY3JpcHRpb259XFxuXFxuW2NvdmVyX3Rhc2tfaWQ6ICR7Y292ZXJUYXNrSWR9XWBcbiAgICAgICAgICAgIDogYFtjb3Zlcl90YXNrX2lkOiAke2NvdmVyVGFza0lkfV1gO1xuXG4gICAgICAgICAgYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAgIC51cGRhdGUoeyBkZXNjcmlwdGlvbjogbmV3RGVzYyB9KVxuICAgICAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZCk7XG5cbiAgICAgICAgICBjb25zb2xlLmxvZyhgU3RvcmVkIGNvdmVyX3Rhc2tfaWQgJHtjb3ZlclRhc2tJZH0gaW4gdHJhY2sgJHt0cmFja0lkfWApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdHJpZ2dlcmluZyBjb3ZlciBnZW5lcmF0aW9uOlwiLCBlcnIpO1xuICB9XG59XG5cbi8vIEh1bWFuLXJlYWRhYmxlIGVycm9yIG1lc3NhZ2VzIGZvciBTdW5vIGVycm9yIGNvZGVzXG4vLyBPZmZpY2lhbCBTdW5vIEFQSSBlcnJvciBjb2RlcyByZWZlcmVuY2U6XG4vLyA0MDAgLSBJbnZhbGlkIFBhcmFtZXRlcnNcbi8vIDQwMSAtIFVuYXV0aG9yaXplZFxuLy8gNDAzIC0gRm9yYmlkZGVuIChtb2RlcmF0aW9uL2NvcHlyaWdodClcbi8vIDQwNCAtIE5vdCBGb3VuZFxuLy8gNDA1IC0gUmF0ZSBMaW1pdGVkIChBUEkgZnJlcXVlbmN5KVxuLy8gNDEzIC0gQ29udGVudCBUb28gTGFyZ2UgKHByb21wdC9seXJpY3MgdG9vIGxvbmcpXG4vLyA0MjkgLSBJbnN1ZmZpY2llbnQgQ3JlZGl0c1xuLy8gNDU1IC0gTWFpbnRlbmFuY2Vcbi8vIDUwMC81MDMgLSBTZXJ2ZXIgZXJyb3JzXG5mdW5jdGlvbiBnZXRTdW5vRXJyb3JNZXNzYWdlKGNvZGU6IG51bWJlciwgb3JpZ2luYWxNZXNzYWdlPzogc3RyaW5nKTogeyBzaG9ydDogc3RyaW5nOyBmdWxsOiBzdHJpbmcgfSB7XG4gIC8vIEZpcnN0LCBjaGVjayBmb3Igc3BlY2lmaWMgZXJyb3IgbWVzc2FnZSBwYXR0ZXJucyAobW9yZSBhY2N1cmF0ZSB0aGFuIGp1c3QgY29kZSlcbiAgaWYgKG9yaWdpbmFsTWVzc2FnZSkge1xuICAgIGNvbnN0IGxvd2VyTXNnID0gb3JpZ2luYWxNZXNzYWdlLnRvTG93ZXJDYXNlKCk7XG4gICAgXG4gICAgLy8gQ29weXJpZ2h0L2NvbnRlbnQgbWF0Y2hpbmcgZGV0ZWN0aW9uXG4gICAgaWYgKGxvd2VyTXNnLmluY2x1ZGVzKFwibWF0Y2hlcyBleGlzdGluZyB3b3JrXCIpIHx8IFxuICAgICAgICBsb3dlck1zZy5pbmNsdWRlcyhcImV4aXN0aW5nIHdvcmsgb2YgYXJ0XCIpIHx8XG4gICAgICAgIGxvd2VyTXNnLmluY2x1ZGVzKFwiY29weXJpZ2h0XCIpIHx8XG4gICAgICAgIGxvd2VyTXNnLmluY2x1ZGVzKFwicHJvdGVjdGVkIGNvbnRlbnRcIikpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHNob3J0OiBcItCa0L7QvdGC0LXQvdGCINC30LDRidC40YnRkdC9INCw0LLRgtC+0YDRgdC60LjQvCDQv9GA0LDQstC+0LxcIixcbiAgICAgICAgZnVsbDogXCLQl9Cw0LPRgNGD0LbQtdC90L3Ri9C5INCw0YPQtNC40L7RhNCw0LnQuyDQuNC70Lgg0YLQtdC60YHRgiDRgNCw0YHQv9C+0LfQvdCw0L0g0LrQsNC6INGB0YPRidC10YHRgtCy0YPRjtGJ0LXQtSDQv9GA0L7QuNC30LLQtdC00LXQvdC40LUuINCh0LjRgdGC0LXQvNCwINC30LDRidC40YLRiyDQsNCy0YLQvtGA0YHQutC40YUg0L/RgNCw0LIgU3VubyDQt9Cw0LHQu9C+0LrQuNGA0L7QstCw0LvQsCDQs9C10L3QtdGA0LDRhtC40Y4uINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC40YHQv9C+0LvRjNC30L7QstCw0YLRjCDQvtGA0LjQs9C40L3QsNC70YzQvdGL0Lkg0LrQvtC90YLQtdC90YIuXCJcbiAgICAgIH07XG4gICAgfVxuICAgIFxuICAgIC8vIE1vZGVyYXRpb24vc2Vuc2l0aXZlIGNvbnRlbnRcbiAgICBpZiAobG93ZXJNc2cuaW5jbHVkZXMoXCJtb2RlcmF0aW9uXCIpIHx8IFxuICAgICAgICBsb3dlck1zZy5pbmNsdWRlcyhcInNlbnNpdGl2ZVwiKSB8fCBcbiAgICAgICAgbG93ZXJNc2cuaW5jbHVkZXMoXCJpbmFwcHJvcHJpYXRlXCIpIHx8XG4gICAgICAgIGxvd2VyTXNnLmluY2x1ZGVzKFwicHJvaGliaXRlZFwiKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2hvcnQ6IFwi0JrQvtC90YLQtdC90YIg0L3QtSDQv9GA0L7RiNGR0Lsg0LzQvtC00LXRgNCw0YbQuNGOXCIsXG4gICAgICAgIGZ1bGw6IFwi0KLQtdC60YHRgiDQuNC70Lgg0L7Qv9C40YHQsNC90LjQtSDRgdC+0LTQtdGA0LbQuNGCINC30LDQv9GA0LXRidGR0L3QvdGL0LUg0YHQu9C+0LLQsCDQuNC70Lgg0YTRgNCw0LfRiy4g0JjQt9C80LXQvdC40YLQtSDRgdC+0LTQtdGA0LbQuNC80L7QtSDQuCDQv9C+0L/RgNC+0LHRg9C50YLQtSDRgdC90L7QstCwLlwiXG4gICAgICB9O1xuICAgIH1cbiAgICBcbiAgICAvLyBBdWRpbyBmZXRjaCBpc3N1ZXNcbiAgICBpZiAobG93ZXJNc2cuaW5jbHVkZXMoXCJmZXRjaFwiKSAmJiBsb3dlck1zZy5pbmNsdWRlcyhcImF1ZGlvXCIpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzaG9ydDogXCLQndC1INGD0LTQsNC70L7RgdGMINC/0L7Qu9GD0YfQuNGC0Ywg0LDRg9C00LjQvtGE0LDQudC7XCIsXG4gICAgICAgIGZ1bGw6IFwi0KHQtdGA0LLQtdGAINC90LUg0YHQvNC+0LMg0LfQsNCz0YDRg9C30LjRgtGMINCy0LDRiCDQsNGD0LTQuNC+0YTQsNC50LsuINCf0YDQvtCy0LXRgNGM0YLQtSwg0YfRgtC+INGE0LDQudC7INC00L7RgdGC0YPQv9C10L0g0Lgg0L/QvtC/0YDQvtCx0YPQudGC0LUg0YHQvdC+0LLQsC5cIlxuICAgICAgfTtcbiAgICB9XG4gICAgXG4gICAgLy8gQ29udGVudCB0b28gbG9uZyAoY2FuIGNvbWUgaW4gbWVzc2FnZSB0b28pXG4gICAgaWYgKGxvd2VyTXNnLmluY2x1ZGVzKFwidG9vIGxvbmdcIikgfHwgbG93ZXJNc2cuaW5jbHVkZXMoXCJ0b28gbGFyZ2VcIikgfHwgbG93ZXJNc2cuaW5jbHVkZXMoXCJleGNlZWRzXCIpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzaG9ydDogXCLQn9GA0LXQstGL0YjQtdC9INC70LjQvNC40YIg0YHQuNC80LLQvtC70L7QslwiLFxuICAgICAgICBmdWxsOiBcItCe0L/QuNGB0LDQvdC40LUsINGB0YLQuNC70Ywg0LjQu9C4INGC0LXQutGB0YIg0L/QtdGB0L3QuCDRgdC70LjRiNC60L7QvCDQtNC70LjQvdC90YvQtS4g0KHQvtC60YDQsNGC0LjRgtC1INGC0LXQutGB0YIg0Lgg0L/QvtC/0YDQvtCx0YPQudGC0LUg0YHQvdC+0LLQsC5cIlxuICAgICAgfTtcbiAgICB9XG4gICAgXG4gICAgLy8gQ3JlZGl0cyBpc3N1ZXNcbiAgICBpZiAobG93ZXJNc2cuaW5jbHVkZXMoXCJjcmVkaXRcIikgfHwgbG93ZXJNc2cuaW5jbHVkZXMoXCJiYWxhbmNlXCIpIHx8IGxvd2VyTXNnLmluY2x1ZGVzKFwiaW5zdWZmaWNpZW50XCIpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzaG9ydDogXCLQndC10LTQvtGB0YLQsNGC0L7Rh9C90L4g0LrRgNC10LTQuNGC0L7QsiBTdW5vXCIsXG4gICAgICAgIGZ1bGw6IFwi0J3QsCDQsNC60LrQsNGD0L3RgtC1IFN1bm8g0L3QtdC00L7RgdGC0LDRgtC+0YfQvdC+INC60YDQtdC00LjRgtC+0LIg0LTQu9GPINCz0LXQvdC10YDQsNGG0LjQuC4g0J7QsdGA0LDRgtC40YLQtdGB0Ywg0LIg0L/QvtC00LTQtdGA0LbQutGDLlwiXG4gICAgICB9O1xuICAgIH1cbiAgfVxuXG4gIC8vIEZhbGxiYWNrIHRvIGNvZGUtYmFzZWQgbWVzc2FnZXNcbiAgY29uc3QgZXJyb3JNZXNzYWdlczogUmVjb3JkPG51bWJlciwgeyBzaG9ydDogc3RyaW5nOyBmdWxsOiBzdHJpbmcgfT4gPSB7XG4gICAgNDAwOiB7XG4gICAgICBzaG9ydDogXCLQndC10LLQtdGA0L3Ri9C1INC/0LDRgNCw0LzQtdGC0YDRiyDQt9Cw0L/RgNC+0YHQsFwiLFxuICAgICAgZnVsbDogXCLQn9Cw0YDQsNC80LXRgtGA0Ysg0LPQtdC90LXRgNCw0YbQuNC4INC90LXQutC+0YDRgNC10LrRgtC90YsuINCf0YDQvtCy0LXRgNGM0YLQtSDQstCy0LXQtNGR0L3QvdGL0LUg0LTQsNC90L3Ri9C1INC4INC/0L7Qv9GA0L7QsdGD0LnRgtC1INGB0L3QvtCy0LAuXCJcbiAgICB9LFxuICAgIDQwMToge1xuICAgICAgc2hvcnQ6IFwi0J7RiNC40LHQutCwINCw0LLRgtC+0YDQuNC30LDRhtC40LhcIixcbiAgICAgIGZ1bGw6IFwi0J/RgNC+0LHQu9C10LzQsCDRgSDQsNCy0YLQvtGA0LjQt9Cw0YbQuNC10Lkg0LIg0YHQtdGA0LLQuNGB0LUgU3Vuby4g0J7QsdGA0LDRgtC40YLQtdGB0Ywg0LIg0L/QvtC00LTQtdGA0LbQutGDLlwiXG4gICAgfSxcbiAgICA0MDM6IHtcbiAgICAgIHNob3J0OiBcItCa0L7QvdGC0LXQvdGCINC30LDQsdC70L7QutC40YDQvtCy0LDQvSDQvNC+0LTQtdGA0LDRhtC40LXQuVwiLFxuICAgICAgZnVsbDogXCLQktCw0Ygg0LfQsNC/0YDQvtGBINGB0L7QtNC10YDQttC40YIg0LfQsNC/0YDQtdGJ0ZHQvdC90YvQuSDQutC+0L3RgtC10L3RgiDQuNC70Lgg0L3QsNGA0YPRiNCw0LXRgiDQv9GA0LDQstC40LvQsCDQuNGB0L/QvtC70YzQt9C+0LLQsNC90LjRjyBTdW5vLiDQmNC30LzQtdC90LjRgtC1INGC0LXQutGB0YIg0LjQu9C4INC+0L/QuNGB0LDQvdC40LUuXCJcbiAgICB9LFxuICAgIDQwNDoge1xuICAgICAgc2hvcnQ6IFwi0KDQtdGB0YPRgNGBINC90LUg0L3QsNC50LTQtdC9XCIsXG4gICAgICBmdWxsOiBcItCX0LDQv9GA0LDRiNC40LLQsNC10LzRi9C5INGA0LXRgdGD0YDRgSDQvdC1INC90LDQudC00LXQvS4g0J/QvtC/0YDQvtCx0YPQudGC0LUg0LXRidGRINGA0LDQty5cIlxuICAgIH0sXG4gICAgNDA1OiB7XG4gICAgICBzaG9ydDogXCLQn9GA0LXQstGL0YjQtdC90LAg0YfQsNGB0YLQvtGC0LAg0LfQsNC/0YDQvtGB0L7QslwiLFxuICAgICAgZnVsbDogXCLQodC70LjRiNC60L7QvCDQvNC90L7Qs9C+INC30LDQv9GA0L7RgdC+0LIg0LogQVBJLiDQn9C+0LTQvtC20LTQuNGC0LUg0L3QtdGB0LrQvtC70YzQutC+INC80LjQvdGD0YIg0Lgg0L/QvtC/0YDQvtCx0YPQudGC0LUg0YHQvdC+0LLQsC5cIlxuICAgIH0sXG4gICAgNDEzOiB7XG4gICAgICBzaG9ydDogXCLQn9GA0LXQstGL0YjQtdC9INC70LjQvNC40YIg0YHQuNC80LLQvtC70L7QslwiLFxuICAgICAgZnVsbDogXCLQntC/0LjRgdCw0L3QuNC1LCDRgdGC0LjQu9GMINC40LvQuCDRgtC10LrRgdGCINC/0LXRgdC90Lgg0YHQu9C40YjQutC+0Lwg0LTQu9C40L3QvdGL0LUg0LTQu9GPINC+0LHRgNCw0LHQvtGC0LrQuC4g0KHQvtC60YDQsNGC0LjRgtC1INGC0LXQutGB0YIgKNC80LDQutGBLiB+MzAwMCDRgdC40LzQstC+0LvQvtCyINC00LvRjyBseXJpY3MsIH4yMDAg0LTQu9GPIHN0eWxlKSDQuCDQv9C+0L/RgNC+0LHRg9C50YLQtSDRgdC90L7QstCwLlwiXG4gICAgfSxcbiAgICA0Mjk6IHtcbiAgICAgIHNob3J0OiBcItCd0LXQtNC+0YHRgtCw0YLQvtGH0L3QviDQutGA0LXQtNC40YLQvtCyXCIsXG4gICAgICBmdWxsOiBcItCd0LAg0LDQutC60LDRg9C90YLQtSBTdW5vINC90LXQtNC+0YHRgtCw0YLQvtGH0L3QviDQutGA0LXQtNC40YLQvtCyINC00LvRjyDQs9C10L3QtdGA0LDRhtC40LguINCe0LHRgNCw0YLQuNGC0LXRgdGMINCyINC/0L7QtNC00LXRgNC20LrRgy5cIlxuICAgIH0sXG4gICAgNDU1OiB7XG4gICAgICBzaG9ydDogXCLQodC10YDQstC40YEg0L3QsCDQvtCx0YHQu9GD0LbQuNCy0LDQvdC40LhcIixcbiAgICAgIGZ1bGw6IFwi0KHQtdGA0LLQuNGBIFN1bm8g0L/RgNC+0YXQvtC00LjRgiDRgtC10YXQvdC40YfQtdGB0LrQvtC1INC+0LHRgdC70YPQttC40LLQsNC90LjQtS4g0J/QvtC/0YDQvtCx0YPQudGC0LUg0L/QvtC30LbQtS5cIlxuICAgIH0sXG4gICAgNTAwOiB7XG4gICAgICBzaG9ydDogXCLQktC90YPRgtGA0LXQvdC90Y/RjyDQvtGI0LjQsdC60LAg0YHQtdGA0LLQtdGA0LBcIixcbiAgICAgIGZ1bGw6IFwi0J/RgNC+0LjQt9C+0YjQu9CwINCy0L3Rg9GC0YDQtdC90L3Rj9GPINC+0YjQuNCx0LrQsCDQvdCwINGB0LXRgNCy0LXRgNC1IFN1bm8uINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC/0L7Qt9C20LUuXCJcbiAgICB9LFxuICAgIDUwMzoge1xuICAgICAgc2hvcnQ6IFwi0KHQtdGA0LLQuNGBINCy0YDQtdC80LXQvdC90L4g0L3QtdC00L7RgdGC0YPQv9C10L1cIixcbiAgICAgIGZ1bGw6IFwi0KHQtdGA0LLQuNGBIFN1bm8g0LLRgNC10LzQtdC90L3QviDQv9C10YDQtdCz0YDRg9C20LXQvSDQuNC70Lgg0L3QsCDQvtCx0YHQu9GD0LbQuNCy0LDQvdC40LguINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC/0L7Qt9C20LUuXCJcbiAgICB9XG4gIH07XG4gIFxuICBpZiAoZXJyb3JNZXNzYWdlc1tjb2RlXSkge1xuICAgIHJldHVybiBlcnJvck1lc3NhZ2VzW2NvZGVdO1xuICB9XG4gIFxuICByZXR1cm4ge1xuICAgIHNob3J0OiBg0J7RiNC40LHQutCwINCz0LXQvdC10YDQsNGG0LjQuCAo0LrQvtC0ICR7Y29kZX0pYCxcbiAgICBmdWxsOiBvcmlnaW5hbE1lc3NhZ2UgfHwgYNCf0YDQvtC40LfQvtGI0LvQsCDQvtGI0LjQsdC60LAg0L/RgNC4INCz0LXQvdC10YDQsNGG0LjQuC4g0JrQvtC0INC+0YjQuNCx0LrQuDogJHtjb2RlfS4g0J/QvtC/0YDQvtCx0YPQudGC0LUg0L/QvtC30LbQtSDQuNC70Lgg0L7QsdGA0LDRgtC40YLQtdGB0Ywg0LIg0L/QvtC00LTQtdGA0LbQutGDLmBcbiAgfTtcbn1cblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIC8vIFZlcmlmeSBjYWxsYmFjayBhdXRoZW50aWNpdHkgdXNpbmcgc2VjcmV0IHRva2VuXG4gICAgY29uc3QgY2FsbGJhY2tTZWNyZXQgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0NBTExCQUNLX1NFQ1JFVFwiKTtcbiAgICBpZiAoY2FsbGJhY2tTZWNyZXQpIHtcbiAgICAgIC8vIENoZWNrIGZvciBzZWNyZXQgaW4gaGVhZGVyIG9yIHF1ZXJ5IHBhcmFtZXRlclxuICAgICAgY29uc3QgdXJsID0gbmV3IFVSTChyZXEudXJsKTtcbiAgICAgIGNvbnN0IGhlYWRlclRva2VuID0gcmVxLmhlYWRlcnMuZ2V0KFwieC1jYWxsYmFjay1zZWNyZXRcIikgfHwgcmVxLmhlYWRlcnMuZ2V0KFwiYXV0aG9yaXphdGlvblwiKT8ucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgICBjb25zdCBxdWVyeVRva2VuID0gdXJsLnNlYXJjaFBhcmFtcy5nZXQoXCJzZWNyZXRcIik7XG4gICAgICBcbiAgICAgIGlmIChoZWFkZXJUb2tlbiAhPT0gY2FsbGJhY2tTZWNyZXQgJiYgcXVlcnlUb2tlbiAhPT0gY2FsbGJhY2tTZWNyZXQpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkludmFsaWQgY2FsbGJhY2sgc2VjcmV0IHByb3ZpZGVkXCIpO1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBjb25zb2xlLmxvZyhcIkNhbGxiYWNrIHNlY3JldCB2ZXJpZmllZCBzdWNjZXNzZnVsbHlcIik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnNvbGUud2FybihcIlNVTk9fQ0FMTEJBQ0tfU0VDUkVUIG5vdCBjb25maWd1cmVkIC0gY2FsbGJhY2sgdmVyaWZpY2F0aW9uIHNraXBwZWRcIik7XG4gICAgfVxuXG4gICAgY29uc3Qgc3VwYWJhc2VBZG1pbiA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSA/PyBcIlwiXG4gICAgKTtcblxuICAgIGNvbnN0IGNhbGxiYWNrRGF0YSA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJSZWNlaXZlZCBTdW5vIGNhbGxiYWNrOlwiLCBKU09OLnN0cmluZ2lmeShjYWxsYmFja0RhdGEpKTtcblxuICAgIC8vIEhhbmRsZSB0aGUgbmVzdGVkIGRhdGEgc3RydWN0dXJlIGZyb20gU3VubyBBUElcbiAgICAvLyBUaGUgc3RydWN0dXJlIGlzOiB7IGNvZGU6IDIwMCwgZGF0YTogeyBjYWxsYmFja1R5cGU6IFwiY29tcGxldGVcIiwgZGF0YTogWy4uLnRyYWNrc10sIHRhc2tfaWQ6IFwiLi4uXCIgfSwgbXNnOiBcIi4uLlwiIH1cbiAgICBjb25zdCB0cmFja3MgPSBjYWxsYmFja0RhdGE/LmRhdGE/LmRhdGEgfHwgY2FsbGJhY2tEYXRhPy5kYXRhIHx8IFtdO1xuICAgIGNvbnN0IHRhc2tJZCA9IGNhbGxiYWNrRGF0YT8uZGF0YT8udGFza19pZDtcbiAgICBjb25zdCBjYWxsYmFja1R5cGUgPSBjYWxsYmFja0RhdGE/LmRhdGE/LmNhbGxiYWNrVHlwZTtcbiAgICBjb25zdCByZXNwb25zZUNvZGUgPSBjYWxsYmFja0RhdGE/LmNvZGU7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gY2FsbGJhY2tEYXRhPy5tc2c7XG4gICAgXG4gICAgY29uc29sZS5sb2coYENhbGxiYWNrIHR5cGU6ICR7Y2FsbGJhY2tUeXBlfSwgVGFzayBJRDogJHt0YXNrSWR9LCBDb2RlOiAke3Jlc3BvbnNlQ29kZX0sIFRyYWNrcyBjb3VudDogJHt0cmFja3MubGVuZ3RofWApO1xuXG4gICAgLy8gSGFuZGxlIGZhaWxlZCBjYWxsYmFja3MgLSBjaGVjayBmb3IgZXJyb3IgY29kZXMgT1IgZXhwbGljaXQgZmFpbHVyZSB0eXBlc1xuICAgIC8vIFN1bm8gbWF5IHJldHVybiBjb2RlIDQxMyB3aXRoIGNhbGxiYWNrVHlwZSBcImNvbXBsZXRlXCIgd2hlbiBhdWRpbyBjYW4ndCBiZSBmZXRjaGVkXG4gICAgY29uc3QgaXNFcnJvciA9IHJlc3BvbnNlQ29kZSAhPT0gMjAwIHx8IFxuICAgICAgICAgICAgICAgICAgICBjYWxsYmFja1R5cGUgPT09IFwiZmFpbFwiIHx8IFxuICAgICAgICAgICAgICAgICAgICBjYWxsYmFja1R5cGUgPT09IFwiZXJyb3JcIiB8fCBcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2tUeXBlID09PSBcImZhaWxlZFwiO1xuICAgIFxuICAgIGlmIChpc0Vycm9yKSB7XG4gICAgICBjb25zb2xlLmxvZyhgUmVjZWl2ZWQgZXJyb3IgY2FsbGJhY2sgZm9yIHRhc2sgJHt0YXNrSWR9IC0gY29kZTogJHtyZXNwb25zZUNvZGV9LCB0eXBlOiAke2NhbGxiYWNrVHlwZX1gKTtcbiAgICAgIFxuICAgICAgLy8gR2V0IGh1bWFuLXJlYWRhYmxlIGVycm9yIG1lc3NhZ2VcbiAgICAgIGNvbnN0IGVycm9ySW5mbyA9IGdldFN1bm9FcnJvck1lc3NhZ2UocmVzcG9uc2VDb2RlIHx8IDUwMCwgZXJyb3JNZXNzYWdlIHx8IGNhbGxiYWNrRGF0YT8uZGF0YT8uZmFpbF9yZWFzb24pO1xuICAgICAgY29uc3QgZmFpbFJlYXNvbiA9IGVycm9ySW5mby5zaG9ydDtcbiAgICAgIFxuICAgICAgLy8gRmluZCB0cmFja3MgdGhhdCBtYXRjaCB0aGlzIHRhc2tfaWQgZmlyc3QsIHRoZW4gZmFsbCBiYWNrIHRvIHJlY2VudCBwZW5kaW5nIHRyYWNrc1xuICAgICAgbGV0IHRyYWNrc1RvRmFpbDogeyBpZDogc3RyaW5nOyB1c2VyX2lkOiBzdHJpbmcgfVtdID0gW107XG4gICAgICBcbiAgICAgIC8vIFRyeSB0byBmaW5kIHRyYWNrcyBieSB0YXNrSWQgaW4gZGVzY3JpcHRpb24gbWV0YWRhdGFcbiAgICAgIGlmICh0YXNrSWQpIHtcbiAgICAgICAgY29uc3QgeyBkYXRhOiB0YXNrVHJhY2tzIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAuc2VsZWN0KFwiaWQsIHVzZXJfaWQsIGRlc2NyaXB0aW9uXCIpXG4gICAgICAgICAgLmluKFwic3RhdHVzXCIsIFtcInByb2Nlc3NpbmdcIiwgXCJwZW5kaW5nXCJdKVxuICAgICAgICAgIC5pbGlrZShcImRlc2NyaXB0aW9uXCIsIGAlJHt0YXNrSWR9JWApXG4gICAgICAgICAgLmxpbWl0KDIpO1xuICAgICAgICBcbiAgICAgICAgaWYgKHRhc2tUcmFja3MgJiYgdGFza1RyYWNrcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgdHJhY2tzVG9GYWlsID0gdGFza1RyYWNrcztcbiAgICAgICAgICBjb25zb2xlLmxvZyhgRm91bmQgJHt0YXNrVHJhY2tzLmxlbmd0aH0gdHJhY2tzIG1hdGNoaW5nIHRhc2tfaWQgJHt0YXNrSWR9YCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIFxuICAgICAgLy8gRmFsbCBiYWNrIHRvIHJlY2VudCBwZW5kaW5nIHRyYWNrcyBpZiBubyB0YXNrIG1hdGNoXG4gICAgICBpZiAodHJhY2tzVG9GYWlsLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBjb25zdCB7IGRhdGE6IHBlbmRpbmdUcmFja3MgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgIC5zZWxlY3QoXCJpZCwgdXNlcl9pZFwiKVxuICAgICAgICAgIC5pbihcInN0YXR1c1wiLCBbXCJwcm9jZXNzaW5nXCIsIFwicGVuZGluZ1wiXSlcbiAgICAgICAgICAub3JkZXIoXCJjcmVhdGVkX2F0XCIsIHsgYXNjZW5kaW5nOiBmYWxzZSB9KVxuICAgICAgICAgIC5saW1pdCg1KTtcbiAgICAgIFxuICAgICAgICBpZiAocGVuZGluZ1RyYWNrcyAmJiBwZW5kaW5nVHJhY2tzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICB0cmFja3NUb0ZhaWwgPSBwZW5kaW5nVHJhY2tzO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBcbiAgICAgIGlmICh0cmFja3NUb0ZhaWwubGVuZ3RoID4gMCkge1xuICAgICAgICBmb3IgKGNvbnN0IHRyYWNrIG9mIHRyYWNrc1RvRmFpbCkge1xuICAgICAgICAgIGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLFxuICAgICAgICAgICAgICBlcnJvcl9tZXNzYWdlOiBmYWlsUmVhc29uLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5lcShcImlkXCIsIHRyYWNrLmlkKTtcbiAgICAgICAgICBcbiAgICAgICAgICAvLyBHZXQgZ2VuZXJhdGlvbiBsb2cgdG8gZmluZCBjb3N0XG4gICAgICAgICAgY29uc3QgeyBkYXRhOiBnZW5Mb2cgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgICAgIC5mcm9tKFwiZ2VuZXJhdGlvbl9sb2dzXCIpXG4gICAgICAgICAgICAuc2VsZWN0KFwiY29zdF9ydWJcIilcbiAgICAgICAgICAgIC5lcShcInRyYWNrX2lkXCIsIHRyYWNrLmlkKVxuICAgICAgICAgICAgLnNpbmdsZSgpO1xuICAgICAgICAgIFxuICAgICAgICAgIC8vIFJlZnVuZCDigr0gdG8gdXNlclxuICAgICAgICAgIGlmIChnZW5Mb2cgJiYgZ2VuTG9nLmNvc3RfcnViID4gMCkge1xuICAgICAgICAgICAgY29uc3QgeyBkYXRhOiBwcm9maWxlIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAgICAgLnNlbGVjdChcImJhbGFuY2VcIilcbiAgICAgICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB0cmFjay51c2VyX2lkKVxuICAgICAgICAgICAgICAuc2luZ2xlKCk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlmIChwcm9maWxlKSB7XG4gICAgICAgICAgICAgIGNvbnN0IG5ld0JhbGFuY2UgPSAocHJvZmlsZS5iYWxhbmNlIHx8IDApICsgZ2VuTG9nLmNvc3RfcnViO1xuICAgICAgICAgICAgICBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBuZXdCYWxhbmNlIH0pXG4gICAgICAgICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB0cmFjay51c2VyX2lkKTtcbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIC8vIExvZyByZWZ1bmQgdHJhbnNhY3Rpb25cbiAgICAgICAgICAgICAgYXdhaXQgc3VwYWJhc2VBZG1pbi5mcm9tKFwiYmFsYW5jZV90cmFuc2FjdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICB1c2VyX2lkOiB0cmFjay51c2VyX2lkLFxuICAgICAgICAgICAgICAgIGFtb3VudDogZ2VuTG9nLmNvc3RfcnViLFxuICAgICAgICAgICAgICAgIGJhbGFuY2VfYWZ0ZXI6IG5ld0JhbGFuY2UsXG4gICAgICAgICAgICAgICAgdHlwZTogXCJyZWZ1bmRcIixcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogYNCS0L7Qt9Cy0YDQsNGCINC30LAg0LPQtdC90LXRgNCw0YbQuNGOOiAke2ZhaWxSZWFzb259YCxcbiAgICAgICAgICAgICAgICByZWZlcmVuY2VfaWQ6IHRyYWNrLmlkLFxuICAgICAgICAgICAgICAgIHJlZmVyZW5jZV90eXBlOiBcInRyYWNrXCIsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coYFJlZnVuZGVkICR7Z2VuTG9nLmNvc3RfcnVifSDigr0gdG8gdXNlciAke3RyYWNrLnVzZXJfaWR9YCk7XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAvLyBDcmVhdGUgbm90aWZpY2F0aW9uIGZvciByZWZ1bmQgd2l0aCBlcnJvciBleHBsYW5hdGlvblxuICAgICAgICAgICAgICBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgICAgICAgLmZyb20oXCJub3RpZmljYXRpb25zXCIpXG4gICAgICAgICAgICAgICAgLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICB1c2VyX2lkOiB0cmFjay51c2VyX2lkLFxuICAgICAgICAgICAgICAgICAgdHlwZTogXCJyZWZ1bmRcIixcbiAgICAgICAgICAgICAgICAgIHRpdGxlOiBg0J7RiNC40LHQutCwOiAke2ZhaWxSZWFzb259YCxcbiAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGAke2Vycm9ySW5mby5mdWxsfVxcblxcbtCS0LDQvCDQstC+0LfQstGA0LDRidC10L3QviAke2dlbkxvZy5jb3N0X3J1Yn0g4oK9YCxcbiAgICAgICAgICAgICAgICAgIHRhcmdldF90eXBlOiBcInRyYWNrXCIsXG4gICAgICAgICAgICAgICAgICB0YXJnZXRfaWQ6IHRyYWNrLmlkLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBcbiAgICAgICAgICAvLyBVcGRhdGUgZ2VuZXJhdGlvbiBsb2cgc3RhdHVzIHRvIGZhaWxlZFxuICAgICAgICAgIGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgICAgIC5mcm9tKFwiZ2VuZXJhdGlvbl9sb2dzXCIpXG4gICAgICAgICAgICAudXBkYXRlKHsgc3RhdHVzOiBcImZhaWxlZFwiIH0pXG4gICAgICAgICAgICAuZXEoXCJ0cmFja19pZFwiLCB0cmFjay5pZCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5sb2coYE1hcmtlZCAke3RyYWNrc1RvRmFpbC5sZW5ndGh9IHRyYWNrcyBhcyBmYWlsZWQgd2l0aCByZWZ1bmRzYCk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgcmVjZWl2ZWQ6IHRydWUsIG1lc3NhZ2U6IFwiRmFpbHVyZSBjYWxsYmFjayBwcm9jZXNzZWQgd2l0aCByZWZ1bmRzXCIgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGlmICghQXJyYXkuaXNBcnJheSh0cmFja3MpIHx8IHRyYWNrcy5sZW5ndGggPT09IDApIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiTm8gdHJhY2tzIGluIGNhbGxiYWNrIGRhdGFcIik7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHJlY2VpdmVkOiB0cnVlLCBtZXNzYWdlOiBcIk5vIHRyYWNrcyB0byBwcm9jZXNzXCIgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIFByb2Nlc3MgXCJjb21wbGV0ZVwiIChhbGwgdHJhY2tzIHJlYWR5KSBhbmQgXCJmaXJzdFwiIChmaXJzdCB0cmFjayByZWFkeSkgY2FsbGJhY2tzXG4gICAgLy8gU2tpcCBcInRleHRcIiBjYWxsYmFja3MgKG9ubHkgbHlyaWNzIGdlbmVyYXRlZCwgbm8gYXVkaW8geWV0KVxuICAgIGlmIChjYWxsYmFja1R5cGUgIT09IFwiY29tcGxldGVcIiAmJiBjYWxsYmFja1R5cGUgIT09IFwiZmlyc3RcIikge1xuICAgICAgY29uc29sZS5sb2coYFNraXBwaW5nIGNhbGxiYWNrIHR5cGU6ICR7Y2FsbGJhY2tUeXBlfSAod2FpdGluZyBmb3IgYXVkaW8pYCk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHJlY2VpdmVkOiB0cnVlLCBtZXNzYWdlOiBgQ2FsbGJhY2sgdHlwZSAke2NhbGxiYWNrVHlwZX0gYWNrbm93bGVkZ2VkYCB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IGlzUGFydGlhbENhbGxiYWNrID0gY2FsbGJhY2tUeXBlID09PSBcImZpcnN0XCI7XG4gICAgaWYgKGlzUGFydGlhbENhbGxiYWNrKSB7XG4gICAgICBjb25zb2xlLmxvZyhgUHJvY2Vzc2luZyBwYXJ0aWFsIGNhbGxiYWNrIChmaXJzdCkg4oCUIHdpbGwgb25seSB1cGRhdGUgdHJhY2tzIHRoYXQgaGF2ZSBhdWRpb191cmxgKTtcbiAgICB9XG5cbiAgICAvLyBDUklUSUNBTDogRmlyc3QsIGZpbmQgdHJhY2tzIHRoYXQgbWF0Y2ggdGhpcyBzcGVjaWZpYyB0YXNrX2lkXG4gICAgLy8gVGhpcyBwcmV2ZW50cyBjcm9zcy11c2VyIHRyYWNrIG1peGluZyB3aGVuIG11bHRpcGxlIGdlbmVyYXRpb25zIGFyZSBwZW5kaW5nXG4gICAgbGV0IG1hdGNoZWRUcmFja3M6IEFycmF5PHtcbiAgICAgIGlkOiBzdHJpbmc7XG4gICAgICB0aXRsZTogc3RyaW5nIHwgbnVsbDtcbiAgICAgIGRlc2NyaXB0aW9uOiBzdHJpbmcgfCBudWxsO1xuICAgICAgbHlyaWNzOiBzdHJpbmcgfCBudWxsO1xuICAgICAgdXNlcl9pZDogc3RyaW5nO1xuICAgICAgc3RhdHVzOiBzdHJpbmc7XG4gICAgfT4gPSBbXTtcblxuICAgIGlmICh0YXNrSWQpIHtcbiAgICAgIGNvbnN0IHsgZGF0YTogdGFza1RyYWNrcywgZXJyb3I6IHRhc2tGaW5kRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnNlbGVjdChcImlkLCB0aXRsZSwgZGVzY3JpcHRpb24sIGx5cmljcywgdXNlcl9pZCwgc3RhdHVzXCIpXG4gICAgICAgIC5pbihcInN0YXR1c1wiLCBbXCJwcm9jZXNzaW5nXCIsIFwicGVuZGluZ1wiXSlcbiAgICAgICAgLmlsaWtlKFwiZGVzY3JpcHRpb25cIiwgYCVbdGFza19pZDogJHt0YXNrSWR9XSVgKVxuICAgICAgICAub3JkZXIoXCJjcmVhdGVkX2F0XCIsIHsgYXNjZW5kaW5nOiB0cnVlIH0pXG4gICAgICAgIC5saW1pdCgyKTtcblxuICAgICAgaWYgKHRhc2tGaW5kRXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZpbmRpbmcgdHJhY2tzIGJ5IHRhc2tfaWQ6XCIsIHRhc2tGaW5kRXJyb3IpO1xuICAgICAgfSBlbHNlIGlmICh0YXNrVHJhY2tzICYmIHRhc2tUcmFja3MubGVuZ3RoID4gMCkge1xuICAgICAgICBtYXRjaGVkVHJhY2tzID0gdGFza1RyYWNrcztcbiAgICAgICAgY29uc29sZS5sb2coYEZvdW5kICR7dGFza1RyYWNrcy5sZW5ndGh9IHRyYWNrcyBtYXRjaGluZyB0YXNrX2lkICR7dGFza0lkfWApO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIElmIG5vIHRhc2tfaWQgbWF0Y2gsIGxvZyBhIHdhcm5pbmcgYnV0IERPIE5PVCBmYWxsIGJhY2sgdG8gcmFuZG9tIHBlbmRpbmcgdHJhY2tzXG4gICAgLy8gVGhpcyBpcyBjcml0aWNhbCB0byBwcmV2ZW50IGNyb3NzLXVzZXIgdHJhY2sgbWl4aW5nXG4gICAgaWYgKG1hdGNoZWRUcmFja3MubGVuZ3RoID09PSAwKSB7XG4gICAgICBjb25zb2xlLndhcm4oYE5vIHRyYWNrcyBmb3VuZCBtYXRjaGluZyB0YXNrX2lkICR7dGFza0lkfS4gQ2FsbGJhY2sgd2lsbCBiZSBpZ25vcmVkIHRvIHByZXZlbnQgY3Jvc3MtdXNlciBtaXhpbmcuYCk7XG4gICAgICBjb25zb2xlLndhcm4oYENhbGxiYWNrIGRhdGEgaGFkICR7dHJhY2tzLmxlbmd0aH0gYXVkaW8gdHJhY2tzLCBidXQgbm8gbWF0Y2hpbmcgREIgcmVjb3Jkcy5gKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgcmVjZWl2ZWQ6IHRydWUsIFxuICAgICAgICAgIHdhcm5pbmc6IFwiTm8gbWF0Y2hpbmcgdHJhY2tzIGZvdW5kIGZvciB0YXNrX2lkXCIsIFxuICAgICAgICAgIHRhc2tfaWQ6IHRhc2tJZCBcbiAgICAgICAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGxldCB1cGRhdGVkQ291bnQgPSAwO1xuXG4gICAgLy8gQ3JlYXRlIGEgY29weSBvZiBtYXRjaGVkIHRyYWNrcyBmb3Igc2FmZSBpdGVyYXRpb24gKGF2b2lkIG11dGF0aW9uIGlzc3VlcylcbiAgICBjb25zdCB0cmFja3NUb1Byb2Nlc3MgPSBbLi4ubWF0Y2hlZFRyYWNrc107XG4gICAgLy8gVHJhY2sgd2hpY2ggaW5kaWNlcyBoYXZlIGJlZW4gcHJvY2Vzc2VkXG4gICAgY29uc3QgcHJvY2Vzc2VkSW5kaWNlcyA9IG5ldyBTZXQ8bnVtYmVyPigpO1xuXG4gICAgLy8gU3VubyByZXR1cm5zIDIgdmVyc2lvbnMgcGVyIGdlbmVyYXRpb24gcmVxdWVzdFxuICAgIC8vIE1hdGNoIHRoZW0gdG8gb3VyIHYxL3YyIHRyYWNrIHBhaXJzIGJ5IG9yZGVyIChmaXJzdCBTdW5vIHJlc3VsdCAtPiB2MSwgc2Vjb25kIC0+IHYyKVxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdHJhY2tzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCB0cmFjayA9IHRyYWNrc1tpXTtcbiAgICAgIGNvbnN0IHsgXG4gICAgICAgIGlkOiBzdW5vQXVkaW9JZCxcbiAgICAgICAgYXVkaW9fdXJsLCBcbiAgICAgICAgc291cmNlX2F1ZGlvX3VybCxcbiAgICAgICAgc3RyZWFtX2F1ZGlvX3VybCxcbiAgICAgICAgaW1hZ2VfdXJsLFxuICAgICAgICBzb3VyY2VfaW1hZ2VfdXJsLFxuICAgICAgICBkdXJhdGlvbiwgXG4gICAgICAgIHRpdGxlOiBzdW5vVGl0bGUsXG4gICAgICB9ID0gdHJhY2s7XG5cbiAgICAgIGNvbnN0IGF1ZGlvVXJsID0gYXVkaW9fdXJsIHx8IHNvdXJjZV9hdWRpb191cmwgfHwgc3RyZWFtX2F1ZGlvX3VybDtcbiAgICAgIGNvbnN0IGNvdmVyVXJsID0gaW1hZ2VfdXJsIHx8IHNvdXJjZV9pbWFnZV91cmw7XG4gICAgICBcbiAgICAgIGlmICghYXVkaW9VcmwpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJUcmFjayBoYXMgbm8gYXVkaW8gVVJMLCBza2lwcGluZ1wiKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIC8vIE1hdGNoIGJ5IGluZGV4OiBmaXJzdCBTdW5vIHJlc3VsdCAtPiBmaXJzdCBtYXRjaGVkIHRyYWNrICh2MSksIHNlY29uZCAtPiBzZWNvbmQgKHYyKVxuICAgICAgLy8gVXNlIHRoZSBvcmlnaW5hbCBhcnJheSBjb3B5LCBub3QgdGhlIG11dGF0ZWQgb25lXG4gICAgICBjb25zdCB0cmFja1RvVXBkYXRlID0gdHJhY2tzVG9Qcm9jZXNzW2ldO1xuICAgICAgXG4gICAgICAvLyBTYWZldHkgY2hlY2s6IGVuc3VyZSB3ZSdyZSB1cGRhdGluZyB0aGUgcmlnaHQgdXNlcidzIHRyYWNrXG4gICAgICBpZiAoIXRyYWNrVG9VcGRhdGUpIHtcbiAgICAgICAgY29uc29sZS5sb2coYE5vIG1hdGNoZWQgdHJhY2sgYXQgaW5kZXggJHtpfSBmb3IgU3VubyByZXN1bHQ6ICR7c3Vub1RpdGxlfWApO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgLy8gU2tpcCBpZiBhbHJlYWR5IHByb2Nlc3NlZCAoc2hvdWxkbid0IGhhcHBlbiwgYnV0IGJlIHNhZmUpXG4gICAgICBpZiAocHJvY2Vzc2VkSW5kaWNlcy5oYXMoaSkpIHtcbiAgICAgICAgY29uc29sZS5sb2coYFRyYWNrIGF0IGluZGV4ICR7aX0gYWxyZWFkeSBwcm9jZXNzZWQsIHNraXBwaW5nYCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgXG4gICAgICBwcm9jZXNzZWRJbmRpY2VzLmFkZChpKTtcbiAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGluZyB0cmFjayAke3RyYWNrVG9VcGRhdGUuaWR9ICgke3RyYWNrVG9VcGRhdGUudGl0bGV9KSB3aXRoIGF1ZGlvOiAke2F1ZGlvVXJsfWApO1xuICAgICAgXG4gICAgICAvLyBDb3B5IGZpbGVzIHRvIFN1cGFiYXNlIFN0b3JhZ2UgZm9yIHBlcm1hbmVudCBzdG9yYWdlXG4gICAgICBsZXQgZmluYWxBdWRpb1VybCA9IGF1ZGlvVXJsO1xuICAgICAgbGV0IGZpbmFsQ292ZXJVcmwgPSBjb3ZlclVybDtcbiAgICAgIFxuICAgICAgLy8gQ29weSBhdWRpbyBmaWxlIHRvIFN0b3JhZ2VcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGF1ZGlvRmlsZU5hbWUgPSBgJHt0cmFja1RvVXBkYXRlLmlkfS5tcDNgO1xuICAgICAgICBjb25zdCBzdG9yZWRBdWRpb1VybCA9IGF3YWl0IGNvcHlGaWxlVG9TdG9yYWdlKFxuICAgICAgICAgIHN1cGFiYXNlQWRtaW4sXG4gICAgICAgICAgYXVkaW9VcmwsXG4gICAgICAgICAgXCJ0cmFja3NcIixcbiAgICAgICAgICBgYXVkaW8vJHthdWRpb0ZpbGVOYW1lfWBcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKHN0b3JlZEF1ZGlvVXJsKSB7XG4gICAgICAgICAgZmluYWxBdWRpb1VybCA9IHN0b3JlZEF1ZGlvVXJsO1xuICAgICAgICAgIGNvbnNvbGUubG9nKGBBdWRpbyBjb3BpZWQgdG8gc3RvcmFnZTogJHtmaW5hbEF1ZGlvVXJsfWApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnNvbGUubG9nKGBGYWlsZWQgdG8gY29weSBhdWRpbywgdXNpbmcgb3JpZ2luYWwgVVJMYCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGF1ZGlvRXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNvcHlpbmcgYXVkaW86YCwgYXVkaW9FcnIpO1xuICAgICAgfVxuICAgICAgXG4gICAgICAvLyBDb3B5IGNvdmVyIGltYWdlIHRvIFN0b3JhZ2VcbiAgICAgIGlmIChjb3ZlclVybCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGNvdmVyRmlsZU5hbWUgPSBgJHt0cmFja1RvVXBkYXRlLmlkfS5qcGdgO1xuICAgICAgICAgIGNvbnN0IHN0b3JlZENvdmVyVXJsID0gYXdhaXQgY29weUZpbGVUb1N0b3JhZ2UoXG4gICAgICAgICAgICBzdXBhYmFzZUFkbWluLFxuICAgICAgICAgICAgY292ZXJVcmwsXG4gICAgICAgICAgICBcInRyYWNrc1wiLFxuICAgICAgICAgICAgYGNvdmVycy8ke2NvdmVyRmlsZU5hbWV9YFxuICAgICAgICAgICk7XG4gICAgICAgICAgaWYgKHN0b3JlZENvdmVyVXJsKSB7XG4gICAgICAgICAgICBmaW5hbENvdmVyVXJsID0gc3RvcmVkQ292ZXJVcmw7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgQ292ZXIgY29waWVkIHRvIHN0b3JhZ2U6ICR7ZmluYWxDb3ZlclVybH1gKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYEZhaWxlZCB0byBjb3B5IGNvdmVyLCB1c2luZyBvcmlnaW5hbCBVUkxgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGNvdmVyRXJyKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY29weWluZyBjb3ZlcjpgLCBjb3ZlckVycik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIFxuICAgICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgYXVkaW9fdXJsOiBmaW5hbEF1ZGlvVXJsLFxuICAgICAgICAgIGNvdmVyX3VybDogZmluYWxDb3ZlclVybCB8fCBudWxsLFxuICAgICAgICAgIGR1cmF0aW9uOiBkdXJhdGlvbiA/IE1hdGgucm91bmQoZHVyYXRpb24pIDogbnVsbCxcbiAgICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgLy8gU3RvcmUgU3VubyBhdWRpbyBJRCBmb3IgcGVyc29uYSBjcmVhdGlvblxuICAgICAgICAgIHN1bm9fYXVkaW9faWQ6IHN1bm9BdWRpb0lkIHx8IG51bGwsXG4gICAgICAgICAgLy8gU3RvcmUgc3Vub190YXNrX2lkIGluIGRlc2NyaXB0aW9uIGZvciByZWZlcmVuY2UgKGFwcGVuZCB0byBleGlzdGluZylcbiAgICAgICAgICBkZXNjcmlwdGlvbjogdHJhY2tUb1VwZGF0ZS5kZXNjcmlwdGlvbiBcbiAgICAgICAgICAgID8gYCR7dHJhY2tUb1VwZGF0ZS5kZXNjcmlwdGlvbn1cXG5cXG5bdGFza19pZDogJHt0YXNrSWR9XWBcbiAgICAgICAgICAgIDogYFt0YXNrX2lkOiAke3Rhc2tJZH1dYCxcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tUb1VwZGF0ZS5pZCk7XG5cbiAgICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgdHJhY2s6XCIsIHVwZGF0ZUVycm9yKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBUcmFjayAke3RyYWNrVG9VcGRhdGUuaWR9IHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IHdpdGggU3RvcmFnZSBVUkxzYCk7XG4gICAgICAgIHVwZGF0ZWRDb3VudCsrO1xuXG4gICAgICAgIC8vIFVwZGF0ZSBnZW5lcmF0aW9uIGxvZyBzdGF0dXNcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAgIC5mcm9tKFwiZ2VuZXJhdGlvbl9sb2dzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJjb21wbGV0ZWRcIiB9KVxuICAgICAgICAgIC5lcShcInRyYWNrX2lkXCIsIHRyYWNrVG9VcGRhdGUuaWQpO1xuXG5cbiAgICAgICAgLy8gUHJvY2VzcyBhZGRvbiBzZXJ2aWNlcyBmb3IgdGhpcyB0cmFjayAocGFzcyB0YXNrSWQgYW5kIGF1ZGlvSWQgZm9yIFN1bm8gdmlkZW8gZ2VuZXJhdGlvbilcbiAgICAgICAgYXdhaXQgcHJvY2Vzc1RyYWNrQWRkb25zKHN1cGFiYXNlQWRtaW4sIHRyYWNrVG9VcGRhdGUuaWQsIHRyYWNrVG9VcGRhdGUudGl0bGUgfHwgXCJVbnRpdGxlZFwiLCBmaW5hbENvdmVyVXJsLCBmaW5hbEF1ZGlvVXJsLCB0YXNrSWQsIHN1bm9BdWRpb0lkKTtcblxuICAgICAgICAvLyBBSSBDbGFzc2lmaWNhdGlvbiAtIHJ1biBpbiBiYWNrZ3JvdW5kIHRvIG5vdCBibG9jayByZXNwb25zZVxuICAgICAgICAvLyBFeHRyYWN0IHN0eWxlIGZyb20gdHJhY2sgZGVzY3JpcHRpb24gKGJlZm9yZSB0YXNrX2lkIHdhcyBhcHBlbmRlZClcbiAgICAgICAgY29uc3Qgb3JpZ2luYWxEZXNjcmlwdGlvbiA9IHRyYWNrVG9VcGRhdGUuZGVzY3JpcHRpb24/LnJlcGxhY2UoL1xcblxcblxcW3Rhc2tfaWQ6LipcXF0kLywgXCJcIikgfHwgbnVsbDtcbiAgICAgICAgY29uc3QgdHJhY2tMeXJpY3MgPSB0cmFja1RvVXBkYXRlLmx5cmljcyB8fCBudWxsO1xuICAgICAgICBcbiAgICAgICAgcnVuSW5CYWNrZ3JvdW5kKFxuICAgICAgICAgIGBjbGFzc2lmeVRyYWNrLSR7dHJhY2tUb1VwZGF0ZS5pZH1gLFxuICAgICAgICAgIGNsYXNzaWZ5VHJhY2tXaXRoQUkoc3VwYWJhc2VBZG1pbiwgdHJhY2tUb1VwZGF0ZS5pZCwgb3JpZ2luYWxEZXNjcmlwdGlvbiwgdHJhY2tMeXJpY3MpXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8g4pSA4pSA4pSAIFRyaWdnZXIgU3VubyBDb3ZlciBHZW5lcmF0aW9uIChiYWNrZ3JvdW5kKSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICAvLyBBZnRlciBhbGwgbXVzaWMgdHJhY2tzIGFyZSB1cGRhdGVkLCByZXF1ZXN0IHBlcnNvbmFsaXplZCBjb3ZlciBhcnRcbiAgICAvLyBUaGlzIHJ1bnMgaW4gYmFja2dyb3VuZCBzbyB3ZSBkb24ndCBkZWxheSB0aGUgY2FsbGJhY2sgcmVzcG9uc2VcbiAgICAvLyBPbmx5IHRyaWdnZXIgb24gXCJjb21wbGV0ZVwiIGNhbGxiYWNrIChub3QgXCJmaXJzdFwiKSB0byBhdm9pZCBwcmVtYXR1cmUgY292ZXIgZ2VuZXJhdGlvblxuICAgIGlmICh1cGRhdGVkQ291bnQgPiAwICYmIHRhc2tJZCAmJiAhaXNQYXJ0aWFsQ2FsbGJhY2spIHtcbiAgICAgIGNvbnN0IHRyYWNrSWRzRm9yQ292ZXIgPSB0cmFja3NUb1Byb2Nlc3NcbiAgICAgICAgLmZpbHRlcih0ID0+IHByb2Nlc3NlZEluZGljZXMuaGFzKHRyYWNrc1RvUHJvY2Vzcy5pbmRleE9mKHQpKSlcbiAgICAgICAgLm1hcCh0ID0+IHQuaWQpO1xuXG4gICAgICBpZiAodHJhY2tJZHNGb3JDb3Zlci5sZW5ndGggPiAwKSB7XG4gICAgICAgIHJ1bkluQmFja2dyb3VuZChcbiAgICAgICAgICBgY292ZXJHZW5lcmF0aW9uLSR7dGFza0lkfWAsXG4gICAgICAgICAgdHJpZ2dlckNvdmVyR2VuZXJhdGlvbihzdXBhYmFzZUFkbWluLCB0YXNrSWQsIHRyYWNrSWRzRm9yQ292ZXIpXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSwgdXBkYXRlZDogdXBkYXRlZENvdW50IH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIHN1bm8tY2FsbGJhY2s6XCIsIGVycm9yKTtcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBlcnJvck1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBQ25GLFNBQVMsWUFBWSxRQUF3Qix5Q0FBeUM7QUFFdEYsbURBQW1EO0FBQ25ELCtEQUErRDtBQUMvRCxTQUFTLGdCQUFnQixRQUFnQixFQUFFLE9BQXlCO0VBQ2xFLFFBQVEsS0FBSyxDQUFDLENBQUEsTUFBTyxRQUFRLEtBQUssQ0FBQyxDQUFDLGFBQWEsRUFBRSxTQUFTLFFBQVEsQ0FBQyxFQUFFO0FBQ3pFO0FBRUEsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxrRUFBa0U7QUFDbEUsZUFBZSxrQkFDYixhQUE2QixFQUM3QixXQUFtQixFQUNuQixNQUFjLEVBQ2QsUUFBZ0I7RUFFaEIsSUFBSTtJQUNGLFFBQVEsR0FBRyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsWUFBWSxDQUFDO0lBRW5ELE1BQU0sV0FBVyxNQUFNLE1BQU07SUFDN0IsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLFFBQVEsS0FBSyxDQUFDLENBQUMsb0JBQW9CLEVBQUUsU0FBUyxNQUFNLENBQUMsQ0FBQyxFQUFFLFNBQVMsVUFBVSxDQUFDLENBQUM7TUFDN0UsT0FBTztJQUNUO0lBRUEsTUFBTSxPQUFPLE1BQU0sU0FBUyxJQUFJO0lBQ2hDLE1BQU0sY0FBYyxNQUFNLEtBQUssV0FBVztJQUMxQyxNQUFNLGFBQWEsSUFBSSxXQUFXO0lBRWxDLFFBQVEsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLFdBQVcsTUFBTSxDQUFDLHFCQUFxQixFQUFFLE9BQU8sQ0FBQyxFQUFFLFNBQVMsQ0FBQztJQUV2RixNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLGNBQWMsT0FBTyxDQUN2RCxJQUFJLENBQUMsUUFDTCxNQUFNLENBQUMsVUFBVSxZQUFZO01BQzVCLGFBQWEsS0FBSyxJQUFJLElBQUk7TUFDMUIsUUFBUTtJQUNWO0lBRUYsSUFBSSxhQUFhO01BQ2YsUUFBUSxLQUFLLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRTtNQUMvQixPQUFPO0lBQ1Q7SUFFQSx1RkFBdUY7SUFDdkYsTUFBTSxVQUFVLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxlQUFlO0lBQzVDLE1BQU0sWUFBWSxDQUFDLEVBQUUsUUFBUSwwQkFBMEIsRUFBRSxPQUFPLENBQUMsRUFBRSxTQUFTLENBQUM7SUFFN0UsUUFBUSxHQUFHLENBQUMsQ0FBQyw0QkFBNEIsRUFBRSxVQUFVLENBQUM7SUFDdEQsT0FBTztFQUVULEVBQUUsT0FBTyxLQUFLO0lBQ1osUUFBUSxLQUFLLENBQUMsQ0FBQyw4QkFBOEIsQ0FBQyxFQUFFO0lBQ2hELE9BQU87RUFDVDtBQUNGO0FBRUEsd0RBQXdEO0FBQ3hELE1BQU0sMEJBQTBCO0FBRWhDLG9GQUFvRjtBQUNwRixpQ0FBaUM7QUFDakMsZUFBZSxvQkFDYixhQUE2QixFQUM3QixPQUFlLEVBQ2YsS0FBb0IsRUFDcEIsTUFBcUI7RUFFckIsSUFBSTtJQUNGLFFBQVEsR0FBRyxDQUFDLENBQUMscUNBQXFDLEVBQUUsUUFBUSxDQUFDO0lBRTdELE1BQU0sZ0JBQWdCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsZUFBZTtNQUNsQixRQUFRLEtBQUssQ0FBQztNQUNkO0lBQ0Y7SUFFQSw0Q0FBNEM7SUFDNUMsTUFBTSxDQUFDLFdBQVcsZUFBZSxjQUFjLGdCQUFnQixHQUFHLE1BQU0sUUFBUSxHQUFHLENBQUM7TUFDbEYsY0FBYyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQUMscUJBQXFCLEtBQUssQ0FBQztNQUMvRCxjQUFjLElBQUksQ0FBQyxlQUFlLE1BQU0sQ0FBQyxrQ0FBa0MsRUFBRSxDQUFDLGFBQWEsTUFBTSxLQUFLLENBQUM7TUFDdkcsY0FBYyxJQUFJLENBQUMsYUFBYSxNQUFNLENBQUMseUJBQXlCLEVBQUUsQ0FBQyxhQUFhLE1BQU0sS0FBSyxDQUFDO01BQzVGLGNBQWMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUMseUJBQXlCLEVBQUUsQ0FBQyxhQUFhLE1BQU0sS0FBSyxDQUFDO0tBQ2pHO0lBRUQsTUFBTSxTQUFTLFVBQVUsSUFBSSxJQUFJLEVBQUU7SUFDbkMsTUFBTSxhQUFhLGNBQWMsSUFBSSxJQUFJLEVBQUU7SUFDM0MsTUFBTSxZQUFZLGFBQWEsSUFBSSxJQUFJLEVBQUU7SUFDekMsTUFBTSxlQUFlLGdCQUFnQixJQUFJLElBQUksRUFBRTtJQUUvQyxJQUFJLE9BQU8sTUFBTSxLQUFLLEdBQUc7TUFDdkIsUUFBUSxHQUFHLENBQUM7TUFDWjtJQUNGO0lBRUEsa0NBQWtDO0lBQ2xDLE1BQU0sYUFBYSxPQUFPLEdBQUcsQ0FBQyxDQUFBLElBQUssQ0FBQyxPQUFPLEVBQUUsRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUM7SUFDN0YsTUFBTSxpQkFBaUIsV0FBVyxHQUFHLENBQUMsQ0FBQSxJQUFLLENBQUMsT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLEVBQUUsV0FBVyxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUM7SUFDbEosTUFBTSxnQkFBZ0IsVUFBVSxNQUFNLEdBQUcsSUFDckMsVUFBVSxHQUFHLENBQUMsQ0FBQSxJQUFLLENBQUMsT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRSxXQUFXLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUMzRztJQUNKLE1BQU0sbUJBQW1CLGFBQWEsTUFBTSxHQUFHLElBQzNDLGFBQWEsR0FBRyxDQUFDLENBQUEsSUFBSyxDQUFDLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUUsV0FBVyxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsUUFDOUc7SUFFSixNQUFNLFNBQVMsQ0FBQzs7OztBQUlwQixFQUFFLFdBQVc7OztBQUdiLEVBQUUsZUFBZTs7O0FBR2pCLEVBQUUsY0FBYzs7O0FBR2hCLEVBQUUsaUJBQWlCOzs7YUFHTixFQUFFLFNBQVMsWUFBWTtRQUM1QixFQUFFLFNBQVMsT0FBTyxTQUFTLENBQUMsR0FBRyxRQUFRLDRCQUE0Qjs7Ozs7Ozs7Ozs2R0FVa0MsQ0FBQztJQUUxRyxNQUFNLFNBQVMsQ0FBQyxtREFBbUQsRUFBRSx3QkFBd0Isb0JBQW9CLENBQUM7SUFFbEgsTUFBTSxXQUFXLE1BQU0sTUFBTSxRQUFRO01BQ25DLFFBQVE7TUFDUixTQUFTO1FBQ1AsZUFBZSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUM7UUFDeEMsZ0JBQWdCO1FBQ2hCLGtCQUFrQjtNQUNwQjtNQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7UUFDbkIsT0FBTztRQUNQLFVBQVU7VUFDUjtZQUFFLE1BQU07WUFBVSxTQUFTO1VBQXFEO1VBQ2hGO1lBQUUsTUFBTTtZQUFRLFNBQVM7VUFBTztTQUNqQztRQUNELGFBQWE7TUFDZjtJQUNGO0lBRUEsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLFFBQVEsS0FBSyxDQUFDLENBQUMsMEJBQTBCLEVBQUUsU0FBUyxNQUFNLENBQUMsQ0FBQztNQUM1RDtJQUNGO0lBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0lBQ2xDLE1BQU0sVUFBVSxPQUFPLE9BQU8sRUFBRSxDQUFDLEVBQUUsRUFBRSxTQUFTO0lBRTlDLElBQUksQ0FBQyxTQUFTO01BQ1osUUFBUSxLQUFLLENBQUM7TUFDZDtJQUNGO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyw0QkFBNEIsRUFBRSxRQUFRLENBQUM7SUFFcEQsMERBQTBEO0lBQzFELElBQUk7SUFDSixJQUFJO01BQ0YsTUFBTSxZQUFZLFFBQVEsS0FBSyxDQUFDO01BQ2hDLElBQUksV0FBVztRQUNiLGlCQUFpQixLQUFLLEtBQUssQ0FBQyxTQUFTLENBQUMsRUFBRTtNQUMxQyxPQUFPO1FBQ0wsaUJBQWlCLEtBQUssS0FBSyxDQUFDO01BQzlCO0lBQ0YsRUFBRSxPQUFPLFVBQVU7TUFDakIsUUFBUSxLQUFLLENBQUMsc0NBQXNDO01BQ3BEO0lBQ0Y7SUFFQSxpQ0FBaUM7SUFDakMsTUFBTSxlQUFlLE9BQU8sSUFBSSxDQUFDLENBQUEsSUFBSyxFQUFFLEVBQUUsS0FBSyxlQUFlLFFBQVEsR0FBRyxNQUFNO0lBQy9FLE1BQU0sbUJBQW1CLFdBQVcsSUFBSSxDQUFDLENBQUEsSUFBSyxFQUFFLEVBQUUsS0FBSyxlQUFlLGFBQWEsR0FBRyxNQUFNO0lBQzVGLE1BQU0sa0JBQWtCLGVBQWUsV0FBVyxHQUM5QyxVQUFVLElBQUksQ0FBQyxDQUFBLElBQUssRUFBRSxFQUFFLEtBQUssZUFBZSxXQUFXLEdBQUcsTUFBTSxPQUNoRTtJQUNKLE1BQU0scUJBQXFCLGVBQWUsZUFBZSxHQUNyRCxhQUFhLElBQUksQ0FBQyxDQUFBLElBQUssRUFBRSxFQUFFLEtBQUssZUFBZSxlQUFlLEdBQUcsTUFBTSxPQUN2RTtJQUVKLG1DQUFtQztJQUNuQyxNQUFNLGFBQTRDLENBQUM7SUFDbkQsSUFBSSxjQUFjLFdBQVcsUUFBUSxHQUFHO0lBQ3hDLElBQUksa0JBQWtCLFdBQVcsYUFBYSxHQUFHO0lBQ2pELElBQUksaUJBQWlCLFdBQVcsV0FBVyxHQUFHO0lBQzlDLElBQUksb0JBQW9CLFdBQVcsZUFBZSxHQUFHO0lBRXJELElBQUksT0FBTyxJQUFJLENBQUMsWUFBWSxNQUFNLEdBQUcsR0FBRztNQUN0QyxNQUFNLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLGNBQ2hDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxZQUNQLEVBQUUsQ0FBQyxNQUFNO01BRVosSUFBSSxXQUFXO1FBQ2IsUUFBUSxLQUFLLENBQUMsMENBQTBDO01BQzFELE9BQU87UUFDTCxRQUFRLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxRQUFRLG1CQUFtQixFQUFFLGFBQWEsUUFBUSxFQUFFLGlCQUFpQixXQUFXLEVBQUUsZ0JBQWdCLFNBQVMsRUFBRSxtQkFBbUIsQ0FBQztNQUN4SjtJQUNGO0VBQ0YsRUFBRSxPQUFPLEtBQUs7SUFDWixRQUFRLEtBQUssQ0FBQywrQkFBK0I7RUFDL0M7QUFDRjtBQUVBLDhEQUE4RDtBQUM5RCxlQUFlLG1CQUNiLGFBQTZCLEVBQzdCLE9BQWUsRUFDZixVQUFrQixFQUNsQixRQUF1QixFQUN2QixRQUF1QixFQUN2QixVQUFtQixFQUNuQixXQUFvQjtFQUVwQixJQUFJO0lBQ0Ysb0NBQW9DO0lBQ3BDLE1BQU0sRUFBRSxNQUFNLFdBQVcsRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sY0FDckQsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyxDQUFDOzs7OztNQUtULENBQUMsRUFDQSxFQUFFLENBQUMsWUFBWSxTQUNmLEVBQUUsQ0FBQyxVQUFVO0lBRWhCLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLGdDQUFnQztNQUM5QztJQUNGO0lBRUEsSUFBSSxDQUFDLGVBQWUsWUFBWSxNQUFNLEtBQUssR0FBRztNQUM1QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLDRCQUE0QixFQUFFLFFBQVEsQ0FBQztNQUNwRDtJQUNGO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsWUFBWSxNQUFNLENBQUMsa0JBQWtCLEVBQUUsUUFBUSxDQUFDO0lBRTFFLDJDQUEyQztJQUMzQyxNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsR0FBRyxNQUFNLGNBQzNCLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQywwQkFDUCxFQUFFLENBQUMsTUFBTSxTQUNULE1BQU07SUFFVCxNQUFNLFlBQWEsT0FBTztJQUMxQixNQUFNLFlBQVksV0FBVyxRQUFRO0lBRXJDLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbEMsTUFBTSx1QkFBdUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBRTFDLEtBQUssTUFBTSxTQUFTLFlBQWE7TUFDL0IsTUFBTSxtQkFBb0IsTUFBTSxhQUFhO01BQzdDLE1BQU0sWUFBWSxrQkFBa0I7TUFDcEMsUUFBUSxHQUFHLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxVQUFVLFdBQVcsRUFBRSxRQUFRLENBQUM7TUFFakUsOEJBQThCO01BQzlCLE1BQU0sY0FDSCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO1FBQUUsUUFBUTtRQUFjLFlBQVksSUFBSSxPQUFPLFdBQVc7TUFBRyxHQUNwRSxFQUFFLENBQUMsTUFBTSxNQUFNLEVBQUU7TUFFcEIsSUFBSSxlQUE4QjtNQUNsQyxJQUFJLGNBQXVDO1FBQ3pDLFVBQVU7UUFDVixhQUFhO1FBQ2IsT0FBTztNQUNUO01BRUEsSUFBSSxjQUFjLGVBQWU7UUFDL0IsZUFBZTtRQUNmLFlBQVksa0JBQWtCLEdBQUc7TUFDbkMsT0FBTyxJQUFJLGNBQWMsZUFBZTtRQUN0QyxlQUFlO1FBQ2YsWUFBWSxTQUFTLEdBQUc7UUFDeEIsb0VBQW9FO1FBQ3BFLElBQUksWUFBWTtVQUNkLFlBQVksWUFBWSxHQUFHO1FBQzdCO1FBQ0EsSUFBSSxhQUFhO1VBQ2YsWUFBWSxhQUFhLEdBQUc7UUFDOUI7TUFDRixPQUFPLElBQUksY0FBYyxZQUFZO1FBQ25DLGVBQWU7UUFDZixZQUFZLFNBQVMsR0FBRztNQUMxQjtNQUVBLElBQUksY0FBYztRQUNoQixJQUFJO1VBQ0YsOENBQThDO1VBQzlDLE1BQU0sV0FBVyxNQUFNLE1BQU0sQ0FBQyxFQUFFLGFBQWEsY0FBYyxFQUFFLGFBQWEsQ0FBQyxFQUFFO1lBQzNFLFFBQVE7WUFDUixTQUFTO2NBQ1AsZ0JBQWdCO2NBQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxxQkFBcUIsQ0FBQztZQUNuRDtZQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7VUFDdkI7VUFFQSxNQUFNLFNBQVMsTUFBTSxTQUFTLElBQUk7VUFDbEMsUUFBUSxHQUFHLENBQUMsQ0FBQyxFQUFFLGFBQWEsa0JBQWtCLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRTtVQUU1RCxJQUFJLENBQUMsT0FBTyxPQUFPLEVBQUU7WUFDbkIsaUJBQWlCO1lBQ2pCLE1BQU0sY0FDSCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO2NBQ04sUUFBUTtjQUNSLFlBQVksSUFBSSxPQUFPLFdBQVc7WUFDcEMsR0FDQyxFQUFFLENBQUMsTUFBTSxNQUFNLEVBQUU7VUFDdEI7UUFDQSw0RUFBNEU7UUFDOUUsRUFBRSxPQUFPLFNBQVM7VUFDaEIsUUFBUSxLQUFLLENBQUMsQ0FBQyxjQUFjLEVBQUUsYUFBYSxDQUFDLENBQUMsRUFBRTtVQUNoRCxNQUFNLGNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztZQUNOLFFBQVE7WUFDUixZQUFZLElBQUksT0FBTyxXQUFXO1VBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sTUFBTSxFQUFFO1FBQ3RCO01BQ0YsT0FBTztRQUNMLFFBQVEsR0FBRyxDQUFDLENBQUMsb0JBQW9CLEVBQUUsVUFBVSxtQkFBbUIsQ0FBQztRQUNqRSxNQUFNLGNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztVQUNOLFFBQVE7VUFDUixZQUFZLElBQUksT0FBTyxXQUFXO1FBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sTUFBTSxFQUFFO01BQ3RCO0lBQ0Y7RUFDRixFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLGtDQUFrQztFQUNsRDtBQUNGO0FBRUEsdUVBQXVFO0FBQ3ZFLDhFQUE4RTtBQUM5RSxxREFBcUQ7QUFDckQsZUFBZSx1QkFDYixhQUE2QixFQUM3QixXQUFtQixFQUNuQixlQUF5QjtFQUV6QixJQUFJO0lBQ0YsTUFBTSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNsQyxNQUFNLGdCQUFnQjtJQUN0QixNQUFNLGlCQUFpQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDcEMsTUFBTSxVQUFVLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxlQUFlO0lBRTVDLElBQUksQ0FBQyxjQUFjO01BQ2pCLFFBQVEsS0FBSyxDQUFDO01BQ2Q7SUFDRjtJQUVBLDJCQUEyQjtJQUMzQixNQUFNLG1CQUFtQixpQkFDckIsQ0FBQyxFQUFFLFFBQVEseUNBQXlDLEVBQUUsbUJBQW1CLGdCQUFnQixDQUFDLEdBQzFGLENBQUMsRUFBRSxRQUFRLGlDQUFpQyxDQUFDO0lBRWpELFFBQVEsR0FBRyxDQUFDLENBQUMsZ0RBQWdELEVBQUUsWUFBWSxDQUFDO0lBQzVFLFFBQVEsR0FBRyxDQUFDLENBQUMsb0JBQW9CLEVBQUUsaUJBQWlCLENBQUM7SUFFckQsc0JBQXNCO0lBQ3RCLHdDQUF3QztJQUN4QyxNQUFNLFFBQVE7TUFDWjtNQUNBO0tBQ0Q7SUFFRCxJQUFJLGdCQUFnQjtJQUNwQixJQUFJLFlBQVk7SUFFaEIsS0FBSyxNQUFNLFFBQVEsTUFBTztNQUN4QixJQUFJO1FBQ0YsTUFBTSxNQUFNLENBQUMsRUFBRSxjQUFjLEVBQUUsS0FBSyxDQUFDO1FBQ3JDLFFBQVEsR0FBRyxDQUFDLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDO1FBRXRDLGdCQUFnQixNQUFNLE1BQU0sS0FBSztVQUMvQixRQUFRO1VBQ1IsU0FBUztZQUNQLGdCQUFnQjtZQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDO1VBQzNDO1VBQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztZQUNuQixRQUFRO1lBQ1IsYUFBYTtVQUNmO1FBQ0Y7UUFFQSxZQUFZLE1BQU0sY0FBYyxJQUFJO1FBQ3BDLFFBQVEsR0FBRyxDQUFDLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxLQUFLLFNBQVMsQ0FBQztRQUU1RCx5REFBeUQ7UUFDekQsSUFBSSxjQUFjLE1BQU0sS0FBSyxLQUFLO01BQ3BDLEVBQUUsT0FBTyxVQUFVO1FBQ2pCLFFBQVEsS0FBSyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRTtNQUNwRDtJQUNGO0lBRUEsSUFBSSxDQUFDLGFBQWMsVUFBVSxJQUFJLEtBQUssT0FBTyxVQUFVLElBQUksS0FBSyxLQUFNO01BQ3BFLFFBQVEsS0FBSyxDQUFDLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxTQUFTLENBQUMsV0FBVyxDQUFDO01BQzlEO0lBQ0Y7SUFFQSw2RUFBNkU7SUFDN0UsTUFBTSxjQUFjLFVBQVUsSUFBSSxFQUFFO0lBQ3BDLElBQUksQ0FBQyxhQUFhO01BQ2hCLFFBQVEsS0FBSyxDQUFDO01BQ2Q7SUFDRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMseUNBQXlDLEVBQUUsWUFBWSxDQUFDO0lBRXJFLDhEQUE4RDtJQUM5RCxLQUFLLE1BQU0sV0FBVyxnQkFBaUI7TUFDckMsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLEdBQUcsTUFBTSxjQUMzQixJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsZUFDUCxFQUFFLENBQUMsTUFBTSxTQUNULE1BQU07TUFFVCxJQUFJLE9BQU87UUFDVCxrQ0FBa0M7UUFDbEMsSUFBSSxDQUFDLE1BQU0sV0FBVyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0IsRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHO1VBQ25FLE1BQU0sVUFBVSxNQUFNLFdBQVcsR0FDN0IsQ0FBQyxFQUFFLE1BQU0sV0FBVyxDQUFDLG9CQUFvQixFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQ3pELENBQUMsZ0JBQWdCLEVBQUUsWUFBWSxDQUFDLENBQUM7VUFFckMsTUFBTSxjQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztZQUFFLGFBQWE7VUFBUSxHQUM5QixFQUFFLENBQUMsTUFBTTtVQUVaLFFBQVEsR0FBRyxDQUFDLENBQUMscUJBQXFCLEVBQUUsWUFBWSxVQUFVLEVBQUUsUUFBUSxDQUFDO1FBQ3ZFO01BQ0Y7SUFDRjtFQUNGLEVBQUUsT0FBTyxLQUFLO0lBQ1osUUFBUSxLQUFLLENBQUMsc0NBQXNDO0VBQ3REO0FBQ0Y7QUFFQSxxREFBcUQ7QUFDckQsMkNBQTJDO0FBQzNDLDJCQUEyQjtBQUMzQixxQkFBcUI7QUFDckIseUNBQXlDO0FBQ3pDLGtCQUFrQjtBQUNsQixxQ0FBcUM7QUFDckMsbURBQW1EO0FBQ25ELDZCQUE2QjtBQUM3QixvQkFBb0I7QUFDcEIsMEJBQTBCO0FBQzFCLFNBQVMsb0JBQW9CLElBQVksRUFBRSxlQUF3QjtFQUNqRSxrRkFBa0Y7RUFDbEYsSUFBSSxpQkFBaUI7SUFDbkIsTUFBTSxXQUFXLGdCQUFnQixXQUFXO0lBRTVDLHVDQUF1QztJQUN2QyxJQUFJLFNBQVMsUUFBUSxDQUFDLDRCQUNsQixTQUFTLFFBQVEsQ0FBQywyQkFDbEIsU0FBUyxRQUFRLENBQUMsZ0JBQ2xCLFNBQVMsUUFBUSxDQUFDLHNCQUFzQjtNQUMxQyxPQUFPO1FBQ0wsT0FBTztRQUNQLE1BQU07TUFDUjtJQUNGO0lBRUEsK0JBQStCO0lBQy9CLElBQUksU0FBUyxRQUFRLENBQUMsaUJBQ2xCLFNBQVMsUUFBUSxDQUFDLGdCQUNsQixTQUFTLFFBQVEsQ0FBQyxvQkFDbEIsU0FBUyxRQUFRLENBQUMsZUFBZTtNQUNuQyxPQUFPO1FBQ0wsT0FBTztRQUNQLE1BQU07TUFDUjtJQUNGO0lBRUEscUJBQXFCO0lBQ3JCLElBQUksU0FBUyxRQUFRLENBQUMsWUFBWSxTQUFTLFFBQVEsQ0FBQyxVQUFVO01BQzVELE9BQU87UUFDTCxPQUFPO1FBQ1AsTUFBTTtNQUNSO0lBQ0Y7SUFFQSw2Q0FBNkM7SUFDN0MsSUFBSSxTQUFTLFFBQVEsQ0FBQyxlQUFlLFNBQVMsUUFBUSxDQUFDLGdCQUFnQixTQUFTLFFBQVEsQ0FBQyxZQUFZO01BQ25HLE9BQU87UUFDTCxPQUFPO1FBQ1AsTUFBTTtNQUNSO0lBQ0Y7SUFFQSxpQkFBaUI7SUFDakIsSUFBSSxTQUFTLFFBQVEsQ0FBQyxhQUFhLFNBQVMsUUFBUSxDQUFDLGNBQWMsU0FBUyxRQUFRLENBQUMsaUJBQWlCO01BQ3BHLE9BQU87UUFDTCxPQUFPO1FBQ1AsTUFBTTtNQUNSO0lBQ0Y7RUFDRjtFQUVBLGtDQUFrQztFQUNsQyxNQUFNLGdCQUFpRTtJQUNyRSxLQUFLO01BQ0gsT0FBTztNQUNQLE1BQU07SUFDUjtJQUNBLEtBQUs7TUFDSCxPQUFPO01BQ1AsTUFBTTtJQUNSO0lBQ0EsS0FBSztNQUNILE9BQU87TUFDUCxNQUFNO0lBQ1I7SUFDQSxLQUFLO01BQ0gsT0FBTztNQUNQLE1BQU07SUFDUjtJQUNBLEtBQUs7TUFDSCxPQUFPO01BQ1AsTUFBTTtJQUNSO0lBQ0EsS0FBSztNQUNILE9BQU87TUFDUCxNQUFNO0lBQ1I7SUFDQSxLQUFLO01BQ0gsT0FBTztNQUNQLE1BQU07SUFDUjtJQUNBLEtBQUs7TUFDSCxPQUFPO01BQ1AsTUFBTTtJQUNSO0lBQ0EsS0FBSztNQUNILE9BQU87TUFDUCxNQUFNO0lBQ1I7SUFDQSxLQUFLO01BQ0gsT0FBTztNQUNQLE1BQU07SUFDUjtFQUNGO0VBRUEsSUFBSSxhQUFhLENBQUMsS0FBSyxFQUFFO0lBQ3ZCLE9BQU8sYUFBYSxDQUFDLEtBQUs7RUFDNUI7RUFFQSxPQUFPO0lBQ0wsT0FBTyxDQUFDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLE1BQU0sbUJBQW1CLENBQUMsNENBQTRDLEVBQUUsS0FBSyw4Q0FBOEMsQ0FBQztFQUM5SDtBQUNGO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0Ysa0RBQWtEO0lBQ2xELE1BQU0saUJBQWlCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNwQyxJQUFJLGdCQUFnQjtNQUNsQixnREFBZ0Q7TUFDaEQsTUFBTSxNQUFNLElBQUksSUFBSSxJQUFJLEdBQUc7TUFDM0IsTUFBTSxjQUFjLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixRQUFRLFdBQVc7TUFDakgsTUFBTSxhQUFhLElBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQztNQUV4QyxJQUFJLGdCQUFnQixrQkFBa0IsZUFBZSxnQkFBZ0I7UUFDbkUsUUFBUSxLQUFLLENBQUM7UUFDZCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBZSxJQUN2QztVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFDQSxRQUFRLEdBQUcsQ0FBQztJQUNkLE9BQU87TUFDTCxRQUFRLElBQUksQ0FBQztJQUNmO0lBRUEsTUFBTSxnQkFBZ0IsYUFDcEIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0lBRy9DLE1BQU0sZUFBZSxNQUFNLElBQUksSUFBSTtJQUNuQyxRQUFRLEdBQUcsQ0FBQywyQkFBMkIsS0FBSyxTQUFTLENBQUM7SUFFdEQsaURBQWlEO0lBQ2pELHFIQUFxSDtJQUNySCxNQUFNLFNBQVMsY0FBYyxNQUFNLFFBQVEsY0FBYyxRQUFRLEVBQUU7SUFDbkUsTUFBTSxTQUFTLGNBQWMsTUFBTTtJQUNuQyxNQUFNLGVBQWUsY0FBYyxNQUFNO0lBQ3pDLE1BQU0sZUFBZSxjQUFjO0lBQ25DLE1BQU0sZUFBZSxjQUFjO0lBRW5DLFFBQVEsR0FBRyxDQUFDLENBQUMsZUFBZSxFQUFFLGFBQWEsV0FBVyxFQUFFLE9BQU8sUUFBUSxFQUFFLGFBQWEsZ0JBQWdCLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQztJQUV2SCw0RUFBNEU7SUFDNUUsb0ZBQW9GO0lBQ3BGLE1BQU0sVUFBVSxpQkFBaUIsT0FDakIsaUJBQWlCLFVBQ2pCLGlCQUFpQixXQUNqQixpQkFBaUI7SUFFakMsSUFBSSxTQUFTO01BQ1gsUUFBUSxHQUFHLENBQUMsQ0FBQyxpQ0FBaUMsRUFBRSxPQUFPLFNBQVMsRUFBRSxhQUFhLFFBQVEsRUFBRSxhQUFhLENBQUM7TUFFdkcsbUNBQW1DO01BQ25DLE1BQU0sWUFBWSxvQkFBb0IsZ0JBQWdCLEtBQUssZ0JBQWdCLGNBQWMsTUFBTTtNQUMvRixNQUFNLGFBQWEsVUFBVSxLQUFLO01BRWxDLHFGQUFxRjtNQUNyRixJQUFJLGVBQWtELEVBQUU7TUFFeEQsdURBQXVEO01BQ3ZELElBQUksUUFBUTtRQUNWLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxHQUFHLE1BQU0sY0FDaEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLDRCQUNQLEVBQUUsQ0FBQyxVQUFVO1VBQUM7VUFBYztTQUFVLEVBQ3RDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEVBQ2xDLEtBQUssQ0FBQztRQUVULElBQUksY0FBYyxXQUFXLE1BQU0sR0FBRyxHQUFHO1VBQ3ZDLGVBQWU7VUFDZixRQUFRLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxXQUFXLE1BQU0sQ0FBQyx5QkFBeUIsRUFBRSxPQUFPLENBQUM7UUFDNUU7TUFDRjtNQUVBLHNEQUFzRDtNQUN0RCxJQUFJLGFBQWEsTUFBTSxLQUFLLEdBQUc7UUFDN0IsTUFBTSxFQUFFLE1BQU0sYUFBYSxFQUFFLEdBQUcsTUFBTSxjQUNuQyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsZUFDUCxFQUFFLENBQUMsVUFBVTtVQUFDO1VBQWM7U0FBVSxFQUN0QyxLQUFLLENBQUMsY0FBYztVQUFFLFdBQVc7UUFBTSxHQUN2QyxLQUFLLENBQUM7UUFFVCxJQUFJLGlCQUFpQixjQUFjLE1BQU0sR0FBRyxHQUFHO1VBQzdDLGVBQWU7UUFDakI7TUFDRjtNQUVBLElBQUksYUFBYSxNQUFNLEdBQUcsR0FBRztRQUMzQixLQUFLLE1BQU0sU0FBUyxhQUFjO1VBQ2hDLE1BQU0sY0FDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7WUFDTixRQUFRO1lBQ1IsZUFBZTtVQUNqQixHQUNDLEVBQUUsQ0FBQyxNQUFNLE1BQU0sRUFBRTtVQUVwQixrQ0FBa0M7VUFDbEMsTUFBTSxFQUFFLE1BQU0sTUFBTSxFQUFFLEdBQUcsTUFBTSxjQUM1QixJQUFJLENBQUMsbUJBQ0wsTUFBTSxDQUFDLFlBQ1AsRUFBRSxDQUFDLFlBQVksTUFBTSxFQUFFLEVBQ3ZCLE1BQU07VUFFVCxtQkFBbUI7VUFDbkIsSUFBSSxVQUFVLE9BQU8sUUFBUSxHQUFHLEdBQUc7WUFDakMsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxjQUM3QixJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxNQUFNLE9BQU8sRUFDM0IsTUFBTTtZQUVULElBQUksU0FBUztjQUNYLE1BQU0sYUFBYSxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSSxPQUFPLFFBQVE7Y0FDM0QsTUFBTSxjQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztnQkFBRSxTQUFTO2NBQVcsR0FDN0IsRUFBRSxDQUFDLFdBQVcsTUFBTSxPQUFPO2NBRTlCLHlCQUF5QjtjQUN6QixNQUFNLGNBQWMsSUFBSSxDQUFDLHdCQUF3QixNQUFNLENBQUM7Z0JBQ3RELFNBQVMsTUFBTSxPQUFPO2dCQUN0QixRQUFRLE9BQU8sUUFBUTtnQkFDdkIsZUFBZTtnQkFDZixNQUFNO2dCQUNOLGFBQWEsQ0FBQyxzQkFBc0IsRUFBRSxXQUFXLENBQUM7Z0JBQ2xELGNBQWMsTUFBTSxFQUFFO2dCQUN0QixnQkFBZ0I7Y0FDbEI7Y0FFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLFNBQVMsRUFBRSxPQUFPLFFBQVEsQ0FBQyxXQUFXLEVBQUUsTUFBTSxPQUFPLENBQUMsQ0FBQztjQUVwRSx3REFBd0Q7Y0FDeEQsTUFBTSxjQUNILElBQUksQ0FBQyxpQkFDTCxNQUFNLENBQUM7Z0JBQ04sU0FBUyxNQUFNLE9BQU87Z0JBQ3RCLE1BQU07Z0JBQ04sT0FBTyxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUM7Z0JBQzlCLFNBQVMsQ0FBQyxFQUFFLFVBQVUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLE9BQU8sUUFBUSxDQUFDLEVBQUUsQ0FBQztnQkFDbkUsYUFBYTtnQkFDYixXQUFXLE1BQU0sRUFBRTtjQUNyQjtZQUNKO1VBQ0Y7VUFFQSx5Q0FBeUM7VUFDekMsTUFBTSxjQUNILElBQUksQ0FBQyxtQkFDTCxNQUFNLENBQUM7WUFBRSxRQUFRO1VBQVMsR0FDMUIsRUFBRSxDQUFDLFlBQVksTUFBTSxFQUFFO1FBQzVCO1FBQ0EsUUFBUSxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsYUFBYSxNQUFNLENBQUMsOEJBQThCLENBQUM7TUFDM0U7TUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLFVBQVU7UUFBTSxTQUFTO01BQTBDLElBQ3BGO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsSUFBSSxDQUFDLE1BQU0sT0FBTyxDQUFDLFdBQVcsT0FBTyxNQUFNLEtBQUssR0FBRztNQUNqRCxRQUFRLEdBQUcsQ0FBQztNQUNaLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsVUFBVTtRQUFNLFNBQVM7TUFBdUIsSUFDakU7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxrRkFBa0Y7SUFDbEYsOERBQThEO0lBQzlELElBQUksaUJBQWlCLGNBQWMsaUJBQWlCLFNBQVM7TUFDM0QsUUFBUSxHQUFHLENBQUMsQ0FBQyx3QkFBd0IsRUFBRSxhQUFhLG9CQUFvQixDQUFDO01BQ3pFLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsVUFBVTtRQUFNLFNBQVMsQ0FBQyxjQUFjLEVBQUUsYUFBYSxhQUFhLENBQUM7TUFBQyxJQUN2RjtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLE1BQU0sb0JBQW9CLGlCQUFpQjtJQUMzQyxJQUFJLG1CQUFtQjtNQUNyQixRQUFRLEdBQUcsQ0FBQyxDQUFDLGlGQUFpRixDQUFDO0lBQ2pHO0lBRUEsZ0VBQWdFO0lBQ2hFLDhFQUE4RTtJQUM5RSxJQUFJLGdCQU9DLEVBQUU7SUFFUCxJQUFJLFFBQVE7TUFDVixNQUFNLEVBQUUsTUFBTSxVQUFVLEVBQUUsT0FBTyxhQUFhLEVBQUUsR0FBRyxNQUFNLGNBQ3RELElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxtREFDUCxFQUFFLENBQUMsVUFBVTtRQUFDO1FBQWM7T0FBVSxFQUN0QyxLQUFLLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUM3QyxLQUFLLENBQUMsY0FBYztRQUFFLFdBQVc7TUFBSyxHQUN0QyxLQUFLLENBQUM7TUFFVCxJQUFJLGVBQWU7UUFDakIsUUFBUSxLQUFLLENBQUMsb0NBQW9DO01BQ3BELE9BQU8sSUFBSSxjQUFjLFdBQVcsTUFBTSxHQUFHLEdBQUc7UUFDOUMsZ0JBQWdCO1FBQ2hCLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLFdBQVcsTUFBTSxDQUFDLHlCQUF5QixFQUFFLE9BQU8sQ0FBQztNQUM1RTtJQUNGO0lBRUEsbUZBQW1GO0lBQ25GLHNEQUFzRDtJQUN0RCxJQUFJLGNBQWMsTUFBTSxLQUFLLEdBQUc7TUFDOUIsUUFBUSxJQUFJLENBQUMsQ0FBQyxpQ0FBaUMsRUFBRSxPQUFPLHdEQUF3RCxDQUFDO01BQ2pILFFBQVEsSUFBSSxDQUFDLENBQUMsa0JBQWtCLEVBQUUsT0FBTyxNQUFNLENBQUMsMENBQTBDLENBQUM7TUFDM0YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixVQUFVO1FBQ1YsU0FBUztRQUNULFNBQVM7TUFDWCxJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsSUFBSSxlQUFlO0lBRW5CLDZFQUE2RTtJQUM3RSxNQUFNLGtCQUFrQjtTQUFJO0tBQWM7SUFDMUMsMENBQTBDO0lBQzFDLE1BQU0sbUJBQW1CLElBQUk7SUFFN0IsaURBQWlEO0lBQ2pELHVGQUF1RjtJQUN2RixJQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxNQUFNLEVBQUUsSUFBSztNQUN0QyxNQUFNLFFBQVEsTUFBTSxDQUFDLEVBQUU7TUFDdkIsTUFBTSxFQUNKLElBQUksV0FBVyxFQUNmLFNBQVMsRUFDVCxnQkFBZ0IsRUFDaEIsZ0JBQWdCLEVBQ2hCLFNBQVMsRUFDVCxnQkFBZ0IsRUFDaEIsUUFBUSxFQUNSLE9BQU8sU0FBUyxFQUNqQixHQUFHO01BRUosTUFBTSxXQUFXLGFBQWEsb0JBQW9CO01BQ2xELE1BQU0sV0FBVyxhQUFhO01BRTlCLElBQUksQ0FBQyxVQUFVO1FBQ2IsUUFBUSxHQUFHLENBQUM7UUFDWjtNQUNGO01BRUEsdUZBQXVGO01BQ3ZGLG1EQUFtRDtNQUNuRCxNQUFNLGdCQUFnQixlQUFlLENBQUMsRUFBRTtNQUV4Qyw2REFBNkQ7TUFDN0QsSUFBSSxDQUFDLGVBQWU7UUFDbEIsUUFBUSxHQUFHLENBQUMsQ0FBQywwQkFBMEIsRUFBRSxFQUFFLGtCQUFrQixFQUFFLFVBQVUsQ0FBQztRQUMxRTtNQUNGO01BRUEsNERBQTREO01BQzVELElBQUksaUJBQWlCLEdBQUcsQ0FBQyxJQUFJO1FBQzNCLFFBQVEsR0FBRyxDQUFDLENBQUMsZUFBZSxFQUFFLEVBQUUsNEJBQTRCLENBQUM7UUFDN0Q7TUFDRjtNQUVBLGlCQUFpQixHQUFHLENBQUM7TUFDckIsUUFBUSxHQUFHLENBQUMsQ0FBQyxlQUFlLEVBQUUsY0FBYyxFQUFFLENBQUMsRUFBRSxFQUFFLGNBQWMsS0FBSyxDQUFDLGNBQWMsRUFBRSxTQUFTLENBQUM7TUFFakcsdURBQXVEO01BQ3ZELElBQUksZ0JBQWdCO01BQ3BCLElBQUksZ0JBQWdCO01BRXBCLDZCQUE2QjtNQUM3QixJQUFJO1FBQ0YsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLGNBQWMsRUFBRSxDQUFDLElBQUksQ0FBQztRQUMvQyxNQUFNLGlCQUFpQixNQUFNLGtCQUMzQixlQUNBLFVBQ0EsVUFDQSxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUM7UUFFMUIsSUFBSSxnQkFBZ0I7VUFDbEIsZ0JBQWdCO1VBQ2hCLFFBQVEsR0FBRyxDQUFDLENBQUMseUJBQXlCLEVBQUUsY0FBYyxDQUFDO1FBQ3pELE9BQU87VUFDTCxRQUFRLEdBQUcsQ0FBQyxDQUFDLHdDQUF3QyxDQUFDO1FBQ3hEO01BQ0YsRUFBRSxPQUFPLFVBQVU7UUFDakIsUUFBUSxLQUFLLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFO01BQ3hDO01BRUEsOEJBQThCO01BQzlCLElBQUksVUFBVTtRQUNaLElBQUk7VUFDRixNQUFNLGdCQUFnQixDQUFDLEVBQUUsY0FBYyxFQUFFLENBQUMsSUFBSSxDQUFDO1VBQy9DLE1BQU0saUJBQWlCLE1BQU0sa0JBQzNCLGVBQ0EsVUFDQSxVQUNBLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQztVQUUzQixJQUFJLGdCQUFnQjtZQUNsQixnQkFBZ0I7WUFDaEIsUUFBUSxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBRSxjQUFjLENBQUM7VUFDekQsT0FBTztZQUNMLFFBQVEsR0FBRyxDQUFDLENBQUMsd0NBQXdDLENBQUM7VUFDeEQ7UUFDRixFQUFFLE9BQU8sVUFBVTtVQUNqQixRQUFRLEtBQUssQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEVBQUU7UUFDeEM7TUFDRjtNQUVBLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sY0FDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sV0FBVztRQUNYLFdBQVcsaUJBQWlCO1FBQzVCLFVBQVUsV0FBVyxLQUFLLEtBQUssQ0FBQyxZQUFZO1FBQzVDLFFBQVE7UUFDUiwyQ0FBMkM7UUFDM0MsZUFBZSxlQUFlO1FBQzlCLHVFQUF1RTtRQUN2RSxhQUFhLGNBQWMsV0FBVyxHQUNsQyxDQUFDLEVBQUUsY0FBYyxXQUFXLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEdBQ3RELENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO01BQzVCLEdBQ0MsRUFBRSxDQUFDLE1BQU0sY0FBYyxFQUFFO01BRTVCLElBQUksYUFBYTtRQUNmLFFBQVEsS0FBSyxDQUFDLHlCQUF5QjtNQUN6QyxPQUFPO1FBQ0wsUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsY0FBYyxFQUFFLENBQUMsdUNBQXVDLENBQUM7UUFDOUU7UUFFQSwrQkFBK0I7UUFDL0IsTUFBTSxjQUNILElBQUksQ0FBQyxtQkFDTCxNQUFNLENBQUM7VUFBRSxRQUFRO1FBQVksR0FDN0IsRUFBRSxDQUFDLFlBQVksY0FBYyxFQUFFO1FBR2xDLDRGQUE0RjtRQUM1RixNQUFNLG1CQUFtQixlQUFlLGNBQWMsRUFBRSxFQUFFLGNBQWMsS0FBSyxJQUFJLFlBQVksZUFBZSxlQUFlLFFBQVE7UUFFbkksOERBQThEO1FBQzlELHFFQUFxRTtRQUNyRSxNQUFNLHNCQUFzQixjQUFjLFdBQVcsRUFBRSxRQUFRLHVCQUF1QixPQUFPO1FBQzdGLE1BQU0sY0FBYyxjQUFjLE1BQU0sSUFBSTtRQUU1QyxnQkFDRSxDQUFDLGNBQWMsRUFBRSxjQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQ25DLG9CQUFvQixlQUFlLGNBQWMsRUFBRSxFQUFFLHFCQUFxQjtNQUU5RTtJQUNGO0lBRUEsa0VBQWtFO0lBQ2xFLHFFQUFxRTtJQUNyRSxrRUFBa0U7SUFDbEUsd0ZBQXdGO0lBQ3hGLElBQUksZUFBZSxLQUFLLFVBQVUsQ0FBQyxtQkFBbUI7TUFDcEQsTUFBTSxtQkFBbUIsZ0JBQ3RCLE1BQU0sQ0FBQyxDQUFBLElBQUssaUJBQWlCLEdBQUcsQ0FBQyxnQkFBZ0IsT0FBTyxDQUFDLEtBQ3pELEdBQUcsQ0FBQyxDQUFBLElBQUssRUFBRSxFQUFFO01BRWhCLElBQUksaUJBQWlCLE1BQU0sR0FBRyxHQUFHO1FBQy9CLGdCQUNFLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLEVBQzNCLHVCQUF1QixlQUFlLFFBQVE7TUFFbEQ7SUFDRjtJQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztNQUFNLFNBQVM7SUFBYSxJQUN0RDtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLDJCQUEyQjtJQUN6QyxNQUFNLGVBQWUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDOUQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQWEsSUFDckM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  let trackId = null;
  try {
    // Security: Verify request comes from service role (internal calls only)
    const authHeader = req.headers.get("Authorization");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (authHeader !== `Bearer ${supabaseServiceKey}`) {
      return new Response(JSON.stringify({
        error: "Unauthorized - internal use only"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const body = await req.json();
    const { track_id, audio_url, track_title, start_time = 0, duration = 30 } = body;
    trackId = track_id;
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    console.log(`Creating ringtone for track: ${track_id}, title: ${track_title}`);
    if (!audio_url) {
      throw new Error("Audio URL is required for ringtone generation");
    }
    // Update the track_addons table with the result (use original audio as ringtone)
    const { data: addonService } = await supabase.from("addon_services").select("id").eq("name", "ringtone").single();
    if (addonService) {
      const { error: updateError } = await supabase.from("track_addons").update({
        result_url: audio_url,
        status: "completed",
        updated_at: new Date().toISOString()
      }).eq("track_id", track_id).eq("addon_service_id", addonService.id);
      if (updateError) {
        console.error("Update addon error:", updateError);
        throw new Error("Failed to update addon status");
      }
    }
    console.log(`Ringtone created successfully for track: ${track_id}`);
    return new Response(JSON.stringify({
      success: true,
      ringtone_url: audio_url,
      message: "Ringtone created successfully"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("generate-ringtone error:", error);
    // Update addon status to failed if we have trackId
    if (trackId) {
      try {
        const supabaseUrl = Deno.env.get("SUPABASE_URL");
        const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
        const supabase = createClient(supabaseUrl, supabaseServiceKey);
        const { data: addonService } = await supabase.from("addon_services").select("id").eq("name", "ringtone").single();
        if (addonService) {
          await supabase.from("track_addons").update({
            status: "failed",
            updated_at: new Date().toISOString()
          }).eq("track_id", trackId).eq("addon_service_id", addonService.id);
        }
      } catch (e) {
        console.error("Failed to update addon status:", e);
      }
    }
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9nZW5lcmF0ZS1yaW5ndG9uZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICBsZXQgdHJhY2tJZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG5cbiAgdHJ5IHtcbiAgICAvLyBTZWN1cml0eTogVmVyaWZ5IHJlcXVlc3QgY29tZXMgZnJvbSBzZXJ2aWNlIHJvbGUgKGludGVybmFsIGNhbGxzIG9ubHkpXG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gICAgXG4gICAgaWYgKGF1dGhIZWFkZXIgIT09IGBCZWFyZXIgJHtzdXBhYmFzZVNlcnZpY2VLZXl9YCkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWQgLSBpbnRlcm5hbCB1c2Ugb25seVwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc3QgeyB0cmFja19pZCwgYXVkaW9fdXJsLCB0cmFja190aXRsZSwgc3RhcnRfdGltZSA9IDAsIGR1cmF0aW9uID0gMzAgfSA9IGJvZHk7XG4gICAgdHJhY2tJZCA9IHRyYWNrX2lkO1xuICAgIFxuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIGNvbnNvbGUubG9nKGBDcmVhdGluZyByaW5ndG9uZSBmb3IgdHJhY2s6ICR7dHJhY2tfaWR9LCB0aXRsZTogJHt0cmFja190aXRsZX1gKTtcblxuICAgIGlmICghYXVkaW9fdXJsKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJBdWRpbyBVUkwgaXMgcmVxdWlyZWQgZm9yIHJpbmd0b25lIGdlbmVyYXRpb25cIik7XG4gICAgfVxuXG4gICAgLy8gVXBkYXRlIHRoZSB0cmFja19hZGRvbnMgdGFibGUgd2l0aCB0aGUgcmVzdWx0ICh1c2Ugb3JpZ2luYWwgYXVkaW8gYXMgcmluZ3RvbmUpXG4gICAgY29uc3QgeyBkYXRhOiBhZGRvblNlcnZpY2UgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImFkZG9uX3NlcnZpY2VzXCIpXG4gICAgICAuc2VsZWN0KFwiaWRcIilcbiAgICAgIC5lcShcIm5hbWVcIiwgXCJyaW5ndG9uZVwiKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKGFkZG9uU2VydmljZSkge1xuICAgICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgIHJlc3VsdF91cmw6IGF1ZGlvX3VybCxcbiAgICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICB9KVxuICAgICAgICAuZXEoXCJ0cmFja19pZFwiLCB0cmFja19pZClcbiAgICAgICAgLmVxKFwiYWRkb25fc2VydmljZV9pZFwiLCBhZGRvblNlcnZpY2UuaWQpO1xuXG4gICAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIlVwZGF0ZSBhZGRvbiBlcnJvcjpcIiwgdXBkYXRlRXJyb3IpO1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIGFkZG9uIHN0YXR1c1wiKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgUmluZ3RvbmUgY3JlYXRlZCBzdWNjZXNzZnVsbHkgZm9yIHRyYWNrOiAke3RyYWNrX2lkfWApO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgcmluZ3RvbmVfdXJsOiBhdWRpb191cmwsXG4gICAgICAgIG1lc3NhZ2U6IFwiUmluZ3RvbmUgY3JlYXRlZCBzdWNjZXNzZnVsbHlcIixcbiAgICAgIH0pLFxuICAgICAge1xuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgfVxuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcImdlbmVyYXRlLXJpbmd0b25lIGVycm9yOlwiLCBlcnJvcik7XG4gICAgXG4gICAgLy8gVXBkYXRlIGFkZG9uIHN0YXR1cyB0byBmYWlsZWQgaWYgd2UgaGF2ZSB0cmFja0lkXG4gICAgaWYgKHRyYWNrSWQpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICAgICAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gICAgICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuICAgICAgICBcbiAgICAgICAgY29uc3QgeyBkYXRhOiBhZGRvblNlcnZpY2UgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJhZGRvbl9zZXJ2aWNlc1wiKVxuICAgICAgICAgIC5zZWxlY3QoXCJpZFwiKVxuICAgICAgICAgIC5lcShcIm5hbWVcIiwgXCJyaW5ndG9uZVwiKVxuICAgICAgICAgIC5zaW5nbGUoKTtcbiAgICAgICAgICBcbiAgICAgICAgaWYgKGFkZG9uU2VydmljZSkge1xuICAgICAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5lcShcInRyYWNrX2lkXCIsIHRyYWNrSWQpXG4gICAgICAgICAgICAuZXEoXCJhZGRvbl9zZXJ2aWNlX2lkXCIsIGFkZG9uU2VydmljZS5pZCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgYWRkb24gc3RhdHVzOlwiLCBlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIGVycm9yOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiLFxuICAgICAgfSksXG4gICAgICB7XG4gICAgICAgIHN0YXR1czogNTAwLFxuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJLFVBQXlCO0VBRTdCLElBQUk7SUFDRix5RUFBeUU7SUFDekUsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFFeEMsSUFBSSxlQUFlLENBQUMsT0FBTyxFQUFFLG1CQUFtQixDQUFDLEVBQUU7TUFDakQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQW1DLElBQzNEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtJQUMzQixNQUFNLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsYUFBYSxDQUFDLEVBQUUsV0FBVyxFQUFFLEVBQUUsR0FBRztJQUM1RSxVQUFVO0lBRVYsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLFFBQVEsR0FBRyxDQUFDLENBQUMsNkJBQTZCLEVBQUUsU0FBUyxTQUFTLEVBQUUsWUFBWSxDQUFDO0lBRTdFLElBQUksQ0FBQyxXQUFXO01BQ2QsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxpRkFBaUY7SUFDakYsTUFBTSxFQUFFLE1BQU0sWUFBWSxFQUFFLEdBQUcsTUFBTSxTQUNsQyxJQUFJLENBQUMsa0JBQ0wsTUFBTSxDQUFDLE1BQ1AsRUFBRSxDQUFDLFFBQVEsWUFDWCxNQUFNO0lBRVQsSUFBSSxjQUFjO01BQ2hCLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztRQUNOLFlBQVk7UUFDWixRQUFRO1FBQ1IsWUFBWSxJQUFJLE9BQU8sV0FBVztNQUNwQyxHQUNDLEVBQUUsQ0FBQyxZQUFZLFVBQ2YsRUFBRSxDQUFDLG9CQUFvQixhQUFhLEVBQUU7TUFFekMsSUFBSSxhQUFhO1FBQ2YsUUFBUSxLQUFLLENBQUMsdUJBQXVCO1FBQ3JDLE1BQU0sSUFBSSxNQUFNO01BQ2xCO0lBQ0Y7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLHlDQUF5QyxFQUFFLFNBQVMsQ0FBQztJQUVsRSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxjQUFjO01BQ2QsU0FBUztJQUNYLElBQ0E7TUFDRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQ2hFO0VBRUosRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFFMUMsbURBQW1EO0lBQ25ELElBQUksU0FBUztNQUNYLElBQUk7UUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO1FBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztRQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO1FBRTNDLE1BQU0sRUFBRSxNQUFNLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGtCQUNMLE1BQU0sQ0FBQyxNQUNQLEVBQUUsQ0FBQyxRQUFRLFlBQ1gsTUFBTTtRQUVULElBQUksY0FBYztVQUNoQixNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztZQUNOLFFBQVE7WUFDUixZQUFZLElBQUksT0FBTyxXQUFXO1VBQ3BDLEdBQ0MsRUFBRSxDQUFDLFlBQVksU0FDZixFQUFFLENBQUMsb0JBQW9CLGFBQWEsRUFBRTtRQUMzQztNQUNGLEVBQUUsT0FBTyxHQUFHO1FBQ1YsUUFBUSxLQUFLLENBQUMsa0NBQWtDO01BQ2xEO0lBQ0Y7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ2xELElBQ0E7TUFDRSxRQUFRO01BQ1IsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUNoRTtFQUVKO0FBQ0YifQ==
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '');
    // Get user from auth header using getClaims (more reliable)
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }
    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      throw new Error('Unauthorized');
    }
    const userId = claimsData.claims.sub;
    const { trackId } = await req.json();
    console.log(`[request-distribution] User ${userId} requesting distribution for track: ${trackId}`);
    if (!trackId) {
      throw new Error('trackId is required');
    }
    // Get track and verify ownership
    const { data: track, error: trackError } = await supabase.from('tracks').select('*').eq('id', trackId).single();
    if (trackError || !track) {
      throw new Error('Track not found');
    }
    if (track.user_id !== userId) {
      throw new Error('Not authorized to request distribution for this track');
    }
    // Check if already in distribution process
    if (track.distribution_status !== 'none') {
      throw new Error(`Track is already in distribution process: ${track.distribution_status}`);
    }
    // Check plagiarism status
    if (track.plagiarism_check_status !== 'clean') {
      throw new Error('Track must pass plagiarism check first');
    }
    // Update track status
    const { error: updateError } = await supabase.from('tracks').update({
      distribution_status: 'pending_moderation',
      distribution_requested_at: new Date().toISOString()
    }).eq('id', trackId);
    if (updateError) {
      throw updateError;
    }
    // Log the request
    await supabase.from('distribution_logs').insert({
      track_id: trackId,
      user_id: userId,
      action: 'distribution_requested',
      stage: 'level_user',
      details: {
        track_title: track.title,
        plagiarism_status: track.plagiarism_check_status
      }
    });
    // Notify admins
    const { data: admins } = await supabase.from('user_roles').select('user_id').in('role', [
      'admin',
      'super_admin',
      'moderator'
    ]);
    if (admins) {
      const notifications = admins.map((admin)=>({
          user_id: admin.user_id,
          type: 'moderation',
          title: '📤 Запрос на дистрибуцию',
          message: `Пользователь запросил дистрибуцию трека "${track.title}"`,
          actor_id: userId,
          target_type: 'track',
          target_id: trackId
        }));
      await supabase.from('notifications').insert(notifications);
    }
    return new Response(JSON.stringify({
      success: true,
      message: 'Distribution request submitted',
      status: 'pending_moderation'
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('[request-distribution] Error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({
      success: false,
      error: message
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9yZXF1ZXN0LWRpc3RyaWJ1dGlvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ2F1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlJyxcbn07XG5cbmludGVyZmFjZSBSZXF1ZXN0RGlzdHJpYnV0aW9uSW5wdXQge1xuICB0cmFja0lkOiBzdHJpbmc7XG59XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09ICdPUFRJT05TJykge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoJ29rJywgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoJ1NVUEFCQVNFX1VSTCcpID8/ICcnLFxuICAgICAgRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZJykgPz8gJydcbiAgICApO1xuXG4gICAgLy8gR2V0IHVzZXIgZnJvbSBhdXRoIGhlYWRlciB1c2luZyBnZXRDbGFpbXMgKG1vcmUgcmVsaWFibGUpXG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldCgnQXV0aG9yaXphdGlvbicpO1xuICAgIGlmICghYXV0aEhlYWRlcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBhdXRob3JpemF0aW9uIGhlYWRlcicpO1xuICAgIH1cblxuICAgIGNvbnN0IHRva2VuID0gYXV0aEhlYWRlci5yZXBsYWNlKCdCZWFyZXIgJywgJycpO1xuICAgIGNvbnN0IHsgZGF0YTogY2xhaW1zRGF0YSwgZXJyb3I6IGNsYWltc0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldENsYWltcyh0b2tlbik7XG4gICAgXG4gICAgaWYgKGNsYWltc0Vycm9yIHx8ICFjbGFpbXNEYXRhPy5jbGFpbXM/LnN1Yikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcbiAgICB9XG4gICAgXG4gICAgY29uc3QgdXNlcklkID0gY2xhaW1zRGF0YS5jbGFpbXMuc3ViIGFzIHN0cmluZztcblxuICAgIGNvbnN0IHsgdHJhY2tJZCB9OiBSZXF1ZXN0RGlzdHJpYnV0aW9uSW5wdXQgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKGBbcmVxdWVzdC1kaXN0cmlidXRpb25dIFVzZXIgJHt1c2VySWR9IHJlcXVlc3RpbmcgZGlzdHJpYnV0aW9uIGZvciB0cmFjazogJHt0cmFja0lkfWApO1xuXG4gICAgaWYgKCF0cmFja0lkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RyYWNrSWQgaXMgcmVxdWlyZWQnKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgdHJhY2sgYW5kIHZlcmlmeSBvd25lcnNoaXBcbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrLCBlcnJvcjogdHJhY2tFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKCd0cmFja3MnKVxuICAgICAgLnNlbGVjdCgnKicpXG4gICAgICAuZXEoJ2lkJywgdHJhY2tJZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICh0cmFja0Vycm9yIHx8ICF0cmFjaykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdUcmFjayBub3QgZm91bmQnKTtcbiAgICB9XG5cbiAgICBpZiAodHJhY2sudXNlcl9pZCAhPT0gdXNlcklkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vdCBhdXRob3JpemVkIHRvIHJlcXVlc3QgZGlzdHJpYnV0aW9uIGZvciB0aGlzIHRyYWNrJyk7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgaWYgYWxyZWFkeSBpbiBkaXN0cmlidXRpb24gcHJvY2Vzc1xuICAgIGlmICh0cmFjay5kaXN0cmlidXRpb25fc3RhdHVzICE9PSAnbm9uZScpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgVHJhY2sgaXMgYWxyZWFkeSBpbiBkaXN0cmlidXRpb24gcHJvY2VzczogJHt0cmFjay5kaXN0cmlidXRpb25fc3RhdHVzfWApO1xuICAgIH1cblxuICAgIC8vIENoZWNrIHBsYWdpYXJpc20gc3RhdHVzXG4gICAgaWYgKHRyYWNrLnBsYWdpYXJpc21fY2hlY2tfc3RhdHVzICE9PSAnY2xlYW4nKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RyYWNrIG11c3QgcGFzcyBwbGFnaWFyaXNtIGNoZWNrIGZpcnN0Jyk7XG4gICAgfVxuXG4gICAgLy8gVXBkYXRlIHRyYWNrIHN0YXR1c1xuICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oJ3RyYWNrcycpXG4gICAgICAudXBkYXRlKHtcbiAgICAgICAgZGlzdHJpYnV0aW9uX3N0YXR1czogJ3BlbmRpbmdfbW9kZXJhdGlvbicsXG4gICAgICAgIGRpc3RyaWJ1dGlvbl9yZXF1ZXN0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxuICAgICAgfSlcbiAgICAgIC5lcSgnaWQnLCB0cmFja0lkKTtcblxuICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgdGhyb3cgdXBkYXRlRXJyb3I7XG4gICAgfVxuXG4gICAgLy8gTG9nIHRoZSByZXF1ZXN0XG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgnZGlzdHJpYnV0aW9uX2xvZ3MnKS5pbnNlcnQoe1xuICAgICAgdHJhY2tfaWQ6IHRyYWNrSWQsXG4gICAgICB1c2VyX2lkOiB1c2VySWQsXG4gICAgICBhY3Rpb246ICdkaXN0cmlidXRpb25fcmVxdWVzdGVkJyxcbiAgICAgIHN0YWdlOiAnbGV2ZWxfdXNlcicsXG4gICAgICBkZXRhaWxzOiB7IFxuICAgICAgICB0cmFja190aXRsZTogdHJhY2sudGl0bGUsXG4gICAgICAgIHBsYWdpYXJpc21fc3RhdHVzOiB0cmFjay5wbGFnaWFyaXNtX2NoZWNrX3N0YXR1c1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gTm90aWZ5IGFkbWluc1xuICAgIGNvbnN0IHsgZGF0YTogYWRtaW5zIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oJ3VzZXJfcm9sZXMnKVxuICAgICAgLnNlbGVjdCgndXNlcl9pZCcpXG4gICAgICAuaW4oJ3JvbGUnLCBbJ2FkbWluJywgJ3N1cGVyX2FkbWluJywgJ21vZGVyYXRvciddKTtcblxuICAgIGlmIChhZG1pbnMpIHtcbiAgICAgIGNvbnN0IG5vdGlmaWNhdGlvbnMgPSBhZG1pbnMubWFwKGFkbWluID0+ICh7XG4gICAgICAgIHVzZXJfaWQ6IGFkbWluLnVzZXJfaWQsXG4gICAgICAgIHR5cGU6ICdtb2RlcmF0aW9uJyxcbiAgICAgICAgdGl0bGU6ICfwn5OkINCX0LDQv9GA0L7RgSDQvdCwINC00LjRgdGC0YDQuNCx0YPRhtC40Y4nLFxuICAgICAgICBtZXNzYWdlOiBg0J/QvtC70YzQt9C+0LLQsNGC0LXQu9GMINC30LDQv9GA0L7RgdC40Lsg0LTQuNGB0YLRgNC40LHRg9GG0LjRjiDRgtGA0LXQutCwIFwiJHt0cmFjay50aXRsZX1cImAsXG4gICAgICAgIGFjdG9yX2lkOiB1c2VySWQsXG4gICAgICAgIHRhcmdldF90eXBlOiAndHJhY2snLFxuICAgICAgICB0YXJnZXRfaWQ6IHRyYWNrSWRcbiAgICAgIH0pKTtcblxuICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgnbm90aWZpY2F0aW9ucycpLmluc2VydChub3RpZmljYXRpb25zKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIG1lc3NhZ2U6ICdEaXN0cmlidXRpb24gcmVxdWVzdCBzdWJtaXR0ZWQnLFxuICAgICAgICBzdGF0dXM6ICdwZW5kaW5nX21vZGVyYXRpb24nXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignW3JlcXVlc3QtZGlzdHJpYnV0aW9uXSBFcnJvcjonLCBlcnJvcik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFNQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLFdBQVcsYUFDZixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0M7SUFHL0MsNERBQTREO0lBQzVELE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVk7TUFDZixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sUUFBUSxXQUFXLE9BQU8sQ0FBQyxXQUFXO0lBQzVDLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBRS9FLElBQUksZUFBZSxDQUFDLFlBQVksUUFBUSxLQUFLO01BQzNDLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxTQUFTLFdBQVcsTUFBTSxDQUFDLEdBQUc7SUFFcEMsTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUE2QixNQUFNLElBQUksSUFBSTtJQUM1RCxRQUFRLEdBQUcsQ0FBQyxDQUFDLDRCQUE0QixFQUFFLE9BQU8sb0NBQW9DLEVBQUUsUUFBUSxDQUFDO0lBRWpHLElBQUksQ0FBQyxTQUFTO01BQ1osTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxpQ0FBaUM7SUFDakMsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxTQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsS0FDUCxFQUFFLENBQUMsTUFBTSxTQUNULE1BQU07SUFFVCxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsSUFBSSxNQUFNLE9BQU8sS0FBSyxRQUFRO01BQzVCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsMkNBQTJDO0lBQzNDLElBQUksTUFBTSxtQkFBbUIsS0FBSyxRQUFRO01BQ3hDLE1BQU0sSUFBSSxNQUFNLENBQUMsMENBQTBDLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQyxDQUFDO0lBQzFGO0lBRUEsMEJBQTBCO0lBQzFCLElBQUksTUFBTSx1QkFBdUIsS0FBSyxTQUFTO01BQzdDLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsc0JBQXNCO0lBQ3RCLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO01BQ04scUJBQXFCO01BQ3JCLDJCQUEyQixJQUFJLE9BQU8sV0FBVztJQUNuRCxHQUNDLEVBQUUsQ0FBQyxNQUFNO0lBRVosSUFBSSxhQUFhO01BQ2YsTUFBTTtJQUNSO0lBRUEsa0JBQWtCO0lBQ2xCLE1BQU0sU0FBUyxJQUFJLENBQUMscUJBQXFCLE1BQU0sQ0FBQztNQUM5QyxVQUFVO01BQ1YsU0FBUztNQUNULFFBQVE7TUFDUixPQUFPO01BQ1AsU0FBUztRQUNQLGFBQWEsTUFBTSxLQUFLO1FBQ3hCLG1CQUFtQixNQUFNLHVCQUF1QjtNQUNsRDtJQUNGO0lBRUEsZ0JBQWdCO0lBQ2hCLE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxHQUFHLE1BQU0sU0FDNUIsSUFBSSxDQUFDLGNBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFFBQVE7TUFBQztNQUFTO01BQWU7S0FBWTtJQUVuRCxJQUFJLFFBQVE7TUFDVixNQUFNLGdCQUFnQixPQUFPLEdBQUcsQ0FBQyxDQUFBLFFBQVMsQ0FBQztVQUN6QyxTQUFTLE1BQU0sT0FBTztVQUN0QixNQUFNO1VBQ04sT0FBTztVQUNQLFNBQVMsQ0FBQyx5Q0FBeUMsRUFBRSxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7VUFDbkUsVUFBVTtVQUNWLGFBQWE7VUFDYixXQUFXO1FBQ2IsQ0FBQztNQUVELE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztJQUM5QztJQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULFNBQVM7TUFDVCxRQUFRO0lBQ1YsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLGlDQUFpQztJQUMvQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU8sT0FBTztJQUFRLElBQ2hEO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
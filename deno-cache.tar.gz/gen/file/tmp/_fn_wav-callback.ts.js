const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const payload = await req.json();
    console.log("WAV callback received:", JSON.stringify(payload));
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
    const { code, data, msg } = payload;
    // The API returns: { code: 200, data: { audio_wav_url: "...", task_id: "..." }, msg: "All generated successfully." }
    // Check for success by code 200 AND presence of audio_wav_url
    if (code === 200 && data?.audio_wav_url) {
      const wavUrl = data.audio_wav_url;
      const taskId = data.task_id;
      console.log(`WAV conversion success! taskId: ${taskId}, wavUrl: ${wavUrl}`);
      // Find the addon by task_id stored in result_url JSON
      const { data: addons } = await supabase.from("track_addons").select("id, track_id, result_url").eq("status", "processing").order("created_at", {
        ascending: false
      });
      let matchedAddon = null;
      // Find addon that matches the task_id
      if (addons && taskId) {
        for (const addon of addons){
          try {
            if (addon.result_url) {
              const resultData = typeof addon.result_url === 'string' ? JSON.parse(addon.result_url) : addon.result_url;
              if (resultData.wav_task_id === taskId) {
                matchedAddon = addon;
                break;
              }
            }
          } catch (e) {
            console.log("Error parsing result_url:", e);
          }
        }
      }
      // Fallback to most recent if no match found
      if (!matchedAddon && addons && addons.length > 0) {
        matchedAddon = addons[0];
        console.log("No task_id match, using most recent addon");
      }
      if (matchedAddon) {
        console.log(`Updating addon ${matchedAddon.id} with WAV URL`);
        await supabase.from("track_addons").update({
          status: "completed",
          result_url: wavUrl,
          updated_at: new Date().toISOString()
        }).eq("id", matchedAddon.id);
        // Also update the track with wav_url for easy access
        await supabase.from("tracks").update({
          wav_url: wavUrl,
          updated_at: new Date().toISOString()
        }).eq("id", matchedAddon.track_id);
        // Notify user
        const { data: track } = await supabase.from("tracks").select("user_id, title").eq("id", matchedAddon.track_id).maybeSingle();
        if (track) {
          await supabase.from("notifications").insert({
            user_id: track.user_id,
            type: "addon_completed",
            title: "WAV готов к скачиванию",
            message: `Трек "${track.title}" конвертирован в WAV формат. Нажмите для скачивания.`,
            target_type: "track",
            target_id: matchedAddon.track_id,
            metadata: {
              wav_url: wavUrl
            }
          });
        }
        console.log("WAV conversion completed and saved:", wavUrl);
      } else {
        console.error("No matching addon found for task:", taskId);
      }
    } else {
      console.error("WAV conversion failed or unexpected format:", payload);
    }
    return new Response(JSON.stringify({
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in wav-callback:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl93YXYtY2FsbGJhY2sudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBwYXlsb2FkID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhcIldBViBjYWxsYmFjayByZWNlaXZlZDpcIiwgSlNPTi5zdHJpbmdpZnkocGF5bG9hZCkpO1xuXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSFcbiAgICApO1xuXG4gICAgY29uc3QgeyBjb2RlLCBkYXRhLCBtc2cgfSA9IHBheWxvYWQ7XG5cbiAgICAvLyBUaGUgQVBJIHJldHVybnM6IHsgY29kZTogMjAwLCBkYXRhOiB7IGF1ZGlvX3dhdl91cmw6IFwiLi4uXCIsIHRhc2tfaWQ6IFwiLi4uXCIgfSwgbXNnOiBcIkFsbCBnZW5lcmF0ZWQgc3VjY2Vzc2Z1bGx5LlwiIH1cbiAgICAvLyBDaGVjayBmb3Igc3VjY2VzcyBieSBjb2RlIDIwMCBBTkQgcHJlc2VuY2Ugb2YgYXVkaW9fd2F2X3VybFxuICAgIGlmIChjb2RlID09PSAyMDAgJiYgZGF0YT8uYXVkaW9fd2F2X3VybCkge1xuICAgICAgY29uc3Qgd2F2VXJsID0gZGF0YS5hdWRpb193YXZfdXJsO1xuICAgICAgY29uc3QgdGFza0lkID0gZGF0YS50YXNrX2lkO1xuXG4gICAgICBjb25zb2xlLmxvZyhgV0FWIGNvbnZlcnNpb24gc3VjY2VzcyEgdGFza0lkOiAke3Rhc2tJZH0sIHdhdlVybDogJHt3YXZVcmx9YCk7XG5cbiAgICAgIC8vIEZpbmQgdGhlIGFkZG9uIGJ5IHRhc2tfaWQgc3RvcmVkIGluIHJlc3VsdF91cmwgSlNPTlxuICAgICAgY29uc3QgeyBkYXRhOiBhZGRvbnMgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgIC5zZWxlY3QoXCJpZCwgdHJhY2tfaWQsIHJlc3VsdF91cmxcIilcbiAgICAgICAgLmVxKFwic3RhdHVzXCIsIFwicHJvY2Vzc2luZ1wiKVxuICAgICAgICAub3JkZXIoXCJjcmVhdGVkX2F0XCIsIHsgYXNjZW5kaW5nOiBmYWxzZSB9KTtcblxuICAgICAgbGV0IG1hdGNoZWRBZGRvbiA9IG51bGw7XG5cbiAgICAgIC8vIEZpbmQgYWRkb24gdGhhdCBtYXRjaGVzIHRoZSB0YXNrX2lkXG4gICAgICBpZiAoYWRkb25zICYmIHRhc2tJZCkge1xuICAgICAgICBmb3IgKGNvbnN0IGFkZG9uIG9mIGFkZG9ucykge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoYWRkb24ucmVzdWx0X3VybCkge1xuICAgICAgICAgICAgICBjb25zdCByZXN1bHREYXRhID0gdHlwZW9mIGFkZG9uLnJlc3VsdF91cmwgPT09ICdzdHJpbmcnIFxuICAgICAgICAgICAgICAgID8gSlNPTi5wYXJzZShhZGRvbi5yZXN1bHRfdXJsKSBcbiAgICAgICAgICAgICAgICA6IGFkZG9uLnJlc3VsdF91cmw7XG4gICAgICAgICAgICAgIGlmIChyZXN1bHREYXRhLndhdl90YXNrX2lkID09PSB0YXNrSWQpIHtcbiAgICAgICAgICAgICAgICBtYXRjaGVkQWRkb24gPSBhZGRvbjtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgcGFyc2luZyByZXN1bHRfdXJsOlwiLCBlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gRmFsbGJhY2sgdG8gbW9zdCByZWNlbnQgaWYgbm8gbWF0Y2ggZm91bmRcbiAgICAgIGlmICghbWF0Y2hlZEFkZG9uICYmIGFkZG9ucyAmJiBhZGRvbnMubGVuZ3RoID4gMCkge1xuICAgICAgICBtYXRjaGVkQWRkb24gPSBhZGRvbnNbMF07XG4gICAgICAgIGNvbnNvbGUubG9nKFwiTm8gdGFza19pZCBtYXRjaCwgdXNpbmcgbW9zdCByZWNlbnQgYWRkb25cIik7XG4gICAgICB9XG5cbiAgICAgIGlmIChtYXRjaGVkQWRkb24pIHtcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0aW5nIGFkZG9uICR7bWF0Y2hlZEFkZG9uLmlkfSB3aXRoIFdBViBVUkxgKTtcbiAgICAgICAgXG4gICAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJ0cmFja19hZGRvbnNcIilcbiAgICAgICAgICAudXBkYXRlKHsgXG4gICAgICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgICByZXN1bHRfdXJsOiB3YXZVcmwsXG4gICAgICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgfSlcbiAgICAgICAgICAuZXEoXCJpZFwiLCBtYXRjaGVkQWRkb24uaWQpO1xuXG4gICAgICAgIC8vIEFsc28gdXBkYXRlIHRoZSB0cmFjayB3aXRoIHdhdl91cmwgZm9yIGVhc3kgYWNjZXNzXG4gICAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAudXBkYXRlKHsgXG4gICAgICAgICAgICB3YXZfdXJsOiB3YXZVcmwsXG4gICAgICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgfSlcbiAgICAgICAgICAuZXEoXCJpZFwiLCBtYXRjaGVkQWRkb24udHJhY2tfaWQpO1xuXG4gICAgICAgIC8vIE5vdGlmeSB1c2VyXG4gICAgICAgIGNvbnN0IHsgZGF0YTogdHJhY2sgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAuc2VsZWN0KFwidXNlcl9pZCwgdGl0bGVcIilcbiAgICAgICAgICAuZXEoXCJpZFwiLCBtYXRjaGVkQWRkb24udHJhY2tfaWQpXG4gICAgICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICAgICAgaWYgKHRyYWNrKSB7XG4gICAgICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcIm5vdGlmaWNhdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgICAgICAgIHVzZXJfaWQ6IHRyYWNrLnVzZXJfaWQsXG4gICAgICAgICAgICB0eXBlOiBcImFkZG9uX2NvbXBsZXRlZFwiLFxuICAgICAgICAgICAgdGl0bGU6IFwiV0FWINCz0L7RgtC+0LIg0Log0YHQutCw0YfQuNCy0LDQvdC40Y5cIixcbiAgICAgICAgICAgIG1lc3NhZ2U6IGDQotGA0LXQuiBcIiR7dHJhY2sudGl0bGV9XCIg0LrQvtC90LLQtdGA0YLQuNGA0L7QstCw0L0g0LIgV0FWINGE0L7RgNC80LDRgi4g0J3QsNC20LzQuNGC0LUg0LTQu9GPINGB0LrQsNGH0LjQstCw0L3QuNGPLmAsXG4gICAgICAgICAgICB0YXJnZXRfdHlwZTogXCJ0cmFja1wiLFxuICAgICAgICAgICAgdGFyZ2V0X2lkOiBtYXRjaGVkQWRkb24udHJhY2tfaWQsXG4gICAgICAgICAgICBtZXRhZGF0YTogeyB3YXZfdXJsOiB3YXZVcmwgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnNvbGUubG9nKFwiV0FWIGNvbnZlcnNpb24gY29tcGxldGVkIGFuZCBzYXZlZDpcIiwgd2F2VXJsKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJObyBtYXRjaGluZyBhZGRvbiBmb3VuZCBmb3IgdGFzazpcIiwgdGFza0lkKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY29uc29sZS5lcnJvcihcIldBViBjb252ZXJzaW9uIGZhaWxlZCBvciB1bmV4cGVjdGVkIGZvcm1hdDpcIiwgcGF5bG9hZCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IHRydWUgfSksIHtcbiAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIHdhdi1jYWxsYmFjazpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBtZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLFVBQVUsTUFBTSxJQUFJLElBQUk7SUFDOUIsUUFBUSxHQUFHLENBQUMsMEJBQTBCLEtBQUssU0FBUyxDQUFDO0lBRXJELE1BQU0sV0FBVyxhQUNmLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxpQkFDYixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFHZixNQUFNLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRztJQUU1QixxSEFBcUg7SUFDckgsOERBQThEO0lBQzlELElBQUksU0FBUyxPQUFPLE1BQU0sZUFBZTtNQUN2QyxNQUFNLFNBQVMsS0FBSyxhQUFhO01BQ2pDLE1BQU0sU0FBUyxLQUFLLE9BQU87TUFFM0IsUUFBUSxHQUFHLENBQUMsQ0FBQyxnQ0FBZ0MsRUFBRSxPQUFPLFVBQVUsRUFBRSxPQUFPLENBQUM7TUFFMUUsc0RBQXNEO01BQ3RELE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxHQUFHLE1BQU0sU0FDNUIsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyw0QkFDUCxFQUFFLENBQUMsVUFBVSxjQUNiLEtBQUssQ0FBQyxjQUFjO1FBQUUsV0FBVztNQUFNO01BRTFDLElBQUksZUFBZTtNQUVuQixzQ0FBc0M7TUFDdEMsSUFBSSxVQUFVLFFBQVE7UUFDcEIsS0FBSyxNQUFNLFNBQVMsT0FBUTtVQUMxQixJQUFJO1lBQ0YsSUFBSSxNQUFNLFVBQVUsRUFBRTtjQUNwQixNQUFNLGFBQWEsT0FBTyxNQUFNLFVBQVUsS0FBSyxXQUMzQyxLQUFLLEtBQUssQ0FBQyxNQUFNLFVBQVUsSUFDM0IsTUFBTSxVQUFVO2NBQ3BCLElBQUksV0FBVyxXQUFXLEtBQUssUUFBUTtnQkFDckMsZUFBZTtnQkFDZjtjQUNGO1lBQ0Y7VUFDRixFQUFFLE9BQU8sR0FBRztZQUNWLFFBQVEsR0FBRyxDQUFDLDZCQUE2QjtVQUMzQztRQUNGO01BQ0Y7TUFFQSw0Q0FBNEM7TUFDNUMsSUFBSSxDQUFDLGdCQUFnQixVQUFVLE9BQU8sTUFBTSxHQUFHLEdBQUc7UUFDaEQsZUFBZSxNQUFNLENBQUMsRUFBRTtRQUN4QixRQUFRLEdBQUcsQ0FBQztNQUNkO01BRUEsSUFBSSxjQUFjO1FBQ2hCLFFBQVEsR0FBRyxDQUFDLENBQUMsZUFBZSxFQUFFLGFBQWEsRUFBRSxDQUFDLGFBQWEsQ0FBQztRQUU1RCxNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztVQUNOLFFBQVE7VUFDUixZQUFZO1VBQ1osWUFBWSxJQUFJLE9BQU8sV0FBVztRQUNwQyxHQUNDLEVBQUUsQ0FBQyxNQUFNLGFBQWEsRUFBRTtRQUUzQixxREFBcUQ7UUFDckQsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztVQUNOLFNBQVM7VUFDVCxZQUFZLElBQUksT0FBTyxXQUFXO1FBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sYUFBYSxRQUFRO1FBRWpDLGNBQWM7UUFDZCxNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsR0FBRyxNQUFNLFNBQzNCLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxrQkFDUCxFQUFFLENBQUMsTUFBTSxhQUFhLFFBQVEsRUFDOUIsV0FBVztRQUVkLElBQUksT0FBTztVQUNULE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztZQUMxQyxTQUFTLE1BQU0sT0FBTztZQUN0QixNQUFNO1lBQ04sT0FBTztZQUNQLFNBQVMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUMscURBQXFELENBQUM7WUFDcEYsYUFBYTtZQUNiLFdBQVcsYUFBYSxRQUFRO1lBQ2hDLFVBQVU7Y0FBRSxTQUFTO1lBQU87VUFDOUI7UUFDRjtRQUVBLFFBQVEsR0FBRyxDQUFDLHVDQUF1QztNQUNyRCxPQUFPO1FBQ0wsUUFBUSxLQUFLLENBQUMscUNBQXFDO01BQ3JEO0lBQ0YsT0FBTztNQUNMLFFBQVEsS0FBSyxDQUFDLCtDQUErQztJQUMvRDtJQUVBLE9BQU8sSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztJQUFLLElBQUk7TUFDckQsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUNoRTtFQUNGLEVBQUUsT0FBTyxPQUFnQjtJQUN2QixRQUFRLEtBQUssQ0FBQywwQkFBMEI7SUFDeEMsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFRLElBQ2hDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
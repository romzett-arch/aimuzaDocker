const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// YooKassa configuration - ADD YOUR KEYS HERE
const YOOKASSA_SHOP_ID = Deno.env.get("YOOKASSA_SHOP_ID") || "";
const YOOKASSA_SECRET_KEY = Deno.env.get("YOOKASSA_SECRET_KEY") || "";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Необходима авторизация");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      throw new Error("Неверный токен авторизации");
    }
    const { amount, description, return_url } = await req.json();
    if (!amount || amount < 1) {
      throw new Error("Сумма должна быть больше 0");
    }
    // Create payment record
    const { data: payment, error: paymentError } = await supabase.from("payments").insert({
      user_id: user.id,
      amount: amount,
      currency: "RUB",
      status: "pending",
      payment_system: "yookassa",
      description: description || `Пополнение баланса на ${amount} ₽`
    }).select().single();
    if (paymentError) {
      throw new Error("Ошибка создания платежа: " + paymentError.message);
    }
    // Create YooKassa payment
    const idempotenceKey = crypto.randomUUID();
    const yooKassaPayment = {
      amount: {
        value: amount.toFixed(2),
        currency: "RUB"
      },
      capture: true,
      confirmation: {
        type: "redirect",
        return_url: return_url || `${req.headers.get("origin")}/profile?payment=success`
      },
      description: description || `Пополнение баланса на ${amount} ₽`,
      metadata: {
        payment_id: payment.id,
        user_id: user.id
      }
    };
    const response = await fetch("https://api.yookassa.ru/v3/payments", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Idempotence-Key": idempotenceKey,
        "Authorization": `Basic ${btoa(`${YOOKASSA_SHOP_ID}:${YOOKASSA_SECRET_KEY}`)}`
      },
      body: JSON.stringify(yooKassaPayment)
    });
    if (!response.ok) {
      const error = await response.text();
      console.error("YooKassa API error:", error);
      throw new Error("Ошибка создания платежа в YooKassa");
    }
    const yooKassaResponse = await response.json();
    // Update payment with external ID
    await supabase.from("payments").update({
      external_id: yooKassaResponse.id,
      metadata: yooKassaResponse
    }).eq("id", payment.id);
    return new Response(JSON.stringify({
      success: true,
      payment_id: payment.id,
      payment_url: yooKassaResponse.confirmation.confirmation_url
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 200
    });
  } catch (error) {
    console.error("YooKassa create error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 400
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl95b29rYXNzYS1jcmVhdGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbi8vIFlvb0thc3NhIGNvbmZpZ3VyYXRpb24gLSBBREQgWU9VUiBLRVlTIEhFUkVcbmNvbnN0IFlPT0tBU1NBX1NIT1BfSUQgPSBEZW5vLmVudi5nZXQoXCJZT09LQVNTQV9TSE9QX0lEXCIpIHx8IFwiXCI7XG5jb25zdCBZT09LQVNTQV9TRUNSRVRfS0VZID0gRGVuby5lbnYuZ2V0KFwiWU9PS0FTU0FfU0VDUkVUX0tFWVwiKSB8fCBcIlwiO1xuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC10L7QsdGF0L7QtNC40LzQsCDQsNCy0YLQvtGA0LjQt9Cw0YbQuNGPXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHRva2VuID0gYXV0aEhlYWRlci5yZXBsYWNlKFwiQmVhcmVyIFwiLCBcIlwiKTtcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9LCBlcnJvcjogYXV0aEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIodG9rZW4pO1xuICAgIFxuICAgIGlmIChhdXRoRXJyb3IgfHwgIXVzZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCd0LXQstC10YDQvdGL0Lkg0YLQvtC60LXQvSDQsNCy0YLQvtGA0LjQt9Cw0YbQuNC4XCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHsgYW1vdW50LCBkZXNjcmlwdGlvbiwgcmV0dXJuX3VybCB9ID0gYXdhaXQgcmVxLmpzb24oKTtcblxuICAgIGlmICghYW1vdW50IHx8IGFtb3VudCA8IDEpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCh0YPQvNC80LAg0LTQvtC70LbQvdCwINCx0YvRgtGMINCx0L7Qu9GM0YjQtSAwXCIpO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZSBwYXltZW50IHJlY29yZFxuICAgIGNvbnN0IHsgZGF0YTogcGF5bWVudCwgZXJyb3I6IHBheW1lbnRFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicGF5bWVudHNcIilcbiAgICAgIC5pbnNlcnQoe1xuICAgICAgICB1c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgICBhbW91bnQ6IGFtb3VudCxcbiAgICAgICAgY3VycmVuY3k6IFwiUlVCXCIsXG4gICAgICAgIHN0YXR1czogXCJwZW5kaW5nXCIsXG4gICAgICAgIHBheW1lbnRfc3lzdGVtOiBcInlvb2thc3NhXCIsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbiB8fCBg0J/QvtC/0L7Qu9C90LXQvdC40LUg0LHQsNC70LDQvdGB0LAg0L3QsCAke2Ftb3VudH0g4oK9YCxcbiAgICAgIH0pXG4gICAgICAuc2VsZWN0KClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmIChwYXltZW50RXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCe0YjQuNCx0LrQsCDRgdC+0LfQtNCw0L3QuNGPINC/0LvQsNGC0LXQttCwOiBcIiArIHBheW1lbnRFcnJvci5tZXNzYWdlKTtcbiAgICB9XG5cbiAgICAvLyBDcmVhdGUgWW9vS2Fzc2EgcGF5bWVudFxuICAgIGNvbnN0IGlkZW1wb3RlbmNlS2V5ID0gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICBcbiAgICBjb25zdCB5b29LYXNzYVBheW1lbnQgPSB7XG4gICAgICBhbW91bnQ6IHtcbiAgICAgICAgdmFsdWU6IGFtb3VudC50b0ZpeGVkKDIpLFxuICAgICAgICBjdXJyZW5jeTogXCJSVUJcIixcbiAgICAgIH0sXG4gICAgICBjYXB0dXJlOiB0cnVlLFxuICAgICAgY29uZmlybWF0aW9uOiB7XG4gICAgICAgIHR5cGU6IFwicmVkaXJlY3RcIixcbiAgICAgICAgcmV0dXJuX3VybDogcmV0dXJuX3VybCB8fCBgJHtyZXEuaGVhZGVycy5nZXQoXCJvcmlnaW5cIil9L3Byb2ZpbGU/cGF5bWVudD1zdWNjZXNzYCxcbiAgICAgIH0sXG4gICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24gfHwgYNCf0L7Qv9C+0LvQvdC10L3QuNC1INCx0LDQu9Cw0L3RgdCwINC90LAgJHthbW91bnR9IOKCvWAsXG4gICAgICBtZXRhZGF0YToge1xuICAgICAgICBwYXltZW50X2lkOiBwYXltZW50LmlkLFxuICAgICAgICB1c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgfSxcbiAgICB9O1xuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcImh0dHBzOi8vYXBpLnlvb2thc3NhLnJ1L3YzL3BheW1lbnRzXCIsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBcIklkZW1wb3RlbmNlLUtleVwiOiBpZGVtcG90ZW5jZUtleSxcbiAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCYXNpYyAke2J0b2EoYCR7WU9PS0FTU0FfU0hPUF9JRH06JHtZT09LQVNTQV9TRUNSRVRfS0VZfWApfWAsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeW9vS2Fzc2FQYXltZW50KSxcbiAgICB9KTtcblxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIGNvbnN0IGVycm9yID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICAgICAgY29uc29sZS5lcnJvcihcIllvb0thc3NhIEFQSSBlcnJvcjpcIiwgZXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwi0J7RiNC40LHQutCwINGB0L7Qt9C00LDQvdC40Y8g0L/Qu9Cw0YLQtdC20LAg0LIgWW9vS2Fzc2FcIik7XG4gICAgfVxuXG4gICAgY29uc3QgeW9vS2Fzc2FSZXNwb25zZSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcblxuICAgIC8vIFVwZGF0ZSBwYXltZW50IHdpdGggZXh0ZXJuYWwgSURcbiAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwYXltZW50c1wiKVxuICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICBleHRlcm5hbF9pZDogeW9vS2Fzc2FSZXNwb25zZS5pZCxcbiAgICAgICAgbWV0YWRhdGE6IHlvb0thc3NhUmVzcG9uc2UsXG4gICAgICB9KVxuICAgICAgLmVxKFwiaWRcIiwgcGF5bWVudC5pZCk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICBwYXltZW50X2lkOiBwYXltZW50LmlkLFxuICAgICAgICBwYXltZW50X3VybDogeW9vS2Fzc2FSZXNwb25zZS5jb25maXJtYXRpb24uY29uZmlybWF0aW9uX3VybCxcbiAgICAgIH0pLFxuICAgICAge1xuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgICBzdGF0dXM6IDIwMCxcbiAgICAgIH1cbiAgICApO1xuICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJZb29LYXNzYSBjcmVhdGUgZXJyb3I6XCIsIGVycm9yKTtcbiAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHtcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgICAgc3RhdHVzOiA0MDAsXG4gICAgICB9XG4gICAgKTtcbiAgfVxufSk7Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsOENBQThDO0FBQzlDLE1BQU0sbUJBQW1CLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUI7QUFDN0QsTUFBTSxzQkFBc0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLDBCQUEwQjtBQUVuRSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVk7TUFDZixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sUUFBUSxXQUFXLE9BQU8sQ0FBQyxXQUFXO0lBQzVDLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLFNBQVMsSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUV6RSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLEdBQUcsTUFBTSxJQUFJLElBQUk7SUFFMUQsSUFBSSxDQUFDLFVBQVUsU0FBUyxHQUFHO01BQ3pCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsd0JBQXdCO0lBQ3hCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbEQsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO01BQ04sU0FBUyxLQUFLLEVBQUU7TUFDaEIsUUFBUTtNQUNSLFVBQVU7TUFDVixRQUFRO01BQ1IsZ0JBQWdCO01BQ2hCLGFBQWEsZUFBZSxDQUFDLHNCQUFzQixFQUFFLE9BQU8sRUFBRSxDQUFDO0lBQ2pFLEdBQ0MsTUFBTSxHQUNOLE1BQU07SUFFVCxJQUFJLGNBQWM7TUFDaEIsTUFBTSxJQUFJLE1BQU0sOEJBQThCLGFBQWEsT0FBTztJQUNwRTtJQUVBLDBCQUEwQjtJQUMxQixNQUFNLGlCQUFpQixPQUFPLFVBQVU7SUFFeEMsTUFBTSxrQkFBa0I7TUFDdEIsUUFBUTtRQUNOLE9BQU8sT0FBTyxPQUFPLENBQUM7UUFDdEIsVUFBVTtNQUNaO01BQ0EsU0FBUztNQUNULGNBQWM7UUFDWixNQUFNO1FBQ04sWUFBWSxjQUFjLENBQUMsRUFBRSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSx3QkFBd0IsQ0FBQztNQUNsRjtNQUNBLGFBQWEsZUFBZSxDQUFDLHNCQUFzQixFQUFFLE9BQU8sRUFBRSxDQUFDO01BQy9ELFVBQVU7UUFDUixZQUFZLFFBQVEsRUFBRTtRQUN0QixTQUFTLEtBQUssRUFBRTtNQUNsQjtJQUNGO0lBRUEsTUFBTSxXQUFXLE1BQU0sTUFBTSx1Q0FBdUM7TUFDbEUsUUFBUTtNQUNSLFNBQVM7UUFDUCxnQkFBZ0I7UUFDaEIsbUJBQW1CO1FBQ25CLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRSxpQkFBaUIsQ0FBQyxFQUFFLG9CQUFvQixDQUFDLEVBQUUsQ0FBQztNQUNoRjtNQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7SUFDdkI7SUFFQSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7TUFDaEIsTUFBTSxRQUFRLE1BQU0sU0FBUyxJQUFJO01BQ2pDLFFBQVEsS0FBSyxDQUFDLHVCQUF1QjtNQUNyQyxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxJQUFJO0lBRTVDLGtDQUFrQztJQUNsQyxNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO01BQ04sYUFBYSxpQkFBaUIsRUFBRTtNQUNoQyxVQUFVO0lBQ1osR0FDQyxFQUFFLENBQUMsTUFBTSxRQUFRLEVBQUU7SUFFdEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsWUFBWSxRQUFRLEVBQUU7TUFDdEIsYUFBYSxpQkFBaUIsWUFBWSxDQUFDLGdCQUFnQjtJQUM3RCxJQUNBO01BQ0UsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtNQUM5RCxRQUFRO0lBQ1Y7RUFFSixFQUFFLE9BQU8sT0FBZ0I7SUFDdkIsUUFBUSxLQUFLLENBQUMsMEJBQTBCO0lBQ3hDLE1BQU0sVUFBVSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUN6RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBUSxJQUNoQztNQUNFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7TUFDOUQsUUFBUTtJQUNWO0VBRUo7QUFDRiJ9
/**
 * arena-lifecycle — Deno Edge Function
 * Вызывается по cron (каждые 5 минут) или вручную (admin)
 * Обрабатывает:
 *  1. Переход active → voting (по end_date)
 *  2. Автофинализация voting → completed
 *  3. Обновление статусов сезонов
 *  4. Создание daily challenge (если нет активного)
 *  5. Сброс weekly_points по понедельникам
 */ const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") || Deno.env.get("API_URL") || "http://api:3000";
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SERVICE_ROLE_KEY") || "";
    const supabase = createClient(supabaseUrl, supabaseKey, {
      auth: {
        persistSession: false
      }
    });
    const results = [];
    // 1. Process contest lifecycle (active→voting→completed, seasons)
    const { data: lifecycleCount, error: lcErr } = await supabase.rpc("process_contest_lifecycle");
    if (lcErr) {
      results.push(`lifecycle error: ${lcErr.message}`);
    } else {
      results.push(`lifecycle processed: ${lifecycleCount} contests`);
    }
    // 2. Create daily challenge if none exists
    const today = new Date();
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const todayEnd = new Date(todayStart.getTime() + 24 * 60 * 60 * 1000);
    const votingEnd = new Date(todayEnd.getTime() + 12 * 60 * 60 * 1000); // +12h for voting
    const { data: existingDaily } = await supabase.from("contests").select("id").eq("contest_type", "daily").gte("start_date", todayStart.toISOString()).limit(1);
    if (!existingDaily || existingDaily.length === 0) {
      // Get random theme for today
      const themes = [
        "Утренняя энергия",
        "Ночной вайб",
        "Дорожное приключение",
        "Мечтательное настроение",
        "Танцевальный бит",
        "Лирическая история",
        "Ретро волна",
        "Электронный рассвет",
        "Акустическая душа",
        "Городской ритм",
        "Космическое путешествие",
        "Летний закат",
        "Зимняя сказка",
        "Весеннее пробуждение",
        "Осенняя меланхолия",
        "Любовная серенада",
        "Бунтарский дух",
        "Тихая гавань",
        "Неоновые огни",
        "Свободный полёт"
      ];
      const theme = themes[today.getDate() % themes.length];
      const dayOfWeek = [
        "Вс",
        "Пн",
        "Вт",
        "Ср",
        "Чт",
        "Пт",
        "Сб"
      ][today.getDay()];
      const dayNum = today.getDate();
      const monthNames = [
        "янв",
        "фев",
        "мар",
        "апр",
        "мая",
        "июн",
        "июл",
        "авг",
        "сен",
        "окт",
        "ноя",
        "дек"
      ];
      const { error: createErr } = await supabase.from("contests").insert({
        title: `Daily Challenge: ${theme}`,
        description: `Ежедневный вызов ${dayNum} ${monthNames[today.getMonth()]}. Создайте трек на тему «${theme}» и победите!`,
        contest_type: "daily",
        status: "active",
        start_date: todayStart.toISOString(),
        end_date: todayEnd.toISOString(),
        voting_end_date: votingEnd.toISOString(),
        theme,
        prize_amount: 50,
        prize_pool_formula: "fixed",
        prize_distribution: [
          0.6,
          0.3,
          0.1
        ],
        max_entries_per_user: 1,
        entry_fee: 0,
        min_participants: 3,
        auto_finalize: true,
        require_new_track: true,
        scoring_mode: "votes",
        created_by: null
      });
      if (createErr) {
        results.push(`daily create error: ${createErr.message}`);
      } else {
        results.push(`daily challenge created: ${theme}`);
      }
    } else {
      results.push("daily challenge already exists");
    }
    // 3. Weekly reset (Monday at 00:00)
    if (today.getDay() === 1 && today.getHours() < 1) {
      const { error: resetErr } = await supabase.from("contest_ratings").update({
        weekly_points: 0
      }).gt("weekly_points", 0);
      if (resetErr) {
        results.push(`weekly reset error: ${resetErr.message}`);
      } else {
        results.push("weekly points reset");
      }
    }
    // 4. Check achievements for recently active users
    const { data: recentEntries } = await supabase.from("contest_entries").select("user_id").gte("created_at", new Date(Date.now() - 10 * 60 * 1000).toISOString()).limit(50);
    if (recentEntries && recentEntries.length > 0) {
      const uniqueUsers = [
        ...new Set(recentEntries.map((e)=>e.user_id))
      ];
      let achievementsAwarded = 0;
      for (const uid of uniqueUsers){
        const { data: count } = await supabase.rpc("check_contest_achievements", {
          p_user_id: uid
        });
        achievementsAwarded += count || 0;
      }
      results.push(`achievements checked for ${uniqueUsers.length} users, awarded ${achievementsAwarded}`);
    }
    return new Response(JSON.stringify({
      ok: true,
      results,
      timestamp: new Date().toISOString()
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 200
    });
  } catch (err) {
    return new Response(JSON.stringify({
      ok: false,
      error: String(err)
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 500
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9hcmVuYS1saWZlY3ljbGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIGFyZW5hLWxpZmVjeWNsZSDigJQgRGVubyBFZGdlIEZ1bmN0aW9uXHJcbiAqINCS0YvQt9GL0LLQsNC10YLRgdGPINC/0L4gY3JvbiAo0LrQsNC20LTRi9C1IDUg0LzQuNC90YPRgikg0LjQu9C4INCy0YDRg9GH0L3Rg9GOIChhZG1pbilcclxuICog0J7QsdGA0LDQsdCw0YLRi9Cy0LDQtdGCOlxyXG4gKiAgMS4g0J/QtdGA0LXRhdC+0LQgYWN0aXZlIOKGkiB2b3RpbmcgKNC/0L4gZW5kX2RhdGUpXHJcbiAqICAyLiDQkNCy0YLQvtGE0LjQvdCw0LvQuNC30LDRhtC40Y8gdm90aW5nIOKGkiBjb21wbGV0ZWRcclxuICogIDMuINCe0LHQvdC+0LLQu9C10L3QuNC1INGB0YLQsNGC0YPRgdC+0LIg0YHQtdC30L7QvdC+0LJcclxuICogIDQuINCh0L7Qt9C00LDQvdC40LUgZGFpbHkgY2hhbGxlbmdlICjQtdGB0LvQuCDQvdC10YIg0LDQutGC0LjQstC90L7Qs9C+KVxyXG4gKiAgNS4g0KHQsdGA0L7RgSB3ZWVrbHlfcG9pbnRzINC/0L4g0L/QvtC90LXQtNC10LvRjNC90LjQutCw0LxcclxuICovXHJcblxyXG5jb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XHJcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xyXG5cclxuY29uc3QgY29yc0hlYWRlcnMgPSB7XHJcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXHJcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGVcIixcclxufTtcclxuXHJcbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcclxuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcclxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXCJva1wiLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpIHx8IERlbm8uZW52LmdldChcIkFQSV9VUkxcIikgfHwgXCJodHRwOi8vYXBpOjMwMDBcIjtcclxuICAgIGNvbnN0IHN1cGFiYXNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSB8fCBEZW5vLmVudi5nZXQoXCJTRVJWSUNFX1JPTEVfS0VZXCIpIHx8IFwiXCI7XHJcblxyXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlS2V5LCB7XHJcbiAgICAgIGF1dGg6IHsgcGVyc2lzdFNlc3Npb246IGZhbHNlIH0sXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCByZXN1bHRzOiBzdHJpbmdbXSA9IFtdO1xyXG5cclxuICAgIC8vIDEuIFByb2Nlc3MgY29udGVzdCBsaWZlY3ljbGUgKGFjdGl2ZeKGknZvdGluZ+KGkmNvbXBsZXRlZCwgc2Vhc29ucylcclxuICAgIGNvbnN0IHsgZGF0YTogbGlmZWN5Y2xlQ291bnQsIGVycm9yOiBsY0VyciB9ID0gYXdhaXQgc3VwYWJhc2UucnBjKFwicHJvY2Vzc19jb250ZXN0X2xpZmVjeWNsZVwiKTtcclxuICAgIGlmIChsY0Vycikge1xyXG4gICAgICByZXN1bHRzLnB1c2goYGxpZmVjeWNsZSBlcnJvcjogJHtsY0Vyci5tZXNzYWdlfWApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmVzdWx0cy5wdXNoKGBsaWZlY3ljbGUgcHJvY2Vzc2VkOiAke2xpZmVjeWNsZUNvdW50fSBjb250ZXN0c2ApO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIDIuIENyZWF0ZSBkYWlseSBjaGFsbGVuZ2UgaWYgbm9uZSBleGlzdHNcclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IHRvZGF5U3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCB0b2RheS5nZXREYXRlKCkpO1xyXG4gICAgY29uc3QgdG9kYXlFbmQgPSBuZXcgRGF0ZSh0b2RheVN0YXJ0LmdldFRpbWUoKSArIDI0ICogNjAgKiA2MCAqIDEwMDApO1xyXG4gICAgY29uc3Qgdm90aW5nRW5kID0gbmV3IERhdGUodG9kYXlFbmQuZ2V0VGltZSgpICsgMTIgKiA2MCAqIDYwICogMTAwMCk7IC8vICsxMmggZm9yIHZvdGluZ1xyXG5cclxuICAgIGNvbnN0IHsgZGF0YTogZXhpc3RpbmdEYWlseSB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgLmZyb20oXCJjb250ZXN0c1wiKVxyXG4gICAgICAuc2VsZWN0KFwiaWRcIilcclxuICAgICAgLmVxKFwiY29udGVzdF90eXBlXCIsIFwiZGFpbHlcIilcclxuICAgICAgLmd0ZShcInN0YXJ0X2RhdGVcIiwgdG9kYXlTdGFydC50b0lTT1N0cmluZygpKVxyXG4gICAgICAubGltaXQoMSk7XHJcblxyXG4gICAgaWYgKCFleGlzdGluZ0RhaWx5IHx8IGV4aXN0aW5nRGFpbHkubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIC8vIEdldCByYW5kb20gdGhlbWUgZm9yIHRvZGF5XHJcbiAgICAgIGNvbnN0IHRoZW1lcyA9IFtcclxuICAgICAgICBcItCj0YLRgNC10L3QvdGP0Y8g0Y3QvdC10YDQs9C40Y9cIiwgXCLQndC+0YfQvdC+0Lkg0LLQsNC50LFcIiwgXCLQlNC+0YDQvtC20L3QvtC1INC/0YDQuNC60LvRjtGH0LXQvdC40LVcIixcclxuICAgICAgICBcItCc0LXRh9GC0LDRgtC10LvRjNC90L7QtSDQvdCw0YHRgtGA0L7QtdC90LjQtVwiLCBcItCi0LDQvdGG0LXQstCw0LvRjNC90YvQuSDQsdC40YJcIiwgXCLQm9C40YDQuNGH0LXRgdC60LDRjyDQuNGB0YLQvtGA0LjRj1wiLFxyXG4gICAgICAgIFwi0KDQtdGC0YDQviDQstC+0LvQvdCwXCIsIFwi0K3Qu9C10LrRgtGA0L7QvdC90YvQuSDRgNCw0YHRgdCy0LXRglwiLCBcItCQ0LrRg9GB0YLQuNGH0LXRgdC60LDRjyDQtNGD0YjQsFwiLFxyXG4gICAgICAgIFwi0JPQvtGA0L7QtNGB0LrQvtC5INGA0LjRgtC8XCIsIFwi0JrQvtGB0LzQuNGH0LXRgdC60L7QtSDQv9GD0YLQtdGI0LXRgdGC0LLQuNC1XCIsIFwi0JvQtdGC0L3QuNC5INC30LDQutCw0YJcIixcclxuICAgICAgICBcItCX0LjQvNC90Y/RjyDRgdC60LDQt9C60LBcIiwgXCLQktC10YHQtdC90L3QtdC1INC/0YDQvtCx0YPQttC00LXQvdC40LVcIiwgXCLQntGB0LXQvdC90Y/RjyDQvNC10LvQsNC90YXQvtC70LjRj1wiLFxyXG4gICAgICAgIFwi0JvRjtCx0L7QstC90LDRjyDRgdC10YDQtdC90LDQtNCwXCIsIFwi0JHRg9C90YLQsNGA0YHQutC40Lkg0LTRg9GFXCIsIFwi0KLQuNGF0LDRjyDQs9Cw0LLQsNC90YxcIixcclxuICAgICAgICBcItCd0LXQvtC90L7QstGL0LUg0L7Qs9C90LhcIiwgXCLQodCy0L7QsdC+0LTQvdGL0Lkg0L/QvtC70ZHRglwiLFxyXG4gICAgICBdO1xyXG4gICAgICBjb25zdCB0aGVtZSA9IHRoZW1lc1t0b2RheS5nZXREYXRlKCkgJSB0aGVtZXMubGVuZ3RoXTtcclxuICAgICAgY29uc3QgZGF5T2ZXZWVrID0gW1wi0JLRgVwiLCBcItCf0L1cIiwgXCLQktGCXCIsIFwi0KHRgFwiLCBcItCn0YJcIiwgXCLQn9GCXCIsIFwi0KHQsVwiXVt0b2RheS5nZXREYXkoKV07XHJcbiAgICAgIGNvbnN0IGRheU51bSA9IHRvZGF5LmdldERhdGUoKTtcclxuICAgICAgY29uc3QgbW9udGhOYW1lcyA9IFtcItGP0L3QslwiLCBcItGE0LXQslwiLCBcItC80LDRgFwiLCBcItCw0L/RgFwiLCBcItC80LDRj1wiLCBcItC40Y7QvVwiLCBcItC40Y7Qu1wiLCBcItCw0LLQs1wiLCBcItGB0LXQvVwiLCBcItC+0LrRglwiLCBcItC90L7Rj1wiLCBcItC00LXQulwiXTtcclxuXHJcbiAgICAgIGNvbnN0IHsgZXJyb3I6IGNyZWF0ZUVyciB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgICAuZnJvbShcImNvbnRlc3RzXCIpXHJcbiAgICAgICAgLmluc2VydCh7XHJcbiAgICAgICAgICB0aXRsZTogYERhaWx5IENoYWxsZW5nZTogJHt0aGVtZX1gLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IGDQldC20LXQtNC90LXQstC90YvQuSDQstGL0LfQvtCyICR7ZGF5TnVtfSAke21vbnRoTmFtZXNbdG9kYXkuZ2V0TW9udGgoKV19LiDQodC+0LfQtNCw0LnRgtC1INGC0YDQtdC6INC90LAg0YLQtdC80YMgwqske3RoZW1lfcK7INC4INC/0L7QsdC10LTQuNGC0LUhYCxcclxuICAgICAgICAgIGNvbnRlc3RfdHlwZTogXCJkYWlseVwiLFxyXG4gICAgICAgICAgc3RhdHVzOiBcImFjdGl2ZVwiLFxyXG4gICAgICAgICAgc3RhcnRfZGF0ZTogdG9kYXlTdGFydC50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgZW5kX2RhdGU6IHRvZGF5RW5kLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgICB2b3RpbmdfZW5kX2RhdGU6IHZvdGluZ0VuZC50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgdGhlbWUsXHJcbiAgICAgICAgICBwcml6ZV9hbW91bnQ6IDUwLFxyXG4gICAgICAgICAgcHJpemVfcG9vbF9mb3JtdWxhOiBcImZpeGVkXCIsXHJcbiAgICAgICAgICBwcml6ZV9kaXN0cmlidXRpb246IFswLjYsIDAuMywgMC4xXSxcclxuICAgICAgICAgIG1heF9lbnRyaWVzX3Blcl91c2VyOiAxLFxyXG4gICAgICAgICAgZW50cnlfZmVlOiAwLFxyXG4gICAgICAgICAgbWluX3BhcnRpY2lwYW50czogMyxcclxuICAgICAgICAgIGF1dG9fZmluYWxpemU6IHRydWUsXHJcbiAgICAgICAgICByZXF1aXJlX25ld190cmFjazogdHJ1ZSxcclxuICAgICAgICAgIHNjb3JpbmdfbW9kZTogXCJ2b3Rlc1wiLFxyXG4gICAgICAgICAgY3JlYXRlZF9ieTogbnVsbCxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgIGlmIChjcmVhdGVFcnIpIHtcclxuICAgICAgICByZXN1bHRzLnB1c2goYGRhaWx5IGNyZWF0ZSBlcnJvcjogJHtjcmVhdGVFcnIubWVzc2FnZX1gKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXN1bHRzLnB1c2goYGRhaWx5IGNoYWxsZW5nZSBjcmVhdGVkOiAke3RoZW1lfWApO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXN1bHRzLnB1c2goXCJkYWlseSBjaGFsbGVuZ2UgYWxyZWFkeSBleGlzdHNcIik7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gMy4gV2Vla2x5IHJlc2V0IChNb25kYXkgYXQgMDA6MDApXHJcbiAgICBpZiAodG9kYXkuZ2V0RGF5KCkgPT09IDEgJiYgdG9kYXkuZ2V0SG91cnMoKSA8IDEpIHtcclxuICAgICAgY29uc3QgeyBlcnJvcjogcmVzZXRFcnIgfSA9IGF3YWl0IHN1cGFiYXNlXHJcbiAgICAgICAgLmZyb20oXCJjb250ZXN0X3JhdGluZ3NcIilcclxuICAgICAgICAudXBkYXRlKHsgd2Vla2x5X3BvaW50czogMCB9KVxyXG4gICAgICAgIC5ndChcIndlZWtseV9wb2ludHNcIiwgMCk7XHJcblxyXG4gICAgICBpZiAocmVzZXRFcnIpIHtcclxuICAgICAgICByZXN1bHRzLnB1c2goYHdlZWtseSByZXNldCBlcnJvcjogJHtyZXNldEVyci5tZXNzYWdlfWApO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlc3VsdHMucHVzaChcIndlZWtseSBwb2ludHMgcmVzZXRcIik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyA0LiBDaGVjayBhY2hpZXZlbWVudHMgZm9yIHJlY2VudGx5IGFjdGl2ZSB1c2Vyc1xyXG4gICAgY29uc3QgeyBkYXRhOiByZWNlbnRFbnRyaWVzIH0gPSBhd2FpdCBzdXBhYmFzZVxyXG4gICAgICAuZnJvbShcImNvbnRlc3RfZW50cmllc1wiKVxyXG4gICAgICAuc2VsZWN0KFwidXNlcl9pZFwiKVxyXG4gICAgICAuZ3RlKFwiY3JlYXRlZF9hdFwiLCBuZXcgRGF0ZShEYXRlLm5vdygpIC0gMTAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKCkpXHJcbiAgICAgIC5saW1pdCg1MCk7XHJcblxyXG4gICAgaWYgKHJlY2VudEVudHJpZXMgJiYgcmVjZW50RW50cmllcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGNvbnN0IHVuaXF1ZVVzZXJzID0gWy4uLm5ldyBTZXQocmVjZW50RW50cmllcy5tYXAoKGU6IGFueSkgPT4gZS51c2VyX2lkKSldO1xyXG4gICAgICBsZXQgYWNoaWV2ZW1lbnRzQXdhcmRlZCA9IDA7XHJcbiAgICAgIGZvciAoY29uc3QgdWlkIG9mIHVuaXF1ZVVzZXJzKSB7XHJcbiAgICAgICAgY29uc3QgeyBkYXRhOiBjb3VudCB9ID0gYXdhaXQgc3VwYWJhc2UucnBjKFwiY2hlY2tfY29udGVzdF9hY2hpZXZlbWVudHNcIiwgeyBwX3VzZXJfaWQ6IHVpZCB9KTtcclxuICAgICAgICBhY2hpZXZlbWVudHNBd2FyZGVkICs9IChjb3VudCB8fCAwKTtcclxuICAgICAgfVxyXG4gICAgICByZXN1bHRzLnB1c2goYGFjaGlldmVtZW50cyBjaGVja2VkIGZvciAke3VuaXF1ZVVzZXJzLmxlbmd0aH0gdXNlcnMsIGF3YXJkZWQgJHthY2hpZXZlbWVudHNBd2FyZGVkfWApO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXHJcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgb2s6IHRydWUsIHJlc3VsdHMsIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0pLFxyXG4gICAgICB7XHJcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcclxuICAgICAgICBzdGF0dXM6IDIwMCxcclxuICAgICAgfVxyXG4gICAgKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXHJcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgb2s6IGZhbHNlLCBlcnJvcjogU3RyaW5nKGVycikgfSksXHJcbiAgICAgIHtcclxuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxyXG4gICAgICAgIHN0YXR1czogNTAwLFxyXG4gICAgICB9XHJcbiAgICApO1xyXG4gIH1cclxufSk7XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7O0NBU0MsR0FFRCxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBQ25GLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxjQUFjO0lBQy9FLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUI7SUFFckcsTUFBTSxXQUFXLGFBQWEsYUFBYSxhQUFhO01BQ3RELE1BQU07UUFBRSxnQkFBZ0I7TUFBTTtJQUNoQztJQUVBLE1BQU0sVUFBb0IsRUFBRTtJQUU1QixrRUFBa0U7SUFDbEUsTUFBTSxFQUFFLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSyxFQUFFLEdBQUcsTUFBTSxTQUFTLEdBQUcsQ0FBQztJQUNsRSxJQUFJLE9BQU87TUFDVCxRQUFRLElBQUksQ0FBQyxDQUFDLGlCQUFpQixFQUFFLE1BQU0sT0FBTyxDQUFDLENBQUM7SUFDbEQsT0FBTztNQUNMLFFBQVEsSUFBSSxDQUFDLENBQUMscUJBQXFCLEVBQUUsZUFBZSxTQUFTLENBQUM7SUFDaEU7SUFFQSwyQ0FBMkM7SUFDM0MsTUFBTSxRQUFRLElBQUk7SUFDbEIsTUFBTSxhQUFhLElBQUksS0FBSyxNQUFNLFdBQVcsSUFBSSxNQUFNLFFBQVEsSUFBSSxNQUFNLE9BQU87SUFDaEYsTUFBTSxXQUFXLElBQUksS0FBSyxXQUFXLE9BQU8sS0FBSyxLQUFLLEtBQUssS0FBSztJQUNoRSxNQUFNLFlBQVksSUFBSSxLQUFLLFNBQVMsT0FBTyxLQUFLLEtBQUssS0FBSyxLQUFLLE9BQU8sa0JBQWtCO0lBRXhGLE1BQU0sRUFBRSxNQUFNLGFBQWEsRUFBRSxHQUFHLE1BQU0sU0FDbkMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLE1BQ1AsRUFBRSxDQUFDLGdCQUFnQixTQUNuQixHQUFHLENBQUMsY0FBYyxXQUFXLFdBQVcsSUFDeEMsS0FBSyxDQUFDO0lBRVQsSUFBSSxDQUFDLGlCQUFpQixjQUFjLE1BQU0sS0FBSyxHQUFHO01BQ2hELDZCQUE2QjtNQUM3QixNQUFNLFNBQVM7UUFDYjtRQUFvQjtRQUFlO1FBQ25DO1FBQTJCO1FBQW9CO1FBQy9DO1FBQWU7UUFBdUI7UUFDdEM7UUFBa0I7UUFBMkI7UUFDN0M7UUFBaUI7UUFBd0I7UUFDekM7UUFBcUI7UUFBa0I7UUFDdkM7UUFBaUI7T0FDbEI7TUFDRCxNQUFNLFFBQVEsTUFBTSxDQUFDLE1BQU0sT0FBTyxLQUFLLE9BQU8sTUFBTSxDQUFDO01BQ3JELE1BQU0sWUFBWTtRQUFDO1FBQU07UUFBTTtRQUFNO1FBQU07UUFBTTtRQUFNO09BQUssQ0FBQyxNQUFNLE1BQU0sR0FBRztNQUM1RSxNQUFNLFNBQVMsTUFBTSxPQUFPO01BQzVCLE1BQU0sYUFBYTtRQUFDO1FBQU87UUFBTztRQUFPO1FBQU87UUFBTztRQUFPO1FBQU87UUFBTztRQUFPO1FBQU87UUFBTztPQUFNO01BRXZHLE1BQU0sRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FDaEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1FBQ04sT0FBTyxDQUFDLGlCQUFpQixFQUFFLE1BQU0sQ0FBQztRQUNsQyxhQUFhLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLEVBQUUsVUFBVSxDQUFDLE1BQU0sUUFBUSxHQUFHLENBQUMseUJBQXlCLEVBQUUsTUFBTSxhQUFhLENBQUM7UUFDdkgsY0FBYztRQUNkLFFBQVE7UUFDUixZQUFZLFdBQVcsV0FBVztRQUNsQyxVQUFVLFNBQVMsV0FBVztRQUM5QixpQkFBaUIsVUFBVSxXQUFXO1FBQ3RDO1FBQ0EsY0FBYztRQUNkLG9CQUFvQjtRQUNwQixvQkFBb0I7VUFBQztVQUFLO1VBQUs7U0FBSTtRQUNuQyxzQkFBc0I7UUFDdEIsV0FBVztRQUNYLGtCQUFrQjtRQUNsQixlQUFlO1FBQ2YsbUJBQW1CO1FBQ25CLGNBQWM7UUFDZCxZQUFZO01BQ2Q7TUFFRixJQUFJLFdBQVc7UUFDYixRQUFRLElBQUksQ0FBQyxDQUFDLG9CQUFvQixFQUFFLFVBQVUsT0FBTyxDQUFDLENBQUM7TUFDekQsT0FBTztRQUNMLFFBQVEsSUFBSSxDQUFDLENBQUMseUJBQXlCLEVBQUUsTUFBTSxDQUFDO01BQ2xEO0lBQ0YsT0FBTztNQUNMLFFBQVEsSUFBSSxDQUFDO0lBQ2Y7SUFFQSxvQ0FBb0M7SUFDcEMsSUFBSSxNQUFNLE1BQU0sT0FBTyxLQUFLLE1BQU0sUUFBUSxLQUFLLEdBQUc7TUFDaEQsTUFBTSxFQUFFLE9BQU8sUUFBUSxFQUFFLEdBQUcsTUFBTSxTQUMvQixJQUFJLENBQUMsbUJBQ0wsTUFBTSxDQUFDO1FBQUUsZUFBZTtNQUFFLEdBQzFCLEVBQUUsQ0FBQyxpQkFBaUI7TUFFdkIsSUFBSSxVQUFVO1FBQ1osUUFBUSxJQUFJLENBQUMsQ0FBQyxvQkFBb0IsRUFBRSxTQUFTLE9BQU8sQ0FBQyxDQUFDO01BQ3hELE9BQU87UUFDTCxRQUFRLElBQUksQ0FBQztNQUNmO0lBQ0Y7SUFFQSxrREFBa0Q7SUFDbEQsTUFBTSxFQUFFLE1BQU0sYUFBYSxFQUFFLEdBQUcsTUFBTSxTQUNuQyxJQUFJLENBQUMsbUJBQ0wsTUFBTSxDQUFDLFdBQ1AsR0FBRyxDQUFDLGNBQWMsSUFBSSxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssS0FBSyxNQUFNLFdBQVcsSUFDbkUsS0FBSyxDQUFDO0lBRVQsSUFBSSxpQkFBaUIsY0FBYyxNQUFNLEdBQUcsR0FBRztNQUM3QyxNQUFNLGNBQWM7V0FBSSxJQUFJLElBQUksY0FBYyxHQUFHLENBQUMsQ0FBQyxJQUFXLEVBQUUsT0FBTztPQUFHO01BQzFFLElBQUksc0JBQXNCO01BQzFCLEtBQUssTUFBTSxPQUFPLFlBQWE7UUFDN0IsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLEdBQUcsTUFBTSxTQUFTLEdBQUcsQ0FBQyw4QkFBOEI7VUFBRSxXQUFXO1FBQUk7UUFDMUYsdUJBQXdCLFNBQVM7TUFDbkM7TUFDQSxRQUFRLElBQUksQ0FBQyxDQUFDLHlCQUF5QixFQUFFLFlBQVksTUFBTSxDQUFDLGdCQUFnQixFQUFFLG9CQUFvQixDQUFDO0lBQ3JHO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxJQUFJO01BQU07TUFBUyxXQUFXLElBQUksT0FBTyxXQUFXO0lBQUcsSUFDeEU7TUFDRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO01BQzlELFFBQVE7SUFDVjtFQUVKLEVBQUUsT0FBTyxLQUFLO0lBQ1osT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxJQUFJO01BQU8sT0FBTyxPQUFPO0lBQUssSUFDL0M7TUFDRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO01BQzlELFFBQVE7SUFDVjtFQUVKO0FBQ0YifQ==
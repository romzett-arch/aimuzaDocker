const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type"
};
const SITE_URL = "https://aiplanetsound.lovable.app";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseKey);
    // Fetch all visible topics (limited to 5000 for performance)
    const { data: topics, error: topicsError } = await supabase.from("forum_topics").select("id, updated_at, title").eq("is_hidden", false).order("updated_at", {
      ascending: false
    }).limit(5000);
    if (topicsError) {
      console.error("Error fetching topics:", topicsError);
      throw topicsError;
    }
    // Fetch categories
    const { data: categories, error: catsError } = await supabase.from("forum_categories").select("slug, updated_at").eq("is_active", true);
    if (catsError) {
      console.error("Error fetching categories:", catsError);
      throw catsError;
    }
    // Fetch tags
    const { data: tags, error: tagsError } = await supabase.from("forum_tags").select("name").gt("usage_count", 0);
    if (tagsError) {
      console.error("Error fetching tags:", tagsError);
    }
    // Build XML sitemap
    let xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${SITE_URL}/forum</loc>
    <changefreq>hourly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${SITE_URL}/forum/tags</loc>
    <changefreq>daily</changefreq>
    <priority>0.5</priority>
  </url>`;
    // Categories
    for (const cat of categories || []){
      xml += `
  <url>
    <loc>${SITE_URL}/forum/c/${cat.slug}</loc>
    <lastmod>${new Date(cat.updated_at).toISOString()}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.7</priority>
  </url>`;
    }
    // Topics
    for (const topic of topics || []){
      xml += `
  <url>
    <loc>${SITE_URL}/forum/t/${topic.id}</loc>
    <lastmod>${new Date(topic.updated_at).toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.6</priority>
  </url>`;
    }
    // Tags
    for (const tag of tags || []){
      xml += `
  <url>
    <loc>${SITE_URL}/forum/tag/${encodeURIComponent(tag.name)}</loc>
    <changefreq>weekly</changefreq>
    <priority>0.4</priority>
  </url>`;
    }
    xml += `
</urlset>`;
    console.log(`[forum-sitemap] Generated sitemap with ${categories?.length || 0} categories, ${topics?.length || 0} topics, ${tags?.length || 0} tags`);
    return new Response(xml, {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, max-age=3600"
      }
    });
  } catch (error) {
    console.error("[forum-sitemap] Error:", error);
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9mb3J1bS1zaXRlbWFwLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMi4zOS4zXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGVcIixcbn07XG5cbmNvbnN0IFNJVEVfVVJMID0gXCJodHRwczovL2FpcGxhbmV0c291bmQubG92YWJsZS5hcHBcIjtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFwib2tcIiwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlS2V5KTtcblxuICAgIC8vIEZldGNoIGFsbCB2aXNpYmxlIHRvcGljcyAobGltaXRlZCB0byA1MDAwIGZvciBwZXJmb3JtYW5jZSlcbiAgICBjb25zdCB7IGRhdGE6IHRvcGljcywgZXJyb3I6IHRvcGljc0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJmb3J1bV90b3BpY3NcIilcbiAgICAgIC5zZWxlY3QoXCJpZCwgdXBkYXRlZF9hdCwgdGl0bGVcIilcbiAgICAgIC5lcShcImlzX2hpZGRlblwiLCBmYWxzZSlcbiAgICAgIC5vcmRlcihcInVwZGF0ZWRfYXRcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAgICAubGltaXQoNTAwMCk7XG5cbiAgICBpZiAodG9waWNzRXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0b3BpY3M6XCIsIHRvcGljc0Vycm9yKTtcbiAgICAgIHRocm93IHRvcGljc0Vycm9yO1xuICAgIH1cblxuICAgIC8vIEZldGNoIGNhdGVnb3JpZXNcbiAgICBjb25zdCB7IGRhdGE6IGNhdGVnb3JpZXMsIGVycm9yOiBjYXRzRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImZvcnVtX2NhdGVnb3JpZXNcIilcbiAgICAgIC5zZWxlY3QoXCJzbHVnLCB1cGRhdGVkX2F0XCIpXG4gICAgICAuZXEoXCJpc19hY3RpdmVcIiwgdHJ1ZSk7XG5cbiAgICBpZiAoY2F0c0Vycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgY2F0ZWdvcmllczpcIiwgY2F0c0Vycm9yKTtcbiAgICAgIHRocm93IGNhdHNFcnJvcjtcbiAgICB9XG5cbiAgICAvLyBGZXRjaCB0YWdzXG4gICAgY29uc3QgeyBkYXRhOiB0YWdzLCBlcnJvcjogdGFnc0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJmb3J1bV90YWdzXCIpXG4gICAgICAuc2VsZWN0KFwibmFtZVwiKVxuICAgICAgLmd0KFwidXNhZ2VfY291bnRcIiwgMCk7XG5cbiAgICBpZiAodGFnc0Vycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFnczpcIiwgdGFnc0Vycm9yKTtcbiAgICB9XG5cbiAgICAvLyBCdWlsZCBYTUwgc2l0ZW1hcFxuICAgIGxldCB4bWwgPSBgPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+XG48dXJsc2V0IHhtbG5zPVwiaHR0cDovL3d3dy5zaXRlbWFwcy5vcmcvc2NoZW1hcy9zaXRlbWFwLzAuOVwiPlxuICA8dXJsPlxuICAgIDxsb2M+JHtTSVRFX1VSTH0vZm9ydW08L2xvYz5cbiAgICA8Y2hhbmdlZnJlcT5ob3VybHk8L2NoYW5nZWZyZXE+XG4gICAgPHByaW9yaXR5PjAuODwvcHJpb3JpdHk+XG4gIDwvdXJsPlxuICA8dXJsPlxuICAgIDxsb2M+JHtTSVRFX1VSTH0vZm9ydW0vdGFnczwvbG9jPlxuICAgIDxjaGFuZ2VmcmVxPmRhaWx5PC9jaGFuZ2VmcmVxPlxuICAgIDxwcmlvcml0eT4wLjU8L3ByaW9yaXR5PlxuICA8L3VybD5gO1xuXG4gICAgLy8gQ2F0ZWdvcmllc1xuICAgIGZvciAoY29uc3QgY2F0IG9mIGNhdGVnb3JpZXMgfHwgW10pIHtcbiAgICAgIHhtbCArPSBgXG4gIDx1cmw+XG4gICAgPGxvYz4ke1NJVEVfVVJMfS9mb3J1bS9jLyR7Y2F0LnNsdWd9PC9sb2M+XG4gICAgPGxhc3Rtb2Q+JHtuZXcgRGF0ZShjYXQudXBkYXRlZF9hdCkudG9JU09TdHJpbmcoKX08L2xhc3Rtb2Q+XG4gICAgPGNoYW5nZWZyZXE+ZGFpbHk8L2NoYW5nZWZyZXE+XG4gICAgPHByaW9yaXR5PjAuNzwvcHJpb3JpdHk+XG4gIDwvdXJsPmA7XG4gICAgfVxuXG4gICAgLy8gVG9waWNzXG4gICAgZm9yIChjb25zdCB0b3BpYyBvZiB0b3BpY3MgfHwgW10pIHtcbiAgICAgIHhtbCArPSBgXG4gIDx1cmw+XG4gICAgPGxvYz4ke1NJVEVfVVJMfS9mb3J1bS90LyR7dG9waWMuaWR9PC9sb2M+XG4gICAgPGxhc3Rtb2Q+JHtuZXcgRGF0ZSh0b3BpYy51cGRhdGVkX2F0KS50b0lTT1N0cmluZygpfTwvbGFzdG1vZD5cbiAgICA8Y2hhbmdlZnJlcT53ZWVrbHk8L2NoYW5nZWZyZXE+XG4gICAgPHByaW9yaXR5PjAuNjwvcHJpb3JpdHk+XG4gIDwvdXJsPmA7XG4gICAgfVxuXG4gICAgLy8gVGFnc1xuICAgIGZvciAoY29uc3QgdGFnIG9mIHRhZ3MgfHwgW10pIHtcbiAgICAgIHhtbCArPSBgXG4gIDx1cmw+XG4gICAgPGxvYz4ke1NJVEVfVVJMfS9mb3J1bS90YWcvJHtlbmNvZGVVUklDb21wb25lbnQodGFnLm5hbWUpfTwvbG9jPlxuICAgIDxjaGFuZ2VmcmVxPndlZWtseTwvY2hhbmdlZnJlcT5cbiAgICA8cHJpb3JpdHk+MC40PC9wcmlvcml0eT5cbiAgPC91cmw+YDtcbiAgICB9XG5cbiAgICB4bWwgKz0gYFxuPC91cmxzZXQ+YDtcblxuICAgIGNvbnNvbGUubG9nKGBbZm9ydW0tc2l0ZW1hcF0gR2VuZXJhdGVkIHNpdGVtYXAgd2l0aCAkeyhjYXRlZ29yaWVzPy5sZW5ndGggfHwgMCl9IGNhdGVnb3JpZXMsICR7KHRvcGljcz8ubGVuZ3RoIHx8IDApfSB0b3BpY3MsICR7KHRhZ3M/Lmxlbmd0aCB8fCAwKX0gdGFnc2ApO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZSh4bWwsIHtcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgLi4uY29yc0hlYWRlcnMsXG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24veG1sOyBjaGFyc2V0PXV0Zi04XCIsXG4gICAgICAgIFwiQ2FjaGUtQ29udHJvbFwiOiBcInB1YmxpYywgbWF4LWFnZT0zNjAwXCIsXG4gICAgICB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJbZm9ydW0tc2l0ZW1hcF0gRXJyb3I6XCIsIGVycm9yKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfSksIHtcbiAgICAgIHN0YXR1czogNTAwLFxuICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICB9KTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSw4Q0FBOEM7QUFFM0UsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLFdBQVc7QUFFakIsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0MsNkRBQTZEO0lBQzdELE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDaEQsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyx5QkFDUCxFQUFFLENBQUMsYUFBYSxPQUNoQixLQUFLLENBQUMsY0FBYztNQUFFLFdBQVc7SUFBTSxHQUN2QyxLQUFLLENBQUM7SUFFVCxJQUFJLGFBQWE7TUFDZixRQUFRLEtBQUssQ0FBQywwQkFBMEI7TUFDeEMsTUFBTTtJQUNSO0lBRUEsbUJBQW1CO0lBQ25CLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FDbEQsSUFBSSxDQUFDLG9CQUNMLE1BQU0sQ0FBQyxvQkFDUCxFQUFFLENBQUMsYUFBYTtJQUVuQixJQUFJLFdBQVc7TUFDYixRQUFRLEtBQUssQ0FBQyw4QkFBOEI7TUFDNUMsTUFBTTtJQUNSO0lBRUEsYUFBYTtJQUNiLE1BQU0sRUFBRSxNQUFNLElBQUksRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FDNUMsSUFBSSxDQUFDLGNBQ0wsTUFBTSxDQUFDLFFBQ1AsRUFBRSxDQUFDLGVBQWU7SUFFckIsSUFBSSxXQUFXO01BQ2IsUUFBUSxLQUFLLENBQUMsd0JBQXdCO0lBQ3hDO0lBRUEsb0JBQW9CO0lBQ3BCLElBQUksTUFBTSxDQUFDOzs7U0FHTixFQUFFLFNBQVM7Ozs7O1NBS1gsRUFBRSxTQUFTOzs7UUFHWixDQUFDO0lBRUwsYUFBYTtJQUNiLEtBQUssTUFBTSxPQUFPLGNBQWMsRUFBRSxDQUFFO01BQ2xDLE9BQU8sQ0FBQzs7U0FFTCxFQUFFLFNBQVMsU0FBUyxFQUFFLElBQUksSUFBSSxDQUFDO2FBQzNCLEVBQUUsSUFBSSxLQUFLLElBQUksVUFBVSxFQUFFLFdBQVcsR0FBRzs7O1FBRzlDLENBQUM7SUFDTDtJQUVBLFNBQVM7SUFDVCxLQUFLLE1BQU0sU0FBUyxVQUFVLEVBQUUsQ0FBRTtNQUNoQyxPQUFPLENBQUM7O1NBRUwsRUFBRSxTQUFTLFNBQVMsRUFBRSxNQUFNLEVBQUUsQ0FBQzthQUMzQixFQUFFLElBQUksS0FBSyxNQUFNLFVBQVUsRUFBRSxXQUFXLEdBQUc7OztRQUdoRCxDQUFDO0lBQ0w7SUFFQSxPQUFPO0lBQ1AsS0FBSyxNQUFNLE9BQU8sUUFBUSxFQUFFLENBQUU7TUFDNUIsT0FBTyxDQUFDOztTQUVMLEVBQUUsU0FBUyxXQUFXLEVBQUUsbUJBQW1CLElBQUksSUFBSSxFQUFFOzs7UUFHdEQsQ0FBQztJQUNMO0lBRUEsT0FBTyxDQUFDO1NBQ0gsQ0FBQztJQUVOLFFBQVEsR0FBRyxDQUFDLENBQUMsdUNBQXVDLEVBQUcsWUFBWSxVQUFVLEVBQUcsYUFBYSxFQUFHLFFBQVEsVUFBVSxFQUFHLFNBQVMsRUFBRyxNQUFNLFVBQVUsRUFBRyxLQUFLLENBQUM7SUFFMUosT0FBTyxJQUFJLFNBQVMsS0FBSztNQUN2QixTQUFTO1FBQ1AsR0FBRyxXQUFXO1FBQ2QsZ0JBQWdCO1FBQ2hCLGlCQUFpQjtNQUNuQjtJQUNGO0VBQ0YsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQywwQkFBMEI7SUFDeEMsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPLE1BQU0sT0FBTztJQUFDLElBQUk7TUFDNUQsUUFBUTtNQUNSLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFDaEU7RUFDRjtBQUNGIn0=
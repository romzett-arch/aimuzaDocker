const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // Security: Verify request comes from service role (internal calls only)
    const authHeader = req.headers.get("Authorization");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (authHeader !== `Bearer ${supabaseServiceKey}`) {
      return new Response(JSON.stringify({
        error: "Unauthorized - internal use only"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { track_id, task_id, audio_id } = await req.json();
    console.log("Get timestamped lyrics request:", {
      track_id,
      task_id,
      audio_id
    });
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    if (!SUNO_API_KEY) {
      throw new Error("SUNO_API_KEY not configured");
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), supabaseServiceKey);
    // Call Suno API to get timestamped lyrics
    const response = await fetch("https://api.sunoapi.org/api/v1/generate/get-timestamped-lyrics", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify({
        taskId: task_id,
        audioId: audio_id
      })
    });
    const result = await response.json();
    console.log("Suno Timestamped Lyrics API response:", result);
    if (result.code !== 200) {
      throw new Error(result.msg || "Failed to get timestamped lyrics");
    }
    // Store the result
    const { data: service } = await supabase.from("addon_services").select("id").eq("name", "timestamped_lyrics").maybeSingle();
    if (service && track_id) {
      await supabase.from("track_addons").insert({
        track_id,
        addon_service_id: service.id,
        status: "completed",
        result_url: JSON.stringify(result.data)
      });
    }
    return new Response(JSON.stringify({
      success: true,
      data: result.data
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in get-timestamped-lyrics:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9nZXQtdGltZXN0YW1wZWQtbHlyaWNzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgLy8gU2VjdXJpdHk6IFZlcmlmeSByZXF1ZXN0IGNvbWVzIGZyb20gc2VydmljZSByb2xlIChpbnRlcm5hbCBjYWxscyBvbmx5KVxuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIFxuICAgIGlmIChhdXRoSGVhZGVyICE9PSBgQmVhcmVyICR7c3VwYWJhc2VTZXJ2aWNlS2V5fWApIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkIC0gaW50ZXJuYWwgdXNlIG9ubHlcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHsgdHJhY2tfaWQsIHRhc2tfaWQsIGF1ZGlvX2lkIH0gPSBhd2FpdCByZXEuanNvbigpO1xuICAgIFxuICAgIGNvbnNvbGUubG9nKFwiR2V0IHRpbWVzdGFtcGVkIGx5cmljcyByZXF1ZXN0OlwiLCB7IHRyYWNrX2lkLCB0YXNrX2lkLCBhdWRpb19pZCB9KTtcblxuICAgIGNvbnN0IFNVTk9fQVBJX0tFWSA9IERlbm8uZW52LmdldChcIlNVTk9fQVBJX0tFWVwiKTtcbiAgICBpZiAoIVNVTk9fQVBJX0tFWSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiU1VOT19BUElfS0VZIG5vdCBjb25maWd1cmVkXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpISxcbiAgICAgIHN1cGFiYXNlU2VydmljZUtleVxuICAgICk7XG5cbiAgICAvLyBDYWxsIFN1bm8gQVBJIHRvIGdldCB0aW1lc3RhbXBlZCBseXJpY3NcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFwiaHR0cHM6Ly9hcGkuc3Vub2FwaS5vcmcvYXBpL3YxL2dlbmVyYXRlL2dldC10aW1lc3RhbXBlZC1seXJpY3NcIiwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0YXNrSWQ6IHRhc2tfaWQsXG4gICAgICAgIGF1ZGlvSWQ6IGF1ZGlvX2lkLFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJTdW5vIFRpbWVzdGFtcGVkIEx5cmljcyBBUEkgcmVzcG9uc2U6XCIsIHJlc3VsdCk7XG5cbiAgICBpZiAocmVzdWx0LmNvZGUgIT09IDIwMCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHJlc3VsdC5tc2cgfHwgXCJGYWlsZWQgdG8gZ2V0IHRpbWVzdGFtcGVkIGx5cmljc1wiKTtcbiAgICB9XG5cbiAgICAvLyBTdG9yZSB0aGUgcmVzdWx0XG4gICAgY29uc3QgeyBkYXRhOiBzZXJ2aWNlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJhZGRvbl9zZXJ2aWNlc1wiKVxuICAgICAgLnNlbGVjdChcImlkXCIpXG4gICAgICAuZXEoXCJuYW1lXCIsIFwidGltZXN0YW1wZWRfbHlyaWNzXCIpXG4gICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgIGlmIChzZXJ2aWNlICYmIHRyYWNrX2lkKSB7XG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwidHJhY2tfYWRkb25zXCIpLmluc2VydCh7XG4gICAgICAgIHRyYWNrX2lkLFxuICAgICAgICBhZGRvbl9zZXJ2aWNlX2lkOiBzZXJ2aWNlLmlkLFxuICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgIHJlc3VsdF91cmw6IEpTT04uc3RyaW5naWZ5KHJlc3VsdC5kYXRhKSxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgZGF0YTogcmVzdWx0LmRhdGEsXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gZ2V0LXRpbWVzdGFtcGVkLWx5cmljczpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBtZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRix5RUFBeUU7SUFDekUsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFFeEMsSUFBSSxlQUFlLENBQUMsT0FBTyxFQUFFLG1CQUFtQixDQUFDLEVBQUU7TUFDakQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQW1DLElBQzNEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxHQUFHLE1BQU0sSUFBSSxJQUFJO0lBRXRELFFBQVEsR0FBRyxDQUFDLG1DQUFtQztNQUFFO01BQVU7TUFBUztJQUFTO0lBRTdFLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbEMsSUFBSSxDQUFDLGNBQWM7TUFDakIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLFdBQVcsYUFDZixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsaUJBQ2I7SUFHRiwwQ0FBMEM7SUFDMUMsTUFBTSxXQUFXLE1BQU0sTUFBTSxrRUFBa0U7TUFDN0YsUUFBUTtNQUNSLFNBQVM7UUFDUCxnQkFBZ0I7UUFDaEIsaUJBQWlCLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQztNQUMzQztNQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7UUFDbkIsUUFBUTtRQUNSLFNBQVM7TUFDWDtJQUNGO0lBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0lBQ2xDLFFBQVEsR0FBRyxDQUFDLHlDQUF5QztJQUVyRCxJQUFJLE9BQU8sSUFBSSxLQUFLLEtBQUs7TUFDdkIsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHLElBQUk7SUFDaEM7SUFFQSxtQkFBbUI7SUFDbkIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxTQUM3QixJQUFJLENBQUMsa0JBQ0wsTUFBTSxDQUFDLE1BQ1AsRUFBRSxDQUFDLFFBQVEsc0JBQ1gsV0FBVztJQUVkLElBQUksV0FBVyxVQUFVO01BQ3ZCLE1BQU0sU0FBUyxJQUFJLENBQUMsZ0JBQWdCLE1BQU0sQ0FBQztRQUN6QztRQUNBLGtCQUFrQixRQUFRLEVBQUU7UUFDNUIsUUFBUTtRQUNSLFlBQVksS0FBSyxTQUFTLENBQUMsT0FBTyxJQUFJO01BQ3hDO0lBQ0Y7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxNQUFNLE9BQU8sSUFBSTtJQUNuQixJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRXRFLEVBQUUsT0FBTyxPQUFnQjtJQUN2QixRQUFRLEtBQUssQ0FBQyxvQ0FBb0M7SUFDbEQsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFRLElBQ2hDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
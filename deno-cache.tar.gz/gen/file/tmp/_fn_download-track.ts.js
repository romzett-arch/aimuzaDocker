const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const ffmpegApiUrl = Deno.env.get("FFMPEG_API_URL");
  const ffmpegApiSecret = Deno.env.get("FFMPEG_API_SECRET");
  try {
    // Validate auth
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Invalid token"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const userId = user.id;
    const body = await req.json();
    const { track_id, include_blockchain = false, stream = false } = body;
    if (!track_id) {
      return new Response(JSON.stringify({
        error: "track_id required"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log("Download track request:", {
      track_id,
      userId,
      include_blockchain,
      stream
    });
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Get track info
    const { data: track, error: trackError } = await supabase.from("tracks").select("id, user_id, title, audio_url, status, created_at").eq("id", track_id).single();
    if (trackError || !track) {
      return new Response(JSON.stringify({
        error: "Track not found"
      }), {
        status: 404,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Check ownership
    if (track.user_id !== userId) {
      return new Response(JSON.stringify({
        error: "Access denied - not your track"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (!track.audio_url) {
      return new Response(JSON.stringify({
        error: "Track has no audio"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Get user profile for artist name
    const { data: profile } = await supabase.from("profiles").select("username").eq("user_id", userId).single();
    const artistName = profile?.username || "AIMuza Artist";
    const shortUserId = userId.substring(0, 8);
    const createdDate = new Date(track.created_at).toISOString().split("T")[0];
    const safeTitle = track.title.replace(/[^a-zA-Zа-яА-Я0-9\s]/g, "_");
    const filename = `${safeTitle}.mp3`;
    // Prepare extended metadata
    const extendedMetadata = {
      title: track.title,
      artist: artistName,
      album: "AIMuza",
      publisher: "AIMuza",
      comment: `Generated with AIMuza - aimuza.ru | User: ${artistName} (${shortUserId}) | Date: ${createdDate}`,
      copyright: `© ${new Date().getFullYear()} ${artistName} via AIMuza`,
      custom: {
        TXXX_AIMUZA_USER_ID: userId,
        TXXX_AIMUZA_USERNAME: artistName,
        TXXX_AIMUZA_WEBSITE: "aimuza.ru",
        TXXX_AIMUZA_DATE: createdDate,
        TXXX_AIMUZA_TRACK_ID: track_id
      }
    };
    // If blockchain protection is requested, get deposit info
    let blockchainHash = null;
    if (include_blockchain) {
      const { data: deposit } = await supabase.from("track_deposits").select("metadata_hash, blockchain_tx_id, deposited_at").eq("track_id", track_id).eq("status", "completed").order("deposited_at", {
        ascending: false
      }).limit(1).single();
      if (deposit?.metadata_hash) {
        blockchainHash = deposit.metadata_hash;
        extendedMetadata.custom["TXXX_BLOCKCHAIN_HASH"] = deposit.metadata_hash;
        if (deposit.blockchain_tx_id) {
          extendedMetadata.custom["TXXX_BLOCKCHAIN_TX"] = deposit.blockchain_tx_id;
        }
        extendedMetadata.custom["TXXX_BLOCKCHAIN_DATE"] = deposit.deposited_at;
        extendedMetadata.comment += ` | Blockchain: ${deposit.metadata_hash.substring(0, 16)}...`;
      }
    }
    // If FFmpeg API is not configured, return/stream original
    if (!ffmpegApiUrl || !ffmpegApiSecret) {
      console.log("FFmpeg API not configured, returning original");
      if (stream) {
        return await proxyFile(track.audio_url, filename, corsHeaders);
      }
      return new Response(JSON.stringify({
        success: true,
        download_url: track.audio_url,
        filename,
        cleaned: false
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Call FFmpeg API for metadata cleaning
    console.log("Calling FFmpeg API for metadata cleaning...");
    const baseUrl = ffmpegApiUrl.replace(/\/(clean-metadata|analyze|normalize)\/?$/, "");
    const ffmpegResponse = await fetch(`${baseUrl}/clean-metadata`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ffmpegApiSecret
      },
      body: JSON.stringify({
        audio_url: track.audio_url,
        metadata: extendedMetadata
      })
    });
    if (!ffmpegResponse.ok) {
      const errorText = await ffmpegResponse.text();
      console.error("FFmpeg API error:", ffmpegResponse.status, errorText);
      // Fallback to original
      if (stream) {
        return await proxyFile(track.audio_url, filename, corsHeaders);
      }
      return new Response(JSON.stringify({
        success: true,
        download_url: track.audio_url,
        filename,
        cleaned: false,
        warning: "Metadata cleaning unavailable"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const ffmpegResult = await ffmpegResponse.json();
    console.log("FFmpeg API response:", ffmpegResult);
    const outputUrl = ffmpegResult.output_url || track.audio_url;
    const cleaned = !!ffmpegResult.output_url;
    // Increment download count
    await supabase.rpc("increment_download_count", {
      track_id
    });
    // Stream mode: proxy the file through edge function to avoid CORS
    if (stream) {
      console.log("Streaming file to client:", outputUrl);
      return await proxyFile(outputUrl, filename, corsHeaders);
    }
    // JSON mode (legacy)
    return new Response(JSON.stringify({
      success: true,
      download_url: outputUrl,
      filename,
      cleaned,
      metadata: {
        artist: artistName,
        user_id: shortUserId,
        date: createdDate,
        blockchain_protected: !!blockchainHash
      }
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in download-track:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
/**
 * Proxy a file URL through the edge function to avoid CORS issues.
 * Returns the file as binary with proper Content-Disposition header.
 */ async function proxyFile(url, filename, corsHeaders) {
  try {
    // Внутри Docker, localhost не доступен — заменяем на nginx hostname
    let internalUrl = url;
    if (url.includes('localhost')) {
      internalUrl = url.replace('http://localhost', 'http://nginx');
    }
    const fileResponse = await fetch(internalUrl);
    if (!fileResponse.ok) {
      throw new Error(`Failed to fetch file: ${fileResponse.status}`);
    }
    const fileData = await fileResponse.arrayBuffer();
    const encodedFilename = encodeURIComponent(filename);
    return new Response(fileData, {
      headers: {
        ...corsHeaders,
        "Content-Type": "audio/mpeg",
        "Content-Disposition": `attachment; filename="${encodedFilename}"; filename*=UTF-8''${encodedFilename}`,
        "Content-Length": String(fileData.byteLength)
      }
    });
  } catch (err) {
    console.error("Proxy file error:", err);
    return new Response(JSON.stringify({
      error: "Failed to proxy file"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9kb3dubG9hZC10cmFjay50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICBjb25zdCBzdXBhYmFzZUFub25LZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSE7XG4gIGNvbnN0IGZmbXBlZ0FwaVVybCA9IERlbm8uZW52LmdldChcIkZGTVBFR19BUElfVVJMXCIpO1xuICBjb25zdCBmZm1wZWdBcGlTZWNyZXQgPSBEZW5vLmVudi5nZXQoXCJGRk1QRUdfQVBJX1NFQ1JFVFwiKTtcblxuICB0cnkge1xuICAgIC8vIFZhbGlkYXRlIGF1dGhcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXI/LnN0YXJ0c1dpdGgoXCJCZWFyZXIgXCIpKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgdXNlckNsaWVudCA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VBbm9uS2V5LCB7XG4gICAgICBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfVxuICAgIH0pO1xuICAgIFxuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0sIGVycm9yOiB1c2VyRXJyb3IgfSA9IGF3YWl0IHVzZXJDbGllbnQuYXV0aC5nZXRVc2VyKCk7XG4gICAgXG4gICAgaWYgKHVzZXJFcnJvciB8fCAhdXNlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJJbnZhbGlkIHRva2VuXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG4gICAgXG4gICAgY29uc3QgdXNlcklkID0gdXNlci5pZDtcblxuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnN0IHsgdHJhY2tfaWQsIGluY2x1ZGVfYmxvY2tjaGFpbiA9IGZhbHNlLCBzdHJlYW0gPSBmYWxzZSB9ID0gYm9keTtcblxuICAgIGlmICghdHJhY2tfaWQpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwidHJhY2tfaWQgcmVxdWlyZWRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKFwiRG93bmxvYWQgdHJhY2sgcmVxdWVzdDpcIiwgeyB0cmFja19pZCwgdXNlcklkLCBpbmNsdWRlX2Jsb2NrY2hhaW4sIHN0cmVhbSB9KTtcblxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgLy8gR2V0IHRyYWNrIGluZm9cbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrLCBlcnJvcjogdHJhY2tFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAuc2VsZWN0KFwiaWQsIHVzZXJfaWQsIHRpdGxlLCBhdWRpb191cmwsIHN0YXR1cywgY3JlYXRlZF9hdFwiKVxuICAgICAgLmVxKFwiaWRcIiwgdHJhY2tfaWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAodHJhY2tFcnJvciB8fCAhdHJhY2spIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVHJhY2sgbm90IGZvdW5kXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDQsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBDaGVjayBvd25lcnNoaXBcbiAgICBpZiAodHJhY2sudXNlcl9pZCAhPT0gdXNlcklkKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkFjY2VzcyBkZW5pZWQgLSBub3QgeW91ciB0cmFja1wiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKCF0cmFjay5hdWRpb191cmwpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVHJhY2sgaGFzIG5vIGF1ZGlvXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgdXNlciBwcm9maWxlIGZvciBhcnRpc3QgbmFtZVxuICAgIGNvbnN0IHsgZGF0YTogcHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgIC5zZWxlY3QoXCJ1c2VybmFtZVwiKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBjb25zdCBhcnRpc3ROYW1lID0gcHJvZmlsZT8udXNlcm5hbWUgfHwgXCJBSU11emEgQXJ0aXN0XCI7XG4gICAgY29uc3Qgc2hvcnRVc2VySWQgPSB1c2VySWQuc3Vic3RyaW5nKDAsIDgpO1xuICAgIGNvbnN0IGNyZWF0ZWREYXRlID0gbmV3IERhdGUodHJhY2suY3JlYXRlZF9hdCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XG4gICAgY29uc3Qgc2FmZVRpdGxlID0gdHJhY2sudGl0bGUucmVwbGFjZSgvW15hLXpBLVrQsC3Rj9CQLdCvMC05XFxzXS9nLCBcIl9cIik7XG4gICAgY29uc3QgZmlsZW5hbWUgPSBgJHtzYWZlVGl0bGV9Lm1wM2A7XG5cbiAgICAvLyBQcmVwYXJlIGV4dGVuZGVkIG1ldGFkYXRhXG4gICAgY29uc3QgZXh0ZW5kZWRNZXRhZGF0YSA9IHtcbiAgICAgIHRpdGxlOiB0cmFjay50aXRsZSxcbiAgICAgIGFydGlzdDogYXJ0aXN0TmFtZSxcbiAgICAgIGFsYnVtOiBcIkFJTXV6YVwiLFxuICAgICAgcHVibGlzaGVyOiBcIkFJTXV6YVwiLFxuICAgICAgY29tbWVudDogYEdlbmVyYXRlZCB3aXRoIEFJTXV6YSAtIGFpbXV6YS5ydSB8IFVzZXI6ICR7YXJ0aXN0TmFtZX0gKCR7c2hvcnRVc2VySWR9KSB8IERhdGU6ICR7Y3JlYXRlZERhdGV9YCxcbiAgICAgIGNvcHlyaWdodDogYMKpICR7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfSAke2FydGlzdE5hbWV9IHZpYSBBSU11emFgLFxuICAgICAgY3VzdG9tOiB7XG4gICAgICAgIFRYWFhfQUlNVVpBX1VTRVJfSUQ6IHVzZXJJZCxcbiAgICAgICAgVFhYWF9BSU1VWkFfVVNFUk5BTUU6IGFydGlzdE5hbWUsXG4gICAgICAgIFRYWFhfQUlNVVpBX1dFQlNJVEU6IFwiYWltdXphLnJ1XCIsXG4gICAgICAgIFRYWFhfQUlNVVpBX0RBVEU6IGNyZWF0ZWREYXRlLFxuICAgICAgICBUWFhYX0FJTVVaQV9UUkFDS19JRDogdHJhY2tfaWQsXG4gICAgICB9IGFzIFJlY29yZDxzdHJpbmcsIHN0cmluZz4sXG4gICAgfTtcblxuICAgIC8vIElmIGJsb2NrY2hhaW4gcHJvdGVjdGlvbiBpcyByZXF1ZXN0ZWQsIGdldCBkZXBvc2l0IGluZm9cbiAgICBsZXQgYmxvY2tjaGFpbkhhc2g6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICAgIGlmIChpbmNsdWRlX2Jsb2NrY2hhaW4pIHtcbiAgICAgIGNvbnN0IHsgZGF0YTogZGVwb3NpdCB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJ0cmFja19kZXBvc2l0c1wiKVxuICAgICAgICAuc2VsZWN0KFwibWV0YWRhdGFfaGFzaCwgYmxvY2tjaGFpbl90eF9pZCwgZGVwb3NpdGVkX2F0XCIpXG4gICAgICAgIC5lcShcInRyYWNrX2lkXCIsIHRyYWNrX2lkKVxuICAgICAgICAuZXEoXCJzdGF0dXNcIiwgXCJjb21wbGV0ZWRcIilcbiAgICAgICAgLm9yZGVyKFwiZGVwb3NpdGVkX2F0XCIsIHsgYXNjZW5kaW5nOiBmYWxzZSB9KVxuICAgICAgICAubGltaXQoMSlcbiAgICAgICAgLnNpbmdsZSgpO1xuXG4gICAgICBpZiAoZGVwb3NpdD8ubWV0YWRhdGFfaGFzaCkge1xuICAgICAgICBibG9ja2NoYWluSGFzaCA9IGRlcG9zaXQubWV0YWRhdGFfaGFzaDtcbiAgICAgICAgZXh0ZW5kZWRNZXRhZGF0YS5jdXN0b21bXCJUWFhYX0JMT0NLQ0hBSU5fSEFTSFwiXSA9IGRlcG9zaXQubWV0YWRhdGFfaGFzaDtcbiAgICAgICAgaWYgKGRlcG9zaXQuYmxvY2tjaGFpbl90eF9pZCkge1xuICAgICAgICAgIGV4dGVuZGVkTWV0YWRhdGEuY3VzdG9tW1wiVFhYWF9CTE9DS0NIQUlOX1RYXCJdID0gZGVwb3NpdC5ibG9ja2NoYWluX3R4X2lkO1xuICAgICAgICB9XG4gICAgICAgIGV4dGVuZGVkTWV0YWRhdGEuY3VzdG9tW1wiVFhYWF9CTE9DS0NIQUlOX0RBVEVcIl0gPSBkZXBvc2l0LmRlcG9zaXRlZF9hdDtcbiAgICAgICAgZXh0ZW5kZWRNZXRhZGF0YS5jb21tZW50ICs9IGAgfCBCbG9ja2NoYWluOiAke2RlcG9zaXQubWV0YWRhdGFfaGFzaC5zdWJzdHJpbmcoMCwgMTYpfS4uLmA7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gSWYgRkZtcGVnIEFQSSBpcyBub3QgY29uZmlndXJlZCwgcmV0dXJuL3N0cmVhbSBvcmlnaW5hbFxuICAgIGlmICghZmZtcGVnQXBpVXJsIHx8ICFmZm1wZWdBcGlTZWNyZXQpIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiRkZtcGVnIEFQSSBub3QgY29uZmlndXJlZCwgcmV0dXJuaW5nIG9yaWdpbmFsXCIpO1xuICAgICAgaWYgKHN0cmVhbSkge1xuICAgICAgICByZXR1cm4gYXdhaXQgcHJveHlGaWxlKHRyYWNrLmF1ZGlvX3VybCwgZmlsZW5hbWUsIGNvcnNIZWFkZXJzKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgICAgZG93bmxvYWRfdXJsOiB0cmFjay5hdWRpb191cmwsXG4gICAgICAgICAgZmlsZW5hbWUsXG4gICAgICAgICAgY2xlYW5lZDogZmFsc2UsXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBDYWxsIEZGbXBlZyBBUEkgZm9yIG1ldGFkYXRhIGNsZWFuaW5nXG4gICAgY29uc29sZS5sb2coXCJDYWxsaW5nIEZGbXBlZyBBUEkgZm9yIG1ldGFkYXRhIGNsZWFuaW5nLi4uXCIpO1xuICAgIFxuICAgIGNvbnN0IGJhc2VVcmwgPSBmZm1wZWdBcGlVcmwhLnJlcGxhY2UoL1xcLyhjbGVhbi1tZXRhZGF0YXxhbmFseXplfG5vcm1hbGl6ZSlcXC8/JC8sIFwiXCIpO1xuICAgIGNvbnN0IGZmbXBlZ1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7YmFzZVVybH0vY2xlYW4tbWV0YWRhdGFgLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJ4LWFwaS1rZXlcIjogZmZtcGVnQXBpU2VjcmV0ISxcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIGF1ZGlvX3VybDogdHJhY2suYXVkaW9fdXJsLFxuICAgICAgICBtZXRhZGF0YTogZXh0ZW5kZWRNZXRhZGF0YSxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgaWYgKCFmZm1wZWdSZXNwb25zZS5vaykge1xuICAgICAgY29uc3QgZXJyb3JUZXh0ID0gYXdhaXQgZmZtcGVnUmVzcG9uc2UudGV4dCgpO1xuICAgICAgY29uc29sZS5lcnJvcihcIkZGbXBlZyBBUEkgZXJyb3I6XCIsIGZmbXBlZ1Jlc3BvbnNlLnN0YXR1cywgZXJyb3JUZXh0KTtcbiAgICAgIFxuICAgICAgLy8gRmFsbGJhY2sgdG8gb3JpZ2luYWxcbiAgICAgIGlmIChzdHJlYW0pIHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IHByb3h5RmlsZSh0cmFjay5hdWRpb191cmwsIGZpbGVuYW1lLCBjb3JzSGVhZGVycyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICAgIGRvd25sb2FkX3VybDogdHJhY2suYXVkaW9fdXJsLFxuICAgICAgICAgIGZpbGVuYW1lLFxuICAgICAgICAgIGNsZWFuZWQ6IGZhbHNlLFxuICAgICAgICAgIHdhcm5pbmc6IFwiTWV0YWRhdGEgY2xlYW5pbmcgdW5hdmFpbGFibGVcIixcbiAgICAgICAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGZmbXBlZ1Jlc3VsdCA9IGF3YWl0IGZmbXBlZ1Jlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhcIkZGbXBlZyBBUEkgcmVzcG9uc2U6XCIsIGZmbXBlZ1Jlc3VsdCk7XG5cbiAgICBjb25zdCBvdXRwdXRVcmwgPSBmZm1wZWdSZXN1bHQub3V0cHV0X3VybCB8fCB0cmFjay5hdWRpb191cmw7XG4gICAgY29uc3QgY2xlYW5lZCA9ICEhZmZtcGVnUmVzdWx0Lm91dHB1dF91cmw7XG5cbiAgICAvLyBJbmNyZW1lbnQgZG93bmxvYWQgY291bnRcbiAgICBhd2FpdCBzdXBhYmFzZS5ycGMoXCJpbmNyZW1lbnRfZG93bmxvYWRfY291bnRcIiwgeyB0cmFja19pZCB9KTtcblxuICAgIC8vIFN0cmVhbSBtb2RlOiBwcm94eSB0aGUgZmlsZSB0aHJvdWdoIGVkZ2UgZnVuY3Rpb24gdG8gYXZvaWQgQ09SU1xuICAgIGlmIChzdHJlYW0pIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiU3RyZWFtaW5nIGZpbGUgdG8gY2xpZW50OlwiLCBvdXRwdXRVcmwpO1xuICAgICAgcmV0dXJuIGF3YWl0IHByb3h5RmlsZShvdXRwdXRVcmwsIGZpbGVuYW1lLCBjb3JzSGVhZGVycyk7XG4gICAgfVxuXG4gICAgLy8gSlNPTiBtb2RlIChsZWdhY3kpXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICBkb3dubG9hZF91cmw6IG91dHB1dFVybCxcbiAgICAgICAgZmlsZW5hbWUsXG4gICAgICAgIGNsZWFuZWQsXG4gICAgICAgIG1ldGFkYXRhOiB7XG4gICAgICAgICAgYXJ0aXN0OiBhcnRpc3ROYW1lLFxuICAgICAgICAgIHVzZXJfaWQ6IHNob3J0VXNlcklkLFxuICAgICAgICAgIGRhdGU6IGNyZWF0ZWREYXRlLFxuICAgICAgICAgIGJsb2NrY2hhaW5fcHJvdGVjdGVkOiAhIWJsb2NrY2hhaW5IYXNoLFxuICAgICAgICB9XG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBkb3dubG9hZC10cmFjazpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBtZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG5cbi8qKlxuICogUHJveHkgYSBmaWxlIFVSTCB0aHJvdWdoIHRoZSBlZGdlIGZ1bmN0aW9uIHRvIGF2b2lkIENPUlMgaXNzdWVzLlxuICogUmV0dXJucyB0aGUgZmlsZSBhcyBiaW5hcnkgd2l0aCBwcm9wZXIgQ29udGVudC1EaXNwb3NpdGlvbiBoZWFkZXIuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIHByb3h5RmlsZShcbiAgdXJsOiBzdHJpbmcsIFxuICBmaWxlbmFtZTogc3RyaW5nLCBcbiAgY29yc0hlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz5cbik6IFByb21pc2U8UmVzcG9uc2U+IHtcbiAgdHJ5IHtcbiAgICAvLyDQktC90YPRgtGA0LggRG9ja2VyLCBsb2NhbGhvc3Qg0L3QtSDQtNC+0YHRgtGD0L/QtdC9IOKAlCDQt9Cw0LzQtdC90Y/QtdC8INC90LAgbmdpbnggaG9zdG5hbWVcbiAgICBsZXQgaW50ZXJuYWxVcmwgPSB1cmw7XG4gICAgaWYgKHVybC5pbmNsdWRlcygnbG9jYWxob3N0JykpIHtcbiAgICAgIGludGVybmFsVXJsID0gdXJsLnJlcGxhY2UoJ2h0dHA6Ly9sb2NhbGhvc3QnLCAnaHR0cDovL25naW54Jyk7XG4gICAgfVxuICAgIGNvbnN0IGZpbGVSZXNwb25zZSA9IGF3YWl0IGZldGNoKGludGVybmFsVXJsKTtcbiAgICBpZiAoIWZpbGVSZXNwb25zZS5vaykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gZmV0Y2ggZmlsZTogJHtmaWxlUmVzcG9uc2Uuc3RhdHVzfWApO1xuICAgIH1cblxuICAgIGNvbnN0IGZpbGVEYXRhID0gYXdhaXQgZmlsZVJlc3BvbnNlLmFycmF5QnVmZmVyKCk7XG4gICAgY29uc3QgZW5jb2RlZEZpbGVuYW1lID0gZW5jb2RlVVJJQ29tcG9uZW50KGZpbGVuYW1lKTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoZmlsZURhdGEsIHtcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgLi4uY29yc0hlYWRlcnMsXG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXVkaW8vbXBlZ1wiLFxuICAgICAgICBcIkNvbnRlbnQtRGlzcG9zaXRpb25cIjogYGF0dGFjaG1lbnQ7IGZpbGVuYW1lPVwiJHtlbmNvZGVkRmlsZW5hbWV9XCI7IGZpbGVuYW1lKj1VVEYtOCcnJHtlbmNvZGVkRmlsZW5hbWV9YCxcbiAgICAgICAgXCJDb250ZW50LUxlbmd0aFwiOiBTdHJpbmcoZmlsZURhdGEuYnl0ZUxlbmd0aCksXG4gICAgICB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiUHJveHkgZmlsZSBlcnJvcjpcIiwgZXJyKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJGYWlsZWQgdG8gcHJveHkgZmlsZVwiIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0VBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUN4QyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFDckMsTUFBTSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUNsQyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFFckMsSUFBSTtJQUNGLGdCQUFnQjtJQUNoQixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZLFdBQVcsWUFBWTtNQUN0QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGFBQWEsYUFBYSxhQUFhLGlCQUFpQjtNQUM1RCxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQ25EO0lBRUEsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sV0FBVyxJQUFJLENBQUMsT0FBTztJQUUxRSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFnQixJQUN4QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFNBQVMsS0FBSyxFQUFFO0lBRXRCLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtJQUMzQixNQUFNLEVBQUUsUUFBUSxFQUFFLHFCQUFxQixLQUFLLEVBQUUsU0FBUyxLQUFLLEVBQUUsR0FBRztJQUVqRSxJQUFJLENBQUMsVUFBVTtNQUNiLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFvQixJQUM1QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQywyQkFBMkI7TUFBRTtNQUFVO01BQVE7TUFBb0I7SUFBTztJQUV0RixNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLGlCQUFpQjtJQUNqQixNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxVQUFVLEVBQUUsR0FBRyxNQUFNLFNBQzlDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxxREFDUCxFQUFFLENBQUMsTUFBTSxVQUNULE1BQU07SUFFVCxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFrQixJQUMxQztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxrQkFBa0I7SUFDbEIsSUFBSSxNQUFNLE9BQU8sS0FBSyxRQUFRO01BQzVCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFpQyxJQUN6RDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxJQUFJLENBQUMsTUFBTSxTQUFTLEVBQUU7TUFDcEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQXFCLElBQzdDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLG1DQUFtQztJQUNuQyxNQUFNLEVBQUUsTUFBTSxPQUFPLEVBQUUsR0FBRyxNQUFNLFNBQzdCLElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQyxZQUNQLEVBQUUsQ0FBQyxXQUFXLFFBQ2QsTUFBTTtJQUVULE1BQU0sYUFBYSxTQUFTLFlBQVk7SUFDeEMsTUFBTSxjQUFjLE9BQU8sU0FBUyxDQUFDLEdBQUc7SUFDeEMsTUFBTSxjQUFjLElBQUksS0FBSyxNQUFNLFVBQVUsRUFBRSxXQUFXLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQzFFLE1BQU0sWUFBWSxNQUFNLEtBQUssQ0FBQyxPQUFPLENBQUMseUJBQXlCO0lBQy9ELE1BQU0sV0FBVyxDQUFDLEVBQUUsVUFBVSxJQUFJLENBQUM7SUFFbkMsNEJBQTRCO0lBQzVCLE1BQU0sbUJBQW1CO01BQ3ZCLE9BQU8sTUFBTSxLQUFLO01BQ2xCLFFBQVE7TUFDUixPQUFPO01BQ1AsV0FBVztNQUNYLFNBQVMsQ0FBQywwQ0FBMEMsRUFBRSxXQUFXLEVBQUUsRUFBRSxZQUFZLFVBQVUsRUFBRSxZQUFZLENBQUM7TUFDMUcsV0FBVyxDQUFDLEVBQUUsRUFBRSxJQUFJLE9BQU8sV0FBVyxHQUFHLENBQUMsRUFBRSxXQUFXLFdBQVcsQ0FBQztNQUNuRSxRQUFRO1FBQ04scUJBQXFCO1FBQ3JCLHNCQUFzQjtRQUN0QixxQkFBcUI7UUFDckIsa0JBQWtCO1FBQ2xCLHNCQUFzQjtNQUN4QjtJQUNGO0lBRUEsMERBQTBEO0lBQzFELElBQUksaUJBQWdDO0lBQ3BDLElBQUksb0JBQW9CO01BQ3RCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxHQUFHLE1BQU0sU0FDN0IsSUFBSSxDQUFDLGtCQUNMLE1BQU0sQ0FBQyxpREFDUCxFQUFFLENBQUMsWUFBWSxVQUNmLEVBQUUsQ0FBQyxVQUFVLGFBQ2IsS0FBSyxDQUFDLGdCQUFnQjtRQUFFLFdBQVc7TUFBTSxHQUN6QyxLQUFLLENBQUMsR0FDTixNQUFNO01BRVQsSUFBSSxTQUFTLGVBQWU7UUFDMUIsaUJBQWlCLFFBQVEsYUFBYTtRQUN0QyxpQkFBaUIsTUFBTSxDQUFDLHVCQUF1QixHQUFHLFFBQVEsYUFBYTtRQUN2RSxJQUFJLFFBQVEsZ0JBQWdCLEVBQUU7VUFDNUIsaUJBQWlCLE1BQU0sQ0FBQyxxQkFBcUIsR0FBRyxRQUFRLGdCQUFnQjtRQUMxRTtRQUNBLGlCQUFpQixNQUFNLENBQUMsdUJBQXVCLEdBQUcsUUFBUSxZQUFZO1FBQ3RFLGlCQUFpQixPQUFPLElBQUksQ0FBQyxlQUFlLEVBQUUsUUFBUSxhQUFhLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUM7TUFDM0Y7SUFDRjtJQUVBLDBEQUEwRDtJQUMxRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCO01BQ3JDLFFBQVEsR0FBRyxDQUFDO01BQ1osSUFBSSxRQUFRO1FBQ1YsT0FBTyxNQUFNLFVBQVUsTUFBTSxTQUFTLEVBQUUsVUFBVTtNQUNwRDtNQUNBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQ2IsU0FBUztRQUNULGNBQWMsTUFBTSxTQUFTO1FBQzdCO1FBQ0EsU0FBUztNQUNYLElBQ0E7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSx3Q0FBd0M7SUFDeEMsUUFBUSxHQUFHLENBQUM7SUFFWixNQUFNLFVBQVUsYUFBYyxPQUFPLENBQUMsNENBQTRDO0lBQ2xGLE1BQU0saUJBQWlCLE1BQU0sTUFBTSxDQUFDLEVBQUUsUUFBUSxlQUFlLENBQUMsRUFBRTtNQUM5RCxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixhQUFhO01BQ2Y7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQ25CLFdBQVcsTUFBTSxTQUFTO1FBQzFCLFVBQVU7TUFDWjtJQUNGO0lBRUEsSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFFO01BQ3RCLE1BQU0sWUFBWSxNQUFNLGVBQWUsSUFBSTtNQUMzQyxRQUFRLEtBQUssQ0FBQyxxQkFBcUIsZUFBZSxNQUFNLEVBQUU7TUFFMUQsdUJBQXVCO01BQ3ZCLElBQUksUUFBUTtRQUNWLE9BQU8sTUFBTSxVQUFVLE1BQU0sU0FBUyxFQUFFLFVBQVU7TUFDcEQ7TUFDQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVCxjQUFjLE1BQU0sU0FBUztRQUM3QjtRQUNBLFNBQVM7UUFDVCxTQUFTO01BQ1gsSUFDQTtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLE1BQU0sZUFBZSxNQUFNLGVBQWUsSUFBSTtJQUM5QyxRQUFRLEdBQUcsQ0FBQyx3QkFBd0I7SUFFcEMsTUFBTSxZQUFZLGFBQWEsVUFBVSxJQUFJLE1BQU0sU0FBUztJQUM1RCxNQUFNLFVBQVUsQ0FBQyxDQUFDLGFBQWEsVUFBVTtJQUV6QywyQkFBMkI7SUFDM0IsTUFBTSxTQUFTLEdBQUcsQ0FBQyw0QkFBNEI7TUFBRTtJQUFTO0lBRTFELGtFQUFrRTtJQUNsRSxJQUFJLFFBQVE7TUFDVixRQUFRLEdBQUcsQ0FBQyw2QkFBNkI7TUFDekMsT0FBTyxNQUFNLFVBQVUsV0FBVyxVQUFVO0lBQzlDO0lBRUEscUJBQXFCO0lBQ3JCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULGNBQWM7TUFDZDtNQUNBO01BQ0EsVUFBVTtRQUNSLFFBQVE7UUFDUixTQUFTO1FBQ1QsTUFBTTtRQUNOLHNCQUFzQixDQUFDLENBQUM7TUFDMUI7SUFDRixJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFnQjtJQUN2QixRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFDMUMsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFRLElBQ2hDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGO0FBRUE7OztDQUdDLEdBQ0QsZUFBZSxVQUNiLEdBQVcsRUFDWCxRQUFnQixFQUNoQixXQUFtQztFQUVuQyxJQUFJO0lBQ0Ysb0VBQW9FO0lBQ3BFLElBQUksY0FBYztJQUNsQixJQUFJLElBQUksUUFBUSxDQUFDLGNBQWM7TUFDN0IsY0FBYyxJQUFJLE9BQU8sQ0FBQyxvQkFBb0I7SUFDaEQ7SUFDQSxNQUFNLGVBQWUsTUFBTSxNQUFNO0lBQ2pDLElBQUksQ0FBQyxhQUFhLEVBQUUsRUFBRTtNQUNwQixNQUFNLElBQUksTUFBTSxDQUFDLHNCQUFzQixFQUFFLGFBQWEsTUFBTSxDQUFDLENBQUM7SUFDaEU7SUFFQSxNQUFNLFdBQVcsTUFBTSxhQUFhLFdBQVc7SUFDL0MsTUFBTSxrQkFBa0IsbUJBQW1CO0lBRTNDLE9BQU8sSUFBSSxTQUFTLFVBQVU7TUFDNUIsU0FBUztRQUNQLEdBQUcsV0FBVztRQUNkLGdCQUFnQjtRQUNoQix1QkFBdUIsQ0FBQyxzQkFBc0IsRUFBRSxnQkFBZ0Isb0JBQW9CLEVBQUUsZ0JBQWdCLENBQUM7UUFDdkcsa0JBQWtCLE9BQU8sU0FBUyxVQUFVO01BQzlDO0lBQ0Y7RUFDRixFQUFFLE9BQU8sS0FBSztJQUNaLFFBQVEsS0FBSyxDQUFDLHFCQUFxQjtJQUNuQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBdUIsSUFDL0M7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
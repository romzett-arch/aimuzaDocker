const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '');
    // Get user from auth header using getClaims (more reliable)
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }
    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      throw new Error('Unauthorized');
    }
    const userId = claimsData.claims.sub;
    // Check if user is admin/moderator
    const { data: role } = await supabase.from('user_roles').select('role').eq('user_id', userId).in('role', [
      'admin',
      'super_admin',
      'moderator'
    ]).single();
    if (!role) {
      throw new Error('Not authorized to approve distributions');
    }
    const { trackId, notes } = await req.json();
    console.log(`[approve-distribution] Admin ${userId} approving track: ${trackId}`);
    if (!trackId) {
      throw new Error('trackId is required');
    }
    // Get track
    const { data: track, error: trackError } = await supabase.from('tracks').select('*').eq('id', trackId).single();
    if (trackError || !track) {
      throw new Error('Track not found');
    }
    if (track.distribution_status !== 'pending_moderation') {
      throw new Error(`Invalid distribution status: ${track.distribution_status}`);
    }
    // Update track - approve for distribution, waiting for master upload
    const { error: updateError } = await supabase.from('tracks').update({
      distribution_status: 'pending_master',
      distribution_approved_at: new Date().toISOString(),
      distribution_approved_by: userId,
      moderation_status: 'approved',
      moderation_reviewed_at: new Date().toISOString(),
      moderation_reviewed_by: userId,
      moderation_notes: notes || null
    }).eq('id', trackId);
    if (updateError) {
      throw updateError;
    }
    // Log the approval
    await supabase.from('distribution_logs').insert({
      track_id: trackId,
      user_id: userId,
      action: 'distribution_approved',
      stage: 'level_user',
      details: {
        notes,
        approved_by: userId
      }
    });
    // Notify track owner
    await supabase.from('notifications').insert({
      user_id: track.user_id,
      type: 'system',
      title: '✅ Трек одобрен для дистрибуции!',
      message: `Поздравляем! Трек "${track.title}" прошёл модерацию. Загрузите Master-копию в формате WAV 24-bit для перехода на Level Pro.`,
      actor_id: userId,
      target_type: 'track',
      target_id: trackId
    });
    return new Response(JSON.stringify({
      success: true,
      message: 'Distribution approved, awaiting master upload',
      status: 'pending_master'
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('[approve-distribution] Error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({
      success: false,
      error: message
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9hcHByb3ZlLWRpc3RyaWJ1dGlvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ2F1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlJyxcbn07XG5cbmludGVyZmFjZSBBcHByb3ZlRGlzdHJpYnV0aW9uSW5wdXQge1xuICB0cmFja0lkOiBzdHJpbmc7XG4gIG5vdGVzPzogc3RyaW5nO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSAnT1BUSU9OUycpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKCdvaycsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9VUkwnKSA/PyAnJyxcbiAgICAgIERlbm8uZW52LmdldCgnU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWScpID8/ICcnXG4gICAgKTtcblxuICAgIC8vIEdldCB1c2VyIGZyb20gYXV0aCBoZWFkZXIgdXNpbmcgZ2V0Q2xhaW1zIChtb3JlIHJlbGlhYmxlKVxuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoJ0F1dGhvcml6YXRpb24nKTtcbiAgICBpZiAoIWF1dGhIZWFkZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gYXV0aG9yaXphdGlvbiBoZWFkZXInKTtcbiAgICB9XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZSgnQmVhcmVyICcsICcnKTtcbiAgICBjb25zdCB7IGRhdGE6IGNsYWltc0RhdGEsIGVycm9yOiBjbGFpbXNFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRDbGFpbXModG9rZW4pO1xuICAgIFxuICAgIGlmIChjbGFpbXNFcnJvciB8fCAhY2xhaW1zRGF0YT8uY2xhaW1zPy5zdWIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignVW5hdXRob3JpemVkJyk7XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHVzZXJJZCA9IGNsYWltc0RhdGEuY2xhaW1zLnN1YiBhcyBzdHJpbmc7XG5cbiAgICAvLyBDaGVjayBpZiB1c2VyIGlzIGFkbWluL21vZGVyYXRvclxuICAgIGNvbnN0IHsgZGF0YTogcm9sZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKCd1c2VyX3JvbGVzJylcbiAgICAgIC5zZWxlY3QoJ3JvbGUnKVxuICAgICAgLmVxKCd1c2VyX2lkJywgdXNlcklkKVxuICAgICAgLmluKCdyb2xlJywgWydhZG1pbicsICdzdXBlcl9hZG1pbicsICdtb2RlcmF0b3InXSlcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICghcm9sZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdOb3QgYXV0aG9yaXplZCB0byBhcHByb3ZlIGRpc3RyaWJ1dGlvbnMnKTtcbiAgICB9XG5cbiAgICBjb25zdCB7IHRyYWNrSWQsIG5vdGVzIH06IEFwcHJvdmVEaXN0cmlidXRpb25JbnB1dCA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coYFthcHByb3ZlLWRpc3RyaWJ1dGlvbl0gQWRtaW4gJHt1c2VySWR9IGFwcHJvdmluZyB0cmFjazogJHt0cmFja0lkfWApO1xuXG4gICAgaWYgKCF0cmFja0lkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RyYWNrSWQgaXMgcmVxdWlyZWQnKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgdHJhY2tcbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrLCBlcnJvcjogdHJhY2tFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKCd0cmFja3MnKVxuICAgICAgLnNlbGVjdCgnKicpXG4gICAgICAuZXEoJ2lkJywgdHJhY2tJZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICh0cmFja0Vycm9yIHx8ICF0cmFjaykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdUcmFjayBub3QgZm91bmQnKTtcbiAgICB9XG5cbiAgICBpZiAodHJhY2suZGlzdHJpYnV0aW9uX3N0YXR1cyAhPT0gJ3BlbmRpbmdfbW9kZXJhdGlvbicpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBkaXN0cmlidXRpb24gc3RhdHVzOiAke3RyYWNrLmRpc3RyaWJ1dGlvbl9zdGF0dXN9YCk7XG4gICAgfVxuXG4gICAgLy8gVXBkYXRlIHRyYWNrIC0gYXBwcm92ZSBmb3IgZGlzdHJpYnV0aW9uLCB3YWl0aW5nIGZvciBtYXN0ZXIgdXBsb2FkXG4gICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgndHJhY2tzJylcbiAgICAgIC51cGRhdGUoe1xuICAgICAgICBkaXN0cmlidXRpb25fc3RhdHVzOiAncGVuZGluZ19tYXN0ZXInLFxuICAgICAgICBkaXN0cmlidXRpb25fYXBwcm92ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZGlzdHJpYnV0aW9uX2FwcHJvdmVkX2J5OiB1c2VySWQsXG4gICAgICAgIG1vZGVyYXRpb25fc3RhdHVzOiAnYXBwcm92ZWQnLFxuICAgICAgICBtb2RlcmF0aW9uX3Jldmlld2VkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIG1vZGVyYXRpb25fcmV2aWV3ZWRfYnk6IHVzZXJJZCxcbiAgICAgICAgbW9kZXJhdGlvbl9ub3Rlczogbm90ZXMgfHwgbnVsbFxuICAgICAgfSlcbiAgICAgIC5lcSgnaWQnLCB0cmFja0lkKTtcblxuICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgdGhyb3cgdXBkYXRlRXJyb3I7XG4gICAgfVxuXG4gICAgLy8gTG9nIHRoZSBhcHByb3ZhbFxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ2Rpc3RyaWJ1dGlvbl9sb2dzJykuaW5zZXJ0KHtcbiAgICAgIHRyYWNrX2lkOiB0cmFja0lkLFxuICAgICAgdXNlcl9pZDogdXNlcklkLFxuICAgICAgYWN0aW9uOiAnZGlzdHJpYnV0aW9uX2FwcHJvdmVkJyxcbiAgICAgIHN0YWdlOiAnbGV2ZWxfdXNlcicsXG4gICAgICBkZXRhaWxzOiB7IFxuICAgICAgICBub3RlcyxcbiAgICAgICAgYXBwcm92ZWRfYnk6IHVzZXJJZFxuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gTm90aWZ5IHRyYWNrIG93bmVyXG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgnbm90aWZpY2F0aW9ucycpLmluc2VydCh7XG4gICAgICB1c2VyX2lkOiB0cmFjay51c2VyX2lkLFxuICAgICAgdHlwZTogJ3N5c3RlbScsXG4gICAgICB0aXRsZTogJ+KchSDQotGA0LXQuiDQvtC00L7QsdGA0LXQvSDQtNC70Y8g0LTQuNGB0YLRgNC40LHRg9GG0LjQuCEnLFxuICAgICAgbWVzc2FnZTogYNCf0L7Qt9C00YDQsNCy0LvRj9C10LwhINCi0YDQtdC6IFwiJHt0cmFjay50aXRsZX1cIiDQv9GA0L7RiNGR0Lsg0LzQvtC00LXRgNCw0YbQuNGOLiDQl9Cw0LPRgNGD0LfQuNGC0LUgTWFzdGVyLdC60L7Qv9C40Y4g0LIg0YTQvtGA0LzQsNGC0LUgV0FWIDI0LWJpdCDQtNC70Y8g0L/QtdGA0LXRhdC+0LTQsCDQvdCwIExldmVsIFByby5gLFxuICAgICAgYWN0b3JfaWQ6IHVzZXJJZCxcbiAgICAgIHRhcmdldF90eXBlOiAndHJhY2snLFxuICAgICAgdGFyZ2V0X2lkOiB0cmFja0lkXG4gICAgfSk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIG1lc3NhZ2U6ICdEaXN0cmlidXRpb24gYXBwcm92ZWQsIGF3YWl0aW5nIG1hc3RlciB1cGxvYWQnLFxuICAgICAgICBzdGF0dXM6ICdwZW5kaW5nX21hc3RlcidcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbYXBwcm92ZS1kaXN0cmlidXRpb25dIEVycm9yOicsIGVycm9yKTtcbiAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcic7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBtZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBQ25GLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQU9BLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sV0FBVyxhQUNmLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFDaEMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdDQUFnQztJQUcvQyw0REFBNEQ7SUFDNUQsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUFTLElBQUksQ0FBQyxTQUFTLENBQUM7SUFFL0UsSUFBSSxlQUFlLENBQUMsWUFBWSxRQUFRLEtBQUs7TUFDM0MsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLFNBQVMsV0FBVyxNQUFNLENBQUMsR0FBRztJQUVwQyxtQ0FBbUM7SUFDbkMsTUFBTSxFQUFFLE1BQU0sSUFBSSxFQUFFLEdBQUcsTUFBTSxTQUMxQixJQUFJLENBQUMsY0FDTCxNQUFNLENBQUMsUUFDUCxFQUFFLENBQUMsV0FBVyxRQUNkLEVBQUUsQ0FBQyxRQUFRO01BQUM7TUFBUztNQUFlO0tBQVksRUFDaEQsTUFBTTtJQUVULElBQUksQ0FBQyxNQUFNO01BQ1QsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxHQUE2QixNQUFNLElBQUksSUFBSTtJQUNuRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDZCQUE2QixFQUFFLE9BQU8sa0JBQWtCLEVBQUUsUUFBUSxDQUFDO0lBRWhGLElBQUksQ0FBQyxTQUFTO01BQ1osTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxZQUFZO0lBQ1osTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxTQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsS0FDUCxFQUFFLENBQUMsTUFBTSxTQUNULE1BQU07SUFFVCxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsSUFBSSxNQUFNLG1CQUFtQixLQUFLLHNCQUFzQjtNQUN0RCxNQUFNLElBQUksTUFBTSxDQUFDLDZCQUE2QixFQUFFLE1BQU0sbUJBQW1CLENBQUMsQ0FBQztJQUM3RTtJQUVBLHFFQUFxRTtJQUNyRSxNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLFNBQ2xDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztNQUNOLHFCQUFxQjtNQUNyQiwwQkFBMEIsSUFBSSxPQUFPLFdBQVc7TUFDaEQsMEJBQTBCO01BQzFCLG1CQUFtQjtNQUNuQix3QkFBd0IsSUFBSSxPQUFPLFdBQVc7TUFDOUMsd0JBQXdCO01BQ3hCLGtCQUFrQixTQUFTO0lBQzdCLEdBQ0MsRUFBRSxDQUFDLE1BQU07SUFFWixJQUFJLGFBQWE7TUFDZixNQUFNO0lBQ1I7SUFFQSxtQkFBbUI7SUFDbkIsTUFBTSxTQUFTLElBQUksQ0FBQyxxQkFBcUIsTUFBTSxDQUFDO01BQzlDLFVBQVU7TUFDVixTQUFTO01BQ1QsUUFBUTtNQUNSLE9BQU87TUFDUCxTQUFTO1FBQ1A7UUFDQSxhQUFhO01BQ2Y7SUFDRjtJQUVBLHFCQUFxQjtJQUNyQixNQUFNLFNBQVMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7TUFDMUMsU0FBUyxNQUFNLE9BQU87TUFDdEIsTUFBTTtNQUNOLE9BQU87TUFDUCxTQUFTLENBQUMsbUJBQW1CLEVBQUUsTUFBTSxLQUFLLENBQUMsMEZBQTBGLENBQUM7TUFDdEksVUFBVTtNQUNWLGFBQWE7TUFDYixXQUFXO0lBQ2I7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxTQUFTO01BQ1QsUUFBUTtJQUNWLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyxpQ0FBaUM7SUFDL0MsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztNQUFPLE9BQU87SUFBUSxJQUNoRDtNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRiJ9
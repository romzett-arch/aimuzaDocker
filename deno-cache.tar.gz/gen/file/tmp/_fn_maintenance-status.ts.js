const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
function toBool(value) {
  return (value ?? "").toLowerCase() === "true";
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const supabaseClient = createClient(supabaseUrl, serviceRoleKey || anonKey);
    // Read settings keys with retry for transient connection resets
    let data = null;
    let lastError = null;
    for(let attempt = 0; attempt < 3; attempt++){
      const res = await supabaseClient.from("settings").select("key,value,updated_at").in("key", [
        "maintenance_mode",
        "maintenance_eta",
        "maintenance_message"
      ]);
      if (!res.error) {
        data = res.data;
        lastError = null;
        break;
      }
      lastError = res.error;
      if (attempt < 2) await new Promise((r)=>setTimeout(r, 200 * (attempt + 1)));
    }
    if (lastError) throw lastError;
    const map = new Map();
    (data ?? []).forEach((row)=>map.set(row.key, {
        value: row.value,
        updated_at: row.updated_at
      }));
    const enabled = toBool(map.get("maintenance_mode")?.value);
    const eta = map.get("maintenance_eta")?.value ?? null;
    const message = map.get("maintenance_message")?.value ?? null;
    const updatedAt = map.get("maintenance_mode")?.updated_at ?? null;
    // Check if user is whitelisted (only if maintenance is enabled)
    let whitelisted = false;
    if (enabled) {
      const authHeader = req.headers.get("authorization");
      if (authHeader?.startsWith("Bearer ")) {
        const token = authHeader.slice(7);
        try {
          const { data: claims } = await supabaseClient.auth.getUser(token);
          if (claims?.user?.id) {
            const { data: whitelist } = await supabaseClient.from("maintenance_whitelist").select("id").eq("user_id", claims.user.id).maybeSingle();
            whitelisted = !!whitelist;
          }
        } catch  {
        // Ignore auth errors, just don't whitelist
        }
      }
    }
    const payload = {
      enabled,
      eta,
      message,
      updated_at: updatedAt,
      whitelisted
    };
    return new Response(JSON.stringify(payload), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
        // If enabled and ETA provided, clients can re-check later; fallback to 5 min.
        "Cache-Control": enabled ? "public, max-age=60" : "public, max-age=30"
      }
    });
  } catch (err) {
    console.error("maintenance-status error:", err);
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({
      enabled: false,
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9tYWludGVuYW5jZS1zdGF0dXMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbnR5cGUgTWFpbnRlbmFuY2VTdGF0dXMgPSB7XG4gIGVuYWJsZWQ6IGJvb2xlYW47XG4gIGV0YTogc3RyaW5nIHwgbnVsbDtcbiAgbWVzc2FnZTogc3RyaW5nIHwgbnVsbDtcbiAgdXBkYXRlZF9hdDogc3RyaW5nIHwgbnVsbDtcbiAgd2hpdGVsaXN0ZWQ/OiBib29sZWFuO1xufTtcblxuZnVuY3Rpb24gdG9Cb29sKHZhbHVlOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKTogYm9vbGVhbiB7XG4gIHJldHVybiAodmFsdWUgPz8gXCJcIikudG9Mb3dlckNhc2UoKSA9PT0gXCJ0cnVlXCI7XG59XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiO1xuICAgIGNvbnN0IGFub25LZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSA/PyBcIlwiO1xuICAgIGNvbnN0IHNlcnZpY2VSb2xlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSA/PyBcIlwiO1xuXG4gICAgY29uc3Qgc3VwYWJhc2VDbGllbnQgPSBjcmVhdGVDbGllbnQoXG4gICAgICBzdXBhYmFzZVVybCxcbiAgICAgIHNlcnZpY2VSb2xlS2V5IHx8IGFub25LZXlcbiAgICApO1xuXG4gICAgLy8gUmVhZCBzZXR0aW5ncyBrZXlzIHdpdGggcmV0cnkgZm9yIHRyYW5zaWVudCBjb25uZWN0aW9uIHJlc2V0c1xuICAgIGxldCBkYXRhOiBhbnkgPSBudWxsO1xuICAgIGxldCBsYXN0RXJyb3I6IGFueSA9IG51bGw7XG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDA7IGF0dGVtcHQgPCAzOyBhdHRlbXB0KyspIHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgIC5mcm9tKFwic2V0dGluZ3NcIilcbiAgICAgICAgLnNlbGVjdChcImtleSx2YWx1ZSx1cGRhdGVkX2F0XCIpXG4gICAgICAgIC5pbihcImtleVwiLCBbXCJtYWludGVuYW5jZV9tb2RlXCIsIFwibWFpbnRlbmFuY2VfZXRhXCIsIFwibWFpbnRlbmFuY2VfbWVzc2FnZVwiXSk7XG4gICAgICBpZiAoIXJlcy5lcnJvcikgeyBkYXRhID0gcmVzLmRhdGE7IGxhc3RFcnJvciA9IG51bGw7IGJyZWFrOyB9XG4gICAgICBsYXN0RXJyb3IgPSByZXMuZXJyb3I7XG4gICAgICBpZiAoYXR0ZW1wdCA8IDIpIGF3YWl0IG5ldyBQcm9taXNlKHIgPT4gc2V0VGltZW91dChyLCAyMDAgKiAoYXR0ZW1wdCArIDEpKSk7XG4gICAgfVxuICAgIGlmIChsYXN0RXJyb3IpIHRocm93IGxhc3RFcnJvcjtcblxuICAgIGNvbnN0IG1hcCA9IG5ldyBNYXA8c3RyaW5nLCB7IHZhbHVlOiBzdHJpbmc7IHVwZGF0ZWRfYXQ6IHN0cmluZyB9PigpO1xuICAgIChkYXRhID8/IFtdKS5mb3JFYWNoKChyb3c6IGFueSkgPT4gbWFwLnNldChyb3cua2V5LCB7IHZhbHVlOiByb3cudmFsdWUsIHVwZGF0ZWRfYXQ6IHJvdy51cGRhdGVkX2F0IH0pKTtcblxuICAgIGNvbnN0IGVuYWJsZWQgPSB0b0Jvb2wobWFwLmdldChcIm1haW50ZW5hbmNlX21vZGVcIik/LnZhbHVlKTtcbiAgICBjb25zdCBldGEgPSBtYXAuZ2V0KFwibWFpbnRlbmFuY2VfZXRhXCIpPy52YWx1ZSA/PyBudWxsO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBtYXAuZ2V0KFwibWFpbnRlbmFuY2VfbWVzc2FnZVwiKT8udmFsdWUgPz8gbnVsbDtcbiAgICBjb25zdCB1cGRhdGVkQXQgPSBtYXAuZ2V0KFwibWFpbnRlbmFuY2VfbW9kZVwiKT8udXBkYXRlZF9hdCA/PyBudWxsO1xuXG4gICAgLy8gQ2hlY2sgaWYgdXNlciBpcyB3aGl0ZWxpc3RlZCAob25seSBpZiBtYWludGVuYW5jZSBpcyBlbmFibGVkKVxuICAgIGxldCB3aGl0ZWxpc3RlZCA9IGZhbHNlO1xuICAgIGlmIChlbmFibGVkKSB7XG4gICAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiYXV0aG9yaXphdGlvblwiKTtcbiAgICAgIGlmIChhdXRoSGVhZGVyPy5zdGFydHNXaXRoKFwiQmVhcmVyIFwiKSkge1xuICAgICAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIuc2xpY2UoNyk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgeyBkYXRhOiBjbGFpbXMgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50LmF1dGguZ2V0VXNlcih0b2tlbik7XG4gICAgICAgICAgaWYgKGNsYWltcz8udXNlcj8uaWQpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgZGF0YTogd2hpdGVsaXN0IH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAgICAgICAuZnJvbShcIm1haW50ZW5hbmNlX3doaXRlbGlzdFwiKVxuICAgICAgICAgICAgICAuc2VsZWN0KFwiaWRcIilcbiAgICAgICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCBjbGFpbXMudXNlci5pZClcbiAgICAgICAgICAgICAgLm1heWJlU2luZ2xlKCk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHdoaXRlbGlzdGVkID0gISF3aGl0ZWxpc3Q7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAvLyBJZ25vcmUgYXV0aCBlcnJvcnMsIGp1c3QgZG9uJ3Qgd2hpdGVsaXN0XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBwYXlsb2FkOiBNYWludGVuYW5jZVN0YXR1cyA9IHtcbiAgICAgIGVuYWJsZWQsXG4gICAgICBldGEsXG4gICAgICBtZXNzYWdlLFxuICAgICAgdXBkYXRlZF9hdDogdXBkYXRlZEF0LFxuICAgICAgd2hpdGVsaXN0ZWQsXG4gICAgfTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkocGF5bG9hZCksIHtcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgLi4uY29yc0hlYWRlcnMsXG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICAvLyBJZiBlbmFibGVkIGFuZCBFVEEgcHJvdmlkZWQsIGNsaWVudHMgY2FuIHJlLWNoZWNrIGxhdGVyOyBmYWxsYmFjayB0byA1IG1pbi5cbiAgICAgICAgXCJDYWNoZS1Db250cm9sXCI6IGVuYWJsZWQgPyBcInB1YmxpYywgbWF4LWFnZT02MFwiIDogXCJwdWJsaWMsIG1heC1hZ2U9MzBcIixcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJtYWludGVuYW5jZS1zdGF0dXMgZXJyb3I6XCIsIGVycik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHsgZW5hYmxlZDogZmFsc2UsIGVycm9yOiBtZXNzYWdlIH0pLCB7XG4gICAgICBzdGF0dXM6IDUwMCxcbiAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgfSk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBVUEsU0FBUyxPQUFPLEtBQWdDO0VBQzlDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsRUFBRSxXQUFXLE9BQU87QUFDekM7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQjtJQUNwRCxNQUFNLFVBQVUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLHdCQUF3QjtJQUNyRCxNQUFNLGlCQUFpQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0lBRXBFLE1BQU0saUJBQWlCLGFBQ3JCLGFBQ0Esa0JBQWtCO0lBR3BCLGdFQUFnRTtJQUNoRSxJQUFJLE9BQVk7SUFDaEIsSUFBSSxZQUFpQjtJQUNyQixJQUFLLElBQUksVUFBVSxHQUFHLFVBQVUsR0FBRyxVQUFXO01BQzVDLE1BQU0sTUFBTSxNQUFNLGVBQ2YsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLHdCQUNQLEVBQUUsQ0FBQyxPQUFPO1FBQUM7UUFBb0I7UUFBbUI7T0FBc0I7TUFDM0UsSUFBSSxDQUFDLElBQUksS0FBSyxFQUFFO1FBQUUsT0FBTyxJQUFJLElBQUk7UUFBRSxZQUFZO1FBQU07TUFBTztNQUM1RCxZQUFZLElBQUksS0FBSztNQUNyQixJQUFJLFVBQVUsR0FBRyxNQUFNLElBQUksUUFBUSxDQUFBLElBQUssV0FBVyxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUM7SUFDMUU7SUFDQSxJQUFJLFdBQVcsTUFBTTtJQUVyQixNQUFNLE1BQU0sSUFBSTtJQUNoQixDQUFDLFFBQVEsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDLE1BQWEsSUFBSSxHQUFHLENBQUMsSUFBSSxHQUFHLEVBQUU7UUFBRSxPQUFPLElBQUksS0FBSztRQUFFLFlBQVksSUFBSSxVQUFVO01BQUM7SUFFbkcsTUFBTSxVQUFVLE9BQU8sSUFBSSxHQUFHLENBQUMscUJBQXFCO0lBQ3BELE1BQU0sTUFBTSxJQUFJLEdBQUcsQ0FBQyxvQkFBb0IsU0FBUztJQUNqRCxNQUFNLFVBQVUsSUFBSSxHQUFHLENBQUMsd0JBQXdCLFNBQVM7SUFDekQsTUFBTSxZQUFZLElBQUksR0FBRyxDQUFDLHFCQUFxQixjQUFjO0lBRTdELGdFQUFnRTtJQUNoRSxJQUFJLGNBQWM7SUFDbEIsSUFBSSxTQUFTO01BQ1gsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztNQUNuQyxJQUFJLFlBQVksV0FBVyxZQUFZO1FBQ3JDLE1BQU0sUUFBUSxXQUFXLEtBQUssQ0FBQztRQUMvQixJQUFJO1VBQ0YsTUFBTSxFQUFFLE1BQU0sTUFBTSxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxPQUFPLENBQUM7VUFDM0QsSUFBSSxRQUFRLE1BQU0sSUFBSTtZQUNwQixNQUFNLEVBQUUsTUFBTSxTQUFTLEVBQUUsR0FBRyxNQUFNLGVBQy9CLElBQUksQ0FBQyx5QkFDTCxNQUFNLENBQUMsTUFDUCxFQUFFLENBQUMsV0FBVyxPQUFPLElBQUksQ0FBQyxFQUFFLEVBQzVCLFdBQVc7WUFFZCxjQUFjLENBQUMsQ0FBQztVQUNsQjtRQUNGLEVBQUUsT0FBTTtRQUNOLDJDQUEyQztRQUM3QztNQUNGO0lBQ0Y7SUFFQSxNQUFNLFVBQTZCO01BQ2pDO01BQ0E7TUFDQTtNQUNBLFlBQVk7TUFDWjtJQUNGO0lBRUEsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUMsVUFBVTtNQUMzQyxTQUFTO1FBQ1AsR0FBRyxXQUFXO1FBQ2QsZ0JBQWdCO1FBQ2hCLDhFQUE4RTtRQUM5RSxpQkFBaUIsVUFBVSx1QkFBdUI7TUFDcEQ7SUFDRjtFQUNGLEVBQUUsT0FBTyxLQUFLO0lBQ1osUUFBUSxLQUFLLENBQUMsNkJBQTZCO0lBQzNDLE1BQU0sVUFBVSxlQUFlLFFBQVEsSUFBSSxPQUFPLEdBQUc7SUFDckQsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU8sT0FBTztJQUFRLElBQUk7TUFDdEUsUUFBUTtNQUNSLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFDaEU7RUFDRjtBQUNGIn0=
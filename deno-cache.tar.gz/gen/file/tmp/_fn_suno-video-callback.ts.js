const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const supabase = createClient(supabaseUrl, supabaseServiceKey);
  try {
    const body = await req.json();
    console.log("Suno video callback received:", JSON.stringify(body));
    const { code, msg, data } = body;
    if (code !== 200) {
      console.error(`Suno video callback error: ${msg}`);
      return new Response(JSON.stringify({
        received: true,
        error: msg
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Extract task_id and video_url - Suno may send different formats
    const task_id = data?.task_id;
    const video_url = data?.video_url;
    // Determine callback type from response structure
    let callbackType = data?.callbackType;
    if (!callbackType && video_url) {
      callbackType = "complete"; // If we have video_url, it's complete
    }
    console.log(`Video callback type: ${callbackType}, task_id: ${task_id}`);
    // Find the track addon with this video task ID
    // The result_url field contains JSON with video_task_id
    const { data: addons, error: findError } = await supabase.from("track_addons").select("*, addon_services!inner(name), tracks!inner(id, user_id, title, suno_audio_id)").eq("addon_services.name", "short_video").eq("status", "processing");
    if (findError) {
      console.error("Error finding addons:", findError);
      return new Response(JSON.stringify({
        received: true,
        error: "Error finding addon"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Find the addon that matches this video task_id
    let matchedAddon = null;
    for (const addon of addons || []){
      try {
        const resultData = typeof addon.result_url === 'string' ? JSON.parse(addon.result_url) : addon.result_url;
        if (resultData?.video_task_id === task_id) {
          matchedAddon = addon;
          break;
        }
      } catch (e) {
        console.log(`Failed to parse result_url for addon ${addon.id}:`, e);
      }
    }
    if (!matchedAddon) {
      console.log("No matching addon found for video task_id:", task_id);
      return new Response(JSON.stringify({
        received: true,
        message: "No matching addon"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const trackData = matchedAddon.tracks;
    const trackId = trackData.id;
    const userId = trackData.user_id;
    const trackTitle = trackData.title;
    console.log(`Found addon ${matchedAddon.id} for track ${trackId}`);
    if (callbackType === "complete" || callbackType === "SUCCESS") {
      // Video generation completed - use video_url from data directly
      const finalVideoUrl = video_url || data?.data?.[0]?.video_url || data?.data?.[0]?.mp4_url;
      console.log(`Video completed for track ${trackId}, URL: ${finalVideoUrl}`);
      const { error: updateError } = await supabase.from("track_addons").update({
        status: "completed",
        result_url: finalVideoUrl || JSON.stringify(data),
        updated_at: new Date().toISOString()
      }).eq("id", matchedAddon.id);
      if (updateError) {
        console.error("Error updating addon:", updateError);
      }
      // Create notification for user
      await supabase.from("notifications").insert({
        user_id: userId,
        type: "addon_completed",
        title: "Музыкальное видео готово",
        message: `Видео для трека "${trackTitle}" успешно создано`,
        target_type: "track",
        target_id: trackId
      });
    } else if (callbackType === "FAILED" || callbackType === "error") {
      // Video generation failed
      console.error(`Video generation failed for track ${trackId}: ${msg}`);
      const { error: updateError } = await supabase.from("track_addons").update({
        status: "failed",
        result_url: JSON.stringify({
          error: msg || "Video generation failed"
        }),
        updated_at: new Date().toISOString()
      }).eq("id", matchedAddon.id);
      if (updateError) {
        console.error("Error updating addon:", updateError);
      }
      // Create notification for user
      await supabase.from("notifications").insert({
        user_id: userId,
        type: "addon_failed",
        title: "Ошибка создания видео",
        message: `Не удалось создать видео для трека "${trackTitle}"`,
        target_type: "track",
        target_id: trackId
      });
    }
    return new Response(JSON.stringify({
      received: true,
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("suno-video-callback error:", error);
    return new Response(JSON.stringify({
      received: true,
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9zdW5vLXZpZGVvLWNhbGxiYWNrLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gIHRyeSB7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJTdW5vIHZpZGVvIGNhbGxiYWNrIHJlY2VpdmVkOlwiLCBKU09OLnN0cmluZ2lmeShib2R5KSk7XG5cbiAgICBjb25zdCB7IGNvZGUsIG1zZywgZGF0YSB9ID0gYm9keTtcblxuICAgIGlmIChjb2RlICE9PSAyMDApIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYFN1bm8gdmlkZW8gY2FsbGJhY2sgZXJyb3I6ICR7bXNnfWApO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeSh7IHJlY2VpdmVkOiB0cnVlLCBlcnJvcjogbXNnIH0pLCB7XG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBFeHRyYWN0IHRhc2tfaWQgYW5kIHZpZGVvX3VybCAtIFN1bm8gbWF5IHNlbmQgZGlmZmVyZW50IGZvcm1hdHNcbiAgICBjb25zdCB0YXNrX2lkID0gZGF0YT8udGFza19pZDtcbiAgICBjb25zdCB2aWRlb191cmwgPSBkYXRhPy52aWRlb191cmw7XG4gICAgXG4gICAgLy8gRGV0ZXJtaW5lIGNhbGxiYWNrIHR5cGUgZnJvbSByZXNwb25zZSBzdHJ1Y3R1cmVcbiAgICBsZXQgY2FsbGJhY2tUeXBlID0gZGF0YT8uY2FsbGJhY2tUeXBlO1xuICAgIGlmICghY2FsbGJhY2tUeXBlICYmIHZpZGVvX3VybCkge1xuICAgICAgY2FsbGJhY2tUeXBlID0gXCJjb21wbGV0ZVwiOyAvLyBJZiB3ZSBoYXZlIHZpZGVvX3VybCwgaXQncyBjb21wbGV0ZVxuICAgIH1cbiAgICBjb25zb2xlLmxvZyhgVmlkZW8gY2FsbGJhY2sgdHlwZTogJHtjYWxsYmFja1R5cGV9LCB0YXNrX2lkOiAke3Rhc2tfaWR9YCk7XG5cbiAgICAvLyBGaW5kIHRoZSB0cmFjayBhZGRvbiB3aXRoIHRoaXMgdmlkZW8gdGFzayBJRFxuICAgIC8vIFRoZSByZXN1bHRfdXJsIGZpZWxkIGNvbnRhaW5zIEpTT04gd2l0aCB2aWRlb190YXNrX2lkXG4gICAgY29uc3QgeyBkYXRhOiBhZGRvbnMsIGVycm9yOiBmaW5kRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgLnNlbGVjdChcIiosIGFkZG9uX3NlcnZpY2VzIWlubmVyKG5hbWUpLCB0cmFja3MhaW5uZXIoaWQsIHVzZXJfaWQsIHRpdGxlLCBzdW5vX2F1ZGlvX2lkKVwiKVxuICAgICAgLmVxKFwiYWRkb25fc2VydmljZXMubmFtZVwiLCBcInNob3J0X3ZpZGVvXCIpXG4gICAgICAuZXEoXCJzdGF0dXNcIiwgXCJwcm9jZXNzaW5nXCIpO1xuXG4gICAgaWYgKGZpbmRFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZpbmRpbmcgYWRkb25zOlwiLCBmaW5kRXJyb3IpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeSh7IHJlY2VpdmVkOiB0cnVlLCBlcnJvcjogXCJFcnJvciBmaW5kaW5nIGFkZG9uXCIgfSksIHtcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8vIEZpbmQgdGhlIGFkZG9uIHRoYXQgbWF0Y2hlcyB0aGlzIHZpZGVvIHRhc2tfaWRcbiAgICBsZXQgbWF0Y2hlZEFkZG9uID0gbnVsbDtcbiAgICBmb3IgKGNvbnN0IGFkZG9uIG9mIGFkZG9ucyB8fCBbXSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0RGF0YSA9IHR5cGVvZiBhZGRvbi5yZXN1bHRfdXJsID09PSAnc3RyaW5nJyBcbiAgICAgICAgICA/IEpTT04ucGFyc2UoYWRkb24ucmVzdWx0X3VybCkgXG4gICAgICAgICAgOiBhZGRvbi5yZXN1bHRfdXJsO1xuICAgICAgICBcbiAgICAgICAgaWYgKHJlc3VsdERhdGE/LnZpZGVvX3Rhc2tfaWQgPT09IHRhc2tfaWQpIHtcbiAgICAgICAgICBtYXRjaGVkQWRkb24gPSBhZGRvbjtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhgRmFpbGVkIHRvIHBhcnNlIHJlc3VsdF91cmwgZm9yIGFkZG9uICR7YWRkb24uaWR9OmAsIGUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICghbWF0Y2hlZEFkZG9uKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIk5vIG1hdGNoaW5nIGFkZG9uIGZvdW5kIGZvciB2aWRlbyB0YXNrX2lkOlwiLCB0YXNrX2lkKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoeyByZWNlaXZlZDogdHJ1ZSwgbWVzc2FnZTogXCJObyBtYXRjaGluZyBhZGRvblwiIH0pLCB7XG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBjb25zdCB0cmFja0RhdGEgPSBtYXRjaGVkQWRkb24udHJhY2tzIGFzIHsgaWQ6IHN0cmluZzsgdXNlcl9pZDogc3RyaW5nOyB0aXRsZTogc3RyaW5nOyBzdW5vX2F1ZGlvX2lkOiBzdHJpbmcgfCBudWxsIH07XG4gICAgY29uc3QgdHJhY2tJZCA9IHRyYWNrRGF0YS5pZDtcbiAgICBjb25zdCB1c2VySWQgPSB0cmFja0RhdGEudXNlcl9pZDtcbiAgICBjb25zdCB0cmFja1RpdGxlID0gdHJhY2tEYXRhLnRpdGxlO1xuXG4gICAgY29uc29sZS5sb2coYEZvdW5kIGFkZG9uICR7bWF0Y2hlZEFkZG9uLmlkfSBmb3IgdHJhY2sgJHt0cmFja0lkfWApO1xuXG4gICAgaWYgKGNhbGxiYWNrVHlwZSA9PT0gXCJjb21wbGV0ZVwiIHx8IGNhbGxiYWNrVHlwZSA9PT0gXCJTVUNDRVNTXCIpIHtcbiAgICAgIC8vIFZpZGVvIGdlbmVyYXRpb24gY29tcGxldGVkIC0gdXNlIHZpZGVvX3VybCBmcm9tIGRhdGEgZGlyZWN0bHlcbiAgICAgIGNvbnN0IGZpbmFsVmlkZW9VcmwgPSB2aWRlb191cmwgfHwgZGF0YT8uZGF0YT8uWzBdPy52aWRlb191cmwgfHwgZGF0YT8uZGF0YT8uWzBdPy5tcDRfdXJsO1xuXG4gICAgICBjb25zb2xlLmxvZyhgVmlkZW8gY29tcGxldGVkIGZvciB0cmFjayAke3RyYWNrSWR9LCBVUkw6ICR7ZmluYWxWaWRlb1VybH1gKTtcblxuICAgICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgIHN0YXR1czogXCJjb21wbGV0ZWRcIixcbiAgICAgICAgICByZXN1bHRfdXJsOiBmaW5hbFZpZGVvVXJsIHx8IEpTT04uc3RyaW5naWZ5KGRhdGEpLFxuICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgbWF0Y2hlZEFkZG9uLmlkKTtcblxuICAgICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBhZGRvbjpcIiwgdXBkYXRlRXJyb3IpO1xuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgbm90aWZpY2F0aW9uIGZvciB1c2VyXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwibm90aWZpY2F0aW9uc1wiKS5pbnNlcnQoe1xuICAgICAgICB1c2VyX2lkOiB1c2VySWQsXG4gICAgICAgIHR5cGU6IFwiYWRkb25fY29tcGxldGVkXCIsXG4gICAgICAgIHRpdGxlOiBcItCc0YPQt9GL0LrQsNC70YzQvdC+0LUg0LLQuNC00LXQviDQs9C+0YLQvtCy0L5cIixcbiAgICAgICAgbWVzc2FnZTogYNCS0LjQtNC10L4g0LTQu9GPINGC0YDQtdC60LAgXCIke3RyYWNrVGl0bGV9XCIg0YPRgdC/0LXRiNC90L4g0YHQvtC30LTQsNC90L5gLFxuICAgICAgICB0YXJnZXRfdHlwZTogXCJ0cmFja1wiLFxuICAgICAgICB0YXJnZXRfaWQ6IHRyYWNrSWQsXG4gICAgICB9KTtcblxuICAgIH0gZWxzZSBpZiAoY2FsbGJhY2tUeXBlID09PSBcIkZBSUxFRFwiIHx8IGNhbGxiYWNrVHlwZSA9PT0gXCJlcnJvclwiKSB7XG4gICAgICAvLyBWaWRlbyBnZW5lcmF0aW9uIGZhaWxlZFxuICAgICAgY29uc29sZS5lcnJvcihgVmlkZW8gZ2VuZXJhdGlvbiBmYWlsZWQgZm9yIHRyYWNrICR7dHJhY2tJZH06ICR7bXNnfWApO1xuXG4gICAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJ0cmFja19hZGRvbnNcIilcbiAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLFxuICAgICAgICAgIHJlc3VsdF91cmw6IEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IG1zZyB8fCBcIlZpZGVvIGdlbmVyYXRpb24gZmFpbGVkXCIgfSksXG4gICAgICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICB9KVxuICAgICAgICAuZXEoXCJpZFwiLCBtYXRjaGVkQWRkb24uaWQpO1xuXG4gICAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIGFkZG9uOlwiLCB1cGRhdGVFcnJvcik7XG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSBub3RpZmljYXRpb24gZm9yIHVzZXJcbiAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oXCJub3RpZmljYXRpb25zXCIpLmluc2VydCh7XG4gICAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcbiAgICAgICAgdHlwZTogXCJhZGRvbl9mYWlsZWRcIixcbiAgICAgICAgdGl0bGU6IFwi0J7RiNC40LHQutCwINGB0L7Qt9C00LDQvdC40Y8g0LLQuNC00LXQvlwiLFxuICAgICAgICBtZXNzYWdlOiBg0J3QtSDRg9C00LDQu9C+0YHRjCDRgdC+0LfQtNCw0YLRjCDQstC40LTQtdC+INC00LvRjyDRgtGA0LXQutCwIFwiJHt0cmFja1RpdGxlfVwiYCxcbiAgICAgICAgdGFyZ2V0X3R5cGU6IFwidHJhY2tcIixcbiAgICAgICAgdGFyZ2V0X2lkOiB0cmFja0lkLFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgcmVjZWl2ZWQ6IHRydWUsIHN1Y2Nlc3M6IHRydWUgfSksXG4gICAgICB7XG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9XG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwic3Vuby12aWRlby1jYWxsYmFjayBlcnJvcjpcIiwgZXJyb3IpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHJlY2VpdmVkOiB0cnVlLFxuICAgICAgICBlcnJvcjogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIixcbiAgICAgIH0pLFxuICAgICAge1xuICAgICAgICBzdGF0dXM6IDUwMCxcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgIH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBQ25GLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUNqQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFDeEMsTUFBTSxXQUFXLGFBQWEsYUFBYTtFQUUzQyxJQUFJO0lBQ0YsTUFBTSxPQUFPLE1BQU0sSUFBSSxJQUFJO0lBQzNCLFFBQVEsR0FBRyxDQUFDLGlDQUFpQyxLQUFLLFNBQVMsQ0FBQztJQUU1RCxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBRztJQUU1QixJQUFJLFNBQVMsS0FBSztNQUNoQixRQUFRLEtBQUssQ0FBQyxDQUFDLDJCQUEyQixFQUFFLElBQUksQ0FBQztNQUNqRCxPQUFPLElBQUksU0FBUyxLQUFLLFNBQVMsQ0FBQztRQUFFLFVBQVU7UUFBTSxPQUFPO01BQUksSUFBSTtRQUNsRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQ2hFO0lBQ0Y7SUFFQSxrRUFBa0U7SUFDbEUsTUFBTSxVQUFVLE1BQU07SUFDdEIsTUFBTSxZQUFZLE1BQU07SUFFeEIsa0RBQWtEO0lBQ2xELElBQUksZUFBZSxNQUFNO0lBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsV0FBVztNQUM5QixlQUFlLFlBQVksc0NBQXNDO0lBQ25FO0lBQ0EsUUFBUSxHQUFHLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxhQUFhLFdBQVcsRUFBRSxRQUFRLENBQUM7SUFFdkUsK0NBQStDO0lBQy9DLHdEQUF3RDtJQUN4RCxNQUFNLEVBQUUsTUFBTSxNQUFNLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLFNBQzlDLElBQUksQ0FBQyxnQkFDTCxNQUFNLENBQUMsa0ZBQ1AsRUFBRSxDQUFDLHVCQUF1QixlQUMxQixFQUFFLENBQUMsVUFBVTtJQUVoQixJQUFJLFdBQVc7TUFDYixRQUFRLEtBQUssQ0FBQyx5QkFBeUI7TUFDdkMsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7UUFBRSxVQUFVO1FBQU0sT0FBTztNQUFzQixJQUFJO1FBQ3BGLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFDaEU7SUFDRjtJQUVBLGlEQUFpRDtJQUNqRCxJQUFJLGVBQWU7SUFDbkIsS0FBSyxNQUFNLFNBQVMsVUFBVSxFQUFFLENBQUU7TUFDaEMsSUFBSTtRQUNGLE1BQU0sYUFBYSxPQUFPLE1BQU0sVUFBVSxLQUFLLFdBQzNDLEtBQUssS0FBSyxDQUFDLE1BQU0sVUFBVSxJQUMzQixNQUFNLFVBQVU7UUFFcEIsSUFBSSxZQUFZLGtCQUFrQixTQUFTO1VBQ3pDLGVBQWU7VUFDZjtRQUNGO01BQ0YsRUFBRSxPQUFPLEdBQUc7UUFDVixRQUFRLEdBQUcsQ0FBQyxDQUFDLHFDQUFxQyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFO01BQ25FO0lBQ0Y7SUFFQSxJQUFJLENBQUMsY0FBYztNQUNqQixRQUFRLEdBQUcsQ0FBQyw4Q0FBOEM7TUFDMUQsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7UUFBRSxVQUFVO1FBQU0sU0FBUztNQUFvQixJQUFJO1FBQ3BGLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFDaEU7SUFDRjtJQUVBLE1BQU0sWUFBWSxhQUFhLE1BQU07SUFDckMsTUFBTSxVQUFVLFVBQVUsRUFBRTtJQUM1QixNQUFNLFNBQVMsVUFBVSxPQUFPO0lBQ2hDLE1BQU0sYUFBYSxVQUFVLEtBQUs7SUFFbEMsUUFBUSxHQUFHLENBQUMsQ0FBQyxZQUFZLEVBQUUsYUFBYSxFQUFFLENBQUMsV0FBVyxFQUFFLFFBQVEsQ0FBQztJQUVqRSxJQUFJLGlCQUFpQixjQUFjLGlCQUFpQixXQUFXO01BQzdELGdFQUFnRTtNQUNoRSxNQUFNLGdCQUFnQixhQUFhLE1BQU0sTUFBTSxDQUFDLEVBQUUsRUFBRSxhQUFhLE1BQU0sTUFBTSxDQUFDLEVBQUUsRUFBRTtNQUVsRixRQUFRLEdBQUcsQ0FBQyxDQUFDLDBCQUEwQixFQUFFLFFBQVEsT0FBTyxFQUFFLGNBQWMsQ0FBQztNQUV6RSxNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLFNBQ2xDLElBQUksQ0FBQyxnQkFDTCxNQUFNLENBQUM7UUFDTixRQUFRO1FBQ1IsWUFBWSxpQkFBaUIsS0FBSyxTQUFTLENBQUM7UUFDNUMsWUFBWSxJQUFJLE9BQU8sV0FBVztNQUNwQyxHQUNDLEVBQUUsQ0FBQyxNQUFNLGFBQWEsRUFBRTtNQUUzQixJQUFJLGFBQWE7UUFDZixRQUFRLEtBQUssQ0FBQyx5QkFBeUI7TUFDekM7TUFFQSwrQkFBK0I7TUFDL0IsTUFBTSxTQUFTLElBQUksQ0FBQyxpQkFBaUIsTUFBTSxDQUFDO1FBQzFDLFNBQVM7UUFDVCxNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxXQUFXLGlCQUFpQixDQUFDO1FBQzFELGFBQWE7UUFDYixXQUFXO01BQ2I7SUFFRixPQUFPLElBQUksaUJBQWlCLFlBQVksaUJBQWlCLFNBQVM7TUFDaEUsMEJBQTBCO01BQzFCLFFBQVEsS0FBSyxDQUFDLENBQUMsa0NBQWtDLEVBQUUsUUFBUSxFQUFFLEVBQUUsSUFBSSxDQUFDO01BRXBFLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztRQUNOLFFBQVE7UUFDUixZQUFZLEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTyxPQUFPO1FBQTBCO1FBQ3JFLFlBQVksSUFBSSxPQUFPLFdBQVc7TUFDcEMsR0FDQyxFQUFFLENBQUMsTUFBTSxhQUFhLEVBQUU7TUFFM0IsSUFBSSxhQUFhO1FBQ2YsUUFBUSxLQUFLLENBQUMseUJBQXlCO01BQ3pDO01BRUEsK0JBQStCO01BQy9CLE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztRQUMxQyxTQUFTO1FBQ1QsTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTLENBQUMsb0NBQW9DLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDN0QsYUFBYTtRQUNiLFdBQVc7TUFDYjtJQUNGO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxVQUFVO01BQU0sU0FBUztJQUFLLElBQy9DO01BQ0UsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUNoRTtFQUVKLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsOEJBQThCO0lBQzVDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsVUFBVTtNQUNWLE9BQU8saUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDbEQsSUFDQTtNQUNFLFFBQVE7TUFDUixTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQ2hFO0VBRUo7QUFDRiJ9
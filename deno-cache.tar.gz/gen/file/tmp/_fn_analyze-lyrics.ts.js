const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
const AGENT_ACCESS_ID = '0846d064-4950-4d79-a54c-62ba315cdb34';
// System prompt for generating style prompts from lyrics
const SYSTEM_PROMPT = `Ты эксперт по созданию музыки с помощью Suno AI. Твоя задача - анализировать текст песни и создавать промт для генерации музыки.

## ТВОЙ ПОДХОД

1. Внимательно прочитай текст песни
2. Если пользователь указал свои требования - ОБЯЗАТЕЛЬНО учитывай их в первую очередь
3. Определи настроение, жанр, темп, вокал на основе текста
4. Сгенерируй оптимальный промт для Suno на РУССКОМ языке

## ФОРМАТ ПРОМТА

Промт должен быть кратким и ёмким (до 200 символов), включать:
- Жанр и стиль музыки
- Настроение и атмосферу
- Тип вокала (если не инструментал)
- Темп и энергетику

## ПРИМЕРЫ ХОРОШИХ ПРОМПТОВ

- "Меланхоличный инди-поп, нежный женский вокал, медленный темп, атмосферная электроника"
- "Энергичный рок, мощный мужской вокал, драйвовые гитары, быстрый темп"
- "Лирический рэп, глубокий бас, минималистичный бит, городская атмосфера"
- "Романтическая баллада, акустическая гитара, тёплый вокал, интимная атмосфера"

## ФОРМАТ ОТВЕТА

Верни ТОЛЬКО валидный JSON (без markdown):
{
  "stylePrompt": "промт для Suno на русском языке (до 200 символов)",
  "genre": "определённый жанр",
  "mood": "настроение трека",
  "tempo": "медленный/средний/быстрый",
  "vocalStyle": "описание вокала"
}`;
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const { lyrics, userPrompt } = await req.json();
    if (!lyrics || typeof lyrics !== 'string') {
      return new Response(JSON.stringify({
        error: 'Текст песни обязателен'
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const TIMEWEB_TOKEN = Deno.env.get('TIMEWEB_AGENT_TOKEN');
    if (!TIMEWEB_TOKEN) {
      console.error('TIMEWEB_AGENT_TOKEN is not configured');
      return new Response(JSON.stringify({
        error: 'Timeweb Agent token не настроен'
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    console.log('Генерация промта для текста, длина:', lyrics.length);
    // Build user prompt with optional requirements
    let userMessage = `Проанализируй этот текст песни и создай оптимальный промт для генерации музыки:\n\n${lyrics}`;
    if (userPrompt && userPrompt.trim()) {
      userMessage = `ТРЕБОВАНИЯ ПОЛЬЗОВАТЕЛЯ (учти их в первую очередь): ${userPrompt}\n\n${userMessage}`;
    }
    const apiUrl = `https://agent.timeweb.cloud/api/v1/cloud-ai/agents/${AGENT_ACCESS_ID}/v1/chat/completions`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${TIMEWEB_TOKEN}`,
        'Content-Type': 'application/json',
        'x-proxy-source': 'lovable-app'
      },
      body: JSON.stringify({
        model: 'deepseek-v3',
        messages: [
          {
            role: 'system',
            content: SYSTEM_PROMPT
          },
          {
            role: 'user',
            content: userMessage
          }
        ],
        temperature: 0.7
      })
    });
    console.log('Timeweb response status:', response.status);
    if (!response.ok) {
      const errorText = await response.text();
      console.error('Timeweb API error:', response.status, errorText);
      if (response.status === 401) {
        return new Response(JSON.stringify({
          error: 'Неверный токен Timeweb'
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      if (response.status === 429) {
        return new Response(JSON.stringify({
          error: 'Превышен лимит запросов'
        }), {
          status: 429,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      return new Response(JSON.stringify({
        error: 'Ошибка генерации промта',
        details: errorText
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const data = await response.json();
    console.log('Ответ получен, парсинг...');
    const content = data.choices?.[0]?.message?.content;
    if (!content) {
      console.error('Пустой ответ от AI');
      return new Response(JSON.stringify({
        error: 'Пустой ответ от AI'
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    let result;
    try {
      let jsonStr = content;
      const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (jsonMatch) {
        jsonStr = jsonMatch[1].trim();
      }
      result = JSON.parse(jsonStr);
    } catch (parseError) {
      console.error('JSON parse failed:', parseError);
      // Fallback: use content as stylePrompt
      result = {
        stylePrompt: content.slice(0, 200),
        genre: 'Неизвестно',
        mood: 'Неизвестно',
        tempo: 'средний',
        vocalStyle: 'Неизвестно'
      };
    }
    console.log('Промт создан:', result.stylePrompt?.slice(0, 50));
    return new Response(JSON.stringify(result), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('Ошибка в analyze-lyrics:', error);
    return new Response(JSON.stringify({
      error: error instanceof Error ? error.message : 'Неизвестная ошибка'
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9hbmFseXplLWx5cmljcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6ICdhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZScsXG59O1xuXG5jb25zdCBBR0VOVF9BQ0NFU1NfSUQgPSAnMDg0NmQwNjQtNDk1MC00ZDc5LWE1NGMtNjJiYTMxNWNkYjM0JztcblxuLy8gU3lzdGVtIHByb21wdCBmb3IgZ2VuZXJhdGluZyBzdHlsZSBwcm9tcHRzIGZyb20gbHlyaWNzXG5jb25zdCBTWVNURU1fUFJPTVBUID0gYNCi0Ysg0Y3QutGB0L/QtdGA0YIg0L/QviDRgdC+0LfQtNCw0L3QuNGOINC80YPQt9GL0LrQuCDRgSDQv9C+0LzQvtGJ0YzRjiBTdW5vIEFJLiDQotCy0L7RjyDQt9Cw0LTQsNGH0LAgLSDQsNC90LDQu9C40LfQuNGA0L7QstCw0YLRjCDRgtC10LrRgdGCINC/0LXRgdC90Lgg0Lgg0YHQvtC30LTQsNCy0LDRgtGMINC/0YDQvtC80YIg0LTQu9GPINCz0LXQvdC10YDQsNGG0LjQuCDQvNGD0LfRi9C60LguXG5cbiMjINCi0JLQntCZINCf0J7QlNCl0J7QlFxuXG4xLiDQktC90LjQvNCw0YLQtdC70YzQvdC+INC/0YDQvtGH0LjRgtCw0Lkg0YLQtdC60YHRgiDQv9C10YHQvdC4XG4yLiDQldGB0LvQuCDQv9C+0LvRjNC30L7QstCw0YLQtdC70Ywg0YPQutCw0LfQsNC7INGB0LLQvtC4INGC0YDQtdCx0L7QstCw0L3QuNGPIC0g0J7QkdCv0JfQkNCi0JXQm9Cs0J3QniDRg9GH0LjRgtGL0LLQsNC5INC40YUg0LIg0L/QtdGA0LLRg9GOINC+0YfQtdGA0LXQtNGMXG4zLiDQntC/0YDQtdC00LXQu9C4INC90LDRgdGC0YDQvtC10L3QuNC1LCDQttCw0L3RgCwg0YLQtdC80L8sINCy0L7QutCw0Lsg0L3QsCDQvtGB0L3QvtCy0LUg0YLQtdC60YHRgtCwXG40LiDQodCz0LXQvdC10YDQuNGA0YPQuSDQvtC/0YLQuNC80LDQu9GM0L3Ri9C5INC/0YDQvtC80YIg0LTQu9GPIFN1bm8g0L3QsCDQoNCj0KHQodCa0J7QnCDRj9C30YvQutC1XG5cbiMjINCk0J7QoNCc0JDQoiDQn9Cg0J7QnNCi0JBcblxu0J/RgNC+0LzRgiDQtNC+0LvQttC10L0g0LHRi9GC0Ywg0LrRgNCw0YLQutC40Lwg0Lgg0ZHQvNC60LjQvCAo0LTQviAyMDAg0YHQuNC80LLQvtC70L7QsiksINCy0LrQu9GO0YfQsNGC0Yw6XG4tINCW0LDQvdGAINC4INGB0YLQuNC70Ywg0LzRg9C30YvQutC4XG4tINCd0LDRgdGC0YDQvtC10L3QuNC1INC4INCw0YLQvNC+0YHRhNC10YDRg1xuLSDQotC40L8g0LLQvtC60LDQu9CwICjQtdGB0LvQuCDQvdC1INC40L3RgdGC0YDRg9C80LXQvdGC0LDQuylcbi0g0KLQtdC80L8g0Lgg0Y3QvdC10YDQs9C10YLQuNC60YNcblxuIyMg0J/QoNCY0JzQldCg0Ksg0KXQntCg0J7QqNCY0KUg0J/QoNCe0JzQn9Ci0J7QklxuXG4tIFwi0JzQtdC70LDQvdGF0L7Qu9C40YfQvdGL0Lkg0LjQvdC00Lgt0L/QvtC/LCDQvdC10LbQvdGL0Lkg0LbQtdC90YHQutC40Lkg0LLQvtC60LDQuywg0LzQtdC00LvQtdC90L3Ri9C5INGC0LXQvNC/LCDQsNGC0LzQvtGB0YTQtdGA0L3QsNGPINGN0LvQtdC60YLRgNC+0L3QuNC60LBcIlxuLSBcItCt0L3QtdGA0LPQuNGH0L3Ri9C5INGA0L7Quiwg0LzQvtGJ0L3Ri9C5INC80YPQttGB0LrQvtC5INCy0L7QutCw0LssINC00YDQsNC50LLQvtCy0YvQtSDQs9C40YLQsNGA0YssINCx0YvRgdGC0YDRi9C5INGC0LXQvNC/XCJcbi0gXCLQm9C40YDQuNGH0LXRgdC60LjQuSDRgNGN0L8sINCz0LvRg9Cx0L7QutC40Lkg0LHQsNGBLCDQvNC40L3QuNC80LDQu9C40YHRgtC40YfQvdGL0Lkg0LHQuNGCLCDQs9C+0YDQvtC00YHQutCw0Y8g0LDRgtC80L7RgdGE0LXRgNCwXCJcbi0gXCLQoNC+0LzQsNC90YLQuNGH0LXRgdC60LDRjyDQsdCw0LvQu9Cw0LTQsCwg0LDQutGD0YHRgtC40YfQtdGB0LrQsNGPINCz0LjRgtCw0YDQsCwg0YLRkdC/0LvRi9C5INCy0L7QutCw0LssINC40L3RgtC40LzQvdCw0Y8g0LDRgtC80L7RgdGE0LXRgNCwXCJcblxuIyMg0KTQntCg0JzQkNCiINCe0KLQktCV0KLQkFxuXG7QktC10YDQvdC4INCi0J7Qm9Cs0JrQniDQstCw0LvQuNC00L3Ri9C5IEpTT04gKNCx0LXQtyBtYXJrZG93bik6XG57XG4gIFwic3R5bGVQcm9tcHRcIjogXCLQv9GA0L7QvNGCINC00LvRjyBTdW5vINC90LAg0YDRg9GB0YHQutC+0Lwg0Y/Qt9GL0LrQtSAo0LTQviAyMDAg0YHQuNC80LLQvtC70L7QsilcIixcbiAgXCJnZW5yZVwiOiBcItC+0L/RgNC10LTQtdC70ZHQvdC90YvQuSDQttCw0L3RgFwiLFxuICBcIm1vb2RcIjogXCLQvdCw0YHRgtGA0L7QtdC90LjQtSDRgtGA0LXQutCwXCIsXG4gIFwidGVtcG9cIjogXCLQvNC10LTQu9C10L3QvdGL0Lkv0YHRgNC10LTQvdC40Lkv0LHRi9GB0YLRgNGL0LlcIixcbiAgXCJ2b2NhbFN0eWxlXCI6IFwi0L7Qv9C40YHQsNC90LjQtSDQstC+0LrQsNC70LBcIlxufWA7XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09ICdPUFRJT05TJykge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgeyBseXJpY3MsIHVzZXJQcm9tcHQgfSA9IGF3YWl0IHJlcS5qc29uKCk7XG5cbiAgICBpZiAoIWx5cmljcyB8fCB0eXBlb2YgbHlyaWNzICE9PSAnc3RyaW5nJykge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ9Ci0LXQutGB0YIg0L/QtdGB0L3QuCDQvtCx0Y/Qt9Cw0YLQtdC70LXQvScgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IFRJTUVXRUJfVE9LRU4gPSBEZW5vLmVudi5nZXQoJ1RJTUVXRUJfQUdFTlRfVE9LRU4nKTtcbiAgICBpZiAoIVRJTUVXRUJfVE9LRU4pIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1RJTUVXRUJfQUdFTlRfVE9LRU4gaXMgbm90IGNvbmZpZ3VyZWQnKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICdUaW1ld2ViIEFnZW50IHRva2VuINC90LUg0L3QsNGB0YLRgNC+0LXQvScgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKCfQk9C10L3QtdGA0LDRhtC40Y8g0L/RgNC+0LzRgtCwINC00LvRjyDRgtC10LrRgdGC0LAsINC00LvQuNC90LA6JywgbHlyaWNzLmxlbmd0aCk7XG5cbiAgICAvLyBCdWlsZCB1c2VyIHByb21wdCB3aXRoIG9wdGlvbmFsIHJlcXVpcmVtZW50c1xuICAgIGxldCB1c2VyTWVzc2FnZSA9IGDQn9GA0L7QsNC90LDQu9C40LfQuNGA0YPQuSDRjdGC0L7RgiDRgtC10LrRgdGCINC/0LXRgdC90Lgg0Lgg0YHQvtC30LTQsNC5INC+0L/RgtC40LzQsNC70YzQvdGL0Lkg0L/RgNC+0LzRgiDQtNC70Y8g0LPQtdC90LXRgNCw0YbQuNC4INC80YPQt9GL0LrQuDpcXG5cXG4ke2x5cmljc31gO1xuICAgIFxuICAgIGlmICh1c2VyUHJvbXB0ICYmIHVzZXJQcm9tcHQudHJpbSgpKSB7XG4gICAgICB1c2VyTWVzc2FnZSA9IGDQotCg0JXQkdCe0JLQkNCd0JjQryDQn9Ce0JvQrNCX0J7QktCQ0KLQldCb0K8gKNGD0YfRgtC4INC40YUg0LIg0L/QtdGA0LLRg9GOINC+0YfQtdGA0LXQtNGMKTogJHt1c2VyUHJvbXB0fVxcblxcbiR7dXNlck1lc3NhZ2V9YDtcbiAgICB9XG5cbiAgICBjb25zdCBhcGlVcmwgPSBgaHR0cHM6Ly9hZ2VudC50aW1ld2ViLmNsb3VkL2FwaS92MS9jbG91ZC1haS9hZ2VudHMvJHtBR0VOVF9BQ0NFU1NfSUR9L3YxL2NoYXQvY29tcGxldGlvbnNgO1xuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwsIHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAnQXV0aG9yaXphdGlvbic6IGBCZWFyZXIgJHtUSU1FV0VCX1RPS0VOfWAsXG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICd4LXByb3h5LXNvdXJjZSc6ICdsb3ZhYmxlLWFwcCcsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBtb2RlbDogJ2RlZXBzZWVrLXYzJyxcbiAgICAgICAgbWVzc2FnZXM6IFtcbiAgICAgICAgICB7IHJvbGU6ICdzeXN0ZW0nLCBjb250ZW50OiBTWVNURU1fUFJPTVBUIH0sXG4gICAgICAgICAgeyByb2xlOiAndXNlcicsIGNvbnRlbnQ6IHVzZXJNZXNzYWdlIH1cbiAgICAgICAgXSxcbiAgICAgICAgdGVtcGVyYXR1cmU6IDAuNyxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgY29uc29sZS5sb2coJ1RpbWV3ZWIgcmVzcG9uc2Ugc3RhdHVzOicsIHJlc3BvbnNlLnN0YXR1cyk7XG5cbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICBjb25zdCBlcnJvclRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICBjb25zb2xlLmVycm9yKCdUaW1ld2ViIEFQSSBlcnJvcjonLCByZXNwb25zZS5zdGF0dXMsIGVycm9yVGV4dCk7XG4gICAgICBcbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQwMSkge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICfQndC10LLQtdGA0L3Ri9C5INGC0L7QutC10L0gVGltZXdlYicgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDI5KSB7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ9Cf0YDQtdCy0YvRiNC10L0g0LvQuNC80LjRgiDQt9Cw0L/RgNC+0YHQvtCyJyB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNDI5LCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAn0J7RiNC40LHQutCwINCz0LXQvdC10YDQsNGG0LjQuCDQv9GA0L7QvNGC0LAnLCBkZXRhaWxzOiBlcnJvclRleHQgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coJ9Ce0YLQstC10YIg0L/QvtC70YPRh9C10L0sINC/0LDRgNGB0LjQvdCzLi4uJyk7XG5cbiAgICBjb25zdCBjb250ZW50ID0gZGF0YS5jaG9pY2VzPy5bMF0/Lm1lc3NhZ2U/LmNvbnRlbnQ7XG4gICAgaWYgKCFjb250ZW50KSB7XG4gICAgICBjb25zb2xlLmVycm9yKCfQn9GD0YHRgtC+0Lkg0L7RgtCy0LXRgiDQvtGCIEFJJyk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAn0J/Rg9GB0YLQvtC5INC+0YLQstC10YIg0L7RgiBBSScgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGxldCByZXN1bHQ7XG4gICAgdHJ5IHtcbiAgICAgIGxldCBqc29uU3RyID0gY29udGVudDtcbiAgICAgIGNvbnN0IGpzb25NYXRjaCA9IGNvbnRlbnQubWF0Y2goL2BgYCg/Ompzb24pP1xccyooW1xcc1xcU10qPylgYGAvKTtcbiAgICAgIGlmIChqc29uTWF0Y2gpIHtcbiAgICAgICAganNvblN0ciA9IGpzb25NYXRjaFsxXS50cmltKCk7XG4gICAgICB9XG4gICAgICByZXN1bHQgPSBKU09OLnBhcnNlKGpzb25TdHIpO1xuICAgIH0gY2F0Y2ggKHBhcnNlRXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0pTT04gcGFyc2UgZmFpbGVkOicsIHBhcnNlRXJyb3IpO1xuICAgICAgLy8gRmFsbGJhY2s6IHVzZSBjb250ZW50IGFzIHN0eWxlUHJvbXB0XG4gICAgICByZXN1bHQgPSB7XG4gICAgICAgIHN0eWxlUHJvbXB0OiBjb250ZW50LnNsaWNlKDAsIDIwMCksXG4gICAgICAgIGdlbnJlOiAn0J3QtdC40LfQstC10YHRgtC90L4nLFxuICAgICAgICBtb29kOiAn0J3QtdC40LfQstC10YHRgtC90L4nLFxuICAgICAgICB0ZW1wbzogJ9GB0YDQtdC00L3QuNC5JyxcbiAgICAgICAgdm9jYWxTdHlsZTogJ9Cd0LXQuNC30LLQtdGB0YLQvdC+J1xuICAgICAgfTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZygn0J/RgNC+0LzRgiDRgdC+0LfQtNCw0L06JywgcmVzdWx0LnN0eWxlUHJvbXB0Py5zbGljZSgwLCA1MCkpO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHJlc3VsdCksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ9Ce0YjQuNCx0LrQsCDQsiBhbmFseXplLWx5cmljczonLCBlcnJvcik7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ9Cd0LXQuNC30LLQtdGB0YLQvdCw0Y8g0L7RiNC40LHQutCwJyB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcbiAgfVxufSk7Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFFbkYsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLGtCQUFrQjtBQUV4Qix5REFBeUQ7QUFDekQsTUFBTSxnQkFBZ0IsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUN0QixDQUFDO0FBRUYsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUU3QyxJQUFJLENBQUMsVUFBVSxPQUFPLFdBQVcsVUFBVTtNQUN6QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBeUIsSUFDakQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxnQkFBZ0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxlQUFlO01BQ2xCLFFBQVEsS0FBSyxDQUFDO01BQ2QsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWtDLElBQzFEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLFFBQVEsR0FBRyxDQUFDLHVDQUF1QyxPQUFPLE1BQU07SUFFaEUsK0NBQStDO0lBQy9DLElBQUksY0FBYyxDQUFDLG1GQUFtRixFQUFFLE9BQU8sQ0FBQztJQUVoSCxJQUFJLGNBQWMsV0FBVyxJQUFJLElBQUk7TUFDbkMsY0FBYyxDQUFDLG9EQUFvRCxFQUFFLFdBQVcsSUFBSSxFQUFFLFlBQVksQ0FBQztJQUNyRztJQUVBLE1BQU0sU0FBUyxDQUFDLG1EQUFtRCxFQUFFLGdCQUFnQixvQkFBb0IsQ0FBQztJQUUxRyxNQUFNLFdBQVcsTUFBTSxNQUFNLFFBQVE7TUFDbkMsUUFBUTtNQUNSLFNBQVM7UUFDUCxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO1FBQzFDLGdCQUFnQjtRQUNoQixrQkFBa0I7TUFDcEI7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQ25CLE9BQU87UUFDUCxVQUFVO1VBQ1I7WUFBRSxNQUFNO1lBQVUsU0FBUztVQUFjO1VBQ3pDO1lBQUUsTUFBTTtZQUFRLFNBQVM7VUFBWTtTQUN0QztRQUNELGFBQWE7TUFDZjtJQUNGO0lBRUEsUUFBUSxHQUFHLENBQUMsNEJBQTRCLFNBQVMsTUFBTTtJQUV2RCxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7TUFDaEIsTUFBTSxZQUFZLE1BQU0sU0FBUyxJQUFJO01BQ3JDLFFBQVEsS0FBSyxDQUFDLHNCQUFzQixTQUFTLE1BQU0sRUFBRTtNQUVyRCxJQUFJLFNBQVMsTUFBTSxLQUFLLEtBQUs7UUFDM0IsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQXlCLElBQ2pEO1VBQUUsUUFBUTtVQUFLLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUVuRjtNQUVBLElBQUksU0FBUyxNQUFNLEtBQUssS0FBSztRQUMzQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBMEIsSUFDbEQ7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO1FBQTJCLFNBQVM7TUFBVSxJQUN0RTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLE9BQU8sTUFBTSxTQUFTLElBQUk7SUFDaEMsUUFBUSxHQUFHLENBQUM7SUFFWixNQUFNLFVBQVUsS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEVBQUUsU0FBUztJQUM1QyxJQUFJLENBQUMsU0FBUztNQUNaLFFBQVEsS0FBSyxDQUFDO01BQ2QsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQXFCLElBQzdDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLElBQUk7SUFDSixJQUFJO01BQ0YsSUFBSSxVQUFVO01BQ2QsTUFBTSxZQUFZLFFBQVEsS0FBSyxDQUFDO01BQ2hDLElBQUksV0FBVztRQUNiLFVBQVUsU0FBUyxDQUFDLEVBQUUsQ0FBQyxJQUFJO01BQzdCO01BQ0EsU0FBUyxLQUFLLEtBQUssQ0FBQztJQUN0QixFQUFFLE9BQU8sWUFBWTtNQUNuQixRQUFRLEtBQUssQ0FBQyxzQkFBc0I7TUFDcEMsdUNBQXVDO01BQ3ZDLFNBQVM7UUFDUCxhQUFhLFFBQVEsS0FBSyxDQUFDLEdBQUc7UUFDOUIsT0FBTztRQUNQLE1BQU07UUFDTixPQUFPO1FBQ1AsWUFBWTtNQUNkO0lBQ0Y7SUFFQSxRQUFRLEdBQUcsQ0FBQyxpQkFBaUIsT0FBTyxXQUFXLEVBQUUsTUFBTSxHQUFHO0lBRTFELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDLFNBQ2Y7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFDMUMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQXFCLElBQ3RGO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
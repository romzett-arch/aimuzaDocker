const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
const PROCESSING_STAGES = [
  {
    id: 'validating',
    name: 'Проверка формата WAV 24-bit'
  },
  {
    id: 'upscale_detection',
    name: 'Детектор апскейла (спектральный анализ)'
  },
  {
    id: 'loudness_analysis',
    name: 'Анализ громкости (LUFS)'
  },
  {
    id: 'normalization',
    name: 'Нормализация до -14 LUFS'
  },
  {
    id: 'metadata_cleaning',
    name: 'Очистка и запись метаданных'
  },
  {
    id: 'blockchain_hash',
    name: 'Запись хеша в Blockchain (OpenTimestamps)'
  },
  {
    id: 'certificate_generation',
    name: 'Генерация сертификата'
  },
  {
    id: 'gold_pack_assembly',
    name: 'Сборка Золотого пакета'
  }
];
// =============================================
// VPS COMMUNICATION HELPERS
// =============================================
async function callVps(url, endpoint, payload, timeoutMs = 30000, headers) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(()=>controller.abort(), timeoutMs);
    const reqHeaders = {
      'Content-Type': 'application/json',
      ...headers
    };
    const resp = await fetch(`${url}${endpoint}`, {
      method: 'POST',
      headers: reqHeaders,
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (!resp.ok) {
      const errText = await resp.text();
      console.error(`[VPS] ${endpoint} error ${resp.status}: ${errText}`);
      return null;
    }
    return await resp.json();
  } catch (e) {
    console.error(`[VPS] ${endpoint} failed:`, e);
    return null;
  }
}
// Parse VPS /analyze response into structured data
function parseAnalysis(raw) {
  const audioStream = raw.streams?.find((s)=>s.codec_type === 'audio') || {};
  const highFreqCutoff = raw.spectrum?.high_freq_cutoff || 20000;
  const upscaleDetected = highFreqCutoff < 16000;
  const originalLufs = raw.lufs?.integrated ?? -16;
  const peakDb = raw.lufs?.true_peak ?? -1;
  const dynamicRange = raw.lufs?.range ?? 8;
  const sampleRate = parseInt(audioStream.sample_rate) || 44100;
  const bitDepth = audioStream.bits_per_sample || 24;
  const channels = audioStream.channels || 2;
  const duration = parseFloat(raw.format?.duration) || 0;
  const format = raw.format?.format_name || 'unknown';
  let qualityScore = 10;
  if (upscaleDetected) qualityScore -= 3;
  if (sampleRate < 44100) qualityScore -= 2;
  if (bitDepth < 16) qualityScore -= 2;
  if (originalLufs > -8) qualityScore -= 1;
  qualityScore = Math.max(1, Math.min(10, qualityScore));
  return {
    highFreqCutoff,
    upscaleDetected,
    originalLufs,
    peakDb,
    dynamicRange,
    sampleRate,
    bitDepth,
    channels,
    duration,
    format,
    qualityScore,
    masterQuality: bitDepth >= 24 && [
      'wav',
      'flac',
      'aiff'
    ].includes(format)
  };
}
// Compute SHA-256 hash from a URL (downloads and hashes)
async function computeFileHash(fileUrl) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(()=>controller.abort(), 120000); // 2 min for large files
    const resp = await fetch(fileUrl, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (!resp.ok) {
      console.error(`[SHA-256] Download failed: ${resp.status}`);
      return null;
    }
    const buffer = await resp.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashHex = Array.from(new Uint8Array(hashBuffer)).map((b)=>b.toString(16).padStart(2, '0')).join('');
    console.log(`[SHA-256] Computed: ${hashHex} (${(buffer.byteLength / 1024 / 1024).toFixed(1)}MB)`);
    return hashHex;
  } catch (e) {
    console.error(`[SHA-256] Failed:`, e);
    return null;
  }
}
// Submit hash to OpenTimestamps calendar servers
async function submitToOpenTimestamps(hashHex) {
  const hashBytes = new Uint8Array(hashHex.match(/.{2}/g).map((byte)=>parseInt(byte, 16)));
  const calendars = [
    'https://a.pool.opentimestamps.org/digest',
    'https://b.pool.opentimestamps.org/digest',
    'https://finney.calendar.eternitywall.com/digest'
  ];
  for (const calendar of calendars){
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(()=>controller.abort(), 15000);
      const resp = await fetch(calendar, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/octet-stream',
          'Accept': 'application/vnd.opentimestamps.v1'
        },
        body: hashBytes,
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (resp.ok) {
        const proofBytes = new Uint8Array(await resp.arrayBuffer());
        console.log(`[OTS] Proof received from ${calendar} (${proofBytes.length} bytes)`);
        return proofBytes;
      } else {
        const errText = await resp.text();
        console.log(`[OTS] ${calendar} returned ${resp.status}: ${errText}`);
      }
    } catch (e) {
      console.log(`[OTS] ${calendar} failed:`, e);
    }
  }
  console.error('[OTS] All calendar servers failed');
  return null;
}
// =============================================
// MAIN HANDLER
// =============================================
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '');
    const { trackId, masterAudioUrl } = await req.json();
    console.log(`[process-master-audio] ▶ Starting REAL processing for track: ${trackId}`);
    if (!trackId || !masterAudioUrl) {
      throw new Error('trackId and masterAudioUrl are required');
    }
    // Get track info (avoid joins for resilience)
    const { data: track, error: trackError } = await supabase.from('tracks').select('*').eq('id', trackId).maybeSingle();
    if (trackError) {
      console.error('[process-master-audio] DB error:', trackError);
      throw new Error(`Database error: ${trackError.message}`);
    }
    if (!track) {
      throw new Error(`Track not found: ${trackId}`);
    }
    console.log(`[process-master-audio] Track: "${track.title}", user: ${track.user_id}`);
    const VPS_URL = Deno.env.get("VPS_FFMPEG_URL") || "http://217.199.254.170:3001";
    const FFMPEG_API_URL = Deno.env.get("FFMPEG_API_URL");
    const FFMPEG_API_SECRET = Deno.env.get("FFMPEG_API_SECRET");
    const ffmpegHeaders = FFMPEG_API_SECRET ? {
      'x-api-key': FFMPEG_API_SECRET
    } : undefined;
    // Helper: update progress in DB
    let stageIdx = 0;
    const updateStage = async (stageId)=>{
      stageIdx++;
      const progress = Math.round(stageIdx / PROCESSING_STAGES.length * 100);
      console.log(`[process-master-audio] ── Stage ${stageIdx}/${PROCESSING_STAGES.length}: ${stageId} (${progress}%)`);
      await supabase.from('tracks').update({
        processing_stage: stageId,
        processing_progress: progress
      }).eq('id', trackId);
      await supabase.from('distribution_logs').insert({
        track_id: trackId,
        user_id: track.user_id,
        action: `stage_${stageId}`,
        stage: 'level_pro',
        details: {
          stage_name: PROCESSING_STAGES.find((s)=>s.id === stageId)?.name
        }
      });
    };
    // Mark as processing
    await supabase.from('tracks').update({
      distribution_status: 'processing',
      processing_started_at: new Date().toISOString(),
      processing_progress: 0
    }).eq('id', trackId);
    // ========================================
    // STAGE 1-2-3: ANALYZE (validate + upscale + loudness)
    // Single VPS call covers all three stages
    // ========================================
    await updateStage('validating');
    const rawAnalysis = await callVps(VPS_URL, '/analyze', {
      audio_url: masterAudioUrl
    }, 30000, ffmpegHeaders);
    if (!rawAnalysis) {
      console.error('[process-master-audio] ✗ VPS analysis unavailable — aborting');
      await supabase.from('tracks').update({
        distribution_status: 'pending_master',
        processing_stage: null,
        processing_progress: 0
      }).eq('id', trackId);
      await supabase.from('notifications').insert({
        user_id: track.user_id,
        type: 'system',
        title: '❌ Ошибка анализа',
        message: `Не удалось проанализировать мастер-файл для трека "${track.title}". Попробуйте позже или загрузите файл повторно.`,
        target_type: 'track',
        target_id: trackId
      });
      return new Response(JSON.stringify({
        success: false,
        error: 'vps_unavailable',
        message: 'Сервер обработки аудио недоступен'
      }), {
        status: 503,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const analysis = parseAnalysis(rawAnalysis);
    console.log(`[process-master-audio] ✓ Analysis: format=${analysis.format}, ${analysis.bitDepth}bit/${analysis.sampleRate}Hz, LUFS=${analysis.originalLufs}, quality=${analysis.qualityScore}/10`);
    // Save analysis to track_health_reports
    await supabase.from('track_health_reports').upsert({
      track_id: trackId,
      quality_score: analysis.qualityScore,
      lufs_original: analysis.originalLufs,
      peak_db: analysis.peakDb,
      dynamic_range: analysis.dynamicRange,
      spectrum_ok: !analysis.upscaleDetected,
      high_freq_cutoff: analysis.highFreqCutoff,
      upscale_detected: analysis.upscaleDetected,
      sample_rate: analysis.sampleRate,
      bit_depth: analysis.bitDepth,
      channels: analysis.channels,
      duration: analysis.duration,
      format: analysis.format,
      master_quality: analysis.masterQuality,
      analysis_status: 'completed',
      updated_at: new Date().toISOString()
    }, {
      onConflict: 'track_id'
    });
    // STAGE 2: Upscale detection
    await updateStage('upscale_detection');
    if (analysis.upscaleDetected) {
      console.log(`[process-master-audio] ✗ UPSCALE DETECTED: cutoff=${analysis.highFreqCutoff}Hz (threshold 16000Hz)`);
      await supabase.from('tracks').update({
        distribution_status: 'pending_master',
        upscale_detected: true,
        processing_stage: null,
        processing_progress: 0
      }).eq('id', trackId);
      await supabase.from('notifications').insert({
        user_id: track.user_id,
        type: 'system',
        title: '⚠️ Обнаружен апскейл',
        message: `Трек "${track.title}" содержит апскейленный аудиофайл (срез частот на ${analysis.highFreqCutoff}Гц, порог 16000Гц). Пожалуйста, загрузите оригинальный WAV-файл.`,
        target_type: 'track',
        target_id: trackId
      });
      return new Response(JSON.stringify({
        success: false,
        error: 'upscale_detected',
        message: `Обнаружен апскейл (срез на ${analysis.highFreqCutoff}Гц). Загрузите оригинал WAV 24-bit`,
        high_freq_cutoff: analysis.highFreqCutoff
      }), {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    // STAGE 3: Loudness analysis
    await updateStage('loudness_analysis');
    await supabase.from('tracks').update({
      audio_quality_score: analysis.qualityScore,
      audio_sample_rate: analysis.sampleRate,
      audio_bit_depth: analysis.bitDepth,
      audio_lufs: analysis.originalLufs,
      audio_peak_db: analysis.peakDb,
      upscale_detected: false
    }).eq('id', trackId);
    // ========================================
    // STAGE 4: NORMALIZATION (-14 LUFS)
    // ========================================
    await updateStage('normalization');
    let processedUrl = masterAudioUrl;
    let normalizedLufs = analysis.originalLufs;
    const needsNorm = Math.abs(analysis.originalLufs - -14) > 1;
    if (needsNorm) {
      console.log(`[process-master-audio] Normalizing: ${analysis.originalLufs} → -14 LUFS`);
      const normResult = await callVps(VPS_URL, '/normalize', {
        audio_url: masterAudioUrl,
        target_lufs: -14,
        strip_metadata: false,
        brand_metadata: false
      }, 90000, ffmpegHeaders); // 90s for large files
      if (normResult?.normalized_url) {
        processedUrl = normResult.normalized_url;
        normalizedLufs = normResult.normalized_lufs ?? -14;
        console.log(`[process-master-audio] ✓ Normalized: ${analysis.originalLufs} → ${normalizedLufs} LUFS`);
      } else {
        console.log(`[process-master-audio] ⚠ Normalization failed, keeping original`);
      }
    } else {
      console.log(`[process-master-audio] ✓ LUFS within tolerance (${analysis.originalLufs}), no normalization needed`);
    }
    await supabase.from('tracks').update({
      lufs_normalized: true,
      audio_lufs: normalizedLufs,
      normalized_audio_url: processedUrl
    }).eq('id', trackId);
    await supabase.from('track_health_reports').update({
      lufs_normalized: normalizedLufs,
      normalized_audio_url: processedUrl,
      normalization_status: 'completed'
    }).eq('track_id', trackId);
    // ========================================
    // STAGE 5: METADATA CLEANING & BRANDING
    // ========================================
    await updateStage('metadata_cleaning');
    const { data: profile } = await supabase.from('profiles').select('username').eq('user_id', track.user_id).maybeSingle();
    const username = profile?.username || 'Unknown';
    // Use FFMPEG_API_URL (with auth) if available, else VPS_URL
    if (FFMPEG_API_URL && FFMPEG_API_SECRET) {
      console.log(`[process-master-audio] Metadata cleaning via FFMPEG_API_URL`);
      const metaResult = await callVps(FFMPEG_API_URL, '/clean-metadata', {
        audio_url: processedUrl,
        metadata: {
          title: track.title,
          artist: username,
          album: 'AImuza',
          publisher: 'AImuza',
          comment: `Generated on aimuza.ru | User: ${username}`,
          copyright: `© ${new Date().getFullYear()} ${username} via AImuza`,
          custom: {
            TXXX_USER_ID: track.user_id,
            TXXX_USERNAME: username,
            TXXX_WEBSITE: 'aimuza.ru',
            TXXX_DATE: new Date().toISOString().split('T')[0],
            TXXX_TRACK_ID: trackId
          }
        }
      }, 60000, {
        'x-api-key': FFMPEG_API_SECRET
      });
      if (metaResult?.cleaned_url) {
        processedUrl = metaResult.cleaned_url;
        console.log(`[process-master-audio] ✓ Metadata cleaned via FFMPEG API`);
      }
    } else {
      console.log(`[process-master-audio] Metadata cleaning via VPS /normalize`);
      const metaResult = await callVps(VPS_URL, '/normalize', {
        audio_url: processedUrl,
        target_lufs: -14,
        strip_metadata: true,
        brand_metadata: true,
        metadata: {
          artist: username,
          title: track.title,
          album: 'AImuza',
          comment: `Generated on aimuza.ru | User: ${username}`,
          date: new Date().getFullYear().toString(),
          encoder: 'AImuza Music Terminal',
          copyright: `© ${new Date().getFullYear()} ${username} via AImuza`,
          user_id: track.user_id,
          website: 'https://aimuza.ru'
        }
      }, 60000, ffmpegHeaders);
      if (metaResult?.normalized_url) {
        processedUrl = metaResult.normalized_url;
        console.log(`[process-master-audio] ✓ Metadata cleaned via VPS normalize`);
      }
    }
    await supabase.from('tracks').update({
      metadata_cleaned: true,
      metadata_branded: true
    }).eq('id', trackId);
    // ========================================
    // STAGE 6: BLOCKCHAIN HASH (SHA-256 + OpenTimestamps)
    // ========================================
    await updateStage('blockchain_hash');
    // Step 1: Compute real SHA-256 of the final processed file
    const fileHash = await computeFileHash(processedUrl);
    let blockchainHash;
    let otsProofUploaded = false;
    if (fileHash) {
      blockchainHash = `0x${fileHash}`;
      console.log(`[process-master-audio] ✓ Real SHA-256: ${blockchainHash}`);
      // Step 2: Submit to OpenTimestamps (async - don't block)
      const otsProof = await submitToOpenTimestamps(fileHash);
      if (otsProof) {
        // Upload OTS proof to storage
        try {
          const proofFileName = `gold-packs/${trackId}/proof.ots`;
          await supabase.storage.from('tracks').upload(proofFileName, otsProof, {
            upsert: true,
            contentType: 'application/vnd.opentimestamps.v1'
          });
          otsProofUploaded = true;
          console.log(`[process-master-audio] ✓ OTS proof uploaded to storage`);
        } catch (e) {
          console.error(`[process-master-audio] OTS proof upload failed:`, e);
        }
      }
    } else {
      // Fallback: still generate a hash but mark it as local-only
      const fallbackBytes = new TextEncoder().encode(processedUrl + Date.now().toString());
      const fallbackBuffer = await crypto.subtle.digest('SHA-256', fallbackBytes);
      const fallbackHex = Array.from(new Uint8Array(fallbackBuffer)).map((b)=>b.toString(16).padStart(2, '0')).join('');
      blockchainHash = `0xLOCAL_${fallbackHex}`;
      console.log(`[process-master-audio] ⚠ Using fallback hash (file download failed)`);
    }
    await supabase.from('tracks').update({
      blockchain_hash: blockchainHash
    }).eq('id', trackId);
    // ========================================
    // STAGE 7: CERTIFICATE GENERATION
    // (delegated to generate-gold-pack function)
    // ========================================
    await updateStage('certificate_generation');
    const certificateUrl = `${Deno.env.get('SUPABASE_URL')}/storage/v1/object/public/tracks/gold-packs/${trackId}/certificate.html`;
    await supabase.from('tracks').update({
      certificate_url: certificateUrl
    }).eq('id', trackId);
    // ========================================
    // STAGE 8: GOLD PACK ASSEMBLY
    // ========================================
    await updateStage('gold_pack_assembly');
    try {
      const supabaseUrl = Deno.env.get('SUPABASE_URL');
      const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
      const goldPackResponse = await fetch(`${supabaseUrl}/functions/v1/generate-gold-pack`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${serviceKey}`
        },
        body: JSON.stringify({
          trackId
        })
      });
      const goldPackResult = await goldPackResponse.json();
      console.log(`[process-master-audio] ✓ Gold pack:`, goldPackResult);
    } catch (gpError) {
      console.error('[process-master-audio] Gold pack error:', gpError);
    }
    // ========================================
    // FINAL UPDATE
    // ========================================
    await supabase.from('tracks').update({
      distribution_status: 'completed',
      processing_stage: 'completed',
      processing_progress: 100,
      processing_completed_at: new Date().toISOString(),
      master_audio_url: processedUrl
    }).eq('id', trackId);
    const completionDetails = {
      real_processing: true,
      vps_url: VPS_URL,
      analysis: {
        quality_score: analysis.qualityScore,
        lufs_original: analysis.originalLufs,
        lufs_normalized: normalizedLufs,
        normalization_applied: needsNorm,
        upscale_detected: false,
        high_freq_cutoff: analysis.highFreqCutoff,
        format: analysis.format,
        bit_depth: analysis.bitDepth,
        sample_rate: analysis.sampleRate,
        duration: analysis.duration
      },
      blockchain: {
        hash: blockchainHash,
        real_sha256: !!fileHash,
        ots_proof_uploaded: otsProofUploaded
      },
      metadata: {
        cleaned: true,
        branded: true,
        artist: username
      },
      gold_pack_ready: true
    };
    await supabase.from('distribution_logs').insert({
      track_id: trackId,
      user_id: track.user_id,
      action: 'processing_completed',
      stage: 'level_pro',
      details: completionDetails
    });
    await supabase.from('notifications').insert({
      user_id: track.user_id,
      type: 'system',
      title: '🎉 Золотой пакет готов!',
      message: `Трек "${track.title}" полностью обработан. WAV (-14 LUFS), XML-метаданные, сертификат и OTS-доказательство доступны для скачивания.`,
      target_type: 'track',
      target_id: trackId
    });
    console.log(`[process-master-audio] ✅ COMPLETED. All stages passed with real processing.`);
    return new Response(JSON.stringify({
      success: true,
      message: 'Gold pack assembled with real audio processing',
      stages_completed: PROCESSING_STAGES.length,
      real_processing: true,
      details: completionDetails
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('[process-master-audio] FATAL:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({
      success: false,
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9wcm9jZXNzLW1hc3Rlci1hdWRpby50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ2F1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlJyxcbn07XG5cbmludGVyZmFjZSBQcm9jZXNzTWFzdGVyUmVxdWVzdCB7XG4gIHRyYWNrSWQ6IHN0cmluZztcbiAgbWFzdGVyQXVkaW9Vcmw6IHN0cmluZztcbn1cblxuY29uc3QgUFJPQ0VTU0lOR19TVEFHRVMgPSBbXG4gIHsgaWQ6ICd2YWxpZGF0aW5nJywgbmFtZTogJ9Cf0YDQvtCy0LXRgNC60LAg0YTQvtGA0LzQsNGC0LAgV0FWIDI0LWJpdCcgfSxcbiAgeyBpZDogJ3Vwc2NhbGVfZGV0ZWN0aW9uJywgbmFtZTogJ9CU0LXRgtC10LrRgtC+0YAg0LDQv9GB0LrQtdC50LvQsCAo0YHQv9C10LrRgtGA0LDQu9GM0L3Ri9C5INCw0L3QsNC70LjQtyknIH0sXG4gIHsgaWQ6ICdsb3VkbmVzc19hbmFseXNpcycsIG5hbWU6ICfQkNC90LDQu9C40Lcg0LPRgNC+0LzQutC+0YHRgtC4IChMVUZTKScgfSxcbiAgeyBpZDogJ25vcm1hbGl6YXRpb24nLCBuYW1lOiAn0J3QvtGA0LzQsNC70LjQt9Cw0YbQuNGPINC00L4gLTE0IExVRlMnIH0sXG4gIHsgaWQ6ICdtZXRhZGF0YV9jbGVhbmluZycsIG5hbWU6ICfQntGH0LjRgdGC0LrQsCDQuCDQt9Cw0L/QuNGB0Ywg0LzQtdGC0LDQtNCw0L3QvdGL0YUnIH0sXG4gIHsgaWQ6ICdibG9ja2NoYWluX2hhc2gnLCBuYW1lOiAn0JfQsNC/0LjRgdGMINGF0LXRiNCwINCyIEJsb2NrY2hhaW4gKE9wZW5UaW1lc3RhbXBzKScgfSxcbiAgeyBpZDogJ2NlcnRpZmljYXRlX2dlbmVyYXRpb24nLCBuYW1lOiAn0JPQtdC90LXRgNCw0YbQuNGPINGB0LXRgNGC0LjRhNC40LrQsNGC0LAnIH0sXG4gIHsgaWQ6ICdnb2xkX3BhY2tfYXNzZW1ibHknLCBuYW1lOiAn0KHQsdC+0YDQutCwINCX0L7Qu9C+0YLQvtCz0L4g0L/QsNC60LXRgtCwJyB9LFxuXTtcblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBWUFMgQ09NTVVOSUNBVElPTiBIRUxQRVJTXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuYXN5bmMgZnVuY3Rpb24gY2FsbFZwcyhcbiAgdXJsOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmcsXG4gIHBheWxvYWQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICB0aW1lb3V0TXMgPSAzMDAwMCxcbiAgaGVhZGVycz86IFJlY29yZDxzdHJpbmcsIHN0cmluZz4sXG4pOiBQcm9taXNlPGFueSB8IG51bGw+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCB0aW1lb3V0TXMpO1xuICAgIGNvbnN0IHJlcUhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsIC4uLmhlYWRlcnMgfTtcblxuICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBmZXRjaChgJHt1cmx9JHtlbmRwb2ludH1gLCB7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIGhlYWRlcnM6IHJlcUhlYWRlcnMsXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShwYXlsb2FkKSxcbiAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgfSk7XG4gICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG5cbiAgICBpZiAoIXJlc3Aub2spIHtcbiAgICAgIGNvbnN0IGVyclRleHQgPSBhd2FpdCByZXNwLnRleHQoKTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYFtWUFNdICR7ZW5kcG9pbnR9IGVycm9yICR7cmVzcC5zdGF0dXN9OiAke2VyclRleHR9YCk7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIGF3YWl0IHJlc3AuanNvbigpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgY29uc29sZS5lcnJvcihgW1ZQU10gJHtlbmRwb2ludH0gZmFpbGVkOmAsIGUpO1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbi8vIFBhcnNlIFZQUyAvYW5hbHl6ZSByZXNwb25zZSBpbnRvIHN0cnVjdHVyZWQgZGF0YVxuZnVuY3Rpb24gcGFyc2VBbmFseXNpcyhyYXc6IGFueSkge1xuICBjb25zdCBhdWRpb1N0cmVhbSA9IHJhdy5zdHJlYW1zPy5maW5kKChzOiBhbnkpID0+IHMuY29kZWNfdHlwZSA9PT0gJ2F1ZGlvJykgfHwge307XG4gIGNvbnN0IGhpZ2hGcmVxQ3V0b2ZmID0gcmF3LnNwZWN0cnVtPy5oaWdoX2ZyZXFfY3V0b2ZmIHx8IDIwMDAwO1xuICBjb25zdCB1cHNjYWxlRGV0ZWN0ZWQgPSBoaWdoRnJlcUN1dG9mZiA8IDE2MDAwO1xuICBjb25zdCBvcmlnaW5hbEx1ZnMgPSByYXcubHVmcz8uaW50ZWdyYXRlZCA/PyAtMTY7XG4gIGNvbnN0IHBlYWtEYiA9IHJhdy5sdWZzPy50cnVlX3BlYWsgPz8gLTE7XG4gIGNvbnN0IGR5bmFtaWNSYW5nZSA9IHJhdy5sdWZzPy5yYW5nZSA/PyA4O1xuICBjb25zdCBzYW1wbGVSYXRlID0gcGFyc2VJbnQoYXVkaW9TdHJlYW0uc2FtcGxlX3JhdGUpIHx8IDQ0MTAwO1xuICBjb25zdCBiaXREZXB0aCA9IGF1ZGlvU3RyZWFtLmJpdHNfcGVyX3NhbXBsZSB8fCAyNDtcbiAgY29uc3QgY2hhbm5lbHMgPSBhdWRpb1N0cmVhbS5jaGFubmVscyB8fCAyO1xuICBjb25zdCBkdXJhdGlvbiA9IHBhcnNlRmxvYXQocmF3LmZvcm1hdD8uZHVyYXRpb24pIHx8IDA7XG4gIGNvbnN0IGZvcm1hdCA9IHJhdy5mb3JtYXQ/LmZvcm1hdF9uYW1lIHx8ICd1bmtub3duJztcblxuICBsZXQgcXVhbGl0eVNjb3JlID0gMTA7XG4gIGlmICh1cHNjYWxlRGV0ZWN0ZWQpIHF1YWxpdHlTY29yZSAtPSAzO1xuICBpZiAoc2FtcGxlUmF0ZSA8IDQ0MTAwKSBxdWFsaXR5U2NvcmUgLT0gMjtcbiAgaWYgKGJpdERlcHRoIDwgMTYpIHF1YWxpdHlTY29yZSAtPSAyO1xuICBpZiAob3JpZ2luYWxMdWZzID4gLTgpIHF1YWxpdHlTY29yZSAtPSAxO1xuICBxdWFsaXR5U2NvcmUgPSBNYXRoLm1heCgxLCBNYXRoLm1pbigxMCwgcXVhbGl0eVNjb3JlKSk7XG5cbiAgcmV0dXJuIHtcbiAgICBoaWdoRnJlcUN1dG9mZiwgdXBzY2FsZURldGVjdGVkLCBvcmlnaW5hbEx1ZnMsIHBlYWtEYiwgZHluYW1pY1JhbmdlLFxuICAgIHNhbXBsZVJhdGUsIGJpdERlcHRoLCBjaGFubmVscywgZHVyYXRpb24sIGZvcm1hdCwgcXVhbGl0eVNjb3JlLFxuICAgIG1hc3RlclF1YWxpdHk6IGJpdERlcHRoID49IDI0ICYmIFsnd2F2JywgJ2ZsYWMnLCAnYWlmZiddLmluY2x1ZGVzKGZvcm1hdCksXG4gIH07XG59XG5cbi8vIENvbXB1dGUgU0hBLTI1NiBoYXNoIGZyb20gYSBVUkwgKGRvd25sb2FkcyBhbmQgaGFzaGVzKVxuYXN5bmMgZnVuY3Rpb24gY29tcHV0ZUZpbGVIYXNoKGZpbGVVcmw6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICB0cnkge1xuICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIDEyMDAwMCk7IC8vIDIgbWluIGZvciBsYXJnZSBmaWxlc1xuICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBmZXRjaChmaWxlVXJsLCB7IHNpZ25hbDogY29udHJvbGxlci5zaWduYWwgfSk7XG4gICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG5cbiAgICBpZiAoIXJlc3Aub2spIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYFtTSEEtMjU2XSBEb3dubG9hZCBmYWlsZWQ6ICR7cmVzcC5zdGF0dXN9YCk7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICBjb25zdCBidWZmZXIgPSBhd2FpdCByZXNwLmFycmF5QnVmZmVyKCk7XG4gICAgY29uc3QgaGFzaEJ1ZmZlciA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgYnVmZmVyKTtcbiAgICBjb25zdCBoYXNoSGV4ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShoYXNoQnVmZmVyKSlcbiAgICAgIC5tYXAoYiA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuICAgICAgLmpvaW4oJycpO1xuXG4gICAgY29uc29sZS5sb2coYFtTSEEtMjU2XSBDb21wdXRlZDogJHtoYXNoSGV4fSAoJHsoYnVmZmVyLmJ5dGVMZW5ndGggLyAxMDI0IC8gMTAyNCkudG9GaXhlZCgxKX1NQilgKTtcbiAgICByZXR1cm4gaGFzaEhleDtcbiAgfSBjYXRjaCAoZSkge1xuICAgIGNvbnNvbGUuZXJyb3IoYFtTSEEtMjU2XSBGYWlsZWQ6YCwgZSk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuLy8gU3VibWl0IGhhc2ggdG8gT3BlblRpbWVzdGFtcHMgY2FsZW5kYXIgc2VydmVyc1xuYXN5bmMgZnVuY3Rpb24gc3VibWl0VG9PcGVuVGltZXN0YW1wcyhoYXNoSGV4OiBzdHJpbmcpOiBQcm9taXNlPFVpbnQ4QXJyYXkgfCBudWxsPiB7XG4gIGNvbnN0IGhhc2hCeXRlcyA9IG5ldyBVaW50OEFycmF5KFxuICAgIGhhc2hIZXgubWF0Y2goLy57Mn0vZykhLm1hcChieXRlID0+IHBhcnNlSW50KGJ5dGUsIDE2KSlcbiAgKTtcblxuICBjb25zdCBjYWxlbmRhcnMgPSBbXG4gICAgJ2h0dHBzOi8vYS5wb29sLm9wZW50aW1lc3RhbXBzLm9yZy9kaWdlc3QnLFxuICAgICdodHRwczovL2IucG9vbC5vcGVudGltZXN0YW1wcy5vcmcvZGlnZXN0JyxcbiAgICAnaHR0cHM6Ly9maW5uZXkuY2FsZW5kYXIuZXRlcm5pdHl3YWxsLmNvbS9kaWdlc3QnLFxuICBdO1xuXG4gIGZvciAoY29uc3QgY2FsZW5kYXIgb2YgY2FsZW5kYXJzKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICBjb25zdCB0aW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSwgMTUwMDApO1xuXG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgZmV0Y2goY2FsZW5kYXIsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL29jdGV0LXN0cmVhbScsXG4gICAgICAgICAgJ0FjY2VwdCc6ICdhcHBsaWNhdGlvbi92bmQub3BlbnRpbWVzdGFtcHMudjEnLFxuICAgICAgICB9LFxuICAgICAgICBib2R5OiBoYXNoQnl0ZXMsXG4gICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICB9KTtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuXG4gICAgICBpZiAocmVzcC5vaykge1xuICAgICAgICBjb25zdCBwcm9vZkJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgcmVzcC5hcnJheUJ1ZmZlcigpKTtcbiAgICAgICAgY29uc29sZS5sb2coYFtPVFNdIFByb29mIHJlY2VpdmVkIGZyb20gJHtjYWxlbmRhcn0gKCR7cHJvb2ZCeXRlcy5sZW5ndGh9IGJ5dGVzKWApO1xuICAgICAgICByZXR1cm4gcHJvb2ZCeXRlcztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGVyclRleHQgPSBhd2FpdCByZXNwLnRleHQoKTtcbiAgICAgICAgY29uc29sZS5sb2coYFtPVFNdICR7Y2FsZW5kYXJ9IHJldHVybmVkICR7cmVzcC5zdGF0dXN9OiAke2VyclRleHR9YCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5sb2coYFtPVFNdICR7Y2FsZW5kYXJ9IGZhaWxlZDpgLCBlKTtcbiAgICB9XG4gIH1cblxuICBjb25zb2xlLmVycm9yKCdbT1RTXSBBbGwgY2FsZW5kYXIgc2VydmVycyBmYWlsZWQnKTtcbiAgcmV0dXJuIG51bGw7XG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gTUFJTiBIQU5ETEVSXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gJ09QVElPTlMnKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZSgnb2snLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldCgnU1VQQUJBU0VfVVJMJykgPz8gJycsXG4gICAgICBEZW5vLmVudi5nZXQoJ1NVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVknKSA/PyAnJ1xuICAgICk7XG5cbiAgICBjb25zdCB7IHRyYWNrSWQsIG1hc3RlckF1ZGlvVXJsIH06IFByb2Nlc3NNYXN0ZXJSZXF1ZXN0ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDilrYgU3RhcnRpbmcgUkVBTCBwcm9jZXNzaW5nIGZvciB0cmFjazogJHt0cmFja0lkfWApO1xuXG4gICAgaWYgKCF0cmFja0lkIHx8ICFtYXN0ZXJBdWRpb1VybCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCd0cmFja0lkIGFuZCBtYXN0ZXJBdWRpb1VybCBhcmUgcmVxdWlyZWQnKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgdHJhY2sgaW5mbyAoYXZvaWQgam9pbnMgZm9yIHJlc2lsaWVuY2UpXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjaywgZXJyb3I6IHRyYWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgndHJhY2tzJylcbiAgICAgIC5zZWxlY3QoJyonKVxuICAgICAgLmVxKCdpZCcsIHRyYWNrSWQpXG4gICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgIGlmICh0cmFja0Vycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIERCIGVycm9yOicsIHRyYWNrRXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBEYXRhYmFzZSBlcnJvcjogJHt0cmFja0Vycm9yLm1lc3NhZ2V9YCk7XG4gICAgfVxuICAgIGlmICghdHJhY2spIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgVHJhY2sgbm90IGZvdW5kOiAke3RyYWNrSWR9YCk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10gVHJhY2s6IFwiJHt0cmFjay50aXRsZX1cIiwgdXNlcjogJHt0cmFjay51c2VyX2lkfWApO1xuXG4gICAgY29uc3QgVlBTX1VSTCA9IERlbm8uZW52LmdldChcIlZQU19GRk1QRUdfVVJMXCIpIHx8IFwiaHR0cDovLzIxNy4xOTkuMjU0LjE3MDozMDAxXCI7XG4gICAgY29uc3QgRkZNUEVHX0FQSV9VUkwgPSBEZW5vLmVudi5nZXQoXCJGRk1QRUdfQVBJX1VSTFwiKTtcbiAgICBjb25zdCBGRk1QRUdfQVBJX1NFQ1JFVCA9IERlbm8uZW52LmdldChcIkZGTVBFR19BUElfU0VDUkVUXCIpO1xuICAgIGNvbnN0IGZmbXBlZ0hlYWRlcnMgPSBGRk1QRUdfQVBJX1NFQ1JFVCA/IHsgJ3gtYXBpLWtleSc6IEZGTVBFR19BUElfU0VDUkVUIH0gOiB1bmRlZmluZWQ7XG5cbiAgICAvLyBIZWxwZXI6IHVwZGF0ZSBwcm9ncmVzcyBpbiBEQlxuICAgIGxldCBzdGFnZUlkeCA9IDA7XG4gICAgY29uc3QgdXBkYXRlU3RhZ2UgPSBhc3luYyAoc3RhZ2VJZDogc3RyaW5nKSA9PiB7XG4gICAgICBzdGFnZUlkeCsrO1xuICAgICAgY29uc3QgcHJvZ3Jlc3MgPSBNYXRoLnJvdW5kKChzdGFnZUlkeCAvIFBST0NFU1NJTkdfU1RBR0VTLmxlbmd0aCkgKiAxMDApO1xuICAgICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10g4pSA4pSAIFN0YWdlICR7c3RhZ2VJZHh9LyR7UFJPQ0VTU0lOR19TVEFHRVMubGVuZ3RofTogJHtzdGFnZUlkfSAoJHtwcm9ncmVzc30lKWApO1xuXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCd0cmFja3MnKS51cGRhdGUoe1xuICAgICAgICBwcm9jZXNzaW5nX3N0YWdlOiBzdGFnZUlkLFxuICAgICAgICBwcm9jZXNzaW5nX3Byb2dyZXNzOiBwcm9ncmVzcyxcbiAgICAgIH0pLmVxKCdpZCcsIHRyYWNrSWQpO1xuXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdkaXN0cmlidXRpb25fbG9ncycpLmluc2VydCh7XG4gICAgICAgIHRyYWNrX2lkOiB0cmFja0lkLFxuICAgICAgICB1c2VyX2lkOiB0cmFjay51c2VyX2lkLFxuICAgICAgICBhY3Rpb246IGBzdGFnZV8ke3N0YWdlSWR9YCxcbiAgICAgICAgc3RhZ2U6ICdsZXZlbF9wcm8nLFxuICAgICAgICBkZXRhaWxzOiB7IHN0YWdlX25hbWU6IFBST0NFU1NJTkdfU1RBR0VTLmZpbmQocyA9PiBzLmlkID09PSBzdGFnZUlkKT8ubmFtZSB9LFxuICAgICAgfSk7XG4gICAgfTtcblxuICAgIC8vIE1hcmsgYXMgcHJvY2Vzc2luZ1xuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ3RyYWNrcycpLnVwZGF0ZSh7XG4gICAgICBkaXN0cmlidXRpb25fc3RhdHVzOiAncHJvY2Vzc2luZycsXG4gICAgICBwcm9jZXNzaW5nX3N0YXJ0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIHByb2Nlc3NpbmdfcHJvZ3Jlc3M6IDAsXG4gICAgfSkuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLy8gU1RBR0UgMS0yLTM6IEFOQUxZWkUgKHZhbGlkYXRlICsgdXBzY2FsZSArIGxvdWRuZXNzKVxuICAgIC8vIFNpbmdsZSBWUFMgY2FsbCBjb3ZlcnMgYWxsIHRocmVlIHN0YWdlc1xuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBhd2FpdCB1cGRhdGVTdGFnZSgndmFsaWRhdGluZycpO1xuXG4gICAgY29uc3QgcmF3QW5hbHlzaXMgPSBhd2FpdCBjYWxsVnBzKFZQU19VUkwsICcvYW5hbHl6ZScsIHsgYXVkaW9fdXJsOiBtYXN0ZXJBdWRpb1VybCB9LCAzMDAwMCwgZmZtcGVnSGVhZGVycyk7XG5cbiAgICBpZiAoIXJhd0FuYWx5c2lzKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIOKclyBWUFMgYW5hbHlzaXMgdW5hdmFpbGFibGUg4oCUIGFib3J0aW5nJyk7XG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCd0cmFja3MnKS51cGRhdGUoe1xuICAgICAgICBkaXN0cmlidXRpb25fc3RhdHVzOiAncGVuZGluZ19tYXN0ZXInLFxuICAgICAgICBwcm9jZXNzaW5nX3N0YWdlOiBudWxsLFxuICAgICAgICBwcm9jZXNzaW5nX3Byb2dyZXNzOiAwLFxuICAgICAgfSkuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ25vdGlmaWNhdGlvbnMnKS5pbnNlcnQoe1xuICAgICAgICB1c2VyX2lkOiB0cmFjay51c2VyX2lkLFxuICAgICAgICB0eXBlOiAnc3lzdGVtJyxcbiAgICAgICAgdGl0bGU6ICfinYwg0J7RiNC40LHQutCwINCw0L3QsNC70LjQt9CwJyxcbiAgICAgICAgbWVzc2FnZTogYNCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/RgNC+0LDQvdCw0LvQuNC30LjRgNC+0LLQsNGC0Ywg0LzQsNGB0YLQtdGALdGE0LDQudC7INC00LvRjyDRgtGA0LXQutCwIFwiJHt0cmFjay50aXRsZX1cIi4g0J/QvtC/0YDQvtCx0YPQudGC0LUg0L/QvtC30LbQtSDQuNC70Lgg0LfQsNCz0YDRg9C30LjRgtC1INGE0LDQudC7INC/0L7QstGC0L7RgNC90L4uYCxcbiAgICAgICAgdGFyZ2V0X3R5cGU6ICd0cmFjaycsXG4gICAgICAgIHRhcmdldF9pZDogdHJhY2tJZCxcbiAgICAgIH0pO1xuXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ3Zwc191bmF2YWlsYWJsZScsIG1lc3NhZ2U6ICfQodC10YDQstC10YAg0L7QsdGA0LDQsdC+0YLQutC4INCw0YPQtNC40L4g0L3QtdC00L7RgdGC0YPQv9C10L0nIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBhbmFseXNpcyA9IHBhcnNlQW5hbHlzaXMocmF3QW5hbHlzaXMpO1xuICAgIGNvbnNvbGUubG9nKGBbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIOKckyBBbmFseXNpczogZm9ybWF0PSR7YW5hbHlzaXMuZm9ybWF0fSwgJHthbmFseXNpcy5iaXREZXB0aH1iaXQvJHthbmFseXNpcy5zYW1wbGVSYXRlfUh6LCBMVUZTPSR7YW5hbHlzaXMub3JpZ2luYWxMdWZzfSwgcXVhbGl0eT0ke2FuYWx5c2lzLnF1YWxpdHlTY29yZX0vMTBgKTtcblxuICAgIC8vIFNhdmUgYW5hbHlzaXMgdG8gdHJhY2tfaGVhbHRoX3JlcG9ydHNcbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCd0cmFja19oZWFsdGhfcmVwb3J0cycpLnVwc2VydCh7XG4gICAgICB0cmFja19pZDogdHJhY2tJZCxcbiAgICAgIHF1YWxpdHlfc2NvcmU6IGFuYWx5c2lzLnF1YWxpdHlTY29yZSxcbiAgICAgIGx1ZnNfb3JpZ2luYWw6IGFuYWx5c2lzLm9yaWdpbmFsTHVmcyxcbiAgICAgIHBlYWtfZGI6IGFuYWx5c2lzLnBlYWtEYixcbiAgICAgIGR5bmFtaWNfcmFuZ2U6IGFuYWx5c2lzLmR5bmFtaWNSYW5nZSxcbiAgICAgIHNwZWN0cnVtX29rOiAhYW5hbHlzaXMudXBzY2FsZURldGVjdGVkLFxuICAgICAgaGlnaF9mcmVxX2N1dG9mZjogYW5hbHlzaXMuaGlnaEZyZXFDdXRvZmYsXG4gICAgICB1cHNjYWxlX2RldGVjdGVkOiBhbmFseXNpcy51cHNjYWxlRGV0ZWN0ZWQsXG4gICAgICBzYW1wbGVfcmF0ZTogYW5hbHlzaXMuc2FtcGxlUmF0ZSxcbiAgICAgIGJpdF9kZXB0aDogYW5hbHlzaXMuYml0RGVwdGgsXG4gICAgICBjaGFubmVsczogYW5hbHlzaXMuY2hhbm5lbHMsXG4gICAgICBkdXJhdGlvbjogYW5hbHlzaXMuZHVyYXRpb24sXG4gICAgICBmb3JtYXQ6IGFuYWx5c2lzLmZvcm1hdCxcbiAgICAgIG1hc3Rlcl9xdWFsaXR5OiBhbmFseXNpcy5tYXN0ZXJRdWFsaXR5LFxuICAgICAgYW5hbHlzaXNfc3RhdHVzOiAnY29tcGxldGVkJyxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9LCB7IG9uQ29uZmxpY3Q6ICd0cmFja19pZCcgfSk7XG5cbiAgICAvLyBTVEFHRSAyOiBVcHNjYWxlIGRldGVjdGlvblxuICAgIGF3YWl0IHVwZGF0ZVN0YWdlKCd1cHNjYWxlX2RldGVjdGlvbicpO1xuXG4gICAgaWYgKGFuYWx5c2lzLnVwc2NhbGVEZXRlY3RlZCkge1xuICAgICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10g4pyXIFVQU0NBTEUgREVURUNURUQ6IGN1dG9mZj0ke2FuYWx5c2lzLmhpZ2hGcmVxQ3V0b2ZmfUh6ICh0aHJlc2hvbGQgMTYwMDBIeilgKTtcblxuICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgndHJhY2tzJykudXBkYXRlKHtcbiAgICAgICAgZGlzdHJpYnV0aW9uX3N0YXR1czogJ3BlbmRpbmdfbWFzdGVyJyxcbiAgICAgICAgdXBzY2FsZV9kZXRlY3RlZDogdHJ1ZSxcbiAgICAgICAgcHJvY2Vzc2luZ19zdGFnZTogbnVsbCxcbiAgICAgICAgcHJvY2Vzc2luZ19wcm9ncmVzczogMCxcbiAgICAgIH0pLmVxKCdpZCcsIHRyYWNrSWQpO1xuXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdub3RpZmljYXRpb25zJykuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogdHJhY2sudXNlcl9pZCxcbiAgICAgICAgdHlwZTogJ3N5c3RlbScsXG4gICAgICAgIHRpdGxlOiAn4pqg77iPINCe0LHQvdCw0YDRg9C20LXQvSDQsNC/0YHQutC10LnQuycsXG4gICAgICAgIG1lc3NhZ2U6IGDQotGA0LXQuiBcIiR7dHJhY2sudGl0bGV9XCIg0YHQvtC00LXRgNC20LjRgiDQsNC/0YHQutC10LnQu9C10L3QvdGL0Lkg0LDRg9C00LjQvtGE0LDQudC7ICjRgdGA0LXQtyDRh9Cw0YHRgtC+0YIg0L3QsCAke2FuYWx5c2lzLmhpZ2hGcmVxQ3V0b2ZmfdCT0YYsINC/0L7RgNC+0LMgMTYwMDDQk9GGKS4g0J/QvtC20LDQu9GD0LnRgdGC0LAsINC30LDQs9GA0YPQt9C40YLQtSDQvtGA0LjQs9C40L3QsNC70YzQvdGL0LkgV0FWLdGE0LDQudC7LmAsXG4gICAgICAgIHRhcmdldF90eXBlOiAndHJhY2snLFxuICAgICAgICB0YXJnZXRfaWQ6IHRyYWNrSWQsXG4gICAgICB9KTtcblxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgIGVycm9yOiAndXBzY2FsZV9kZXRlY3RlZCcsXG4gICAgICAgICAgbWVzc2FnZTogYNCe0LHQvdCw0YDRg9C20LXQvSDQsNC/0YHQutC10LnQuyAo0YHRgNC10Lcg0L3QsCAke2FuYWx5c2lzLmhpZ2hGcmVxQ3V0b2ZmfdCT0YYpLiDQl9Cw0LPRgNGD0LfQuNGC0LUg0L7RgNC40LPQuNC90LDQuyBXQVYgMjQtYml0YCxcbiAgICAgICAgICBoaWdoX2ZyZXFfY3V0b2ZmOiBhbmFseXNpcy5oaWdoRnJlcUN1dG9mZixcbiAgICAgICAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gU1RBR0UgMzogTG91ZG5lc3MgYW5hbHlzaXNcbiAgICBhd2FpdCB1cGRhdGVTdGFnZSgnbG91ZG5lc3NfYW5hbHlzaXMnKTtcblxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ3RyYWNrcycpLnVwZGF0ZSh7XG4gICAgICBhdWRpb19xdWFsaXR5X3Njb3JlOiBhbmFseXNpcy5xdWFsaXR5U2NvcmUsXG4gICAgICBhdWRpb19zYW1wbGVfcmF0ZTogYW5hbHlzaXMuc2FtcGxlUmF0ZSxcbiAgICAgIGF1ZGlvX2JpdF9kZXB0aDogYW5hbHlzaXMuYml0RGVwdGgsXG4gICAgICBhdWRpb19sdWZzOiBhbmFseXNpcy5vcmlnaW5hbEx1ZnMsXG4gICAgICBhdWRpb19wZWFrX2RiOiBhbmFseXNpcy5wZWFrRGIsXG4gICAgICB1cHNjYWxlX2RldGVjdGVkOiBmYWxzZSxcbiAgICB9KS5lcSgnaWQnLCB0cmFja0lkKTtcblxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAvLyBTVEFHRSA0OiBOT1JNQUxJWkFUSU9OICgtMTQgTFVGUylcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgYXdhaXQgdXBkYXRlU3RhZ2UoJ25vcm1hbGl6YXRpb24nKTtcblxuICAgIGxldCBwcm9jZXNzZWRVcmwgPSBtYXN0ZXJBdWRpb1VybDtcbiAgICBsZXQgbm9ybWFsaXplZEx1ZnMgPSBhbmFseXNpcy5vcmlnaW5hbEx1ZnM7XG4gICAgY29uc3QgbmVlZHNOb3JtID0gTWF0aC5hYnMoYW5hbHlzaXMub3JpZ2luYWxMdWZzIC0gKC0xNCkpID4gMTtcblxuICAgIGlmIChuZWVkc05vcm0pIHtcbiAgICAgIGNvbnNvbGUubG9nKGBbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIE5vcm1hbGl6aW5nOiAke2FuYWx5c2lzLm9yaWdpbmFsTHVmc30g4oaSIC0xNCBMVUZTYCk7XG5cbiAgICAgIGNvbnN0IG5vcm1SZXN1bHQgPSBhd2FpdCBjYWxsVnBzKFZQU19VUkwsICcvbm9ybWFsaXplJywge1xuICAgICAgICBhdWRpb191cmw6IG1hc3RlckF1ZGlvVXJsLFxuICAgICAgICB0YXJnZXRfbHVmczogLTE0LFxuICAgICAgICBzdHJpcF9tZXRhZGF0YTogZmFsc2UsXG4gICAgICAgIGJyYW5kX21ldGFkYXRhOiBmYWxzZSxcbiAgICAgIH0sIDkwMDAwLCBmZm1wZWdIZWFkZXJzKTsgLy8gOTBzIGZvciBsYXJnZSBmaWxlc1xuXG4gICAgICBpZiAobm9ybVJlc3VsdD8ubm9ybWFsaXplZF91cmwpIHtcbiAgICAgICAgcHJvY2Vzc2VkVXJsID0gbm9ybVJlc3VsdC5ub3JtYWxpemVkX3VybDtcbiAgICAgICAgbm9ybWFsaXplZEx1ZnMgPSBub3JtUmVzdWx0Lm5vcm1hbGl6ZWRfbHVmcyA/PyAtMTQ7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIOKckyBOb3JtYWxpemVkOiAke2FuYWx5c2lzLm9yaWdpbmFsTHVmc30g4oaSICR7bm9ybWFsaXplZEx1ZnN9IExVRlNgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIOKaoCBOb3JtYWxpemF0aW9uIGZhaWxlZCwga2VlcGluZyBvcmlnaW5hbGApO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDinJMgTFVGUyB3aXRoaW4gdG9sZXJhbmNlICgke2FuYWx5c2lzLm9yaWdpbmFsTHVmc30pLCBubyBub3JtYWxpemF0aW9uIG5lZWRlZGApO1xuICAgIH1cblxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ3RyYWNrcycpLnVwZGF0ZSh7XG4gICAgICBsdWZzX25vcm1hbGl6ZWQ6IHRydWUsXG4gICAgICBhdWRpb19sdWZzOiBub3JtYWxpemVkTHVmcyxcbiAgICAgIG5vcm1hbGl6ZWRfYXVkaW9fdXJsOiBwcm9jZXNzZWRVcmwsXG4gICAgfSkuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCd0cmFja19oZWFsdGhfcmVwb3J0cycpLnVwZGF0ZSh7XG4gICAgICBsdWZzX25vcm1hbGl6ZWQ6IG5vcm1hbGl6ZWRMdWZzLFxuICAgICAgbm9ybWFsaXplZF9hdWRpb191cmw6IHByb2Nlc3NlZFVybCxcbiAgICAgIG5vcm1hbGl6YXRpb25fc3RhdHVzOiAnY29tcGxldGVkJyxcbiAgICB9KS5lcSgndHJhY2tfaWQnLCB0cmFja0lkKTtcblxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAvLyBTVEFHRSA1OiBNRVRBREFUQSBDTEVBTklORyAmIEJSQU5ESU5HXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGF3YWl0IHVwZGF0ZVN0YWdlKCdtZXRhZGF0YV9jbGVhbmluZycpO1xuXG4gICAgY29uc3QgeyBkYXRhOiBwcm9maWxlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oJ3Byb2ZpbGVzJylcbiAgICAgIC5zZWxlY3QoJ3VzZXJuYW1lJylcbiAgICAgIC5lcSgndXNlcl9pZCcsIHRyYWNrLnVzZXJfaWQpXG4gICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgIGNvbnN0IHVzZXJuYW1lID0gcHJvZmlsZT8udXNlcm5hbWUgfHwgJ1Vua25vd24nO1xuXG4gICAgLy8gVXNlIEZGTVBFR19BUElfVVJMICh3aXRoIGF1dGgpIGlmIGF2YWlsYWJsZSwgZWxzZSBWUFNfVVJMXG4gICAgaWYgKEZGTVBFR19BUElfVVJMICYmIEZGTVBFR19BUElfU0VDUkVUKSB7XG4gICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSBNZXRhZGF0YSBjbGVhbmluZyB2aWEgRkZNUEVHX0FQSV9VUkxgKTtcblxuICAgICAgY29uc3QgbWV0YVJlc3VsdCA9IGF3YWl0IGNhbGxWcHMoRkZNUEVHX0FQSV9VUkwsICcvY2xlYW4tbWV0YWRhdGEnLCB7XG4gICAgICAgIGF1ZGlvX3VybDogcHJvY2Vzc2VkVXJsLFxuICAgICAgICBtZXRhZGF0YToge1xuICAgICAgICAgIHRpdGxlOiB0cmFjay50aXRsZSxcbiAgICAgICAgICBhcnRpc3Q6IHVzZXJuYW1lLFxuICAgICAgICAgIGFsYnVtOiAnQUltdXphJyxcbiAgICAgICAgICBwdWJsaXNoZXI6ICdBSW11emEnLFxuICAgICAgICAgIGNvbW1lbnQ6IGBHZW5lcmF0ZWQgb24gYWltdXphLnJ1IHwgVXNlcjogJHt1c2VybmFtZX1gLFxuICAgICAgICAgIGNvcHlyaWdodDogYMKpICR7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfSAke3VzZXJuYW1lfSB2aWEgQUltdXphYCxcbiAgICAgICAgICBjdXN0b206IHtcbiAgICAgICAgICAgIFRYWFhfVVNFUl9JRDogdHJhY2sudXNlcl9pZCxcbiAgICAgICAgICAgIFRYWFhfVVNFUk5BTUU6IHVzZXJuYW1lLFxuICAgICAgICAgICAgVFhYWF9XRUJTSVRFOiAnYWltdXphLnJ1JyxcbiAgICAgICAgICAgIFRYWFhfREFURTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gICAgICAgICAgICBUWFhYX1RSQUNLX0lEOiB0cmFja0lkLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9LCA2MDAwMCwgeyAneC1hcGkta2V5JzogRkZNUEVHX0FQSV9TRUNSRVQgfSk7XG5cbiAgICAgIGlmIChtZXRhUmVzdWx0Py5jbGVhbmVkX3VybCkge1xuICAgICAgICBwcm9jZXNzZWRVcmwgPSBtZXRhUmVzdWx0LmNsZWFuZWRfdXJsO1xuICAgICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDinJMgTWV0YWRhdGEgY2xlYW5lZCB2aWEgRkZNUEVHIEFQSWApO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSBNZXRhZGF0YSBjbGVhbmluZyB2aWEgVlBTIC9ub3JtYWxpemVgKTtcblxuICAgICAgY29uc3QgbWV0YVJlc3VsdCA9IGF3YWl0IGNhbGxWcHMoVlBTX1VSTCwgJy9ub3JtYWxpemUnLCB7XG4gICAgICAgIGF1ZGlvX3VybDogcHJvY2Vzc2VkVXJsLFxuICAgICAgICB0YXJnZXRfbHVmczogLTE0LFxuICAgICAgICBzdHJpcF9tZXRhZGF0YTogdHJ1ZSxcbiAgICAgICAgYnJhbmRfbWV0YWRhdGE6IHRydWUsXG4gICAgICAgIG1ldGFkYXRhOiB7XG4gICAgICAgICAgYXJ0aXN0OiB1c2VybmFtZSxcbiAgICAgICAgICB0aXRsZTogdHJhY2sudGl0bGUsXG4gICAgICAgICAgYWxidW06ICdBSW11emEnLFxuICAgICAgICAgIGNvbW1lbnQ6IGBHZW5lcmF0ZWQgb24gYWltdXphLnJ1IHwgVXNlcjogJHt1c2VybmFtZX1gLFxuICAgICAgICAgIGRhdGU6IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKS50b1N0cmluZygpLFxuICAgICAgICAgIGVuY29kZXI6ICdBSW11emEgTXVzaWMgVGVybWluYWwnLFxuICAgICAgICAgIGNvcHlyaWdodDogYMKpICR7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfSAke3VzZXJuYW1lfSB2aWEgQUltdXphYCxcbiAgICAgICAgICB1c2VyX2lkOiB0cmFjay51c2VyX2lkLFxuICAgICAgICAgIHdlYnNpdGU6ICdodHRwczovL2FpbXV6YS5ydScsXG4gICAgICAgIH0sXG4gICAgICB9LCA2MDAwMCwgZmZtcGVnSGVhZGVycyk7XG5cbiAgICAgIGlmIChtZXRhUmVzdWx0Py5ub3JtYWxpemVkX3VybCkge1xuICAgICAgICBwcm9jZXNzZWRVcmwgPSBtZXRhUmVzdWx0Lm5vcm1hbGl6ZWRfdXJsO1xuICAgICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDinJMgTWV0YWRhdGEgY2xlYW5lZCB2aWEgVlBTIG5vcm1hbGl6ZWApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ3RyYWNrcycpLnVwZGF0ZSh7XG4gICAgICBtZXRhZGF0YV9jbGVhbmVkOiB0cnVlLFxuICAgICAgbWV0YWRhdGFfYnJhbmRlZDogdHJ1ZSxcbiAgICB9KS5lcSgnaWQnLCB0cmFja0lkKTtcblxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAvLyBTVEFHRSA2OiBCTE9DS0NIQUlOIEhBU0ggKFNIQS0yNTYgKyBPcGVuVGltZXN0YW1wcylcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgYXdhaXQgdXBkYXRlU3RhZ2UoJ2Jsb2NrY2hhaW5faGFzaCcpO1xuXG4gICAgLy8gU3RlcCAxOiBDb21wdXRlIHJlYWwgU0hBLTI1NiBvZiB0aGUgZmluYWwgcHJvY2Vzc2VkIGZpbGVcbiAgICBjb25zdCBmaWxlSGFzaCA9IGF3YWl0IGNvbXB1dGVGaWxlSGFzaChwcm9jZXNzZWRVcmwpO1xuXG4gICAgbGV0IGJsb2NrY2hhaW5IYXNoOiBzdHJpbmc7XG4gICAgbGV0IG90c1Byb29mVXBsb2FkZWQgPSBmYWxzZTtcblxuICAgIGlmIChmaWxlSGFzaCkge1xuICAgICAgYmxvY2tjaGFpbkhhc2ggPSBgMHgke2ZpbGVIYXNofWA7XG4gICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDinJMgUmVhbCBTSEEtMjU2OiAke2Jsb2NrY2hhaW5IYXNofWApO1xuXG4gICAgICAvLyBTdGVwIDI6IFN1Ym1pdCB0byBPcGVuVGltZXN0YW1wcyAoYXN5bmMgLSBkb24ndCBibG9jaylcbiAgICAgIGNvbnN0IG90c1Byb29mID0gYXdhaXQgc3VibWl0VG9PcGVuVGltZXN0YW1wcyhmaWxlSGFzaCk7XG5cbiAgICAgIGlmIChvdHNQcm9vZikge1xuICAgICAgICAvLyBVcGxvYWQgT1RTIHByb29mIHRvIHN0b3JhZ2VcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBwcm9vZkZpbGVOYW1lID0gYGdvbGQtcGFja3MvJHt0cmFja0lkfS9wcm9vZi5vdHNgO1xuICAgICAgICAgIGF3YWl0IHN1cGFiYXNlLnN0b3JhZ2UuZnJvbSgndHJhY2tzJykudXBsb2FkKFxuICAgICAgICAgICAgcHJvb2ZGaWxlTmFtZSxcbiAgICAgICAgICAgIG90c1Byb29mLFxuICAgICAgICAgICAgeyB1cHNlcnQ6IHRydWUsIGNvbnRlbnRUeXBlOiAnYXBwbGljYXRpb24vdm5kLm9wZW50aW1lc3RhbXBzLnYxJyB9XG4gICAgICAgICAgKTtcbiAgICAgICAgICBvdHNQcm9vZlVwbG9hZGVkID0gdHJ1ZTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDinJMgT1RTIHByb29mIHVwbG9hZGVkIHRvIHN0b3JhZ2VgKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10gT1RTIHByb29mIHVwbG9hZCBmYWlsZWQ6YCwgZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgLy8gRmFsbGJhY2s6IHN0aWxsIGdlbmVyYXRlIGEgaGFzaCBidXQgbWFyayBpdCBhcyBsb2NhbC1vbmx5XG4gICAgICBjb25zdCBmYWxsYmFja0J5dGVzID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHByb2Nlc3NlZFVybCArIERhdGUubm93KCkudG9TdHJpbmcoKSk7XG4gICAgICBjb25zdCBmYWxsYmFja0J1ZmZlciA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgZmFsbGJhY2tCeXRlcyk7XG4gICAgICBjb25zdCBmYWxsYmFja0hleCA9IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoZmFsbGJhY2tCdWZmZXIpKVxuICAgICAgICAubWFwKGIgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcbiAgICAgICAgLmpvaW4oJycpO1xuICAgICAgYmxvY2tjaGFpbkhhc2ggPSBgMHhMT0NBTF8ke2ZhbGxiYWNrSGV4fWA7XG4gICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDimqAgVXNpbmcgZmFsbGJhY2sgaGFzaCAoZmlsZSBkb3dubG9hZCBmYWlsZWQpYCk7XG4gICAgfVxuXG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgndHJhY2tzJykudXBkYXRlKHtcbiAgICAgIGJsb2NrY2hhaW5faGFzaDogYmxvY2tjaGFpbkhhc2gsXG4gICAgfSkuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLy8gU1RBR0UgNzogQ0VSVElGSUNBVEUgR0VORVJBVElPTlxuICAgIC8vIChkZWxlZ2F0ZWQgdG8gZ2VuZXJhdGUtZ29sZC1wYWNrIGZ1bmN0aW9uKVxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBhd2FpdCB1cGRhdGVTdGFnZSgnY2VydGlmaWNhdGVfZ2VuZXJhdGlvbicpO1xuXG4gICAgY29uc3QgY2VydGlmaWNhdGVVcmwgPSBgJHtEZW5vLmVudi5nZXQoJ1NVUEFCQVNFX1VSTCcpfS9zdG9yYWdlL3YxL29iamVjdC9wdWJsaWMvdHJhY2tzL2dvbGQtcGFja3MvJHt0cmFja0lkfS9jZXJ0aWZpY2F0ZS5odG1sYDtcbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCd0cmFja3MnKS51cGRhdGUoe1xuICAgICAgY2VydGlmaWNhdGVfdXJsOiBjZXJ0aWZpY2F0ZVVybCxcbiAgICB9KS5lcSgnaWQnLCB0cmFja0lkKTtcblxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAvLyBTVEFHRSA4OiBHT0xEIFBBQ0sgQVNTRU1CTFlcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgYXdhaXQgdXBkYXRlU3RhZ2UoJ2dvbGRfcGFja19hc3NlbWJseScpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9VUkwnKSE7XG4gICAgICBjb25zdCBzZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZJykhO1xuXG4gICAgICBjb25zdCBnb2xkUGFja1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2goXG4gICAgICAgIGAke3N1cGFiYXNlVXJsfS9mdW5jdGlvbnMvdjEvZ2VuZXJhdGUtZ29sZC1wYWNrYCxcbiAgICAgICAge1xuICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6IGBCZWFyZXIgJHtzZXJ2aWNlS2V5fWAsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHRyYWNrSWQgfSksXG4gICAgICAgIH1cbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IGdvbGRQYWNrUmVzdWx0ID0gYXdhaXQgZ29sZFBhY2tSZXNwb25zZS5qc29uKCk7XG4gICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDinJMgR29sZCBwYWNrOmAsIGdvbGRQYWNrUmVzdWx0KTtcbiAgICB9IGNhdGNoIChncEVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIEdvbGQgcGFjayBlcnJvcjonLCBncEVycm9yKTtcbiAgICB9XG5cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLy8gRklOQUwgVVBEQVRFXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ3RyYWNrcycpLnVwZGF0ZSh7XG4gICAgICBkaXN0cmlidXRpb25fc3RhdHVzOiAnY29tcGxldGVkJyxcbiAgICAgIHByb2Nlc3Npbmdfc3RhZ2U6ICdjb21wbGV0ZWQnLFxuICAgICAgcHJvY2Vzc2luZ19wcm9ncmVzczogMTAwLFxuICAgICAgcHJvY2Vzc2luZ19jb21wbGV0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIG1hc3Rlcl9hdWRpb191cmw6IHByb2Nlc3NlZFVybCxcbiAgICB9KS5lcSgnaWQnLCB0cmFja0lkKTtcblxuICAgIGNvbnN0IGNvbXBsZXRpb25EZXRhaWxzID0ge1xuICAgICAgcmVhbF9wcm9jZXNzaW5nOiB0cnVlLFxuICAgICAgdnBzX3VybDogVlBTX1VSTCxcbiAgICAgIGFuYWx5c2lzOiB7XG4gICAgICAgIHF1YWxpdHlfc2NvcmU6IGFuYWx5c2lzLnF1YWxpdHlTY29yZSxcbiAgICAgICAgbHVmc19vcmlnaW5hbDogYW5hbHlzaXMub3JpZ2luYWxMdWZzLFxuICAgICAgICBsdWZzX25vcm1hbGl6ZWQ6IG5vcm1hbGl6ZWRMdWZzLFxuICAgICAgICBub3JtYWxpemF0aW9uX2FwcGxpZWQ6IG5lZWRzTm9ybSxcbiAgICAgICAgdXBzY2FsZV9kZXRlY3RlZDogZmFsc2UsXG4gICAgICAgIGhpZ2hfZnJlcV9jdXRvZmY6IGFuYWx5c2lzLmhpZ2hGcmVxQ3V0b2ZmLFxuICAgICAgICBmb3JtYXQ6IGFuYWx5c2lzLmZvcm1hdCxcbiAgICAgICAgYml0X2RlcHRoOiBhbmFseXNpcy5iaXREZXB0aCxcbiAgICAgICAgc2FtcGxlX3JhdGU6IGFuYWx5c2lzLnNhbXBsZVJhdGUsXG4gICAgICAgIGR1cmF0aW9uOiBhbmFseXNpcy5kdXJhdGlvbixcbiAgICAgIH0sXG4gICAgICBibG9ja2NoYWluOiB7XG4gICAgICAgIGhhc2g6IGJsb2NrY2hhaW5IYXNoLFxuICAgICAgICByZWFsX3NoYTI1NjogISFmaWxlSGFzaCxcbiAgICAgICAgb3RzX3Byb29mX3VwbG9hZGVkOiBvdHNQcm9vZlVwbG9hZGVkLFxuICAgICAgfSxcbiAgICAgIG1ldGFkYXRhOiB7XG4gICAgICAgIGNsZWFuZWQ6IHRydWUsXG4gICAgICAgIGJyYW5kZWQ6IHRydWUsXG4gICAgICAgIGFydGlzdDogdXNlcm5hbWUsXG4gICAgICB9LFxuICAgICAgZ29sZF9wYWNrX3JlYWR5OiB0cnVlLFxuICAgIH07XG5cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdkaXN0cmlidXRpb25fbG9ncycpLmluc2VydCh7XG4gICAgICB0cmFja19pZDogdHJhY2tJZCxcbiAgICAgIHVzZXJfaWQ6IHRyYWNrLnVzZXJfaWQsXG4gICAgICBhY3Rpb246ICdwcm9jZXNzaW5nX2NvbXBsZXRlZCcsXG4gICAgICBzdGFnZTogJ2xldmVsX3BybycsXG4gICAgICBkZXRhaWxzOiBjb21wbGV0aW9uRGV0YWlscyxcbiAgICB9KTtcblxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ25vdGlmaWNhdGlvbnMnKS5pbnNlcnQoe1xuICAgICAgdXNlcl9pZDogdHJhY2sudXNlcl9pZCxcbiAgICAgIHR5cGU6ICdzeXN0ZW0nLFxuICAgICAgdGl0bGU6ICfwn46JINCX0L7Qu9C+0YLQvtC5INC/0LDQutC10YIg0LPQvtGC0L7QsiEnLFxuICAgICAgbWVzc2FnZTogYNCi0YDQtdC6IFwiJHt0cmFjay50aXRsZX1cIiDQv9C+0LvQvdC+0YHRgtGM0Y4g0L7QsdGA0LDQsdC+0YLQsNC9LiBXQVYgKC0xNCBMVUZTKSwgWE1MLdC80LXRgtCw0LTQsNC90L3Ri9C1LCDRgdC10YDRgtC40YTQuNC60LDRgiDQuCBPVFMt0LTQvtC60LDQt9Cw0YLQtdC70YzRgdGC0LLQviDQtNC+0YHRgtGD0L/QvdGLINC00LvRjyDRgdC60LDRh9C40LLQsNC90LjRjy5gLFxuICAgICAgdGFyZ2V0X3R5cGU6ICd0cmFjaycsXG4gICAgICB0YXJnZXRfaWQ6IHRyYWNrSWQsXG4gICAgfSk7XG5cbiAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDinIUgQ09NUExFVEVELiBBbGwgc3RhZ2VzIHBhc3NlZCB3aXRoIHJlYWwgcHJvY2Vzc2luZy5gKTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgIG1lc3NhZ2U6ICdHb2xkIHBhY2sgYXNzZW1ibGVkIHdpdGggcmVhbCBhdWRpbyBwcm9jZXNzaW5nJyxcbiAgICAgICAgc3RhZ2VzX2NvbXBsZXRlZDogUFJPQ0VTU0lOR19TVEFHRVMubGVuZ3RoLFxuICAgICAgICByZWFsX3Byb2Nlc3Npbmc6IHRydWUsXG4gICAgICAgIGRldGFpbHM6IGNvbXBsZXRpb25EZXRhaWxzLFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1twcm9jZXNzLW1hc3Rlci1hdWRpb10gRkFUQUw6JywgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJztcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IG1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBT0EsTUFBTSxvQkFBb0I7RUFDeEI7SUFBRSxJQUFJO0lBQWMsTUFBTTtFQUE4QjtFQUN4RDtJQUFFLElBQUk7SUFBcUIsTUFBTTtFQUEwQztFQUMzRTtJQUFFLElBQUk7SUFBcUIsTUFBTTtFQUEwQjtFQUMzRDtJQUFFLElBQUk7SUFBaUIsTUFBTTtFQUEyQjtFQUN4RDtJQUFFLElBQUk7SUFBcUIsTUFBTTtFQUE4QjtFQUMvRDtJQUFFLElBQUk7SUFBbUIsTUFBTTtFQUE0QztFQUMzRTtJQUFFLElBQUk7SUFBMEIsTUFBTTtFQUF3QjtFQUM5RDtJQUFFLElBQUk7SUFBc0IsTUFBTTtFQUF5QjtDQUM1RDtBQUVELGdEQUFnRDtBQUNoRCw0QkFBNEI7QUFDNUIsZ0RBQWdEO0FBRWhELGVBQWUsUUFDYixHQUFXLEVBQ1gsUUFBZ0IsRUFDaEIsT0FBZ0MsRUFDaEMsWUFBWSxLQUFLLEVBQ2pCLE9BQWdDO0VBRWhDLElBQUk7SUFDRixNQUFNLGFBQWEsSUFBSTtJQUN2QixNQUFNLFlBQVksV0FBVyxJQUFNLFdBQVcsS0FBSyxJQUFJO0lBQ3ZELE1BQU0sYUFBcUM7TUFBRSxnQkFBZ0I7TUFBb0IsR0FBRyxPQUFPO0lBQUM7SUFFNUYsTUFBTSxPQUFPLE1BQU0sTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBQyxFQUFFO01BQzVDLFFBQVE7TUFDUixTQUFTO01BQ1QsTUFBTSxLQUFLLFNBQVMsQ0FBQztNQUNyQixRQUFRLFdBQVcsTUFBTTtJQUMzQjtJQUNBLGFBQWE7SUFFYixJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUU7TUFDWixNQUFNLFVBQVUsTUFBTSxLQUFLLElBQUk7TUFDL0IsUUFBUSxLQUFLLENBQUMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxPQUFPLEVBQUUsS0FBSyxNQUFNLENBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQztNQUNsRSxPQUFPO0lBQ1Q7SUFDQSxPQUFPLE1BQU0sS0FBSyxJQUFJO0VBQ3hCLEVBQUUsT0FBTyxHQUFHO0lBQ1YsUUFBUSxLQUFLLENBQUMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxRQUFRLENBQUMsRUFBRTtJQUMzQyxPQUFPO0VBQ1Q7QUFDRjtBQUVBLG1EQUFtRDtBQUNuRCxTQUFTLGNBQWMsR0FBUTtFQUM3QixNQUFNLGNBQWMsSUFBSSxPQUFPLEVBQUUsS0FBSyxDQUFDLElBQVcsRUFBRSxVQUFVLEtBQUssWUFBWSxDQUFDO0VBQ2hGLE1BQU0saUJBQWlCLElBQUksUUFBUSxFQUFFLG9CQUFvQjtFQUN6RCxNQUFNLGtCQUFrQixpQkFBaUI7RUFDekMsTUFBTSxlQUFlLElBQUksSUFBSSxFQUFFLGNBQWMsQ0FBQztFQUM5QyxNQUFNLFNBQVMsSUFBSSxJQUFJLEVBQUUsYUFBYSxDQUFDO0VBQ3ZDLE1BQU0sZUFBZSxJQUFJLElBQUksRUFBRSxTQUFTO0VBQ3hDLE1BQU0sYUFBYSxTQUFTLFlBQVksV0FBVyxLQUFLO0VBQ3hELE1BQU0sV0FBVyxZQUFZLGVBQWUsSUFBSTtFQUNoRCxNQUFNLFdBQVcsWUFBWSxRQUFRLElBQUk7RUFDekMsTUFBTSxXQUFXLFdBQVcsSUFBSSxNQUFNLEVBQUUsYUFBYTtFQUNyRCxNQUFNLFNBQVMsSUFBSSxNQUFNLEVBQUUsZUFBZTtFQUUxQyxJQUFJLGVBQWU7RUFDbkIsSUFBSSxpQkFBaUIsZ0JBQWdCO0VBQ3JDLElBQUksYUFBYSxPQUFPLGdCQUFnQjtFQUN4QyxJQUFJLFdBQVcsSUFBSSxnQkFBZ0I7RUFDbkMsSUFBSSxlQUFlLENBQUMsR0FBRyxnQkFBZ0I7RUFDdkMsZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLElBQUk7RUFFeEMsT0FBTztJQUNMO0lBQWdCO0lBQWlCO0lBQWM7SUFBUTtJQUN2RDtJQUFZO0lBQVU7SUFBVTtJQUFVO0lBQVE7SUFDbEQsZUFBZSxZQUFZLE1BQU07TUFBQztNQUFPO01BQVE7S0FBTyxDQUFDLFFBQVEsQ0FBQztFQUNwRTtBQUNGO0FBRUEseURBQXlEO0FBQ3pELGVBQWUsZ0JBQWdCLE9BQWU7RUFDNUMsSUFBSTtJQUNGLE1BQU0sYUFBYSxJQUFJO0lBQ3ZCLE1BQU0sWUFBWSxXQUFXLElBQU0sV0FBVyxLQUFLLElBQUksU0FBUyx3QkFBd0I7SUFDeEYsTUFBTSxPQUFPLE1BQU0sTUFBTSxTQUFTO01BQUUsUUFBUSxXQUFXLE1BQU07SUFBQztJQUM5RCxhQUFhO0lBRWIsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFO01BQ1osUUFBUSxLQUFLLENBQUMsQ0FBQywyQkFBMkIsRUFBRSxLQUFLLE1BQU0sQ0FBQyxDQUFDO01BQ3pELE9BQU87SUFDVDtJQUVBLE1BQU0sU0FBUyxNQUFNLEtBQUssV0FBVztJQUNyQyxNQUFNLGFBQWEsTUFBTSxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVztJQUN6RCxNQUFNLFVBQVUsTUFBTSxJQUFJLENBQUMsSUFBSSxXQUFXLGFBQ3ZDLEdBQUcsQ0FBQyxDQUFBLElBQUssRUFBRSxRQUFRLENBQUMsSUFBSSxRQUFRLENBQUMsR0FBRyxNQUNwQyxJQUFJLENBQUM7SUFFUixRQUFRLEdBQUcsQ0FBQyxDQUFDLG9CQUFvQixFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsT0FBTyxVQUFVLEdBQUcsT0FBTyxJQUFJLEVBQUUsT0FBTyxDQUFDLEdBQUcsR0FBRyxDQUFDO0lBQ2hHLE9BQU87RUFDVCxFQUFFLE9BQU8sR0FBRztJQUNWLFFBQVEsS0FBSyxDQUFDLENBQUMsaUJBQWlCLENBQUMsRUFBRTtJQUNuQyxPQUFPO0VBQ1Q7QUFDRjtBQUVBLGlEQUFpRDtBQUNqRCxlQUFlLHVCQUF1QixPQUFlO0VBQ25ELE1BQU0sWUFBWSxJQUFJLFdBQ3BCLFFBQVEsS0FBSyxDQUFDLFNBQVUsR0FBRyxDQUFDLENBQUEsT0FBUSxTQUFTLE1BQU07RUFHckQsTUFBTSxZQUFZO0lBQ2hCO0lBQ0E7SUFDQTtHQUNEO0VBRUQsS0FBSyxNQUFNLFlBQVksVUFBVztJQUNoQyxJQUFJO01BQ0YsTUFBTSxhQUFhLElBQUk7TUFDdkIsTUFBTSxZQUFZLFdBQVcsSUFBTSxXQUFXLEtBQUssSUFBSTtNQUV2RCxNQUFNLE9BQU8sTUFBTSxNQUFNLFVBQVU7UUFDakMsUUFBUTtRQUNSLFNBQVM7VUFDUCxnQkFBZ0I7VUFDaEIsVUFBVTtRQUNaO1FBQ0EsTUFBTTtRQUNOLFFBQVEsV0FBVyxNQUFNO01BQzNCO01BQ0EsYUFBYTtNQUViLElBQUksS0FBSyxFQUFFLEVBQUU7UUFDWCxNQUFNLGFBQWEsSUFBSSxXQUFXLE1BQU0sS0FBSyxXQUFXO1FBQ3hELFFBQVEsR0FBRyxDQUFDLENBQUMsMEJBQTBCLEVBQUUsU0FBUyxFQUFFLEVBQUUsV0FBVyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQ2hGLE9BQU87TUFDVCxPQUFPO1FBQ0wsTUFBTSxVQUFVLE1BQU0sS0FBSyxJQUFJO1FBQy9CLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLFNBQVMsVUFBVSxFQUFFLEtBQUssTUFBTSxDQUFDLEVBQUUsRUFBRSxRQUFRLENBQUM7TUFDckU7SUFDRixFQUFFLE9BQU8sR0FBRztNQUNWLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLFNBQVMsUUFBUSxDQUFDLEVBQUU7SUFDM0M7RUFDRjtFQUVBLFFBQVEsS0FBSyxDQUFDO0VBQ2QsT0FBTztBQUNUO0FBRUEsZ0RBQWdEO0FBQ2hELGVBQWU7QUFDZixnREFBZ0Q7QUFFaEQsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxXQUFXLGFBQ2YsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0lBRy9DLE1BQU0sRUFBRSxPQUFPLEVBQUUsY0FBYyxFQUFFLEdBQXlCLE1BQU0sSUFBSSxJQUFJO0lBQ3hFLFFBQVEsR0FBRyxDQUFDLENBQUMsNkRBQTZELEVBQUUsUUFBUSxDQUFDO0lBRXJGLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCO01BQy9CLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsOENBQThDO0lBQzlDLE1BQU0sRUFBRSxNQUFNLEtBQUssRUFBRSxPQUFPLFVBQVUsRUFBRSxHQUFHLE1BQU0sU0FDOUMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLEtBQ1AsRUFBRSxDQUFDLE1BQU0sU0FDVCxXQUFXO0lBRWQsSUFBSSxZQUFZO01BQ2QsUUFBUSxLQUFLLENBQUMsb0NBQW9DO01BQ2xELE1BQU0sSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsV0FBVyxPQUFPLENBQUMsQ0FBQztJQUN6RDtJQUNBLElBQUksQ0FBQyxPQUFPO01BQ1YsTUFBTSxJQUFJLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxRQUFRLENBQUM7SUFDL0M7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLCtCQUErQixFQUFFLE1BQU0sS0FBSyxDQUFDLFNBQVMsRUFBRSxNQUFNLE9BQU8sQ0FBQyxDQUFDO0lBRXBGLE1BQU0sVUFBVSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMscUJBQXFCO0lBQ2xELE1BQU0saUJBQWlCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNwQyxNQUFNLG9CQUFvQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDdkMsTUFBTSxnQkFBZ0Isb0JBQW9CO01BQUUsYUFBYTtJQUFrQixJQUFJO0lBRS9FLGdDQUFnQztJQUNoQyxJQUFJLFdBQVc7SUFDZixNQUFNLGNBQWMsT0FBTztNQUN6QjtNQUNBLE1BQU0sV0FBVyxLQUFLLEtBQUssQ0FBQyxBQUFDLFdBQVcsa0JBQWtCLE1BQU0sR0FBSTtNQUNwRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGdDQUFnQyxFQUFFLFNBQVMsQ0FBQyxFQUFFLGtCQUFrQixNQUFNLENBQUMsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLFNBQVMsRUFBRSxDQUFDO01BRWhILE1BQU0sU0FBUyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQUM7UUFDbkMsa0JBQWtCO1FBQ2xCLHFCQUFxQjtNQUN2QixHQUFHLEVBQUUsQ0FBQyxNQUFNO01BRVosTUFBTSxTQUFTLElBQUksQ0FBQyxxQkFBcUIsTUFBTSxDQUFDO1FBQzlDLFVBQVU7UUFDVixTQUFTLE1BQU0sT0FBTztRQUN0QixRQUFRLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQztRQUMxQixPQUFPO1FBQ1AsU0FBUztVQUFFLFlBQVksa0JBQWtCLElBQUksQ0FBQyxDQUFBLElBQUssRUFBRSxFQUFFLEtBQUssVUFBVTtRQUFLO01BQzdFO0lBQ0Y7SUFFQSxxQkFBcUI7SUFDckIsTUFBTSxTQUFTLElBQUksQ0FBQyxVQUFVLE1BQU0sQ0FBQztNQUNuQyxxQkFBcUI7TUFDckIsdUJBQXVCLElBQUksT0FBTyxXQUFXO01BQzdDLHFCQUFxQjtJQUN2QixHQUFHLEVBQUUsQ0FBQyxNQUFNO0lBRVosMkNBQTJDO0lBQzNDLHVEQUF1RDtJQUN2RCwwQ0FBMEM7SUFDMUMsMkNBQTJDO0lBQzNDLE1BQU0sWUFBWTtJQUVsQixNQUFNLGNBQWMsTUFBTSxRQUFRLFNBQVMsWUFBWTtNQUFFLFdBQVc7SUFBZSxHQUFHLE9BQU87SUFFN0YsSUFBSSxDQUFDLGFBQWE7TUFDaEIsUUFBUSxLQUFLLENBQUM7TUFDZCxNQUFNLFNBQVMsSUFBSSxDQUFDLFVBQVUsTUFBTSxDQUFDO1FBQ25DLHFCQUFxQjtRQUNyQixrQkFBa0I7UUFDbEIscUJBQXFCO01BQ3ZCLEdBQUcsRUFBRSxDQUFDLE1BQU07TUFFWixNQUFNLFNBQVMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7UUFDMUMsU0FBUyxNQUFNLE9BQU87UUFDdEIsTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTLENBQUMsbURBQW1ELEVBQUUsTUFBTSxLQUFLLENBQUMsZ0RBQWdELENBQUM7UUFDNUgsYUFBYTtRQUNiLFdBQVc7TUFDYjtNQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsU0FBUztRQUFPLE9BQU87UUFBbUIsU0FBUztNQUFvQyxJQUN4RztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFdBQVcsY0FBYztJQUMvQixRQUFRLEdBQUcsQ0FBQyxDQUFDLDBDQUEwQyxFQUFFLFNBQVMsTUFBTSxDQUFDLEVBQUUsRUFBRSxTQUFTLFFBQVEsQ0FBQyxJQUFJLEVBQUUsU0FBUyxVQUFVLENBQUMsU0FBUyxFQUFFLFNBQVMsWUFBWSxDQUFDLFVBQVUsRUFBRSxTQUFTLFlBQVksQ0FBQyxHQUFHLENBQUM7SUFFaE0sd0NBQXdDO0lBQ3hDLE1BQU0sU0FBUyxJQUFJLENBQUMsd0JBQXdCLE1BQU0sQ0FBQztNQUNqRCxVQUFVO01BQ1YsZUFBZSxTQUFTLFlBQVk7TUFDcEMsZUFBZSxTQUFTLFlBQVk7TUFDcEMsU0FBUyxTQUFTLE1BQU07TUFDeEIsZUFBZSxTQUFTLFlBQVk7TUFDcEMsYUFBYSxDQUFDLFNBQVMsZUFBZTtNQUN0QyxrQkFBa0IsU0FBUyxjQUFjO01BQ3pDLGtCQUFrQixTQUFTLGVBQWU7TUFDMUMsYUFBYSxTQUFTLFVBQVU7TUFDaEMsV0FBVyxTQUFTLFFBQVE7TUFDNUIsVUFBVSxTQUFTLFFBQVE7TUFDM0IsVUFBVSxTQUFTLFFBQVE7TUFDM0IsUUFBUSxTQUFTLE1BQU07TUFDdkIsZ0JBQWdCLFNBQVMsYUFBYTtNQUN0QyxpQkFBaUI7TUFDakIsWUFBWSxJQUFJLE9BQU8sV0FBVztJQUNwQyxHQUFHO01BQUUsWUFBWTtJQUFXO0lBRTVCLDZCQUE2QjtJQUM3QixNQUFNLFlBQVk7SUFFbEIsSUFBSSxTQUFTLGVBQWUsRUFBRTtNQUM1QixRQUFRLEdBQUcsQ0FBQyxDQUFDLGtEQUFrRCxFQUFFLFNBQVMsY0FBYyxDQUFDLHNCQUFzQixDQUFDO01BRWhILE1BQU0sU0FBUyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQUM7UUFDbkMscUJBQXFCO1FBQ3JCLGtCQUFrQjtRQUNsQixrQkFBa0I7UUFDbEIscUJBQXFCO01BQ3ZCLEdBQUcsRUFBRSxDQUFDLE1BQU07TUFFWixNQUFNLFNBQVMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7UUFDMUMsU0FBUyxNQUFNLE9BQU87UUFDdEIsTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTLENBQUMsTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDLGtEQUFrRCxFQUFFLFNBQVMsY0FBYyxDQUFDLGdFQUFnRSxDQUFDO1FBQzNLLGFBQWE7UUFDYixXQUFXO01BQ2I7TUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVCxPQUFPO1FBQ1AsU0FBUyxDQUFDLDJCQUEyQixFQUFFLFNBQVMsY0FBYyxDQUFDLGtDQUFrQyxDQUFDO1FBQ2xHLGtCQUFrQixTQUFTLGNBQWM7TUFDM0MsSUFDQTtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLDZCQUE2QjtJQUM3QixNQUFNLFlBQVk7SUFFbEIsTUFBTSxTQUFTLElBQUksQ0FBQyxVQUFVLE1BQU0sQ0FBQztNQUNuQyxxQkFBcUIsU0FBUyxZQUFZO01BQzFDLG1CQUFtQixTQUFTLFVBQVU7TUFDdEMsaUJBQWlCLFNBQVMsUUFBUTtNQUNsQyxZQUFZLFNBQVMsWUFBWTtNQUNqQyxlQUFlLFNBQVMsTUFBTTtNQUM5QixrQkFBa0I7SUFDcEIsR0FBRyxFQUFFLENBQUMsTUFBTTtJQUVaLDJDQUEyQztJQUMzQyxvQ0FBb0M7SUFDcEMsMkNBQTJDO0lBQzNDLE1BQU0sWUFBWTtJQUVsQixJQUFJLGVBQWU7SUFDbkIsSUFBSSxpQkFBaUIsU0FBUyxZQUFZO0lBQzFDLE1BQU0sWUFBWSxLQUFLLEdBQUcsQ0FBQyxTQUFTLFlBQVksR0FBSSxDQUFDLE1BQU87SUFFNUQsSUFBSSxXQUFXO01BQ2IsUUFBUSxHQUFHLENBQUMsQ0FBQyxvQ0FBb0MsRUFBRSxTQUFTLFlBQVksQ0FBQyxXQUFXLENBQUM7TUFFckYsTUFBTSxhQUFhLE1BQU0sUUFBUSxTQUFTLGNBQWM7UUFDdEQsV0FBVztRQUNYLGFBQWEsQ0FBQztRQUNkLGdCQUFnQjtRQUNoQixnQkFBZ0I7TUFDbEIsR0FBRyxPQUFPLGdCQUFnQixzQkFBc0I7TUFFaEQsSUFBSSxZQUFZLGdCQUFnQjtRQUM5QixlQUFlLFdBQVcsY0FBYztRQUN4QyxpQkFBaUIsV0FBVyxlQUFlLElBQUksQ0FBQztRQUNoRCxRQUFRLEdBQUcsQ0FBQyxDQUFDLHFDQUFxQyxFQUFFLFNBQVMsWUFBWSxDQUFDLEdBQUcsRUFBRSxlQUFlLEtBQUssQ0FBQztNQUN0RyxPQUFPO1FBQ0wsUUFBUSxHQUFHLENBQUMsQ0FBQywrREFBK0QsQ0FBQztNQUMvRTtJQUNGLE9BQU87TUFDTCxRQUFRLEdBQUcsQ0FBQyxDQUFDLGdEQUFnRCxFQUFFLFNBQVMsWUFBWSxDQUFDLDBCQUEwQixDQUFDO0lBQ2xIO0lBRUEsTUFBTSxTQUFTLElBQUksQ0FBQyxVQUFVLE1BQU0sQ0FBQztNQUNuQyxpQkFBaUI7TUFDakIsWUFBWTtNQUNaLHNCQUFzQjtJQUN4QixHQUFHLEVBQUUsQ0FBQyxNQUFNO0lBRVosTUFBTSxTQUFTLElBQUksQ0FBQyx3QkFBd0IsTUFBTSxDQUFDO01BQ2pELGlCQUFpQjtNQUNqQixzQkFBc0I7TUFDdEIsc0JBQXNCO0lBQ3hCLEdBQUcsRUFBRSxDQUFDLFlBQVk7SUFFbEIsMkNBQTJDO0lBQzNDLHdDQUF3QztJQUN4QywyQ0FBMkM7SUFDM0MsTUFBTSxZQUFZO0lBRWxCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxHQUFHLE1BQU0sU0FDN0IsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFlBQ1AsRUFBRSxDQUFDLFdBQVcsTUFBTSxPQUFPLEVBQzNCLFdBQVc7SUFFZCxNQUFNLFdBQVcsU0FBUyxZQUFZO0lBRXRDLDREQUE0RDtJQUM1RCxJQUFJLGtCQUFrQixtQkFBbUI7TUFDdkMsUUFBUSxHQUFHLENBQUMsQ0FBQywyREFBMkQsQ0FBQztNQUV6RSxNQUFNLGFBQWEsTUFBTSxRQUFRLGdCQUFnQixtQkFBbUI7UUFDbEUsV0FBVztRQUNYLFVBQVU7VUFDUixPQUFPLE1BQU0sS0FBSztVQUNsQixRQUFRO1VBQ1IsT0FBTztVQUNQLFdBQVc7VUFDWCxTQUFTLENBQUMsK0JBQStCLEVBQUUsU0FBUyxDQUFDO1VBQ3JELFdBQVcsQ0FBQyxFQUFFLEVBQUUsSUFBSSxPQUFPLFdBQVcsR0FBRyxDQUFDLEVBQUUsU0FBUyxXQUFXLENBQUM7VUFDakUsUUFBUTtZQUNOLGNBQWMsTUFBTSxPQUFPO1lBQzNCLGVBQWU7WUFDZixjQUFjO1lBQ2QsV0FBVyxJQUFJLE9BQU8sV0FBVyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNqRCxlQUFlO1VBQ2pCO1FBQ0Y7TUFDRixHQUFHLE9BQU87UUFBRSxhQUFhO01BQWtCO01BRTNDLElBQUksWUFBWSxhQUFhO1FBQzNCLGVBQWUsV0FBVyxXQUFXO1FBQ3JDLFFBQVEsR0FBRyxDQUFDLENBQUMsd0RBQXdELENBQUM7TUFDeEU7SUFDRixPQUFPO01BQ0wsUUFBUSxHQUFHLENBQUMsQ0FBQywyREFBMkQsQ0FBQztNQUV6RSxNQUFNLGFBQWEsTUFBTSxRQUFRLFNBQVMsY0FBYztRQUN0RCxXQUFXO1FBQ1gsYUFBYSxDQUFDO1FBQ2QsZ0JBQWdCO1FBQ2hCLGdCQUFnQjtRQUNoQixVQUFVO1VBQ1IsUUFBUTtVQUNSLE9BQU8sTUFBTSxLQUFLO1VBQ2xCLE9BQU87VUFDUCxTQUFTLENBQUMsK0JBQStCLEVBQUUsU0FBUyxDQUFDO1VBQ3JELE1BQU0sSUFBSSxPQUFPLFdBQVcsR0FBRyxRQUFRO1VBQ3ZDLFNBQVM7VUFDVCxXQUFXLENBQUMsRUFBRSxFQUFFLElBQUksT0FBTyxXQUFXLEdBQUcsQ0FBQyxFQUFFLFNBQVMsV0FBVyxDQUFDO1VBQ2pFLFNBQVMsTUFBTSxPQUFPO1VBQ3RCLFNBQVM7UUFDWDtNQUNGLEdBQUcsT0FBTztNQUVWLElBQUksWUFBWSxnQkFBZ0I7UUFDOUIsZUFBZSxXQUFXLGNBQWM7UUFDeEMsUUFBUSxHQUFHLENBQUMsQ0FBQywyREFBMkQsQ0FBQztNQUMzRTtJQUNGO0lBRUEsTUFBTSxTQUFTLElBQUksQ0FBQyxVQUFVLE1BQU0sQ0FBQztNQUNuQyxrQkFBa0I7TUFDbEIsa0JBQWtCO0lBQ3BCLEdBQUcsRUFBRSxDQUFDLE1BQU07SUFFWiwyQ0FBMkM7SUFDM0Msc0RBQXNEO0lBQ3RELDJDQUEyQztJQUMzQyxNQUFNLFlBQVk7SUFFbEIsMkRBQTJEO0lBQzNELE1BQU0sV0FBVyxNQUFNLGdCQUFnQjtJQUV2QyxJQUFJO0lBQ0osSUFBSSxtQkFBbUI7SUFFdkIsSUFBSSxVQUFVO01BQ1osaUJBQWlCLENBQUMsRUFBRSxFQUFFLFNBQVMsQ0FBQztNQUNoQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLHVDQUF1QyxFQUFFLGVBQWUsQ0FBQztNQUV0RSx5REFBeUQ7TUFDekQsTUFBTSxXQUFXLE1BQU0sdUJBQXVCO01BRTlDLElBQUksVUFBVTtRQUNaLDhCQUE4QjtRQUM5QixJQUFJO1VBQ0YsTUFBTSxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsUUFBUSxVQUFVLENBQUM7VUFDdkQsTUFBTSxTQUFTLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQzFDLGVBQ0EsVUFDQTtZQUFFLFFBQVE7WUFBTSxhQUFhO1VBQW9DO1VBRW5FLG1CQUFtQjtVQUNuQixRQUFRLEdBQUcsQ0FBQyxDQUFDLHNEQUFzRCxDQUFDO1FBQ3RFLEVBQUUsT0FBTyxHQUFHO1VBQ1YsUUFBUSxLQUFLLENBQUMsQ0FBQywrQ0FBK0MsQ0FBQyxFQUFFO1FBQ25FO01BQ0Y7SUFDRixPQUFPO01BQ0wsNERBQTREO01BQzVELE1BQU0sZ0JBQWdCLElBQUksY0FBYyxNQUFNLENBQUMsZUFBZSxLQUFLLEdBQUcsR0FBRyxRQUFRO01BQ2pGLE1BQU0saUJBQWlCLE1BQU0sT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVc7TUFDN0QsTUFBTSxjQUFjLE1BQU0sSUFBSSxDQUFDLElBQUksV0FBVyxpQkFDM0MsR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxHQUFHLE1BQ3BDLElBQUksQ0FBQztNQUNSLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUM7TUFDekMsUUFBUSxHQUFHLENBQUMsQ0FBQyxtRUFBbUUsQ0FBQztJQUNuRjtJQUVBLE1BQU0sU0FBUyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQUM7TUFDbkMsaUJBQWlCO0lBQ25CLEdBQUcsRUFBRSxDQUFDLE1BQU07SUFFWiwyQ0FBMkM7SUFDM0Msa0NBQWtDO0lBQ2xDLDZDQUE2QztJQUM3QywyQ0FBMkM7SUFDM0MsTUFBTSxZQUFZO0lBRWxCLE1BQU0saUJBQWlCLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLDRDQUE0QyxFQUFFLFFBQVEsaUJBQWlCLENBQUM7SUFDL0gsTUFBTSxTQUFTLElBQUksQ0FBQyxVQUFVLE1BQU0sQ0FBQztNQUNuQyxpQkFBaUI7SUFDbkIsR0FBRyxFQUFFLENBQUMsTUFBTTtJQUVaLDJDQUEyQztJQUMzQyw4QkFBOEI7SUFDOUIsMkNBQTJDO0lBQzNDLE1BQU0sWUFBWTtJQUVsQixJQUFJO01BQ0YsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztNQUNqQyxNQUFNLGFBQWEsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO01BRWhDLE1BQU0sbUJBQW1CLE1BQU0sTUFDN0IsQ0FBQyxFQUFFLFlBQVksZ0NBQWdDLENBQUMsRUFDaEQ7UUFDRSxRQUFRO1FBQ1IsU0FBUztVQUNQLGdCQUFnQjtVQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDO1FBQ3pDO1FBQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztVQUFFO1FBQVE7TUFDakM7TUFHRixNQUFNLGlCQUFpQixNQUFNLGlCQUFpQixJQUFJO01BQ2xELFFBQVEsR0FBRyxDQUFDLENBQUMsbUNBQW1DLENBQUMsRUFBRTtJQUNyRCxFQUFFLE9BQU8sU0FBUztNQUNoQixRQUFRLEtBQUssQ0FBQywyQ0FBMkM7SUFDM0Q7SUFFQSwyQ0FBMkM7SUFDM0MsZUFBZTtJQUNmLDJDQUEyQztJQUMzQyxNQUFNLFNBQVMsSUFBSSxDQUFDLFVBQVUsTUFBTSxDQUFDO01BQ25DLHFCQUFxQjtNQUNyQixrQkFBa0I7TUFDbEIscUJBQXFCO01BQ3JCLHlCQUF5QixJQUFJLE9BQU8sV0FBVztNQUMvQyxrQkFBa0I7SUFDcEIsR0FBRyxFQUFFLENBQUMsTUFBTTtJQUVaLE1BQU0sb0JBQW9CO01BQ3hCLGlCQUFpQjtNQUNqQixTQUFTO01BQ1QsVUFBVTtRQUNSLGVBQWUsU0FBUyxZQUFZO1FBQ3BDLGVBQWUsU0FBUyxZQUFZO1FBQ3BDLGlCQUFpQjtRQUNqQix1QkFBdUI7UUFDdkIsa0JBQWtCO1FBQ2xCLGtCQUFrQixTQUFTLGNBQWM7UUFDekMsUUFBUSxTQUFTLE1BQU07UUFDdkIsV0FBVyxTQUFTLFFBQVE7UUFDNUIsYUFBYSxTQUFTLFVBQVU7UUFDaEMsVUFBVSxTQUFTLFFBQVE7TUFDN0I7TUFDQSxZQUFZO1FBQ1YsTUFBTTtRQUNOLGFBQWEsQ0FBQyxDQUFDO1FBQ2Ysb0JBQW9CO01BQ3RCO01BQ0EsVUFBVTtRQUNSLFNBQVM7UUFDVCxTQUFTO1FBQ1QsUUFBUTtNQUNWO01BQ0EsaUJBQWlCO0lBQ25CO0lBRUEsTUFBTSxTQUFTLElBQUksQ0FBQyxxQkFBcUIsTUFBTSxDQUFDO01BQzlDLFVBQVU7TUFDVixTQUFTLE1BQU0sT0FBTztNQUN0QixRQUFRO01BQ1IsT0FBTztNQUNQLFNBQVM7SUFDWDtJQUVBLE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztNQUMxQyxTQUFTLE1BQU0sT0FBTztNQUN0QixNQUFNO01BQ04sT0FBTztNQUNQLFNBQVMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUMsK0dBQStHLENBQUM7TUFDOUksYUFBYTtNQUNiLFdBQVc7SUFDYjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsMkVBQTJFLENBQUM7SUFFekYsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsU0FBUztNQUNULGtCQUFrQixrQkFBa0IsTUFBTTtNQUMxQyxpQkFBaUI7TUFDakIsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyxpQ0FBaUM7SUFDL0MsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztNQUFPLE9BQU87SUFBUSxJQUNoRDtNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRiJ9
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
const FILE_UPLOAD_BASE = "https://sunoapiorg.redpandaai.co";
// Map artist names to genre/style descriptions (Suno doesn't allow artist names)
const artistToStyleMap = {
  "Drake": "moody trap hip-hop with melodic hooks",
  "The Weeknd": "dark synth-pop R&B with falsetto vocals",
  "Taylor Swift": "catchy pop-country with storytelling lyrics",
  "Ed Sheeran": "acoustic pop folk with romantic themes",
  "Billie Eilish": "dark minimalist pop with whispered vocals",
  "Ariana Grande": "powerful pop R&B with high vocals",
  "Dua Lipa": "disco-influenced dance pop",
  "Bad Bunny": "reggaeton latin trap with urban beats",
  "Post Malone": "melodic hip-hop rock fusion",
  "Kendrick Lamar": "conscious lyrical hip-hop",
  "Beyoncé": "powerful R&B pop with soulful vocals",
  "Bruno Mars": "funk pop with retro grooves",
  "Adele": "powerful ballads with soulful vocals",
  "Coldplay": "anthemic alternative rock with atmospheric synths"
};
function convertArtistToStyle(artistName) {
  if (artistToStyleMap[artistName]) {
    return artistToStyleMap[artistName];
  }
  const lowerName = artistName.toLowerCase();
  for (const [artist, style] of Object.entries(artistToStyleMap)){
    if (artist.toLowerCase() === lowerName) {
      return style;
    }
  }
  return "contemporary pop with modern production";
}
function cleanStyleForSuno(style) {
  if (!style) return "";
  let cleanedStyle = style;
  for (const artistName of Object.keys(artistToStyleMap)){
    const regex = new RegExp(`${artistName}\\s*style`, "gi");
    if (regex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(regex, convertArtistToStyle(artistName));
    }
    const standaloneRegex = new RegExp(`\\b${artistName}\\b`, "gi");
    if (standaloneRegex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(standaloneRegex, convertArtistToStyle(artistName));
    }
  }
  cleanedStyle = cleanedStyle.replace(/,\s*,/g, ",").replace(/\s+/g, " ").trim();
  return cleanedStyle;
}
/**
 * Upload file to Suno API via URL method
 */ async function uploadFileToSuno(fileUrl) {
  console.log(`Uploading file to Suno from URL: ${fileUrl}`);
  // Send both parameter names for API compatibility
  const requestBody = {
    fileUrl: fileUrl,
    uploadPath: fileUrl,
    url: fileUrl
  };
  console.log("Upload request body:", JSON.stringify(requestBody));
  const response = await fetch(`${FILE_UPLOAD_BASE}/api/file-url-upload`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${SUNO_API_KEY}`
    },
    body: JSON.stringify(requestBody)
  });
  const data = await response.json();
  console.log("File upload response:", JSON.stringify(data));
  if (!response.ok || data.code && data.code !== 200) {
    throw new Error(data.msg || "Failed to upload file to Suno");
  }
  // Response contains downloadUrl for the uploaded file
  const uploadedUrl = data.data?.downloadUrl || data.data?.url || data.data || data.downloadUrl || data.url;
  console.log("Uploaded file URL:", uploadedUrl);
  return uploadedUrl;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { trackId, sourceAudioUrl, prompt, style, title } = await req.json();
    if (!trackId || !sourceAudioUrl) {
      return new Response(JSON.stringify({
        error: "Missing required fields: trackId, sourceAudioUrl"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (!prompt) {
      return new Response(JSON.stringify({
        error: "Missing required field: prompt (lyrics for vocals)"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Starting upload-add-vocal for track ${trackId} by user ${user.id}`);
    console.log(`Source audio: ${sourceAudioUrl}`);
    console.log(`Style: ${style}, Prompt length: ${prompt.length}`);
    // Clean the style to remove artist names
    const cleanedStyle = cleanStyleForSuno(style || "");
    console.log(`Cleaned style: ${cleanedStyle}`);
    // Update track status to processing
    const { error: updateError } = await supabaseClient.from("tracks").update({
      status: "processing",
      error_message: null
    }).eq("id", trackId).eq("user_id", user.id);
    if (updateError) {
      console.error("Failed to update track status:", updateError);
    }
    // Step 1: Upload the source audio to Suno's servers
    let sunoUploadUrl;
    try {
      sunoUploadUrl = await uploadFileToSuno(sourceAudioUrl);
      console.log(`File uploaded to Suno: ${sunoUploadUrl}`);
    } catch (uploadError) {
      console.error("Failed to upload file to Suno:", uploadError);
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: "Не удалось загрузить аудио для обработки"
      }).eq("id", trackId);
      return new Response(JSON.stringify({
        error: "Failed to upload audio file"
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Step 2: Call Suno upload-extend endpoint (for adding vocals to instrumental)
    // Using upload-extend API: POST /api/v1/generate/upload-extend
    // Required params: uploadUrl, defaultParamFlag, continueAt, instrumental, prompt, model, callBackUrl
    // NOTE: continueAt must be > 0 according to API docs, use 0.01 as minimum
    const sunoPayload = {
      uploadUrl: sunoUploadUrl,
      defaultParamFlag: true,
      continueAt: 0.01,
      instrumental: false,
      prompt: prompt,
      model: "V4",
      callBackUrl: `${Deno.env.get("SUPABASE_URL")}/functions/v1/suno-callback`
    };
    // Add style if provided (max 200 chars for V4)
    if (cleanedStyle) {
      sunoPayload.style = cleanedStyle.slice(0, 200);
    }
    console.log("Sending to Suno upload-extend API:", JSON.stringify(sunoPayload));
    const sunoResponse = await fetch(`${SUNO_API_BASE}/api/v1/generate/upload-extend`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify(sunoPayload)
    });
    const sunoData = await sunoResponse.json();
    console.log("Suno upload-extend response:", JSON.stringify(sunoData));
    if (!sunoResponse.ok || sunoData.code !== 200) {
      const errorMessage = sunoData.msg || "Failed to start vocal generation";
      console.error(`Suno API error: ${errorMessage}`);
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: errorMessage
      }).eq("id", trackId).eq("user_id", user.id);
      return new Response(JSON.stringify({
        error: errorMessage,
        details: sunoData
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const taskId = sunoData.data?.taskId;
    console.log(`Vocal generation started with task ID: ${taskId}`);
    return new Response(JSON.stringify({
      success: true,
      taskId,
      message: "Vocal generation started successfully"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in upload-add-vocal:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl91cGxvYWQtYWRkLXZvY2FsLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5jb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG5jb25zdCBTVU5PX0FQSV9CQVNFID0gXCJodHRwczovL2FwaWJveC5lcndlaW1hLmFpXCI7XG5jb25zdCBGSUxFX1VQTE9BRF9CQVNFID0gXCJodHRwczovL3N1bm9hcGlvcmcucmVkcGFuZGFhaS5jb1wiO1xuXG4vLyBNYXAgYXJ0aXN0IG5hbWVzIHRvIGdlbnJlL3N0eWxlIGRlc2NyaXB0aW9ucyAoU3VubyBkb2Vzbid0IGFsbG93IGFydGlzdCBuYW1lcylcbmNvbnN0IGFydGlzdFRvU3R5bGVNYXA6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIFwiRHJha2VcIjogXCJtb29keSB0cmFwIGhpcC1ob3Agd2l0aCBtZWxvZGljIGhvb2tzXCIsXG4gIFwiVGhlIFdlZWtuZFwiOiBcImRhcmsgc3ludGgtcG9wIFImQiB3aXRoIGZhbHNldHRvIHZvY2Fsc1wiLFxuICBcIlRheWxvciBTd2lmdFwiOiBcImNhdGNoeSBwb3AtY291bnRyeSB3aXRoIHN0b3J5dGVsbGluZyBseXJpY3NcIixcbiAgXCJFZCBTaGVlcmFuXCI6IFwiYWNvdXN0aWMgcG9wIGZvbGsgd2l0aCByb21hbnRpYyB0aGVtZXNcIixcbiAgXCJCaWxsaWUgRWlsaXNoXCI6IFwiZGFyayBtaW5pbWFsaXN0IHBvcCB3aXRoIHdoaXNwZXJlZCB2b2NhbHNcIixcbiAgXCJBcmlhbmEgR3JhbmRlXCI6IFwicG93ZXJmdWwgcG9wIFImQiB3aXRoIGhpZ2ggdm9jYWxzXCIsXG4gIFwiRHVhIExpcGFcIjogXCJkaXNjby1pbmZsdWVuY2VkIGRhbmNlIHBvcFwiLFxuICBcIkJhZCBCdW5ueVwiOiBcInJlZ2dhZXRvbiBsYXRpbiB0cmFwIHdpdGggdXJiYW4gYmVhdHNcIixcbiAgXCJQb3N0IE1hbG9uZVwiOiBcIm1lbG9kaWMgaGlwLWhvcCByb2NrIGZ1c2lvblwiLFxuICBcIktlbmRyaWNrIExhbWFyXCI6IFwiY29uc2Npb3VzIGx5cmljYWwgaGlwLWhvcFwiLFxuICBcIkJleW9uY8OpXCI6IFwicG93ZXJmdWwgUiZCIHBvcCB3aXRoIHNvdWxmdWwgdm9jYWxzXCIsXG4gIFwiQnJ1bm8gTWFyc1wiOiBcImZ1bmsgcG9wIHdpdGggcmV0cm8gZ3Jvb3Zlc1wiLFxuICBcIkFkZWxlXCI6IFwicG93ZXJmdWwgYmFsbGFkcyB3aXRoIHNvdWxmdWwgdm9jYWxzXCIsXG4gIFwiQ29sZHBsYXlcIjogXCJhbnRoZW1pYyBhbHRlcm5hdGl2ZSByb2NrIHdpdGggYXRtb3NwaGVyaWMgc3ludGhzXCIsXG59O1xuXG5mdW5jdGlvbiBjb252ZXJ0QXJ0aXN0VG9TdHlsZShhcnRpc3ROYW1lOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoYXJ0aXN0VG9TdHlsZU1hcFthcnRpc3ROYW1lXSkge1xuICAgIHJldHVybiBhcnRpc3RUb1N0eWxlTWFwW2FydGlzdE5hbWVdO1xuICB9XG4gIGNvbnN0IGxvd2VyTmFtZSA9IGFydGlzdE5hbWUudG9Mb3dlckNhc2UoKTtcbiAgZm9yIChjb25zdCBbYXJ0aXN0LCBzdHlsZV0gb2YgT2JqZWN0LmVudHJpZXMoYXJ0aXN0VG9TdHlsZU1hcCkpIHtcbiAgICBpZiAoYXJ0aXN0LnRvTG93ZXJDYXNlKCkgPT09IGxvd2VyTmFtZSkge1xuICAgICAgcmV0dXJuIHN0eWxlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gXCJjb250ZW1wb3JhcnkgcG9wIHdpdGggbW9kZXJuIHByb2R1Y3Rpb25cIjtcbn1cblxuZnVuY3Rpb24gY2xlYW5TdHlsZUZvclN1bm8oc3R5bGU6IHN0cmluZyk6IHN0cmluZyB7XG4gIGlmICghc3R5bGUpIHJldHVybiBcIlwiO1xuICBcbiAgbGV0IGNsZWFuZWRTdHlsZSA9IHN0eWxlO1xuICBmb3IgKGNvbnN0IGFydGlzdE5hbWUgb2YgT2JqZWN0LmtleXMoYXJ0aXN0VG9TdHlsZU1hcCkpIHtcbiAgICBjb25zdCByZWdleCA9IG5ldyBSZWdFeHAoYCR7YXJ0aXN0TmFtZX1cXFxccypzdHlsZWAsIFwiZ2lcIik7XG4gICAgaWYgKHJlZ2V4LnRlc3QoY2xlYW5lZFN0eWxlKSkge1xuICAgICAgY2xlYW5lZFN0eWxlID0gY2xlYW5lZFN0eWxlLnJlcGxhY2UocmVnZXgsIGNvbnZlcnRBcnRpc3RUb1N0eWxlKGFydGlzdE5hbWUpKTtcbiAgICB9XG4gICAgY29uc3Qgc3RhbmRhbG9uZVJlZ2V4ID0gbmV3IFJlZ0V4cChgXFxcXGIke2FydGlzdE5hbWV9XFxcXGJgLCBcImdpXCIpO1xuICAgIGlmIChzdGFuZGFsb25lUmVnZXgudGVzdChjbGVhbmVkU3R5bGUpKSB7XG4gICAgICBjbGVhbmVkU3R5bGUgPSBjbGVhbmVkU3R5bGUucmVwbGFjZShzdGFuZGFsb25lUmVnZXgsIGNvbnZlcnRBcnRpc3RUb1N0eWxlKGFydGlzdE5hbWUpKTtcbiAgICB9XG4gIH1cbiAgXG4gIGNsZWFuZWRTdHlsZSA9IGNsZWFuZWRTdHlsZS5yZXBsYWNlKC8sXFxzKiwvZywgXCIsXCIpLnJlcGxhY2UoL1xccysvZywgXCIgXCIpLnRyaW0oKTtcbiAgcmV0dXJuIGNsZWFuZWRTdHlsZTtcbn1cblxuLyoqXG4gKiBVcGxvYWQgZmlsZSB0byBTdW5vIEFQSSB2aWEgVVJMIG1ldGhvZFxuICovXG5hc3luYyBmdW5jdGlvbiB1cGxvYWRGaWxlVG9TdW5vKGZpbGVVcmw6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnNvbGUubG9nKGBVcGxvYWRpbmcgZmlsZSB0byBTdW5vIGZyb20gVVJMOiAke2ZpbGVVcmx9YCk7XG4gIFxuICAvLyBTZW5kIGJvdGggcGFyYW1ldGVyIG5hbWVzIGZvciBBUEkgY29tcGF0aWJpbGl0eVxuICBjb25zdCByZXF1ZXN0Qm9keSA9IHsgXG4gICAgZmlsZVVybDogZmlsZVVybCxcbiAgICB1cGxvYWRQYXRoOiBmaWxlVXJsLFxuICAgIHVybDogZmlsZVVybCBcbiAgfTtcbiAgY29uc29sZS5sb2coXCJVcGxvYWQgcmVxdWVzdCBib2R5OlwiLCBKU09OLnN0cmluZ2lmeShyZXF1ZXN0Qm9keSkpO1xuICBcbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtGSUxFX1VQTE9BRF9CQVNFfS9hcGkvZmlsZS11cmwtdXBsb2FkYCwge1xuICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgaGVhZGVyczoge1xuICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NVTk9fQVBJX0tFWX1gLFxuICAgIH0sXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkocmVxdWVzdEJvZHkpLFxuICB9KTtcblxuICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICBjb25zb2xlLmxvZyhcIkZpbGUgdXBsb2FkIHJlc3BvbnNlOlwiLCBKU09OLnN0cmluZ2lmeShkYXRhKSk7XG4gIFxuICBpZiAoIXJlc3BvbnNlLm9rIHx8IChkYXRhLmNvZGUgJiYgZGF0YS5jb2RlICE9PSAyMDApKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGRhdGEubXNnIHx8IFwiRmFpbGVkIHRvIHVwbG9hZCBmaWxlIHRvIFN1bm9cIik7XG4gIH1cbiAgXG4gIC8vIFJlc3BvbnNlIGNvbnRhaW5zIGRvd25sb2FkVXJsIGZvciB0aGUgdXBsb2FkZWQgZmlsZVxuICBjb25zdCB1cGxvYWRlZFVybCA9IGRhdGEuZGF0YT8uZG93bmxvYWRVcmwgfHwgZGF0YS5kYXRhPy51cmwgfHwgZGF0YS5kYXRhIHx8IGRhdGEuZG93bmxvYWRVcmwgfHwgZGF0YS51cmw7XG4gIGNvbnNvbGUubG9nKFwiVXBsb2FkZWQgZmlsZSBVUkw6XCIsIHVwbG9hZGVkVXJsKTtcbiAgcmV0dXJuIHVwbG9hZGVkVXJsO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk5vIGF1dGhvcml6YXRpb24gaGVhZGVyXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZUNsaWVudCA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikgPz8gXCJcIixcbiAgICAgIHsgZ2xvYmFsOiB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYXV0aEhlYWRlciB9IH0gfVxuICAgICk7XG5cbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9LCBlcnJvcjogdXNlckVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudC5hdXRoLmdldFVzZXIoKTtcbiAgICBpZiAodXNlckVycm9yIHx8ICF1c2VyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgeyBcbiAgICAgIHRyYWNrSWQsIFxuICAgICAgc291cmNlQXVkaW9VcmwsICAvLyBVUkwgb2YgdXBsb2FkZWQgaW5zdHJ1bWVudGFsIGF1ZGlvIGZpbGVcbiAgICAgIHByb21wdCwgICAgICAgICAgLy8gTHlyaWNzIHRleHQgZm9yIHZvY2Fsc1xuICAgICAgc3R5bGUsICAgICAgICAgICAvLyBNdXNpYyBzdHlsZVxuICAgICAgdGl0bGUsIFxuICAgIH0gPSBhd2FpdCByZXEuanNvbigpO1xuXG4gICAgaWYgKCF0cmFja0lkIHx8ICFzb3VyY2VBdWRpb1VybCkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJNaXNzaW5nIHJlcXVpcmVkIGZpZWxkczogdHJhY2tJZCwgc291cmNlQXVkaW9VcmxcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGlmICghcHJvbXB0KSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk1pc3NpbmcgcmVxdWlyZWQgZmllbGQ6IHByb21wdCAobHlyaWNzIGZvciB2b2NhbHMpXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgU3RhcnRpbmcgdXBsb2FkLWFkZC12b2NhbCBmb3IgdHJhY2sgJHt0cmFja0lkfSBieSB1c2VyICR7dXNlci5pZH1gKTtcbiAgICBjb25zb2xlLmxvZyhgU291cmNlIGF1ZGlvOiAke3NvdXJjZUF1ZGlvVXJsfWApO1xuICAgIGNvbnNvbGUubG9nKGBTdHlsZTogJHtzdHlsZX0sIFByb21wdCBsZW5ndGg6ICR7cHJvbXB0Lmxlbmd0aH1gKTtcblxuICAgIC8vIENsZWFuIHRoZSBzdHlsZSB0byByZW1vdmUgYXJ0aXN0IG5hbWVzXG4gICAgY29uc3QgY2xlYW5lZFN0eWxlID0gY2xlYW5TdHlsZUZvclN1bm8oc3R5bGUgfHwgXCJcIik7XG4gICAgY29uc29sZS5sb2coYENsZWFuZWQgc3R5bGU6ICR7Y2xlYW5lZFN0eWxlfWApO1xuXG4gICAgLy8gVXBkYXRlIHRyYWNrIHN0YXR1cyB0byBwcm9jZXNzaW5nXG4gICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJwcm9jZXNzaW5nXCIsIGVycm9yX21lc3NhZ2U6IG51bGwgfSlcbiAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpO1xuXG4gICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSB0cmFjayBzdGF0dXM6XCIsIHVwZGF0ZUVycm9yKTtcbiAgICB9XG5cbiAgICAvLyBTdGVwIDE6IFVwbG9hZCB0aGUgc291cmNlIGF1ZGlvIHRvIFN1bm8ncyBzZXJ2ZXJzXG4gICAgbGV0IHN1bm9VcGxvYWRVcmw6IHN0cmluZztcbiAgICB0cnkge1xuICAgICAgc3Vub1VwbG9hZFVybCA9IGF3YWl0IHVwbG9hZEZpbGVUb1N1bm8oc291cmNlQXVkaW9VcmwpO1xuICAgICAgY29uc29sZS5sb2coYEZpbGUgdXBsb2FkZWQgdG8gU3VubzogJHtzdW5vVXBsb2FkVXJsfWApO1xuICAgIH0gY2F0Y2ggKHVwbG9hZEVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHVwbG9hZCBmaWxlIHRvIFN1bm86XCIsIHVwbG9hZEVycm9yKTtcbiAgICAgIGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgIC51cGRhdGUoeyBcbiAgICAgICAgICBzdGF0dXM6IFwiZmFpbGVkXCIsXG4gICAgICAgICAgZXJyb3JfbWVzc2FnZTogXCLQndC1INGD0LTQsNC70L7RgdGMINC30LDQs9GA0YPQt9C40YLRjCDQsNGD0LTQuNC+INC00LvRjyDQvtCx0YDQsNCx0L7RgtC60LhcIlxuICAgICAgICB9KVxuICAgICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKTtcbiAgICAgIFxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJGYWlsZWQgdG8gdXBsb2FkIGF1ZGlvIGZpbGVcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIFN0ZXAgMjogQ2FsbCBTdW5vIHVwbG9hZC1leHRlbmQgZW5kcG9pbnQgKGZvciBhZGRpbmcgdm9jYWxzIHRvIGluc3RydW1lbnRhbClcbiAgICAvLyBVc2luZyB1cGxvYWQtZXh0ZW5kIEFQSTogUE9TVCAvYXBpL3YxL2dlbmVyYXRlL3VwbG9hZC1leHRlbmRcbiAgICAvLyBSZXF1aXJlZCBwYXJhbXM6IHVwbG9hZFVybCwgZGVmYXVsdFBhcmFtRmxhZywgY29udGludWVBdCwgaW5zdHJ1bWVudGFsLCBwcm9tcHQsIG1vZGVsLCBjYWxsQmFja1VybFxuICAgIC8vIE5PVEU6IGNvbnRpbnVlQXQgbXVzdCBiZSA+IDAgYWNjb3JkaW5nIHRvIEFQSSBkb2NzLCB1c2UgMC4wMSBhcyBtaW5pbXVtXG4gICAgY29uc3Qgc3Vub1BheWxvYWQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgICAgdXBsb2FkVXJsOiBzdW5vVXBsb2FkVXJsLFxuICAgICAgZGVmYXVsdFBhcmFtRmxhZzogdHJ1ZSwgICAvLyBSZXF1aXJlZCAtIHVzZSBjdXN0b20gcGFyYW1zIChtdXN0IGJlIHRydWUgd2hlbiBwcm92aWRpbmcgc3R5bGUvcHJvbXB0KVxuICAgICAgY29udGludWVBdDogMC4wMSwgICAgICAgICAvLyBSZXF1aXJlZCAtIG11c3QgYmUgPiAwIChzZWNvbmRzKVxuICAgICAgaW5zdHJ1bWVudGFsOiBmYWxzZSwgICAgICAvLyBXZSB3YW50IHZvY2FscyBhZGRlZFxuICAgICAgcHJvbXB0OiBwcm9tcHQsICAgICAgICAgICAvLyBUaGUgbHlyaWNzXG4gICAgICBtb2RlbDogXCJWNFwiLFxuICAgICAgY2FsbEJhY2tVcmw6IGAke0Rlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKX0vZnVuY3Rpb25zL3YxL3N1bm8tY2FsbGJhY2tgLFxuICAgIH07XG5cbiAgICAvLyBBZGQgc3R5bGUgaWYgcHJvdmlkZWQgKG1heCAyMDAgY2hhcnMgZm9yIFY0KVxuICAgIGlmIChjbGVhbmVkU3R5bGUpIHtcbiAgICAgIHN1bm9QYXlsb2FkLnN0eWxlID0gY2xlYW5lZFN0eWxlLnNsaWNlKDAsIDIwMCk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coXCJTZW5kaW5nIHRvIFN1bm8gdXBsb2FkLWV4dGVuZCBBUEk6XCIsIEpTT04uc3RyaW5naWZ5KHN1bm9QYXlsb2FkKSk7XG5cbiAgICBjb25zdCBzdW5vUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtTVU5PX0FQSV9CQVNFfS9hcGkvdjEvZ2VuZXJhdGUvdXBsb2FkLWV4dGVuZGAsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NVTk9fQVBJX0tFWX1gLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHN1bm9QYXlsb2FkKSxcbiAgICB9KTtcblxuICAgIGNvbnN0IHN1bm9EYXRhID0gYXdhaXQgc3Vub1Jlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhcIlN1bm8gdXBsb2FkLWV4dGVuZCByZXNwb25zZTpcIiwgSlNPTi5zdHJpbmdpZnkoc3Vub0RhdGEpKTtcblxuICAgIGlmICghc3Vub1Jlc3BvbnNlLm9rIHx8IHN1bm9EYXRhLmNvZGUgIT09IDIwMCkge1xuICAgICAgY29uc3QgZXJyb3JNZXNzYWdlID0gc3Vub0RhdGEubXNnIHx8IFwiRmFpbGVkIHRvIHN0YXJ0IHZvY2FsIGdlbmVyYXRpb25cIjtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYFN1bm8gQVBJIGVycm9yOiAke2Vycm9yTWVzc2FnZX1gKTtcbiAgICAgIFxuICAgICAgYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgICBlcnJvcl9tZXNzYWdlOiBlcnJvck1lc3NhZ2VcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZClcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcblxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBlcnJvcjogZXJyb3JNZXNzYWdlLFxuICAgICAgICAgIGRldGFpbHM6IHN1bm9EYXRhIFxuICAgICAgICB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHRhc2tJZCA9IHN1bm9EYXRhLmRhdGE/LnRhc2tJZDtcbiAgICBjb25zb2xlLmxvZyhgVm9jYWwgZ2VuZXJhdGlvbiBzdGFydGVkIHdpdGggdGFzayBJRDogJHt0YXNrSWR9YCk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIHRhc2tJZCxcbiAgICAgICAgbWVzc2FnZTogXCJWb2NhbCBnZW5lcmF0aW9uIHN0YXJ0ZWQgc3VjY2Vzc2Z1bGx5XCIgXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiB1cGxvYWQtYWRkLXZvY2FsOlwiLCBlcnJvcik7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogZXJyb3JNZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2xDLE1BQU0sZ0JBQWdCO0FBQ3RCLE1BQU0sbUJBQW1CO0FBRXpCLGlGQUFpRjtBQUNqRixNQUFNLG1CQUEyQztFQUMvQyxTQUFTO0VBQ1QsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGlCQUFpQjtFQUNqQixZQUFZO0VBQ1osYUFBYTtFQUNiLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLGNBQWM7RUFDZCxTQUFTO0VBQ1QsWUFBWTtBQUNkO0FBRUEsU0FBUyxxQkFBcUIsVUFBa0I7RUFDOUMsSUFBSSxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUU7SUFDaEMsT0FBTyxnQkFBZ0IsQ0FBQyxXQUFXO0VBQ3JDO0VBQ0EsTUFBTSxZQUFZLFdBQVcsV0FBVztFQUN4QyxLQUFLLE1BQU0sQ0FBQyxRQUFRLE1BQU0sSUFBSSxPQUFPLE9BQU8sQ0FBQyxrQkFBbUI7SUFDOUQsSUFBSSxPQUFPLFdBQVcsT0FBTyxXQUFXO01BQ3RDLE9BQU87SUFDVDtFQUNGO0VBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxrQkFBa0IsS0FBYTtFQUN0QyxJQUFJLENBQUMsT0FBTyxPQUFPO0VBRW5CLElBQUksZUFBZTtFQUNuQixLQUFLLE1BQU0sY0FBYyxPQUFPLElBQUksQ0FBQyxrQkFBbUI7SUFDdEQsTUFBTSxRQUFRLElBQUksT0FBTyxDQUFDLEVBQUUsV0FBVyxTQUFTLENBQUMsRUFBRTtJQUNuRCxJQUFJLE1BQU0sSUFBSSxDQUFDLGVBQWU7TUFDNUIsZUFBZSxhQUFhLE9BQU8sQ0FBQyxPQUFPLHFCQUFxQjtJQUNsRTtJQUNBLE1BQU0sa0JBQWtCLElBQUksT0FBTyxDQUFDLEdBQUcsRUFBRSxXQUFXLEdBQUcsQ0FBQyxFQUFFO0lBQzFELElBQUksZ0JBQWdCLElBQUksQ0FBQyxlQUFlO01BQ3RDLGVBQWUsYUFBYSxPQUFPLENBQUMsaUJBQWlCLHFCQUFxQjtJQUM1RTtFQUNGO0VBRUEsZUFBZSxhQUFhLE9BQU8sQ0FBQyxVQUFVLEtBQUssT0FBTyxDQUFDLFFBQVEsS0FBSyxJQUFJO0VBQzVFLE9BQU87QUFDVDtBQUVBOztDQUVDLEdBQ0QsZUFBZSxpQkFBaUIsT0FBZTtFQUM3QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLGlDQUFpQyxFQUFFLFFBQVEsQ0FBQztFQUV6RCxrREFBa0Q7RUFDbEQsTUFBTSxjQUFjO0lBQ2xCLFNBQVM7SUFDVCxZQUFZO0lBQ1osS0FBSztFQUNQO0VBQ0EsUUFBUSxHQUFHLENBQUMsd0JBQXdCLEtBQUssU0FBUyxDQUFDO0VBRW5ELE1BQU0sV0FBVyxNQUFNLE1BQU0sQ0FBQyxFQUFFLGlCQUFpQixvQkFBb0IsQ0FBQyxFQUFFO0lBQ3RFLFFBQVE7SUFDUixTQUFTO01BQ1AsZ0JBQWdCO01BQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7SUFDM0M7SUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO0VBQ3ZCO0VBRUEsTUFBTSxPQUFPLE1BQU0sU0FBUyxJQUFJO0VBQ2hDLFFBQVEsR0FBRyxDQUFDLHlCQUF5QixLQUFLLFNBQVMsQ0FBQztFQUVwRCxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUssS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssS0FBTTtJQUNwRCxNQUFNLElBQUksTUFBTSxLQUFLLEdBQUcsSUFBSTtFQUM5QjtFQUVBLHNEQUFzRDtFQUN0RCxNQUFNLGNBQWMsS0FBSyxJQUFJLEVBQUUsZUFBZSxLQUFLLElBQUksRUFBRSxPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUssV0FBVyxJQUFJLEtBQUssR0FBRztFQUN6RyxRQUFRLEdBQUcsQ0FBQyxzQkFBc0I7RUFDbEMsT0FBTztBQUNUO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEwQixJQUNsRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGlCQUFpQixhQUNyQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFDckM7TUFBRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQUU7SUFHdkQsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sZUFBZSxJQUFJLENBQUMsT0FBTztJQUM5RSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFlLElBQ3ZDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sRUFDSixPQUFPLEVBQ1AsY0FBYyxFQUNkLE1BQU0sRUFDTixLQUFLLEVBQ0wsS0FBSyxFQUNOLEdBQUcsTUFBTSxJQUFJLElBQUk7SUFFbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0I7TUFDL0IsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQW1ELElBQzNFO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLElBQUksQ0FBQyxRQUFRO01BQ1gsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQXFELElBQzdFO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsb0NBQW9DLEVBQUUsUUFBUSxTQUFTLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUMvRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGNBQWMsRUFBRSxlQUFlLENBQUM7SUFDN0MsUUFBUSxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0lBRTlELHlDQUF5QztJQUN6QyxNQUFNLGVBQWUsa0JBQWtCLFNBQVM7SUFDaEQsUUFBUSxHQUFHLENBQUMsQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDO0lBRTVDLG9DQUFvQztJQUNwQyxNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLGVBQ2xDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztNQUFFLFFBQVE7TUFBYyxlQUFlO0lBQUssR0FDbkQsRUFBRSxDQUFDLE1BQU0sU0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUU7SUFFeEIsSUFBSSxhQUFhO01BQ2YsUUFBUSxLQUFLLENBQUMsa0NBQWtDO0lBQ2xEO0lBRUEsb0RBQW9EO0lBQ3BELElBQUk7SUFDSixJQUFJO01BQ0YsZ0JBQWdCLE1BQU0saUJBQWlCO01BQ3ZDLFFBQVEsR0FBRyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsY0FBYyxDQUFDO0lBQ3ZELEVBQUUsT0FBTyxhQUFhO01BQ3BCLFFBQVEsS0FBSyxDQUFDLGtDQUFrQztNQUNoRCxNQUFNLGVBQ0gsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sUUFBUTtRQUNSLGVBQWU7TUFDakIsR0FDQyxFQUFFLENBQUMsTUFBTTtNQUVaLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE4QixJQUN0RDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSwrRUFBK0U7SUFDL0UsK0RBQStEO0lBQy9ELHFHQUFxRztJQUNyRywwRUFBMEU7SUFDMUUsTUFBTSxjQUF1QztNQUMzQyxXQUFXO01BQ1gsa0JBQWtCO01BQ2xCLFlBQVk7TUFDWixjQUFjO01BQ2QsUUFBUTtNQUNSLE9BQU87TUFDUCxhQUFhLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLDJCQUEyQixDQUFDO0lBQzNFO0lBRUEsK0NBQStDO0lBQy9DLElBQUksY0FBYztNQUNoQixZQUFZLEtBQUssR0FBRyxhQUFhLEtBQUssQ0FBQyxHQUFHO0lBQzVDO0lBRUEsUUFBUSxHQUFHLENBQUMsc0NBQXNDLEtBQUssU0FBUyxDQUFDO0lBRWpFLE1BQU0sZUFBZSxNQUFNLE1BQU0sQ0FBQyxFQUFFLGNBQWMsOEJBQThCLENBQUMsRUFBRTtNQUNqRixRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDO01BQzNDO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztJQUN2QjtJQUVBLE1BQU0sV0FBVyxNQUFNLGFBQWEsSUFBSTtJQUN4QyxRQUFRLEdBQUcsQ0FBQyxnQ0FBZ0MsS0FBSyxTQUFTLENBQUM7SUFFM0QsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLFNBQVMsSUFBSSxLQUFLLEtBQUs7TUFDN0MsTUFBTSxlQUFlLFNBQVMsR0FBRyxJQUFJO01BQ3JDLFFBQVEsS0FBSyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDO01BRS9DLE1BQU0sZUFDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7UUFDTixRQUFRO1FBQ1IsZUFBZTtNQUNqQixHQUNDLEVBQUUsQ0FBQyxNQUFNLFNBQ1QsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFO01BRXhCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQ2IsT0FBTztRQUNQLFNBQVM7TUFDWCxJQUNBO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sU0FBUyxTQUFTLElBQUksRUFBRTtJQUM5QixRQUFRLEdBQUcsQ0FBQyxDQUFDLHVDQUF1QyxFQUFFLE9BQU8sQ0FBQztJQUU5RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVDtNQUNBLFNBQVM7SUFDWCxJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsOEJBQThCO0lBQzVDLE1BQU0sZUFBZSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUM5RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBYSxJQUNyQztNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRiJ9
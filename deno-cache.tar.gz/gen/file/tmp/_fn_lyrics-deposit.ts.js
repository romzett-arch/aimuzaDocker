const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Генерация SHA-256 хеша
async function generateHash(data) {
  const encoder = new TextEncoder();
  const dataBuffer = encoder.encode(data);
  const hashBuffer = await crypto.subtle.digest("SHA-256", dataBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b)=>b.toString(16).padStart(2, "0")).join("");
}
// OpenTimestamps - бесплатная blockchain фиксация
async function submitToOpenTimestamps(hash) {
  try {
    const response = await fetch("https://a.pool.opentimestamps.org/digest", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: hash
    });
    if (!response.ok) {
      const fallbackResponse = await fetch("https://b.pool.opentimestamps.org/digest", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: hash
      });
      if (!fallbackResponse.ok) {
        throw new Error("OpenTimestamps servers unavailable");
      }
      return `ots_pending_${Date.now()}`;
    }
    return `ots_${Date.now()}`;
  } catch (error) {
    console.error("OpenTimestamps error:", error);
    return `ots_pending_${hash.substring(0, 16)}`;
  }
}
// n'RIS API интеграция
async function submitToNris(lyrics, hash, apiKey, apiUrl) {
  if (!apiKey) {
    throw new Error("API ключ n'RIS не настроен");
  }
  const response = await fetch(`${apiUrl}/deposits`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      type: "lyrics",
      title: lyrics.title,
      author: lyrics.author_name,
      hash: hash,
      metadata: {
        created_at: lyrics.created_at,
        language: lyrics.language
      }
    })
  });
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`n'RIS API error: ${error}`);
  }
  const result = await response.json();
  return {
    depositId: result.deposit_id || result.id,
    certificateUrl: result.certificate_url
  };
}
// IRMA API интеграция
async function submitToIrma(lyrics, hash, apiKey, apiUrl) {
  if (!apiKey) {
    throw new Error("API ключ IRMA не настроен");
  }
  const response = await fetch(`${apiUrl}/register`, {
    method: "POST",
    headers: {
      "X-API-Key": apiKey,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      work_type: "lyrics",
      title: lyrics.title,
      creators: [
        {
          role: "author",
          name: lyrics.author_name
        }
      ],
      content_hash: hash
    })
  });
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`IRMA API error: ${error}`);
  }
  const result = await response.json();
  return {
    depositId: result.registration_id || result.id,
    certificateUrl: result.certificate_url
  };
}
// Генерация HTML сертификата для текста
async function generateLyricsCertificate(supabase, lyrics, hash, depositId, authorName) {
  const formattedDate = new Date().toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
  const htmlContent = `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Сертификат депонирования текста - ${lyrics.title}</title>
  <style>
    @media print {
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .no-print { display: none !important; }
      @page { size: A4; margin: 15mm; }
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { 
      font-family: 'Times New Roman', 'Georgia', serif; 
      padding: 40px; 
      max-width: 800px; 
      margin: 0 auto; 
      background: #fff;
      color: #1a1a1a;
      line-height: 1.5;
    }
    .certificate {
      border: 3px double #2c3e50;
      padding: 40px;
      background: linear-gradient(135deg, #fefefe 0%, #f8f9fa 100%);
      position: relative;
    }
    .certificate::before {
      content: '';
      position: absolute;
      top: 10px; left: 10px; right: 10px; bottom: 10px;
      border: 1px solid #bdc3c7;
      pointer-events: none;
    }
    .header { 
      text-align: center; 
      border-bottom: 2px solid #2c3e50; 
      padding-bottom: 25px; 
      margin-bottom: 30px; 
    }
    .label-name { font-size: 14px; color: #555; font-weight: 500; letter-spacing: 1px; margin-bottom: 5px; }
    .website { font-size: 18px; color: #2c3e50; font-weight: bold; letter-spacing: 2px; }
    .title { 
      font-size: 28px; font-weight: bold; color: #1a1a1a; 
      text-transform: uppercase; letter-spacing: 3px; margin-top: 20px;
    }
    .subtitle { font-size: 16px; color: #666; margin-top: 10px; font-style: italic; }
    .content { display: grid; gap: 18px; }
    .section { display: grid; grid-template-columns: 180px 1fr; align-items: start; gap: 15px; }
    .label { font-weight: bold; color: #2c3e50; font-size: 14px; padding-top: 10px; }
    .value { 
      padding: 12px 15px; background: #fff; border: 1px solid #ddd;
      border-radius: 4px; font-size: 15px; box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);
    }
    .hash { font-family: 'Courier New', monospace; font-size: 11px; word-break: break-all; color: #555; }
    .seal { text-align: center; margin: 35px 0 25px; }
    .seal-text { 
      display: inline-block; padding: 20px 35px; border: 4px double #2c3e50; 
      border-radius: 50%; font-size: 14px; font-weight: bold; color: #2c3e50;
      text-align: center; line-height: 1.4; background: linear-gradient(135deg, #fff 0%, #f0f0f0 100%);
    }
    .footer { 
      margin-top: 30px; padding-top: 20px; border-top: 2px solid #2c3e50; 
      font-size: 12px; color: #666; text-align: center; line-height: 1.8;
    }
    .footer .platform { font-weight: bold; color: #2c3e50; font-size: 14px; margin-top: 15px; }
    .print-btn {
      display: block; margin: 20px auto; padding: 12px 30px;
      background: #2c3e50; color: #fff; border: none; border-radius: 5px;
      font-size: 16px; cursor: pointer; font-family: inherit;
    }
    .print-btn:hover { background: #1a252f; }
  </style>
</head>
<body>
  <button class="print-btn no-print" onclick="window.print()">📄 Сохранить как PDF / Распечатать</button>
  
  <div class="certificate">
    <div class="header">
      <div class="label-name">ООО "Музыкальный лейбл НОТА-ФЕЯ"</div>
      <div class="website">aimuza.ru</div>
      <div class="title">СЕРТИФИКАТ ДЕПОНИРОВАНИЯ</div>
      <div class="subtitle">Литературное произведение (текст песни)</div>
    </div>
    
    <div class="content">
      <div class="section">
        <div class="label">Название:</div>
        <div class="value">${lyrics.title}</div>
      </div>
      <div class="section">
        <div class="label">Автор текста:</div>
        <div class="value">${authorName || "Не указан"}</div>
      </div>
      <div class="section">
        <div class="label">Цифровой отпечаток (SHA-256):</div>
        <div class="value hash">${hash}</div>
      </div>
      <div class="section">
        <div class="label">Идентификатор:</div>
        <div class="value">${depositId}</div>
      </div>
      <div class="section">
        <div class="label">Дата депонирования:</div>
        <div class="value">${formattedDate}</div>
      </div>
    </div>
    
    <div class="seal">
      <div class="seal-text">НОТА-ФЕЯ<br/>✓ Verified</div>
    </div>
    
    <div class="footer">
      <p>Данный сертификат подтверждает факт существования текста на указанную дату.</p>
      <p>Цифровой отпечаток позволяет однозначно идентифицировать оригинальный текст.</p>
      <p class="platform">ООО "Музыкальный лейбл НОТА-ФЕЯ" • aimuza.ru</p>
    </div>
  </div>
</body>
</html>`;
  const fileName = `lyrics_certificate_${depositId}.html`;
  const htmlBytes = new TextEncoder().encode(htmlContent);
  const blob = new Blob([
    htmlBytes
  ], {
    type: "text/html;charset=utf-8"
  });
  const { error: uploadError } = await supabase.storage.from("certificates").upload(fileName, blob, {
    contentType: "text/html;charset=utf-8",
    cacheControl: "3600",
    upsert: true
  });
  if (uploadError) {
    console.error("Error uploading certificate:", uploadError);
    throw new Error("Не удалось сохранить сертификат");
  }
  const { data: urlData } = supabase.storage.from("certificates").getPublicUrl(fileName);
  return urlData.publicUrl;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Get user from auth header
    const authHeader = req.headers.get("authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "Требуется авторизация"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return new Response(JSON.stringify({
        error: "Неверный токен авторизации"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { lyricsId, method, authorName } = await req.json();
    console.log(`Processing lyrics deposit: ${lyricsId}, method: ${method}`);
    // Get lyrics data
    const { data: lyrics, error: lyricsError } = await supabase.from("lyrics_items").select("*").eq("id", lyricsId).eq("user_id", user.id).single();
    if (lyricsError || !lyrics) {
      return new Response(JSON.stringify({
        error: "Текст не найден или нет доступа"
      }), {
        status: 404,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Check for existing deposit
    const { data: existingDeposit } = await supabase.from("lyrics_deposits").select("id, status").eq("lyrics_id", lyricsId).eq("status", "completed").single();
    if (existingDeposit) {
      return new Response(JSON.stringify({
        error: "Текст уже депонирован"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Get deposit price
    const { data: priceSetting } = await supabase.from("app_settings").select("value").eq("key", "lyrics_deposit_price").single();
    const depositPrice = parseInt(priceSetting?.value || "50", 10);
    // Check user balance
    const { data: profile } = await supabase.from("profiles").select("balance").eq("user_id", user.id).single();
    if (!profile || (profile.balance || 0) < depositPrice) {
      return new Response(JSON.stringify({
        error: `Недостаточно средств. Требуется: ${depositPrice} ₽`
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Generate hash from lyrics content
    const contentHash = await generateHash(lyrics.content + lyrics.title + new Date().toISOString());
    const timestampHash = await generateHash(contentHash + Date.now().toString());
    let externalId = null;
    let certificateUrl = null;
    // Process based on method
    if (method === "blockchain") {
      externalId = await submitToOpenTimestamps(contentHash);
    } else if (method === "nris") {
      const nrisApiKey = Deno.env.get("NRIS_API_KEY");
      const nrisApiUrl = Deno.env.get("NRIS_API_URL") || "https://api.nris.ru";
      if (!nrisApiKey) {
        return new Response(JSON.stringify({
          error: "Сервис n'RIS временно недоступен"
        }), {
          status: 503,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      const result = await submitToNris({
        ...lyrics,
        author_name: authorName
      }, contentHash, nrisApiKey, nrisApiUrl);
      externalId = result.depositId;
      certificateUrl = result.certificateUrl || null;
    } else if (method === "irma") {
      const irmaApiKey = Deno.env.get("IRMA_API_KEY");
      const irmaApiUrl = Deno.env.get("IRMA_API_URL") || "https://api.irma.ru";
      if (!irmaApiKey) {
        return new Response(JSON.stringify({
          error: "Сервис IRMA временно недоступен"
        }), {
          status: 503,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      const result = await submitToIrma({
        ...lyrics,
        author_name: authorName
      }, contentHash, irmaApiKey, irmaApiUrl);
      externalId = result.depositId;
      certificateUrl = result.certificateUrl || null;
    }
    // Generate internal deposit ID
    const depositId = `LYR-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    // Always generate PDF certificate for internal
    if (method === "internal" || !certificateUrl) {
      certificateUrl = await generateLyricsCertificate(supabase, lyrics, contentHash, depositId, authorName || "");
    }
    // Deduct balance
    await supabase.from("profiles").update({
      balance: (profile.balance || 0) - depositPrice
    }).eq("user_id", user.id);
    // Create deposit record
    const { data: deposit, error: depositError } = await supabase.from("lyrics_deposits").insert({
      lyrics_id: lyricsId,
      user_id: user.id,
      method,
      status: "completed",
      content_hash: contentHash,
      timestamp_hash: timestampHash,
      external_id: externalId || depositId,
      certificate_url: certificateUrl,
      author_name: authorName,
      price_rub: depositPrice,
      deposited_at: new Date().toISOString()
    }).select().single();
    if (depositError) {
      console.error("Error creating deposit:", depositError);
      // Refund on error
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user.id);
      throw depositError;
    }
    // Create notification
    await supabase.from("notifications").insert({
      user_id: user.id,
      type: "lyrics_deposited",
      title: "Текст депонирован",
      message: `Ваш текст "${lyrics.title}" успешно депонирован`,
      target_type: "lyrics",
      target_id: lyricsId
    });
    console.log(`Lyrics deposit completed: ${deposit.id}`);
    return new Response(JSON.stringify({
      success: true,
      deposit,
      certificateUrl
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Lyrics deposit error:", error);
    const message = error instanceof Error ? error.message : "Ошибка при депонировании";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9seXJpY3MtZGVwb3NpdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuaW50ZXJmYWNlIERlcG9zaXRSZXF1ZXN0IHtcbiAgbHlyaWNzSWQ6IHN0cmluZztcbiAgbWV0aG9kOiBcImludGVybmFsXCIgfCBcImJsb2NrY2hhaW5cIiB8IFwibnJpc1wiIHwgXCJpcm1hXCI7XG4gIGF1dGhvck5hbWU/OiBzdHJpbmc7XG59XG5cbi8vINCT0LXQvdC10YDQsNGG0LjRjyBTSEEtMjU2INGF0LXRiNCwXG5hc3luYyBmdW5jdGlvbiBnZW5lcmF0ZUhhc2goZGF0YTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc3QgZW5jb2RlciA9IG5ldyBUZXh0RW5jb2RlcigpO1xuICBjb25zdCBkYXRhQnVmZmVyID0gZW5jb2Rlci5lbmNvZGUoZGF0YSk7XG4gIGNvbnN0IGhhc2hCdWZmZXIgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdChcIlNIQS0yNTZcIiwgZGF0YUJ1ZmZlcik7XG4gIGNvbnN0IGhhc2hBcnJheSA9IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoaGFzaEJ1ZmZlcikpO1xuICByZXR1cm4gaGFzaEFycmF5Lm1hcChiID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsIFwiMFwiKSkuam9pbihcIlwiKTtcbn1cblxuLy8gT3BlblRpbWVzdGFtcHMgLSDQsdC10YHQv9C70LDRgtC90LDRjyBibG9ja2NoYWluINGE0LjQutGB0LDRhtC40Y9cbmFzeW5jIGZ1bmN0aW9uIHN1Ym1pdFRvT3BlblRpbWVzdGFtcHMoaGFzaDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFwiaHR0cHM6Ly9hLnBvb2wub3BlbnRpbWVzdGFtcHMub3JnL2RpZ2VzdFwiLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFwiIH0sXG4gICAgICBib2R5OiBoYXNoLFxuICAgIH0pO1xuICAgIFxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIGNvbnN0IGZhbGxiYWNrUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcImh0dHBzOi8vYi5wb29sLm9wZW50aW1lc3RhbXBzLm9yZy9kaWdlc3RcIiwge1xuICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLCBcbiAgICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFwiIH0sXG4gICAgICAgIGJvZHk6IGhhc2gsXG4gICAgICB9KTtcbiAgICAgIFxuICAgICAgaWYgKCFmYWxsYmFja1Jlc3BvbnNlLm9rKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIk9wZW5UaW1lc3RhbXBzIHNlcnZlcnMgdW5hdmFpbGFibGVcIik7XG4gICAgICB9XG4gICAgICByZXR1cm4gYG90c19wZW5kaW5nXyR7RGF0ZS5ub3coKX1gO1xuICAgIH1cbiAgICByZXR1cm4gYG90c18ke0RhdGUubm93KCl9YDtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiT3BlblRpbWVzdGFtcHMgZXJyb3I6XCIsIGVycm9yKTtcbiAgICByZXR1cm4gYG90c19wZW5kaW5nXyR7aGFzaC5zdWJzdHJpbmcoMCwgMTYpfWA7XG4gIH1cbn1cblxuLy8gbidSSVMgQVBJINC40L3RgtC10LPRgNCw0YbQuNGPXG5hc3luYyBmdW5jdGlvbiBzdWJtaXRUb05yaXMoXG4gIGx5cmljczogYW55LFxuICBoYXNoOiBzdHJpbmcsXG4gIGFwaUtleTogc3RyaW5nLFxuICBhcGlVcmw6IHN0cmluZ1xuKTogUHJvbWlzZTx7IGRlcG9zaXRJZDogc3RyaW5nOyBjZXJ0aWZpY2F0ZVVybD86IHN0cmluZyB9PiB7XG4gIGlmICghYXBpS2V5KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiQVBJINC60LvRjtGHIG4nUklTINC90LUg0L3QsNGB0YLRgNC+0LXQvVwiKTtcbiAgfVxuXG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7YXBpVXJsfS9kZXBvc2l0c2AsIHtcbiAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgIGhlYWRlcnM6IHtcbiAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7YXBpS2V5fWAsXG4gICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICB9LFxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgIHR5cGU6IFwibHlyaWNzXCIsXG4gICAgICB0aXRsZTogbHlyaWNzLnRpdGxlLFxuICAgICAgYXV0aG9yOiBseXJpY3MuYXV0aG9yX25hbWUsXG4gICAgICBoYXNoOiBoYXNoLFxuICAgICAgbWV0YWRhdGE6IHtcbiAgICAgICAgY3JlYXRlZF9hdDogbHlyaWNzLmNyZWF0ZWRfYXQsXG4gICAgICAgIGxhbmd1YWdlOiBseXJpY3MubGFuZ3VhZ2UsXG4gICAgICB9LFxuICAgIH0pLFxuICB9KTtcblxuICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgY29uc3QgZXJyb3IgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBuJ1JJUyBBUEkgZXJyb3I6ICR7ZXJyb3J9YCk7XG4gIH1cblxuICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gIHJldHVybiB7XG4gICAgZGVwb3NpdElkOiByZXN1bHQuZGVwb3NpdF9pZCB8fCByZXN1bHQuaWQsXG4gICAgY2VydGlmaWNhdGVVcmw6IHJlc3VsdC5jZXJ0aWZpY2F0ZV91cmwsXG4gIH07XG59XG5cbi8vIElSTUEgQVBJINC40L3RgtC10LPRgNCw0YbQuNGPXG5hc3luYyBmdW5jdGlvbiBzdWJtaXRUb0lybWEoXG4gIGx5cmljczogYW55LFxuICBoYXNoOiBzdHJpbmcsXG4gIGFwaUtleTogc3RyaW5nLFxuICBhcGlVcmw6IHN0cmluZ1xuKTogUHJvbWlzZTx7IGRlcG9zaXRJZDogc3RyaW5nOyBjZXJ0aWZpY2F0ZVVybD86IHN0cmluZyB9PiB7XG4gIGlmICghYXBpS2V5KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiQVBJINC60LvRjtGHIElSTUEg0L3QtSDQvdCw0YHRgtGA0L7QtdC9XCIpO1xuICB9XG5cbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHthcGlVcmx9L3JlZ2lzdGVyYCwge1xuICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgaGVhZGVyczoge1xuICAgICAgXCJYLUFQSS1LZXlcIjogYXBpS2V5LFxuICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgfSxcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICB3b3JrX3R5cGU6IFwibHlyaWNzXCIsXG4gICAgICB0aXRsZTogbHlyaWNzLnRpdGxlLFxuICAgICAgY3JlYXRvcnM6IFt7IHJvbGU6IFwiYXV0aG9yXCIsIG5hbWU6IGx5cmljcy5hdXRob3JfbmFtZSB9XSxcbiAgICAgIGNvbnRlbnRfaGFzaDogaGFzaCxcbiAgICB9KSxcbiAgfSk7XG5cbiAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgIGNvbnN0IGVycm9yID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICAgIHRocm93IG5ldyBFcnJvcihgSVJNQSBBUEkgZXJyb3I6ICR7ZXJyb3J9YCk7XG4gIH1cblxuICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gIHJldHVybiB7XG4gICAgZGVwb3NpdElkOiByZXN1bHQucmVnaXN0cmF0aW9uX2lkIHx8IHJlc3VsdC5pZCxcbiAgICBjZXJ0aWZpY2F0ZVVybDogcmVzdWx0LmNlcnRpZmljYXRlX3VybCxcbiAgfTtcbn1cblxuLy8g0JPQtdC90LXRgNCw0YbQuNGPIEhUTUwg0YHQtdGA0YLQuNGE0LjQutCw0YLQsCDQtNC70Y8g0YLQtdC60YHRgtCwXG5hc3luYyBmdW5jdGlvbiBnZW5lcmF0ZUx5cmljc0NlcnRpZmljYXRlKFxuICBzdXBhYmFzZTogYW55LFxuICBseXJpY3M6IGFueSxcbiAgaGFzaDogc3RyaW5nLFxuICBkZXBvc2l0SWQ6IHN0cmluZyxcbiAgYXV0aG9yTmFtZTogc3RyaW5nXG4pOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBmb3JtYXR0ZWREYXRlID0gbmV3IERhdGUoKS50b0xvY2FsZVN0cmluZygncnUtUlUnLCB7XG4gICAgZGF5OiAnMi1kaWdpdCcsXG4gICAgbW9udGg6ICcyLWRpZ2l0JywgXG4gICAgeWVhcjogJ251bWVyaWMnLFxuICAgIGhvdXI6ICcyLWRpZ2l0JyxcbiAgICBtaW51dGU6ICcyLWRpZ2l0JyxcbiAgICBzZWNvbmQ6ICcyLWRpZ2l0J1xuICB9KTtcblxuICBjb25zdCBodG1sQ29udGVudCA9IGA8IURPQ1RZUEUgaHRtbD5cbjxodG1sIGxhbmc9XCJydVwiPlxuPGhlYWQ+XG4gIDxtZXRhIGNoYXJzZXQ9XCJVVEYtOFwiPlxuICA8bWV0YSBuYW1lPVwidmlld3BvcnRcIiBjb250ZW50PVwid2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEuMFwiPlxuICA8dGl0bGU+0KHQtdGA0YLQuNGE0LjQutCw0YIg0LTQtdC/0L7QvdC40YDQvtCy0LDQvdC40Y8g0YLQtdC60YHRgtCwIC0gJHtseXJpY3MudGl0bGV9PC90aXRsZT5cbiAgPHN0eWxlPlxuICAgIEBtZWRpYSBwcmludCB7XG4gICAgICBib2R5IHsgLXdlYmtpdC1wcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0OyBwcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0OyB9XG4gICAgICAubm8tcHJpbnQgeyBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7IH1cbiAgICAgIEBwYWdlIHsgc2l6ZTogQTQ7IG1hcmdpbjogMTVtbTsgfVxuICAgIH1cbiAgICAqIHsgYm94LXNpemluZzogYm9yZGVyLWJveDsgbWFyZ2luOiAwOyBwYWRkaW5nOiAwOyB9XG4gICAgYm9keSB7IFxuICAgICAgZm9udC1mYW1pbHk6ICdUaW1lcyBOZXcgUm9tYW4nLCAnR2VvcmdpYScsIHNlcmlmOyBcbiAgICAgIHBhZGRpbmc6IDQwcHg7IFxuICAgICAgbWF4LXdpZHRoOiA4MDBweDsgXG4gICAgICBtYXJnaW46IDAgYXV0bzsgXG4gICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgICAgY29sb3I6ICMxYTFhMWE7XG4gICAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIH1cbiAgICAuY2VydGlmaWNhdGUge1xuICAgICAgYm9yZGVyOiAzcHggZG91YmxlICMyYzNlNTA7XG4gICAgICBwYWRkaW5nOiA0MHB4O1xuICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgI2ZlZmVmZSAwJSwgI2Y4ZjlmYSAxMDAlKTtcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB9XG4gICAgLmNlcnRpZmljYXRlOjpiZWZvcmUge1xuICAgICAgY29udGVudDogJyc7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICB0b3A6IDEwcHg7IGxlZnQ6IDEwcHg7IHJpZ2h0OiAxMHB4OyBib3R0b206IDEwcHg7XG4gICAgICBib3JkZXI6IDFweCBzb2xpZCAjYmRjM2M3O1xuICAgICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XG4gICAgfVxuICAgIC5oZWFkZXIgeyBcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjsgXG4gICAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzJjM2U1MDsgXG4gICAgICBwYWRkaW5nLWJvdHRvbTogMjVweDsgXG4gICAgICBtYXJnaW4tYm90dG9tOiAzMHB4OyBcbiAgICB9XG4gICAgLmxhYmVsLW5hbWUgeyBmb250LXNpemU6IDE0cHg7IGNvbG9yOiAjNTU1OyBmb250LXdlaWdodDogNTAwOyBsZXR0ZXItc3BhY2luZzogMXB4OyBtYXJnaW4tYm90dG9tOiA1cHg7IH1cbiAgICAud2Vic2l0ZSB7IGZvbnQtc2l6ZTogMThweDsgY29sb3I6ICMyYzNlNTA7IGZvbnQtd2VpZ2h0OiBib2xkOyBsZXR0ZXItc3BhY2luZzogMnB4OyB9XG4gICAgLnRpdGxlIHsgXG4gICAgICBmb250LXNpemU6IDI4cHg7IGZvbnQtd2VpZ2h0OiBib2xkOyBjb2xvcjogIzFhMWExYTsgXG4gICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlOyBsZXR0ZXItc3BhY2luZzogM3B4OyBtYXJnaW4tdG9wOiAyMHB4O1xuICAgIH1cbiAgICAuc3VidGl0bGUgeyBmb250LXNpemU6IDE2cHg7IGNvbG9yOiAjNjY2OyBtYXJnaW4tdG9wOiAxMHB4OyBmb250LXN0eWxlOiBpdGFsaWM7IH1cbiAgICAuY29udGVudCB7IGRpc3BsYXk6IGdyaWQ7IGdhcDogMThweDsgfVxuICAgIC5zZWN0aW9uIHsgZGlzcGxheTogZ3JpZDsgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxODBweCAxZnI7IGFsaWduLWl0ZW1zOiBzdGFydDsgZ2FwOiAxNXB4OyB9XG4gICAgLmxhYmVsIHsgZm9udC13ZWlnaHQ6IGJvbGQ7IGNvbG9yOiAjMmMzZTUwOyBmb250LXNpemU6IDE0cHg7IHBhZGRpbmctdG9wOiAxMHB4OyB9XG4gICAgLnZhbHVlIHsgXG4gICAgICBwYWRkaW5nOiAxMnB4IDE1cHg7IGJhY2tncm91bmQ6ICNmZmY7IGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XG4gICAgICBib3JkZXItcmFkaXVzOiA0cHg7IGZvbnQtc2l6ZTogMTVweDsgYm94LXNoYWRvdzogaW5zZXQgMCAxcHggM3B4IHJnYmEoMCwwLDAsMC4wNSk7XG4gICAgfVxuICAgIC5oYXNoIHsgZm9udC1mYW1pbHk6ICdDb3VyaWVyIE5ldycsIG1vbm9zcGFjZTsgZm9udC1zaXplOiAxMXB4OyB3b3JkLWJyZWFrOiBicmVhay1hbGw7IGNvbG9yOiAjNTU1OyB9XG4gICAgLnNlYWwgeyB0ZXh0LWFsaWduOiBjZW50ZXI7IG1hcmdpbjogMzVweCAwIDI1cHg7IH1cbiAgICAuc2VhbC10ZXh0IHsgXG4gICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7IHBhZGRpbmc6IDIwcHggMzVweDsgYm9yZGVyOiA0cHggZG91YmxlICMyYzNlNTA7IFxuICAgICAgYm9yZGVyLXJhZGl1czogNTAlOyBmb250LXNpemU6IDE0cHg7IGZvbnQtd2VpZ2h0OiBib2xkOyBjb2xvcjogIzJjM2U1MDtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjsgbGluZS1oZWlnaHQ6IDEuNDsgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgI2ZmZiAwJSwgI2YwZjBmMCAxMDAlKTtcbiAgICB9XG4gICAgLmZvb3RlciB7IFxuICAgICAgbWFyZ2luLXRvcDogMzBweDsgcGFkZGluZy10b3A6IDIwcHg7IGJvcmRlci10b3A6IDJweCBzb2xpZCAjMmMzZTUwOyBcbiAgICAgIGZvbnQtc2l6ZTogMTJweDsgY29sb3I6ICM2NjY7IHRleHQtYWxpZ246IGNlbnRlcjsgbGluZS1oZWlnaHQ6IDEuODtcbiAgICB9XG4gICAgLmZvb3RlciAucGxhdGZvcm0geyBmb250LXdlaWdodDogYm9sZDsgY29sb3I6ICMyYzNlNTA7IGZvbnQtc2l6ZTogMTRweDsgbWFyZ2luLXRvcDogMTVweDsgfVxuICAgIC5wcmludC1idG4ge1xuICAgICAgZGlzcGxheTogYmxvY2s7IG1hcmdpbjogMjBweCBhdXRvOyBwYWRkaW5nOiAxMnB4IDMwcHg7XG4gICAgICBiYWNrZ3JvdW5kOiAjMmMzZTUwOyBjb2xvcjogI2ZmZjsgYm9yZGVyOiBub25lOyBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICBmb250LXNpemU6IDE2cHg7IGN1cnNvcjogcG9pbnRlcjsgZm9udC1mYW1pbHk6IGluaGVyaXQ7XG4gICAgfVxuICAgIC5wcmludC1idG46aG92ZXIgeyBiYWNrZ3JvdW5kOiAjMWEyNTJmOyB9XG4gIDwvc3R5bGU+XG48L2hlYWQ+XG48Ym9keT5cbiAgPGJ1dHRvbiBjbGFzcz1cInByaW50LWJ0biBuby1wcmludFwiIG9uY2xpY2s9XCJ3aW5kb3cucHJpbnQoKVwiPvCfk4Qg0KHQvtGF0YDQsNC90LjRgtGMINC60LDQuiBQREYgLyDQoNCw0YHQv9C10YfQsNGC0LDRgtGMPC9idXR0b24+XG4gIFxuICA8ZGl2IGNsYXNzPVwiY2VydGlmaWNhdGVcIj5cbiAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibGFiZWwtbmFtZVwiPtCe0J7QniBcItCc0YPQt9GL0LrQsNC70YzQvdGL0Lkg0LvQtdC50LHQuyDQndCe0KLQkC3QpNCV0K9cIjwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cIndlYnNpdGVcIj5haW11emEucnU8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJ0aXRsZVwiPtCh0JXQoNCi0JjQpNCY0JrQkNCiINCU0JXQn9Ce0J3QmNCg0J7QktCQ0J3QmNCvPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwic3VidGl0bGVcIj7Qm9C40YLQtdGA0LDRgtGD0YDQvdC+0LUg0L/RgNC+0LjQt9Cy0LXQtNC10L3QuNC1ICjRgtC10LrRgdGCINC/0LXRgdC90LgpPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgXG4gICAgPGRpdiBjbGFzcz1cImNvbnRlbnRcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbFwiPtCd0LDQt9Cy0LDQvdC40LU6PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ2YWx1ZVwiPiR7bHlyaWNzLnRpdGxlfTwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwic2VjdGlvblwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwibGFiZWxcIj7QkNCy0YLQvtGAINGC0LXQutGB0YLQsDo8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInZhbHVlXCI+JHthdXRob3JOYW1lIHx8IFwi0J3QtSDRg9C60LDQt9Cw0L1cIn08L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+0KbQuNGE0YDQvtCy0L7QuSDQvtGC0L/QtdGH0LDRgtC+0LogKFNIQS0yNTYpOjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwidmFsdWUgaGFzaFwiPiR7aGFzaH08L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+0JjQtNC10L3RgtC40YTQuNC60LDRgtC+0YA6PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ2YWx1ZVwiPiR7ZGVwb3NpdElkfTwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwic2VjdGlvblwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwibGFiZWxcIj7QlNCw0YLQsCDQtNC10L/QvtC90LjRgNC+0LLQsNC90LjRjzo8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInZhbHVlXCI+JHtmb3JtYXR0ZWREYXRlfTwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgXG4gICAgPGRpdiBjbGFzcz1cInNlYWxcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzZWFsLXRleHRcIj7QndCe0KLQkC3QpNCV0K88YnIvPuKckyBWZXJpZmllZDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIFxuICAgIDxkaXYgY2xhc3M9XCJmb290ZXJcIj5cbiAgICAgIDxwPtCU0LDQvdC90YvQuSDRgdC10YDRgtC40YTQuNC60LDRgiDQv9C+0LTRgtCy0LXRgNC20LTQsNC10YIg0YTQsNC60YIg0YHRg9GJ0LXRgdGC0LLQvtCy0LDQvdC40Y8g0YLQtdC60YHRgtCwINC90LAg0YPQutCw0LfQsNC90L3Rg9GOINC00LDRgtGDLjwvcD5cbiAgICAgIDxwPtCm0LjRhNGA0L7QstC+0Lkg0L7RgtC/0LXRh9Cw0YLQvtC6INC/0L7Qt9Cy0L7Qu9GP0LXRgiDQvtC00L3QvtC30L3QsNGH0L3QviDQuNC00LXQvdGC0LjRhNC40YbQuNGA0L7QstCw0YLRjCDQvtGA0LjQs9C40L3QsNC70YzQvdGL0Lkg0YLQtdC60YHRgi48L3A+XG4gICAgICA8cCBjbGFzcz1cInBsYXRmb3JtXCI+0J7QntCeIFwi0JzRg9C30YvQutCw0LvRjNC90YvQuSDQu9C10LnQsdC7INCd0J7QotCQLdCk0JXQr1wiIOKAoiBhaW11emEucnU8L3A+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuPC9ib2R5PlxuPC9odG1sPmA7XG5cbiAgY29uc3QgZmlsZU5hbWUgPSBgbHlyaWNzX2NlcnRpZmljYXRlXyR7ZGVwb3NpdElkfS5odG1sYDtcbiAgY29uc3QgaHRtbEJ5dGVzID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKGh0bWxDb250ZW50KTtcbiAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtodG1sQnl0ZXNdLCB7IHR5cGU6IFwidGV4dC9odG1sO2NoYXJzZXQ9dXRmLThcIiB9KTtcbiAgXG4gIGNvbnN0IHsgZXJyb3I6IHVwbG9hZEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5zdG9yYWdlXG4gICAgLmZyb20oXCJjZXJ0aWZpY2F0ZXNcIilcbiAgICAudXBsb2FkKGZpbGVOYW1lLCBibG9iLCB7XG4gICAgICBjb250ZW50VHlwZTogXCJ0ZXh0L2h0bWw7Y2hhcnNldD11dGYtOFwiLFxuICAgICAgY2FjaGVDb250cm9sOiBcIjM2MDBcIixcbiAgICAgIHVwc2VydDogdHJ1ZSxcbiAgICB9KTtcblxuICBpZiAodXBsb2FkRXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBsb2FkaW5nIGNlcnRpZmljYXRlOlwiLCB1cGxvYWRFcnJvcik7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDRgdC+0YXRgNCw0L3QuNGC0Ywg0YHQtdGA0YLQuNGE0LjQutCw0YJcIik7XG4gIH1cblxuICBjb25zdCB7IGRhdGE6IHVybERhdGEgfSA9IHN1cGFiYXNlLnN0b3JhZ2VcbiAgICAuZnJvbShcImNlcnRpZmljYXRlc1wiKVxuICAgIC5nZXRQdWJsaWNVcmwoZmlsZU5hbWUpO1xuXG4gIHJldHVybiB1cmxEYXRhLnB1YmxpY1VybDtcbn1cblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIC8vIEdldCB1c2VyIGZyb20gYXV0aCBoZWFkZXJcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiYXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0KLRgNC10LHRg9C10YLRgdGPINCw0LLRgtC+0YDQuNC30LDRhtC40Y9cIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHRva2VuID0gYXV0aEhlYWRlci5yZXBsYWNlKFwiQmVhcmVyIFwiLCBcIlwiKTtcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9LCBlcnJvcjogYXV0aEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIodG9rZW4pO1xuICAgIFxuICAgIGlmIChhdXRoRXJyb3IgfHwgIXVzZXIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0J3QtdCy0LXRgNC90YvQuSDRgtC+0LrQtdC9INCw0LLRgtC+0YDQuNC30LDRhtC40LhcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHsgbHlyaWNzSWQsIG1ldGhvZCwgYXV0aG9yTmFtZSB9ID0gYXdhaXQgcmVxLmpzb24oKSBhcyBEZXBvc2l0UmVxdWVzdDtcbiAgICBjb25zb2xlLmxvZyhgUHJvY2Vzc2luZyBseXJpY3MgZGVwb3NpdDogJHtseXJpY3NJZH0sIG1ldGhvZDogJHttZXRob2R9YCk7XG5cbiAgICAvLyBHZXQgbHlyaWNzIGRhdGFcbiAgICBjb25zdCB7IGRhdGE6IGx5cmljcywgZXJyb3I6IGx5cmljc0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJseXJpY3NfaXRlbXNcIilcbiAgICAgIC5zZWxlY3QoXCIqXCIpXG4gICAgICAuZXEoXCJpZFwiLCBseXJpY3NJZClcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmIChseXJpY3NFcnJvciB8fCAhbHlyaWNzKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCi0LXQutGB0YIg0L3QtSDQvdCw0LnQtNC10L0g0LjQu9C4INC90LXRgiDQtNC+0YHRgtGD0L/QsFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDA0LCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgZm9yIGV4aXN0aW5nIGRlcG9zaXRcbiAgICBjb25zdCB7IGRhdGE6IGV4aXN0aW5nRGVwb3NpdCB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwibHlyaWNzX2RlcG9zaXRzXCIpXG4gICAgICAuc2VsZWN0KFwiaWQsIHN0YXR1c1wiKVxuICAgICAgLmVxKFwibHlyaWNzX2lkXCIsIGx5cmljc0lkKVxuICAgICAgLmVxKFwic3RhdHVzXCIsIFwiY29tcGxldGVkXCIpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoZXhpc3RpbmdEZXBvc2l0KSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCi0LXQutGB0YIg0YPQttC1INC00LXQv9C+0L3QuNGA0L7QstCw0L1cIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIEdldCBkZXBvc2l0IHByaWNlXG4gICAgY29uc3QgeyBkYXRhOiBwcmljZVNldHRpbmcgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImFwcF9zZXR0aW5nc1wiKVxuICAgICAgLnNlbGVjdChcInZhbHVlXCIpXG4gICAgICAuZXEoXCJrZXlcIiwgXCJseXJpY3NfZGVwb3NpdF9wcmljZVwiKVxuICAgICAgLnNpbmdsZSgpO1xuICAgIFxuICAgIGNvbnN0IGRlcG9zaXRQcmljZSA9IHBhcnNlSW50KHByaWNlU2V0dGluZz8udmFsdWUgfHwgXCI1MFwiLCAxMCk7XG5cbiAgICAvLyBDaGVjayB1c2VyIGJhbGFuY2VcbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAuc2VsZWN0KFwiYmFsYW5jZVwiKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKCFwcm9maWxlIHx8IChwcm9maWxlLmJhbGFuY2UgfHwgMCkgPCBkZXBvc2l0UHJpY2UpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGDQndC10LTQvtGB0YLQsNGC0L7Rh9C90L4g0YHRgNC10LTRgdGC0LIuINCi0YDQtdCx0YPQtdGC0YHRjzogJHtkZXBvc2l0UHJpY2V9IOKCvWAgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBHZW5lcmF0ZSBoYXNoIGZyb20gbHlyaWNzIGNvbnRlbnRcbiAgICBjb25zdCBjb250ZW50SGFzaCA9IGF3YWl0IGdlbmVyYXRlSGFzaChseXJpY3MuY29udGVudCArIGx5cmljcy50aXRsZSArIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgY29uc3QgdGltZXN0YW1wSGFzaCA9IGF3YWl0IGdlbmVyYXRlSGFzaChjb250ZW50SGFzaCArIERhdGUubm93KCkudG9TdHJpbmcoKSk7XG5cbiAgICBsZXQgZXh0ZXJuYWxJZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gICAgbGV0IGNlcnRpZmljYXRlVXJsOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuICAgIC8vIFByb2Nlc3MgYmFzZWQgb24gbWV0aG9kXG4gICAgaWYgKG1ldGhvZCA9PT0gXCJibG9ja2NoYWluXCIpIHtcbiAgICAgIGV4dGVybmFsSWQgPSBhd2FpdCBzdWJtaXRUb09wZW5UaW1lc3RhbXBzKGNvbnRlbnRIYXNoKTtcbiAgICB9IGVsc2UgaWYgKG1ldGhvZCA9PT0gXCJucmlzXCIpIHtcbiAgICAgIGNvbnN0IG5yaXNBcGlLZXkgPSBEZW5vLmVudi5nZXQoXCJOUklTX0FQSV9LRVlcIik7XG4gICAgICBjb25zdCBucmlzQXBpVXJsID0gRGVuby5lbnYuZ2V0KFwiTlJJU19BUElfVVJMXCIpIHx8IFwiaHR0cHM6Ly9hcGkubnJpcy5ydVwiO1xuICAgICAgXG4gICAgICBpZiAoIW5yaXNBcGlLZXkpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCh0LXRgNCy0LjRgSBuJ1JJUyDQstGA0LXQvNC10L3QvdC+INC90LXQtNC+0YHRgtGD0L/QtdC9XCIgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDUwMywgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHN1Ym1pdFRvTnJpcyhcbiAgICAgICAgeyAuLi5seXJpY3MsIGF1dGhvcl9uYW1lOiBhdXRob3JOYW1lIH0sXG4gICAgICAgIGNvbnRlbnRIYXNoLFxuICAgICAgICBucmlzQXBpS2V5LFxuICAgICAgICBucmlzQXBpVXJsXG4gICAgICApO1xuICAgICAgZXh0ZXJuYWxJZCA9IHJlc3VsdC5kZXBvc2l0SWQ7XG4gICAgICBjZXJ0aWZpY2F0ZVVybCA9IHJlc3VsdC5jZXJ0aWZpY2F0ZVVybCB8fCBudWxsO1xuICAgIH0gZWxzZSBpZiAobWV0aG9kID09PSBcImlybWFcIikge1xuICAgICAgY29uc3QgaXJtYUFwaUtleSA9IERlbm8uZW52LmdldChcIklSTUFfQVBJX0tFWVwiKTtcbiAgICAgIGNvbnN0IGlybWFBcGlVcmwgPSBEZW5vLmVudi5nZXQoXCJJUk1BX0FQSV9VUkxcIikgfHwgXCJodHRwczovL2FwaS5pcm1hLnJ1XCI7XG4gICAgICBcbiAgICAgIGlmICghaXJtYUFwaUtleSkge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0KHQtdGA0LLQuNGBIElSTUEg0LLRgNC10LzQtdC90L3QviDQvdC10LTQvtGB0YLRg9C/0LXQvVwiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA1MDMsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzdWJtaXRUb0lybWEoXG4gICAgICAgIHsgLi4ubHlyaWNzLCBhdXRob3JfbmFtZTogYXV0aG9yTmFtZSB9LFxuICAgICAgICBjb250ZW50SGFzaCxcbiAgICAgICAgaXJtYUFwaUtleSxcbiAgICAgICAgaXJtYUFwaVVybFxuICAgICAgKTtcbiAgICAgIGV4dGVybmFsSWQgPSByZXN1bHQuZGVwb3NpdElkO1xuICAgICAgY2VydGlmaWNhdGVVcmwgPSByZXN1bHQuY2VydGlmaWNhdGVVcmwgfHwgbnVsbDtcbiAgICB9XG5cbiAgICAvLyBHZW5lcmF0ZSBpbnRlcm5hbCBkZXBvc2l0IElEXG4gICAgY29uc3QgZGVwb3NpdElkID0gYExZUi0ke0RhdGUubm93KCl9LSR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyKDIsIDkpLnRvVXBwZXJDYXNlKCl9YDtcbiAgICBcbiAgICAvLyBBbHdheXMgZ2VuZXJhdGUgUERGIGNlcnRpZmljYXRlIGZvciBpbnRlcm5hbFxuICAgIGlmIChtZXRob2QgPT09IFwiaW50ZXJuYWxcIiB8fCAhY2VydGlmaWNhdGVVcmwpIHtcbiAgICAgIGNlcnRpZmljYXRlVXJsID0gYXdhaXQgZ2VuZXJhdGVMeXJpY3NDZXJ0aWZpY2F0ZShcbiAgICAgICAgc3VwYWJhc2UsXG4gICAgICAgIGx5cmljcyxcbiAgICAgICAgY29udGVudEhhc2gsXG4gICAgICAgIGRlcG9zaXRJZCxcbiAgICAgICAgYXV0aG9yTmFtZSB8fCBcIlwiXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIERlZHVjdCBiYWxhbmNlXG4gICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiAocHJvZmlsZS5iYWxhbmNlIHx8IDApIC0gZGVwb3NpdFByaWNlIH0pXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpO1xuXG4gICAgLy8gQ3JlYXRlIGRlcG9zaXQgcmVjb3JkXG4gICAgY29uc3QgeyBkYXRhOiBkZXBvc2l0LCBlcnJvcjogZGVwb3NpdEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJseXJpY3NfZGVwb3NpdHNcIilcbiAgICAgIC5pbnNlcnQoe1xuICAgICAgICBseXJpY3NfaWQ6IGx5cmljc0lkLFxuICAgICAgICB1c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgICBtZXRob2QsXG4gICAgICAgIHN0YXR1czogXCJjb21wbGV0ZWRcIixcbiAgICAgICAgY29udGVudF9oYXNoOiBjb250ZW50SGFzaCxcbiAgICAgICAgdGltZXN0YW1wX2hhc2g6IHRpbWVzdGFtcEhhc2gsXG4gICAgICAgIGV4dGVybmFsX2lkOiBleHRlcm5hbElkIHx8IGRlcG9zaXRJZCxcbiAgICAgICAgY2VydGlmaWNhdGVfdXJsOiBjZXJ0aWZpY2F0ZVVybCxcbiAgICAgICAgYXV0aG9yX25hbWU6IGF1dGhvck5hbWUsXG4gICAgICAgIHByaWNlX3J1YjogZGVwb3NpdFByaWNlLFxuICAgICAgICBkZXBvc2l0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIH0pXG4gICAgICAuc2VsZWN0KClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmIChkZXBvc2l0RXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjcmVhdGluZyBkZXBvc2l0OlwiLCBkZXBvc2l0RXJyb3IpO1xuICAgICAgLy8gUmVmdW5kIG9uIGVycm9yXG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBwcm9maWxlLmJhbGFuY2UgfSlcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcbiAgICAgIHRocm93IGRlcG9zaXRFcnJvcjtcbiAgICB9XG5cbiAgICAvLyBDcmVhdGUgbm90aWZpY2F0aW9uXG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcIm5vdGlmaWNhdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgIHVzZXJfaWQ6IHVzZXIuaWQsXG4gICAgICB0eXBlOiBcImx5cmljc19kZXBvc2l0ZWRcIixcbiAgICAgIHRpdGxlOiBcItCi0LXQutGB0YIg0LTQtdC/0L7QvdC40YDQvtCy0LDQvVwiLFxuICAgICAgbWVzc2FnZTogYNCS0LDRiCDRgtC10LrRgdGCIFwiJHtseXJpY3MudGl0bGV9XCIg0YPRgdC/0LXRiNC90L4g0LTQtdC/0L7QvdC40YDQvtCy0LDQvWAsXG4gICAgICB0YXJnZXRfdHlwZTogXCJseXJpY3NcIixcbiAgICAgIHRhcmdldF9pZDogbHlyaWNzSWQsXG4gICAgfSk7XG5cbiAgICBjb25zb2xlLmxvZyhgTHlyaWNzIGRlcG9zaXQgY29tcGxldGVkOiAke2RlcG9zaXQuaWR9YCk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIGRlcG9zaXQsXG4gICAgICAgIGNlcnRpZmljYXRlVXJsIFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICBjb25zb2xlLmVycm9yKFwiTHlyaWNzIGRlcG9zaXQgZXJyb3I6XCIsIGVycm9yKTtcbiAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcItCe0YjQuNCx0LrQsCDQv9GA0Lgg0LTQtdC/0L7QvdC40YDQvtCy0LDQvdC40LhcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBUUEseUJBQXlCO0FBQ3pCLGVBQWUsYUFBYSxJQUFZO0VBQ3RDLE1BQU0sVUFBVSxJQUFJO0VBQ3BCLE1BQU0sYUFBYSxRQUFRLE1BQU0sQ0FBQztFQUNsQyxNQUFNLGFBQWEsTUFBTSxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVztFQUN6RCxNQUFNLFlBQVksTUFBTSxJQUFJLENBQUMsSUFBSSxXQUFXO0VBQzVDLE9BQU8sVUFBVSxHQUFHLENBQUMsQ0FBQSxJQUFLLEVBQUUsUUFBUSxDQUFDLElBQUksUUFBUSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFDbEU7QUFFQSxrREFBa0Q7QUFDbEQsZUFBZSx1QkFBdUIsSUFBWTtFQUNoRCxJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTSw0Q0FBNEM7TUFDdkUsUUFBUTtNQUNSLFNBQVM7UUFBRSxnQkFBZ0I7TUFBb0M7TUFDL0QsTUFBTTtJQUNSO0lBRUEsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLE1BQU0sbUJBQW1CLE1BQU0sTUFBTSw0Q0FBNEM7UUFDL0UsUUFBUTtRQUNSLFNBQVM7VUFBRSxnQkFBZ0I7UUFBb0M7UUFDL0QsTUFBTTtNQUNSO01BRUEsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEVBQUU7UUFDeEIsTUFBTSxJQUFJLE1BQU07TUFDbEI7TUFDQSxPQUFPLENBQUMsWUFBWSxFQUFFLEtBQUssR0FBRyxHQUFHLENBQUM7SUFDcEM7SUFDQSxPQUFPLENBQUMsSUFBSSxFQUFFLEtBQUssR0FBRyxHQUFHLENBQUM7RUFDNUIsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyx5QkFBeUI7SUFDdkMsT0FBTyxDQUFDLFlBQVksRUFBRSxLQUFLLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQztFQUMvQztBQUNGO0FBRUEsdUJBQXVCO0FBQ3ZCLGVBQWUsYUFDYixNQUFXLEVBQ1gsSUFBWSxFQUNaLE1BQWMsRUFDZCxNQUFjO0VBRWQsSUFBSSxDQUFDLFFBQVE7SUFDWCxNQUFNLElBQUksTUFBTTtFQUNsQjtFQUVBLE1BQU0sV0FBVyxNQUFNLE1BQU0sQ0FBQyxFQUFFLE9BQU8sU0FBUyxDQUFDLEVBQUU7SUFDakQsUUFBUTtJQUNSLFNBQVM7TUFDUCxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO01BQ25DLGdCQUFnQjtJQUNsQjtJQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7TUFDbkIsTUFBTTtNQUNOLE9BQU8sT0FBTyxLQUFLO01BQ25CLFFBQVEsT0FBTyxXQUFXO01BQzFCLE1BQU07TUFDTixVQUFVO1FBQ1IsWUFBWSxPQUFPLFVBQVU7UUFDN0IsVUFBVSxPQUFPLFFBQVE7TUFDM0I7SUFDRjtFQUNGO0VBRUEsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO0lBQ2hCLE1BQU0sUUFBUSxNQUFNLFNBQVMsSUFBSTtJQUNqQyxNQUFNLElBQUksTUFBTSxDQUFDLGlCQUFpQixFQUFFLE1BQU0sQ0FBQztFQUM3QztFQUVBLE1BQU0sU0FBUyxNQUFNLFNBQVMsSUFBSTtFQUNsQyxPQUFPO0lBQ0wsV0FBVyxPQUFPLFVBQVUsSUFBSSxPQUFPLEVBQUU7SUFDekMsZ0JBQWdCLE9BQU8sZUFBZTtFQUN4QztBQUNGO0FBRUEsc0JBQXNCO0FBQ3RCLGVBQWUsYUFDYixNQUFXLEVBQ1gsSUFBWSxFQUNaLE1BQWMsRUFDZCxNQUFjO0VBRWQsSUFBSSxDQUFDLFFBQVE7SUFDWCxNQUFNLElBQUksTUFBTTtFQUNsQjtFQUVBLE1BQU0sV0FBVyxNQUFNLE1BQU0sQ0FBQyxFQUFFLE9BQU8sU0FBUyxDQUFDLEVBQUU7SUFDakQsUUFBUTtJQUNSLFNBQVM7TUFDUCxhQUFhO01BQ2IsZ0JBQWdCO0lBQ2xCO0lBQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztNQUNuQixXQUFXO01BQ1gsT0FBTyxPQUFPLEtBQUs7TUFDbkIsVUFBVTtRQUFDO1VBQUUsTUFBTTtVQUFVLE1BQU0sT0FBTyxXQUFXO1FBQUM7T0FBRTtNQUN4RCxjQUFjO0lBQ2hCO0VBQ0Y7RUFFQSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7SUFDaEIsTUFBTSxRQUFRLE1BQU0sU0FBUyxJQUFJO0lBQ2pDLE1BQU0sSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDO0VBQzVDO0VBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0VBQ2xDLE9BQU87SUFDTCxXQUFXLE9BQU8sZUFBZSxJQUFJLE9BQU8sRUFBRTtJQUM5QyxnQkFBZ0IsT0FBTyxlQUFlO0VBQ3hDO0FBQ0Y7QUFFQSx3Q0FBd0M7QUFDeEMsZUFBZSwwQkFDYixRQUFhLEVBQ2IsTUFBVyxFQUNYLElBQVksRUFDWixTQUFpQixFQUNqQixVQUFrQjtFQUVsQixNQUFNLGdCQUFnQixJQUFJLE9BQU8sY0FBYyxDQUFDLFNBQVM7SUFDdkQsS0FBSztJQUNMLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFFBQVE7SUFDUixRQUFRO0VBQ1Y7RUFFQSxNQUFNLGNBQWMsQ0FBQzs7Ozs7MkNBS29CLEVBQUUsT0FBTyxLQUFLLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyQkFvRi9CLEVBQUUsT0FBTyxLQUFLLENBQUM7Ozs7MkJBSWYsRUFBRSxjQUFjLFlBQVk7Ozs7Z0NBSXZCLEVBQUUsS0FBSzs7OzsyQkFJWixFQUFFLFVBQVU7Ozs7MkJBSVosRUFBRSxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7T0FlcEMsQ0FBQztFQUVOLE1BQU0sV0FBVyxDQUFDLG1CQUFtQixFQUFFLFVBQVUsS0FBSyxDQUFDO0VBQ3ZELE1BQU0sWUFBWSxJQUFJLGNBQWMsTUFBTSxDQUFDO0VBQzNDLE1BQU0sT0FBTyxJQUFJLEtBQUs7SUFBQztHQUFVLEVBQUU7SUFBRSxNQUFNO0VBQTBCO0VBRXJFLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FBUyxPQUFPLENBQ2xELElBQUksQ0FBQyxnQkFDTCxNQUFNLENBQUMsVUFBVSxNQUFNO0lBQ3RCLGFBQWE7SUFDYixjQUFjO0lBQ2QsUUFBUTtFQUNWO0VBRUYsSUFBSSxhQUFhO0lBQ2YsUUFBUSxLQUFLLENBQUMsZ0NBQWdDO0lBQzlDLE1BQU0sSUFBSSxNQUFNO0VBQ2xCO0VBRUEsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsU0FBUyxPQUFPLENBQ3ZDLElBQUksQ0FBQyxnQkFDTCxZQUFZLENBQUM7RUFFaEIsT0FBTyxRQUFRLFNBQVM7QUFDMUI7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLDRCQUE0QjtJQUM1QixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZO01BQ2YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQXdCLElBQ2hEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sUUFBUSxXQUFXLE9BQU8sQ0FBQyxXQUFXO0lBQzVDLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLFNBQVMsSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUV6RSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE2QixJQUNyRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUN2RCxRQUFRLEdBQUcsQ0FBQyxDQUFDLDJCQUEyQixFQUFFLFNBQVMsVUFBVSxFQUFFLE9BQU8sQ0FBQztJQUV2RSxrQkFBa0I7SUFDbEIsTUFBTSxFQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUNoRCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDLEtBQ1AsRUFBRSxDQUFDLE1BQU0sVUFDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtJQUVULElBQUksZUFBZSxDQUFDLFFBQVE7TUFDMUIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWtDLElBQzFEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLDZCQUE2QjtJQUM3QixNQUFNLEVBQUUsTUFBTSxlQUFlLEVBQUUsR0FBRyxNQUFNLFNBQ3JDLElBQUksQ0FBQyxtQkFDTCxNQUFNLENBQUMsY0FDUCxFQUFFLENBQUMsYUFBYSxVQUNoQixFQUFFLENBQUMsVUFBVSxhQUNiLE1BQU07SUFFVCxJQUFJLGlCQUFpQjtNQUNuQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBd0IsSUFDaEQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsb0JBQW9CO0lBQ3BCLE1BQU0sRUFBRSxNQUFNLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyxTQUNQLEVBQUUsQ0FBQyxPQUFPLHdCQUNWLE1BQU07SUFFVCxNQUFNLGVBQWUsU0FBUyxjQUFjLFNBQVMsTUFBTTtJQUUzRCxxQkFBcUI7SUFDckIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxTQUM3QixJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtJQUVULElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxPQUFPLElBQUksQ0FBQyxJQUFJLGNBQWM7TUFDckQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPLENBQUMsaUNBQWlDLEVBQUUsYUFBYSxFQUFFLENBQUM7TUFBQyxJQUM3RTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxvQ0FBb0M7SUFDcEMsTUFBTSxjQUFjLE1BQU0sYUFBYSxPQUFPLE9BQU8sR0FBRyxPQUFPLEtBQUssR0FBRyxJQUFJLE9BQU8sV0FBVztJQUM3RixNQUFNLGdCQUFnQixNQUFNLGFBQWEsY0FBYyxLQUFLLEdBQUcsR0FBRyxRQUFRO0lBRTFFLElBQUksYUFBNEI7SUFDaEMsSUFBSSxpQkFBZ0M7SUFFcEMsMEJBQTBCO0lBQzFCLElBQUksV0FBVyxjQUFjO01BQzNCLGFBQWEsTUFBTSx1QkFBdUI7SUFDNUMsT0FBTyxJQUFJLFdBQVcsUUFBUTtNQUM1QixNQUFNLGFBQWEsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO01BQ2hDLE1BQU0sYUFBYSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CO01BRW5ELElBQUksQ0FBQyxZQUFZO1FBQ2YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQW1DLElBQzNEO1VBQUUsUUFBUTtVQUFLLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUVuRjtNQUVBLE1BQU0sU0FBUyxNQUFNLGFBQ25CO1FBQUUsR0FBRyxNQUFNO1FBQUUsYUFBYTtNQUFXLEdBQ3JDLGFBQ0EsWUFDQTtNQUVGLGFBQWEsT0FBTyxTQUFTO01BQzdCLGlCQUFpQixPQUFPLGNBQWMsSUFBSTtJQUM1QyxPQUFPLElBQUksV0FBVyxRQUFRO01BQzVCLE1BQU0sYUFBYSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7TUFDaEMsTUFBTSxhQUFhLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUI7TUFFbkQsSUFBSSxDQUFDLFlBQVk7UUFDZixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBa0MsSUFDMUQ7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BRUEsTUFBTSxTQUFTLE1BQU0sYUFDbkI7UUFBRSxHQUFHLE1BQU07UUFBRSxhQUFhO01BQVcsR0FDckMsYUFDQSxZQUNBO01BRUYsYUFBYSxPQUFPLFNBQVM7TUFDN0IsaUJBQWlCLE9BQU8sY0FBYyxJQUFJO0lBQzVDO0lBRUEsK0JBQStCO0lBQy9CLE1BQU0sWUFBWSxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUcsR0FBRyxDQUFDLEVBQUUsS0FBSyxNQUFNLEdBQUcsUUFBUSxDQUFDLElBQUksTUFBTSxDQUFDLEdBQUcsR0FBRyxXQUFXLEdBQUcsQ0FBQztJQUU5RiwrQ0FBK0M7SUFDL0MsSUFBSSxXQUFXLGNBQWMsQ0FBQyxnQkFBZ0I7TUFDNUMsaUJBQWlCLE1BQU0sMEJBQ3JCLFVBQ0EsUUFDQSxhQUNBLFdBQ0EsY0FBYztJQUVsQjtJQUVBLGlCQUFpQjtJQUNqQixNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO01BQUUsU0FBUyxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSTtJQUFhLEdBQ3hELEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRTtJQUV4Qix3QkFBd0I7SUFDeEIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLE9BQU8sWUFBWSxFQUFFLEdBQUcsTUFBTSxTQUNsRCxJQUFJLENBQUMsbUJBQ0wsTUFBTSxDQUFDO01BQ04sV0FBVztNQUNYLFNBQVMsS0FBSyxFQUFFO01BQ2hCO01BQ0EsUUFBUTtNQUNSLGNBQWM7TUFDZCxnQkFBZ0I7TUFDaEIsYUFBYSxjQUFjO01BQzNCLGlCQUFpQjtNQUNqQixhQUFhO01BQ2IsV0FBVztNQUNYLGNBQWMsSUFBSSxPQUFPLFdBQVc7SUFDdEMsR0FDQyxNQUFNLEdBQ04sTUFBTTtJQUVULElBQUksY0FBYztNQUNoQixRQUFRLEtBQUssQ0FBQywyQkFBMkI7TUFDekMsa0JBQWtCO01BQ2xCLE1BQU0sU0FDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7UUFBRSxTQUFTLFFBQVEsT0FBTztNQUFDLEdBQ2xDLEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRTtNQUN4QixNQUFNO0lBQ1I7SUFFQSxzQkFBc0I7SUFDdEIsTUFBTSxTQUFTLElBQUksQ0FBQyxpQkFBaUIsTUFBTSxDQUFDO01BQzFDLFNBQVMsS0FBSyxFQUFFO01BQ2hCLE1BQU07TUFDTixPQUFPO01BQ1AsU0FBUyxDQUFDLFdBQVcsRUFBRSxPQUFPLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztNQUMxRCxhQUFhO01BQ2IsV0FBVztJQUNiO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQywwQkFBMEIsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBRXJELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNUO01BQ0E7SUFDRixJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFnQjtJQUN2QixRQUFRLEtBQUssQ0FBQyx5QkFBeUI7SUFDdkMsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFRLElBQ2hDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // Security: Verify request comes from authenticated user or service role
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
    // Check if called by service role (from other edge functions) or validate user
    const isServiceRole = authHeader === `Bearer ${supabaseServiceKey}`;
    if (!isServiceRole) {
      // Validate user auth
      const userClient = createClient(supabaseUrl, supabaseAnonKey, {
        global: {
          headers: {
            Authorization: authHeader
          }
        }
      });
      const { data: { user }, error: userError } = await userClient.auth.getUser();
      if (userError || !user) {
        return new Response(JSON.stringify({
          error: "Unauthorized"
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
    }
    const { separation_id, type, source_url } = await req.json();
    console.log("Audio separation request:", {
      separation_id,
      type,
      source_url
    });
    if (!separation_id || !type || !source_url) {
      return new Response(JSON.stringify({
        error: "Missing required fields"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Update status to processing
    await supabase.from("audio_separations").update({
      status: "processing"
    }).eq("id", separation_id);
    console.log("Updated separation status to processing");
    // Start background processing using the event loop
    // The function will continue running after the response is sent
    (async ()=>{
      await processAudioSeparation(supabase, separation_id, type, source_url);
    })();
    return new Response(JSON.stringify({
      success: true,
      message: "Processing started"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Audio separation error:", error);
    return new Response(JSON.stringify({
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
async function processAudioSeparation(supabase, separationId, type, sourceUrl) {
  try {
    console.log("Starting audio separation processing:", {
      separationId,
      type
    });
    // Get the SUNO_API_KEY for audio separation
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    if (!SUNO_API_KEY) {
      throw new Error("SUNO_API_KEY not configured");
    }
    // Call the Suno API for audio separation
    // Note: This is a placeholder for the actual Suno vocal-removal/stems API
    // The actual endpoint and request format may vary based on Suno's API documentation
    let endpoint = "";
    let requestBody = {};
    if (type === "vocal") {
      // Vocal separation - separate vocals from instrumentals
      endpoint = "https://apibox.erweima.ai/api/v1/suno/vocal-removal/generate";
      requestBody = {
        audio_url: sourceUrl
      };
    } else {
      // Stem separation - separate into individual instruments
      endpoint = "https://apibox.erweima.ai/api/v1/suno/stem-separation/generate";
      requestBody = {
        audio_url: sourceUrl,
        stems: [
          "drums",
          "bass",
          "guitar",
          "piano",
          "other"
        ]
      };
    }
    console.log("Calling separation API:", endpoint);
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${SUNO_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(requestBody)
    });
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Separation API error:", response.status, errorText);
      throw new Error(`API error: ${response.status}`);
    }
    const result = await response.json();
    console.log("Separation API response:", result);
    // Check if we got a task ID for polling
    if (result.data?.task_id) {
      // Poll for completion
      const completedResult = await pollForCompletion(SUNO_API_KEY, result.data.task_id, type);
      // Update the separation record with results
      await supabase.from("audio_separations").update({
        status: "completed",
        result_urls: completedResult
      }).eq("id", separationId);
      console.log("Separation completed successfully");
    } else if (result.data?.urls || result.urls) {
      // Direct result
      const urls = result.data?.urls || result.urls;
      await supabase.from("audio_separations").update({
        status: "completed",
        result_urls: urls
      }).eq("id", separationId);
      console.log("Separation completed successfully with direct result");
    } else {
      throw new Error("Unexpected API response format");
    }
  } catch (error) {
    console.error("Processing error:", error);
    // Update status to failed
    await supabase.from("audio_separations").update({
      status: "failed",
      error_message: error instanceof Error ? error.message : "Unknown error"
    }).eq("id", separationId);
  }
}
async function pollForCompletion(apiKey, taskId, type, maxAttempts = 60, intervalMs = 5000) {
  const endpoint = type === "vocal" ? `https://apibox.erweima.ai/api/v1/suno/vocal-removal/status/${taskId}` : `https://apibox.erweima.ai/api/v1/suno/stem-separation/status/${taskId}`;
  for(let attempt = 0; attempt < maxAttempts; attempt++){
    console.log(`Polling attempt ${attempt + 1}/${maxAttempts}`);
    const response = await fetch(endpoint, {
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      }
    });
    if (!response.ok) {
      console.error("Poll error:", response.status);
      throw new Error(`Poll error: ${response.status}`);
    }
    const result = await response.json();
    console.log("Poll result:", result);
    if (result.data?.status === "completed" || result.status === "completed") {
      // Return the URLs
      return result.data?.urls || result.urls || {};
    }
    if (result.data?.status === "failed" || result.status === "failed") {
      throw new Error(result.data?.error || result.error || "Processing failed");
    }
    // Wait before next poll
    await new Promise((resolve)=>setTimeout(resolve, intervalMs));
  }
  throw new Error("Timeout waiting for separation to complete");
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9hdWRpby1zZXBhcmF0aW9uLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgLy8gU2VjdXJpdHk6IFZlcmlmeSByZXF1ZXN0IGNvbWVzIGZyb20gYXV0aGVudGljYXRlZCB1c2VyIG9yIHNlcnZpY2Ugcm9sZVxuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZUFub25LZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSE7XG4gICAgXG4gICAgLy8gQ2hlY2sgaWYgY2FsbGVkIGJ5IHNlcnZpY2Ugcm9sZSAoZnJvbSBvdGhlciBlZGdlIGZ1bmN0aW9ucykgb3IgdmFsaWRhdGUgdXNlclxuICAgIGNvbnN0IGlzU2VydmljZVJvbGUgPSBhdXRoSGVhZGVyID09PSBgQmVhcmVyICR7c3VwYWJhc2VTZXJ2aWNlS2V5fWA7XG4gICAgXG4gICAgaWYgKCFpc1NlcnZpY2VSb2xlKSB7XG4gICAgICAvLyBWYWxpZGF0ZSB1c2VyIGF1dGhcbiAgICAgIGNvbnN0IHVzZXJDbGllbnQgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlQW5vbktleSwge1xuICAgICAgICBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfVxuICAgICAgfSk7XG4gICAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9LCBlcnJvcjogdXNlckVycm9yIH0gPSBhd2FpdCB1c2VyQ2xpZW50LmF1dGguZ2V0VXNlcigpO1xuICAgICAgaWYgKHVzZXJFcnJvciB8fCAhdXNlcikge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgeyBzZXBhcmF0aW9uX2lkLCB0eXBlLCBzb3VyY2VfdXJsIH0gPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKFwiQXVkaW8gc2VwYXJhdGlvbiByZXF1ZXN0OlwiLCB7IHNlcGFyYXRpb25faWQsIHR5cGUsIHNvdXJjZV91cmwgfSk7XG5cbiAgICBpZiAoIXNlcGFyYXRpb25faWQgfHwgIXR5cGUgfHwgIXNvdXJjZV91cmwpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiTWlzc2luZyByZXF1aXJlZCBmaWVsZHNcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgLy8gVXBkYXRlIHN0YXR1cyB0byBwcm9jZXNzaW5nXG4gICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiYXVkaW9fc2VwYXJhdGlvbnNcIilcbiAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiIH0pXG4gICAgICAuZXEoXCJpZFwiLCBzZXBhcmF0aW9uX2lkKTtcblxuICAgIGNvbnNvbGUubG9nKFwiVXBkYXRlZCBzZXBhcmF0aW9uIHN0YXR1cyB0byBwcm9jZXNzaW5nXCIpO1xuXG4gICAgLy8gU3RhcnQgYmFja2dyb3VuZCBwcm9jZXNzaW5nIHVzaW5nIHRoZSBldmVudCBsb29wXG4gICAgLy8gVGhlIGZ1bmN0aW9uIHdpbGwgY29udGludWUgcnVubmluZyBhZnRlciB0aGUgcmVzcG9uc2UgaXMgc2VudFxuICAgIChhc3luYyAoKSA9PiB7XG4gICAgICBhd2FpdCBwcm9jZXNzQXVkaW9TZXBhcmF0aW9uKHN1cGFiYXNlLCBzZXBhcmF0aW9uX2lkLCB0eXBlLCBzb3VyY2VfdXJsKTtcbiAgICB9KSgpO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSwgbWVzc2FnZTogXCJQcm9jZXNzaW5nIHN0YXJ0ZWRcIiB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiQXVkaW8gc2VwYXJhdGlvbiBlcnJvcjpcIiwgZXJyb3IpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG5cbmFzeW5jIGZ1bmN0aW9uIHByb2Nlc3NBdWRpb1NlcGFyYXRpb24oXG4gIHN1cGFiYXNlOiBhbnksXG4gIHNlcGFyYXRpb25JZDogc3RyaW5nLFxuICB0eXBlOiBcInZvY2FsXCIgfCBcInN0ZW1zXCIsXG4gIHNvdXJjZVVybDogc3RyaW5nXG4pIHtcbiAgdHJ5IHtcbiAgICBjb25zb2xlLmxvZyhcIlN0YXJ0aW5nIGF1ZGlvIHNlcGFyYXRpb24gcHJvY2Vzc2luZzpcIiwgeyBzZXBhcmF0aW9uSWQsIHR5cGUgfSk7XG5cbiAgICAvLyBHZXQgdGhlIFNVTk9fQVBJX0tFWSBmb3IgYXVkaW8gc2VwYXJhdGlvblxuICAgIGNvbnN0IFNVTk9fQVBJX0tFWSA9IERlbm8uZW52LmdldChcIlNVTk9fQVBJX0tFWVwiKTtcbiAgICBcbiAgICBpZiAoIVNVTk9fQVBJX0tFWSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiU1VOT19BUElfS0VZIG5vdCBjb25maWd1cmVkXCIpO1xuICAgIH1cblxuICAgIC8vIENhbGwgdGhlIFN1bm8gQVBJIGZvciBhdWRpbyBzZXBhcmF0aW9uXG4gICAgLy8gTm90ZTogVGhpcyBpcyBhIHBsYWNlaG9sZGVyIGZvciB0aGUgYWN0dWFsIFN1bm8gdm9jYWwtcmVtb3ZhbC9zdGVtcyBBUElcbiAgICAvLyBUaGUgYWN0dWFsIGVuZHBvaW50IGFuZCByZXF1ZXN0IGZvcm1hdCBtYXkgdmFyeSBiYXNlZCBvbiBTdW5vJ3MgQVBJIGRvY3VtZW50YXRpb25cbiAgICBcbiAgICBsZXQgZW5kcG9pbnQgPSBcIlwiO1xuICAgIGxldCByZXF1ZXN0Qm9keTogYW55ID0ge307XG4gICAgXG4gICAgaWYgKHR5cGUgPT09IFwidm9jYWxcIikge1xuICAgICAgLy8gVm9jYWwgc2VwYXJhdGlvbiAtIHNlcGFyYXRlIHZvY2FscyBmcm9tIGluc3RydW1lbnRhbHNcbiAgICAgIGVuZHBvaW50ID0gXCJodHRwczovL2FwaWJveC5lcndlaW1hLmFpL2FwaS92MS9zdW5vL3ZvY2FsLXJlbW92YWwvZ2VuZXJhdGVcIjtcbiAgICAgIHJlcXVlc3RCb2R5ID0ge1xuICAgICAgICBhdWRpb191cmw6IHNvdXJjZVVybCxcbiAgICAgIH07XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFN0ZW0gc2VwYXJhdGlvbiAtIHNlcGFyYXRlIGludG8gaW5kaXZpZHVhbCBpbnN0cnVtZW50c1xuICAgICAgZW5kcG9pbnQgPSBcImh0dHBzOi8vYXBpYm94LmVyd2VpbWEuYWkvYXBpL3YxL3N1bm8vc3RlbS1zZXBhcmF0aW9uL2dlbmVyYXRlXCI7XG4gICAgICByZXF1ZXN0Qm9keSA9IHtcbiAgICAgICAgYXVkaW9fdXJsOiBzb3VyY2VVcmwsXG4gICAgICAgIHN0ZW1zOiBbXCJkcnVtc1wiLCBcImJhc3NcIiwgXCJndWl0YXJcIiwgXCJwaWFub1wiLCBcIm90aGVyXCJdLFxuICAgICAgfTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhcIkNhbGxpbmcgc2VwYXJhdGlvbiBBUEk6XCIsIGVuZHBvaW50KTtcblxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goZW5kcG9pbnQsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlcXVlc3RCb2R5KSxcbiAgICB9KTtcblxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIGNvbnN0IGVycm9yVGV4dCA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJTZXBhcmF0aW9uIEFQSSBlcnJvcjpcIiwgcmVzcG9uc2Uuc3RhdHVzLCBlcnJvclRleHQpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBBUEkgZXJyb3I6ICR7cmVzcG9uc2Uuc3RhdHVzfWApO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhcIlNlcGFyYXRpb24gQVBJIHJlc3BvbnNlOlwiLCByZXN1bHQpO1xuXG4gICAgLy8gQ2hlY2sgaWYgd2UgZ290IGEgdGFzayBJRCBmb3IgcG9sbGluZ1xuICAgIGlmIChyZXN1bHQuZGF0YT8udGFza19pZCkge1xuICAgICAgLy8gUG9sbCBmb3IgY29tcGxldGlvblxuICAgICAgY29uc3QgY29tcGxldGVkUmVzdWx0ID0gYXdhaXQgcG9sbEZvckNvbXBsZXRpb24oU1VOT19BUElfS0VZLCByZXN1bHQuZGF0YS50YXNrX2lkLCB0eXBlKTtcbiAgICAgIFxuICAgICAgLy8gVXBkYXRlIHRoZSBzZXBhcmF0aW9uIHJlY29yZCB3aXRoIHJlc3VsdHNcbiAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwiYXVkaW9fc2VwYXJhdGlvbnNcIilcbiAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgIHJlc3VsdF91cmxzOiBjb21wbGV0ZWRSZXN1bHQsXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHNlcGFyYXRpb25JZCk7XG4gICAgICAgIFxuICAgICAgY29uc29sZS5sb2coXCJTZXBhcmF0aW9uIGNvbXBsZXRlZCBzdWNjZXNzZnVsbHlcIik7XG4gICAgfSBlbHNlIGlmIChyZXN1bHQuZGF0YT8udXJscyB8fCByZXN1bHQudXJscykge1xuICAgICAgLy8gRGlyZWN0IHJlc3VsdFxuICAgICAgY29uc3QgdXJscyA9IHJlc3VsdC5kYXRhPy51cmxzIHx8IHJlc3VsdC51cmxzO1xuICAgICAgXG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcImF1ZGlvX3NlcGFyYXRpb25zXCIpXG4gICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgIHN0YXR1czogXCJjb21wbGV0ZWRcIixcbiAgICAgICAgICByZXN1bHRfdXJsczogdXJscyxcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgc2VwYXJhdGlvbklkKTtcbiAgICAgICAgXG4gICAgICBjb25zb2xlLmxvZyhcIlNlcGFyYXRpb24gY29tcGxldGVkIHN1Y2Nlc3NmdWxseSB3aXRoIGRpcmVjdCByZXN1bHRcIik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlVuZXhwZWN0ZWQgQVBJIHJlc3BvbnNlIGZvcm1hdFwiKTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIlByb2Nlc3NpbmcgZXJyb3I6XCIsIGVycm9yKTtcbiAgICBcbiAgICAvLyBVcGRhdGUgc3RhdHVzIHRvIGZhaWxlZFxuICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImF1ZGlvX3NlcGFyYXRpb25zXCIpXG4gICAgICAudXBkYXRlKHtcbiAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLFxuICAgICAgICBlcnJvcl9tZXNzYWdlOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiLFxuICAgICAgfSlcbiAgICAgIC5lcShcImlkXCIsIHNlcGFyYXRpb25JZCk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gcG9sbEZvckNvbXBsZXRpb24oXG4gIGFwaUtleTogc3RyaW5nLFxuICB0YXNrSWQ6IHN0cmluZyxcbiAgdHlwZTogXCJ2b2NhbFwiIHwgXCJzdGVtc1wiLFxuICBtYXhBdHRlbXB0cyA9IDYwLFxuICBpbnRlcnZhbE1zID0gNTAwMFxuKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+PiB7XG4gIGNvbnN0IGVuZHBvaW50ID0gdHlwZSA9PT0gXCJ2b2NhbFwiXG4gICAgPyBgaHR0cHM6Ly9hcGlib3guZXJ3ZWltYS5haS9hcGkvdjEvc3Vuby92b2NhbC1yZW1vdmFsL3N0YXR1cy8ke3Rhc2tJZH1gXG4gICAgOiBgaHR0cHM6Ly9hcGlib3guZXJ3ZWltYS5haS9hcGkvdjEvc3Vuby9zdGVtLXNlcGFyYXRpb24vc3RhdHVzLyR7dGFza0lkfWA7XG5cbiAgZm9yIChsZXQgYXR0ZW1wdCA9IDA7IGF0dGVtcHQgPCBtYXhBdHRlbXB0czsgYXR0ZW1wdCsrKSB7XG4gICAgY29uc29sZS5sb2coYFBvbGxpbmcgYXR0ZW1wdCAke2F0dGVtcHQgKyAxfS8ke21heEF0dGVtcHRzfWApO1xuICAgIFxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goZW5kcG9pbnQsIHtcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHthcGlLZXl9YCxcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgY29uc29sZS5lcnJvcihcIlBvbGwgZXJyb3I6XCIsIHJlc3BvbnNlLnN0YXR1cyk7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFBvbGwgZXJyb3I6ICR7cmVzcG9uc2Uuc3RhdHVzfWApO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhcIlBvbGwgcmVzdWx0OlwiLCByZXN1bHQpO1xuXG4gICAgaWYgKHJlc3VsdC5kYXRhPy5zdGF0dXMgPT09IFwiY29tcGxldGVkXCIgfHwgcmVzdWx0LnN0YXR1cyA9PT0gXCJjb21wbGV0ZWRcIikge1xuICAgICAgLy8gUmV0dXJuIHRoZSBVUkxzXG4gICAgICByZXR1cm4gcmVzdWx0LmRhdGE/LnVybHMgfHwgcmVzdWx0LnVybHMgfHwge307XG4gICAgfVxuXG4gICAgaWYgKHJlc3VsdC5kYXRhPy5zdGF0dXMgPT09IFwiZmFpbGVkXCIgfHwgcmVzdWx0LnN0YXR1cyA9PT0gXCJmYWlsZWRcIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHJlc3VsdC5kYXRhPy5lcnJvciB8fCByZXN1bHQuZXJyb3IgfHwgXCJQcm9jZXNzaW5nIGZhaWxlZFwiKTtcbiAgICB9XG5cbiAgICAvLyBXYWl0IGJlZm9yZSBuZXh0IHBvbGxcbiAgICBhd2FpdCBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgaW50ZXJ2YWxNcykpO1xuICB9XG5cbiAgdGhyb3cgbmV3IEVycm9yKFwiVGltZW91dCB3YWl0aW5nIGZvciBzZXBhcmF0aW9uIHRvIGNvbXBsZXRlXCIpO1xufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YseUVBQXlFO0lBQ3pFLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVk7TUFDZixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFFckMsK0VBQStFO0lBQy9FLE1BQU0sZ0JBQWdCLGVBQWUsQ0FBQyxPQUFPLEVBQUUsbUJBQW1CLENBQUM7SUFFbkUsSUFBSSxDQUFDLGVBQWU7TUFDbEIscUJBQXFCO01BQ3JCLE1BQU0sYUFBYSxhQUFhLGFBQWEsaUJBQWlCO1FBQzVELFFBQVE7VUFBRSxTQUFTO1lBQUUsZUFBZTtVQUFXO1FBQUU7TUFDbkQ7TUFDQSxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxXQUFXLElBQUksQ0FBQyxPQUFPO01BQzFFLElBQUksYUFBYSxDQUFDLE1BQU07UUFDdEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQWUsSUFDdkM7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO0lBQ0Y7SUFFQSxNQUFNLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUMxRCxRQUFRLEdBQUcsQ0FBQyw2QkFBNkI7TUFBRTtNQUFlO01BQU07SUFBVztJQUUzRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLFlBQVk7TUFDMUMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTBCLElBQ2xEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0MsOEJBQThCO0lBQzlCLE1BQU0sU0FDSCxJQUFJLENBQUMscUJBQ0wsTUFBTSxDQUFDO01BQUUsUUFBUTtJQUFhLEdBQzlCLEVBQUUsQ0FBQyxNQUFNO0lBRVosUUFBUSxHQUFHLENBQUM7SUFFWixtREFBbUQ7SUFDbkQsZ0VBQWdFO0lBQ2hFLENBQUM7TUFDQyxNQUFNLHVCQUF1QixVQUFVLGVBQWUsTUFBTTtJQUM5RCxDQUFDO0lBRUQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU0sU0FBUztJQUFxQixJQUM5RDtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUV0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLDJCQUEyQjtJQUN6QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU8saUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFBZ0IsSUFDakY7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0Y7QUFFQSxlQUFlLHVCQUNiLFFBQWEsRUFDYixZQUFvQixFQUNwQixJQUF1QixFQUN2QixTQUFpQjtFQUVqQixJQUFJO0lBQ0YsUUFBUSxHQUFHLENBQUMseUNBQXlDO01BQUU7TUFBYztJQUFLO0lBRTFFLDRDQUE0QztJQUM1QyxNQUFNLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBRWxDLElBQUksQ0FBQyxjQUFjO01BQ2pCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEseUNBQXlDO0lBQ3pDLDBFQUEwRTtJQUMxRSxvRkFBb0Y7SUFFcEYsSUFBSSxXQUFXO0lBQ2YsSUFBSSxjQUFtQixDQUFDO0lBRXhCLElBQUksU0FBUyxTQUFTO01BQ3BCLHdEQUF3RDtNQUN4RCxXQUFXO01BQ1gsY0FBYztRQUNaLFdBQVc7TUFDYjtJQUNGLE9BQU87TUFDTCx5REFBeUQ7TUFDekQsV0FBVztNQUNYLGNBQWM7UUFDWixXQUFXO1FBQ1gsT0FBTztVQUFDO1VBQVM7VUFBUTtVQUFVO1VBQVM7U0FBUTtNQUN0RDtJQUNGO0lBRUEsUUFBUSxHQUFHLENBQUMsMkJBQTJCO0lBRXZDLE1BQU0sV0FBVyxNQUFNLE1BQU0sVUFBVTtNQUNyQyxRQUFRO01BQ1IsU0FBUztRQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7UUFDekMsZ0JBQWdCO01BQ2xCO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztJQUN2QjtJQUVBLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRTtNQUNoQixNQUFNLFlBQVksTUFBTSxTQUFTLElBQUk7TUFDckMsUUFBUSxLQUFLLENBQUMseUJBQXlCLFNBQVMsTUFBTSxFQUFFO01BQ3hELE1BQU0sSUFBSSxNQUFNLENBQUMsV0FBVyxFQUFFLFNBQVMsTUFBTSxDQUFDLENBQUM7SUFDakQ7SUFFQSxNQUFNLFNBQVMsTUFBTSxTQUFTLElBQUk7SUFDbEMsUUFBUSxHQUFHLENBQUMsNEJBQTRCO0lBRXhDLHdDQUF3QztJQUN4QyxJQUFJLE9BQU8sSUFBSSxFQUFFLFNBQVM7TUFDeEIsc0JBQXNCO01BQ3RCLE1BQU0sa0JBQWtCLE1BQU0sa0JBQWtCLGNBQWMsT0FBTyxJQUFJLENBQUMsT0FBTyxFQUFFO01BRW5GLDRDQUE0QztNQUM1QyxNQUFNLFNBQ0gsSUFBSSxDQUFDLHFCQUNMLE1BQU0sQ0FBQztRQUNOLFFBQVE7UUFDUixhQUFhO01BQ2YsR0FDQyxFQUFFLENBQUMsTUFBTTtNQUVaLFFBQVEsR0FBRyxDQUFDO0lBQ2QsT0FBTyxJQUFJLE9BQU8sSUFBSSxFQUFFLFFBQVEsT0FBTyxJQUFJLEVBQUU7TUFDM0MsZ0JBQWdCO01BQ2hCLE1BQU0sT0FBTyxPQUFPLElBQUksRUFBRSxRQUFRLE9BQU8sSUFBSTtNQUU3QyxNQUFNLFNBQ0gsSUFBSSxDQUFDLHFCQUNMLE1BQU0sQ0FBQztRQUNOLFFBQVE7UUFDUixhQUFhO01BQ2YsR0FDQyxFQUFFLENBQUMsTUFBTTtNQUVaLFFBQVEsR0FBRyxDQUFDO0lBQ2QsT0FBTztNQUNMLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0VBQ0YsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyxxQkFBcUI7SUFFbkMsMEJBQTBCO0lBQzFCLE1BQU0sU0FDSCxJQUFJLENBQUMscUJBQ0wsTUFBTSxDQUFDO01BQ04sUUFBUTtNQUNSLGVBQWUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDMUQsR0FDQyxFQUFFLENBQUMsTUFBTTtFQUNkO0FBQ0Y7QUFFQSxlQUFlLGtCQUNiLE1BQWMsRUFDZCxNQUFjLEVBQ2QsSUFBdUIsRUFDdkIsY0FBYyxFQUFFLEVBQ2hCLGFBQWEsSUFBSTtFQUVqQixNQUFNLFdBQVcsU0FBUyxVQUN0QixDQUFDLDJEQUEyRCxFQUFFLE9BQU8sQ0FBQyxHQUN0RSxDQUFDLDZEQUE2RCxFQUFFLE9BQU8sQ0FBQztFQUU1RSxJQUFLLElBQUksVUFBVSxHQUFHLFVBQVUsYUFBYSxVQUFXO0lBQ3RELFFBQVEsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLENBQUMsRUFBRSxZQUFZLENBQUM7SUFFM0QsTUFBTSxXQUFXLE1BQU0sTUFBTSxVQUFVO01BQ3JDLFNBQVM7UUFDUCxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO1FBQ25DLGdCQUFnQjtNQUNsQjtJQUNGO0lBRUEsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLFFBQVEsS0FBSyxDQUFDLGVBQWUsU0FBUyxNQUFNO01BQzVDLE1BQU0sSUFBSSxNQUFNLENBQUMsWUFBWSxFQUFFLFNBQVMsTUFBTSxDQUFDLENBQUM7SUFDbEQ7SUFFQSxNQUFNLFNBQVMsTUFBTSxTQUFTLElBQUk7SUFDbEMsUUFBUSxHQUFHLENBQUMsZ0JBQWdCO0lBRTVCLElBQUksT0FBTyxJQUFJLEVBQUUsV0FBVyxlQUFlLE9BQU8sTUFBTSxLQUFLLGFBQWE7TUFDeEUsa0JBQWtCO01BQ2xCLE9BQU8sT0FBTyxJQUFJLEVBQUUsUUFBUSxPQUFPLElBQUksSUFBSSxDQUFDO0lBQzlDO0lBRUEsSUFBSSxPQUFPLElBQUksRUFBRSxXQUFXLFlBQVksT0FBTyxNQUFNLEtBQUssVUFBVTtNQUNsRSxNQUFNLElBQUksTUFBTSxPQUFPLElBQUksRUFBRSxTQUFTLE9BQU8sS0FBSyxJQUFJO0lBQ3hEO0lBRUEsd0JBQXdCO0lBQ3hCLE1BQU0sSUFBSSxRQUFRLENBQUEsVUFBVyxXQUFXLFNBQVM7RUFDbkQ7RUFFQSxNQUFNLElBQUksTUFBTTtBQUNsQiJ9
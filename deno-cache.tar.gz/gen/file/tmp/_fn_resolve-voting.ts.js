const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Get tracks with expired voting
    const { data: expiredTracks, error: fetchError } = await supabase.from("tracks").select("id, title, voting_likes_count, voting_dislikes_count, voting_ends_at, user_id").eq("moderation_status", "voting").lt("voting_ends_at", new Date().toISOString());
    if (fetchError) {
      throw fetchError;
    }
    if (!expiredTracks?.length) {
      return new Response(JSON.stringify({
        message: "No expired voting tracks found",
        processed: 0
      }), {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    console.log(`Processing ${expiredTracks.length} expired voting tracks`);
    // Get voting settings
    const { data: settings } = await supabase.from("settings").select("key, value").in("key", [
      "voting_min_votes",
      "voting_approval_ratio",
      "voting_notify_artist"
    ]);
    const settingsMap = new Map(settings?.map((s)=>[
        s.key,
        s.value
      ]) || []);
    const minVotes = parseInt(settingsMap.get("voting_min_votes") || "10", 10);
    const approvalRatio = parseFloat(settingsMap.get("voting_approval_ratio") || "0.6");
    const notifyArtist = settingsMap.get("voting_notify_artist") !== "false"; // default true
    const results = [];
    for (const track of expiredTracks){
      const totalVotes = (track.voting_likes_count || 0) + (track.voting_dislikes_count || 0);
      let votingResult;
      let newModerationStatus;
      let reason;
      if (totalVotes < minVotes) {
        votingResult = "rejected";
        newModerationStatus = "rejected";
        reason = `Недостаточно голосов: ${totalVotes} из ${minVotes} минимальных`;
      } else {
        const likeRatio = (track.voting_likes_count || 0) / totalVotes;
        if (likeRatio >= approvalRatio) {
          votingResult = "voting_approved";
          newModerationStatus = "pending"; // Back to moderation queue for final label decision
          reason = `Голосование пройдено: ${Math.round(likeRatio * 100)}% положительных голосов. Возвращён на модерацию для финального решения.`;
        } else {
          votingResult = "rejected";
          newModerationStatus = "rejected";
          reason = `Отклонено: ${Math.round(likeRatio * 100)}% положительных (нужно ${Math.round(approvalRatio * 100)}%)`;
        }
      }
      // Update track status
      // CRITICAL: Do NOT auto-publish! Track goes back to moderation queue
      const { error: updateError } = await supabase.from("tracks").update({
        moderation_status: newModerationStatus,
        voting_result: votingResult,
        is_public: false
      }).eq("id", track.id);
      if (updateError) {
        console.error(`Failed to update track ${track.id}:`, updateError);
        continue;
      }
      // Notify artist
      if (notifyArtist && track.user_id) {
        await supabase.from("notifications").insert({
          user_id: track.user_id,
          type: "voting_result",
          title: votingResult === "voting_approved" ? "🎉 Голосование пройдено!" : "Голосование завершено",
          message: votingResult === "voting_approved" ? `Трек "${track.title}" успешно прошёл голосование и отправлен на финальное рассмотрение лейбла.` : `К сожалению, трек "${track.title}" не набрал достаточно голосов. ${reason}`,
          target_type: "track",
          target_id: track.id
        });
      }
      results.push({
        trackId: track.id,
        title: track.title,
        result: votingResult,
        reason
      });
      console.log(`Track "${track.title}" (${track.id}): ${votingResult} -> moderation_status=${newModerationStatus}`);
    }
    return new Response(JSON.stringify({
      success: true,
      processed: results.length,
      results
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('Error in resolve-voting:', error);
    return new Response(JSON.stringify({
      error: error instanceof Error ? error.message : 'Unknown error'
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9yZXNvbHZlLXZvdGluZy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ2F1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlJyxcbn07XG5cbmludGVyZmFjZSBWb3RpbmdUcmFjayB7XG4gIGlkOiBzdHJpbmc7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIHZvdGluZ19saWtlc19jb3VudDogbnVtYmVyO1xuICB2b3RpbmdfZGlzbGlrZXNfY291bnQ6IG51bWJlcjtcbiAgdm90aW5nX2VuZHNfYXQ6IHN0cmluZztcbiAgdXNlcl9pZDogc3RyaW5nO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSAnT1BUSU9OUycpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIC8vIEdldCB0cmFja3Mgd2l0aCBleHBpcmVkIHZvdGluZ1xuICAgIGNvbnN0IHsgZGF0YTogZXhwaXJlZFRyYWNrcywgZXJyb3I6IGZldGNoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLnNlbGVjdChcImlkLCB0aXRsZSwgdm90aW5nX2xpa2VzX2NvdW50LCB2b3RpbmdfZGlzbGlrZXNfY291bnQsIHZvdGluZ19lbmRzX2F0LCB1c2VyX2lkXCIpXG4gICAgICAuZXEoXCJtb2RlcmF0aW9uX3N0YXR1c1wiLCBcInZvdGluZ1wiKVxuICAgICAgLmx0KFwidm90aW5nX2VuZHNfYXRcIiwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcblxuICAgIGlmIChmZXRjaEVycm9yKSB7XG4gICAgICB0aHJvdyBmZXRjaEVycm9yO1xuICAgIH1cblxuICAgIGlmICghZXhwaXJlZFRyYWNrcz8ubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IG1lc3NhZ2U6IFwiTm8gZXhwaXJlZCB2b3RpbmcgdHJhY2tzIGZvdW5kXCIsIHByb2Nlc3NlZDogMCB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgUHJvY2Vzc2luZyAke2V4cGlyZWRUcmFja3MubGVuZ3RofSBleHBpcmVkIHZvdGluZyB0cmFja3NgKTtcblxuICAgIC8vIEdldCB2b3Rpbmcgc2V0dGluZ3NcbiAgICBjb25zdCB7IGRhdGE6IHNldHRpbmdzIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJzZXR0aW5nc1wiKVxuICAgICAgLnNlbGVjdChcImtleSwgdmFsdWVcIilcbiAgICAgIC5pbihcImtleVwiLCBbXCJ2b3RpbmdfbWluX3ZvdGVzXCIsIFwidm90aW5nX2FwcHJvdmFsX3JhdGlvXCIsIFwidm90aW5nX25vdGlmeV9hcnRpc3RcIl0pO1xuXG4gICAgY29uc3Qgc2V0dGluZ3NNYXAgPSBuZXcgTWFwKHNldHRpbmdzPy5tYXAocyA9PiBbcy5rZXksIHMudmFsdWVdKSB8fCBbXSk7XG4gICAgY29uc3QgbWluVm90ZXMgPSBwYXJzZUludChzZXR0aW5nc01hcC5nZXQoXCJ2b3RpbmdfbWluX3ZvdGVzXCIpIHx8IFwiMTBcIiwgMTApO1xuICAgIGNvbnN0IGFwcHJvdmFsUmF0aW8gPSBwYXJzZUZsb2F0KHNldHRpbmdzTWFwLmdldChcInZvdGluZ19hcHByb3ZhbF9yYXRpb1wiKSB8fCBcIjAuNlwiKTtcbiAgICBjb25zdCBub3RpZnlBcnRpc3QgPSBzZXR0aW5nc01hcC5nZXQoXCJ2b3Rpbmdfbm90aWZ5X2FydGlzdFwiKSAhPT0gXCJmYWxzZVwiOyAvLyBkZWZhdWx0IHRydWVcblxuICAgIGNvbnN0IHJlc3VsdHM6IEFycmF5PHsgdHJhY2tJZDogc3RyaW5nOyB0aXRsZTogc3RyaW5nOyByZXN1bHQ6IHN0cmluZzsgcmVhc29uOiBzdHJpbmcgfT4gPSBbXTtcblxuICAgIGZvciAoY29uc3QgdHJhY2sgb2YgZXhwaXJlZFRyYWNrcyBhcyBWb3RpbmdUcmFja1tdKSB7XG4gICAgICBjb25zdCB0b3RhbFZvdGVzID0gKHRyYWNrLnZvdGluZ19saWtlc19jb3VudCB8fCAwKSArICh0cmFjay52b3RpbmdfZGlzbGlrZXNfY291bnQgfHwgMCk7XG4gICAgICBsZXQgdm90aW5nUmVzdWx0OiBcInZvdGluZ19hcHByb3ZlZFwiIHwgXCJyZWplY3RlZFwiO1xuICAgICAgbGV0IG5ld01vZGVyYXRpb25TdGF0dXM6IFwicGVuZGluZ1wiIHwgXCJyZWplY3RlZFwiO1xuICAgICAgbGV0IHJlYXNvbjogc3RyaW5nO1xuXG4gICAgICBpZiAodG90YWxWb3RlcyA8IG1pblZvdGVzKSB7XG4gICAgICAgIHZvdGluZ1Jlc3VsdCA9IFwicmVqZWN0ZWRcIjtcbiAgICAgICAgbmV3TW9kZXJhdGlvblN0YXR1cyA9IFwicmVqZWN0ZWRcIjtcbiAgICAgICAgcmVhc29uID0gYNCd0LXQtNC+0YHRgtCw0YLQvtGH0L3QviDQs9C+0LvQvtGB0L7QsjogJHt0b3RhbFZvdGVzfSDQuNC3ICR7bWluVm90ZXN9INC80LjQvdC40LzQsNC70YzQvdGL0YVgO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgbGlrZVJhdGlvID0gKHRyYWNrLnZvdGluZ19saWtlc19jb3VudCB8fCAwKSAvIHRvdGFsVm90ZXM7XG4gICAgICAgIGlmIChsaWtlUmF0aW8gPj0gYXBwcm92YWxSYXRpbykge1xuICAgICAgICAgIHZvdGluZ1Jlc3VsdCA9IFwidm90aW5nX2FwcHJvdmVkXCI7XG4gICAgICAgICAgbmV3TW9kZXJhdGlvblN0YXR1cyA9IFwicGVuZGluZ1wiOyAvLyBCYWNrIHRvIG1vZGVyYXRpb24gcXVldWUgZm9yIGZpbmFsIGxhYmVsIGRlY2lzaW9uXG4gICAgICAgICAgcmVhc29uID0gYNCT0L7Qu9C+0YHQvtCy0LDQvdC40LUg0L/RgNC+0LnQtNC10L3QvjogJHtNYXRoLnJvdW5kKGxpa2VSYXRpbyAqIDEwMCl9JSDQv9C+0LvQvtC20LjRgtC10LvRjNC90YvRhSDQs9C+0LvQvtGB0L7Qsi4g0JLQvtC30LLRgNCw0YnRkdC9INC90LAg0LzQvtC00LXRgNCw0YbQuNGOINC00LvRjyDRhNC40L3QsNC70YzQvdC+0LPQviDRgNC10YjQtdC90LjRjy5gO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHZvdGluZ1Jlc3VsdCA9IFwicmVqZWN0ZWRcIjtcbiAgICAgICAgICBuZXdNb2RlcmF0aW9uU3RhdHVzID0gXCJyZWplY3RlZFwiO1xuICAgICAgICAgIHJlYXNvbiA9IGDQntGC0LrQu9C+0L3QtdC90L46ICR7TWF0aC5yb3VuZChsaWtlUmF0aW8gKiAxMDApfSUg0L/QvtC70L7QttC40YLQtdC70YzQvdGL0YUgKNC90YPQttC90L4gJHtNYXRoLnJvdW5kKGFwcHJvdmFsUmF0aW8gKiAxMDApfSUpYDtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBVcGRhdGUgdHJhY2sgc3RhdHVzXG4gICAgICAvLyBDUklUSUNBTDogRG8gTk9UIGF1dG8tcHVibGlzaCEgVHJhY2sgZ29lcyBiYWNrIHRvIG1vZGVyYXRpb24gcXVldWVcbiAgICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICBtb2RlcmF0aW9uX3N0YXR1czogbmV3TW9kZXJhdGlvblN0YXR1cyxcbiAgICAgICAgICB2b3RpbmdfcmVzdWx0OiB2b3RpbmdSZXN1bHQsXG4gICAgICAgICAgaXNfcHVibGljOiBmYWxzZSwgLy8gS2VlcCBoaWRkZW4gLSBsYWJlbCBtYWtlcyBmaW5hbCBkZWNpc2lvblxuICAgICAgICB9KVxuICAgICAgICAuZXEoXCJpZFwiLCB0cmFjay5pZCk7XG5cbiAgICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBGYWlsZWQgdG8gdXBkYXRlIHRyYWNrICR7dHJhY2suaWR9OmAsIHVwZGF0ZUVycm9yKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIC8vIE5vdGlmeSBhcnRpc3RcbiAgICAgIGlmIChub3RpZnlBcnRpc3QgJiYgdHJhY2sudXNlcl9pZCkge1xuICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwibm90aWZpY2F0aW9uc1wiKVxuICAgICAgICAgIC5pbnNlcnQoe1xuICAgICAgICAgICAgdXNlcl9pZDogdHJhY2sudXNlcl9pZCxcbiAgICAgICAgICAgIHR5cGU6IFwidm90aW5nX3Jlc3VsdFwiLFxuICAgICAgICAgICAgdGl0bGU6IHZvdGluZ1Jlc3VsdCA9PT0gXCJ2b3RpbmdfYXBwcm92ZWRcIiBcbiAgICAgICAgICAgICAgPyBcIvCfjokg0JPQvtC70L7RgdC+0LLQsNC90LjQtSDQv9GA0L7QudC00LXQvdC+IVwiIFxuICAgICAgICAgICAgICA6IFwi0JPQvtC70L7RgdC+0LLQsNC90LjQtSDQt9Cw0LLQtdGA0YjQtdC90L5cIixcbiAgICAgICAgICAgIG1lc3NhZ2U6IHZvdGluZ1Jlc3VsdCA9PT0gXCJ2b3RpbmdfYXBwcm92ZWRcIlxuICAgICAgICAgICAgICA/IGDQotGA0LXQuiBcIiR7dHJhY2sudGl0bGV9XCIg0YPRgdC/0LXRiNC90L4g0L/RgNC+0YjRkdC7INCz0L7Qu9C+0YHQvtCy0LDQvdC40LUg0Lgg0L7RgtC/0YDQsNCy0LvQtdC9INC90LAg0YTQuNC90LDQu9GM0L3QvtC1INGA0LDRgdGB0LzQvtGC0YDQtdC90LjQtSDQu9C10LnQsdC70LAuYFxuICAgICAgICAgICAgICA6IGDQmiDRgdC+0LbQsNC70LXQvdC40Y4sINGC0YDQtdC6IFwiJHt0cmFjay50aXRsZX1cIiDQvdC1INC90LDQsdGA0LDQuyDQtNC+0YHRgtCw0YLQvtGH0L3QviDQs9C+0LvQvtGB0L7Qsi4gJHtyZWFzb259YCxcbiAgICAgICAgICAgIHRhcmdldF90eXBlOiBcInRyYWNrXCIsXG4gICAgICAgICAgICB0YXJnZXRfaWQ6IHRyYWNrLmlkLFxuICAgICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICByZXN1bHRzLnB1c2goe1xuICAgICAgICB0cmFja0lkOiB0cmFjay5pZCxcbiAgICAgICAgdGl0bGU6IHRyYWNrLnRpdGxlLFxuICAgICAgICByZXN1bHQ6IHZvdGluZ1Jlc3VsdCxcbiAgICAgICAgcmVhc29uLFxuICAgICAgfSk7XG5cbiAgICAgIGNvbnNvbGUubG9nKGBUcmFjayBcIiR7dHJhY2sudGl0bGV9XCIgKCR7dHJhY2suaWR9KTogJHt2b3RpbmdSZXN1bHR9IC0+IG1vZGVyYXRpb25fc3RhdHVzPSR7bmV3TW9kZXJhdGlvblN0YXR1c31gKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIHByb2Nlc3NlZDogcmVzdWx0cy5sZW5ndGgsXG4gICAgICAgIHJlc3VsdHMsXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgaW4gcmVzb2x2ZS12b3Rpbmc6JywgZXJyb3IpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJyB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFXQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLGlDQUFpQztJQUNqQyxNQUFNLEVBQUUsTUFBTSxhQUFhLEVBQUUsT0FBTyxVQUFVLEVBQUUsR0FBRyxNQUFNLFNBQ3RELElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxpRkFDUCxFQUFFLENBQUMscUJBQXFCLFVBQ3hCLEVBQUUsQ0FBQyxrQkFBa0IsSUFBSSxPQUFPLFdBQVc7SUFFOUMsSUFBSSxZQUFZO01BQ2QsTUFBTTtJQUNSO0lBRUEsSUFBSSxDQUFDLGVBQWUsUUFBUTtNQUMxQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLFNBQVM7UUFBa0MsV0FBVztNQUFFLElBQ3pFO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsY0FBYyxNQUFNLENBQUMsc0JBQXNCLENBQUM7SUFFdEUsc0JBQXNCO0lBQ3RCLE1BQU0sRUFBRSxNQUFNLFFBQVEsRUFBRSxHQUFHLE1BQU0sU0FDOUIsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLGNBQ1AsRUFBRSxDQUFDLE9BQU87TUFBQztNQUFvQjtNQUF5QjtLQUF1QjtJQUVsRixNQUFNLGNBQWMsSUFBSSxJQUFJLFVBQVUsSUFBSSxDQUFBLElBQUs7UUFBQyxFQUFFLEdBQUc7UUFBRSxFQUFFLEtBQUs7T0FBQyxLQUFLLEVBQUU7SUFDdEUsTUFBTSxXQUFXLFNBQVMsWUFBWSxHQUFHLENBQUMsdUJBQXVCLE1BQU07SUFDdkUsTUFBTSxnQkFBZ0IsV0FBVyxZQUFZLEdBQUcsQ0FBQyw0QkFBNEI7SUFDN0UsTUFBTSxlQUFlLFlBQVksR0FBRyxDQUFDLDRCQUE0QixTQUFTLGVBQWU7SUFFekYsTUFBTSxVQUFxRixFQUFFO0lBRTdGLEtBQUssTUFBTSxTQUFTLGNBQWdDO01BQ2xELE1BQU0sYUFBYSxDQUFDLE1BQU0sa0JBQWtCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxxQkFBcUIsSUFBSSxDQUFDO01BQ3RGLElBQUk7TUFDSixJQUFJO01BQ0osSUFBSTtNQUVKLElBQUksYUFBYSxVQUFVO1FBQ3pCLGVBQWU7UUFDZixzQkFBc0I7UUFDdEIsU0FBUyxDQUFDLHNCQUFzQixFQUFFLFdBQVcsSUFBSSxFQUFFLFNBQVMsWUFBWSxDQUFDO01BQzNFLE9BQU87UUFDTCxNQUFNLFlBQVksQ0FBQyxNQUFNLGtCQUFrQixJQUFJLENBQUMsSUFBSTtRQUNwRCxJQUFJLGFBQWEsZUFBZTtVQUM5QixlQUFlO1VBQ2Ysc0JBQXNCLFdBQVcsb0RBQW9EO1VBQ3JGLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLEtBQUssQ0FBQyxZQUFZLEtBQUssdUVBQXVFLENBQUM7UUFDeEksT0FBTztVQUNMLGVBQWU7VUFDZixzQkFBc0I7VUFDdEIsU0FBUyxDQUFDLFdBQVcsRUFBRSxLQUFLLEtBQUssQ0FBQyxZQUFZLEtBQUssdUJBQXVCLEVBQUUsS0FBSyxLQUFLLENBQUMsZ0JBQWdCLEtBQUssRUFBRSxDQUFDO1FBQ2pIO01BQ0Y7TUFFQSxzQkFBc0I7TUFDdEIscUVBQXFFO01BQ3JFLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sbUJBQW1CO1FBQ25CLGVBQWU7UUFDZixXQUFXO01BQ2IsR0FDQyxFQUFFLENBQUMsTUFBTSxNQUFNLEVBQUU7TUFFcEIsSUFBSSxhQUFhO1FBQ2YsUUFBUSxLQUFLLENBQUMsQ0FBQyx1QkFBdUIsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRTtRQUNyRDtNQUNGO01BRUEsZ0JBQWdCO01BQ2hCLElBQUksZ0JBQWdCLE1BQU0sT0FBTyxFQUFFO1FBQ2pDLE1BQU0sU0FDSCxJQUFJLENBQUMsaUJBQ0wsTUFBTSxDQUFDO1VBQ04sU0FBUyxNQUFNLE9BQU87VUFDdEIsTUFBTTtVQUNOLE9BQU8saUJBQWlCLG9CQUNwQiw2QkFDQTtVQUNKLFNBQVMsaUJBQWlCLG9CQUN0QixDQUFDLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQywwRUFBMEUsQ0FBQyxHQUNoRyxDQUFDLG1CQUFtQixFQUFFLE1BQU0sS0FBSyxDQUFDLGdDQUFnQyxFQUFFLE9BQU8sQ0FBQztVQUNoRixhQUFhO1VBQ2IsV0FBVyxNQUFNLEVBQUU7UUFDckI7TUFDSjtNQUVBLFFBQVEsSUFBSSxDQUFDO1FBQ1gsU0FBUyxNQUFNLEVBQUU7UUFDakIsT0FBTyxNQUFNLEtBQUs7UUFDbEIsUUFBUTtRQUNSO01BQ0Y7TUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEtBQUssQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLENBQUMsR0FBRyxFQUFFLGFBQWEsc0JBQXNCLEVBQUUsb0JBQW9CLENBQUM7SUFDakg7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxXQUFXLFFBQVEsTUFBTTtNQUN6QjtJQUNGLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFDMUMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQWdCLElBQ2pGO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
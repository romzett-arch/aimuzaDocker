const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Poll for lyrics result
async function pollLyricsResult(taskId, apiKey, maxAttempts = 30) {
  for(let i = 0; i < maxAttempts; i++){
    await new Promise((resolve)=>setTimeout(resolve, 2000)); // Wait 2 seconds between polls
    try {
      const response = await fetch(`https://api.sunoapi.org/api/v1/lyrics/record-info?taskId=${taskId}`, {
        headers: {
          "Authorization": `Bearer ${apiKey}`
        }
      });
      const result = await response.json();
      console.log(`Poll attempt ${i + 1}:`, result);
      if (result.code === 200 && result.data?.status === "SUCCESS") {
        // API returns an array of results in result.data.response.data
        const lyricsData = result.data.response?.data;
        if (lyricsData && lyricsData.length > 0) {
          return {
            text: lyricsData[0].text || "",
            title: lyricsData[0].title || ""
          };
        }
        // Fallback to direct fields if available
        return {
          text: result.data.text || "",
          title: result.data.title || ""
        };
      }
      if (result.data?.status === "FAILED") {
        throw new Error("Lyrics generation failed");
      }
    } catch (error) {
      console.error("Poll error:", error);
    }
  }
  return null;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // CRITICAL: Authenticate user from token
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "Необходима авторизация"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
    // Verify JWT and get authenticated user using getUser (works with modern Supabase)
    const token = authHeader.replace("Bearer ", "");
    const { data: { user: authUser }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !authUser?.id) {
      console.error("Auth error:", authError);
      return new Response(JSON.stringify({
        error: "Неверный токен авторизации"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Use authenticated user ID, NOT from request body
    const user_id = authUser.id;
    const { prompt } = await req.json();
    console.log("Generate lyrics request:", {
      prompt,
      user_id
    });
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    if (!SUNO_API_KEY) {
      throw new Error("SUNO_API_KEY not configured");
    }
    // Get service price
    const { data: service } = await supabase.from("addon_services").select("price_rub").eq("name", "generate_lyrics").maybeSingle();
    const price = service?.price_rub || 4;
    // Check user balance
    const { data: profile } = await supabase.from("profiles").select("balance").eq("user_id", user_id).maybeSingle();
    if (!profile || (profile.balance || 0) < price) {
      throw new Error("Недостаточно средств на балансе");
    }
    // Deduct balance
    const newBalance = (profile.balance || 0) - price;
    await supabase.from("profiles").update({
      balance: newBalance
    }).eq("user_id", user_id);
    // Log transaction
    await supabase.from("balance_transactions").insert({
      user_id: user_id,
      amount: -price,
      balance_after: newBalance,
      type: "lyrics_gen",
      description: "Генерация текста (Suno)"
    });
    // Call Suno API to generate lyrics
    // Note: callBackUrl is required by API, but we'll poll for results
    const callbackUrl = `${Deno.env.get("SUPABASE_URL")}/functions/v1/lyrics-callback`;
    const response = await fetch("https://api.sunoapi.org/api/v1/lyrics", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify({
        prompt,
        callBackUrl: callbackUrl
      })
    });
    const result = await response.json();
    console.log("Suno Lyrics API response:", result);
    if (result.code !== 200) {
      // Refund on failure
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user_id);
      throw new Error(result.msg || "Failed to generate lyrics");
    }
    const taskId = result.data?.taskId;
    if (!taskId) {
      // Refund on failure
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user_id);
      throw new Error("No taskId returned from API");
    }
    // Poll for result
    const lyricsResult = await pollLyricsResult(taskId, SUNO_API_KEY);
    if (!lyricsResult) {
      // Refund on timeout
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user_id);
      throw new Error("Timeout waiting for lyrics generation");
    }
    // Save to history
    await supabase.from("generated_lyrics").insert({
      user_id: user_id,
      prompt: prompt,
      lyrics: lyricsResult.text,
      title: lyricsResult.title || null
    });
    return new Response(JSON.stringify({
      success: true,
      lyrics: lyricsResult.text,
      title: lyricsResult.title,
      message: "Текст успешно сгенерирован"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in generate-lyrics:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9nZW5lcmF0ZS1seXJpY3MudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbi8vIFBvbGwgZm9yIGx5cmljcyByZXN1bHRcbmFzeW5jIGZ1bmN0aW9uIHBvbGxMeXJpY3NSZXN1bHQodGFza0lkOiBzdHJpbmcsIGFwaUtleTogc3RyaW5nLCBtYXhBdHRlbXB0cyA9IDMwKTogUHJvbWlzZTx7IHRleHQ6IHN0cmluZzsgdGl0bGU6IHN0cmluZyB9IHwgbnVsbD4ge1xuICBmb3IgKGxldCBpID0gMDsgaSA8IG1heEF0dGVtcHRzOyBpKyspIHtcbiAgICBhd2FpdCBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgMjAwMCkpOyAvLyBXYWl0IDIgc2Vjb25kcyBiZXR3ZWVuIHBvbGxzXG4gICAgXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYGh0dHBzOi8vYXBpLnN1bm9hcGkub3JnL2FwaS92MS9seXJpY3MvcmVjb3JkLWluZm8/dGFza0lkPSR7dGFza0lkfWAsIHtcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7YXBpS2V5fWAsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICAgIFxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgY29uc29sZS5sb2coYFBvbGwgYXR0ZW1wdCAke2kgKyAxfTpgLCByZXN1bHQpO1xuICAgICAgXG4gICAgICBpZiAocmVzdWx0LmNvZGUgPT09IDIwMCAmJiByZXN1bHQuZGF0YT8uc3RhdHVzID09PSBcIlNVQ0NFU1NcIikge1xuICAgICAgICAvLyBBUEkgcmV0dXJucyBhbiBhcnJheSBvZiByZXN1bHRzIGluIHJlc3VsdC5kYXRhLnJlc3BvbnNlLmRhdGFcbiAgICAgICAgY29uc3QgbHlyaWNzRGF0YSA9IHJlc3VsdC5kYXRhLnJlc3BvbnNlPy5kYXRhO1xuICAgICAgICBpZiAobHlyaWNzRGF0YSAmJiBseXJpY3NEYXRhLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdGV4dDogbHlyaWNzRGF0YVswXS50ZXh0IHx8IFwiXCIsXG4gICAgICAgICAgICB0aXRsZTogbHlyaWNzRGF0YVswXS50aXRsZSB8fCBcIlwiLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgLy8gRmFsbGJhY2sgdG8gZGlyZWN0IGZpZWxkcyBpZiBhdmFpbGFibGVcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB0ZXh0OiByZXN1bHQuZGF0YS50ZXh0IHx8IFwiXCIsXG4gICAgICAgICAgdGl0bGU6IHJlc3VsdC5kYXRhLnRpdGxlIHx8IFwiXCIsXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBcbiAgICAgIGlmIChyZXN1bHQuZGF0YT8uc3RhdHVzID09PSBcIkZBSUxFRFwiKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkx5cmljcyBnZW5lcmF0aW9uIGZhaWxlZFwiKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIlBvbGwgZXJyb3I6XCIsIGVycm9yKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICAvLyBDUklUSUNBTDogQXV0aGVudGljYXRlIHVzZXIgZnJvbSB0b2tlblxuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcj8uc3RhcnRzV2l0aChcIkJlYXJlciBcIikpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0J3QtdC+0LHRhdC+0LTQuNC80LAg0LDQstGC0L7RgNC40LfQsNGG0LjRj1wiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSFcbiAgICApO1xuXG4gICAgLy8gVmVyaWZ5IEpXVCBhbmQgZ2V0IGF1dGhlbnRpY2F0ZWQgdXNlciB1c2luZyBnZXRVc2VyICh3b3JrcyB3aXRoIG1vZGVybiBTdXBhYmFzZSlcbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXI6IGF1dGhVc2VyIH0sIGVycm9yOiBhdXRoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcih0b2tlbik7XG4gICAgXG4gICAgaWYgKGF1dGhFcnJvciB8fCAhYXV0aFVzZXI/LmlkKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiQXV0aCBlcnJvcjpcIiwgYXV0aEVycm9yKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0J3QtdCy0LXRgNC90YvQuSDRgtC+0LrQtdC9INCw0LLRgtC+0YDQuNC30LDRhtC40LhcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIFVzZSBhdXRoZW50aWNhdGVkIHVzZXIgSUQsIE5PVCBmcm9tIHJlcXVlc3QgYm9keVxuICAgIGNvbnN0IHVzZXJfaWQgPSBhdXRoVXNlci5pZDtcbiAgICBcbiAgICBjb25zdCB7IHByb21wdCB9ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBcbiAgICBjb25zb2xlLmxvZyhcIkdlbmVyYXRlIGx5cmljcyByZXF1ZXN0OlwiLCB7IHByb21wdCwgdXNlcl9pZCB9KTtcblxuICAgIGNvbnN0IFNVTk9fQVBJX0tFWSA9IERlbm8uZW52LmdldChcIlNVTk9fQVBJX0tFWVwiKTtcbiAgICBpZiAoIVNVTk9fQVBJX0tFWSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiU1VOT19BUElfS0VZIG5vdCBjb25maWd1cmVkXCIpO1xuICAgIH1cblxuICAgIC8vIEdldCBzZXJ2aWNlIHByaWNlXG4gICAgY29uc3QgeyBkYXRhOiBzZXJ2aWNlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJhZGRvbl9zZXJ2aWNlc1wiKVxuICAgICAgLnNlbGVjdChcInByaWNlX3J1YlwiKVxuICAgICAgLmVxKFwibmFtZVwiLCBcImdlbmVyYXRlX2x5cmljc1wiKVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICBjb25zdCBwcmljZSA9IHNlcnZpY2U/LnByaWNlX3J1YiB8fCA0O1xuXG4gICAgLy8gQ2hlY2sgdXNlciBiYWxhbmNlXG4gICAgY29uc3QgeyBkYXRhOiBwcm9maWxlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgLnNlbGVjdChcImJhbGFuY2VcIilcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcl9pZClcbiAgICAgIC5tYXliZVNpbmdsZSgpO1xuXG4gICAgaWYgKCFwcm9maWxlIHx8IChwcm9maWxlLmJhbGFuY2UgfHwgMCkgPCBwcmljZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtdC00L7RgdGC0LDRgtC+0YfQvdC+INGB0YDQtdC00YHRgtCyINC90LAg0LHQsNC70LDQvdGB0LVcIik7XG4gICAgfVxuXG4gICAgLy8gRGVkdWN0IGJhbGFuY2VcbiAgICBjb25zdCBuZXdCYWxhbmNlID0gKHByb2ZpbGUuYmFsYW5jZSB8fCAwKSAtIHByaWNlO1xuICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAudXBkYXRlKHsgYmFsYW5jZTogbmV3QmFsYW5jZSB9KVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyX2lkKTtcblxuICAgIC8vIExvZyB0cmFuc2FjdGlvblxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oXCJiYWxhbmNlX3RyYW5zYWN0aW9uc1wiKS5pbnNlcnQoe1xuICAgICAgdXNlcl9pZDogdXNlcl9pZCxcbiAgICAgIGFtb3VudDogLXByaWNlLFxuICAgICAgYmFsYW5jZV9hZnRlcjogbmV3QmFsYW5jZSxcbiAgICAgIHR5cGU6IFwibHlyaWNzX2dlblwiLFxuICAgICAgZGVzY3JpcHRpb246IFwi0JPQtdC90LXRgNCw0YbQuNGPINGC0LXQutGB0YLQsCAoU3VubylcIixcbiAgICB9KTtcblxuICAgIC8vIENhbGwgU3VubyBBUEkgdG8gZ2VuZXJhdGUgbHlyaWNzXG4gICAgLy8gTm90ZTogY2FsbEJhY2tVcmwgaXMgcmVxdWlyZWQgYnkgQVBJLCBidXQgd2UnbGwgcG9sbCBmb3IgcmVzdWx0c1xuICAgIGNvbnN0IGNhbGxiYWNrVXJsID0gYCR7RGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpfS9mdW5jdGlvbnMvdjEvbHlyaWNzLWNhbGxiYWNrYDtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFwiaHR0cHM6Ly9hcGkuc3Vub2FwaS5vcmcvYXBpL3YxL2x5cmljc1wiLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHByb21wdCxcbiAgICAgICAgY2FsbEJhY2tVcmw6IGNhbGxiYWNrVXJsLFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJTdW5vIEx5cmljcyBBUEkgcmVzcG9uc2U6XCIsIHJlc3VsdCk7XG5cbiAgICBpZiAocmVzdWx0LmNvZGUgIT09IDIwMCkge1xuICAgICAgLy8gUmVmdW5kIG9uIGZhaWx1cmVcbiAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IHByb2ZpbGUuYmFsYW5jZSB9KVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJfaWQpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHJlc3VsdC5tc2cgfHwgXCJGYWlsZWQgdG8gZ2VuZXJhdGUgbHlyaWNzXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHRhc2tJZCA9IHJlc3VsdC5kYXRhPy50YXNrSWQ7XG4gICAgaWYgKCF0YXNrSWQpIHtcbiAgICAgIC8vIFJlZnVuZCBvbiBmYWlsdXJlXG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBwcm9maWxlLmJhbGFuY2UgfSlcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyX2lkKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vIHRhc2tJZCByZXR1cm5lZCBmcm9tIEFQSVwiKTtcbiAgICB9XG5cbiAgICAvLyBQb2xsIGZvciByZXN1bHRcbiAgICBjb25zdCBseXJpY3NSZXN1bHQgPSBhd2FpdCBwb2xsTHlyaWNzUmVzdWx0KHRhc2tJZCwgU1VOT19BUElfS0VZKTtcbiAgICBcbiAgICBpZiAoIWx5cmljc1Jlc3VsdCkge1xuICAgICAgLy8gUmVmdW5kIG9uIHRpbWVvdXRcbiAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IHByb2ZpbGUuYmFsYW5jZSB9KVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJfaWQpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVGltZW91dCB3YWl0aW5nIGZvciBseXJpY3MgZ2VuZXJhdGlvblwiKTtcbiAgICB9XG5cbiAgICAvLyBTYXZlIHRvIGhpc3RvcnlcbiAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJnZW5lcmF0ZWRfbHlyaWNzXCIpXG4gICAgICAuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogdXNlcl9pZCxcbiAgICAgICAgcHJvbXB0OiBwcm9tcHQsXG4gICAgICAgIGx5cmljczogbHlyaWNzUmVzdWx0LnRleHQsXG4gICAgICAgIHRpdGxlOiBseXJpY3NSZXN1bHQudGl0bGUgfHwgbnVsbCxcbiAgICAgIH0pO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICBseXJpY3M6IGx5cmljc1Jlc3VsdC50ZXh0LFxuICAgICAgICB0aXRsZTogbHlyaWNzUmVzdWx0LnRpdGxlLFxuICAgICAgICBtZXNzYWdlOiBcItCi0LXQutGB0YIg0YPRgdC/0LXRiNC90L4g0YHQs9C10L3QtdGA0LjRgNC+0LLQsNC9XCIgXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gZ2VuZXJhdGUtbHlyaWNzOlwiLCBlcnJvcik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IG1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTsiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSx5QkFBeUI7QUFDekIsZUFBZSxpQkFBaUIsTUFBYyxFQUFFLE1BQWMsRUFBRSxjQUFjLEVBQUU7RUFDOUUsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsSUFBSztJQUNwQyxNQUFNLElBQUksUUFBUSxDQUFBLFVBQVcsV0FBVyxTQUFTLFFBQVEsK0JBQStCO0lBRXhGLElBQUk7TUFDRixNQUFNLFdBQVcsTUFBTSxNQUFNLENBQUMseURBQXlELEVBQUUsT0FBTyxDQUFDLEVBQUU7UUFDakcsU0FBUztVQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUM7UUFDckM7TUFDRjtNQUVBLE1BQU0sU0FBUyxNQUFNLFNBQVMsSUFBSTtNQUNsQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUU7TUFFdEMsSUFBSSxPQUFPLElBQUksS0FBSyxPQUFPLE9BQU8sSUFBSSxFQUFFLFdBQVcsV0FBVztRQUM1RCwrREFBK0Q7UUFDL0QsTUFBTSxhQUFhLE9BQU8sSUFBSSxDQUFDLFFBQVEsRUFBRTtRQUN6QyxJQUFJLGNBQWMsV0FBVyxNQUFNLEdBQUcsR0FBRztVQUN2QyxPQUFPO1lBQ0wsTUFBTSxVQUFVLENBQUMsRUFBRSxDQUFDLElBQUksSUFBSTtZQUM1QixPQUFPLFVBQVUsQ0FBQyxFQUFFLENBQUMsS0FBSyxJQUFJO1VBQ2hDO1FBQ0Y7UUFDQSx5Q0FBeUM7UUFDekMsT0FBTztVQUNMLE1BQU0sT0FBTyxJQUFJLENBQUMsSUFBSSxJQUFJO1VBQzFCLE9BQU8sT0FBTyxJQUFJLENBQUMsS0FBSyxJQUFJO1FBQzlCO01BQ0Y7TUFFQSxJQUFJLE9BQU8sSUFBSSxFQUFFLFdBQVcsVUFBVTtRQUNwQyxNQUFNLElBQUksTUFBTTtNQUNsQjtJQUNGLEVBQUUsT0FBTyxPQUFPO01BQ2QsUUFBUSxLQUFLLENBQUMsZUFBZTtJQUMvQjtFQUNGO0VBQ0EsT0FBTztBQUNUO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YseUNBQXlDO0lBQ3pDLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVksV0FBVyxZQUFZO01BQ3RDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF5QixJQUNqRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFdBQVcsYUFDZixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsaUJBQ2IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBR2YsbUZBQW1GO0lBQ25GLE1BQU0sUUFBUSxXQUFXLE9BQU8sQ0FBQyxXQUFXO0lBQzVDLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxRQUFRLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBRW5GLElBQUksYUFBYSxDQUFDLFVBQVUsSUFBSTtNQUM5QixRQUFRLEtBQUssQ0FBQyxlQUFlO01BQzdCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE2QixJQUNyRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxtREFBbUQ7SUFDbkQsTUFBTSxVQUFVLFNBQVMsRUFBRTtJQUUzQixNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFJLElBQUk7SUFFakMsUUFBUSxHQUFHLENBQUMsNEJBQTRCO01BQUU7TUFBUTtJQUFRO0lBRTFELE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbEMsSUFBSSxDQUFDLGNBQWM7TUFDakIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxvQkFBb0I7SUFDcEIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxTQUM3QixJQUFJLENBQUMsa0JBQ0wsTUFBTSxDQUFDLGFBQ1AsRUFBRSxDQUFDLFFBQVEsbUJBQ1gsV0FBVztJQUVkLE1BQU0sUUFBUSxTQUFTLGFBQWE7SUFFcEMscUJBQXFCO0lBQ3JCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxHQUFHLE1BQU0sU0FDN0IsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsU0FDZCxXQUFXO0lBRWQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLE9BQU8sSUFBSSxDQUFDLElBQUksT0FBTztNQUM5QyxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLGlCQUFpQjtJQUNqQixNQUFNLGFBQWEsQ0FBQyxRQUFRLE9BQU8sSUFBSSxDQUFDLElBQUk7SUFDNUMsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztNQUFFLFNBQVM7SUFBVyxHQUM3QixFQUFFLENBQUMsV0FBVztJQUVqQixrQkFBa0I7SUFDbEIsTUFBTSxTQUFTLElBQUksQ0FBQyx3QkFBd0IsTUFBTSxDQUFDO01BQ2pELFNBQVM7TUFDVCxRQUFRLENBQUM7TUFDVCxlQUFlO01BQ2YsTUFBTTtNQUNOLGFBQWE7SUFDZjtJQUVBLG1DQUFtQztJQUNuQyxtRUFBbUU7SUFDbkUsTUFBTSxjQUFjLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLDZCQUE2QixDQUFDO0lBQ2xGLE1BQU0sV0FBVyxNQUFNLE1BQU0seUNBQXlDO01BQ3BFLFFBQVE7TUFDUixTQUFTO1FBQ1AsZ0JBQWdCO1FBQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQ25CO1FBQ0EsYUFBYTtNQUNmO0lBQ0Y7SUFFQSxNQUFNLFNBQVMsTUFBTSxTQUFTLElBQUk7SUFDbEMsUUFBUSxHQUFHLENBQUMsNkJBQTZCO0lBRXpDLElBQUksT0FBTyxJQUFJLEtBQUssS0FBSztNQUN2QixvQkFBb0I7TUFDcEIsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztRQUFFLFNBQVMsUUFBUSxPQUFPO01BQUMsR0FDbEMsRUFBRSxDQUFDLFdBQVc7TUFDakIsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHLElBQUk7SUFDaEM7SUFFQSxNQUFNLFNBQVMsT0FBTyxJQUFJLEVBQUU7SUFDNUIsSUFBSSxDQUFDLFFBQVE7TUFDWCxvQkFBb0I7TUFDcEIsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztRQUFFLFNBQVMsUUFBUSxPQUFPO01BQUMsR0FDbEMsRUFBRSxDQUFDLFdBQVc7TUFDakIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxrQkFBa0I7SUFDbEIsTUFBTSxlQUFlLE1BQU0saUJBQWlCLFFBQVE7SUFFcEQsSUFBSSxDQUFDLGNBQWM7TUFDakIsb0JBQW9CO01BQ3BCLE1BQU0sU0FDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7UUFBRSxTQUFTLFFBQVEsT0FBTztNQUFDLEdBQ2xDLEVBQUUsQ0FBQyxXQUFXO01BQ2pCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsa0JBQWtCO0lBQ2xCLE1BQU0sU0FDSCxJQUFJLENBQUMsb0JBQ0wsTUFBTSxDQUFDO01BQ04sU0FBUztNQUNULFFBQVE7TUFDUixRQUFRLGFBQWEsSUFBSTtNQUN6QixPQUFPLGFBQWEsS0FBSyxJQUFJO0lBQy9CO0lBRUYsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsUUFBUSxhQUFhLElBQUk7TUFDekIsT0FBTyxhQUFhLEtBQUs7TUFDekIsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEUsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDZCQUE2QjtJQUMzQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
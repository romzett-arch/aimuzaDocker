const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Timeweb Agent ID for lyrics/prompt generation
const AGENT_ACCESS_ID = '0846d064-4950-4d79-a54c-62ba315cdb34';
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // Authenticate user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "Необходима авторизация"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
    const token = authHeader.replace("Bearer ", "");
    const { data, error: authError } = await supabase.auth.getClaims(token);
    if (authError || !data?.claims?.sub) {
      console.error("Auth error:", authError);
      return new Response(JSON.stringify({
        error: "Неверный токен авторизации"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const user_id = data.claims.sub;
    const { mode, lyrics, style, theme, userRequest } = await req.json();
    console.log("Timeweb lyrics request:", {
      mode,
      user_id,
      hasLyrics: !!lyrics,
      style,
      theme
    });
    const TIMEWEB_TOKEN = Deno.env.get("TIMEWEB_AGENT_TOKEN");
    if (!TIMEWEB_TOKEN) {
      throw new Error("TIMEWEB_AGENT_TOKEN not configured");
    }
    // Get service price (use existing generate_lyrics service)
    const { data: service } = await supabase.from("addon_services").select("price_rub").eq("name", "generate_lyrics").maybeSingle();
    const price = service?.price_rub || 5;
    // Check user balance
    const { data: profile } = await supabase.from("profiles").select("balance").eq("user_id", user_id).maybeSingle();
    if (!profile || (profile.balance || 0) < price) {
      return new Response(JSON.stringify({
        error: "Недостаточно средств на балансе"
      }), {
        status: 402,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Deduct balance
    const newBalance = (profile.balance || 0) - price;
    const { error: balanceError } = await supabase.from("profiles").update({
      balance: newBalance
    }).eq("user_id", user_id);
    if (balanceError) {
      throw new Error("Ошибка списания баланса");
    }
    // Log transaction
    await supabase.from("balance_transactions").insert({
      user_id: user_id,
      amount: -price,
      balance_after: newBalance,
      type: "lyrics_gen",
      description: `Генерация текста (${mode})`,
      metadata: {
        mode
      }
    });
    // Build prompt based on mode
    let systemPrompt;
    let userPrompt;
    if (mode === "improve") {
      systemPrompt = `Ты профессиональный поэт-песенник. Твоя задача — улучшить текст песни, сохраняя его смысл и настроение.

Правила:
- Улучши рифмы, ритм и звучание
- Сохрани оригинальную идею и эмоции
- Исправь грамматические ошибки
- Сделай текст более выразительным и поэтичным
- НЕ добавляй теги разметки типа [Verse], [Chorus] — только чистый текст
- Отвечай ТОЛЬКО текстом песни, без пояснений`;
      userPrompt = `Улучши этот текст песни${style ? ` в стиле ${style}` : ""}:

${lyrics}`;
    } else if (mode === "markup") {
      // Режим разметки текста тегами
      systemPrompt = `Ты эксперт по разметке текстов песен для AI-генераторов музыки (Suno, Udio).

Твоя задача — добавить структурную разметку к тексту песни.

Правила:
1. УЧИТЫВАЙ ПОЖЕЛАНИЕ ПОЛЬЗОВАТЕЛЯ — на основе его пожеланий разработай разметку
2. Используй теги структуры: [Verse], [Chorus], [Bridge], [Outro], [Intro], [Pre-Chorus], [Hook]
3. Добавляй теги вокала при необходимости: [Male Vocal], [Female Vocal], [Duet], [Whisper], [Shout]
4. Добавляй теги настроения и динамики: [Soft], [Powerful], [Emotional], [Energetic]
5. Используй инструментальные указания: [Guitar Solo], [Piano Break], [Drop], [Build-up]
6. Сохраняй оригинальный текст без изменений — только добавляй теги
7. Теги ставь в начале строки или секции
8. ОБЯЗАТЕЛЬНО добавляй секцию [Outro] в конце песни с инструкциями затухания/окончания
9. Отвечай ТОЛЬКО размеченным текстом, без пояснений

ВАЖНО — ОКОНЧАНИЕ ПЕСНИ:
После последнего текстового блока ВСЕГДА добавляй блок [Outro] с описанием того, как песня заканчивается.
Используй комбинацию тегов и ремарок в скобках для создания атмосферного завершения.
Если пользователь указал своё видение окончания — следуй ему. Если нет — создай подходящее по настроению.

Пример окончания:
[Outro]
[Bassline filtering out]
[Minimalist percussion and pads]
(Breathy whisper: повтор ключевой фразы...)
[Soft synth swell]
[Fade out]
[End]

Примеры тегов:
[Verse 1]
[Chorus] [Powerful, layered harmonies]
[Bridge] [Soft, piano only]
[Outro] [Fade out]`;
      const userWish = userRequest?.trim() ? `\nПожелание пользователя: ${userRequest}` : "";
      userPrompt = `Разметь этот текст песни тегами структуры:${userWish}

${lyrics}`;
    } else if (mode === "create_prompt") {
      systemPrompt = `Ты эксперт по созданию музыкальных промптов для AI-генераторов музыки (Suno, Udio).

Твоя задача — проанализировать текст песни и создать оптимальный промт стиля на АНГЛИЙСКОМ языке.

Правила:
- Определи жанр, настроение, темп, вокал
- Укажи инструменты и звучание
- Используй музыкальную терминологию
- Формат: теги через запятую, без скобок
- Максимум 150 символов
- Пиши ТОЛЬКО НА АНГЛИЙСКОМ
- Отвечай ТОЛЬКО промтом, без пояснений

Примеры хороших промптов:
- "dark trap, 808 bass, aggressive vocals, minor key, 140 bpm"
- "acoustic indie folk, warm vocals, fingerpicking guitar, nostalgic, autumn vibes"
- "synthwave, retro 80s, female vocals, dreamy, neon lights, pulsing synths"`;
      userPrompt = `Проанализируй этот текст песни и создай промт стиля:

${lyrics}

${style ? `Текущий стиль (учти при создании): ${style}` : ""}`;
    } else if (mode === "ideas") {
      // Generate 3 random song ideas
      systemPrompt = `Ты креативный генератор идей для песен. Твоя задача — придумать 3 оригинальные, неожиданные идеи для песен.

Для КАЖДОЙ идеи укажи:
1. **Название** — яркое, запоминающееся название песни
2. **Настроение** — эмоциональный тон (грустная, весёлая, меланхоличная, энергичная, романтичная и т.д.)
3. **Концепция** — краткое описание истории/сюжета песни (2-3 предложения)
4. **Теги стиля** — музыкальные теги для генерации на английском через запятую (например: indie pop, acoustic guitar, soft female vocals, nostalgic)
5. **Первые строки** — 4-6 строк начала текста песни

Формат ответа (строго соблюдай):

---IDEA_1---
НАЗВАНИЕ: [название]
НАСТРОЕНИЕ: [настроение]
КОНЦЕПЦИЯ: [концепция]
ТЕГИ: [теги через запятую, на английском]
ТЕКСТ:
[первые 4-6 строк]

---IDEA_2---
...

---IDEA_3---
...

Правила:
- Идеи должны быть РАЗНООБРАЗНЫМИ по жанру и настроению
- Используй неизбитые темы и метафоры
- Тексты пиши на русском языке
- Теги стиля пиши ТОЛЬКО на английском
- НЕ добавляй никаких пояснений, только идеи в заданном формате`;
      userPrompt = `Сгенерируй 3 креативные и разнообразные идеи для песен. Удиви меня!`;
    } else {
      // Generate new
      systemPrompt = `Ты профессиональный поэт-песенник. Твоя задача — написать оригинальный текст песни.

Правила:
- Создай уникальный, запоминающийся текст
- Используй чёткую структуру: куплеты, припев, бридж
- НЕ добавляй теги разметки типа [Verse], [Chorus] — только чистый текст
- Разделяй секции пустыми строками
- Рифмы должны быть естественными
- Текст должен быть эмоциональным и цепляющим
- Пиши на русском языке если не указано иное
- Отвечай ТОЛЬКО текстом песни, без пояснений`;
      const baseText = lyrics?.trim() || theme || "";
      userPrompt = baseText ? `Напиши новый текст песни${style ? ` в стиле ${style}` : ""}, вдохновляясь этой идеей/темой:

${baseText}` : `Напиши оригинальный текст песни${style ? ` в стиле ${style}` : ""}. Тема на твой выбор — что-то эмоциональное и современное.`;
    }
    // Call Timeweb Agent API
    const apiUrl = `https://agent.timeweb.cloud/api/v1/cloud-ai/agents/${AGENT_ACCESS_ID}/v1/chat/completions`;
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${TIMEWEB_TOKEN}`,
        "x-proxy-source": "lovable-app"
      },
      body: JSON.stringify({
        model: "deepseek-v3",
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: userPrompt
          }
        ],
        temperature: 0.8
      })
    });
    console.log("Timeweb response status:", response.status);
    if (!response.ok) {
      // Refund on API error
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user_id);
      const errorText = await response.text();
      console.error("Timeweb API error:", response.status, errorText);
      throw new Error("Ошибка API Timeweb");
    }
    const result = await response.json();
    console.log("Timeweb response received");
    const generatedContent = result.choices?.[0]?.message?.content;
    if (!generatedContent) {
      // Refund on empty result
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user_id);
      throw new Error("Не удалось сгенерировать текст");
    }
    // Save to history (only for lyrics modes, not markup or create_prompt)
    if (mode !== "create_prompt" && mode !== "markup") {
      await supabase.from("generated_lyrics").insert({
        user_id: user_id,
        prompt: mode === "improve" ? `[IMPROVE] ${style || ""}` : `[GENERATE] ${theme || style || ""}`,
        lyrics: generatedContent,
        title: null
      });
    }
    // Different response based on mode
    if (mode === "create_prompt") {
      return new Response(JSON.stringify({
        success: true,
        stylePrompt: generatedContent.trim(),
        mode,
        message: "Промт создан!"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (mode === "markup") {
      return new Response(JSON.stringify({
        success: true,
        lyrics: generatedContent.trim(),
        mode,
        message: "Текст размечен!"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (mode === "ideas") {
      // Parse ideas from response
      const ideas = [];
      const ideaBlocks = generatedContent.split(/---IDEA_\d+---/).filter((b)=>b.trim());
      for (const block of ideaBlocks){
        const titleMatch = block.match(/НАЗВАНИЕ:\s*(.+)/i);
        const moodMatch = block.match(/НАСТРОЕНИЕ:\s*(.+)/i);
        const conceptMatch = block.match(/КОНЦЕПЦИЯ:\s*(.+)/i);
        const tagsMatch = block.match(/ТЕГИ:\s*(.+)/i);
        const lyricsMatch = block.match(/ТЕКСТ:\s*([\s\S]+?)(?=(?:---IDEA_|$))/i);
        if (titleMatch) {
          ideas.push({
            title: titleMatch[1].trim(),
            mood: moodMatch?.[1]?.trim() || "",
            concept: conceptMatch?.[1]?.trim() || "",
            tags: tagsMatch?.[1]?.trim() || "",
            lyrics: lyricsMatch?.[1]?.trim() || ""
          });
        }
      }
      return new Response(JSON.stringify({
        success: true,
        ideas,
        mode,
        message: "Идеи сгенерированы!"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    return new Response(JSON.stringify({
      success: true,
      lyrics: generatedContent.trim(),
      mode,
      message: mode === "improve" ? "Текст улучшен!" : "Текст сгенерирован!"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in deepseek-lyrics:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9kZWVwc2Vlay1seXJpY3MudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbnR5cGUgTW9kZSA9IFwiaW1wcm92ZVwiIHwgXCJnZW5lcmF0ZVwiIHwgXCJjcmVhdGVfcHJvbXB0XCIgfCBcIm1hcmt1cFwiIHwgXCJpZGVhc1wiO1xuXG4vLyBUaW1ld2ViIEFnZW50IElEIGZvciBseXJpY3MvcHJvbXB0IGdlbmVyYXRpb25cbmNvbnN0IEFHRU5UX0FDQ0VTU19JRCA9ICcwODQ2ZDA2NC00OTUwLTRkNzktYTU0Yy02MmJhMzE1Y2RiMzQnO1xuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgLy8gQXV0aGVudGljYXRlIHVzZXJcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXI/LnN0YXJ0c1dpdGgoXCJCZWFyZXIgXCIpKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LXQvtCx0YXQvtC00LjQvNCwINCw0LLRgtC+0YDQuNC30LDRhtC40Y9cIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpISxcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhXG4gICAgKTtcblxuICAgIGNvbnN0IHRva2VuID0gYXV0aEhlYWRlci5yZXBsYWNlKFwiQmVhcmVyIFwiLCBcIlwiKTtcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yOiBhdXRoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0Q2xhaW1zKHRva2VuKTtcbiAgICBcbiAgICBpZiAoYXV0aEVycm9yIHx8ICFkYXRhPy5jbGFpbXM/LnN1Yikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkF1dGggZXJyb3I6XCIsIGF1dGhFcnJvcik7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LXQstC10YDQvdGL0Lkg0YLQvtC60LXQvSDQsNCy0YLQvtGA0LjQt9Cw0YbQuNC4XCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB1c2VyX2lkID0gZGF0YS5jbGFpbXMuc3ViIGFzIHN0cmluZztcbiAgICBjb25zdCB7IG1vZGUsIGx5cmljcywgc3R5bGUsIHRoZW1lLCB1c2VyUmVxdWVzdCB9ID0gYXdhaXQgcmVxLmpzb24oKSBhcyB7XG4gICAgICBtb2RlOiBNb2RlO1xuICAgICAgbHlyaWNzPzogc3RyaW5nO1xuICAgICAgc3R5bGU/OiBzdHJpbmc7XG4gICAgICB0aGVtZT86IHN0cmluZztcbiAgICAgIHVzZXJSZXF1ZXN0Pzogc3RyaW5nOyAvLyDQn9C+0LbQtdC70LDQvdC40LUg0L/QvtC70YzQt9C+0LLQsNGC0LXQu9GPINC00LvRjyDRgNCw0LfQvNC10YLQutC4XG4gICAgfTtcblxuICAgIGNvbnNvbGUubG9nKFwiVGltZXdlYiBseXJpY3MgcmVxdWVzdDpcIiwgeyBtb2RlLCB1c2VyX2lkLCBoYXNMeXJpY3M6ICEhbHlyaWNzLCBzdHlsZSwgdGhlbWUgfSk7XG5cbiAgICBjb25zdCBUSU1FV0VCX1RPS0VOID0gRGVuby5lbnYuZ2V0KFwiVElNRVdFQl9BR0VOVF9UT0tFTlwiKTtcbiAgICBpZiAoIVRJTUVXRUJfVE9LRU4pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRJTUVXRUJfQUdFTlRfVE9LRU4gbm90IGNvbmZpZ3VyZWRcIik7XG4gICAgfVxuXG4gICAgLy8gR2V0IHNlcnZpY2UgcHJpY2UgKHVzZSBleGlzdGluZyBnZW5lcmF0ZV9seXJpY3Mgc2VydmljZSlcbiAgICBjb25zdCB7IGRhdGE6IHNlcnZpY2UgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImFkZG9uX3NlcnZpY2VzXCIpXG4gICAgICAuc2VsZWN0KFwicHJpY2VfcnViXCIpXG4gICAgICAuZXEoXCJuYW1lXCIsIFwiZ2VuZXJhdGVfbHlyaWNzXCIpXG4gICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgIGNvbnN0IHByaWNlID0gc2VydmljZT8ucHJpY2VfcnViIHx8IDU7XG5cbiAgICAvLyBDaGVjayB1c2VyIGJhbGFuY2VcbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAuc2VsZWN0KFwiYmFsYW5jZVwiKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyX2lkKVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICBpZiAoIXByb2ZpbGUgfHwgKHByb2ZpbGUuYmFsYW5jZSB8fCAwKSA8IHByaWNlKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LXQtNC+0YHRgtCw0YLQvtGH0L3QviDRgdGA0LXQtNGB0YLQsiDQvdCwINCx0LDQu9Cw0L3RgdC1XCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDIsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBEZWR1Y3QgYmFsYW5jZVxuICAgIGNvbnN0IG5ld0JhbGFuY2UgPSAocHJvZmlsZS5iYWxhbmNlIHx8IDApIC0gcHJpY2U7XG4gICAgY29uc3QgeyBlcnJvcjogYmFsYW5jZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IG5ld0JhbGFuY2UgfSlcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcl9pZCk7XG5cbiAgICBpZiAoYmFsYW5jZUVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCLQntGI0LjQsdC60LAg0YHQv9C40YHQsNC90LjRjyDQsdCw0LvQsNC90YHQsFwiKTtcbiAgICB9XG5cbiAgICAvLyBMb2cgdHJhbnNhY3Rpb25cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwiYmFsYW5jZV90cmFuc2FjdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgIHVzZXJfaWQ6IHVzZXJfaWQsXG4gICAgICBhbW91bnQ6IC1wcmljZSxcbiAgICAgIGJhbGFuY2VfYWZ0ZXI6IG5ld0JhbGFuY2UsXG4gICAgICB0eXBlOiBcImx5cmljc19nZW5cIixcbiAgICAgIGRlc2NyaXB0aW9uOiBg0JPQtdC90LXRgNCw0YbQuNGPINGC0LXQutGB0YLQsCAoJHttb2RlfSlgLFxuICAgICAgbWV0YWRhdGE6IHsgbW9kZSB9LFxuICAgIH0pO1xuXG4gICAgLy8gQnVpbGQgcHJvbXB0IGJhc2VkIG9uIG1vZGVcbiAgICBsZXQgc3lzdGVtUHJvbXB0OiBzdHJpbmc7XG4gICAgbGV0IHVzZXJQcm9tcHQ6IHN0cmluZztcblxuICAgIGlmIChtb2RlID09PSBcImltcHJvdmVcIikge1xuICAgICAgc3lzdGVtUHJvbXB0ID0gYNCi0Ysg0L/RgNC+0YTQtdGB0YHQuNC+0L3QsNC70YzQvdGL0Lkg0L/QvtGN0YIt0L/QtdGB0LXQvdC90LjQui4g0KLQstC+0Y8g0LfQsNC00LDRh9CwIOKAlCDRg9C70YPRh9GI0LjRgtGMINGC0LXQutGB0YIg0L/QtdGB0L3QuCwg0YHQvtGF0YDQsNC90Y/RjyDQtdCz0L4g0YHQvNGL0YHQuyDQuCDQvdCw0YHRgtGA0L7QtdC90LjQtS5cblxu0J/RgNCw0LLQuNC70LA6XG4tINCj0LvRg9GH0YjQuCDRgNC40YTQvNGLLCDRgNC40YLQvCDQuCDQt9Cy0YPRh9Cw0L3QuNC1XG4tINCh0L7RhdGA0LDQvdC4INC+0YDQuNCz0LjQvdCw0LvRjNC90YPRjiDQuNC00LXRjiDQuCDRjdC80L7RhtC40Lhcbi0g0JjRgdC/0YDQsNCy0Ywg0LPRgNCw0LzQvNCw0YLQuNGH0LXRgdC60LjQtSDQvtGI0LjQsdC60Lhcbi0g0KHQtNC10LvQsNC5INGC0LXQutGB0YIg0LHQvtC70LXQtSDQstGL0YDQsNC30LjRgtC10LvRjNC90YvQvCDQuCDQv9C+0Y3RgtC40YfQvdGL0Lxcbi0g0J3QlSDQtNC+0LHQsNCy0LvRj9C5INGC0LXQs9C4INGA0LDQt9C80LXRgtC60Lgg0YLQuNC/0LAgW1ZlcnNlXSwgW0Nob3J1c10g4oCUINGC0L7Qu9GM0LrQviDRh9C40YHRgtGL0Lkg0YLQtdC60YHRglxuLSDQntGC0LLQtdGH0LDQuSDQotCe0JvQrNCa0J4g0YLQtdC60YHRgtC+0Lwg0L/QtdGB0L3QuCwg0LHQtdC3INC/0L7Rj9GB0L3QtdC90LjQuWA7XG5cbiAgICAgIHVzZXJQcm9tcHQgPSBg0KPQu9GD0YfRiNC4INGN0YLQvtGCINGC0LXQutGB0YIg0L/QtdGB0L3QuCR7c3R5bGUgPyBgINCyINGB0YLQuNC70LUgJHtzdHlsZX1gIDogXCJcIn06XG5cbiR7bHlyaWNzfWA7XG4gICAgfSBlbHNlIGlmIChtb2RlID09PSBcIm1hcmt1cFwiKSB7XG4gICAgICAvLyDQoNC10LbQuNC8INGA0LDQt9C80LXRgtC60Lgg0YLQtdC60YHRgtCwINGC0LXQs9Cw0LzQuFxuICAgICAgc3lzdGVtUHJvbXB0ID0gYNCi0Ysg0Y3QutGB0L/QtdGA0YIg0L/QviDRgNCw0LfQvNC10YLQutC1INGC0LXQutGB0YLQvtCyINC/0LXRgdC10L0g0LTQu9GPIEFJLdCz0LXQvdC10YDQsNGC0L7RgNC+0LIg0LzRg9C30YvQutC4IChTdW5vLCBVZGlvKS5cblxu0KLQstC+0Y8g0LfQsNC00LDRh9CwIOKAlCDQtNC+0LHQsNCy0LjRgtGMINGB0YLRgNGD0LrRgtGD0YDQvdGD0Y4g0YDQsNC30LzQtdGC0LrRgyDQuiDRgtC10LrRgdGC0YMg0L/QtdGB0L3QuC5cblxu0J/RgNCw0LLQuNC70LA6XG4xLiDQo9Cn0JjQotCr0JLQkNCZINCf0J7QltCV0JvQkNCd0JjQlSDQn9Ce0JvQrNCX0J7QktCQ0KLQldCb0K8g4oCUINC90LAg0L7RgdC90L7QstC1INC10LPQviDQv9C+0LbQtdC70LDQvdC40Lkg0YDQsNC30YDQsNCx0L7RgtCw0Lkg0YDQsNC30LzQtdGC0LrRg1xuMi4g0JjRgdC/0L7Qu9GM0LfRg9C5INGC0LXQs9C4INGB0YLRgNGD0LrRgtGD0YDRizogW1ZlcnNlXSwgW0Nob3J1c10sIFtCcmlkZ2VdLCBbT3V0cm9dLCBbSW50cm9dLCBbUHJlLUNob3J1c10sIFtIb29rXVxuMy4g0JTQvtCx0LDQstC70Y/QuSDRgtC10LPQuCDQstC+0LrQsNC70LAg0L/RgNC4INC90LXQvtCx0YXQvtC00LjQvNC+0YHRgtC4OiBbTWFsZSBWb2NhbF0sIFtGZW1hbGUgVm9jYWxdLCBbRHVldF0sIFtXaGlzcGVyXSwgW1Nob3V0XVxuNC4g0JTQvtCx0LDQstC70Y/QuSDRgtC10LPQuCDQvdCw0YHRgtGA0L7QtdC90LjRjyDQuCDQtNC40L3QsNC80LjQutC4OiBbU29mdF0sIFtQb3dlcmZ1bF0sIFtFbW90aW9uYWxdLCBbRW5lcmdldGljXVxuNS4g0JjRgdC/0L7Qu9GM0LfRg9C5INC40L3RgdGC0YDRg9C80LXQvdGC0LDQu9GM0L3Ri9C1INGD0LrQsNC30LDQvdC40Y86IFtHdWl0YXIgU29sb10sIFtQaWFubyBCcmVha10sIFtEcm9wXSwgW0J1aWxkLXVwXVxuNi4g0KHQvtGF0YDQsNC90Y/QuSDQvtGA0LjQs9C40L3QsNC70YzQvdGL0Lkg0YLQtdC60YHRgiDQsdC10Lcg0LjQt9C80LXQvdC10L3QuNC5IOKAlCDRgtC+0LvRjNC60L4g0LTQvtCx0LDQstC70Y/QuSDRgtC10LPQuFxuNy4g0KLQtdCz0Lgg0YHRgtCw0LLRjCDQsiDQvdCw0YfQsNC70LUg0YHRgtGA0L7QutC4INC40LvQuCDRgdC10LrRhtC40LhcbjguINCe0JHQr9CX0JDQotCV0JvQrNCd0J4g0LTQvtCx0LDQstC70Y/QuSDRgdC10LrRhtC40Y4gW091dHJvXSDQsiDQutC+0L3RhtC1INC/0LXRgdC90Lgg0YEg0LjQvdGB0YLRgNGD0LrRhtC40Y/QvNC4INC30LDRgtGD0YXQsNC90LjRjy/QvtC60L7QvdGH0LDQvdC40Y9cbjkuINCe0YLQstC10YfQsNC5INCi0J7Qm9Cs0JrQniDRgNCw0LfQvNC10YfQtdC90L3Ri9C8INGC0LXQutGB0YLQvtC8LCDQsdC10Lcg0L/QvtGP0YHQvdC10L3QuNC5XG5cbtCS0JDQltCd0J4g4oCUINCe0JrQntCd0KfQkNCd0JjQlSDQn9CV0KHQndCYOlxu0J/QvtGB0LvQtSDQv9C+0YHQu9C10LTQvdC10LPQviDRgtC10LrRgdGC0L7QstC+0LPQviDQsdC70L7QutCwINCS0KHQldCT0JTQkCDQtNC+0LHQsNCy0LvRj9C5INCx0LvQvtC6IFtPdXRyb10g0YEg0L7Qv9C40YHQsNC90LjQtdC8INGC0L7Qs9C+LCDQutCw0Log0L/QtdGB0L3RjyDQt9Cw0LrQsNC90YfQuNCy0LDQtdGC0YHRjy5cbtCY0YHQv9C+0LvRjNC30YPQuSDQutC+0LzQsdC40L3QsNGG0LjRjiDRgtC10LPQvtCyINC4INGA0LXQvNCw0YDQvtC6INCyINGB0LrQvtCx0LrQsNGFINC00LvRjyDRgdC+0LfQtNCw0L3QuNGPINCw0YLQvNC+0YHRhNC10YDQvdC+0LPQviDQt9Cw0LLQtdGA0YjQtdC90LjRjy5cbtCV0YHQu9C4INC/0L7Qu9GM0LfQvtCy0LDRgtC10LvRjCDRg9C60LDQt9Cw0Lsg0YHQstC+0ZEg0LLQuNC00LXQvdC40LUg0L7QutC+0L3Rh9Cw0L3QuNGPIOKAlCDRgdC70LXQtNGD0Lkg0LXQvNGDLiDQldGB0LvQuCDQvdC10YIg4oCUINGB0L7Qt9C00LDQuSDQv9C+0LTRhdC+0LTRj9GJ0LXQtSDQv9C+INC90LDRgdGC0YDQvtC10L3QuNGOLlxuXG7Qn9GA0LjQvNC10YAg0L7QutC+0L3Rh9Cw0L3QuNGPOlxuW091dHJvXVxuW0Jhc3NsaW5lIGZpbHRlcmluZyBvdXRdXG5bTWluaW1hbGlzdCBwZXJjdXNzaW9uIGFuZCBwYWRzXVxuKEJyZWF0aHkgd2hpc3Blcjog0L/QvtCy0YLQvtGAINC60LvRjtGH0LXQstC+0Lkg0YTRgNCw0LfRiy4uLilcbltTb2Z0IHN5bnRoIHN3ZWxsXVxuW0ZhZGUgb3V0XVxuW0VuZF1cblxu0J/RgNC40LzQtdGA0Ysg0YLQtdCz0L7QsjpcbltWZXJzZSAxXVxuW0Nob3J1c10gW1Bvd2VyZnVsLCBsYXllcmVkIGhhcm1vbmllc11cbltCcmlkZ2VdIFtTb2Z0LCBwaWFubyBvbmx5XVxuW091dHJvXSBbRmFkZSBvdXRdYDtcblxuICAgICAgY29uc3QgdXNlcldpc2ggPSB1c2VyUmVxdWVzdD8udHJpbSgpID8gYFxcbtCf0L7QttC10LvQsNC90LjQtSDQv9C+0LvRjNC30L7QstCw0YLQtdC70Y86ICR7dXNlclJlcXVlc3R9YCA6IFwiXCI7XG4gICAgICB1c2VyUHJvbXB0ID0gYNCg0LDQt9C80LXRgtGMINGN0YLQvtGCINGC0LXQutGB0YIg0L/QtdGB0L3QuCDRgtC10LPQsNC80Lgg0YHRgtGA0YPQutGC0YPRgNGLOiR7dXNlcldpc2h9XG5cbiR7bHlyaWNzfWA7XG4gICAgfSBlbHNlIGlmIChtb2RlID09PSBcImNyZWF0ZV9wcm9tcHRcIikge1xuICAgICAgc3lzdGVtUHJvbXB0ID0gYNCi0Ysg0Y3QutGB0L/QtdGA0YIg0L/QviDRgdC+0LfQtNCw0L3QuNGOINC80YPQt9GL0LrQsNC70YzQvdGL0YUg0L/RgNC+0LzQv9GC0L7QsiDQtNC70Y8gQUkt0LPQtdC90LXRgNCw0YLQvtGA0L7QsiDQvNGD0LfRi9C60LggKFN1bm8sIFVkaW8pLlxuXG7QotCy0L7RjyDQt9Cw0LTQsNGH0LAg4oCUINC/0YDQvtCw0L3QsNC70LjQt9C40YDQvtCy0LDRgtGMINGC0LXQutGB0YIg0L/QtdGB0L3QuCDQuCDRgdC+0LfQtNCw0YLRjCDQvtC/0YLQuNC80LDQu9GM0L3Ri9C5INC/0YDQvtC80YIg0YHRgtC40LvRjyDQvdCwINCQ0J3Qk9Cb0JjQmdCh0JrQntCcINGP0LfRi9C60LUuXG5cbtCf0YDQsNCy0LjQu9CwOlxuLSDQntC/0YDQtdC00LXQu9C4INC20LDQvdGALCDQvdCw0YHRgtGA0L7QtdC90LjQtSwg0YLQtdC80L8sINCy0L7QutCw0Ltcbi0g0KPQutCw0LbQuCDQuNC90YHRgtGA0YPQvNC10L3RgtGLINC4INC30LLRg9GH0LDQvdC40LVcbi0g0JjRgdC/0L7Qu9GM0LfRg9C5INC80YPQt9GL0LrQsNC70YzQvdGD0Y4g0YLQtdGA0LzQuNC90L7Qu9C+0LPQuNGOXG4tINCk0L7RgNC80LDRgjog0YLQtdCz0Lgg0YfQtdGA0LXQtyDQt9Cw0L/Rj9GC0YPRjiwg0LHQtdC3INGB0LrQvtCx0L7QulxuLSDQnNCw0LrRgdC40LzRg9C8IDE1MCDRgdC40LzQstC+0LvQvtCyXG4tINCf0LjRiNC4INCi0J7Qm9Cs0JrQniDQndCQINCQ0J3Qk9Cb0JjQmdCh0JrQntCcXG4tINCe0YLQstC10YfQsNC5INCi0J7Qm9Cs0JrQniDQv9GA0L7QvNGC0L7QvCwg0LHQtdC3INC/0L7Rj9GB0L3QtdC90LjQuVxuXG7Qn9GA0LjQvNC10YDRiyDRhdC+0YDQvtGI0LjRhSDQv9GA0L7QvNC/0YLQvtCyOlxuLSBcImRhcmsgdHJhcCwgODA4IGJhc3MsIGFnZ3Jlc3NpdmUgdm9jYWxzLCBtaW5vciBrZXksIDE0MCBicG1cIlxuLSBcImFjb3VzdGljIGluZGllIGZvbGssIHdhcm0gdm9jYWxzLCBmaW5nZXJwaWNraW5nIGd1aXRhciwgbm9zdGFsZ2ljLCBhdXR1bW4gdmliZXNcIlxuLSBcInN5bnRod2F2ZSwgcmV0cm8gODBzLCBmZW1hbGUgdm9jYWxzLCBkcmVhbXksIG5lb24gbGlnaHRzLCBwdWxzaW5nIHN5bnRoc1wiYDtcblxuICAgICAgdXNlclByb21wdCA9IGDQn9GA0L7QsNC90LDQu9C40LfQuNGA0YPQuSDRjdGC0L7RgiDRgtC10LrRgdGCINC/0LXRgdC90Lgg0Lgg0YHQvtC30LTQsNC5INC/0YDQvtC80YIg0YHRgtC40LvRjzpcblxuJHtseXJpY3N9XG5cbiR7c3R5bGUgPyBg0KLQtdC60YPRidC40Lkg0YHRgtC40LvRjCAo0YPRh9GC0Lgg0L/RgNC4INGB0L7Qt9C00LDQvdC40LgpOiAke3N0eWxlfWAgOiBcIlwifWA7XG4gICAgfSBlbHNlIGlmIChtb2RlID09PSBcImlkZWFzXCIpIHtcbiAgICAgIC8vIEdlbmVyYXRlIDMgcmFuZG9tIHNvbmcgaWRlYXNcbiAgICAgIHN5c3RlbVByb21wdCA9IGDQotGLINC60YDQtdCw0YLQuNCy0L3Ri9C5INCz0LXQvdC10YDQsNGC0L7RgCDQuNC00LXQuSDQtNC70Y8g0L/QtdGB0LXQvS4g0KLQstC+0Y8g0LfQsNC00LDRh9CwIOKAlCDQv9GA0LjQtNGD0LzQsNGC0YwgMyDQvtGA0LjQs9C40L3QsNC70YzQvdGL0LUsINC90LXQvtC20LjQtNCw0L3QvdGL0LUg0LjQtNC10Lgg0LTQu9GPINC/0LXRgdC10L0uXG5cbtCU0LvRjyDQmtCQ0JbQlNCe0Jkg0LjQtNC10Lgg0YPQutCw0LbQuDpcbjEuICoq0J3QsNC30LLQsNC90LjQtSoqIOKAlCDRj9GA0LrQvtC1LCDQt9Cw0L/QvtC80LjQvdCw0Y7RidC10LXRgdGPINC90LDQt9Cy0LDQvdC40LUg0L/QtdGB0L3QuFxuMi4gKirQndCw0YHRgtGA0L7QtdC90LjQtSoqIOKAlCDRjdC80L7RhtC40L7QvdCw0LvRjNC90YvQuSDRgtC+0L0gKNCz0YDRg9GB0YLQvdCw0Y8sINCy0LXRgdGR0LvQsNGPLCDQvNC10LvQsNC90YXQvtC70LjRh9C90LDRjywg0Y3QvdC10YDQs9C40YfQvdCw0Y8sINGA0L7QvNCw0L3RgtC40YfQvdCw0Y8g0Lgg0YIu0LQuKVxuMy4gKirQmtC+0L3RhtC10L/RhtC40Y8qKiDigJQg0LrRgNCw0YLQutC+0LUg0L7Qv9C40YHQsNC90LjQtSDQuNGB0YLQvtGA0LjQuC/RgdGO0LbQtdGC0LAg0L/QtdGB0L3QuCAoMi0zINC/0YDQtdC00LvQvtC20LXQvdC40Y8pXG40LiAqKtCi0LXQs9C4INGB0YLQuNC70Y8qKiDigJQg0LzRg9C30YvQutCw0LvRjNC90YvQtSDRgtC10LPQuCDQtNC70Y8g0LPQtdC90LXRgNCw0YbQuNC4INC90LAg0LDQvdCz0LvQuNC50YHQutC+0Lwg0YfQtdGA0LXQtyDQt9Cw0L/Rj9GC0YPRjiAo0L3QsNC/0YDQuNC80LXRgDogaW5kaWUgcG9wLCBhY291c3RpYyBndWl0YXIsIHNvZnQgZmVtYWxlIHZvY2Fscywgbm9zdGFsZ2ljKVxuNS4gKirQn9C10YDQstGL0LUg0YHRgtGA0L7QutC4Kiog4oCUIDQtNiDRgdGC0YDQvtC6INC90LDRh9Cw0LvQsCDRgtC10LrRgdGC0LAg0L/QtdGB0L3QuFxuXG7QpNC+0YDQvNCw0YIg0L7RgtCy0LXRgtCwICjRgdGC0YDQvtCz0L4g0YHQvtCx0LvRjtC00LDQuSk6XG5cbi0tLUlERUFfMS0tLVxu0J3QkNCX0JLQkNCd0JjQlTogW9C90LDQt9Cy0LDQvdC40LVdXG7QndCQ0KHQotCg0J7QldCd0JjQlTogW9C90LDRgdGC0YDQvtC10L3QuNC1XVxu0JrQntCd0KbQldCf0KbQmNCvOiBb0LrQvtC90YbQtdC/0YbQuNGPXVxu0KLQldCT0Jg6IFvRgtC10LPQuCDRh9C10YDQtdC3INC30LDQv9GP0YLRg9GOLCDQvdCwINCw0L3Qs9C70LjQudGB0LrQvtC8XVxu0KLQldCa0KHQojpcblvQv9C10YDQstGL0LUgNC02INGB0YLRgNC+0LpdXG5cbi0tLUlERUFfMi0tLVxuLi4uXG5cbi0tLUlERUFfMy0tLVxuLi4uXG5cbtCf0YDQsNCy0LjQu9CwOlxuLSDQmNC00LXQuCDQtNC+0LvQttC90Ysg0LHRi9GC0Ywg0KDQkNCX0J3QntCe0JHQoNCQ0JfQndCr0JzQmCDQv9C+INC20LDQvdGA0YMg0Lgg0L3QsNGB0YLRgNC+0LXQvdC40Y5cbi0g0JjRgdC/0L7Qu9GM0LfRg9C5INC90LXQuNC30LHQuNGC0YvQtSDRgtC10LzRiyDQuCDQvNC10YLQsNGE0L7RgNGLXG4tINCi0LXQutGB0YLRiyDQv9C40YjQuCDQvdCwINGA0YPRgdGB0LrQvtC8INGP0LfRi9C60LVcbi0g0KLQtdCz0Lgg0YHRgtC40LvRjyDQv9C40YjQuCDQotCe0JvQrNCa0J4g0L3QsCDQsNC90LPQu9C40LnRgdC60L7QvFxuLSDQndCVINC00L7QsdCw0LLQu9GP0Lkg0L3QuNC60LDQutC40YUg0L/QvtGP0YHQvdC10L3QuNC5LCDRgtC+0LvRjNC60L4g0LjQtNC10Lgg0LIg0LfQsNC00LDQvdC90L7QvCDRhNC+0YDQvNCw0YLQtWA7XG5cbiAgICAgIHVzZXJQcm9tcHQgPSBg0KHQs9C10L3QtdGA0LjRgNGD0LkgMyDQutGA0LXQsNGC0LjQstC90YvQtSDQuCDRgNCw0LfQvdC+0L7QsdGA0LDQt9C90YvQtSDQuNC00LXQuCDQtNC70Y8g0L/QtdGB0LXQvS4g0KPQtNC40LLQuCDQvNC10L3RjyFgO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBHZW5lcmF0ZSBuZXdcbiAgICAgIHN5c3RlbVByb21wdCA9IGDQotGLINC/0YDQvtGE0LXRgdGB0LjQvtC90LDQu9GM0L3Ri9C5INC/0L7RjdGCLdC/0LXRgdC10L3QvdC40LouINCi0LLQvtGPINC30LDQtNCw0YfQsCDigJQg0L3QsNC/0LjRgdCw0YLRjCDQvtGA0LjQs9C40L3QsNC70YzQvdGL0Lkg0YLQtdC60YHRgiDQv9C10YHQvdC4LlxuXG7Qn9GA0LDQstC40LvQsDpcbi0g0KHQvtC30LTQsNC5INGD0L3QuNC60LDQu9GM0L3Ri9C5LCDQt9Cw0L/QvtC80LjQvdCw0Y7RidC40LnRgdGPINGC0LXQutGB0YJcbi0g0JjRgdC/0L7Qu9GM0LfRg9C5INGH0ZHRgtC60YPRjiDRgdGC0YDRg9C60YLRg9GA0YM6INC60YPQv9C70LXRgtGLLCDQv9GA0LjQv9C10LIsINCx0YDQuNC00LZcbi0g0J3QlSDQtNC+0LHQsNCy0LvRj9C5INGC0LXQs9C4INGA0LDQt9C80LXRgtC60Lgg0YLQuNC/0LAgW1ZlcnNlXSwgW0Nob3J1c10g4oCUINGC0L7Qu9GM0LrQviDRh9C40YHRgtGL0Lkg0YLQtdC60YHRglxuLSDQoNCw0LfQtNC10LvRj9C5INGB0LXQutGG0LjQuCDQv9GD0YHRgtGL0LzQuCDRgdGC0YDQvtC60LDQvNC4XG4tINCg0LjRhNC80Ysg0LTQvtC70LbQvdGLINCx0YvRgtGMINC10YHRgtC10YHRgtCy0LXQvdC90YvQvNC4XG4tINCi0LXQutGB0YIg0LTQvtC70LbQtdC9INCx0YvRgtGMINGN0LzQvtGG0LjQvtC90LDQu9GM0L3Ri9C8INC4INGG0LXQv9C70Y/RjtGJ0LjQvFxuLSDQn9C40YjQuCDQvdCwINGA0YPRgdGB0LrQvtC8INGP0LfRi9C60LUg0LXRgdC70Lgg0L3QtSDRg9C60LDQt9Cw0L3QviDQuNC90L7QtVxuLSDQntGC0LLQtdGH0LDQuSDQotCe0JvQrNCa0J4g0YLQtdC60YHRgtC+0Lwg0L/QtdGB0L3QuCwg0LHQtdC3INC/0L7Rj9GB0L3QtdC90LjQuWA7XG5cbiAgICAgIGNvbnN0IGJhc2VUZXh0ID0gbHlyaWNzPy50cmltKCkgfHwgdGhlbWUgfHwgXCJcIjtcbiAgICAgIHVzZXJQcm9tcHQgPSBiYXNlVGV4dCBcbiAgICAgICAgPyBg0J3QsNC/0LjRiNC4INC90L7QstGL0Lkg0YLQtdC60YHRgiDQv9C10YHQvdC4JHtzdHlsZSA/IGAg0LIg0YHRgtC40LvQtSAke3N0eWxlfWAgOiBcIlwifSwg0LLQtNC+0YXQvdC+0LLQu9GP0Y/RgdGMINGN0YLQvtC5INC40LTQtdC10Lkv0YLQtdC80L7QuTpcblxuJHtiYXNlVGV4dH1gXG4gICAgICAgIDogYNCd0LDQv9C40YjQuCDQvtGA0LjQs9C40L3QsNC70YzQvdGL0Lkg0YLQtdC60YHRgiDQv9C10YHQvdC4JHtzdHlsZSA/IGAg0LIg0YHRgtC40LvQtSAke3N0eWxlfWAgOiBcIlwifS4g0KLQtdC80LAg0L3QsCDRgtCy0L7QuSDQstGL0LHQvtGAIOKAlCDRh9GC0L4t0YLQviDRjdC80L7RhtC40L7QvdCw0LvRjNC90L7QtSDQuCDRgdC+0LLRgNC10LzQtdC90L3QvtC1LmA7XG4gICAgfVxuXG4gICAgLy8gQ2FsbCBUaW1ld2ViIEFnZW50IEFQSVxuICAgIGNvbnN0IGFwaVVybCA9IGBodHRwczovL2FnZW50LnRpbWV3ZWIuY2xvdWQvYXBpL3YxL2Nsb3VkLWFpL2FnZW50cy8ke0FHRU5UX0FDQ0VTU19JRH0vdjEvY2hhdC9jb21wbGV0aW9uc2A7XG4gICAgXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1RJTUVXRUJfVE9LRU59YCxcbiAgICAgICAgXCJ4LXByb3h5LXNvdXJjZVwiOiBcImxvdmFibGUtYXBwXCIsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBtb2RlbDogXCJkZWVwc2Vlay12M1wiLFxuICAgICAgICBtZXNzYWdlczogW1xuICAgICAgICAgIHsgcm9sZTogXCJzeXN0ZW1cIiwgY29udGVudDogc3lzdGVtUHJvbXB0IH0sXG4gICAgICAgICAgeyByb2xlOiBcInVzZXJcIiwgY29udGVudDogdXNlclByb21wdCB9LFxuICAgICAgICBdLFxuICAgICAgICB0ZW1wZXJhdHVyZTogMC44LFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBjb25zb2xlLmxvZyhcIlRpbWV3ZWIgcmVzcG9uc2Ugc3RhdHVzOlwiLCByZXNwb25zZS5zdGF0dXMpO1xuXG4gICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgLy8gUmVmdW5kIG9uIEFQSSBlcnJvclxuICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogcHJvZmlsZS5iYWxhbmNlIH0pXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcl9pZCk7XG5cbiAgICAgIGNvbnN0IGVycm9yVGV4dCA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJUaW1ld2ViIEFQSSBlcnJvcjpcIiwgcmVzcG9uc2Uuc3RhdHVzLCBlcnJvclRleHQpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwi0J7RiNC40LHQutCwIEFQSSBUaW1ld2ViXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhcIlRpbWV3ZWIgcmVzcG9uc2UgcmVjZWl2ZWRcIik7XG5cbiAgICBjb25zdCBnZW5lcmF0ZWRDb250ZW50ID0gcmVzdWx0LmNob2ljZXM/LlswXT8ubWVzc2FnZT8uY29udGVudDtcbiAgICBcbiAgICBpZiAoIWdlbmVyYXRlZENvbnRlbnQpIHtcbiAgICAgIC8vIFJlZnVuZCBvbiBlbXB0eSByZXN1bHRcbiAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IHByb2ZpbGUuYmFsYW5jZSB9KVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJfaWQpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDRgdCz0LXQvdC10YDQuNGA0L7QstCw0YLRjCDRgtC10LrRgdGCXCIpO1xuICAgIH1cblxuICAgIC8vIFNhdmUgdG8gaGlzdG9yeSAob25seSBmb3IgbHlyaWNzIG1vZGVzLCBub3QgbWFya3VwIG9yIGNyZWF0ZV9wcm9tcHQpXG4gICAgaWYgKG1vZGUgIT09IFwiY3JlYXRlX3Byb21wdFwiICYmIG1vZGUgIT09IFwibWFya3VwXCIpIHtcbiAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwiZ2VuZXJhdGVkX2x5cmljc1wiKVxuICAgICAgICAuaW5zZXJ0KHtcbiAgICAgICAgICB1c2VyX2lkOiB1c2VyX2lkLFxuICAgICAgICAgIHByb21wdDogbW9kZSA9PT0gXCJpbXByb3ZlXCIgPyBgW0lNUFJPVkVdICR7c3R5bGUgfHwgXCJcIn1gIDogYFtHRU5FUkFURV0gJHt0aGVtZSB8fCBzdHlsZSB8fCBcIlwifWAsXG4gICAgICAgICAgbHlyaWNzOiBnZW5lcmF0ZWRDb250ZW50LFxuICAgICAgICAgIHRpdGxlOiBudWxsLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBEaWZmZXJlbnQgcmVzcG9uc2UgYmFzZWQgb24gbW9kZVxuICAgIGlmIChtb2RlID09PSBcImNyZWF0ZV9wcm9tcHRcIikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgICBzdHlsZVByb21wdDogZ2VuZXJhdGVkQ29udGVudC50cmltKCksXG4gICAgICAgICAgbW9kZSxcbiAgICAgICAgICBtZXNzYWdlOiBcItCf0YDQvtC80YIg0YHQvtC30LTQsNC9IVwiIFxuICAgICAgICB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKG1vZGUgPT09IFwibWFya3VwXCIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgICAgbHlyaWNzOiBnZW5lcmF0ZWRDb250ZW50LnRyaW0oKSxcbiAgICAgICAgICBtb2RlLFxuICAgICAgICAgIG1lc3NhZ2U6IFwi0KLQtdC60YHRgiDRgNCw0LfQvNC10YfQtdC9IVwiIFxuICAgICAgICB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKG1vZGUgPT09IFwiaWRlYXNcIikge1xuICAgICAgLy8gUGFyc2UgaWRlYXMgZnJvbSByZXNwb25zZVxuICAgICAgY29uc3QgaWRlYXM6IEFycmF5PHtcbiAgICAgICAgdGl0bGU6IHN0cmluZztcbiAgICAgICAgbW9vZDogc3RyaW5nO1xuICAgICAgICBjb25jZXB0OiBzdHJpbmc7XG4gICAgICAgIHRhZ3M6IHN0cmluZztcbiAgICAgICAgbHlyaWNzOiBzdHJpbmc7XG4gICAgICB9PiA9IFtdO1xuXG4gICAgICBjb25zdCBpZGVhQmxvY2tzID0gZ2VuZXJhdGVkQ29udGVudC5zcGxpdCgvLS0tSURFQV9cXGQrLS0tLykuZmlsdGVyKChiOiBzdHJpbmcpID0+IGIudHJpbSgpKTtcbiAgICAgIFxuICAgICAgZm9yIChjb25zdCBibG9jayBvZiBpZGVhQmxvY2tzKSB7XG4gICAgICAgIGNvbnN0IHRpdGxlTWF0Y2ggPSBibG9jay5tYXRjaCgv0J3QkNCX0JLQkNCd0JjQlTpcXHMqKC4rKS9pKTtcbiAgICAgICAgY29uc3QgbW9vZE1hdGNoID0gYmxvY2subWF0Y2goL9Cd0JDQodCi0KDQntCV0J3QmNCVOlxccyooLispL2kpO1xuICAgICAgICBjb25zdCBjb25jZXB0TWF0Y2ggPSBibG9jay5tYXRjaCgv0JrQntCd0KbQldCf0KbQmNCvOlxccyooLispL2kpO1xuICAgICAgICBjb25zdCB0YWdzTWF0Y2ggPSBibG9jay5tYXRjaCgv0KLQldCT0Jg6XFxzKiguKykvaSk7XG4gICAgICAgIGNvbnN0IGx5cmljc01hdGNoID0gYmxvY2subWF0Y2goL9Ci0JXQmtCh0KI6XFxzKihbXFxzXFxTXSs/KSg/PSg/Oi0tLUlERUFffCQpKS9pKTtcblxuICAgICAgICBpZiAodGl0bGVNYXRjaCkge1xuICAgICAgICAgIGlkZWFzLnB1c2goe1xuICAgICAgICAgICAgdGl0bGU6IHRpdGxlTWF0Y2hbMV0udHJpbSgpLFxuICAgICAgICAgICAgbW9vZDogbW9vZE1hdGNoPy5bMV0/LnRyaW0oKSB8fCBcIlwiLFxuICAgICAgICAgICAgY29uY2VwdDogY29uY2VwdE1hdGNoPy5bMV0/LnRyaW0oKSB8fCBcIlwiLFxuICAgICAgICAgICAgdGFnczogdGFnc01hdGNoPy5bMV0/LnRyaW0oKSB8fCBcIlwiLFxuICAgICAgICAgICAgbHlyaWNzOiBseXJpY3NNYXRjaD8uWzFdPy50cmltKCkgfHwgXCJcIixcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICAgIGlkZWFzLFxuICAgICAgICAgIG1vZGUsXG4gICAgICAgICAgbWVzc2FnZTogXCLQmNC00LXQuCDRgdCz0LXQvdC10YDQuNGA0L7QstCw0L3RiyFcIiBcbiAgICAgICAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgbHlyaWNzOiBnZW5lcmF0ZWRDb250ZW50LnRyaW0oKSxcbiAgICAgICAgbW9kZSxcbiAgICAgICAgbWVzc2FnZTogbW9kZSA9PT0gXCJpbXByb3ZlXCIgPyBcItCi0LXQutGB0YIg0YPQu9GD0YfRiNC10L0hXCIgOiBcItCi0LXQutGB0YIg0YHQs9C10L3QtdGA0LjRgNC+0LLQsNC9IVwiIFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIGRlZXBzZWVrLWx5cmljczpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBtZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFJQSxnREFBZ0Q7QUFDaEQsTUFBTSxrQkFBa0I7QUFFeEIsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0Ysb0JBQW9CO0lBQ3BCLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVksV0FBVyxZQUFZO01BQ3RDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF5QixJQUNqRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFdBQVcsYUFDZixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsaUJBQ2IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBR2YsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBRWpFLElBQUksYUFBYSxDQUFDLE1BQU0sUUFBUSxLQUFLO01BQ25DLFFBQVEsS0FBSyxDQUFDLGVBQWU7TUFDN0IsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTZCLElBQ3JEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sVUFBVSxLQUFLLE1BQU0sQ0FBQyxHQUFHO0lBQy9CLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEdBQUcsTUFBTSxJQUFJLElBQUk7SUFRbEUsUUFBUSxHQUFHLENBQUMsMkJBQTJCO01BQUU7TUFBTTtNQUFTLFdBQVcsQ0FBQyxDQUFDO01BQVE7TUFBTztJQUFNO0lBRTFGLE1BQU0sZ0JBQWdCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsZUFBZTtNQUNsQixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLDJEQUEyRDtJQUMzRCxNQUFNLEVBQUUsTUFBTSxPQUFPLEVBQUUsR0FBRyxNQUFNLFNBQzdCLElBQUksQ0FBQyxrQkFDTCxNQUFNLENBQUMsYUFDUCxFQUFFLENBQUMsUUFBUSxtQkFDWCxXQUFXO0lBRWQsTUFBTSxRQUFRLFNBQVMsYUFBYTtJQUVwQyxxQkFBcUI7SUFDckIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxTQUM3QixJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxTQUNkLFdBQVc7SUFFZCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSSxPQUFPO01BQzlDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFrQyxJQUMxRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxpQkFBaUI7SUFDakIsTUFBTSxhQUFhLENBQUMsUUFBUSxPQUFPLElBQUksQ0FBQyxJQUFJO0lBQzVDLE1BQU0sRUFBRSxPQUFPLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbkMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO01BQUUsU0FBUztJQUFXLEdBQzdCLEVBQUUsQ0FBQyxXQUFXO0lBRWpCLElBQUksY0FBYztNQUNoQixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLGtCQUFrQjtJQUNsQixNQUFNLFNBQVMsSUFBSSxDQUFDLHdCQUF3QixNQUFNLENBQUM7TUFDakQsU0FBUztNQUNULFFBQVEsQ0FBQztNQUNULGVBQWU7TUFDZixNQUFNO01BQ04sYUFBYSxDQUFDLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxDQUFDO01BQ3pDLFVBQVU7UUFBRTtNQUFLO0lBQ25CO0lBRUEsNkJBQTZCO0lBQzdCLElBQUk7SUFDSixJQUFJO0lBRUosSUFBSSxTQUFTLFdBQVc7TUFDdEIsZUFBZSxDQUFDOzs7Ozs7Ozs2Q0FRdUIsQ0FBQztNQUV4QyxhQUFhLENBQUMsdUJBQXVCLEVBQUUsUUFBUSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsR0FBRyxHQUFHOztBQUU5RSxFQUFFLE9BQU8sQ0FBQztJQUNOLE9BQU8sSUFBSSxTQUFTLFVBQVU7TUFDNUIsK0JBQStCO01BQy9CLGVBQWUsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tCQWlDSixDQUFDO01BRWIsTUFBTSxXQUFXLGFBQWEsU0FBUyxDQUFDLDBCQUEwQixFQUFFLFlBQVksQ0FBQyxHQUFHO01BQ3BGLGFBQWEsQ0FBQywwQ0FBMEMsRUFBRSxTQUFTOztBQUV6RSxFQUFFLE9BQU8sQ0FBQztJQUNOLE9BQU8sSUFBSSxTQUFTLGlCQUFpQjtNQUNuQyxlQUFlLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7NEVBZ0JzRCxDQUFDO01BRXZFLGFBQWEsQ0FBQzs7QUFFcEIsRUFBRSxPQUFPOztBQUVULEVBQUUsUUFBUSxDQUFDLG1DQUFtQyxFQUFFLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUMxRCxPQUFPLElBQUksU0FBUyxTQUFTO01BQzNCLCtCQUErQjtNQUMvQixlQUFlLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsrREE4QnlDLENBQUM7TUFFMUQsYUFBYSxDQUFDLG1FQUFtRSxDQUFDO0lBQ3BGLE9BQU87TUFDTCxlQUFlO01BQ2YsZUFBZSxDQUFDOzs7Ozs7Ozs7OzZDQVV1QixDQUFDO01BRXhDLE1BQU0sV0FBVyxRQUFRLFVBQVUsU0FBUztNQUM1QyxhQUFhLFdBQ1QsQ0FBQyx3QkFBd0IsRUFBRSxRQUFRLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxHQUFHLEdBQUc7O0FBRXRFLEVBQUUsU0FBUyxDQUFDLEdBQ0YsQ0FBQywrQkFBK0IsRUFBRSxRQUFRLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxHQUFHLEdBQUcsMERBQTBELENBQUM7SUFDcEk7SUFFQSx5QkFBeUI7SUFDekIsTUFBTSxTQUFTLENBQUMsbURBQW1ELEVBQUUsZ0JBQWdCLG9CQUFvQixDQUFDO0lBRTFHLE1BQU0sV0FBVyxNQUFNLE1BQU0sUUFBUTtNQUNuQyxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO1FBQzFDLGtCQUFrQjtNQUNwQjtNQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7UUFDbkIsT0FBTztRQUNQLFVBQVU7VUFDUjtZQUFFLE1BQU07WUFBVSxTQUFTO1VBQWE7VUFDeEM7WUFBRSxNQUFNO1lBQVEsU0FBUztVQUFXO1NBQ3JDO1FBQ0QsYUFBYTtNQUNmO0lBQ0Y7SUFFQSxRQUFRLEdBQUcsQ0FBQyw0QkFBNEIsU0FBUyxNQUFNO0lBRXZELElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRTtNQUNoQixzQkFBc0I7TUFDdEIsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztRQUFFLFNBQVMsUUFBUSxPQUFPO01BQUMsR0FDbEMsRUFBRSxDQUFDLFdBQVc7TUFFakIsTUFBTSxZQUFZLE1BQU0sU0FBUyxJQUFJO01BQ3JDLFFBQVEsS0FBSyxDQUFDLHNCQUFzQixTQUFTLE1BQU0sRUFBRTtNQUNyRCxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sU0FBUyxNQUFNLFNBQVMsSUFBSTtJQUNsQyxRQUFRLEdBQUcsQ0FBQztJQUVaLE1BQU0sbUJBQW1CLE9BQU8sT0FBTyxFQUFFLENBQUMsRUFBRSxFQUFFLFNBQVM7SUFFdkQsSUFBSSxDQUFDLGtCQUFrQjtNQUNyQix5QkFBeUI7TUFDekIsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztRQUFFLFNBQVMsUUFBUSxPQUFPO01BQUMsR0FDbEMsRUFBRSxDQUFDLFdBQVc7TUFDakIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSx1RUFBdUU7SUFDdkUsSUFBSSxTQUFTLG1CQUFtQixTQUFTLFVBQVU7TUFDakQsTUFBTSxTQUNILElBQUksQ0FBQyxvQkFDTCxNQUFNLENBQUM7UUFDTixTQUFTO1FBQ1QsUUFBUSxTQUFTLFlBQVksQ0FBQyxVQUFVLEVBQUUsU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxTQUFTLFNBQVMsR0FBRyxDQUFDO1FBQzlGLFFBQVE7UUFDUixPQUFPO01BQ1Q7SUFDSjtJQUVBLG1DQUFtQztJQUNuQyxJQUFJLFNBQVMsaUJBQWlCO01BQzVCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQ2IsU0FBUztRQUNULGFBQWEsaUJBQWlCLElBQUk7UUFDbEM7UUFDQSxTQUFTO01BQ1gsSUFDQTtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLElBQUksU0FBUyxVQUFVO01BQ3JCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQ2IsU0FBUztRQUNULFFBQVEsaUJBQWlCLElBQUk7UUFDN0I7UUFDQSxTQUFTO01BQ1gsSUFDQTtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLElBQUksU0FBUyxTQUFTO01BQ3BCLDRCQUE0QjtNQUM1QixNQUFNLFFBTUQsRUFBRTtNQUVQLE1BQU0sYUFBYSxpQkFBaUIsS0FBSyxDQUFDLGtCQUFrQixNQUFNLENBQUMsQ0FBQyxJQUFjLEVBQUUsSUFBSTtNQUV4RixLQUFLLE1BQU0sU0FBUyxXQUFZO1FBQzlCLE1BQU0sYUFBYSxNQUFNLEtBQUssQ0FBQztRQUMvQixNQUFNLFlBQVksTUFBTSxLQUFLLENBQUM7UUFDOUIsTUFBTSxlQUFlLE1BQU0sS0FBSyxDQUFDO1FBQ2pDLE1BQU0sWUFBWSxNQUFNLEtBQUssQ0FBQztRQUM5QixNQUFNLGNBQWMsTUFBTSxLQUFLLENBQUM7UUFFaEMsSUFBSSxZQUFZO1VBQ2QsTUFBTSxJQUFJLENBQUM7WUFDVCxPQUFPLFVBQVUsQ0FBQyxFQUFFLENBQUMsSUFBSTtZQUN6QixNQUFNLFdBQVcsQ0FBQyxFQUFFLEVBQUUsVUFBVTtZQUNoQyxTQUFTLGNBQWMsQ0FBQyxFQUFFLEVBQUUsVUFBVTtZQUN0QyxNQUFNLFdBQVcsQ0FBQyxFQUFFLEVBQUUsVUFBVTtZQUNoQyxRQUFRLGFBQWEsQ0FBQyxFQUFFLEVBQUUsVUFBVTtVQUN0QztRQUNGO01BQ0Y7TUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVDtRQUNBO1FBQ0EsU0FBUztNQUNYLElBQ0E7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxRQUFRLGlCQUFpQixJQUFJO01BQzdCO01BQ0EsU0FBUyxTQUFTLFlBQVksbUJBQW1CO0lBQ25ELElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEUsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDZCQUE2QjtJQUMzQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
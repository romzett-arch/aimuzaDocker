const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabaseClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      console.error("Auth error:", claimsError);
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const userId = claimsData.claims.sub;
    // Check if user is admin using the is_admin function
    const { data: isAdmin } = await supabaseClient.rpc("is_admin", {
      _user_id: userId
    });
    if (!isAdmin) {
      return new Response(JSON.stringify({
        error: "Access denied. Admin only."
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Admin ${userId} requesting Suno credits balance`);
    // Fetch credits from Suno API
    const sunoResponse = await fetch(`${SUNO_API_BASE}/api/v1/generate/credit`, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${SUNO_API_KEY}`
      }
    });
    // Check if response is JSON before parsing
    const contentType = sunoResponse.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      const text = await sunoResponse.text();
      console.error("Suno API returned non-JSON:", text.substring(0, 200));
      return new Response(JSON.stringify({
        error: "Suno API unavailable",
        details: `Status: ${sunoResponse.status}, returned HTML instead of JSON`
      }), {
        status: 503,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const sunoData = await sunoResponse.json();
    console.log("Suno credits response:", JSON.stringify(sunoData));
    if (!sunoResponse.ok || sunoData.code !== 200) {
      console.error("Suno API error:", sunoData);
      return new Response(JSON.stringify({
        error: "Failed to fetch Suno credits",
        details: sunoData.msg || "Unknown error"
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const credits = sunoData.data;
    console.log(`Suno credits remaining: ${credits}`);
    return new Response(JSON.stringify({
      success: true,
      credits: credits
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in suno-credits:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9zdW5vLWNyZWRpdHMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmNvbnN0IFNVTk9fQVBJX0tFWSA9IERlbm8uZW52LmdldChcIlNVTk9fQVBJX0tFWVwiKTtcbmNvbnN0IFNVTk9fQVBJX0JBU0UgPSBcImh0dHBzOi8vYXBpYm94LmVyd2VpbWEuYWlcIjtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcj8uc3RhcnRzV2l0aChcIkJlYXJlciBcIikpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiTm8gYXV0aG9yaXphdGlvbiBoZWFkZXJcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlQ2xpZW50ID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpID8/IFwiXCIsXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSA/PyBcIlwiLFxuICAgICAgeyBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfSB9XG4gICAgKTtcblxuICAgIGNvbnN0IHRva2VuID0gYXV0aEhlYWRlci5yZXBsYWNlKFwiQmVhcmVyIFwiLCBcIlwiKTtcbiAgICBjb25zdCB7IGRhdGE6IGNsYWltc0RhdGEsIGVycm9yOiBjbGFpbXNFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnQuYXV0aC5nZXRDbGFpbXModG9rZW4pO1xuICAgIFxuICAgIGlmIChjbGFpbXNFcnJvciB8fCAhY2xhaW1zRGF0YT8uY2xhaW1zPy5zdWIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJBdXRoIGVycm9yOlwiLCBjbGFpbXNFcnJvcik7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHVzZXJJZCA9IGNsYWltc0RhdGEuY2xhaW1zLnN1YjtcblxuICAgIC8vIENoZWNrIGlmIHVzZXIgaXMgYWRtaW4gdXNpbmcgdGhlIGlzX2FkbWluIGZ1bmN0aW9uXG4gICAgY29uc3QgeyBkYXRhOiBpc0FkbWluIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudC5ycGMoXCJpc19hZG1pblwiLCB7IF91c2VyX2lkOiB1c2VySWQgfSk7XG4gICAgXG4gICAgaWYgKCFpc0FkbWluKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkFjY2VzcyBkZW5pZWQuIEFkbWluIG9ubHkuXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDMsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgQWRtaW4gJHt1c2VySWR9IHJlcXVlc3RpbmcgU3VubyBjcmVkaXRzIGJhbGFuY2VgKTtcblxuICAgIC8vIEZldGNoIGNyZWRpdHMgZnJvbSBTdW5vIEFQSVxuICAgIGNvbnN0IHN1bm9SZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke1NVTk9fQVBJX0JBU0V9L2FwaS92MS9nZW5lcmF0ZS9jcmVkaXRgLCB7XG4gICAgICBtZXRob2Q6IFwiR0VUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgLy8gQ2hlY2sgaWYgcmVzcG9uc2UgaXMgSlNPTiBiZWZvcmUgcGFyc2luZ1xuICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gc3Vub1Jlc3BvbnNlLmhlYWRlcnMuZ2V0KFwiY29udGVudC10eXBlXCIpIHx8IFwiXCI7XG4gICAgaWYgKCFjb250ZW50VHlwZS5pbmNsdWRlcyhcImFwcGxpY2F0aW9uL2pzb25cIikpIHtcbiAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCBzdW5vUmVzcG9uc2UudGV4dCgpO1xuICAgICAgY29uc29sZS5lcnJvcihcIlN1bm8gQVBJIHJldHVybmVkIG5vbi1KU09OOlwiLCB0ZXh0LnN1YnN0cmluZygwLCAyMDApKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgZXJyb3I6IFwiU3VubyBBUEkgdW5hdmFpbGFibGVcIixcbiAgICAgICAgICBkZXRhaWxzOiBgU3RhdHVzOiAke3N1bm9SZXNwb25zZS5zdGF0dXN9LCByZXR1cm5lZCBIVE1MIGluc3RlYWQgb2YgSlNPTmBcbiAgICAgICAgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDMsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdW5vRGF0YSA9IGF3YWl0IHN1bm9SZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJTdW5vIGNyZWRpdHMgcmVzcG9uc2U6XCIsIEpTT04uc3RyaW5naWZ5KHN1bm9EYXRhKSk7XG5cbiAgICBpZiAoIXN1bm9SZXNwb25zZS5vayB8fCBzdW5vRGF0YS5jb2RlICE9PSAyMDApIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJTdW5vIEFQSSBlcnJvcjpcIiwgc3Vub0RhdGEpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBlcnJvcjogXCJGYWlsZWQgdG8gZmV0Y2ggU3VubyBjcmVkaXRzXCIsXG4gICAgICAgICAgZGV0YWlsczogc3Vub0RhdGEubXNnIHx8IFwiVW5rbm93biBlcnJvclwiXG4gICAgICAgIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgY3JlZGl0cyA9IHN1bm9EYXRhLmRhdGE7XG4gICAgY29uc29sZS5sb2coYFN1bm8gY3JlZGl0cyByZW1haW5pbmc6ICR7Y3JlZGl0c31gKTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgY3JlZGl0czogY3JlZGl0c1xuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gc3Vuby1jcmVkaXRzOlwiLCBlcnJvcik7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogZXJyb3JNZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2xDLE1BQU0sZ0JBQWdCO0FBRXRCLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVksV0FBVyxZQUFZO01BQ3RDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEwQixJQUNsRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGlCQUFpQixhQUNyQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFDckM7TUFBRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQUU7SUFHdkQsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxTQUFTLENBQUM7SUFFckYsSUFBSSxlQUFlLENBQUMsWUFBWSxRQUFRLEtBQUs7TUFDM0MsUUFBUSxLQUFLLENBQUMsZUFBZTtNQUM3QixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFNBQVMsV0FBVyxNQUFNLENBQUMsR0FBRztJQUVwQyxxREFBcUQ7SUFDckQsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxlQUFlLEdBQUcsQ0FBQyxZQUFZO01BQUUsVUFBVTtJQUFPO0lBRWxGLElBQUksQ0FBQyxTQUFTO01BQ1osT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTZCLElBQ3JEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLE9BQU8sZ0NBQWdDLENBQUM7SUFFN0QsOEJBQThCO0lBQzlCLE1BQU0sZUFBZSxNQUFNLE1BQU0sQ0FBQyxFQUFFLGNBQWMsdUJBQXVCLENBQUMsRUFBRTtNQUMxRSxRQUFRO01BQ1IsU0FBUztRQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7SUFDRjtJQUVBLDJDQUEyQztJQUMzQyxNQUFNLGNBQWMsYUFBYSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQjtJQUNoRSxJQUFJLENBQUMsWUFBWSxRQUFRLENBQUMscUJBQXFCO01BQzdDLE1BQU0sT0FBTyxNQUFNLGFBQWEsSUFBSTtNQUNwQyxRQUFRLEtBQUssQ0FBQywrQkFBK0IsS0FBSyxTQUFTLENBQUMsR0FBRztNQUMvRCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLE9BQU87UUFDUCxTQUFTLENBQUMsUUFBUSxFQUFFLGFBQWEsTUFBTSxDQUFDLCtCQUErQixDQUFDO01BQzFFLElBQ0E7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxXQUFXLE1BQU0sYUFBYSxJQUFJO0lBQ3hDLFFBQVEsR0FBRyxDQUFDLDBCQUEwQixLQUFLLFNBQVMsQ0FBQztJQUVyRCxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksU0FBUyxJQUFJLEtBQUssS0FBSztNQUM3QyxRQUFRLEtBQUssQ0FBQyxtQkFBbUI7TUFDakMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixPQUFPO1FBQ1AsU0FBUyxTQUFTLEdBQUcsSUFBSTtNQUMzQixJQUNBO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sVUFBVSxTQUFTLElBQUk7SUFDN0IsUUFBUSxHQUFHLENBQUMsQ0FBQyx3QkFBd0IsRUFBRSxRQUFRLENBQUM7SUFFaEQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQywwQkFBMEI7SUFDeEMsTUFBTSxlQUFlLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQzlELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFhLElBQ3JDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const body = await req.json();
    const { promo_video_id, status, video_url, thumbnail_url, file_size_bytes, error_message } = body;
    if (!promo_video_id) {
      throw new Error("promo_video_id is required");
    }
    console.log(`Promo video callback: ${promo_video_id}, status: ${status}`);
    // Get promo video record
    const { data: promoVideo, error: fetchError } = await supabase.from("promo_videos").select("id, track_id, user_id").eq("id", promo_video_id).single();
    if (fetchError || !promoVideo) {
      throw new Error("Promo video not found");
    }
    // Update status
    const updateData = {
      status,
      progress: status === "completed" ? 100 : undefined,
      updated_at: new Date().toISOString()
    };
    if (status === "completed") {
      updateData.video_url = video_url;
      updateData.thumbnail_url = thumbnail_url;
      updateData.file_size_bytes = file_size_bytes;
      updateData.completed_at = new Date().toISOString();
      // Send notification to user
      await supabase.from("notifications").insert({
        user_id: promoVideo.user_id,
        type: "system",
        title: "🎬 Промо-видео готово!",
        message: "Ваше промо-видео успешно создано и готово к скачиванию",
        target_type: "promo_video",
        target_id: promo_video_id
      });
    } else if (status === "failed") {
      updateData.error_message = error_message || "Unknown error";
      // Notify user about failure
      await supabase.from("notifications").insert({
        user_id: promoVideo.user_id,
        type: "system",
        title: "Ошибка генерации видео",
        message: error_message || "Не удалось создать промо-видео. Попробуйте ещё раз.",
        target_type: "promo_video",
        target_id: promo_video_id
      });
    }
    const { error: updateError } = await supabase.from("promo_videos").update(updateData).eq("id", promo_video_id);
    if (updateError) {
      console.error("Update error:", updateError);
      throw new Error("Failed to update promo video");
    }
    console.log(`Promo video ${promo_video_id} updated to ${status}`);
    return new Response(JSON.stringify({
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Promo video callback error:", errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9wcm9tby12aWRlby1jYWxsYmFjay50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDIuNDkuMVwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5pbnRlcmZhY2UgQ2FsbGJhY2tEYXRhIHtcbiAgcHJvbW9fdmlkZW9faWQ6IHN0cmluZztcbiAgc3RhdHVzOiBcImNvbXBsZXRlZFwiIHwgXCJmYWlsZWRcIjtcbiAgdmlkZW9fdXJsPzogc3RyaW5nO1xuICB0aHVtYm5haWxfdXJsPzogc3RyaW5nO1xuICBmaWxlX3NpemVfYnl0ZXM/OiBudW1iZXI7XG4gIGVycm9yX21lc3NhZ2U/OiBzdHJpbmc7XG59XG5cbnNlcnZlKGFzeW5jIChyZXE6IFJlcXVlc3QpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlU2VydmljZUtleSk7XG5cbiAgICBjb25zdCBib2R5OiBDYWxsYmFja0RhdGEgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnN0IHsgcHJvbW9fdmlkZW9faWQsIHN0YXR1cywgdmlkZW9fdXJsLCB0aHVtYm5haWxfdXJsLCBmaWxlX3NpemVfYnl0ZXMsIGVycm9yX21lc3NhZ2UgfSA9IGJvZHk7XG5cbiAgICBpZiAoIXByb21vX3ZpZGVvX2lkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJwcm9tb192aWRlb19pZCBpcyByZXF1aXJlZFwiKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgUHJvbW8gdmlkZW8gY2FsbGJhY2s6ICR7cHJvbW9fdmlkZW9faWR9LCBzdGF0dXM6ICR7c3RhdHVzfWApO1xuXG4gICAgLy8gR2V0IHByb21vIHZpZGVvIHJlY29yZFxuICAgIGNvbnN0IHsgZGF0YTogcHJvbW9WaWRlbywgZXJyb3I6IGZldGNoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInByb21vX3ZpZGVvc1wiKVxuICAgICAgLnNlbGVjdChcImlkLCB0cmFja19pZCwgdXNlcl9pZFwiKVxuICAgICAgLmVxKFwiaWRcIiwgcHJvbW9fdmlkZW9faWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoZmV0Y2hFcnJvciB8fCAhcHJvbW9WaWRlbykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUHJvbW8gdmlkZW8gbm90IGZvdW5kXCIpO1xuICAgIH1cblxuICAgIC8vIFVwZGF0ZSBzdGF0dXNcbiAgICBjb25zdCB1cGRhdGVEYXRhOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHtcbiAgICAgIHN0YXR1cyxcbiAgICAgIHByb2dyZXNzOiBzdGF0dXMgPT09IFwiY29tcGxldGVkXCIgPyAxMDAgOiB1bmRlZmluZWQsXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfTtcblxuICAgIGlmIChzdGF0dXMgPT09IFwiY29tcGxldGVkXCIpIHtcbiAgICAgIHVwZGF0ZURhdGEudmlkZW9fdXJsID0gdmlkZW9fdXJsO1xuICAgICAgdXBkYXRlRGF0YS50aHVtYm5haWxfdXJsID0gdGh1bWJuYWlsX3VybDtcbiAgICAgIHVwZGF0ZURhdGEuZmlsZV9zaXplX2J5dGVzID0gZmlsZV9zaXplX2J5dGVzO1xuICAgICAgdXBkYXRlRGF0YS5jb21wbGV0ZWRfYXQgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG5cbiAgICAgIC8vIFNlbmQgbm90aWZpY2F0aW9uIHRvIHVzZXJcbiAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oXCJub3RpZmljYXRpb25zXCIpLmluc2VydCh7XG4gICAgICAgIHVzZXJfaWQ6IHByb21vVmlkZW8udXNlcl9pZCxcbiAgICAgICAgdHlwZTogXCJzeXN0ZW1cIixcbiAgICAgICAgdGl0bGU6IFwi8J+OrCDQn9GA0L7QvNC+LdCy0LjQtNC10L4g0LPQvtGC0L7QstC+IVwiLFxuICAgICAgICBtZXNzYWdlOiBcItCS0LDRiNC1INC/0YDQvtC80L4t0LLQuNC00LXQviDRg9GB0L/QtdGI0L3QviDRgdC+0LfQtNCw0L3QviDQuCDQs9C+0YLQvtCy0L4g0Log0YHQutCw0YfQuNCy0LDQvdC40Y5cIixcbiAgICAgICAgdGFyZ2V0X3R5cGU6IFwicHJvbW9fdmlkZW9cIixcbiAgICAgICAgdGFyZ2V0X2lkOiBwcm9tb192aWRlb19pZCxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoc3RhdHVzID09PSBcImZhaWxlZFwiKSB7XG4gICAgICB1cGRhdGVEYXRhLmVycm9yX21lc3NhZ2UgPSBlcnJvcl9tZXNzYWdlIHx8IFwiVW5rbm93biBlcnJvclwiO1xuXG4gICAgICAvLyBOb3RpZnkgdXNlciBhYm91dCBmYWlsdXJlXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwibm90aWZpY2F0aW9uc1wiKS5pbnNlcnQoe1xuICAgICAgICB1c2VyX2lkOiBwcm9tb1ZpZGVvLnVzZXJfaWQsXG4gICAgICAgIHR5cGU6IFwic3lzdGVtXCIsXG4gICAgICAgIHRpdGxlOiBcItCe0YjQuNCx0LrQsCDQs9C10L3QtdGA0LDRhtC40Lgg0LLQuNC00LXQvlwiLFxuICAgICAgICBtZXNzYWdlOiBlcnJvcl9tZXNzYWdlIHx8IFwi0J3QtSDRg9C00LDQu9C+0YHRjCDRgdC+0LfQtNCw0YLRjCDQv9GA0L7QvNC+LdCy0LjQtNC10L4uINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC10YnRkSDRgNCw0LcuXCIsXG4gICAgICAgIHRhcmdldF90eXBlOiBcInByb21vX3ZpZGVvXCIsXG4gICAgICAgIHRhcmdldF9pZDogcHJvbW9fdmlkZW9faWQsXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicHJvbW9fdmlkZW9zXCIpXG4gICAgICAudXBkYXRlKHVwZGF0ZURhdGEpXG4gICAgICAuZXEoXCJpZFwiLCBwcm9tb192aWRlb19pZCk7XG5cbiAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJVcGRhdGUgZXJyb3I6XCIsIHVwZGF0ZUVycm9yKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgcHJvbW8gdmlkZW9cIik7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFByb21vIHZpZGVvICR7cHJvbW9fdmlkZW9faWR9IHVwZGF0ZWQgdG8gJHtzdGF0dXN9YCk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiB0cnVlIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICBjb25zb2xlLmVycm9yKFwiUHJvbW8gdmlkZW8gY2FsbGJhY2sgZXJyb3I6XCIsIGVycm9yTWVzc2FnZSk7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBlcnJvck1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBQ25GLFNBQVMsWUFBWSxRQUFRLDhDQUE4QztBQUUzRSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQVdBLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDakMsTUFBTSxxQkFBcUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ3hDLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0MsTUFBTSxPQUFxQixNQUFNLElBQUksSUFBSTtJQUN6QyxNQUFNLEVBQUUsY0FBYyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLGVBQWUsRUFBRSxhQUFhLEVBQUUsR0FBRztJQUU3RixJQUFJLENBQUMsZ0JBQWdCO01BQ25CLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsRUFBRSxlQUFlLFVBQVUsRUFBRSxPQUFPLENBQUM7SUFFeEUseUJBQXlCO0lBQ3pCLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxPQUFPLFVBQVUsRUFBRSxHQUFHLE1BQU0sU0FDbkQsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyx5QkFDUCxFQUFFLENBQUMsTUFBTSxnQkFDVCxNQUFNO0lBRVQsSUFBSSxjQUFjLENBQUMsWUFBWTtNQUM3QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLGdCQUFnQjtJQUNoQixNQUFNLGFBQXNDO01BQzFDO01BQ0EsVUFBVSxXQUFXLGNBQWMsTUFBTTtNQUN6QyxZQUFZLElBQUksT0FBTyxXQUFXO0lBQ3BDO0lBRUEsSUFBSSxXQUFXLGFBQWE7TUFDMUIsV0FBVyxTQUFTLEdBQUc7TUFDdkIsV0FBVyxhQUFhLEdBQUc7TUFDM0IsV0FBVyxlQUFlLEdBQUc7TUFDN0IsV0FBVyxZQUFZLEdBQUcsSUFBSSxPQUFPLFdBQVc7TUFFaEQsNEJBQTRCO01BQzVCLE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztRQUMxQyxTQUFTLFdBQVcsT0FBTztRQUMzQixNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVM7UUFDVCxhQUFhO1FBQ2IsV0FBVztNQUNiO0lBQ0YsT0FBTyxJQUFJLFdBQVcsVUFBVTtNQUM5QixXQUFXLGFBQWEsR0FBRyxpQkFBaUI7TUFFNUMsNEJBQTRCO01BQzVCLE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztRQUMxQyxTQUFTLFdBQVcsT0FBTztRQUMzQixNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVMsaUJBQWlCO1FBQzFCLGFBQWE7UUFDYixXQUFXO01BQ2I7SUFDRjtJQUVBLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyxZQUNQLEVBQUUsQ0FBQyxNQUFNO0lBRVosSUFBSSxhQUFhO01BQ2YsUUFBUSxLQUFLLENBQUMsaUJBQWlCO01BQy9CLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxZQUFZLEVBQUUsZUFBZSxZQUFZLEVBQUUsT0FBTyxDQUFDO0lBRWhFLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztJQUFLLElBQy9CO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsTUFBTSxlQUFlLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQzlELFFBQVEsS0FBSyxDQUFDLCtCQUErQjtJQUM3QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLFNBQVM7TUFBTyxPQUFPO0lBQWEsSUFDckQ7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseAdmin = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabaseClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      console.error("Auth error:", claimsError);
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const userId = claimsData.claims.sub;
    // Check if user is admin (roles are in user_roles table, not profiles)
    const { data: roles } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", userId);
    const isAdmin = roles?.some((r)=>r.role === "admin" || r.role === "super_admin");
    if (!isAdmin) {
      return new Response(JSON.stringify({
        error: "Forbidden: admin only"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { trackId } = await req.json();
    if (!trackId) {
      return new Response(JSON.stringify({
        error: "Missing trackId"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Get track data
    const { data: track, error: trackError } = await supabaseAdmin.from("tracks").select("*").eq("id", trackId).single();
    if (trackError || !track) {
      return new Response(JSON.stringify({
        error: "Track not found"
      }), {
        status: 404,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`[Admin Recheck] Track ${trackId}, status: ${track.status}`);
    // Check if track already has permanent audio stored in our Supabase storage
    const supabaseStorageUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const hasLocalAudio = track.audio_url && track.audio_url.includes(supabaseStorageUrl);
    if (hasLocalAudio && track.status === "completed") {
      return new Response(JSON.stringify({
        success: true,
        status: "completed",
        message: "Трек уже готов и сохранён в нашем хранилище",
        audio_url: track.audio_url
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Extract task_id from description
    const taskIdMatch = track.description?.match(/\[task_id:([^\]]+)\]/);
    const taskId = taskIdMatch?.[1]?.trim();
    if (!taskId) {
      // If no task_id but track has audio, it's still usable
      if (track.audio_url) {
        return new Response(JSON.stringify({
          success: true,
          status: "completed",
          message: "Трек имеет аудио, но task_id не найден. Возможно, был создан вручную.",
          audio_url: track.audio_url
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      return new Response(JSON.stringify({
        success: false,
        error: "No task_id found in track description",
        message: "Трек не содержит task_id для проверки"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`[Admin Recheck] Checking Suno task ${taskId}`);
    // Check status with Suno API
    const statusResponse = await fetch(`${SUNO_API_BASE}/api/v1/generate/record?taskId=${taskId}`, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${SUNO_API_KEY}`
      }
    });
    const statusData = await statusResponse.json();
    console.log(`[Admin Recheck] Suno response:`, JSON.stringify(statusData));
    if (statusData.code === 200 && statusData.data) {
      const records = statusData.data.response?.sunoData || statusData.data.data || [];
      const taskStatus = statusData.data.status;
      console.log(`[Admin Recheck] Task status: ${taskStatus}, Records: ${records.length}`);
      // Check for completed status with audio
      if (records.length > 0 && records[0].audio_url) {
        const record = records[0];
        // Download and store audio permanently
        let permanentAudioUrl = record.audio_url;
        let permanentCoverUrl = record.image_url || track.cover_url;
        try {
          // Download audio
          const audioResponse = await fetch(record.audio_url);
          if (audioResponse.ok) {
            const audioBuffer = await audioResponse.arrayBuffer();
            const audioPath = `${track.user_id}/${trackId}.mp3`;
            const { error: audioUploadError } = await supabaseAdmin.storage.from("tracks").upload(audioPath, audioBuffer, {
              contentType: "audio/mpeg",
              upsert: true
            });
            if (!audioUploadError) {
              const { data: audioUrlData } = supabaseAdmin.storage.from("tracks").getPublicUrl(audioPath);
              permanentAudioUrl = audioUrlData.publicUrl;
              console.log(`[Admin Recheck] Audio saved: ${permanentAudioUrl}`);
            } else {
              console.error(`[Admin Recheck] Audio upload error:`, audioUploadError);
            }
          }
          // Download cover if available
          if (record.image_url) {
            const coverResponse = await fetch(record.image_url);
            if (coverResponse.ok) {
              const coverBuffer = await coverResponse.arrayBuffer();
              const coverPath = `${track.user_id}/${trackId}-cover.jpg`;
              const { error: coverUploadError } = await supabaseAdmin.storage.from("tracks").upload(coverPath, coverBuffer, {
                contentType: "image/jpeg",
                upsert: true
              });
              if (!coverUploadError) {
                const { data: coverUrlData } = supabaseAdmin.storage.from("tracks").getPublicUrl(coverPath);
                permanentCoverUrl = coverUrlData.publicUrl;
                console.log(`[Admin Recheck] Cover saved: ${permanentCoverUrl}`);
              }
            }
          }
        } catch (downloadError) {
          console.error(`[Admin Recheck] Download error:`, downloadError);
        // Continue with original URLs if download fails
        }
        // Update track with audio URL
        const { error: updateError } = await supabaseAdmin.from("tracks").update({
          audio_url: permanentAudioUrl,
          cover_url: permanentCoverUrl,
          duration: record.duration ? Math.round(record.duration) : null,
          status: "completed",
          error_message: null,
          suno_audio_id: record.id || null
        }).eq("id", trackId);
        if (updateError) {
          console.error("[Admin Recheck] Error updating track:", updateError);
          return new Response(JSON.stringify({
            success: false,
            error: updateError.message
          }), {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json"
            }
          });
        }
        return new Response(JSON.stringify({
          success: true,
          status: "completed",
          message: "Трек успешно обновлён!",
          audio_url: permanentAudioUrl
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Check for failed status
      if (taskStatus === "GENERATE_AUDIO_FAILED" || taskStatus === "FAILED" || taskStatus === "ERROR") {
        const errorMessage = statusData.data.fail_reason || statusData.data.error_message || "Генерация отклонена сервисом";
        await supabaseAdmin.from("tracks").update({
          status: "failed",
          error_message: errorMessage
        }).eq("id", trackId);
        return new Response(JSON.stringify({
          success: false,
          status: "failed",
          message: `Ошибка генерации: ${errorMessage}`
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Still processing
      return new Response(JSON.stringify({
        success: false,
        status: taskStatus || "processing",
        message: `Статус: ${taskStatus}. Трек ещё генерируется.`
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // API returned error or no data - check if it's a 404 (task expired)
    if (statusData.status === 404 || statusData.error === "Not Found") {
      // Task no longer exists on Suno servers - check if we have local audio
      if (track.audio_url) {
        // We have audio, just update status to completed
        await supabaseAdmin.from("tracks").update({
          status: "completed",
          error_message: null
        }).eq("id", trackId);
        return new Response(JSON.stringify({
          success: true,
          status: "completed",
          message: "Задача удалена с сервера Suno, но аудио доступно. Статус обновлён.",
          audio_url: track.audio_url
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      return new Response(JSON.stringify({
        success: false,
        status: "expired",
        message: "Задача удалена с сервера Suno и аудио недоступно. Генерация не может быть восстановлена."
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    return new Response(JSON.stringify({
      success: false,
      status: "unknown",
      message: `Suno API ответил: ${statusData.msg || statusData.error || "Unknown error"}`,
      raw: statusData
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("[Admin Recheck] Error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9hZG1pbi1yZWNoZWNrLXRyYWNrLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5jb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG5jb25zdCBTVU5PX0FQSV9CQVNFID0gXCJodHRwczovL2FwaWJveC5lcndlaW1hLmFpXCI7XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXI/LnN0YXJ0c1dpdGgoXCJCZWFyZXIgXCIpKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk5vIGF1dGhvcml6YXRpb24gaGVhZGVyXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZUFkbWluID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpID8/IFwiXCIsXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpID8/IFwiXCJcbiAgICApO1xuXG4gICAgY29uc3Qgc3VwYWJhc2VDbGllbnQgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgPz8gXCJcIixcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX0FOT05fS0VZXCIpID8/IFwiXCIsXG4gICAgICB7IGdsb2JhbDogeyBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGF1dGhIZWFkZXIgfSB9IH1cbiAgICApO1xuXG4gICAgY29uc3QgdG9rZW4gPSBhdXRoSGVhZGVyLnJlcGxhY2UoXCJCZWFyZXIgXCIsIFwiXCIpO1xuICAgIGNvbnN0IHsgZGF0YTogY2xhaW1zRGF0YSwgZXJyb3I6IGNsYWltc0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudC5hdXRoLmdldENsYWltcyh0b2tlbik7XG4gICAgXG4gICAgaWYgKGNsYWltc0Vycm9yIHx8ICFjbGFpbXNEYXRhPy5jbGFpbXM/LnN1Yikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkF1dGggZXJyb3I6XCIsIGNsYWltc0Vycm9yKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG4gICAgXG4gICAgY29uc3QgdXNlcklkID0gY2xhaW1zRGF0YS5jbGFpbXMuc3ViO1xuXG4gICAgLy8gQ2hlY2sgaWYgdXNlciBpcyBhZG1pbiAocm9sZXMgYXJlIGluIHVzZXJfcm9sZXMgdGFibGUsIG5vdCBwcm9maWxlcylcbiAgICBjb25zdCB7IGRhdGE6IHJvbGVzIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAuZnJvbShcInVzZXJfcm9sZXNcIilcbiAgICAgIC5zZWxlY3QoXCJyb2xlXCIpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZCk7XG5cbiAgICBjb25zdCBpc0FkbWluID0gcm9sZXM/LnNvbWUociA9PiByLnJvbGUgPT09IFwiYWRtaW5cIiB8fCByLnJvbGUgPT09IFwic3VwZXJfYWRtaW5cIik7XG4gICAgaWYgKCFpc0FkbWluKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkZvcmJpZGRlbjogYWRtaW4gb25seVwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgeyB0cmFja0lkIH0gPSBhd2FpdCByZXEuanNvbigpO1xuXG4gICAgaWYgKCF0cmFja0lkKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk1pc3NpbmcgdHJhY2tJZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gR2V0IHRyYWNrIGRhdGFcbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrLCBlcnJvcjogdHJhY2tFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgIC5zZWxlY3QoXCIqXCIpXG4gICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKHRyYWNrRXJyb3IgfHwgIXRyYWNrKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlRyYWNrIG5vdCBmb3VuZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDA0LCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFtBZG1pbiBSZWNoZWNrXSBUcmFjayAke3RyYWNrSWR9LCBzdGF0dXM6ICR7dHJhY2suc3RhdHVzfWApO1xuXG4gICAgLy8gQ2hlY2sgaWYgdHJhY2sgYWxyZWFkeSBoYXMgcGVybWFuZW50IGF1ZGlvIHN0b3JlZCBpbiBvdXIgU3VwYWJhc2Ugc3RvcmFnZVxuICAgIGNvbnN0IHN1cGFiYXNlU3RvcmFnZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiO1xuICAgIGNvbnN0IGhhc0xvY2FsQXVkaW8gPSB0cmFjay5hdWRpb191cmwgJiYgdHJhY2suYXVkaW9fdXJsLmluY2x1ZGVzKHN1cGFiYXNlU3RvcmFnZVVybCk7XG4gICAgXG4gICAgaWYgKGhhc0xvY2FsQXVkaW8gJiYgdHJhY2suc3RhdHVzID09PSBcImNvbXBsZXRlZFwiKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgIG1lc3NhZ2U6IFwi0KLRgNC10Log0YPQttC1INCz0L7RgtC+0LIg0Lgg0YHQvtGF0YDQsNC90ZHQvSDQsiDQvdCw0YjQtdC8INGF0YDQsNC90LjQu9C40YnQtVwiLFxuICAgICAgICAgIGF1ZGlvX3VybDogdHJhY2suYXVkaW9fdXJsXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBFeHRyYWN0IHRhc2tfaWQgZnJvbSBkZXNjcmlwdGlvblxuICAgIGNvbnN0IHRhc2tJZE1hdGNoID0gdHJhY2suZGVzY3JpcHRpb24/Lm1hdGNoKC9cXFt0YXNrX2lkOihbXlxcXV0rKVxcXS8pO1xuICAgIGNvbnN0IHRhc2tJZCA9IHRhc2tJZE1hdGNoPy5bMV0/LnRyaW0oKTtcblxuICAgIGlmICghdGFza0lkKSB7XG4gICAgICAvLyBJZiBubyB0YXNrX2lkIGJ1dCB0cmFjayBoYXMgYXVkaW8sIGl0J3Mgc3RpbGwgdXNhYmxlXG4gICAgICBpZiAodHJhY2suYXVkaW9fdXJsKSB7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcItCi0YDQtdC6INC40LzQtdC10YIg0LDRg9C00LjQviwg0L3QviB0YXNrX2lkINC90LUg0L3QsNC50LTQtdC9LiDQktC+0LfQvNC+0LbQvdC+LCDQsdGL0Lsg0YHQvtC30LTQsNC9INCy0YDRg9GH0L3Rg9GOLlwiLFxuICAgICAgICAgICAgYXVkaW9fdXJsOiB0cmFjay5hdWRpb191cmxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgIGVycm9yOiBcIk5vIHRhc2tfaWQgZm91bmQgaW4gdHJhY2sgZGVzY3JpcHRpb25cIixcbiAgICAgICAgICBtZXNzYWdlOiBcItCi0YDQtdC6INC90LUg0YHQvtC00LXRgNC20LjRgiB0YXNrX2lkINC00LvRjyDQv9GA0L7QstC10YDQutC4XCJcbiAgICAgICAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBbQWRtaW4gUmVjaGVja10gQ2hlY2tpbmcgU3VubyB0YXNrICR7dGFza0lkfWApO1xuXG4gICAgLy8gQ2hlY2sgc3RhdHVzIHdpdGggU3VubyBBUElcbiAgICBjb25zdCBzdGF0dXNSZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke1NVTk9fQVBJX0JBU0V9L2FwaS92MS9nZW5lcmF0ZS9yZWNvcmQ/dGFza0lkPSR7dGFza0lkfWAsIHtcbiAgICAgIG1ldGhvZDogXCJHRVRcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICBjb25zdCBzdGF0dXNEYXRhID0gYXdhaXQgc3RhdHVzUmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKGBbQWRtaW4gUmVjaGVja10gU3VubyByZXNwb25zZTpgLCBKU09OLnN0cmluZ2lmeShzdGF0dXNEYXRhKSk7XG5cbiAgICBpZiAoc3RhdHVzRGF0YS5jb2RlID09PSAyMDAgJiYgc3RhdHVzRGF0YS5kYXRhKSB7XG4gICAgICBjb25zdCByZWNvcmRzID0gc3RhdHVzRGF0YS5kYXRhLnJlc3BvbnNlPy5zdW5vRGF0YSB8fCBzdGF0dXNEYXRhLmRhdGEuZGF0YSB8fCBbXTtcbiAgICAgIGNvbnN0IHRhc2tTdGF0dXMgPSBzdGF0dXNEYXRhLmRhdGEuc3RhdHVzO1xuICAgICAgXG4gICAgICBjb25zb2xlLmxvZyhgW0FkbWluIFJlY2hlY2tdIFRhc2sgc3RhdHVzOiAke3Rhc2tTdGF0dXN9LCBSZWNvcmRzOiAke3JlY29yZHMubGVuZ3RofWApO1xuICAgICAgXG4gICAgICAvLyBDaGVjayBmb3IgY29tcGxldGVkIHN0YXR1cyB3aXRoIGF1ZGlvXG4gICAgICBpZiAocmVjb3Jkcy5sZW5ndGggPiAwICYmIHJlY29yZHNbMF0uYXVkaW9fdXJsKSB7XG4gICAgICAgIGNvbnN0IHJlY29yZCA9IHJlY29yZHNbMF07XG4gICAgICAgIFxuICAgICAgICAvLyBEb3dubG9hZCBhbmQgc3RvcmUgYXVkaW8gcGVybWFuZW50bHlcbiAgICAgICAgbGV0IHBlcm1hbmVudEF1ZGlvVXJsID0gcmVjb3JkLmF1ZGlvX3VybDtcbiAgICAgICAgbGV0IHBlcm1hbmVudENvdmVyVXJsID0gcmVjb3JkLmltYWdlX3VybCB8fCB0cmFjay5jb3Zlcl91cmw7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAvLyBEb3dubG9hZCBhdWRpb1xuICAgICAgICAgIGNvbnN0IGF1ZGlvUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChyZWNvcmQuYXVkaW9fdXJsKTtcbiAgICAgICAgICBpZiAoYXVkaW9SZXNwb25zZS5vaykge1xuICAgICAgICAgICAgY29uc3QgYXVkaW9CdWZmZXIgPSBhd2FpdCBhdWRpb1Jlc3BvbnNlLmFycmF5QnVmZmVyKCk7XG4gICAgICAgICAgICBjb25zdCBhdWRpb1BhdGggPSBgJHt0cmFjay51c2VyX2lkfS8ke3RyYWNrSWR9Lm1wM2A7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGNvbnN0IHsgZXJyb3I6IGF1ZGlvVXBsb2FkRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW4uc3RvcmFnZVxuICAgICAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgICAgICAudXBsb2FkKGF1ZGlvUGF0aCwgYXVkaW9CdWZmZXIsIHtcbiAgICAgICAgICAgICAgICBjb250ZW50VHlwZTogXCJhdWRpby9tcGVnXCIsXG4gICAgICAgICAgICAgICAgdXBzZXJ0OiB0cnVlLFxuICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgaWYgKCFhdWRpb1VwbG9hZEVycm9yKSB7XG4gICAgICAgICAgICAgIGNvbnN0IHsgZGF0YTogYXVkaW9VcmxEYXRhIH0gPSBzdXBhYmFzZUFkbWluLnN0b3JhZ2VcbiAgICAgICAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgICAgICAgIC5nZXRQdWJsaWNVcmwoYXVkaW9QYXRoKTtcbiAgICAgICAgICAgICAgcGVybWFuZW50QXVkaW9VcmwgPSBhdWRpb1VybERhdGEucHVibGljVXJsO1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgW0FkbWluIFJlY2hlY2tdIEF1ZGlvIHNhdmVkOiAke3Blcm1hbmVudEF1ZGlvVXJsfWApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgW0FkbWluIFJlY2hlY2tdIEF1ZGlvIHVwbG9hZCBlcnJvcjpgLCBhdWRpb1VwbG9hZEVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBEb3dubG9hZCBjb3ZlciBpZiBhdmFpbGFibGVcbiAgICAgICAgICBpZiAocmVjb3JkLmltYWdlX3VybCkge1xuICAgICAgICAgICAgY29uc3QgY292ZXJSZXNwb25zZSA9IGF3YWl0IGZldGNoKHJlY29yZC5pbWFnZV91cmwpO1xuICAgICAgICAgICAgaWYgKGNvdmVyUmVzcG9uc2Uub2spIHtcbiAgICAgICAgICAgICAgY29uc3QgY292ZXJCdWZmZXIgPSBhd2FpdCBjb3ZlclJlc3BvbnNlLmFycmF5QnVmZmVyKCk7XG4gICAgICAgICAgICAgIGNvbnN0IGNvdmVyUGF0aCA9IGAke3RyYWNrLnVzZXJfaWR9LyR7dHJhY2tJZH0tY292ZXIuanBnYDtcbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIGNvbnN0IHsgZXJyb3I6IGNvdmVyVXBsb2FkRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW4uc3RvcmFnZVxuICAgICAgICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgICAgICAgLnVwbG9hZChjb3ZlclBhdGgsIGNvdmVyQnVmZmVyLCB7XG4gICAgICAgICAgICAgICAgICBjb250ZW50VHlwZTogXCJpbWFnZS9qcGVnXCIsXG4gICAgICAgICAgICAgICAgICB1cHNlcnQ6IHRydWUsXG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgaWYgKCFjb3ZlclVwbG9hZEVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBkYXRhOiBjb3ZlclVybERhdGEgfSA9IHN1cGFiYXNlQWRtaW4uc3RvcmFnZVxuICAgICAgICAgICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAgICAgICAgIC5nZXRQdWJsaWNVcmwoY292ZXJQYXRoKTtcbiAgICAgICAgICAgICAgICBwZXJtYW5lbnRDb3ZlclVybCA9IGNvdmVyVXJsRGF0YS5wdWJsaWNVcmw7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYFtBZG1pbiBSZWNoZWNrXSBDb3ZlciBzYXZlZDogJHtwZXJtYW5lbnRDb3ZlclVybH1gKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZG93bmxvYWRFcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFtBZG1pbiBSZWNoZWNrXSBEb3dubG9hZCBlcnJvcjpgLCBkb3dubG9hZEVycm9yKTtcbiAgICAgICAgICAvLyBDb250aW51ZSB3aXRoIG9yaWdpbmFsIFVSTHMgaWYgZG93bmxvYWQgZmFpbHNcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFVwZGF0ZSB0cmFjayB3aXRoIGF1ZGlvIFVSTFxuICAgICAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgICBhdWRpb191cmw6IHBlcm1hbmVudEF1ZGlvVXJsLFxuICAgICAgICAgICAgY292ZXJfdXJsOiBwZXJtYW5lbnRDb3ZlclVybCxcbiAgICAgICAgICAgIGR1cmF0aW9uOiByZWNvcmQuZHVyYXRpb24gPyBNYXRoLnJvdW5kKHJlY29yZC5kdXJhdGlvbikgOiBudWxsLFxuICAgICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgICAgZXJyb3JfbWVzc2FnZTogbnVsbCxcbiAgICAgICAgICAgIHN1bm9fYXVkaW9faWQ6IHJlY29yZC5pZCB8fCBudWxsLFxuICAgICAgICAgIH0pXG4gICAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZCk7XG5cbiAgICAgICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIltBZG1pbiBSZWNoZWNrXSBFcnJvciB1cGRhdGluZyB0cmFjazpcIiwgdXBkYXRlRXJyb3IpO1xuICAgICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICAgICAgZXJyb3I6IHVwZGF0ZUVycm9yLm1lc3NhZ2VcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgIHN0YXR1czogXCJjb21wbGV0ZWRcIixcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwi0KLRgNC10Log0YPRgdC/0LXRiNC90L4g0L7QsdC90L7QstC70ZHQvSFcIixcbiAgICAgICAgICAgIGF1ZGlvX3VybDogcGVybWFuZW50QXVkaW9VcmxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgXG4gICAgICAvLyBDaGVjayBmb3IgZmFpbGVkIHN0YXR1c1xuICAgICAgaWYgKHRhc2tTdGF0dXMgPT09IFwiR0VORVJBVEVfQVVESU9fRkFJTEVEXCIgfHwgdGFza1N0YXR1cyA9PT0gXCJGQUlMRURcIiB8fCB0YXNrU3RhdHVzID09PSBcIkVSUk9SXCIpIHtcbiAgICAgICAgY29uc3QgZXJyb3JNZXNzYWdlID0gc3RhdHVzRGF0YS5kYXRhLmZhaWxfcmVhc29uIHx8IHN0YXR1c0RhdGEuZGF0YS5lcnJvcl9tZXNzYWdlIHx8IFwi0JPQtdC90LXRgNCw0YbQuNGPINC+0YLQutC70L7QvdC10L3QsCDRgdC10YDQstC40YHQvtC8XCI7XG4gICAgICAgIFxuICAgICAgICBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgICAgIGVycm9yX21lc3NhZ2U6IGVycm9yTWVzc2FnZSxcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpO1xuXG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLFxuICAgICAgICAgICAgbWVzc2FnZTogYNCe0YjQuNCx0LrQsCDQs9C10L3QtdGA0LDRhtC40Lg6ICR7ZXJyb3JNZXNzYWdlfWBcbiAgICAgICAgICB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICAvLyBTdGlsbCBwcm9jZXNzaW5nXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgIHN0YXR1czogdGFza1N0YXR1cyB8fCBcInByb2Nlc3NpbmdcIixcbiAgICAgICAgICBtZXNzYWdlOiBg0KHRgtCw0YLRg9GBOiAke3Rhc2tTdGF0dXN9LiDQotGA0LXQuiDQtdGJ0ZEg0LPQtdC90LXRgNC40YDRg9C10YLRgdGPLmBcbiAgICAgICAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cbiAgICBcbiAgICAvLyBBUEkgcmV0dXJuZWQgZXJyb3Igb3Igbm8gZGF0YSAtIGNoZWNrIGlmIGl0J3MgYSA0MDQgKHRhc2sgZXhwaXJlZClcbiAgICBpZiAoc3RhdHVzRGF0YS5zdGF0dXMgPT09IDQwNCB8fCBzdGF0dXNEYXRhLmVycm9yID09PSBcIk5vdCBGb3VuZFwiKSB7XG4gICAgICAvLyBUYXNrIG5vIGxvbmdlciBleGlzdHMgb24gU3VubyBzZXJ2ZXJzIC0gY2hlY2sgaWYgd2UgaGF2ZSBsb2NhbCBhdWRpb1xuICAgICAgaWYgKHRyYWNrLmF1ZGlvX3VybCkge1xuICAgICAgICAvLyBXZSBoYXZlIGF1ZGlvLCBqdXN0IHVwZGF0ZSBzdGF0dXMgdG8gY29tcGxldGVkXG4gICAgICAgIGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgICAgZXJyb3JfbWVzc2FnZTogbnVsbCxcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpO1xuXG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcItCX0LDQtNCw0YfQsCDRg9C00LDQu9C10L3QsCDRgSDRgdC10YDQstC10YDQsCBTdW5vLCDQvdC+INCw0YPQtNC40L4g0LTQvtGB0YLRg9C/0L3Qvi4g0KHRgtCw0YLRg9GBINC+0LHQvdC+0LLQu9GR0L0uXCIsXG4gICAgICAgICAgICBhdWRpb191cmw6IHRyYWNrLmF1ZGlvX3VybFxuICAgICAgICAgIH0pLFxuICAgICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgICAgc3RhdHVzOiBcImV4cGlyZWRcIixcbiAgICAgICAgICBtZXNzYWdlOiBcItCX0LDQtNCw0YfQsCDRg9C00LDQu9C10L3QsCDRgSDRgdC10YDQstC10YDQsCBTdW5vINC4INCw0YPQtNC40L4g0L3QtdC00L7RgdGC0YPQv9C90L4uINCT0LXQvdC10YDQsNGG0LjRjyDQvdC1INC80L7QttC10YIg0LHRi9GC0Ywg0LLQvtGB0YHRgtCw0L3QvtCy0LvQtdC90LAuXCJcbiAgICAgICAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgc3RhdHVzOiBcInVua25vd25cIixcbiAgICAgICAgbWVzc2FnZTogYFN1bm8gQVBJINC+0YLQstC10YLQuNC7OiAke3N0YXR1c0RhdGEubXNnIHx8IHN0YXR1c0RhdGEuZXJyb3IgfHwgXCJVbmtub3duIGVycm9yXCJ9YCxcbiAgICAgICAgcmF3OiBzdGF0dXNEYXRhXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJbQWRtaW4gUmVjaGVja10gRXJyb3I6XCIsIGVycm9yKTtcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBlcnJvck1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBQ25GLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDbEMsTUFBTSxnQkFBZ0I7QUFFdEIsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWSxXQUFXLFlBQVk7TUFDdEMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTBCLElBQ2xEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sZ0JBQWdCLGFBQ3BCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFDaEMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdDQUFnQztJQUcvQyxNQUFNLGlCQUFpQixhQUNyQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFDckM7TUFBRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQUU7SUFHdkQsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxTQUFTLENBQUM7SUFFckYsSUFBSSxlQUFlLENBQUMsWUFBWSxRQUFRLEtBQUs7TUFDM0MsUUFBUSxLQUFLLENBQUMsZUFBZTtNQUM3QixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFNBQVMsV0FBVyxNQUFNLENBQUMsR0FBRztJQUVwQyx1RUFBdUU7SUFDdkUsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLEdBQUcsTUFBTSxjQUMzQixJQUFJLENBQUMsY0FDTCxNQUFNLENBQUMsUUFDUCxFQUFFLENBQUMsV0FBVztJQUVqQixNQUFNLFVBQVUsT0FBTyxLQUFLLENBQUEsSUFBSyxFQUFFLElBQUksS0FBSyxXQUFXLEVBQUUsSUFBSSxLQUFLO0lBQ2xFLElBQUksQ0FBQyxTQUFTO01BQ1osT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQXdCLElBQ2hEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sRUFBRSxPQUFPLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUVsQyxJQUFJLENBQUMsU0FBUztNQUNaLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFrQixJQUMxQztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxpQkFBaUI7SUFDakIsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxjQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsS0FDUCxFQUFFLENBQUMsTUFBTSxTQUNULE1BQU07SUFFVCxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFrQixJQUMxQztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLFFBQVEsVUFBVSxFQUFFLE1BQU0sTUFBTSxDQUFDLENBQUM7SUFFdkUsNEVBQTRFO0lBQzVFLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUI7SUFDM0QsTUFBTSxnQkFBZ0IsTUFBTSxTQUFTLElBQUksTUFBTSxTQUFTLENBQUMsUUFBUSxDQUFDO0lBRWxFLElBQUksaUJBQWlCLE1BQU0sTUFBTSxLQUFLLGFBQWE7TUFDakQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixTQUFTO1FBQ1QsUUFBUTtRQUNSLFNBQVM7UUFDVCxXQUFXLE1BQU0sU0FBUztNQUM1QixJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsbUNBQW1DO0lBQ25DLE1BQU0sY0FBYyxNQUFNLFdBQVcsRUFBRSxNQUFNO0lBQzdDLE1BQU0sU0FBUyxhQUFhLENBQUMsRUFBRSxFQUFFO0lBRWpDLElBQUksQ0FBQyxRQUFRO01BQ1gsdURBQXVEO01BQ3ZELElBQUksTUFBTSxTQUFTLEVBQUU7UUFDbkIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsUUFBUTtVQUNSLFNBQVM7VUFDVCxXQUFXLE1BQU0sU0FBUztRQUM1QixJQUNBO1VBQUUsU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRXRFO01BRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixTQUFTO1FBQ1QsT0FBTztRQUNQLFNBQVM7TUFDWCxJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxtQ0FBbUMsRUFBRSxPQUFPLENBQUM7SUFFMUQsNkJBQTZCO0lBQzdCLE1BQU0saUJBQWlCLE1BQU0sTUFBTSxDQUFDLEVBQUUsY0FBYywrQkFBK0IsRUFBRSxPQUFPLENBQUMsRUFBRTtNQUM3RixRQUFRO01BQ1IsU0FBUztRQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7SUFDRjtJQUVBLE1BQU0sYUFBYSxNQUFNLGVBQWUsSUFBSTtJQUM1QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLDhCQUE4QixDQUFDLEVBQUUsS0FBSyxTQUFTLENBQUM7SUFFN0QsSUFBSSxXQUFXLElBQUksS0FBSyxPQUFPLFdBQVcsSUFBSSxFQUFFO01BQzlDLE1BQU0sVUFBVSxXQUFXLElBQUksQ0FBQyxRQUFRLEVBQUUsWUFBWSxXQUFXLElBQUksQ0FBQyxJQUFJLElBQUksRUFBRTtNQUNoRixNQUFNLGFBQWEsV0FBVyxJQUFJLENBQUMsTUFBTTtNQUV6QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLDZCQUE2QixFQUFFLFdBQVcsV0FBVyxFQUFFLFFBQVEsTUFBTSxDQUFDLENBQUM7TUFFcEYsd0NBQXdDO01BQ3hDLElBQUksUUFBUSxNQUFNLEdBQUcsS0FBSyxPQUFPLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRTtRQUM5QyxNQUFNLFNBQVMsT0FBTyxDQUFDLEVBQUU7UUFFekIsdUNBQXVDO1FBQ3ZDLElBQUksb0JBQW9CLE9BQU8sU0FBUztRQUN4QyxJQUFJLG9CQUFvQixPQUFPLFNBQVMsSUFBSSxNQUFNLFNBQVM7UUFFM0QsSUFBSTtVQUNGLGlCQUFpQjtVQUNqQixNQUFNLGdCQUFnQixNQUFNLE1BQU0sT0FBTyxTQUFTO1VBQ2xELElBQUksY0FBYyxFQUFFLEVBQUU7WUFDcEIsTUFBTSxjQUFjLE1BQU0sY0FBYyxXQUFXO1lBQ25ELE1BQU0sWUFBWSxDQUFDLEVBQUUsTUFBTSxPQUFPLENBQUMsQ0FBQyxFQUFFLFFBQVEsSUFBSSxDQUFDO1lBRW5ELE1BQU0sRUFBRSxPQUFPLGdCQUFnQixFQUFFLEdBQUcsTUFBTSxjQUFjLE9BQU8sQ0FDNUQsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLFdBQVcsYUFBYTtjQUM5QixhQUFhO2NBQ2IsUUFBUTtZQUNWO1lBRUYsSUFBSSxDQUFDLGtCQUFrQjtjQUNyQixNQUFNLEVBQUUsTUFBTSxZQUFZLEVBQUUsR0FBRyxjQUFjLE9BQU8sQ0FDakQsSUFBSSxDQUFDLFVBQ0wsWUFBWSxDQUFDO2NBQ2hCLG9CQUFvQixhQUFhLFNBQVM7Y0FDMUMsUUFBUSxHQUFHLENBQUMsQ0FBQyw2QkFBNkIsRUFBRSxrQkFBa0IsQ0FBQztZQUNqRSxPQUFPO2NBQ0wsUUFBUSxLQUFLLENBQUMsQ0FBQyxtQ0FBbUMsQ0FBQyxFQUFFO1lBQ3ZEO1VBQ0Y7VUFFQSw4QkFBOEI7VUFDOUIsSUFBSSxPQUFPLFNBQVMsRUFBRTtZQUNwQixNQUFNLGdCQUFnQixNQUFNLE1BQU0sT0FBTyxTQUFTO1lBQ2xELElBQUksY0FBYyxFQUFFLEVBQUU7Y0FDcEIsTUFBTSxjQUFjLE1BQU0sY0FBYyxXQUFXO2NBQ25ELE1BQU0sWUFBWSxDQUFDLEVBQUUsTUFBTSxPQUFPLENBQUMsQ0FBQyxFQUFFLFFBQVEsVUFBVSxDQUFDO2NBRXpELE1BQU0sRUFBRSxPQUFPLGdCQUFnQixFQUFFLEdBQUcsTUFBTSxjQUFjLE9BQU8sQ0FDNUQsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLFdBQVcsYUFBYTtnQkFDOUIsYUFBYTtnQkFDYixRQUFRO2NBQ1Y7Y0FFRixJQUFJLENBQUMsa0JBQWtCO2dCQUNyQixNQUFNLEVBQUUsTUFBTSxZQUFZLEVBQUUsR0FBRyxjQUFjLE9BQU8sQ0FDakQsSUFBSSxDQUFDLFVBQ0wsWUFBWSxDQUFDO2dCQUNoQixvQkFBb0IsYUFBYSxTQUFTO2dCQUMxQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLDZCQUE2QixFQUFFLGtCQUFrQixDQUFDO2NBQ2pFO1lBQ0Y7VUFDRjtRQUNGLEVBQUUsT0FBTyxlQUFlO1VBQ3RCLFFBQVEsS0FBSyxDQUFDLENBQUMsK0JBQStCLENBQUMsRUFBRTtRQUNqRCxnREFBZ0Q7UUFDbEQ7UUFFQSw4QkFBOEI7UUFDOUIsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxjQUNsQyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7VUFDTixXQUFXO1VBQ1gsV0FBVztVQUNYLFVBQVUsT0FBTyxRQUFRLEdBQUcsS0FBSyxLQUFLLENBQUMsT0FBTyxRQUFRLElBQUk7VUFDMUQsUUFBUTtVQUNSLGVBQWU7VUFDZixlQUFlLE9BQU8sRUFBRSxJQUFJO1FBQzlCLEdBQ0MsRUFBRSxDQUFDLE1BQU07UUFFWixJQUFJLGFBQWE7VUFDZixRQUFRLEtBQUssQ0FBQyx5Q0FBeUM7VUFDdkQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7WUFDYixTQUFTO1lBQ1QsT0FBTyxZQUFZLE9BQU87VUFDNUIsSUFDQTtZQUFFLFNBQVM7Y0FBRSxHQUFHLFdBQVc7Y0FBRSxnQkFBZ0I7WUFBbUI7VUFBRTtRQUV0RTtRQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQ2IsU0FBUztVQUNULFFBQVE7VUFDUixTQUFTO1VBQ1QsV0FBVztRQUNiLElBQ0E7VUFBRSxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFdEU7TUFFQSwwQkFBMEI7TUFDMUIsSUFBSSxlQUFlLDJCQUEyQixlQUFlLFlBQVksZUFBZSxTQUFTO1FBQy9GLE1BQU0sZUFBZSxXQUFXLElBQUksQ0FBQyxXQUFXLElBQUksV0FBVyxJQUFJLENBQUMsYUFBYSxJQUFJO1FBRXJGLE1BQU0sY0FDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7VUFDTixRQUFRO1VBQ1IsZUFBZTtRQUNqQixHQUNDLEVBQUUsQ0FBQyxNQUFNO1FBRVosT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsUUFBUTtVQUNSLFNBQVMsQ0FBQyxrQkFBa0IsRUFBRSxhQUFhLENBQUM7UUFDOUMsSUFDQTtVQUFFLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUV0RTtNQUVBLG1CQUFtQjtNQUNuQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVCxRQUFRLGNBQWM7UUFDdEIsU0FBUyxDQUFDLFFBQVEsRUFBRSxXQUFXLHdCQUF3QixDQUFDO01BQzFELElBQ0E7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxxRUFBcUU7SUFDckUsSUFBSSxXQUFXLE1BQU0sS0FBSyxPQUFPLFdBQVcsS0FBSyxLQUFLLGFBQWE7TUFDakUsdUVBQXVFO01BQ3ZFLElBQUksTUFBTSxTQUFTLEVBQUU7UUFDbkIsaURBQWlEO1FBQ2pELE1BQU0sY0FDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7VUFDTixRQUFRO1VBQ1IsZUFBZTtRQUNqQixHQUNDLEVBQUUsQ0FBQyxNQUFNO1FBRVosT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsUUFBUTtVQUNSLFNBQVM7VUFDVCxXQUFXLE1BQU0sU0FBUztRQUM1QixJQUNBO1VBQUUsU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRXRFO01BRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixTQUFTO1FBQ1QsUUFBUTtRQUNSLFNBQVM7TUFDWCxJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsUUFBUTtNQUNSLFNBQVMsQ0FBQyxrQkFBa0IsRUFBRSxXQUFXLEdBQUcsSUFBSSxXQUFXLEtBQUssSUFBSSxnQkFBZ0IsQ0FBQztNQUNyRixLQUFLO0lBQ1AsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLDBCQUEwQjtJQUN4QyxNQUFNLGVBQWUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDOUQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQWEsSUFDckM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
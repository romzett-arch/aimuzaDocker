const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
const FILE_UPLOAD_BASE = "https://sunoapiorg.redpandaai.co";
// Map artist names to genre/style descriptions (Suno doesn't allow artist names)
const artistToStyleMap = {
  "Drake": "moody trap hip-hop with melodic hooks",
  "The Weeknd": "dark synth-pop R&B with falsetto vocals",
  "Taylor Swift": "catchy pop-country with storytelling lyrics",
  "Ed Sheeran": "acoustic pop folk with romantic themes",
  "Billie Eilish": "dark minimalist pop with whispered vocals",
  "Ariana Grande": "powerful pop R&B with high vocals",
  "Dua Lipa": "disco-influenced dance pop",
  "Bad Bunny": "reggaeton latin trap with urban beats",
  "Post Malone": "melodic hip-hop rock fusion",
  "Kendrick Lamar": "conscious lyrical hip-hop",
  "Beyoncé": "powerful R&B pop with soulful vocals",
  "Bruno Mars": "funk pop with retro grooves",
  "Adele": "powerful ballads with soulful vocals",
  "Coldplay": "anthemic alternative rock with atmospheric synths"
};
function convertArtistToStyle(artistName) {
  if (artistToStyleMap[artistName]) {
    return artistToStyleMap[artistName];
  }
  const lowerName = artistName.toLowerCase();
  for (const [artist, style] of Object.entries(artistToStyleMap)){
    if (artist.toLowerCase() === lowerName) {
      return style;
    }
  }
  return "contemporary pop with modern production";
}
function cleanStyleForSuno(style) {
  if (!style) return "";
  let cleanedStyle = style;
  for (const artistName of Object.keys(artistToStyleMap)){
    const regex = new RegExp(`${artistName}\\s*style`, "gi");
    if (regex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(regex, convertArtistToStyle(artistName));
    }
    const standaloneRegex = new RegExp(`\\b${artistName}\\b`, "gi");
    if (standaloneRegex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(standaloneRegex, convertArtistToStyle(artistName));
    }
  }
  cleanedStyle = cleanedStyle.replace(/,\s*,/g, ",").replace(/\s+/g, " ").trim();
  return cleanedStyle;
}
/**
 * Upload file to Suno API via URL method
 */ async function uploadFileToSuno(fileUrl) {
  console.log(`Uploading file to Suno from URL: ${fileUrl}`);
  // Send both parameter names for API compatibility
  const requestBody = {
    fileUrl: fileUrl,
    uploadPath: fileUrl,
    url: fileUrl
  };
  console.log("Upload request body:", JSON.stringify(requestBody));
  const response = await fetch(`${FILE_UPLOAD_BASE}/api/file-url-upload`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${SUNO_API_KEY}`
    },
    body: JSON.stringify(requestBody)
  });
  const data = await response.json();
  console.log("File upload response:", JSON.stringify(data));
  if (!response.ok || data.code && data.code !== 200) {
    throw new Error(data.msg || "Failed to upload file to Suno");
  }
  // Response contains downloadUrl for the uploaded file
  const uploadedUrl = data.data?.downloadUrl || data.data?.url || data.data || data.downloadUrl || data.url;
  console.log("Uploaded file URL:", uploadedUrl);
  return uploadedUrl;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { trackId, sourceAudioUrl, prompt, style, title, instrumental, customMode = true } = await req.json();
    if (!trackId || !sourceAudioUrl) {
      return new Response(JSON.stringify({
        error: "Missing required fields: trackId, sourceAudioUrl"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Starting upload-cover for track ${trackId} by user ${user.id}`);
    console.log(`Source audio: ${sourceAudioUrl}`);
    console.log(`Style: ${style}, Instrumental: ${instrumental}`);
    // Clean the style to remove artist names
    const cleanedStyle = cleanStyleForSuno(style || "");
    console.log(`Cleaned style: ${cleanedStyle}`);
    // Update track status to processing
    const { error: updateError } = await supabaseClient.from("tracks").update({
      status: "processing",
      error_message: null
    }).eq("id", trackId).eq("user_id", user.id);
    if (updateError) {
      console.error("Failed to update track status:", updateError);
    }
    // Step 1: Upload the source audio to Suno's servers
    let sunoUploadUrl;
    try {
      sunoUploadUrl = await uploadFileToSuno(sourceAudioUrl);
      console.log(`File uploaded to Suno: ${sunoUploadUrl}`);
    } catch (uploadError) {
      console.error("Failed to upload file to Suno:", uploadError);
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: "Не удалось загрузить аудио для обработки"
      }).eq("id", trackId);
      return new Response(JSON.stringify({
        error: "Failed to upload audio file"
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Step 2: Call Suno upload-cover endpoint
    const sunoPayload = {
      uploadUrl: sunoUploadUrl,
      customMode: customMode,
      instrumental: instrumental || false,
      model: "V4",
      callBackUrl: `${Deno.env.get("SUPABASE_URL")}/functions/v1/suno-callback`
    };
    if (customMode) {
      if (prompt) sunoPayload.prompt = prompt;
      if (cleanedStyle) sunoPayload.style = cleanedStyle;
      if (title) sunoPayload.title = title;
    }
    console.log("Sending to Suno upload-cover API:", JSON.stringify(sunoPayload));
    const sunoResponse = await fetch(`${SUNO_API_BASE}/api/v1/generate/upload-cover`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify(sunoPayload)
    });
    const sunoData = await sunoResponse.json();
    console.log("Suno upload-cover response:", JSON.stringify(sunoData));
    if (!sunoResponse.ok || sunoData.code !== 200) {
      const errorMessage = sunoData.msg || "Failed to start cover generation";
      console.error(`Suno API error: ${errorMessage}`);
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: errorMessage
      }).eq("id", trackId).eq("user_id", user.id);
      return new Response(JSON.stringify({
        error: errorMessage,
        details: sunoData
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const taskId = sunoData.data?.taskId;
    console.log(`Cover generation started with task ID: ${taskId}`);
    return new Response(JSON.stringify({
      success: true,
      taskId,
      message: "Cover generation started successfully"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in upload-cover:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl91cGxvYWQtY292ZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmNvbnN0IFNVTk9fQVBJX0tFWSA9IERlbm8uZW52LmdldChcIlNVTk9fQVBJX0tFWVwiKTtcbmNvbnN0IFNVTk9fQVBJX0JBU0UgPSBcImh0dHBzOi8vYXBpYm94LmVyd2VpbWEuYWlcIjtcbmNvbnN0IEZJTEVfVVBMT0FEX0JBU0UgPSBcImh0dHBzOi8vc3Vub2FwaW9yZy5yZWRwYW5kYWFpLmNvXCI7XG5cbi8vIE1hcCBhcnRpc3QgbmFtZXMgdG8gZ2VucmUvc3R5bGUgZGVzY3JpcHRpb25zIChTdW5vIGRvZXNuJ3QgYWxsb3cgYXJ0aXN0IG5hbWVzKVxuY29uc3QgYXJ0aXN0VG9TdHlsZU1hcDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgXCJEcmFrZVwiOiBcIm1vb2R5IHRyYXAgaGlwLWhvcCB3aXRoIG1lbG9kaWMgaG9va3NcIixcbiAgXCJUaGUgV2Vla25kXCI6IFwiZGFyayBzeW50aC1wb3AgUiZCIHdpdGggZmFsc2V0dG8gdm9jYWxzXCIsXG4gIFwiVGF5bG9yIFN3aWZ0XCI6IFwiY2F0Y2h5IHBvcC1jb3VudHJ5IHdpdGggc3Rvcnl0ZWxsaW5nIGx5cmljc1wiLFxuICBcIkVkIFNoZWVyYW5cIjogXCJhY291c3RpYyBwb3AgZm9sayB3aXRoIHJvbWFudGljIHRoZW1lc1wiLFxuICBcIkJpbGxpZSBFaWxpc2hcIjogXCJkYXJrIG1pbmltYWxpc3QgcG9wIHdpdGggd2hpc3BlcmVkIHZvY2Fsc1wiLFxuICBcIkFyaWFuYSBHcmFuZGVcIjogXCJwb3dlcmZ1bCBwb3AgUiZCIHdpdGggaGlnaCB2b2NhbHNcIixcbiAgXCJEdWEgTGlwYVwiOiBcImRpc2NvLWluZmx1ZW5jZWQgZGFuY2UgcG9wXCIsXG4gIFwiQmFkIEJ1bm55XCI6IFwicmVnZ2FldG9uIGxhdGluIHRyYXAgd2l0aCB1cmJhbiBiZWF0c1wiLFxuICBcIlBvc3QgTWFsb25lXCI6IFwibWVsb2RpYyBoaXAtaG9wIHJvY2sgZnVzaW9uXCIsXG4gIFwiS2VuZHJpY2sgTGFtYXJcIjogXCJjb25zY2lvdXMgbHlyaWNhbCBoaXAtaG9wXCIsXG4gIFwiQmV5b25jw6lcIjogXCJwb3dlcmZ1bCBSJkIgcG9wIHdpdGggc291bGZ1bCB2b2NhbHNcIixcbiAgXCJCcnVubyBNYXJzXCI6IFwiZnVuayBwb3Agd2l0aCByZXRybyBncm9vdmVzXCIsXG4gIFwiQWRlbGVcIjogXCJwb3dlcmZ1bCBiYWxsYWRzIHdpdGggc291bGZ1bCB2b2NhbHNcIixcbiAgXCJDb2xkcGxheVwiOiBcImFudGhlbWljIGFsdGVybmF0aXZlIHJvY2sgd2l0aCBhdG1vc3BoZXJpYyBzeW50aHNcIixcbn07XG5cbmZ1bmN0aW9uIGNvbnZlcnRBcnRpc3RUb1N0eWxlKGFydGlzdE5hbWU6IHN0cmluZyk6IHN0cmluZyB7XG4gIGlmIChhcnRpc3RUb1N0eWxlTWFwW2FydGlzdE5hbWVdKSB7XG4gICAgcmV0dXJuIGFydGlzdFRvU3R5bGVNYXBbYXJ0aXN0TmFtZV07XG4gIH1cbiAgY29uc3QgbG93ZXJOYW1lID0gYXJ0aXN0TmFtZS50b0xvd2VyQ2FzZSgpO1xuICBmb3IgKGNvbnN0IFthcnRpc3QsIHN0eWxlXSBvZiBPYmplY3QuZW50cmllcyhhcnRpc3RUb1N0eWxlTWFwKSkge1xuICAgIGlmIChhcnRpc3QudG9Mb3dlckNhc2UoKSA9PT0gbG93ZXJOYW1lKSB7XG4gICAgICByZXR1cm4gc3R5bGU7XG4gICAgfVxuICB9XG4gIHJldHVybiBcImNvbnRlbXBvcmFyeSBwb3Agd2l0aCBtb2Rlcm4gcHJvZHVjdGlvblwiO1xufVxuXG5mdW5jdGlvbiBjbGVhblN0eWxlRm9yU3VubyhzdHlsZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgaWYgKCFzdHlsZSkgcmV0dXJuIFwiXCI7XG4gIFxuICBsZXQgY2xlYW5lZFN0eWxlID0gc3R5bGU7XG4gIGZvciAoY29uc3QgYXJ0aXN0TmFtZSBvZiBPYmplY3Qua2V5cyhhcnRpc3RUb1N0eWxlTWFwKSkge1xuICAgIGNvbnN0IHJlZ2V4ID0gbmV3IFJlZ0V4cChgJHthcnRpc3ROYW1lfVxcXFxzKnN0eWxlYCwgXCJnaVwiKTtcbiAgICBpZiAocmVnZXgudGVzdChjbGVhbmVkU3R5bGUpKSB7XG4gICAgICBjbGVhbmVkU3R5bGUgPSBjbGVhbmVkU3R5bGUucmVwbGFjZShyZWdleCwgY29udmVydEFydGlzdFRvU3R5bGUoYXJ0aXN0TmFtZSkpO1xuICAgIH1cbiAgICBjb25zdCBzdGFuZGFsb25lUmVnZXggPSBuZXcgUmVnRXhwKGBcXFxcYiR7YXJ0aXN0TmFtZX1cXFxcYmAsIFwiZ2lcIik7XG4gICAgaWYgKHN0YW5kYWxvbmVSZWdleC50ZXN0KGNsZWFuZWRTdHlsZSkpIHtcbiAgICAgIGNsZWFuZWRTdHlsZSA9IGNsZWFuZWRTdHlsZS5yZXBsYWNlKHN0YW5kYWxvbmVSZWdleCwgY29udmVydEFydGlzdFRvU3R5bGUoYXJ0aXN0TmFtZSkpO1xuICAgIH1cbiAgfVxuICBcbiAgY2xlYW5lZFN0eWxlID0gY2xlYW5lZFN0eWxlLnJlcGxhY2UoLyxcXHMqLC9nLCBcIixcIikucmVwbGFjZSgvXFxzKy9nLCBcIiBcIikudHJpbSgpO1xuICByZXR1cm4gY2xlYW5lZFN0eWxlO1xufVxuXG4vKipcbiAqIFVwbG9hZCBmaWxlIHRvIFN1bm8gQVBJIHZpYSBVUkwgbWV0aG9kXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIHVwbG9hZEZpbGVUb1N1bm8oZmlsZVVybDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc29sZS5sb2coYFVwbG9hZGluZyBmaWxlIHRvIFN1bm8gZnJvbSBVUkw6ICR7ZmlsZVVybH1gKTtcbiAgXG4gIC8vIFNlbmQgYm90aCBwYXJhbWV0ZXIgbmFtZXMgZm9yIEFQSSBjb21wYXRpYmlsaXR5XG4gIGNvbnN0IHJlcXVlc3RCb2R5ID0geyBcbiAgICBmaWxlVXJsOiBmaWxlVXJsLFxuICAgIHVwbG9hZFBhdGg6IGZpbGVVcmwsXG4gICAgdXJsOiBmaWxlVXJsIFxuICB9O1xuICBjb25zb2xlLmxvZyhcIlVwbG9hZCByZXF1ZXN0IGJvZHk6XCIsIEpTT04uc3RyaW5naWZ5KHJlcXVlc3RCb2R5KSk7XG4gIFxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0ZJTEVfVVBMT0FEX0JBU0V9L2FwaS9maWxlLXVybC11cGxvYWRgLCB7XG4gICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICBoZWFkZXJzOiB7XG4gICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgfSxcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeShyZXF1ZXN0Qm9keSksXG4gIH0pO1xuXG4gIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gIGNvbnNvbGUubG9nKFwiRmlsZSB1cGxvYWQgcmVzcG9uc2U6XCIsIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcbiAgXG4gIGlmICghcmVzcG9uc2Uub2sgfHwgKGRhdGEuY29kZSAmJiBkYXRhLmNvZGUgIT09IDIwMCkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoZGF0YS5tc2cgfHwgXCJGYWlsZWQgdG8gdXBsb2FkIGZpbGUgdG8gU3Vub1wiKTtcbiAgfVxuICBcbiAgLy8gUmVzcG9uc2UgY29udGFpbnMgZG93bmxvYWRVcmwgZm9yIHRoZSB1cGxvYWRlZCBmaWxlXG4gIGNvbnN0IHVwbG9hZGVkVXJsID0gZGF0YS5kYXRhPy5kb3dubG9hZFVybCB8fCBkYXRhLmRhdGE/LnVybCB8fCBkYXRhLmRhdGEgfHwgZGF0YS5kb3dubG9hZFVybCB8fCBkYXRhLnVybDtcbiAgY29uc29sZS5sb2coXCJVcGxvYWRlZCBmaWxlIFVSTDpcIiwgdXBsb2FkZWRVcmwpO1xuICByZXR1cm4gdXBsb2FkZWRVcmw7XG59XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiTm8gYXV0aG9yaXphdGlvbiBoZWFkZXJcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlQ2xpZW50ID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpID8/IFwiXCIsXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSA/PyBcIlwiLFxuICAgICAgeyBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfSB9XG4gICAgKTtcblxuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0sIGVycm9yOiB1c2VyRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50LmF1dGguZ2V0VXNlcigpO1xuICAgIGlmICh1c2VyRXJyb3IgfHwgIXVzZXIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB7IFxuICAgICAgdHJhY2tJZCwgXG4gICAgICBzb3VyY2VBdWRpb1VybCwgIC8vIFVSTCBvZiB1cGxvYWRlZCBhdWRpbyBmaWxlIChmcm9tIFN1cGFiYXNlIHN0b3JhZ2Ugb3IgZXh0ZXJuYWwpXG4gICAgICBwcm9tcHQsICAgICAgICAgIC8vIEx5cmljcyBvciBkZXNjcmlwdGlvblxuICAgICAgc3R5bGUsICAgICAgICAgICAvLyBNdXNpYyBzdHlsZVxuICAgICAgdGl0bGUsIFxuICAgICAgaW5zdHJ1bWVudGFsLFxuICAgICAgY3VzdG9tTW9kZSA9IHRydWUsXG4gICAgfSA9IGF3YWl0IHJlcS5qc29uKCk7XG5cbiAgICBpZiAoIXRyYWNrSWQgfHwgIXNvdXJjZUF1ZGlvVXJsKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk1pc3NpbmcgcmVxdWlyZWQgZmllbGRzOiB0cmFja0lkLCBzb3VyY2VBdWRpb1VybFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFN0YXJ0aW5nIHVwbG9hZC1jb3ZlciBmb3IgdHJhY2sgJHt0cmFja0lkfSBieSB1c2VyICR7dXNlci5pZH1gKTtcbiAgICBjb25zb2xlLmxvZyhgU291cmNlIGF1ZGlvOiAke3NvdXJjZUF1ZGlvVXJsfWApO1xuICAgIGNvbnNvbGUubG9nKGBTdHlsZTogJHtzdHlsZX0sIEluc3RydW1lbnRhbDogJHtpbnN0cnVtZW50YWx9YCk7XG5cbiAgICAvLyBDbGVhbiB0aGUgc3R5bGUgdG8gcmVtb3ZlIGFydGlzdCBuYW1lc1xuICAgIGNvbnN0IGNsZWFuZWRTdHlsZSA9IGNsZWFuU3R5bGVGb3JTdW5vKHN0eWxlIHx8IFwiXCIpO1xuICAgIGNvbnNvbGUubG9nKGBDbGVhbmVkIHN0eWxlOiAke2NsZWFuZWRTdHlsZX1gKTtcblxuICAgIC8vIFVwZGF0ZSB0cmFjayBzdGF0dXMgdG8gcHJvY2Vzc2luZ1xuICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiLCBlcnJvcl9tZXNzYWdlOiBudWxsIH0pXG4gICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcblxuICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgdHJhY2sgc3RhdHVzOlwiLCB1cGRhdGVFcnJvcik7XG4gICAgfVxuXG4gICAgLy8gU3RlcCAxOiBVcGxvYWQgdGhlIHNvdXJjZSBhdWRpbyB0byBTdW5vJ3Mgc2VydmVyc1xuICAgIGxldCBzdW5vVXBsb2FkVXJsOiBzdHJpbmc7XG4gICAgdHJ5IHtcbiAgICAgIHN1bm9VcGxvYWRVcmwgPSBhd2FpdCB1cGxvYWRGaWxlVG9TdW5vKHNvdXJjZUF1ZGlvVXJsKTtcbiAgICAgIGNvbnNvbGUubG9nKGBGaWxlIHVwbG9hZGVkIHRvIFN1bm86ICR7c3Vub1VwbG9hZFVybH1gKTtcbiAgICB9IGNhdGNoICh1cGxvYWRFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGxvYWQgZmlsZSB0byBTdW5vOlwiLCB1cGxvYWRFcnJvcik7XG4gICAgICBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAudXBkYXRlKHsgXG4gICAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLFxuICAgICAgICAgIGVycm9yX21lc3NhZ2U6IFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQt9Cw0LPRgNGD0LfQuNGC0Ywg0LDRg9C00LjQviDQtNC70Y8g0L7QsdGA0LDQsdC+0YLQutC4XCJcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZCk7XG4gICAgICBcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiRmFpbGVkIHRvIHVwbG9hZCBhdWRpbyBmaWxlXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBTdGVwIDI6IENhbGwgU3VubyB1cGxvYWQtY292ZXIgZW5kcG9pbnRcbiAgICBjb25zdCBzdW5vUGF5bG9hZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICB1cGxvYWRVcmw6IHN1bm9VcGxvYWRVcmwsXG4gICAgICBjdXN0b21Nb2RlOiBjdXN0b21Nb2RlLFxuICAgICAgaW5zdHJ1bWVudGFsOiBpbnN0cnVtZW50YWwgfHwgZmFsc2UsXG4gICAgICBtb2RlbDogXCJWNFwiLFxuICAgICAgY2FsbEJhY2tVcmw6IGAke0Rlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKX0vZnVuY3Rpb25zL3YxL3N1bm8tY2FsbGJhY2tgLFxuICAgIH07XG5cbiAgICBpZiAoY3VzdG9tTW9kZSkge1xuICAgICAgaWYgKHByb21wdCkgc3Vub1BheWxvYWQucHJvbXB0ID0gcHJvbXB0O1xuICAgICAgaWYgKGNsZWFuZWRTdHlsZSkgc3Vub1BheWxvYWQuc3R5bGUgPSBjbGVhbmVkU3R5bGU7XG4gICAgICBpZiAodGl0bGUpIHN1bm9QYXlsb2FkLnRpdGxlID0gdGl0bGU7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coXCJTZW5kaW5nIHRvIFN1bm8gdXBsb2FkLWNvdmVyIEFQSTpcIiwgSlNPTi5zdHJpbmdpZnkoc3Vub1BheWxvYWQpKTtcblxuICAgIGNvbnN0IHN1bm9SZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke1NVTk9fQVBJX0JBU0V9L2FwaS92MS9nZW5lcmF0ZS91cGxvYWQtY292ZXJgLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShzdW5vUGF5bG9hZCksXG4gICAgfSk7XG5cbiAgICBjb25zdCBzdW5vRGF0YSA9IGF3YWl0IHN1bm9SZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJTdW5vIHVwbG9hZC1jb3ZlciByZXNwb25zZTpcIiwgSlNPTi5zdHJpbmdpZnkoc3Vub0RhdGEpKTtcblxuICAgIGlmICghc3Vub1Jlc3BvbnNlLm9rIHx8IHN1bm9EYXRhLmNvZGUgIT09IDIwMCkge1xuICAgICAgY29uc3QgZXJyb3JNZXNzYWdlID0gc3Vub0RhdGEubXNnIHx8IFwiRmFpbGVkIHRvIHN0YXJ0IGNvdmVyIGdlbmVyYXRpb25cIjtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYFN1bm8gQVBJIGVycm9yOiAke2Vycm9yTWVzc2FnZX1gKTtcbiAgICAgIFxuICAgICAgYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgICBlcnJvcl9tZXNzYWdlOiBlcnJvck1lc3NhZ2VcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZClcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcblxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBlcnJvcjogZXJyb3JNZXNzYWdlLFxuICAgICAgICAgIGRldGFpbHM6IHN1bm9EYXRhIFxuICAgICAgICB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHRhc2tJZCA9IHN1bm9EYXRhLmRhdGE/LnRhc2tJZDtcbiAgICBjb25zb2xlLmxvZyhgQ292ZXIgZ2VuZXJhdGlvbiBzdGFydGVkIHdpdGggdGFzayBJRDogJHt0YXNrSWR9YCk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIHRhc2tJZCxcbiAgICAgICAgbWVzc2FnZTogXCJDb3ZlciBnZW5lcmF0aW9uIHN0YXJ0ZWQgc3VjY2Vzc2Z1bGx5XCIgXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiB1cGxvYWQtY292ZXI6XCIsIGVycm9yKTtcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBlcnJvck1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLFFBQVEsQ0FBQztFQUFvQixXQUFtQixpQkFBaUIsR0FBRztBQUFTO0FBQ25GLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDbEMsTUFBTSxnQkFBZ0I7QUFDdEIsTUFBTSxtQkFBbUI7QUFFekIsaUZBQWlGO0FBQ2pGLE1BQU0sbUJBQTJDO0VBQy9DLFNBQVM7RUFDVCxjQUFjO0VBQ2QsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCxpQkFBaUI7RUFDakIsaUJBQWlCO0VBQ2pCLFlBQVk7RUFDWixhQUFhO0VBQ2IsZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsY0FBYztFQUNkLFNBQVM7RUFDVCxZQUFZO0FBQ2Q7QUFFQSxTQUFTLHFCQUFxQixVQUFrQjtFQUM5QyxJQUFJLGdCQUFnQixDQUFDLFdBQVcsRUFBRTtJQUNoQyxPQUFPLGdCQUFnQixDQUFDLFdBQVc7RUFDckM7RUFDQSxNQUFNLFlBQVksV0FBVyxXQUFXO0VBQ3hDLEtBQUssTUFBTSxDQUFDLFFBQVEsTUFBTSxJQUFJLE9BQU8sT0FBTyxDQUFDLGtCQUFtQjtJQUM5RCxJQUFJLE9BQU8sV0FBVyxPQUFPLFdBQVc7TUFDdEMsT0FBTztJQUNUO0VBQ0Y7RUFDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTLGtCQUFrQixLQUFhO0VBQ3RDLElBQUksQ0FBQyxPQUFPLE9BQU87RUFFbkIsSUFBSSxlQUFlO0VBQ25CLEtBQUssTUFBTSxjQUFjLE9BQU8sSUFBSSxDQUFDLGtCQUFtQjtJQUN0RCxNQUFNLFFBQVEsSUFBSSxPQUFPLENBQUMsRUFBRSxXQUFXLFNBQVMsQ0FBQyxFQUFFO0lBQ25ELElBQUksTUFBTSxJQUFJLENBQUMsZUFBZTtNQUM1QixlQUFlLGFBQWEsT0FBTyxDQUFDLE9BQU8scUJBQXFCO0lBQ2xFO0lBQ0EsTUFBTSxrQkFBa0IsSUFBSSxPQUFPLENBQUMsR0FBRyxFQUFFLFdBQVcsR0FBRyxDQUFDLEVBQUU7SUFDMUQsSUFBSSxnQkFBZ0IsSUFBSSxDQUFDLGVBQWU7TUFDdEMsZUFBZSxhQUFhLE9BQU8sQ0FBQyxpQkFBaUIscUJBQXFCO0lBQzVFO0VBQ0Y7RUFFQSxlQUFlLGFBQWEsT0FBTyxDQUFDLFVBQVUsS0FBSyxPQUFPLENBQUMsUUFBUSxLQUFLLElBQUk7RUFDNUUsT0FBTztBQUNUO0FBRUE7O0NBRUMsR0FDRCxlQUFlLGlCQUFpQixPQUFlO0VBQzdDLFFBQVEsR0FBRyxDQUFDLENBQUMsaUNBQWlDLEVBQUUsUUFBUSxDQUFDO0VBRXpELGtEQUFrRDtFQUNsRCxNQUFNLGNBQWM7SUFDbEIsU0FBUztJQUNULFlBQVk7SUFDWixLQUFLO0VBQ1A7RUFDQSxRQUFRLEdBQUcsQ0FBQyx3QkFBd0IsS0FBSyxTQUFTLENBQUM7RUFFbkQsTUFBTSxXQUFXLE1BQU0sTUFBTSxDQUFDLEVBQUUsaUJBQWlCLG9CQUFvQixDQUFDLEVBQUU7SUFDdEUsUUFBUTtJQUNSLFNBQVM7TUFDUCxnQkFBZ0I7TUFDaEIsaUJBQWlCLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQztJQUMzQztJQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7RUFDdkI7RUFFQSxNQUFNLE9BQU8sTUFBTSxTQUFTLElBQUk7RUFDaEMsUUFBUSxHQUFHLENBQUMseUJBQXlCLEtBQUssU0FBUyxDQUFDO0VBRXBELElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSyxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksS0FBSyxLQUFNO0lBQ3BELE1BQU0sSUFBSSxNQUFNLEtBQUssR0FBRyxJQUFJO0VBQzlCO0VBRUEsc0RBQXNEO0VBQ3RELE1BQU0sY0FBYyxLQUFLLElBQUksRUFBRSxlQUFlLEtBQUssSUFBSSxFQUFFLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksS0FBSyxHQUFHO0VBQ3pHLFFBQVEsR0FBRyxDQUFDLHNCQUFzQjtFQUNsQyxPQUFPO0FBQ1Q7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZO01BQ2YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTBCLElBQ2xEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0saUJBQWlCLGFBQ3JCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFDaEMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLHdCQUF3QixJQUNyQztNQUFFLFFBQVE7UUFBRSxTQUFTO1VBQUUsZUFBZTtRQUFXO01BQUU7SUFBRTtJQUd2RCxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxPQUFPO0lBQzlFLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWUsSUFDdkM7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxFQUNKLE9BQU8sRUFDUCxjQUFjLEVBQ2QsTUFBTSxFQUNOLEtBQUssRUFDTCxLQUFLLEVBQ0wsWUFBWSxFQUNaLGFBQWEsSUFBSSxFQUNsQixHQUFHLE1BQU0sSUFBSSxJQUFJO0lBRWxCLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCO01BQy9CLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFtRCxJQUMzRTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGdDQUFnQyxFQUFFLFFBQVEsU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7SUFDM0UsUUFBUSxHQUFHLENBQUMsQ0FBQyxjQUFjLEVBQUUsZUFBZSxDQUFDO0lBQzdDLFFBQVEsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sZ0JBQWdCLEVBQUUsYUFBYSxDQUFDO0lBRTVELHlDQUF5QztJQUN6QyxNQUFNLGVBQWUsa0JBQWtCLFNBQVM7SUFDaEQsUUFBUSxHQUFHLENBQUMsQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDO0lBRTVDLG9DQUFvQztJQUNwQyxNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLGVBQ2xDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztNQUFFLFFBQVE7TUFBYyxlQUFlO0lBQUssR0FDbkQsRUFBRSxDQUFDLE1BQU0sU0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUU7SUFFeEIsSUFBSSxhQUFhO01BQ2YsUUFBUSxLQUFLLENBQUMsa0NBQWtDO0lBQ2xEO0lBRUEsb0RBQW9EO0lBQ3BELElBQUk7SUFDSixJQUFJO01BQ0YsZ0JBQWdCLE1BQU0saUJBQWlCO01BQ3ZDLFFBQVEsR0FBRyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsY0FBYyxDQUFDO0lBQ3ZELEVBQUUsT0FBTyxhQUFhO01BQ3BCLFFBQVEsS0FBSyxDQUFDLGtDQUFrQztNQUNoRCxNQUFNLGVBQ0gsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sUUFBUTtRQUNSLGVBQWU7TUFDakIsR0FDQyxFQUFFLENBQUMsTUFBTTtNQUVaLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE4QixJQUN0RDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSwwQ0FBMEM7SUFDMUMsTUFBTSxjQUF1QztNQUMzQyxXQUFXO01BQ1gsWUFBWTtNQUNaLGNBQWMsZ0JBQWdCO01BQzlCLE9BQU87TUFDUCxhQUFhLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLDJCQUEyQixDQUFDO0lBQzNFO0lBRUEsSUFBSSxZQUFZO01BQ2QsSUFBSSxRQUFRLFlBQVksTUFBTSxHQUFHO01BQ2pDLElBQUksY0FBYyxZQUFZLEtBQUssR0FBRztNQUN0QyxJQUFJLE9BQU8sWUFBWSxLQUFLLEdBQUc7SUFDakM7SUFFQSxRQUFRLEdBQUcsQ0FBQyxxQ0FBcUMsS0FBSyxTQUFTLENBQUM7SUFFaEUsTUFBTSxlQUFlLE1BQU0sTUFBTSxDQUFDLEVBQUUsY0FBYyw2QkFBNkIsQ0FBQyxFQUFFO01BQ2hGLFFBQVE7TUFDUixTQUFTO1FBQ1AsZ0JBQWdCO1FBQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO0lBQ3ZCO0lBRUEsTUFBTSxXQUFXLE1BQU0sYUFBYSxJQUFJO0lBQ3hDLFFBQVEsR0FBRyxDQUFDLCtCQUErQixLQUFLLFNBQVMsQ0FBQztJQUUxRCxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksU0FBUyxJQUFJLEtBQUssS0FBSztNQUM3QyxNQUFNLGVBQWUsU0FBUyxHQUFHLElBQUk7TUFDckMsUUFBUSxLQUFLLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLENBQUM7TUFFL0MsTUFBTSxlQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztRQUNOLFFBQVE7UUFDUixlQUFlO01BQ2pCLEdBQ0MsRUFBRSxDQUFDLE1BQU0sU0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUU7TUFFeEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixPQUFPO1FBQ1AsU0FBUztNQUNYLElBQ0E7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxTQUFTLFNBQVMsSUFBSSxFQUFFO0lBQzlCLFFBQVEsR0FBRyxDQUFDLENBQUMsdUNBQXVDLEVBQUUsT0FBTyxDQUFDO0lBRTlELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNUO01BQ0EsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQywwQkFBMEI7SUFDeEMsTUFBTSxlQUFlLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQzlELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFhLElBQ3JDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "http://api:3000";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
const BASE_URL = Deno.env.get("BASE_URL") || "http://localhost";
// Download external file and save to local storage via API
async function downloadToLocalStorage(externalUrl, bucket, filePath) {
  try {
    console.log(`Downloading ${externalUrl} → ${bucket}/${filePath}`);
    const resp = await fetch(externalUrl);
    if (!resp.ok) {
      console.log(`Download failed: ${resp.status}`);
      return null;
    }
    const blob = await resp.blob();
    const buffer = new Uint8Array(await blob.arrayBuffer());
    // Upload to local storage API (PUT for upsert)
    const uploadResp = await fetch(`${SUPABASE_URL}/storage/v1/object/${bucket}/${filePath}`, {
      method: "PUT",
      headers: {
        "Content-Type": blob.type || "application/octet-stream",
        "Authorization": `Bearer ${SERVICE_ROLE_KEY}`
      },
      body: buffer
    });
    if (!uploadResp.ok) {
      const errText = await uploadResp.text();
      console.log(`Upload to storage failed: ${uploadResp.status} ${errText}`);
      return null;
    }
    const localUrl = `${BASE_URL}/storage/v1/object/public/${bucket}/${filePath}`;
    console.log(`Saved to local storage: ${localUrl}`);
    return localUrl;
  } catch (err) {
    console.error(`Error downloading to storage:`, err);
    return null;
  }
}
// Fetch with retry logic for connection issues
async function fetchWithRetry(url, options, maxRetries = 2) {
  let lastError = null;
  for(let attempt = 0; attempt <= maxRetries; attempt++){
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(()=>controller.abort(), 10000); // 10s timeout
      const response = await fetch(url, {
        ...options,
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      return response;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      console.log(`Fetch attempt ${attempt + 1} failed:`, lastError.message);
      // Don't retry on abort
      if (lastError.name === 'AbortError') {
        throw new Error("Request timeout");
      }
      // Wait before retry (exponential backoff)
      if (attempt < maxRetries) {
        await new Promise((resolve)=>setTimeout(resolve, 1000 * (attempt + 1)));
      }
    }
  }
  throw lastError || new Error("Failed after retries");
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    // Get user via API-compatible auth endpoint
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      console.error("Auth error:", userError);
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const userId = user.id;
    const { taskId: rawTaskId, trackId } = await req.json();
    // Trim whitespace from taskId to prevent URL encoding issues
    const taskId = rawTaskId?.trim();
    if (!taskId) {
      return new Response(JSON.stringify({
        error: "Missing taskId"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Checking status for task ${taskId}`);
    let statusData;
    try {
      const statusResponse = await fetchWithRetry(`${SUNO_API_BASE}/api/v1/generate/record-info?taskId=${encodeURIComponent(taskId)}`, {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${SUNO_API_KEY}`
        }
      });
      statusData = await statusResponse.json();
    } catch (fetchError) {
      // Network error - don't mark track as failed, just return processing status
      console.log(`Network error checking status (will retry via polling):`, fetchError);
      return new Response(JSON.stringify({
        success: false,
        status: "processing",
        message: "Network issue, waiting for callback"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log("Status response:", JSON.stringify(statusData));
    if (statusData.code === 200 && statusData.data) {
      const records = statusData.data.response?.sunoData || statusData.data.data || [];
      const taskStatus = statusData.data.status;
      console.log(`Task status: ${taskStatus}, Records: ${records.length}`);
      // Check for failed status - handle GENERATE_AUDIO_FAILED and other failure states
      if (taskStatus === "GENERATE_AUDIO_FAILED" || taskStatus === "FAILED" || taskStatus === "ERROR") {
        console.log(`Task ${taskId} failed with status: ${taskStatus}`);
        if (trackId) {
          const errorMessage = statusData.data.fail_reason || statusData.data.error_message || statusData.msg || "Генерация отклонена сервисом";
          const { error: updateError } = await supabaseClient.from("tracks").update({
            status: "failed",
            error_message: errorMessage
          }).eq("id", trackId).eq("user_id", userId);
          if (updateError) {
            console.error("Error updating failed track:", updateError);
          }
        }
        return new Response(JSON.stringify({
          success: false,
          status: taskStatus,
          error: statusData.data.fail_reason || "Generation failed"
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Suno record-info returns camelCase fields (audioUrl, imageUrl)
      // while callback uses snake_case (audio_url, image_url)
      // Normalize to handle both formats
      const normalizedRecords = records.map((r)=>({
          audioUrl: r.audioUrl || r.audio_url || r.source_audio_url || r.sourceAudioUrl,
          imageUrl: r.imageUrl || r.image_url || r.source_image_url || r.sourceImageUrl,
          duration: r.duration,
          id: r.id
        }));
      // Check if ANY record has a real audio URL (not empty string, null, undefined)
      const hasAnyAudio = normalizedRecords.some((r)=>r.audioUrl && String(r.audioUrl) !== "" && String(r.audioUrl) !== "null");
      if (normalizedRecords.length > 0 && hasAnyAudio) {
        // Find ALL tracks matching this task_id (both v1 and v2)
        const { data: matchedTracks } = await supabaseClient.from("tracks").select("id, title, description").eq("user_id", userId).in("status", [
          "processing",
          "pending"
        ]).order("created_at", {
          ascending: true
        });
        // Filter to tracks that have this task_id
        const tracksWithTask = (matchedTracks || []).filter((t)=>t.description?.includes(`[task_id: ${taskId}]`) || t.description?.includes(`[task_id:${taskId}]`));
        console.log(`Found ${tracksWithTask.length} tracks matching task_id ${taskId}`);
        // Update each track with corresponding Suno record (by order: first→v1, second→v2)
        // Download files to local storage for persistent access
        // CRITICAL: Only update tracks where the corresponding record has a valid audio URL
        for(let i = 0; i < tracksWithTask.length && i < normalizedRecords.length; i++){
          const rec = normalizedRecords[i];
          const trk = tracksWithTask[i];
          // CRITICAL: Skip records without valid audio URL
          // When status is FIRST_SUCCESS, only one of two records has audio
          const rawAudioUrl = rec.audioUrl ? String(rec.audioUrl) : "";
          if (!rawAudioUrl || rawAudioUrl === "" || rawAudioUrl === "null" || rawAudioUrl === "undefined") {
            console.log(`Track ${trk.id} (${trk.title}) — no audio URL yet, skipping (status: ${taskStatus})`);
            continue;
          }
          // Download audio to local storage
          let finalAudioUrl = rawAudioUrl;
          const localAudio = await downloadToLocalStorage(finalAudioUrl, "tracks", `audio/${trk.id}.mp3`);
          if (localAudio) finalAudioUrl = localAudio;
          // Download cover to local storage
          let finalCoverUrl = rec.imageUrl ? String(rec.imageUrl) : null;
          if (finalCoverUrl && (finalCoverUrl === "null" || finalCoverUrl === "undefined")) {
            finalCoverUrl = null;
          }
          if (finalCoverUrl) {
            const localCover = await downloadToLocalStorage(finalCoverUrl, "tracks", `covers/${trk.id}.jpg`);
            if (localCover) finalCoverUrl = localCover;
          }
          const { error: updateError } = await supabaseClient.from("tracks").update({
            audio_url: finalAudioUrl,
            cover_url: finalCoverUrl,
            duration: rec.duration ? Math.round(Number(rec.duration)) : null,
            status: "completed"
          }).eq("id", trk.id).eq("user_id", userId);
          if (updateError) {
            console.error(`Error updating track ${trk.id}:`, updateError);
          } else {
            console.log(`Track ${trk.id} (${trk.title}) completed via polling with local storage`);
          }
        }
      } else if (normalizedRecords.length > 0) {
        console.log(`Task ${taskId}: records exist but no audio URLs ready yet (status: ${taskStatus})`);
      }
      return new Response(JSON.stringify({
        success: true,
        status: taskStatus,
        records: normalizedRecords
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Handle API error response - but don't mark as failed for 404 (still processing)
    if (statusData.code !== 200) {
      console.log(`Suno API response: code=${statusData.code}, status=${statusData.status}`);
      // 404 often means the task is still being processed - don't mark as failed
      if (statusData.status === 404 || statusData.error === "Not Found") {
        console.log("Task not found in API - still processing, waiting for callback");
        return new Response(JSON.stringify({
          success: false,
          status: "processing",
          message: "Still processing, waiting for callback"
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // For other errors, mark as failed only if explicitly an error
      if (trackId && statusData.code && statusData.code >= 400 && statusData.code < 500 && statusData.code !== 404) {
        const { error: updateError } = await supabaseClient.from("tracks").update({
          status: "failed",
          error_message: statusData.msg || "API error"
        }).eq("id", trackId).eq("user_id", userId);
        if (updateError) {
          console.error("Error updating failed track:", updateError);
        }
      }
      return new Response(JSON.stringify({
        success: false,
        status: "processing",
        error: statusData.msg || "API error"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    return new Response(JSON.stringify({
      success: false,
      status: "pending",
      data: statusData
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in suno-check-status:", error);
    // Don't return 500 for network issues - just indicate still processing
    return new Response(JSON.stringify({
      success: false,
      status: "processing",
      message: "Checking status, waiting for callback"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9zdW5vLWNoZWNrLXN0YXR1cy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuY29uc3QgU1VOT19BUElfS0VZID0gRGVuby5lbnYuZ2V0KFwiU1VOT19BUElfS0VZXCIpO1xuY29uc3QgU1VOT19BUElfQkFTRSA9IFwiaHR0cHM6Ly9hcGlib3guZXJ3ZWltYS5haVwiO1xuY29uc3QgU1VQQUJBU0VfVVJMID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpIHx8IFwiaHR0cDovL2FwaTozMDAwXCI7XG5jb25zdCBTRVJWSUNFX1JPTEVfS0VZID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSB8fCBcIlwiO1xuY29uc3QgQkFTRV9VUkwgPSBEZW5vLmVudi5nZXQoXCJCQVNFX1VSTFwiKSB8fCBcImh0dHA6Ly9sb2NhbGhvc3RcIjtcblxuLy8gRG93bmxvYWQgZXh0ZXJuYWwgZmlsZSBhbmQgc2F2ZSB0byBsb2NhbCBzdG9yYWdlIHZpYSBBUElcbmFzeW5jIGZ1bmN0aW9uIGRvd25sb2FkVG9Mb2NhbFN0b3JhZ2UoXG4gIGV4dGVybmFsVXJsOiBzdHJpbmcsXG4gIGJ1Y2tldDogc3RyaW5nLFxuICBmaWxlUGF0aDogc3RyaW5nXG4pOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgdHJ5IHtcbiAgICBjb25zb2xlLmxvZyhgRG93bmxvYWRpbmcgJHtleHRlcm5hbFVybH0g4oaSICR7YnVja2V0fS8ke2ZpbGVQYXRofWApO1xuICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBmZXRjaChleHRlcm5hbFVybCk7XG4gICAgaWYgKCFyZXNwLm9rKSB7XG4gICAgICBjb25zb2xlLmxvZyhgRG93bmxvYWQgZmFpbGVkOiAke3Jlc3Auc3RhdHVzfWApO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwLmJsb2IoKTtcbiAgICBjb25zdCBidWZmZXIgPSBuZXcgVWludDhBcnJheShhd2FpdCBibG9iLmFycmF5QnVmZmVyKCkpO1xuXG4gICAgLy8gVXBsb2FkIHRvIGxvY2FsIHN0b3JhZ2UgQVBJIChQVVQgZm9yIHVwc2VydClcbiAgICBjb25zdCB1cGxvYWRSZXNwID0gYXdhaXQgZmV0Y2goXG4gICAgICBgJHtTVVBBQkFTRV9VUkx9L3N0b3JhZ2UvdjEvb2JqZWN0LyR7YnVja2V0fS8ke2ZpbGVQYXRofWAsXG4gICAgICB7XG4gICAgICAgIG1ldGhvZDogXCJQVVRcIixcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IGJsb2IudHlwZSB8fCBcImFwcGxpY2F0aW9uL29jdGV0LXN0cmVhbVwiLFxuICAgICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U0VSVklDRV9ST0xFX0tFWX1gLFxuICAgICAgICB9LFxuICAgICAgICBib2R5OiBidWZmZXIsXG4gICAgICB9XG4gICAgKTtcblxuICAgIGlmICghdXBsb2FkUmVzcC5vaykge1xuICAgICAgY29uc3QgZXJyVGV4dCA9IGF3YWl0IHVwbG9hZFJlc3AudGV4dCgpO1xuICAgICAgY29uc29sZS5sb2coYFVwbG9hZCB0byBzdG9yYWdlIGZhaWxlZDogJHt1cGxvYWRSZXNwLnN0YXR1c30gJHtlcnJUZXh0fWApO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgY29uc3QgbG9jYWxVcmwgPSBgJHtCQVNFX1VSTH0vc3RvcmFnZS92MS9vYmplY3QvcHVibGljLyR7YnVja2V0fS8ke2ZpbGVQYXRofWA7XG4gICAgY29uc29sZS5sb2coYFNhdmVkIHRvIGxvY2FsIHN0b3JhZ2U6ICR7bG9jYWxVcmx9YCk7XG4gICAgcmV0dXJuIGxvY2FsVXJsO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKGBFcnJvciBkb3dubG9hZGluZyB0byBzdG9yYWdlOmAsIGVycik7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuLy8gRmV0Y2ggd2l0aCByZXRyeSBsb2dpYyBmb3IgY29ubmVjdGlvbiBpc3N1ZXNcbmFzeW5jIGZ1bmN0aW9uIGZldGNoV2l0aFJldHJ5KHVybDogc3RyaW5nLCBvcHRpb25zOiBSZXF1ZXN0SW5pdCwgbWF4UmV0cmllcyA9IDIpOiBQcm9taXNlPFJlc3BvbnNlPiB7XG4gIGxldCBsYXN0RXJyb3I6IEVycm9yIHwgbnVsbCA9IG51bGw7XG4gIFxuICBmb3IgKGxldCBhdHRlbXB0ID0gMDsgYXR0ZW1wdCA8PSBtYXhSZXRyaWVzOyBhdHRlbXB0KyspIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCAxMDAwMCk7IC8vIDEwcyB0aW1lb3V0XG4gICAgICBcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICB9KTtcbiAgICAgIFxuICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxhc3RFcnJvciA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvciA6IG5ldyBFcnJvcihTdHJpbmcoZXJyb3IpKTtcbiAgICAgIGNvbnNvbGUubG9nKGBGZXRjaCBhdHRlbXB0ICR7YXR0ZW1wdCArIDF9IGZhaWxlZDpgLCBsYXN0RXJyb3IubWVzc2FnZSk7XG4gICAgICBcbiAgICAgIC8vIERvbid0IHJldHJ5IG9uIGFib3J0XG4gICAgICBpZiAobGFzdEVycm9yLm5hbWUgPT09ICdBYm9ydEVycm9yJykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJSZXF1ZXN0IHRpbWVvdXRcIik7XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIFdhaXQgYmVmb3JlIHJldHJ5IChleHBvbmVudGlhbCBiYWNrb2ZmKVxuICAgICAgaWYgKGF0dGVtcHQgPCBtYXhSZXRyaWVzKSB7XG4gICAgICAgIGF3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCAxMDAwICogKGF0dGVtcHQgKyAxKSkpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBcbiAgdGhyb3cgbGFzdEVycm9yIHx8IG5ldyBFcnJvcihcIkZhaWxlZCBhZnRlciByZXRyaWVzXCIpO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyPy5zdGFydHNXaXRoKFwiQmVhcmVyIFwiKSkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJObyBhdXRob3JpemF0aW9uIGhlYWRlclwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgc3VwYWJhc2VDbGllbnQgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgPz8gXCJcIixcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX0FOT05fS0VZXCIpID8/IFwiXCIsXG4gICAgICB7IGdsb2JhbDogeyBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGF1dGhIZWFkZXIgfSB9IH1cbiAgICApO1xuXG4gICAgLy8gR2V0IHVzZXIgdmlhIEFQSS1jb21wYXRpYmxlIGF1dGggZW5kcG9pbnRcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9LCBlcnJvcjogdXNlckVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudC5hdXRoLmdldFVzZXIoKTtcbiAgICBcbiAgICBpZiAodXNlckVycm9yIHx8ICF1c2VyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiQXV0aCBlcnJvcjpcIiwgdXNlckVycm9yKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG4gICAgXG4gICAgY29uc3QgdXNlcklkID0gdXNlci5pZDtcblxuICAgIGNvbnN0IHsgdGFza0lkOiByYXdUYXNrSWQsIHRyYWNrSWQgfSA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgXG4gICAgLy8gVHJpbSB3aGl0ZXNwYWNlIGZyb20gdGFza0lkIHRvIHByZXZlbnQgVVJMIGVuY29kaW5nIGlzc3Vlc1xuICAgIGNvbnN0IHRhc2tJZCA9IHJhd1Rhc2tJZD8udHJpbSgpO1xuXG4gICAgaWYgKCF0YXNrSWQpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiTWlzc2luZyB0YXNrSWRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBDaGVja2luZyBzdGF0dXMgZm9yIHRhc2sgJHt0YXNrSWR9YCk7XG5cbiAgICBsZXQgc3RhdHVzRGF0YTtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc3RhdHVzUmVzcG9uc2UgPSBhd2FpdCBmZXRjaFdpdGhSZXRyeShcbiAgICAgICAgYCR7U1VOT19BUElfQkFTRX0vYXBpL3YxL2dlbmVyYXRlL3JlY29yZC1pbmZvP3Rhc2tJZD0ke2VuY29kZVVSSUNvbXBvbmVudCh0YXNrSWQpfWAsXG4gICAgICAgIHtcbiAgICAgICAgICBtZXRob2Q6IFwiR0VUXCIsXG4gICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICAgICAgICB9LFxuICAgICAgICB9XG4gICAgICApO1xuICAgICAgc3RhdHVzRGF0YSA9IGF3YWl0IHN0YXR1c1Jlc3BvbnNlLmpzb24oKTtcbiAgICB9IGNhdGNoIChmZXRjaEVycm9yKSB7XG4gICAgICAvLyBOZXR3b3JrIGVycm9yIC0gZG9uJ3QgbWFyayB0cmFjayBhcyBmYWlsZWQsIGp1c3QgcmV0dXJuIHByb2Nlc3Npbmcgc3RhdHVzXG4gICAgICBjb25zb2xlLmxvZyhgTmV0d29yayBlcnJvciBjaGVja2luZyBzdGF0dXMgKHdpbGwgcmV0cnkgdmlhIHBvbGxpbmcpOmAsIGZldGNoRXJyb3IpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiLFxuICAgICAgICAgIG1lc3NhZ2U6IFwiTmV0d29yayBpc3N1ZSwgd2FpdGluZyBmb3IgY2FsbGJhY2tcIlxuICAgICAgICB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coXCJTdGF0dXMgcmVzcG9uc2U6XCIsIEpTT04uc3RyaW5naWZ5KHN0YXR1c0RhdGEpKTtcblxuICAgIGlmIChzdGF0dXNEYXRhLmNvZGUgPT09IDIwMCAmJiBzdGF0dXNEYXRhLmRhdGEpIHtcbiAgICAgIGNvbnN0IHJlY29yZHMgPSBzdGF0dXNEYXRhLmRhdGEucmVzcG9uc2U/LnN1bm9EYXRhIHx8IHN0YXR1c0RhdGEuZGF0YS5kYXRhIHx8IFtdO1xuICAgICAgY29uc3QgdGFza1N0YXR1cyA9IHN0YXR1c0RhdGEuZGF0YS5zdGF0dXM7XG4gICAgICBcbiAgICAgIGNvbnNvbGUubG9nKGBUYXNrIHN0YXR1czogJHt0YXNrU3RhdHVzfSwgUmVjb3JkczogJHtyZWNvcmRzLmxlbmd0aH1gKTtcbiAgICAgIFxuICAgICAgLy8gQ2hlY2sgZm9yIGZhaWxlZCBzdGF0dXMgLSBoYW5kbGUgR0VORVJBVEVfQVVESU9fRkFJTEVEIGFuZCBvdGhlciBmYWlsdXJlIHN0YXRlc1xuICAgICAgaWYgKHRhc2tTdGF0dXMgPT09IFwiR0VORVJBVEVfQVVESU9fRkFJTEVEXCIgfHwgdGFza1N0YXR1cyA9PT0gXCJGQUlMRURcIiB8fCB0YXNrU3RhdHVzID09PSBcIkVSUk9SXCIpIHtcbiAgICAgICAgY29uc29sZS5sb2coYFRhc2sgJHt0YXNrSWR9IGZhaWxlZCB3aXRoIHN0YXR1czogJHt0YXNrU3RhdHVzfWApO1xuICAgICAgICBcbiAgICAgICAgaWYgKHRyYWNrSWQpIHtcbiAgICAgICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBzdGF0dXNEYXRhLmRhdGEuZmFpbF9yZWFzb24gfHwgc3RhdHVzRGF0YS5kYXRhLmVycm9yX21lc3NhZ2UgfHwgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzRGF0YS5tc2cgfHwgXCLQk9C10L3QtdGA0LDRhtC40Y8g0L7RgtC60LvQvtC90LXQvdCwINGB0LXRgNCy0LjRgdC+0LxcIjtcbiAgICAgICAgICBcbiAgICAgICAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLFxuICAgICAgICAgICAgICBlcnJvcl9tZXNzYWdlOiBlcnJvck1lc3NhZ2UsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZClcbiAgICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKTtcblxuICAgICAgICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIGZhaWxlZCB0cmFjazpcIiwgdXBkYXRlRXJyb3IpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgICAgICBzdGF0dXM6IHRhc2tTdGF0dXMsXG4gICAgICAgICAgICBlcnJvcjogc3RhdHVzRGF0YS5kYXRhLmZhaWxfcmVhc29uIHx8IFwiR2VuZXJhdGlvbiBmYWlsZWRcIlxuICAgICAgICAgIH0pLFxuICAgICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIFN1bm8gcmVjb3JkLWluZm8gcmV0dXJucyBjYW1lbENhc2UgZmllbGRzIChhdWRpb1VybCwgaW1hZ2VVcmwpXG4gICAgICAvLyB3aGlsZSBjYWxsYmFjayB1c2VzIHNuYWtlX2Nhc2UgKGF1ZGlvX3VybCwgaW1hZ2VfdXJsKVxuICAgICAgLy8gTm9ybWFsaXplIHRvIGhhbmRsZSBib3RoIGZvcm1hdHNcbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWRSZWNvcmRzID0gcmVjb3Jkcy5tYXAoKHI6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KSA9PiAoe1xuICAgICAgICBhdWRpb1VybDogci5hdWRpb1VybCB8fCByLmF1ZGlvX3VybCB8fCByLnNvdXJjZV9hdWRpb191cmwgfHwgci5zb3VyY2VBdWRpb1VybCxcbiAgICAgICAgaW1hZ2VVcmw6IHIuaW1hZ2VVcmwgfHwgci5pbWFnZV91cmwgfHwgci5zb3VyY2VfaW1hZ2VfdXJsIHx8IHIuc291cmNlSW1hZ2VVcmwsXG4gICAgICAgIGR1cmF0aW9uOiByLmR1cmF0aW9uLFxuICAgICAgICBpZDogci5pZCxcbiAgICAgIH0pKTtcblxuICAgICAgLy8gQ2hlY2sgaWYgQU5ZIHJlY29yZCBoYXMgYSByZWFsIGF1ZGlvIFVSTCAobm90IGVtcHR5IHN0cmluZywgbnVsbCwgdW5kZWZpbmVkKVxuICAgICAgY29uc3QgaGFzQW55QXVkaW8gPSBub3JtYWxpemVkUmVjb3Jkcy5zb21lKFxuICAgICAgICAocjogeyBhdWRpb1VybDogdW5rbm93biB9KSA9PiByLmF1ZGlvVXJsICYmIFN0cmluZyhyLmF1ZGlvVXJsKSAhPT0gXCJcIiAmJiBTdHJpbmcoci5hdWRpb1VybCkgIT09IFwibnVsbFwiXG4gICAgICApO1xuXG4gICAgICBpZiAobm9ybWFsaXplZFJlY29yZHMubGVuZ3RoID4gMCAmJiBoYXNBbnlBdWRpbykge1xuICAgICAgICAvLyBGaW5kIEFMTCB0cmFja3MgbWF0Y2hpbmcgdGhpcyB0YXNrX2lkIChib3RoIHYxIGFuZCB2MilcbiAgICAgICAgY29uc3QgeyBkYXRhOiBtYXRjaGVkVHJhY2tzIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgLnNlbGVjdChcImlkLCB0aXRsZSwgZGVzY3JpcHRpb25cIilcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZClcbiAgICAgICAgICAuaW4oXCJzdGF0dXNcIiwgW1wicHJvY2Vzc2luZ1wiLCBcInBlbmRpbmdcIl0pXG4gICAgICAgICAgLm9yZGVyKFwiY3JlYXRlZF9hdFwiLCB7IGFzY2VuZGluZzogdHJ1ZSB9KTtcblxuICAgICAgICAvLyBGaWx0ZXIgdG8gdHJhY2tzIHRoYXQgaGF2ZSB0aGlzIHRhc2tfaWRcbiAgICAgICAgY29uc3QgdHJhY2tzV2l0aFRhc2sgPSAobWF0Y2hlZFRyYWNrcyB8fCBbXSkuZmlsdGVyKFxuICAgICAgICAgICh0OiB7IGRlc2NyaXB0aW9uPzogc3RyaW5nIH0pID0+IHQuZGVzY3JpcHRpb24/LmluY2x1ZGVzKGBbdGFza19pZDogJHt0YXNrSWR9XWApIHx8IHQuZGVzY3JpcHRpb24/LmluY2x1ZGVzKGBbdGFza19pZDoke3Rhc2tJZH1dYClcbiAgICAgICAgKTtcblxuICAgICAgICBjb25zb2xlLmxvZyhgRm91bmQgJHt0cmFja3NXaXRoVGFzay5sZW5ndGh9IHRyYWNrcyBtYXRjaGluZyB0YXNrX2lkICR7dGFza0lkfWApO1xuXG4gICAgICAgIC8vIFVwZGF0ZSBlYWNoIHRyYWNrIHdpdGggY29ycmVzcG9uZGluZyBTdW5vIHJlY29yZCAoYnkgb3JkZXI6IGZpcnN04oaSdjEsIHNlY29uZOKGknYyKVxuICAgICAgICAvLyBEb3dubG9hZCBmaWxlcyB0byBsb2NhbCBzdG9yYWdlIGZvciBwZXJzaXN0ZW50IGFjY2Vzc1xuICAgICAgICAvLyBDUklUSUNBTDogT25seSB1cGRhdGUgdHJhY2tzIHdoZXJlIHRoZSBjb3JyZXNwb25kaW5nIHJlY29yZCBoYXMgYSB2YWxpZCBhdWRpbyBVUkxcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0cmFja3NXaXRoVGFzay5sZW5ndGggJiYgaSA8IG5vcm1hbGl6ZWRSZWNvcmRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgY29uc3QgcmVjID0gbm9ybWFsaXplZFJlY29yZHNbaV07XG4gICAgICAgICAgY29uc3QgdHJrID0gdHJhY2tzV2l0aFRhc2tbaV07XG4gICAgICAgICAgXG4gICAgICAgICAgLy8gQ1JJVElDQUw6IFNraXAgcmVjb3JkcyB3aXRob3V0IHZhbGlkIGF1ZGlvIFVSTFxuICAgICAgICAgIC8vIFdoZW4gc3RhdHVzIGlzIEZJUlNUX1NVQ0NFU1MsIG9ubHkgb25lIG9mIHR3byByZWNvcmRzIGhhcyBhdWRpb1xuICAgICAgICAgIGNvbnN0IHJhd0F1ZGlvVXJsID0gcmVjLmF1ZGlvVXJsID8gU3RyaW5nKHJlYy5hdWRpb1VybCkgOiBcIlwiO1xuICAgICAgICAgIGlmICghcmF3QXVkaW9VcmwgfHwgcmF3QXVkaW9VcmwgPT09IFwiXCIgfHwgcmF3QXVkaW9VcmwgPT09IFwibnVsbFwiIHx8IHJhd0F1ZGlvVXJsID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgVHJhY2sgJHt0cmsuaWR9ICgke3Ryay50aXRsZX0pIOKAlCBubyBhdWRpbyBVUkwgeWV0LCBza2lwcGluZyAoc3RhdHVzOiAke3Rhc2tTdGF0dXN9KWApO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIFxuICAgICAgICAgIC8vIERvd25sb2FkIGF1ZGlvIHRvIGxvY2FsIHN0b3JhZ2VcbiAgICAgICAgICBsZXQgZmluYWxBdWRpb1VybCA9IHJhd0F1ZGlvVXJsO1xuICAgICAgICAgIGNvbnN0IGxvY2FsQXVkaW8gPSBhd2FpdCBkb3dubG9hZFRvTG9jYWxTdG9yYWdlKFxuICAgICAgICAgICAgZmluYWxBdWRpb1VybCxcbiAgICAgICAgICAgIFwidHJhY2tzXCIsXG4gICAgICAgICAgICBgYXVkaW8vJHt0cmsuaWR9Lm1wM2BcbiAgICAgICAgICApO1xuICAgICAgICAgIGlmIChsb2NhbEF1ZGlvKSBmaW5hbEF1ZGlvVXJsID0gbG9jYWxBdWRpbztcblxuICAgICAgICAgIC8vIERvd25sb2FkIGNvdmVyIHRvIGxvY2FsIHN0b3JhZ2VcbiAgICAgICAgICBsZXQgZmluYWxDb3ZlclVybDogc3RyaW5nIHwgbnVsbCA9IHJlYy5pbWFnZVVybCA/IFN0cmluZyhyZWMuaW1hZ2VVcmwpIDogbnVsbDtcbiAgICAgICAgICBpZiAoZmluYWxDb3ZlclVybCAmJiAoZmluYWxDb3ZlclVybCA9PT0gXCJudWxsXCIgfHwgZmluYWxDb3ZlclVybCA9PT0gXCJ1bmRlZmluZWRcIikpIHtcbiAgICAgICAgICAgIGZpbmFsQ292ZXJVcmwgPSBudWxsO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoZmluYWxDb3ZlclVybCkge1xuICAgICAgICAgICAgY29uc3QgbG9jYWxDb3ZlciA9IGF3YWl0IGRvd25sb2FkVG9Mb2NhbFN0b3JhZ2UoXG4gICAgICAgICAgICAgIGZpbmFsQ292ZXJVcmwsXG4gICAgICAgICAgICAgIFwidHJhY2tzXCIsXG4gICAgICAgICAgICAgIGBjb3ZlcnMvJHt0cmsuaWR9LmpwZ2BcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBpZiAobG9jYWxDb3ZlcikgZmluYWxDb3ZlclVybCA9IGxvY2FsQ292ZXI7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgICAgIGF1ZGlvX3VybDogZmluYWxBdWRpb1VybCxcbiAgICAgICAgICAgICAgY292ZXJfdXJsOiBmaW5hbENvdmVyVXJsLFxuICAgICAgICAgICAgICBkdXJhdGlvbjogcmVjLmR1cmF0aW9uID8gTWF0aC5yb3VuZChOdW1iZXIocmVjLmR1cmF0aW9uKSkgOiBudWxsLFxuICAgICAgICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmVxKFwiaWRcIiwgdHJrLmlkKVxuICAgICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuXG4gICAgICAgICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciB1cGRhdGluZyB0cmFjayAke3Ryay5pZH06YCwgdXBkYXRlRXJyb3IpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgVHJhY2sgJHt0cmsuaWR9ICgke3Ryay50aXRsZX0pIGNvbXBsZXRlZCB2aWEgcG9sbGluZyB3aXRoIGxvY2FsIHN0b3JhZ2VgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAobm9ybWFsaXplZFJlY29yZHMubGVuZ3RoID4gMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhgVGFzayAke3Rhc2tJZH06IHJlY29yZHMgZXhpc3QgYnV0IG5vIGF1ZGlvIFVSTHMgcmVhZHkgeWV0IChzdGF0dXM6ICR7dGFza1N0YXR1c30pYCk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICBzdGF0dXM6IHRhc2tTdGF0dXMsXG4gICAgICAgICAgcmVjb3Jkczogbm9ybWFsaXplZFJlY29yZHMgXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG4gICAgXG4gICAgLy8gSGFuZGxlIEFQSSBlcnJvciByZXNwb25zZSAtIGJ1dCBkb24ndCBtYXJrIGFzIGZhaWxlZCBmb3IgNDA0IChzdGlsbCBwcm9jZXNzaW5nKVxuICAgIGlmIChzdGF0dXNEYXRhLmNvZGUgIT09IDIwMCkge1xuICAgICAgY29uc29sZS5sb2coYFN1bm8gQVBJIHJlc3BvbnNlOiBjb2RlPSR7c3RhdHVzRGF0YS5jb2RlfSwgc3RhdHVzPSR7c3RhdHVzRGF0YS5zdGF0dXN9YCk7XG4gICAgICBcbiAgICAgIC8vIDQwNCBvZnRlbiBtZWFucyB0aGUgdGFzayBpcyBzdGlsbCBiZWluZyBwcm9jZXNzZWQgLSBkb24ndCBtYXJrIGFzIGZhaWxlZFxuICAgICAgaWYgKHN0YXR1c0RhdGEuc3RhdHVzID09PSA0MDQgfHwgc3RhdHVzRGF0YS5lcnJvciA9PT0gXCJOb3QgRm91bmRcIikge1xuICAgICAgICBjb25zb2xlLmxvZyhcIlRhc2sgbm90IGZvdW5kIGluIEFQSSAtIHN0aWxsIHByb2Nlc3NpbmcsIHdhaXRpbmcgZm9yIGNhbGxiYWNrXCIpO1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICAgIHN0YXR1czogXCJwcm9jZXNzaW5nXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcIlN0aWxsIHByb2Nlc3NpbmcsIHdhaXRpbmcgZm9yIGNhbGxiYWNrXCJcbiAgICAgICAgICB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgXG4gICAgICAvLyBGb3Igb3RoZXIgZXJyb3JzLCBtYXJrIGFzIGZhaWxlZCBvbmx5IGlmIGV4cGxpY2l0bHkgYW4gZXJyb3JcbiAgICAgIGlmICh0cmFja0lkICYmIHN0YXR1c0RhdGEuY29kZSAmJiBzdGF0dXNEYXRhLmNvZGUgPj0gNDAwICYmIHN0YXR1c0RhdGEuY29kZSA8IDUwMCAmJiBzdGF0dXNEYXRhLmNvZGUgIT09IDQwNCkge1xuICAgICAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLFxuICAgICAgICAgICAgZXJyb3JfbWVzc2FnZTogc3RhdHVzRGF0YS5tc2cgfHwgXCJBUEkgZXJyb3JcIixcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuXG4gICAgICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBmYWlsZWQgdHJhY2s6XCIsIHVwZGF0ZUVycm9yKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgIHN0YXR1czogXCJwcm9jZXNzaW5nXCIsXG4gICAgICAgICAgZXJyb3I6IHN0YXR1c0RhdGEubXNnIHx8IFwiQVBJIGVycm9yXCJcbiAgICAgICAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgc3RhdHVzOiBcInBlbmRpbmdcIixcbiAgICAgICAgZGF0YTogc3RhdHVzRGF0YVxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gc3Vuby1jaGVjay1zdGF0dXM6XCIsIGVycm9yKTtcbiAgICAvLyBEb24ndCByZXR1cm4gNTAwIGZvciBuZXR3b3JrIGlzc3VlcyAtIGp1c3QgaW5kaWNhdGUgc3RpbGwgcHJvY2Vzc2luZ1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgc3RhdHVzOiBcInByb2Nlc3NpbmdcIixcbiAgICAgICAgbWVzc2FnZTogXCJDaGVja2luZyBzdGF0dXMsIHdhaXRpbmcgZm9yIGNhbGxiYWNrXCJcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTsiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2xDLE1BQU0sZ0JBQWdCO0FBQ3RCLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CO0FBQ3JELE1BQU0sbUJBQW1CLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0M7QUFDdEUsTUFBTSxXQUFXLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxlQUFlO0FBRTdDLDJEQUEyRDtBQUMzRCxlQUFlLHVCQUNiLFdBQW1CLEVBQ25CLE1BQWMsRUFDZCxRQUFnQjtFQUVoQixJQUFJO0lBQ0YsUUFBUSxHQUFHLENBQUMsQ0FBQyxZQUFZLEVBQUUsWUFBWSxHQUFHLEVBQUUsT0FBTyxDQUFDLEVBQUUsU0FBUyxDQUFDO0lBQ2hFLE1BQU0sT0FBTyxNQUFNLE1BQU07SUFDekIsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFO01BQ1osUUFBUSxHQUFHLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLE1BQU0sQ0FBQyxDQUFDO01BQzdDLE9BQU87SUFDVDtJQUNBLE1BQU0sT0FBTyxNQUFNLEtBQUssSUFBSTtJQUM1QixNQUFNLFNBQVMsSUFBSSxXQUFXLE1BQU0sS0FBSyxXQUFXO0lBRXBELCtDQUErQztJQUMvQyxNQUFNLGFBQWEsTUFBTSxNQUN2QixDQUFDLEVBQUUsYUFBYSxtQkFBbUIsRUFBRSxPQUFPLENBQUMsRUFBRSxTQUFTLENBQUMsRUFDekQ7TUFDRSxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQixLQUFLLElBQUksSUFBSTtRQUM3QixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLENBQUM7TUFDL0M7TUFDQSxNQUFNO0lBQ1I7SUFHRixJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUU7TUFDbEIsTUFBTSxVQUFVLE1BQU0sV0FBVyxJQUFJO01BQ3JDLFFBQVEsR0FBRyxDQUFDLENBQUMsMEJBQTBCLEVBQUUsV0FBVyxNQUFNLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQztNQUN2RSxPQUFPO0lBQ1Q7SUFFQSxNQUFNLFdBQVcsQ0FBQyxFQUFFLFNBQVMsMEJBQTBCLEVBQUUsT0FBTyxDQUFDLEVBQUUsU0FBUyxDQUFDO0lBQzdFLFFBQVEsR0FBRyxDQUFDLENBQUMsd0JBQXdCLEVBQUUsU0FBUyxDQUFDO0lBQ2pELE9BQU87RUFDVCxFQUFFLE9BQU8sS0FBSztJQUNaLFFBQVEsS0FBSyxDQUFDLENBQUMsNkJBQTZCLENBQUMsRUFBRTtJQUMvQyxPQUFPO0VBQ1Q7QUFDRjtBQUVBLCtDQUErQztBQUMvQyxlQUFlLGVBQWUsR0FBVyxFQUFFLE9BQW9CLEVBQUUsYUFBYSxDQUFDO0VBQzdFLElBQUksWUFBMEI7RUFFOUIsSUFBSyxJQUFJLFVBQVUsR0FBRyxXQUFXLFlBQVksVUFBVztJQUN0RCxJQUFJO01BQ0YsTUFBTSxhQUFhLElBQUk7TUFDdkIsTUFBTSxZQUFZLFdBQVcsSUFBTSxXQUFXLEtBQUssSUFBSSxRQUFRLGNBQWM7TUFFN0UsTUFBTSxXQUFXLE1BQU0sTUFBTSxLQUFLO1FBQ2hDLEdBQUcsT0FBTztRQUNWLFFBQVEsV0FBVyxNQUFNO01BQzNCO01BRUEsYUFBYTtNQUNiLE9BQU87SUFDVCxFQUFFLE9BQU8sT0FBTztNQUNkLFlBQVksaUJBQWlCLFFBQVEsUUFBUSxJQUFJLE1BQU0sT0FBTztNQUM5RCxRQUFRLEdBQUcsQ0FBQyxDQUFDLGNBQWMsRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDLEVBQUUsVUFBVSxPQUFPO01BRXJFLHVCQUF1QjtNQUN2QixJQUFJLFVBQVUsSUFBSSxLQUFLLGNBQWM7UUFDbkMsTUFBTSxJQUFJLE1BQU07TUFDbEI7TUFFQSwwQ0FBMEM7TUFDMUMsSUFBSSxVQUFVLFlBQVk7UUFDeEIsTUFBTSxJQUFJLFFBQVEsQ0FBQSxVQUFXLFdBQVcsU0FBUyxPQUFPLENBQUMsVUFBVSxDQUFDO01BQ3RFO0lBQ0Y7RUFDRjtFQUVBLE1BQU0sYUFBYSxJQUFJLE1BQU07QUFDL0I7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZLFdBQVcsWUFBWTtNQUN0QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBMEIsSUFDbEQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxpQkFBaUIsYUFDckIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLElBQ3JDO01BQUUsUUFBUTtRQUFFLFNBQVM7VUFBRSxlQUFlO1FBQVc7TUFBRTtJQUFFO0lBR3ZELDRDQUE0QztJQUM1QyxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxPQUFPO0lBRTlFLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsUUFBUSxLQUFLLENBQUMsZUFBZTtNQUM3QixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFNBQVMsS0FBSyxFQUFFO0lBRXRCLE1BQU0sRUFBRSxRQUFRLFNBQVMsRUFBRSxPQUFPLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUVyRCw2REFBNkQ7SUFDN0QsTUFBTSxTQUFTLFdBQVc7SUFFMUIsSUFBSSxDQUFDLFFBQVE7TUFDWCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBaUIsSUFDekM7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBRSxPQUFPLENBQUM7SUFFaEQsSUFBSTtJQUNKLElBQUk7TUFDRixNQUFNLGlCQUFpQixNQUFNLGVBQzNCLENBQUMsRUFBRSxjQUFjLG9DQUFvQyxFQUFFLG1CQUFtQixRQUFRLENBQUMsRUFDbkY7UUFDRSxRQUFRO1FBQ1IsU0FBUztVQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7UUFDM0M7TUFDRjtNQUVGLGFBQWEsTUFBTSxlQUFlLElBQUk7SUFDeEMsRUFBRSxPQUFPLFlBQVk7TUFDbkIsNEVBQTRFO01BQzVFLFFBQVEsR0FBRyxDQUFDLENBQUMsdURBQXVELENBQUMsRUFBRTtNQUN2RSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVCxRQUFRO1FBQ1IsU0FBUztNQUNYLElBQ0E7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxRQUFRLEdBQUcsQ0FBQyxvQkFBb0IsS0FBSyxTQUFTLENBQUM7SUFFL0MsSUFBSSxXQUFXLElBQUksS0FBSyxPQUFPLFdBQVcsSUFBSSxFQUFFO01BQzlDLE1BQU0sVUFBVSxXQUFXLElBQUksQ0FBQyxRQUFRLEVBQUUsWUFBWSxXQUFXLElBQUksQ0FBQyxJQUFJLElBQUksRUFBRTtNQUNoRixNQUFNLGFBQWEsV0FBVyxJQUFJLENBQUMsTUFBTTtNQUV6QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLGFBQWEsRUFBRSxXQUFXLFdBQVcsRUFBRSxRQUFRLE1BQU0sQ0FBQyxDQUFDO01BRXBFLGtGQUFrRjtNQUNsRixJQUFJLGVBQWUsMkJBQTJCLGVBQWUsWUFBWSxlQUFlLFNBQVM7UUFDL0YsUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxxQkFBcUIsRUFBRSxXQUFXLENBQUM7UUFFOUQsSUFBSSxTQUFTO1VBQ1gsTUFBTSxlQUFlLFdBQVcsSUFBSSxDQUFDLFdBQVcsSUFBSSxXQUFXLElBQUksQ0FBQyxhQUFhLElBQzVELFdBQVcsR0FBRyxJQUFJO1VBRXZDLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sZUFDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1lBQ04sUUFBUTtZQUNSLGVBQWU7VUFDakIsR0FDQyxFQUFFLENBQUMsTUFBTSxTQUNULEVBQUUsQ0FBQyxXQUFXO1VBRWpCLElBQUksYUFBYTtZQUNmLFFBQVEsS0FBSyxDQUFDLGdDQUFnQztVQUNoRDtRQUNGO1FBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsUUFBUTtVQUNSLE9BQU8sV0FBVyxJQUFJLENBQUMsV0FBVyxJQUFJO1FBQ3hDLElBQ0E7VUFBRSxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFdEU7TUFFQSxpRUFBaUU7TUFDakUsd0RBQXdEO01BQ3hELG1DQUFtQztNQUNuQyxNQUFNLG9CQUFvQixRQUFRLEdBQUcsQ0FBQyxDQUFDLElBQStCLENBQUM7VUFDckUsVUFBVSxFQUFFLFFBQVEsSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLGdCQUFnQixJQUFJLEVBQUUsY0FBYztVQUM3RSxVQUFVLEVBQUUsUUFBUSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsZ0JBQWdCLElBQUksRUFBRSxjQUFjO1VBQzdFLFVBQVUsRUFBRSxRQUFRO1VBQ3BCLElBQUksRUFBRSxFQUFFO1FBQ1YsQ0FBQztNQUVELCtFQUErRTtNQUMvRSxNQUFNLGNBQWMsa0JBQWtCLElBQUksQ0FDeEMsQ0FBQyxJQUE2QixFQUFFLFFBQVEsSUFBSSxPQUFPLEVBQUUsUUFBUSxNQUFNLE1BQU0sT0FBTyxFQUFFLFFBQVEsTUFBTTtNQUdsRyxJQUFJLGtCQUFrQixNQUFNLEdBQUcsS0FBSyxhQUFhO1FBQy9DLHlEQUF5RDtRQUN6RCxNQUFNLEVBQUUsTUFBTSxhQUFhLEVBQUUsR0FBRyxNQUFNLGVBQ25DLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQywwQkFDUCxFQUFFLENBQUMsV0FBVyxRQUNkLEVBQUUsQ0FBQyxVQUFVO1VBQUM7VUFBYztTQUFVLEVBQ3RDLEtBQUssQ0FBQyxjQUFjO1VBQUUsV0FBVztRQUFLO1FBRXpDLDBDQUEwQztRQUMxQyxNQUFNLGlCQUFpQixDQUFDLGlCQUFpQixFQUFFLEVBQUUsTUFBTSxDQUNqRCxDQUFDLElBQWdDLEVBQUUsV0FBVyxFQUFFLFNBQVMsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxTQUFTLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBR25JLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLGVBQWUsTUFBTSxDQUFDLHlCQUF5QixFQUFFLE9BQU8sQ0FBQztRQUU5RSxtRkFBbUY7UUFDbkYsd0RBQXdEO1FBQ3hELG9GQUFvRjtRQUNwRixJQUFLLElBQUksSUFBSSxHQUFHLElBQUksZUFBZSxNQUFNLElBQUksSUFBSSxrQkFBa0IsTUFBTSxFQUFFLElBQUs7VUFDOUUsTUFBTSxNQUFNLGlCQUFpQixDQUFDLEVBQUU7VUFDaEMsTUFBTSxNQUFNLGNBQWMsQ0FBQyxFQUFFO1VBRTdCLGlEQUFpRDtVQUNqRCxrRUFBa0U7VUFDbEUsTUFBTSxjQUFjLElBQUksUUFBUSxHQUFHLE9BQU8sSUFBSSxRQUFRLElBQUk7VUFDMUQsSUFBSSxDQUFDLGVBQWUsZ0JBQWdCLE1BQU0sZ0JBQWdCLFVBQVUsZ0JBQWdCLGFBQWE7WUFDL0YsUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFLElBQUksS0FBSyxDQUFDLHdDQUF3QyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBQ2pHO1VBQ0Y7VUFFQSxrQ0FBa0M7VUFDbEMsSUFBSSxnQkFBZ0I7VUFDcEIsTUFBTSxhQUFhLE1BQU0sdUJBQ3ZCLGVBQ0EsVUFDQSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUM7VUFFdkIsSUFBSSxZQUFZLGdCQUFnQjtVQUVoQyxrQ0FBa0M7VUFDbEMsSUFBSSxnQkFBK0IsSUFBSSxRQUFRLEdBQUcsT0FBTyxJQUFJLFFBQVEsSUFBSTtVQUN6RSxJQUFJLGlCQUFpQixDQUFDLGtCQUFrQixVQUFVLGtCQUFrQixXQUFXLEdBQUc7WUFDaEYsZ0JBQWdCO1VBQ2xCO1VBQ0EsSUFBSSxlQUFlO1lBQ2pCLE1BQU0sYUFBYSxNQUFNLHVCQUN2QixlQUNBLFVBQ0EsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDO1lBRXhCLElBQUksWUFBWSxnQkFBZ0I7VUFDbEM7VUFFQSxNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLGVBQ2xDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztZQUNOLFdBQVc7WUFDWCxXQUFXO1lBQ1gsVUFBVSxJQUFJLFFBQVEsR0FBRyxLQUFLLEtBQUssQ0FBQyxPQUFPLElBQUksUUFBUSxLQUFLO1lBQzVELFFBQVE7VUFDVixHQUNDLEVBQUUsQ0FBQyxNQUFNLElBQUksRUFBRSxFQUNmLEVBQUUsQ0FBQyxXQUFXO1VBRWpCLElBQUksYUFBYTtZQUNmLFFBQVEsS0FBSyxDQUFDLENBQUMscUJBQXFCLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUU7VUFDbkQsT0FBTztZQUNMLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsRUFBRSxJQUFJLEtBQUssQ0FBQywwQ0FBMEMsQ0FBQztVQUN2RjtRQUNGO01BQ0YsT0FBTyxJQUFJLGtCQUFrQixNQUFNLEdBQUcsR0FBRztRQUN2QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxPQUFPLHFEQUFxRCxFQUFFLFdBQVcsQ0FBQyxDQUFDO01BQ2pHO01BRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixTQUFTO1FBQ1QsUUFBUTtRQUNSLFNBQVM7TUFDWCxJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsa0ZBQWtGO0lBQ2xGLElBQUksV0FBVyxJQUFJLEtBQUssS0FBSztNQUMzQixRQUFRLEdBQUcsQ0FBQyxDQUFDLHdCQUF3QixFQUFFLFdBQVcsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLE1BQU0sQ0FBQyxDQUFDO01BRXJGLDJFQUEyRTtNQUMzRSxJQUFJLFdBQVcsTUFBTSxLQUFLLE9BQU8sV0FBVyxLQUFLLEtBQUssYUFBYTtRQUNqRSxRQUFRLEdBQUcsQ0FBQztRQUNaLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQ2IsU0FBUztVQUNULFFBQVE7VUFDUixTQUFTO1FBQ1gsSUFDQTtVQUFFLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUV0RTtNQUVBLCtEQUErRDtNQUMvRCxJQUFJLFdBQVcsV0FBVyxJQUFJLElBQUksV0FBVyxJQUFJLElBQUksT0FBTyxXQUFXLElBQUksR0FBRyxPQUFPLFdBQVcsSUFBSSxLQUFLLEtBQUs7UUFDNUcsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxlQUNsQyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7VUFDTixRQUFRO1VBQ1IsZUFBZSxXQUFXLEdBQUcsSUFBSTtRQUNuQyxHQUNDLEVBQUUsQ0FBQyxNQUFNLFNBQ1QsRUFBRSxDQUFDLFdBQVc7UUFFakIsSUFBSSxhQUFhO1VBQ2YsUUFBUSxLQUFLLENBQUMsZ0NBQWdDO1FBQ2hEO01BQ0Y7TUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVCxRQUFRO1FBQ1IsT0FBTyxXQUFXLEdBQUcsSUFBSTtNQUMzQixJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsUUFBUTtNQUNSLE1BQU07SUFDUixJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsK0JBQStCO0lBQzdDLHVFQUF1RTtJQUN2RSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxRQUFRO01BQ1IsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEU7QUFDRiJ9
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
// Generate SILK-compatible XML metadata
function generateSilkXml(track) {
  const now = new Date().toISOString();
  const releaseDate = track.processing_completed_at || now;
  const genreName = track.genre?.[0]?.name || 'Electronic';
  const genreNameRu = track.genre?.[0]?.name_ru || 'Электронная';
  const uploaderName = track.profiles?.[0]?.username || 'Unknown';
  return `<?xml version="1.0" encoding="UTF-8"?>
<release xmlns="http://silk.ru/schema/release/v1">
  <metadata>
    <format_version>1.0</format_version>
    <generated_at>${now}</generated_at>
    <generator>Notafeya Distribution Platform</generator>
  </metadata>
  
  <release_info>
    <internal_id>${track.id}</internal_id>
    <isrc>${track.isrc_code || 'PENDING'}</isrc>
    <title><![CDATA[${track.title}]]></title>
    <artist><![CDATA[${track.performer_name}]]></artist>
    <label><![CDATA[${track.label_name || 'Notafeya Records'}]]></label>
    <release_date>${releaseDate.split('T')[0]}</release_date>
    <genre>${genreName}</genre>
    <genre_ru>${genreNameRu}</genre_ru>
    <duration_seconds>${Math.round(track.duration || 0)}</duration_seconds>
  </release_info>
  
  <credits>
    <music_author><![CDATA[${track.music_author || track.performer_name}]]></music_author>
    <lyrics_author><![CDATA[${track.lyrics_author || 'Instrumental'}]]></lyrics_author>
    <performer><![CDATA[${track.performer_name}]]></performer>
    <producer><![CDATA[${track.performer_name}]]></producer>
    <uploader><![CDATA[${uploaderName}]]></uploader>
  </credits>
  
  <technical>
    <audio_format>WAV</audio_format>
    <bit_depth>24</bit_depth>
    <sample_rate>44100</sample_rate>
    <loudness_standard>-14 LUFS</loudness_standard>
    <mastered>true</mastered>
    <metadata_cleaned>true</metadata_cleaned>
  </technical>
  
  <blockchain>
    <hash>${track.blockchain_hash || 'N/A'}</hash>
    <timestamp>${releaseDate}</timestamp>
    <network>OpenTimestamps</network>
    <verified>true</verified>
  </blockchain>
  
  <assets>
    <master_audio>${track.master_audio_url ? 'included' : 'pending'}</master_audio>
    <cover_art resolution="3000x3000">${track.cover_url ? 'included' : 'pending'}</cover_art>
    <promo_video>not_available</promo_video>
    <certificate>${track.certificate_url ? 'included' : 'pending'}</certificate>
  </assets>
  
  <distribution>
    <platforms>
      <platform name="Spotify" status="ready"/>
      <platform name="Apple Music" status="ready"/>
      <platform name="Yandex Music" status="ready"/>
      <platform name="VK Music" status="ready"/>
      <platform name="Deezer" status="ready"/>
      <platform name="SoundCloud" status="ready"/>
    </platforms>
    <territory>Worldwide</territory>
    <exclusive>false</exclusive>
  </distribution>
  
  <legal>
    <copyright>© ${new Date().getFullYear()} ${track.label_name || 'Notafeya Records'}. All rights reserved.</copyright>
    <license>Standard Distribution License</license>
    <content_rating>Unrated</content_rating>
  </legal>
</release>`;
}
// Generate PDF certificate HTML (would be converted to PDF in production)
function generateCertificateHtml(track) {
  const now = new Date();
  const formattedDate = now.toLocaleDateString('ru-RU', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  return `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Сертификат авторства - ${track.title}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=Montserrat:wght@300;400;600&display=swap');
    
    * { margin: 0; padding: 0; box-sizing: border-box; }
    
    body {
      font-family: 'Montserrat', sans-serif;
      background: linear-gradient(135deg, #0f0f23 0%, #1a1a3e 50%, #0f0f23 100%);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 40px;
    }
    
    .certificate {
      background: linear-gradient(180deg, #fefefe 0%, #f8f6f0 100%);
      border: 3px solid #c9a962;
      border-radius: 8px;
      padding: 60px 80px;
      max-width: 800px;
      width: 100%;
      position: relative;
      box-shadow: 0 20px 60px rgba(0,0,0,0.5);
    }
    
    .certificate::before {
      content: '';
      position: absolute;
      top: 15px;
      left: 15px;
      right: 15px;
      bottom: 15px;
      border: 1px solid #c9a962;
      border-radius: 4px;
      pointer-events: none;
    }
    
    .header {
      text-align: center;
      margin-bottom: 40px;
    }
    
    .logo {
      font-family: 'Cormorant Garamond', serif;
      font-size: 18px;
      color: #666;
      letter-spacing: 4px;
      text-transform: uppercase;
      margin-bottom: 20px;
    }
    
    .title {
      font-family: 'Cormorant Garamond', serif;
      font-size: 42px;
      font-weight: 700;
      color: #1a1a2e;
      margin-bottom: 10px;
    }
    
    .subtitle {
      font-size: 14px;
      color: #666;
      letter-spacing: 2px;
      text-transform: uppercase;
    }
    
    .divider {
      height: 2px;
      background: linear-gradient(90deg, transparent, #c9a962, transparent);
      margin: 30px 0;
    }
    
    .content {
      text-align: center;
    }
    
    .track-title {
      font-family: 'Cormorant Garamond', serif;
      font-size: 28px;
      font-weight: 600;
      color: #1a1a2e;
      margin-bottom: 15px;
    }
    
    .track-artist {
      font-size: 18px;
      color: #444;
      margin-bottom: 30px;
    }
    
    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin: 30px 0;
      text-align: left;
    }
    
    .info-item {
      padding: 15px;
      background: rgba(201, 169, 98, 0.1);
      border-radius: 4px;
    }
    
    .info-label {
      font-size: 11px;
      color: #888;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 5px;
    }
    
    .info-value {
      font-size: 14px;
      color: #1a1a2e;
      font-weight: 500;
    }
    
    .blockchain-section {
      margin: 40px 0;
      padding: 25px;
      background: #1a1a2e;
      border-radius: 6px;
      color: white;
    }
    
    .blockchain-title {
      font-size: 12px;
      color: #c9a962;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin-bottom: 15px;
    }
    
    .blockchain-hash {
      font-family: 'Courier New', monospace;
      font-size: 11px;
      word-break: break-all;
      color: #8be9fd;
      background: rgba(0,0,0,0.3);
      padding: 15px;
      border-radius: 4px;
    }
    
    .footer {
      margin-top: 40px;
      text-align: center;
    }
    
    .seal {
      width: 100px;
      height: 100px;
      margin: 0 auto 20px;
      border: 3px solid #c9a962;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Cormorant Garamond', serif;
      font-size: 12px;
      color: #c9a962;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    
    .date {
      font-size: 14px;
      color: #666;
    }
    
    .certificate-id {
      margin-top: 15px;
      font-size: 11px;
      color: #999;
      letter-spacing: 1px;
    }
  </style>
</head>
<body>
  <div class="certificate">
    <div class="header">
      <div class="logo">♪ Notafeya Records ♪</div>
      <h1 class="title">Сертификат Авторства</h1>
      <p class="subtitle">Certificate of Authorship</p>
    </div>
    
    <div class="divider"></div>
    
    <div class="content">
      <h2 class="track-title">"${track.title}"</h2>
      <p class="track-artist">Исполнитель: ${track.performer_name}</p>
      
      <div class="info-grid">
        <div class="info-item">
          <div class="info-label">Автор музыки</div>
          <div class="info-value">${track.music_author || track.performer_name}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Автор текста</div>
          <div class="info-value">${track.lyrics_author || 'Инструментал'}</div>
        </div>
        <div class="info-item">
          <div class="info-label">ISRC код</div>
          <div class="info-value">${track.isrc_code || 'В обработке'}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Лейбл</div>
          <div class="info-value">${track.label_name || 'Notafeya Records'}</div>
        </div>
      </div>
      
      <div class="blockchain-section">
        <div class="blockchain-title">⛓ Blockchain Verification</div>
        <div class="blockchain-hash">${track.blockchain_hash || 'Hash pending...'}</div>
      </div>
    </div>
    
    <div class="footer">
      <div class="seal">Verified<br/>✓</div>
      <p class="date">${formattedDate}</p>
      <p class="certificate-id">ID: ${track.id.substring(0, 8).toUpperCase()}</p>
    </div>
  </div>
</body>
</html>`;
}
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '');
    const { trackId } = await req.json();
    console.log(`[generate-gold-pack] Starting for track: ${trackId}`);
    if (!trackId) {
      throw new Error('trackId is required');
    }
    // Get track with all metadata
    const { data: track, error: trackError } = await supabase.from('tracks').select(`
        id, title, performer_name, music_author, lyrics_author, label_name,
        isrc_code, duration, blockchain_hash, cover_url, master_audio_url,
        certificate_url, created_at, processing_completed_at,
        profiles:user_id(username),
        genre:genres(name_ru, name)
      `).eq('id', trackId).single();
    if (trackError || !track) {
      throw new Error('Track not found');
    }
    console.log(`[generate-gold-pack] Generating assets for: ${track.title}`);
    // Generate SILK XML metadata
    const xmlContent = generateSilkXml(track);
    const xmlFileName = `gold-packs/${trackId}/metadata_silk.xml`;
    const { error: xmlUploadError } = await supabase.storage.from('tracks').upload(xmlFileName, new Blob([
      xmlContent
    ], {
      type: 'application/xml'
    }), {
      upsert: true,
      contentType: 'application/xml'
    });
    if (xmlUploadError) {
      console.error('[generate-gold-pack] XML upload error:', xmlUploadError);
    }
    // Generate certificate HTML (in production would convert to PDF)
    const certificateHtml = generateCertificateHtml(track);
    const certificateFileName = `gold-packs/${trackId}/certificate.html`;
    const { error: certUploadError } = await supabase.storage.from('tracks').upload(certificateFileName, new Blob([
      certificateHtml
    ], {
      type: 'text/html'
    }), {
      upsert: true,
      contentType: 'text/html'
    });
    if (certUploadError) {
      console.error('[generate-gold-pack] Certificate upload error:', certUploadError);
    }
    // Get public URLs
    const { data: xmlUrl } = supabase.storage.from('tracks').getPublicUrl(xmlFileName);
    const { data: certUrl } = supabase.storage.from('tracks').getPublicUrl(certificateFileName);
    // Generate pack manifest
    const manifest = {
      version: '1.0',
      generated_at: new Date().toISOString(),
      track_id: track.id,
      track_title: track.title,
      artist: track.performer_name,
      isrc: track.isrc_code,
      blockchain_hash: track.blockchain_hash,
      contents: {
        master_audio: {
          format: 'WAV 24-bit/44.1kHz',
          url: track.master_audio_url,
          status: track.master_audio_url ? 'included' : 'pending'
        },
        cover_art: {
          format: 'JPEG 3000x3000',
          url: track.cover_url,
          status: track.cover_url ? 'included' : 'pending'
        },
        metadata: {
          format: 'SILK XML v1.0',
          url: xmlUrl.publicUrl,
          status: 'included'
        },
        certificate: {
          format: 'HTML/PDF',
          url: certUrl.publicUrl,
          status: 'included'
        },
        promo_video: {
          format: 'MP4 1080p',
          url: null,
          status: 'not_available'
        }
      },
      distribution: {
        platforms: [
          'Spotify',
          'Apple Music',
          'Yandex Music',
          'VK Music',
          'Deezer',
          'SoundCloud'
        ],
        territory: 'Worldwide',
        release_ready: true
      }
    };
    const manifestFileName = `gold-packs/${trackId}/manifest.json`;
    await supabase.storage.from('tracks').upload(manifestFileName, new Blob([
      JSON.stringify(manifest, null, 2)
    ], {
      type: 'application/json'
    }), {
      upsert: true,
      contentType: 'application/json'
    });
    const { data: manifestUrl } = supabase.storage.from('tracks').getPublicUrl(manifestFileName);
    // Update track with gold pack URL (manifest as entry point)
    await supabase.from('tracks').update({
      gold_pack_url: manifestUrl.publicUrl,
      certificate_url: certUrl.publicUrl
    }).eq('id', trackId);
    // Log the gold pack generation
    const { data: userData } = await supabase.from('tracks').select('user_id').eq('id', trackId).single();
    if (userData) {
      await supabase.from('distribution_logs').insert({
        track_id: trackId,
        user_id: userData.user_id,
        action: 'gold_pack_generated',
        stage: 'level_pro',
        details: {
          manifest_url: manifestUrl.publicUrl,
          xml_url: xmlUrl.publicUrl,
          certificate_url: certUrl.publicUrl,
          has_master: !!track.master_audio_url,
          has_cover: !!track.cover_url,
          has_video: false
        }
      });
      // Notify user
      await supabase.from('notifications').insert({
        user_id: userData.user_id,
        type: 'system',
        title: '📦 Золотой пакет SILK готов!',
        message: `Ваш трек "${track.title}" готов к дистрибуции. WAV, XML-метаданные и сертификат доступны для скачивания.`,
        target_type: 'track',
        target_id: trackId
      });
    }
    return new Response(JSON.stringify({
      success: true,
      goldPack: {
        manifestUrl: manifestUrl.publicUrl,
        xmlUrl: xmlUrl.publicUrl,
        certificateUrl: certUrl.publicUrl,
        masterAudioUrl: track.master_audio_url,
        coverUrl: track.cover_url,
        promoVideoUrl: null
      }
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('[generate-gold-pack] Error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({
      success: false,
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9nZW5lcmF0ZS1nb2xkLXBhY2sudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9O1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6ICdhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZScsXG59O1xuXG5pbnRlcmZhY2UgR29sZFBhY2tSZXF1ZXN0IHtcbiAgdHJhY2tJZDogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgVHJhY2tNZXRhZGF0YSB7XG4gIGlkOiBzdHJpbmc7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIHBlcmZvcm1lcl9uYW1lOiBzdHJpbmc7XG4gIG11c2ljX2F1dGhvcjogc3RyaW5nIHwgbnVsbDtcbiAgbHlyaWNzX2F1dGhvcjogc3RyaW5nIHwgbnVsbDtcbiAgbGFiZWxfbmFtZTogc3RyaW5nIHwgbnVsbDtcbiAgaXNyY19jb2RlOiBzdHJpbmcgfCBudWxsO1xuICBkdXJhdGlvbjogbnVtYmVyO1xuICBnZW5yZTogeyBuYW1lX3J1OiBzdHJpbmc7IG5hbWU6IHN0cmluZyB9W10gfCBudWxsO1xuICBibG9ja2NoYWluX2hhc2g6IHN0cmluZyB8IG51bGw7XG4gIGNvdmVyX3VybDogc3RyaW5nIHwgbnVsbDtcbiAgbWFzdGVyX2F1ZGlvX3VybDogc3RyaW5nIHwgbnVsbDtcbiAgY2VydGlmaWNhdGVfdXJsOiBzdHJpbmcgfCBudWxsO1xuICBjcmVhdGVkX2F0OiBzdHJpbmc7XG4gIHByb2Nlc3NpbmdfY29tcGxldGVkX2F0OiBzdHJpbmcgfCBudWxsO1xuICBwcm9maWxlczogeyB1c2VybmFtZTogc3RyaW5nIHwgbnVsbCB9W10gfCBudWxsO1xufVxuXG4vLyBHZW5lcmF0ZSBTSUxLLWNvbXBhdGlibGUgWE1MIG1ldGFkYXRhXG5mdW5jdGlvbiBnZW5lcmF0ZVNpbGtYbWwodHJhY2s6IFRyYWNrTWV0YWRhdGEpOiBzdHJpbmcge1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gIGNvbnN0IHJlbGVhc2VEYXRlID0gdHJhY2sucHJvY2Vzc2luZ19jb21wbGV0ZWRfYXQgfHwgbm93O1xuICBjb25zdCBnZW5yZU5hbWUgPSB0cmFjay5nZW5yZT8uWzBdPy5uYW1lIHx8ICdFbGVjdHJvbmljJztcbiAgY29uc3QgZ2VucmVOYW1lUnUgPSB0cmFjay5nZW5yZT8uWzBdPy5uYW1lX3J1IHx8ICfQrdC70LXQutGC0YDQvtC90L3QsNGPJztcbiAgY29uc3QgdXBsb2FkZXJOYW1lID0gdHJhY2sucHJvZmlsZXM/LlswXT8udXNlcm5hbWUgfHwgJ1Vua25vd24nO1xuICBcbiAgcmV0dXJuIGA8P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJVVEYtOFwiPz5cbjxyZWxlYXNlIHhtbG5zPVwiaHR0cDovL3NpbGsucnUvc2NoZW1hL3JlbGVhc2UvdjFcIj5cbiAgPG1ldGFkYXRhPlxuICAgIDxmb3JtYXRfdmVyc2lvbj4xLjA8L2Zvcm1hdF92ZXJzaW9uPlxuICAgIDxnZW5lcmF0ZWRfYXQ+JHtub3d9PC9nZW5lcmF0ZWRfYXQ+XG4gICAgPGdlbmVyYXRvcj5Ob3RhZmV5YSBEaXN0cmlidXRpb24gUGxhdGZvcm08L2dlbmVyYXRvcj5cbiAgPC9tZXRhZGF0YT5cbiAgXG4gIDxyZWxlYXNlX2luZm8+XG4gICAgPGludGVybmFsX2lkPiR7dHJhY2suaWR9PC9pbnRlcm5hbF9pZD5cbiAgICA8aXNyYz4ke3RyYWNrLmlzcmNfY29kZSB8fCAnUEVORElORyd9PC9pc3JjPlxuICAgIDx0aXRsZT48IVtDREFUQVske3RyYWNrLnRpdGxlfV1dPjwvdGl0bGU+XG4gICAgPGFydGlzdD48IVtDREFUQVske3RyYWNrLnBlcmZvcm1lcl9uYW1lfV1dPjwvYXJ0aXN0PlxuICAgIDxsYWJlbD48IVtDREFUQVske3RyYWNrLmxhYmVsX25hbWUgfHwgJ05vdGFmZXlhIFJlY29yZHMnfV1dPjwvbGFiZWw+XG4gICAgPHJlbGVhc2VfZGF0ZT4ke3JlbGVhc2VEYXRlLnNwbGl0KCdUJylbMF19PC9yZWxlYXNlX2RhdGU+XG4gICAgPGdlbnJlPiR7Z2VucmVOYW1lfTwvZ2VucmU+XG4gICAgPGdlbnJlX3J1PiR7Z2VucmVOYW1lUnV9PC9nZW5yZV9ydT5cbiAgICA8ZHVyYXRpb25fc2Vjb25kcz4ke01hdGgucm91bmQodHJhY2suZHVyYXRpb24gfHwgMCl9PC9kdXJhdGlvbl9zZWNvbmRzPlxuICA8L3JlbGVhc2VfaW5mbz5cbiAgXG4gIDxjcmVkaXRzPlxuICAgIDxtdXNpY19hdXRob3I+PCFbQ0RBVEFbJHt0cmFjay5tdXNpY19hdXRob3IgfHwgdHJhY2sucGVyZm9ybWVyX25hbWV9XV0+PC9tdXNpY19hdXRob3I+XG4gICAgPGx5cmljc19hdXRob3I+PCFbQ0RBVEFbJHt0cmFjay5seXJpY3NfYXV0aG9yIHx8ICdJbnN0cnVtZW50YWwnfV1dPjwvbHlyaWNzX2F1dGhvcj5cbiAgICA8cGVyZm9ybWVyPjwhW0NEQVRBWyR7dHJhY2sucGVyZm9ybWVyX25hbWV9XV0+PC9wZXJmb3JtZXI+XG4gICAgPHByb2R1Y2VyPjwhW0NEQVRBWyR7dHJhY2sucGVyZm9ybWVyX25hbWV9XV0+PC9wcm9kdWNlcj5cbiAgICA8dXBsb2FkZXI+PCFbQ0RBVEFbJHt1cGxvYWRlck5hbWV9XV0+PC91cGxvYWRlcj5cbiAgPC9jcmVkaXRzPlxuICBcbiAgPHRlY2huaWNhbD5cbiAgICA8YXVkaW9fZm9ybWF0PldBVjwvYXVkaW9fZm9ybWF0PlxuICAgIDxiaXRfZGVwdGg+MjQ8L2JpdF9kZXB0aD5cbiAgICA8c2FtcGxlX3JhdGU+NDQxMDA8L3NhbXBsZV9yYXRlPlxuICAgIDxsb3VkbmVzc19zdGFuZGFyZD4tMTQgTFVGUzwvbG91ZG5lc3Nfc3RhbmRhcmQ+XG4gICAgPG1hc3RlcmVkPnRydWU8L21hc3RlcmVkPlxuICAgIDxtZXRhZGF0YV9jbGVhbmVkPnRydWU8L21ldGFkYXRhX2NsZWFuZWQ+XG4gIDwvdGVjaG5pY2FsPlxuICBcbiAgPGJsb2NrY2hhaW4+XG4gICAgPGhhc2g+JHt0cmFjay5ibG9ja2NoYWluX2hhc2ggfHwgJ04vQSd9PC9oYXNoPlxuICAgIDx0aW1lc3RhbXA+JHtyZWxlYXNlRGF0ZX08L3RpbWVzdGFtcD5cbiAgICA8bmV0d29yaz5PcGVuVGltZXN0YW1wczwvbmV0d29yaz5cbiAgICA8dmVyaWZpZWQ+dHJ1ZTwvdmVyaWZpZWQ+XG4gIDwvYmxvY2tjaGFpbj5cbiAgXG4gIDxhc3NldHM+XG4gICAgPG1hc3Rlcl9hdWRpbz4ke3RyYWNrLm1hc3Rlcl9hdWRpb191cmwgPyAnaW5jbHVkZWQnIDogJ3BlbmRpbmcnfTwvbWFzdGVyX2F1ZGlvPlxuICAgIDxjb3Zlcl9hcnQgcmVzb2x1dGlvbj1cIjMwMDB4MzAwMFwiPiR7dHJhY2suY292ZXJfdXJsID8gJ2luY2x1ZGVkJyA6ICdwZW5kaW5nJ308L2NvdmVyX2FydD5cbiAgICA8cHJvbW9fdmlkZW8+bm90X2F2YWlsYWJsZTwvcHJvbW9fdmlkZW8+XG4gICAgPGNlcnRpZmljYXRlPiR7dHJhY2suY2VydGlmaWNhdGVfdXJsID8gJ2luY2x1ZGVkJyA6ICdwZW5kaW5nJ308L2NlcnRpZmljYXRlPlxuICA8L2Fzc2V0cz5cbiAgXG4gIDxkaXN0cmlidXRpb24+XG4gICAgPHBsYXRmb3Jtcz5cbiAgICAgIDxwbGF0Zm9ybSBuYW1lPVwiU3BvdGlmeVwiIHN0YXR1cz1cInJlYWR5XCIvPlxuICAgICAgPHBsYXRmb3JtIG5hbWU9XCJBcHBsZSBNdXNpY1wiIHN0YXR1cz1cInJlYWR5XCIvPlxuICAgICAgPHBsYXRmb3JtIG5hbWU9XCJZYW5kZXggTXVzaWNcIiBzdGF0dXM9XCJyZWFkeVwiLz5cbiAgICAgIDxwbGF0Zm9ybSBuYW1lPVwiVksgTXVzaWNcIiBzdGF0dXM9XCJyZWFkeVwiLz5cbiAgICAgIDxwbGF0Zm9ybSBuYW1lPVwiRGVlemVyXCIgc3RhdHVzPVwicmVhZHlcIi8+XG4gICAgICA8cGxhdGZvcm0gbmFtZT1cIlNvdW5kQ2xvdWRcIiBzdGF0dXM9XCJyZWFkeVwiLz5cbiAgICA8L3BsYXRmb3Jtcz5cbiAgICA8dGVycml0b3J5Pldvcmxkd2lkZTwvdGVycml0b3J5PlxuICAgIDxleGNsdXNpdmU+ZmFsc2U8L2V4Y2x1c2l2ZT5cbiAgPC9kaXN0cmlidXRpb24+XG4gIFxuICA8bGVnYWw+XG4gICAgPGNvcHlyaWdodD7CqSAke25ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKX0gJHt0cmFjay5sYWJlbF9uYW1lIHx8ICdOb3RhZmV5YSBSZWNvcmRzJ30uIEFsbCByaWdodHMgcmVzZXJ2ZWQuPC9jb3B5cmlnaHQ+XG4gICAgPGxpY2Vuc2U+U3RhbmRhcmQgRGlzdHJpYnV0aW9uIExpY2Vuc2U8L2xpY2Vuc2U+XG4gICAgPGNvbnRlbnRfcmF0aW5nPlVucmF0ZWQ8L2NvbnRlbnRfcmF0aW5nPlxuICA8L2xlZ2FsPlxuPC9yZWxlYXNlPmA7XG59XG5cbi8vIEdlbmVyYXRlIFBERiBjZXJ0aWZpY2F0ZSBIVE1MICh3b3VsZCBiZSBjb252ZXJ0ZWQgdG8gUERGIGluIHByb2R1Y3Rpb24pXG5mdW5jdGlvbiBnZW5lcmF0ZUNlcnRpZmljYXRlSHRtbCh0cmFjazogVHJhY2tNZXRhZGF0YSk6IHN0cmluZyB7XG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XG4gIGNvbnN0IGZvcm1hdHRlZERhdGUgPSBub3cudG9Mb2NhbGVEYXRlU3RyaW5nKCdydS1SVScsIHtcbiAgICB5ZWFyOiAnbnVtZXJpYycsXG4gICAgbW9udGg6ICdsb25nJyxcbiAgICBkYXk6ICdudW1lcmljJ1xuICB9KTtcbiAgXG4gIHJldHVybiBgPCFET0NUWVBFIGh0bWw+XG48aHRtbCBsYW5nPVwicnVcIj5cbjxoZWFkPlxuICA8bWV0YSBjaGFyc2V0PVwiVVRGLThcIj5cbiAgPHRpdGxlPtCh0LXRgNGC0LjRhNC40LrQsNGCINCw0LLRgtC+0YDRgdGC0LLQsCAtICR7dHJhY2sudGl0bGV9PC90aXRsZT5cbiAgPHN0eWxlPlxuICAgIEBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PUNvcm1vcmFudCtHYXJhbW9uZDp3Z2h0QDQwMDs2MDA7NzAwJmZhbWlseT1Nb250c2VycmF0OndnaHRAMzAwOzQwMDs2MDAmZGlzcGxheT1zd2FwJyk7XG4gICAgXG4gICAgKiB7IG1hcmdpbjogMDsgcGFkZGluZzogMDsgYm94LXNpemluZzogYm9yZGVyLWJveDsgfVxuICAgIFxuICAgIGJvZHkge1xuICAgICAgZm9udC1mYW1pbHk6ICdNb250c2VycmF0Jywgc2Fucy1zZXJpZjtcbiAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICMwZjBmMjMgMCUsICMxYTFhM2UgNTAlLCAjMGYwZjIzIDEwMCUpO1xuICAgICAgbWluLWhlaWdodDogMTAwdmg7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgcGFkZGluZzogNDBweDtcbiAgICB9XG4gICAgXG4gICAgLmNlcnRpZmljYXRlIHtcbiAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxODBkZWcsICNmZWZlZmUgMCUsICNmOGY2ZjAgMTAwJSk7XG4gICAgICBib3JkZXI6IDNweCBzb2xpZCAjYzlhOTYyO1xuICAgICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgICAgcGFkZGluZzogNjBweCA4MHB4O1xuICAgICAgbWF4LXdpZHRoOiA4MDBweDtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgYm94LXNoYWRvdzogMCAyMHB4IDYwcHggcmdiYSgwLDAsMCwwLjUpO1xuICAgIH1cbiAgICBcbiAgICAuY2VydGlmaWNhdGU6OmJlZm9yZSB7XG4gICAgICBjb250ZW50OiAnJztcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIHRvcDogMTVweDtcbiAgICAgIGxlZnQ6IDE1cHg7XG4gICAgICByaWdodDogMTVweDtcbiAgICAgIGJvdHRvbTogMTVweDtcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNjOWE5NjI7XG4gICAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICB9XG4gICAgXG4gICAgLmhlYWRlciB7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICBtYXJnaW4tYm90dG9tOiA0MHB4O1xuICAgIH1cbiAgICBcbiAgICAubG9nbyB7XG4gICAgICBmb250LWZhbWlseTogJ0Nvcm1vcmFudCBHYXJhbW9uZCcsIHNlcmlmO1xuICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgY29sb3I6ICM2NjY7XG4gICAgICBsZXR0ZXItc3BhY2luZzogNHB4O1xuICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gICAgfVxuICAgIFxuICAgIC50aXRsZSB7XG4gICAgICBmb250LWZhbWlseTogJ0Nvcm1vcmFudCBHYXJhbW9uZCcsIHNlcmlmO1xuICAgICAgZm9udC1zaXplOiA0MnB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICAgIGNvbG9yOiAjMWExYTJlO1xuICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICB9XG4gICAgXG4gICAgLnN1YnRpdGxlIHtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGNvbG9yOiAjNjY2O1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDJweDtcbiAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgfVxuICAgIFxuICAgIC5kaXZpZGVyIHtcbiAgICAgIGhlaWdodDogMnB4O1xuICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCB0cmFuc3BhcmVudCwgI2M5YTk2MiwgdHJhbnNwYXJlbnQpO1xuICAgICAgbWFyZ2luOiAzMHB4IDA7XG4gICAgfVxuICAgIFxuICAgIC5jb250ZW50IHtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICB9XG4gICAgXG4gICAgLnRyYWNrLXRpdGxlIHtcbiAgICAgIGZvbnQtZmFtaWx5OiAnQ29ybW9yYW50IEdhcmFtb25kJywgc2VyaWY7XG4gICAgICBmb250LXNpemU6IDI4cHg7XG4gICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgY29sb3I6ICMxYTFhMmU7XG4gICAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICAgIH1cbiAgICBcbiAgICAudHJhY2stYXJ0aXN0IHtcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgIGNvbG9yOiAjNDQ0O1xuICAgICAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgICB9XG4gICAgXG4gICAgLmluZm8tZ3JpZCB7XG4gICAgICBkaXNwbGF5OiBncmlkO1xuICAgICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgMWZyO1xuICAgICAgZ2FwOiAyMHB4O1xuICAgICAgbWFyZ2luOiAzMHB4IDA7XG4gICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIH1cbiAgICBcbiAgICAuaW5mby1pdGVtIHtcbiAgICAgIHBhZGRpbmc6IDE1cHg7XG4gICAgICBiYWNrZ3JvdW5kOiByZ2JhKDIwMSwgMTY5LCA5OCwgMC4xKTtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgICB9XG4gICAgXG4gICAgLmluZm8tbGFiZWwge1xuICAgICAgZm9udC1zaXplOiAxMXB4O1xuICAgICAgY29sb3I6ICM4ODg7XG4gICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcbiAgICB9XG4gICAgXG4gICAgLmluZm8tdmFsdWUge1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgY29sb3I6ICMxYTFhMmU7XG4gICAgICBmb250LXdlaWdodDogNTAwO1xuICAgIH1cbiAgICBcbiAgICAuYmxvY2tjaGFpbi1zZWN0aW9uIHtcbiAgICAgIG1hcmdpbjogNDBweCAwO1xuICAgICAgcGFkZGluZzogMjVweDtcbiAgICAgIGJhY2tncm91bmQ6ICMxYTFhMmU7XG4gICAgICBib3JkZXItcmFkaXVzOiA2cHg7XG4gICAgICBjb2xvcjogd2hpdGU7XG4gICAgfVxuICAgIFxuICAgIC5ibG9ja2NoYWluLXRpdGxlIHtcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgIGNvbG9yOiAjYzlhOTYyO1xuICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAycHg7XG4gICAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICAgIH1cbiAgICBcbiAgICAuYmxvY2tjaGFpbi1oYXNoIHtcbiAgICAgIGZvbnQtZmFtaWx5OiAnQ291cmllciBOZXcnLCBtb25vc3BhY2U7XG4gICAgICBmb250LXNpemU6IDExcHg7XG4gICAgICB3b3JkLWJyZWFrOiBicmVhay1hbGw7XG4gICAgICBjb2xvcjogIzhiZTlmZDtcbiAgICAgIGJhY2tncm91bmQ6IHJnYmEoMCwwLDAsMC4zKTtcbiAgICAgIHBhZGRpbmc6IDE1cHg7XG4gICAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgfVxuICAgIFxuICAgIC5mb290ZXIge1xuICAgICAgbWFyZ2luLXRvcDogNDBweDtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICB9XG4gICAgXG4gICAgLnNlYWwge1xuICAgICAgd2lkdGg6IDEwMHB4O1xuICAgICAgaGVpZ2h0OiAxMDBweDtcbiAgICAgIG1hcmdpbjogMCBhdXRvIDIwcHg7XG4gICAgICBib3JkZXI6IDNweCBzb2xpZCAjYzlhOTYyO1xuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgIGZvbnQtZmFtaWx5OiAnQ29ybW9yYW50IEdhcmFtb25kJywgc2VyaWY7XG4gICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICBjb2xvcjogI2M5YTk2MjtcbiAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICAgIH1cbiAgICBcbiAgICAuZGF0ZSB7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBjb2xvcjogIzY2NjtcbiAgICB9XG4gICAgXG4gICAgLmNlcnRpZmljYXRlLWlkIHtcbiAgICAgIG1hcmdpbi10b3A6IDE1cHg7XG4gICAgICBmb250LXNpemU6IDExcHg7XG4gICAgICBjb2xvcjogIzk5OTtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gICAgfVxuICA8L3N0eWxlPlxuPC9oZWFkPlxuPGJvZHk+XG4gIDxkaXYgY2xhc3M9XCJjZXJ0aWZpY2F0ZVwiPlxuICAgIDxkaXYgY2xhc3M9XCJoZWFkZXJcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJsb2dvXCI+4pmqIE5vdGFmZXlhIFJlY29yZHMg4pmqPC9kaXY+XG4gICAgICA8aDEgY2xhc3M9XCJ0aXRsZVwiPtCh0LXRgNGC0LjRhNC40LrQsNGCINCQ0LLRgtC+0YDRgdGC0LLQsDwvaDE+XG4gICAgICA8cCBjbGFzcz1cInN1YnRpdGxlXCI+Q2VydGlmaWNhdGUgb2YgQXV0aG9yc2hpcDwvcD5cbiAgICA8L2Rpdj5cbiAgICBcbiAgICA8ZGl2IGNsYXNzPVwiZGl2aWRlclwiPjwvZGl2PlxuICAgIFxuICAgIDxkaXYgY2xhc3M9XCJjb250ZW50XCI+XG4gICAgICA8aDIgY2xhc3M9XCJ0cmFjay10aXRsZVwiPlwiJHt0cmFjay50aXRsZX1cIjwvaDI+XG4gICAgICA8cCBjbGFzcz1cInRyYWNrLWFydGlzdFwiPtCY0YHQv9C+0LvQvdC40YLQtdC70Yw6ICR7dHJhY2sucGVyZm9ybWVyX25hbWV9PC9wPlxuICAgICAgXG4gICAgICA8ZGl2IGNsYXNzPVwiaW5mby1ncmlkXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLWl0ZW1cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1sYWJlbFwiPtCQ0LLRgtC+0YAg0LzRg9C30YvQutC4PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tdmFsdWVcIj4ke3RyYWNrLm11c2ljX2F1dGhvciB8fCB0cmFjay5wZXJmb3JtZXJfbmFtZX08L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLWl0ZW1cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1sYWJlbFwiPtCQ0LLRgtC+0YAg0YLQtdC60YHRgtCwPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tdmFsdWVcIj4ke3RyYWNrLmx5cmljc19hdXRob3IgfHwgJ9CY0L3RgdGC0YDRg9C80LXQvdGC0LDQuyd9PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1pdGVtXCI+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tbGFiZWxcIj5JU1JDINC60L7QtDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLXZhbHVlXCI+JHt0cmFjay5pc3JjX2NvZGUgfHwgJ9CSINC+0LHRgNCw0LHQvtGC0LrQtSd9PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1pdGVtXCI+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tbGFiZWxcIj7Qm9C10LnQsdC7PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tdmFsdWVcIj4ke3RyYWNrLmxhYmVsX25hbWUgfHwgJ05vdGFmZXlhIFJlY29yZHMnfTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgXG4gICAgICA8ZGl2IGNsYXNzPVwiYmxvY2tjaGFpbi1zZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJibG9ja2NoYWluLXRpdGxlXCI+4puTIEJsb2NrY2hhaW4gVmVyaWZpY2F0aW9uPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJibG9ja2NoYWluLWhhc2hcIj4ke3RyYWNrLmJsb2NrY2hhaW5faGFzaCB8fCAnSGFzaCBwZW5kaW5nLi4uJ308L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIFxuICAgIDxkaXYgY2xhc3M9XCJmb290ZXJcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzZWFsXCI+VmVyaWZpZWQ8YnIvPuKckzwvZGl2PlxuICAgICAgPHAgY2xhc3M9XCJkYXRlXCI+JHtmb3JtYXR0ZWREYXRlfTwvcD5cbiAgICAgIDxwIGNsYXNzPVwiY2VydGlmaWNhdGUtaWRcIj5JRDogJHt0cmFjay5pZC5zdWJzdHJpbmcoMCwgOCkudG9VcHBlckNhc2UoKX08L3A+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuPC9ib2R5PlxuPC9odG1sPmA7XG59XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09ICdPUFRJT05TJykge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoJ29rJywgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoJ1NVUEFCQVNFX1VSTCcpID8/ICcnLFxuICAgICAgRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZJykgPz8gJydcbiAgICApO1xuXG4gICAgY29uc3QgeyB0cmFja0lkIH06IEdvbGRQYWNrUmVxdWVzdCA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coYFtnZW5lcmF0ZS1nb2xkLXBhY2tdIFN0YXJ0aW5nIGZvciB0cmFjazogJHt0cmFja0lkfWApO1xuXG4gICAgaWYgKCF0cmFja0lkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RyYWNrSWQgaXMgcmVxdWlyZWQnKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgdHJhY2sgd2l0aCBhbGwgbWV0YWRhdGFcbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrLCBlcnJvcjogdHJhY2tFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKCd0cmFja3MnKVxuICAgICAgLnNlbGVjdChgXG4gICAgICAgIGlkLCB0aXRsZSwgcGVyZm9ybWVyX25hbWUsIG11c2ljX2F1dGhvciwgbHlyaWNzX2F1dGhvciwgbGFiZWxfbmFtZSxcbiAgICAgICAgaXNyY19jb2RlLCBkdXJhdGlvbiwgYmxvY2tjaGFpbl9oYXNoLCBjb3Zlcl91cmwsIG1hc3Rlcl9hdWRpb191cmwsXG4gICAgICAgIGNlcnRpZmljYXRlX3VybCwgY3JlYXRlZF9hdCwgcHJvY2Vzc2luZ19jb21wbGV0ZWRfYXQsXG4gICAgICAgIHByb2ZpbGVzOnVzZXJfaWQodXNlcm5hbWUpLFxuICAgICAgICBnZW5yZTpnZW5yZXMobmFtZV9ydSwgbmFtZSlcbiAgICAgIGApXG4gICAgICAuZXEoJ2lkJywgdHJhY2tJZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICh0cmFja0Vycm9yIHx8ICF0cmFjaykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdUcmFjayBub3QgZm91bmQnKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgW2dlbmVyYXRlLWdvbGQtcGFja10gR2VuZXJhdGluZyBhc3NldHMgZm9yOiAke3RyYWNrLnRpdGxlfWApO1xuXG4gICAgLy8gR2VuZXJhdGUgU0lMSyBYTUwgbWV0YWRhdGFcbiAgICBjb25zdCB4bWxDb250ZW50ID0gZ2VuZXJhdGVTaWxrWG1sKHRyYWNrIGFzIFRyYWNrTWV0YWRhdGEpO1xuICAgIGNvbnN0IHhtbEZpbGVOYW1lID0gYGdvbGQtcGFja3MvJHt0cmFja0lkfS9tZXRhZGF0YV9zaWxrLnhtbGA7XG4gICAgXG4gICAgY29uc3QgeyBlcnJvcjogeG1sVXBsb2FkRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLnN0b3JhZ2VcbiAgICAgIC5mcm9tKCd0cmFja3MnKVxuICAgICAgLnVwbG9hZCh4bWxGaWxlTmFtZSwgbmV3IEJsb2IoW3htbENvbnRlbnRdLCB7IHR5cGU6ICdhcHBsaWNhdGlvbi94bWwnIH0pLCB7XG4gICAgICAgIHVwc2VydDogdHJ1ZSxcbiAgICAgICAgY29udGVudFR5cGU6ICdhcHBsaWNhdGlvbi94bWwnXG4gICAgICB9KTtcblxuICAgIGlmICh4bWxVcGxvYWRFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignW2dlbmVyYXRlLWdvbGQtcGFja10gWE1MIHVwbG9hZCBlcnJvcjonLCB4bWxVcGxvYWRFcnJvcik7XG4gICAgfVxuXG4gICAgLy8gR2VuZXJhdGUgY2VydGlmaWNhdGUgSFRNTCAoaW4gcHJvZHVjdGlvbiB3b3VsZCBjb252ZXJ0IHRvIFBERilcbiAgICBjb25zdCBjZXJ0aWZpY2F0ZUh0bWwgPSBnZW5lcmF0ZUNlcnRpZmljYXRlSHRtbCh0cmFjayBhcyBUcmFja01ldGFkYXRhKTtcbiAgICBjb25zdCBjZXJ0aWZpY2F0ZUZpbGVOYW1lID0gYGdvbGQtcGFja3MvJHt0cmFja0lkfS9jZXJ0aWZpY2F0ZS5odG1sYDtcbiAgICBcbiAgICBjb25zdCB7IGVycm9yOiBjZXJ0VXBsb2FkRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLnN0b3JhZ2VcbiAgICAgIC5mcm9tKCd0cmFja3MnKVxuICAgICAgLnVwbG9hZChjZXJ0aWZpY2F0ZUZpbGVOYW1lLCBuZXcgQmxvYihbY2VydGlmaWNhdGVIdG1sXSwgeyB0eXBlOiAndGV4dC9odG1sJyB9KSwge1xuICAgICAgICB1cHNlcnQ6IHRydWUsXG4gICAgICAgIGNvbnRlbnRUeXBlOiAndGV4dC9odG1sJ1xuICAgICAgfSk7XG5cbiAgICBpZiAoY2VydFVwbG9hZEVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdbZ2VuZXJhdGUtZ29sZC1wYWNrXSBDZXJ0aWZpY2F0ZSB1cGxvYWQgZXJyb3I6JywgY2VydFVwbG9hZEVycm9yKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgcHVibGljIFVSTHNcbiAgICBjb25zdCB7IGRhdGE6IHhtbFVybCB9ID0gc3VwYWJhc2Uuc3RvcmFnZS5mcm9tKCd0cmFja3MnKS5nZXRQdWJsaWNVcmwoeG1sRmlsZU5hbWUpO1xuICAgIGNvbnN0IHsgZGF0YTogY2VydFVybCB9ID0gc3VwYWJhc2Uuc3RvcmFnZS5mcm9tKCd0cmFja3MnKS5nZXRQdWJsaWNVcmwoY2VydGlmaWNhdGVGaWxlTmFtZSk7XG5cbiAgICAvLyBHZW5lcmF0ZSBwYWNrIG1hbmlmZXN0XG4gICAgY29uc3QgbWFuaWZlc3QgPSB7XG4gICAgICB2ZXJzaW9uOiAnMS4wJyxcbiAgICAgIGdlbmVyYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgdHJhY2tfaWQ6IHRyYWNrLmlkLFxuICAgICAgdHJhY2tfdGl0bGU6IHRyYWNrLnRpdGxlLFxuICAgICAgYXJ0aXN0OiB0cmFjay5wZXJmb3JtZXJfbmFtZSxcbiAgICAgIGlzcmM6IHRyYWNrLmlzcmNfY29kZSxcbiAgICAgIGJsb2NrY2hhaW5faGFzaDogdHJhY2suYmxvY2tjaGFpbl9oYXNoLFxuICAgICAgY29udGVudHM6IHtcbiAgICAgICAgbWFzdGVyX2F1ZGlvOiB7XG4gICAgICAgICAgZm9ybWF0OiAnV0FWIDI0LWJpdC80NC4xa0h6JyxcbiAgICAgICAgICB1cmw6IHRyYWNrLm1hc3Rlcl9hdWRpb191cmwsXG4gICAgICAgICAgc3RhdHVzOiB0cmFjay5tYXN0ZXJfYXVkaW9fdXJsID8gJ2luY2x1ZGVkJyA6ICdwZW5kaW5nJ1xuICAgICAgICB9LFxuICAgICAgICBjb3Zlcl9hcnQ6IHtcbiAgICAgICAgICBmb3JtYXQ6ICdKUEVHIDMwMDB4MzAwMCcsXG4gICAgICAgICAgdXJsOiB0cmFjay5jb3Zlcl91cmwsXG4gICAgICAgICAgc3RhdHVzOiB0cmFjay5jb3Zlcl91cmwgPyAnaW5jbHVkZWQnIDogJ3BlbmRpbmcnXG4gICAgICAgIH0sXG4gICAgICAgIG1ldGFkYXRhOiB7XG4gICAgICAgICAgZm9ybWF0OiAnU0lMSyBYTUwgdjEuMCcsXG4gICAgICAgICAgdXJsOiB4bWxVcmwucHVibGljVXJsLFxuICAgICAgICAgIHN0YXR1czogJ2luY2x1ZGVkJ1xuICAgICAgICB9LFxuICAgICAgICBjZXJ0aWZpY2F0ZToge1xuICAgICAgICAgIGZvcm1hdDogJ0hUTUwvUERGJyxcbiAgICAgICAgICB1cmw6IGNlcnRVcmwucHVibGljVXJsLFxuICAgICAgICAgIHN0YXR1czogJ2luY2x1ZGVkJ1xuICAgICAgICB9LFxuICAgICAgICBwcm9tb192aWRlbzoge1xuICAgICAgICAgIGZvcm1hdDogJ01QNCAxMDgwcCcsXG4gICAgICAgICAgdXJsOiBudWxsLFxuICAgICAgICAgIHN0YXR1czogJ25vdF9hdmFpbGFibGUnXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBkaXN0cmlidXRpb246IHtcbiAgICAgICAgcGxhdGZvcm1zOiBbJ1Nwb3RpZnknLCAnQXBwbGUgTXVzaWMnLCAnWWFuZGV4IE11c2ljJywgJ1ZLIE11c2ljJywgJ0RlZXplcicsICdTb3VuZENsb3VkJ10sXG4gICAgICAgIHRlcnJpdG9yeTogJ1dvcmxkd2lkZScsXG4gICAgICAgIHJlbGVhc2VfcmVhZHk6IHRydWVcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgbWFuaWZlc3RGaWxlTmFtZSA9IGBnb2xkLXBhY2tzLyR7dHJhY2tJZH0vbWFuaWZlc3QuanNvbmA7XG4gICAgYXdhaXQgc3VwYWJhc2Uuc3RvcmFnZVxuICAgICAgLmZyb20oJ3RyYWNrcycpXG4gICAgICAudXBsb2FkKG1hbmlmZXN0RmlsZU5hbWUsIG5ldyBCbG9iKFtKU09OLnN0cmluZ2lmeShtYW5pZmVzdCwgbnVsbCwgMildLCB7IHR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyB9KSwge1xuICAgICAgICB1cHNlcnQ6IHRydWUsXG4gICAgICAgIGNvbnRlbnRUeXBlOiAnYXBwbGljYXRpb24vanNvbidcbiAgICAgIH0pO1xuXG4gICAgY29uc3QgeyBkYXRhOiBtYW5pZmVzdFVybCB9ID0gc3VwYWJhc2Uuc3RvcmFnZS5mcm9tKCd0cmFja3MnKS5nZXRQdWJsaWNVcmwobWFuaWZlc3RGaWxlTmFtZSk7XG5cbiAgICAvLyBVcGRhdGUgdHJhY2sgd2l0aCBnb2xkIHBhY2sgVVJMIChtYW5pZmVzdCBhcyBlbnRyeSBwb2ludClcbiAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oJ3RyYWNrcycpXG4gICAgICAudXBkYXRlKHtcbiAgICAgICAgZ29sZF9wYWNrX3VybDogbWFuaWZlc3RVcmwucHVibGljVXJsLFxuICAgICAgICBjZXJ0aWZpY2F0ZV91cmw6IGNlcnRVcmwucHVibGljVXJsXG4gICAgICB9KVxuICAgICAgLmVxKCdpZCcsIHRyYWNrSWQpO1xuXG4gICAgLy8gTG9nIHRoZSBnb2xkIHBhY2sgZ2VuZXJhdGlvblxuICAgIGNvbnN0IHsgZGF0YTogdXNlckRhdGEgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgndHJhY2tzJylcbiAgICAgIC5zZWxlY3QoJ3VzZXJfaWQnKVxuICAgICAgLmVxKCdpZCcsIHRyYWNrSWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAodXNlckRhdGEpIHtcbiAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ2Rpc3RyaWJ1dGlvbl9sb2dzJykuaW5zZXJ0KHtcbiAgICAgICAgdHJhY2tfaWQ6IHRyYWNrSWQsXG4gICAgICAgIHVzZXJfaWQ6IHVzZXJEYXRhLnVzZXJfaWQsXG4gICAgICAgIGFjdGlvbjogJ2dvbGRfcGFja19nZW5lcmF0ZWQnLFxuICAgICAgICBzdGFnZTogJ2xldmVsX3BybycsXG4gICAgICAgIGRldGFpbHM6IHtcbiAgICAgICAgICBtYW5pZmVzdF91cmw6IG1hbmlmZXN0VXJsLnB1YmxpY1VybCxcbiAgICAgICAgICB4bWxfdXJsOiB4bWxVcmwucHVibGljVXJsLFxuICAgICAgICAgIGNlcnRpZmljYXRlX3VybDogY2VydFVybC5wdWJsaWNVcmwsXG4gICAgICAgICAgaGFzX21hc3RlcjogISF0cmFjay5tYXN0ZXJfYXVkaW9fdXJsLFxuICAgICAgICAgIGhhc19jb3ZlcjogISF0cmFjay5jb3Zlcl91cmwsXG4gICAgICAgICAgaGFzX3ZpZGVvOiBmYWxzZVxuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgLy8gTm90aWZ5IHVzZXJcbiAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ25vdGlmaWNhdGlvbnMnKS5pbnNlcnQoe1xuICAgICAgICB1c2VyX2lkOiB1c2VyRGF0YS51c2VyX2lkLFxuICAgICAgICB0eXBlOiAnc3lzdGVtJyxcbiAgICAgICAgdGl0bGU6ICfwn5OmINCX0L7Qu9C+0YLQvtC5INC/0LDQutC10YIgU0lMSyDQs9C+0YLQvtCyIScsXG4gICAgICAgIG1lc3NhZ2U6IGDQktCw0Ygg0YLRgNC10LogXCIke3RyYWNrLnRpdGxlfVwiINCz0L7RgtC+0LIg0Log0LTQuNGB0YLRgNC40LHRg9GG0LjQuC4gV0FWLCBYTUwt0LzQtdGC0LDQtNCw0L3QvdGL0LUg0Lgg0YHQtdGA0YLQuNGE0LjQutCw0YIg0LTQvtGB0YLRg9C/0L3RiyDQtNC70Y8g0YHQutCw0YfQuNCy0LDQvdC40Y8uYCxcbiAgICAgICAgdGFyZ2V0X3R5cGU6ICd0cmFjaycsXG4gICAgICAgIHRhcmdldF9pZDogdHJhY2tJZFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgZ29sZFBhY2s6IHtcbiAgICAgICAgICBtYW5pZmVzdFVybDogbWFuaWZlc3RVcmwucHVibGljVXJsLFxuICAgICAgICAgIHhtbFVybDogeG1sVXJsLnB1YmxpY1VybCxcbiAgICAgICAgICBjZXJ0aWZpY2F0ZVVybDogY2VydFVybC5wdWJsaWNVcmwsXG4gICAgICAgICAgbWFzdGVyQXVkaW9Vcmw6IHRyYWNrLm1hc3Rlcl9hdWRpb191cmwsXG4gICAgICAgICAgY292ZXJVcmw6IHRyYWNrLmNvdmVyX3VybCxcbiAgICAgICAgICBwcm9tb1ZpZGVvVXJsOiBudWxsXG4gICAgICAgIH1cbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbZ2VuZXJhdGUtZ29sZC1wYWNrXSBFcnJvcjonLCBlcnJvcik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUF5QkEsd0NBQXdDO0FBQ3hDLFNBQVMsZ0JBQWdCLEtBQW9CO0VBQzNDLE1BQU0sTUFBTSxJQUFJLE9BQU8sV0FBVztFQUNsQyxNQUFNLGNBQWMsTUFBTSx1QkFBdUIsSUFBSTtFQUNyRCxNQUFNLFlBQVksTUFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUUsUUFBUTtFQUM1QyxNQUFNLGNBQWMsTUFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUUsV0FBVztFQUNqRCxNQUFNLGVBQWUsTUFBTSxRQUFRLEVBQUUsQ0FBQyxFQUFFLEVBQUUsWUFBWTtFQUV0RCxPQUFPLENBQUM7Ozs7a0JBSVEsRUFBRSxJQUFJOzs7OztpQkFLUCxFQUFFLE1BQU0sRUFBRSxDQUFDO1VBQ2xCLEVBQUUsTUFBTSxTQUFTLElBQUksVUFBVTtvQkFDckIsRUFBRSxNQUFNLEtBQUssQ0FBQztxQkFDYixFQUFFLE1BQU0sY0FBYyxDQUFDO29CQUN4QixFQUFFLE1BQU0sVUFBVSxJQUFJLG1CQUFtQjtrQkFDM0MsRUFBRSxZQUFZLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO1dBQ25DLEVBQUUsVUFBVTtjQUNULEVBQUUsWUFBWTtzQkFDTixFQUFFLEtBQUssS0FBSyxDQUFDLE1BQU0sUUFBUSxJQUFJLEdBQUc7Ozs7MkJBSTdCLEVBQUUsTUFBTSxZQUFZLElBQUksTUFBTSxjQUFjLENBQUM7NEJBQzVDLEVBQUUsTUFBTSxhQUFhLElBQUksZUFBZTt3QkFDNUMsRUFBRSxNQUFNLGNBQWMsQ0FBQzt1QkFDeEIsRUFBRSxNQUFNLGNBQWMsQ0FBQzt1QkFDdkIsRUFBRSxhQUFhOzs7Ozs7Ozs7Ozs7O1VBYTVCLEVBQUUsTUFBTSxlQUFlLElBQUksTUFBTTtlQUM1QixFQUFFLFlBQVk7Ozs7OztrQkFNWCxFQUFFLE1BQU0sZ0JBQWdCLEdBQUcsYUFBYSxVQUFVO3NDQUM5QixFQUFFLE1BQU0sU0FBUyxHQUFHLGFBQWEsVUFBVTs7aUJBRWhFLEVBQUUsTUFBTSxlQUFlLEdBQUcsYUFBYSxVQUFVOzs7Ozs7Ozs7Ozs7Ozs7OztpQkFpQmpELEVBQUUsSUFBSSxPQUFPLFdBQVcsR0FBRyxDQUFDLEVBQUUsTUFBTSxVQUFVLElBQUksbUJBQW1COzs7O1VBSTVFLENBQUM7QUFDWDtBQUVBLDBFQUEwRTtBQUMxRSxTQUFTLHdCQUF3QixLQUFvQjtFQUNuRCxNQUFNLE1BQU0sSUFBSTtFQUNoQixNQUFNLGdCQUFnQixJQUFJLGtCQUFrQixDQUFDLFNBQVM7SUFDcEQsTUFBTTtJQUNOLE9BQU87SUFDUCxLQUFLO0VBQ1A7RUFFQSxPQUFPLENBQUM7Ozs7Z0NBSXNCLEVBQUUsTUFBTSxLQUFLLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OytCQStMZixFQUFFLE1BQU0sS0FBSyxDQUFDOzJDQUNGLEVBQUUsTUFBTSxjQUFjLENBQUM7Ozs7O2tDQUtoQyxFQUFFLE1BQU0sWUFBWSxJQUFJLE1BQU0sY0FBYyxDQUFDOzs7O2tDQUk3QyxFQUFFLE1BQU0sYUFBYSxJQUFJLGVBQWU7Ozs7a0NBSXhDLEVBQUUsTUFBTSxTQUFTLElBQUksY0FBYzs7OztrQ0FJbkMsRUFBRSxNQUFNLFVBQVUsSUFBSSxtQkFBbUI7Ozs7OztxQ0FNdEMsRUFBRSxNQUFNLGVBQWUsSUFBSSxrQkFBa0I7Ozs7OztzQkFNNUQsRUFBRSxjQUFjO29DQUNGLEVBQUUsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxXQUFXLEdBQUc7Ozs7T0FJdEUsQ0FBQztBQUNSO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxXQUFXLGFBQ2YsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0lBRy9DLE1BQU0sRUFBRSxPQUFPLEVBQUUsR0FBb0IsTUFBTSxJQUFJLElBQUk7SUFDbkQsUUFBUSxHQUFHLENBQUMsQ0FBQyx5Q0FBeUMsRUFBRSxRQUFRLENBQUM7SUFFakUsSUFBSSxDQUFDLFNBQVM7TUFDWixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLDhCQUE4QjtJQUM5QixNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxVQUFVLEVBQUUsR0FBRyxNQUFNLFNBQzlDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxDQUFDOzs7Ozs7TUFNVCxDQUFDLEVBQ0EsRUFBRSxDQUFDLE1BQU0sU0FDVCxNQUFNO0lBRVQsSUFBSSxjQUFjLENBQUMsT0FBTztNQUN4QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsNENBQTRDLEVBQUUsTUFBTSxLQUFLLENBQUMsQ0FBQztJQUV4RSw2QkFBNkI7SUFDN0IsTUFBTSxhQUFhLGdCQUFnQjtJQUNuQyxNQUFNLGNBQWMsQ0FBQyxXQUFXLEVBQUUsUUFBUSxrQkFBa0IsQ0FBQztJQUU3RCxNQUFNLEVBQUUsT0FBTyxjQUFjLEVBQUUsR0FBRyxNQUFNLFNBQVMsT0FBTyxDQUNyRCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsYUFBYSxJQUFJLEtBQUs7TUFBQztLQUFXLEVBQUU7TUFBRSxNQUFNO0lBQWtCLElBQUk7TUFDeEUsUUFBUTtNQUNSLGFBQWE7SUFDZjtJQUVGLElBQUksZ0JBQWdCO01BQ2xCLFFBQVEsS0FBSyxDQUFDLDBDQUEwQztJQUMxRDtJQUVBLGlFQUFpRTtJQUNqRSxNQUFNLGtCQUFrQix3QkFBd0I7SUFDaEQsTUFBTSxzQkFBc0IsQ0FBQyxXQUFXLEVBQUUsUUFBUSxpQkFBaUIsQ0FBQztJQUVwRSxNQUFNLEVBQUUsT0FBTyxlQUFlLEVBQUUsR0FBRyxNQUFNLFNBQVMsT0FBTyxDQUN0RCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMscUJBQXFCLElBQUksS0FBSztNQUFDO0tBQWdCLEVBQUU7TUFBRSxNQUFNO0lBQVksSUFBSTtNQUMvRSxRQUFRO01BQ1IsYUFBYTtJQUNmO0lBRUYsSUFBSSxpQkFBaUI7TUFDbkIsUUFBUSxLQUFLLENBQUMsa0RBQWtEO0lBQ2xFO0lBRUEsa0JBQWtCO0lBQ2xCLE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxHQUFHLFNBQVMsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLFlBQVksQ0FBQztJQUN0RSxNQUFNLEVBQUUsTUFBTSxPQUFPLEVBQUUsR0FBRyxTQUFTLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxZQUFZLENBQUM7SUFFdkUseUJBQXlCO0lBQ3pCLE1BQU0sV0FBVztNQUNmLFNBQVM7TUFDVCxjQUFjLElBQUksT0FBTyxXQUFXO01BQ3BDLFVBQVUsTUFBTSxFQUFFO01BQ2xCLGFBQWEsTUFBTSxLQUFLO01BQ3hCLFFBQVEsTUFBTSxjQUFjO01BQzVCLE1BQU0sTUFBTSxTQUFTO01BQ3JCLGlCQUFpQixNQUFNLGVBQWU7TUFDdEMsVUFBVTtRQUNSLGNBQWM7VUFDWixRQUFRO1VBQ1IsS0FBSyxNQUFNLGdCQUFnQjtVQUMzQixRQUFRLE1BQU0sZ0JBQWdCLEdBQUcsYUFBYTtRQUNoRDtRQUNBLFdBQVc7VUFDVCxRQUFRO1VBQ1IsS0FBSyxNQUFNLFNBQVM7VUFDcEIsUUFBUSxNQUFNLFNBQVMsR0FBRyxhQUFhO1FBQ3pDO1FBQ0EsVUFBVTtVQUNSLFFBQVE7VUFDUixLQUFLLE9BQU8sU0FBUztVQUNyQixRQUFRO1FBQ1Y7UUFDQSxhQUFhO1VBQ1gsUUFBUTtVQUNSLEtBQUssUUFBUSxTQUFTO1VBQ3RCLFFBQVE7UUFDVjtRQUNBLGFBQWE7VUFDWCxRQUFRO1VBQ1IsS0FBSztVQUNMLFFBQVE7UUFDVjtNQUNGO01BQ0EsY0FBYztRQUNaLFdBQVc7VUFBQztVQUFXO1VBQWU7VUFBZ0I7VUFBWTtVQUFVO1NBQWE7UUFDekYsV0FBVztRQUNYLGVBQWU7TUFDakI7SUFDRjtJQUVBLE1BQU0sbUJBQW1CLENBQUMsV0FBVyxFQUFFLFFBQVEsY0FBYyxDQUFDO0lBQzlELE1BQU0sU0FBUyxPQUFPLENBQ25CLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxrQkFBa0IsSUFBSSxLQUFLO01BQUMsS0FBSyxTQUFTLENBQUMsVUFBVSxNQUFNO0tBQUcsRUFBRTtNQUFFLE1BQU07SUFBbUIsSUFBSTtNQUNyRyxRQUFRO01BQ1IsYUFBYTtJQUNmO0lBRUYsTUFBTSxFQUFFLE1BQU0sV0FBVyxFQUFFLEdBQUcsU0FBUyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsWUFBWSxDQUFDO0lBRTNFLDREQUE0RDtJQUM1RCxNQUFNLFNBQ0gsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO01BQ04sZUFBZSxZQUFZLFNBQVM7TUFDcEMsaUJBQWlCLFFBQVEsU0FBUztJQUNwQyxHQUNDLEVBQUUsQ0FBQyxNQUFNO0lBRVosK0JBQStCO0lBQy9CLE1BQU0sRUFBRSxNQUFNLFFBQVEsRUFBRSxHQUFHLE1BQU0sU0FDOUIsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLE1BQU0sU0FDVCxNQUFNO0lBRVQsSUFBSSxVQUFVO01BQ1osTUFBTSxTQUFTLElBQUksQ0FBQyxxQkFBcUIsTUFBTSxDQUFDO1FBQzlDLFVBQVU7UUFDVixTQUFTLFNBQVMsT0FBTztRQUN6QixRQUFRO1FBQ1IsT0FBTztRQUNQLFNBQVM7VUFDUCxjQUFjLFlBQVksU0FBUztVQUNuQyxTQUFTLE9BQU8sU0FBUztVQUN6QixpQkFBaUIsUUFBUSxTQUFTO1VBQ2xDLFlBQVksQ0FBQyxDQUFDLE1BQU0sZ0JBQWdCO1VBQ3BDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sU0FBUztVQUM1QixXQUFXO1FBQ2I7TUFDRjtNQUVBLGNBQWM7TUFDZCxNQUFNLFNBQVMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7UUFDMUMsU0FBUyxTQUFTLE9BQU87UUFDekIsTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTLENBQUMsVUFBVSxFQUFFLE1BQU0sS0FBSyxDQUFDLGdGQUFnRixDQUFDO1FBQ25ILGFBQWE7UUFDYixXQUFXO01BQ2I7SUFDRjtJQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULFVBQVU7UUFDUixhQUFhLFlBQVksU0FBUztRQUNsQyxRQUFRLE9BQU8sU0FBUztRQUN4QixnQkFBZ0IsUUFBUSxTQUFTO1FBQ2pDLGdCQUFnQixNQUFNLGdCQUFnQjtRQUN0QyxVQUFVLE1BQU0sU0FBUztRQUN6QixlQUFlO01BQ2pCO0lBQ0YsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLCtCQUErQjtJQUM3QyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU8sT0FBTztJQUFRLElBQ2hEO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
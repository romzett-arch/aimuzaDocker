const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
  try {
    const authHeader = req.headers.get("Authorization");
    let userId = null;
    let isInternalCall = false;
    // Check if this is an internal call with service key
    if (authHeader === `Bearer ${supabaseServiceKey}`) {
      isInternalCall = true;
      console.log("Internal service call detected");
    } else if (authHeader?.startsWith("Bearer ")) {
      // User JWT - validate and get user
      const userClient = createClient(supabaseUrl, supabaseAnonKey, {
        global: {
          headers: {
            Authorization: authHeader
          }
        }
      });
      const token = authHeader.replace("Bearer ", "");
      const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
      if (claimsError || !claimsData?.claims) {
        return new Response(JSON.stringify({
          error: "Unauthorized"
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      userId = claimsData.claims.sub;
      console.log(`User call from: ${userId}`);
    } else {
      return new Response(JSON.stringify({
        error: "Unauthorized - missing auth"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const body = await req.json();
    const { track_id, audio_id } = body;
    console.log("Convert to WAV request:", {
      track_id,
      audio_id,
      userId,
      isInternalCall
    });
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    if (!SUNO_API_KEY) {
      throw new Error("SUNO_API_KEY not configured");
    }
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Get track info to get task_id from description
    const { data: track, error: trackError } = await supabase.from("tracks").select("id, user_id, suno_audio_id, title, description, audio_url, wav_url").eq("id", track_id).single();
    if (trackError || !track) {
      throw new Error("Track not found");
    }
    // If WAV already exists on track, return it
    if (track.wav_url) {
      console.log("WAV already exists on track:", track.wav_url);
      return new Response(JSON.stringify({
        success: true,
        wav_url: track.wav_url,
        message: "WAV already available"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // If user call, verify ownership
    if (!isInternalCall && track.user_id !== userId) {
      return new Response(JSON.stringify({
        error: "Access denied - not your track"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Extract task_id from track description
    let taskId = null;
    if (track.description) {
      const taskIdMatch = track.description.match(/\[task_id:\s*([^\]]+)\]/);
      if (taskIdMatch) {
        taskId = taskIdMatch[1].trim();
      }
    }
    // Use provided audio_id or get from track
    const audioId = audio_id || track.suno_audio_id;
    if (!taskId) {
      throw new Error("Track has no Suno task ID for WAV conversion");
    }
    // Get addon service
    const { data: addonService } = await supabase.from("addon_services").select("id, price_rub").eq("name", "convert_wav").single();
    if (!addonService) {
      throw new Error("WAV conversion service not found");
    }
    const callbackUrl = `${supabaseUrl}/functions/v1/wav-callback`;
    // Call Suno API to convert to WAV
    const response = await fetch("https://api.sunoapi.org/api/v1/wav/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify({
        taskId: taskId,
        audioId: audioId,
        callBackUrl: callbackUrl
      })
    });
    const result = await response.json();
    console.log("Suno WAV API response:", result);
    // Handle "already exists" case - try to get the WAV URL directly
    if (result.code === 409 && result.data?.taskId) {
      console.log("WAV already exists, fetching record-info...");
      // Get WAV record info from Suno API - correct endpoint is /wav/record-info
      const statusResponse = await fetch(`https://api.sunoapi.org/api/v1/wav/record-info?taskId=${result.data.taskId}`, {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${SUNO_API_KEY}`
        }
      });
      const statusResult = await statusResponse.json();
      console.log("WAV record-info response:", statusResult);
      // Check if WAV URL is available - the field is "audioWavUrl" in "response" object
      if (statusResult.code === 200 && statusResult.data?.response?.audioWavUrl) {
        const wavUrl = statusResult.data.response.audioWavUrl;
        console.log("Found WAV URL from record-info:", wavUrl);
        // Update track with WAV URL
        await supabase.from("tracks").update({
          wav_url: wavUrl,
          updated_at: new Date().toISOString()
        }).eq("id", track_id);
        // Update addon status
        await supabase.from("track_addons").upsert({
          track_id,
          addon_service_id: addonService.id,
          status: "completed",
          result_url: wavUrl,
          updated_at: new Date().toISOString()
        }, {
          onConflict: "track_id,addon_service_id"
        });
        // Send notification
        await supabase.from("notifications").insert({
          user_id: track.user_id,
          type: "addon_completed",
          title: "WAV готов к скачиванию",
          message: `Трек "${track.title}" доступен в WAV формате.`,
          target_type: "track",
          target_id: track_id,
          metadata: {
            wav_url: wavUrl
          }
        });
        return new Response(JSON.stringify({
          success: true,
          wav_url: wavUrl,
          message: "WAV ready"
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Status not ready yet, keep waiting
      await supabase.from("track_addons").upsert({
        track_id,
        addon_service_id: addonService.id,
        status: "processing",
        result_url: JSON.stringify({
          wav_task_id: result.data.taskId,
          suno_audio_id: audioId
        }),
        updated_at: new Date().toISOString()
      }, {
        onConflict: "track_id,addon_service_id"
      });
      return new Response(JSON.stringify({
        success: true,
        taskId: result.data.taskId,
        message: "WAV conversion in progress"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (result.code !== 200) {
      throw new Error(result.msg || "Failed to start WAV conversion");
    }
    // Create or update addon record
    await supabase.from("track_addons").upsert({
      track_id,
      addon_service_id: addonService.id,
      status: "processing",
      result_url: JSON.stringify({
        wav_task_id: result.data?.taskId,
        suno_audio_id: audioId
      }),
      updated_at: new Date().toISOString()
    }, {
      onConflict: "track_id,addon_service_id"
    });
    return new Response(JSON.stringify({
      success: true,
      taskId: result.data?.taskId
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in convert-to-wav:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9jb252ZXJ0LXRvLXdhdi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICBjb25zdCBzdXBhYmFzZUFub25LZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSE7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBsZXQgdXNlcklkOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgICBsZXQgaXNJbnRlcm5hbENhbGwgPSBmYWxzZTtcblxuICAgIC8vIENoZWNrIGlmIHRoaXMgaXMgYW4gaW50ZXJuYWwgY2FsbCB3aXRoIHNlcnZpY2Uga2V5XG4gICAgaWYgKGF1dGhIZWFkZXIgPT09IGBCZWFyZXIgJHtzdXBhYmFzZVNlcnZpY2VLZXl9YCkge1xuICAgICAgaXNJbnRlcm5hbENhbGwgPSB0cnVlO1xuICAgICAgY29uc29sZS5sb2coXCJJbnRlcm5hbCBzZXJ2aWNlIGNhbGwgZGV0ZWN0ZWRcIik7XG4gICAgfSBlbHNlIGlmIChhdXRoSGVhZGVyPy5zdGFydHNXaXRoKFwiQmVhcmVyIFwiKSkge1xuICAgICAgLy8gVXNlciBKV1QgLSB2YWxpZGF0ZSBhbmQgZ2V0IHVzZXJcbiAgICAgIGNvbnN0IHVzZXJDbGllbnQgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlQW5vbktleSwge1xuICAgICAgICBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfVxuICAgICAgfSk7XG4gICAgICBcbiAgICAgIGNvbnN0IHRva2VuID0gYXV0aEhlYWRlci5yZXBsYWNlKFwiQmVhcmVyIFwiLCBcIlwiKTtcbiAgICAgIGNvbnN0IHsgZGF0YTogY2xhaW1zRGF0YSwgZXJyb3I6IGNsYWltc0Vycm9yIH0gPSBhd2FpdCB1c2VyQ2xpZW50LmF1dGguZ2V0Q2xhaW1zKHRva2VuKTtcbiAgICAgIFxuICAgICAgaWYgKGNsYWltc0Vycm9yIHx8ICFjbGFpbXNEYXRhPy5jbGFpbXMpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgXG4gICAgICB1c2VySWQgPSBjbGFpbXNEYXRhLmNsYWltcy5zdWIgYXMgc3RyaW5nO1xuICAgICAgY29uc29sZS5sb2coYFVzZXIgY2FsbCBmcm9tOiAke3VzZXJJZH1gKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWQgLSBtaXNzaW5nIGF1dGhcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnN0IHsgdHJhY2tfaWQsIGF1ZGlvX2lkIH0gPSBib2R5O1xuICAgIFxuICAgIGNvbnNvbGUubG9nKFwiQ29udmVydCB0byBXQVYgcmVxdWVzdDpcIiwgeyB0cmFja19pZCwgYXVkaW9faWQsIHVzZXJJZCwgaXNJbnRlcm5hbENhbGwgfSk7XG5cbiAgICBjb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG4gICAgaWYgKCFTVU5PX0FQSV9LRVkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlNVTk9fQVBJX0tFWSBub3QgY29uZmlndXJlZFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIC8vIEdldCB0cmFjayBpbmZvIHRvIGdldCB0YXNrX2lkIGZyb20gZGVzY3JpcHRpb25cbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrLCBlcnJvcjogdHJhY2tFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAuc2VsZWN0KFwiaWQsIHVzZXJfaWQsIHN1bm9fYXVkaW9faWQsIHRpdGxlLCBkZXNjcmlwdGlvbiwgYXVkaW9fdXJsLCB3YXZfdXJsXCIpXG4gICAgICAuZXEoXCJpZFwiLCB0cmFja19pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICh0cmFja0Vycm9yIHx8ICF0cmFjaykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVHJhY2sgbm90IGZvdW5kXCIpO1xuICAgIH1cblxuICAgIC8vIElmIFdBViBhbHJlYWR5IGV4aXN0cyBvbiB0cmFjaywgcmV0dXJuIGl0XG4gICAgaWYgKHRyYWNrLndhdl91cmwpIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiV0FWIGFscmVhZHkgZXhpc3RzIG9uIHRyYWNrOlwiLCB0cmFjay53YXZfdXJsKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSwgd2F2X3VybDogdHJhY2sud2F2X3VybCwgbWVzc2FnZTogXCJXQVYgYWxyZWFkeSBhdmFpbGFibGVcIiB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gSWYgdXNlciBjYWxsLCB2ZXJpZnkgb3duZXJzaGlwXG4gICAgaWYgKCFpc0ludGVybmFsQ2FsbCAmJiB0cmFjay51c2VyX2lkICE9PSB1c2VySWQpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiQWNjZXNzIGRlbmllZCAtIG5vdCB5b3VyIHRyYWNrXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDMsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBFeHRyYWN0IHRhc2tfaWQgZnJvbSB0cmFjayBkZXNjcmlwdGlvblxuICAgIGxldCB0YXNrSWQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICAgIGlmICh0cmFjay5kZXNjcmlwdGlvbikge1xuICAgICAgY29uc3QgdGFza0lkTWF0Y2ggPSB0cmFjay5kZXNjcmlwdGlvbi5tYXRjaCgvXFxbdGFza19pZDpcXHMqKFteXFxdXSspXFxdLyk7XG4gICAgICBpZiAodGFza0lkTWF0Y2gpIHtcbiAgICAgICAgdGFza0lkID0gdGFza0lkTWF0Y2hbMV0udHJpbSgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFVzZSBwcm92aWRlZCBhdWRpb19pZCBvciBnZXQgZnJvbSB0cmFja1xuICAgIGNvbnN0IGF1ZGlvSWQgPSBhdWRpb19pZCB8fCB0cmFjay5zdW5vX2F1ZGlvX2lkO1xuXG4gICAgaWYgKCF0YXNrSWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRyYWNrIGhhcyBubyBTdW5vIHRhc2sgSUQgZm9yIFdBViBjb252ZXJzaW9uXCIpO1xuICAgIH1cblxuICAgIC8vIEdldCBhZGRvbiBzZXJ2aWNlXG4gICAgY29uc3QgeyBkYXRhOiBhZGRvblNlcnZpY2UgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImFkZG9uX3NlcnZpY2VzXCIpXG4gICAgICAuc2VsZWN0KFwiaWQsIHByaWNlX3J1YlwiKVxuICAgICAgLmVxKFwibmFtZVwiLCBcImNvbnZlcnRfd2F2XCIpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoIWFkZG9uU2VydmljZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiV0FWIGNvbnZlcnNpb24gc2VydmljZSBub3QgZm91bmRcIik7XG4gICAgfVxuXG4gICAgY29uc3QgY2FsbGJhY2tVcmwgPSBgJHtzdXBhYmFzZVVybH0vZnVuY3Rpb25zL3YxL3dhdi1jYWxsYmFja2A7XG5cbiAgICAvLyBDYWxsIFN1bm8gQVBJIHRvIGNvbnZlcnQgdG8gV0FWXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcImh0dHBzOi8vYXBpLnN1bm9hcGkub3JnL2FwaS92MS93YXYvZ2VuZXJhdGVcIiwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0YXNrSWQ6IHRhc2tJZCxcbiAgICAgICAgYXVkaW9JZDogYXVkaW9JZCxcbiAgICAgICAgY2FsbEJhY2tVcmw6IGNhbGxiYWNrVXJsLFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJTdW5vIFdBViBBUEkgcmVzcG9uc2U6XCIsIHJlc3VsdCk7XG5cbiAgICAvLyBIYW5kbGUgXCJhbHJlYWR5IGV4aXN0c1wiIGNhc2UgLSB0cnkgdG8gZ2V0IHRoZSBXQVYgVVJMIGRpcmVjdGx5XG4gICAgaWYgKHJlc3VsdC5jb2RlID09PSA0MDkgJiYgcmVzdWx0LmRhdGE/LnRhc2tJZCkge1xuICAgICAgY29uc29sZS5sb2coXCJXQVYgYWxyZWFkeSBleGlzdHMsIGZldGNoaW5nIHJlY29yZC1pbmZvLi4uXCIpO1xuICAgICAgXG4gICAgICAvLyBHZXQgV0FWIHJlY29yZCBpbmZvIGZyb20gU3VubyBBUEkgLSBjb3JyZWN0IGVuZHBvaW50IGlzIC93YXYvcmVjb3JkLWluZm9cbiAgICAgIGNvbnN0IHN0YXR1c1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2goYGh0dHBzOi8vYXBpLnN1bm9hcGkub3JnL2FwaS92MS93YXYvcmVjb3JkLWluZm8/dGFza0lkPSR7cmVzdWx0LmRhdGEudGFza0lkfWAsIHtcbiAgICAgICAgbWV0aG9kOiBcIkdFVFwiLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgICAgXG4gICAgICBjb25zdCBzdGF0dXNSZXN1bHQgPSBhd2FpdCBzdGF0dXNSZXNwb25zZS5qc29uKCk7XG4gICAgICBjb25zb2xlLmxvZyhcIldBViByZWNvcmQtaW5mbyByZXNwb25zZTpcIiwgc3RhdHVzUmVzdWx0KTtcbiAgICAgIFxuICAgICAgLy8gQ2hlY2sgaWYgV0FWIFVSTCBpcyBhdmFpbGFibGUgLSB0aGUgZmllbGQgaXMgXCJhdWRpb1dhdlVybFwiIGluIFwicmVzcG9uc2VcIiBvYmplY3RcbiAgICAgIGlmIChzdGF0dXNSZXN1bHQuY29kZSA9PT0gMjAwICYmIHN0YXR1c1Jlc3VsdC5kYXRhPy5yZXNwb25zZT8uYXVkaW9XYXZVcmwpIHtcbiAgICAgICAgY29uc3Qgd2F2VXJsID0gc3RhdHVzUmVzdWx0LmRhdGEucmVzcG9uc2UuYXVkaW9XYXZVcmw7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiRm91bmQgV0FWIFVSTCBmcm9tIHJlY29yZC1pbmZvOlwiLCB3YXZVcmwpO1xuICAgICAgICBcbiAgICAgICAgLy8gVXBkYXRlIHRyYWNrIHdpdGggV0FWIFVSTFxuICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICAgICAgd2F2X3VybDogd2F2VXJsLFxuICAgICAgICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIH0pXG4gICAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tfaWQpO1xuICAgICAgICBcbiAgICAgICAgLy8gVXBkYXRlIGFkZG9uIHN0YXR1c1xuICAgICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwidHJhY2tfYWRkb25zXCIpLnVwc2VydCh7XG4gICAgICAgICAgdHJhY2tfaWQsXG4gICAgICAgICAgYWRkb25fc2VydmljZV9pZDogYWRkb25TZXJ2aWNlLmlkLFxuICAgICAgICAgIHN0YXR1czogXCJjb21wbGV0ZWRcIixcbiAgICAgICAgICByZXN1bHRfdXJsOiB3YXZVcmwsXG4gICAgICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICB9LCB7XG4gICAgICAgICAgb25Db25mbGljdDogXCJ0cmFja19pZCxhZGRvbl9zZXJ2aWNlX2lkXCIsXG4gICAgICAgIH0pO1xuICAgICAgICBcbiAgICAgICAgLy8gU2VuZCBub3RpZmljYXRpb25cbiAgICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcIm5vdGlmaWNhdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgICAgICB1c2VyX2lkOiB0cmFjay51c2VyX2lkLFxuICAgICAgICAgIHR5cGU6IFwiYWRkb25fY29tcGxldGVkXCIsXG4gICAgICAgICAgdGl0bGU6IFwiV0FWINCz0L7RgtC+0LIg0Log0YHQutCw0YfQuNCy0LDQvdC40Y5cIixcbiAgICAgICAgICBtZXNzYWdlOiBg0KLRgNC10LogXCIke3RyYWNrLnRpdGxlfVwiINC00L7RgdGC0YPQv9C10L0g0LIgV0FWINGE0L7RgNC80LDRgtC1LmAsXG4gICAgICAgICAgdGFyZ2V0X3R5cGU6IFwidHJhY2tcIixcbiAgICAgICAgICB0YXJnZXRfaWQ6IHRyYWNrX2lkLFxuICAgICAgICAgIG1ldGFkYXRhOiB7IHdhdl91cmw6IHdhdlVybCB9LFxuICAgICAgICB9KTtcbiAgICAgICAgXG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiB0cnVlLCB3YXZfdXJsOiB3YXZVcmwsIG1lc3NhZ2U6IFwiV0FWIHJlYWR5XCIgfSksXG4gICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgLy8gU3RhdHVzIG5vdCByZWFkeSB5ZXQsIGtlZXAgd2FpdGluZ1xuICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcInRyYWNrX2FkZG9uc1wiKS51cHNlcnQoe1xuICAgICAgICB0cmFja19pZCxcbiAgICAgICAgYWRkb25fc2VydmljZV9pZDogYWRkb25TZXJ2aWNlLmlkLFxuICAgICAgICBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiLFxuICAgICAgICByZXN1bHRfdXJsOiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHdhdl90YXNrX2lkOiByZXN1bHQuZGF0YS50YXNrSWQsXG4gICAgICAgICAgc3Vub19hdWRpb19pZDogYXVkaW9JZCxcbiAgICAgICAgfSksXG4gICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIH0sIHtcbiAgICAgICAgb25Db25mbGljdDogXCJ0cmFja19pZCxhZGRvbl9zZXJ2aWNlX2lkXCIsXG4gICAgICB9KTtcblxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiB0cnVlLCB0YXNrSWQ6IHJlc3VsdC5kYXRhLnRhc2tJZCwgbWVzc2FnZTogXCJXQVYgY29udmVyc2lvbiBpbiBwcm9ncmVzc1wiIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAocmVzdWx0LmNvZGUgIT09IDIwMCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHJlc3VsdC5tc2cgfHwgXCJGYWlsZWQgdG8gc3RhcnQgV0FWIGNvbnZlcnNpb25cIik7XG4gICAgfVxuXG4gICAgLy8gQ3JlYXRlIG9yIHVwZGF0ZSBhZGRvbiByZWNvcmRcbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwidHJhY2tfYWRkb25zXCIpLnVwc2VydCh7XG4gICAgICB0cmFja19pZCxcbiAgICAgIGFkZG9uX3NlcnZpY2VfaWQ6IGFkZG9uU2VydmljZS5pZCxcbiAgICAgIHN0YXR1czogXCJwcm9jZXNzaW5nXCIsXG4gICAgICByZXN1bHRfdXJsOiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICB3YXZfdGFza19pZDogcmVzdWx0LmRhdGE/LnRhc2tJZCxcbiAgICAgICAgc3Vub19hdWRpb19pZDogYXVkaW9JZCxcbiAgICAgIH0pLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0sIHtcbiAgICAgIG9uQ29uZmxpY3Q6IFwidHJhY2tfaWQsYWRkb25fc2VydmljZV9pZFwiLFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSwgdGFza0lkOiByZXN1bHQuZGF0YT8udGFza0lkIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBjb252ZXJ0LXRvLXdhdjpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBtZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFDakMsTUFBTSxxQkFBcUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0VBQ3hDLE1BQU0sa0JBQWtCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUVyQyxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLFNBQXdCO0lBQzVCLElBQUksaUJBQWlCO0lBRXJCLHFEQUFxRDtJQUNyRCxJQUFJLGVBQWUsQ0FBQyxPQUFPLEVBQUUsbUJBQW1CLENBQUMsRUFBRTtNQUNqRCxpQkFBaUI7TUFDakIsUUFBUSxHQUFHLENBQUM7SUFDZCxPQUFPLElBQUksWUFBWSxXQUFXLFlBQVk7TUFDNUMsbUNBQW1DO01BQ25DLE1BQU0sYUFBYSxhQUFhLGFBQWEsaUJBQWlCO1FBQzVELFFBQVE7VUFBRSxTQUFTO1lBQUUsZUFBZTtVQUFXO1FBQUU7TUFDbkQ7TUFFQSxNQUFNLFFBQVEsV0FBVyxPQUFPLENBQUMsV0FBVztNQUM1QyxNQUFNLEVBQUUsTUFBTSxVQUFVLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLFdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQztNQUVqRixJQUFJLGVBQWUsQ0FBQyxZQUFZLFFBQVE7UUFDdEMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQWUsSUFDdkM7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BRUEsU0FBUyxXQUFXLE1BQU0sQ0FBQyxHQUFHO01BQzlCLFFBQVEsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDO0lBQ3pDLE9BQU87TUFDTCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBOEIsSUFDdEQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxPQUFPLE1BQU0sSUFBSSxJQUFJO0lBQzNCLE1BQU0sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEdBQUc7SUFFL0IsUUFBUSxHQUFHLENBQUMsMkJBQTJCO01BQUU7TUFBVTtNQUFVO01BQVE7SUFBZTtJQUVwRixNQUFNLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2xDLElBQUksQ0FBQyxjQUFjO01BQ2pCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxXQUFXLGFBQWEsYUFBYTtJQUUzQyxpREFBaUQ7SUFDakQsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxTQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsc0VBQ1AsRUFBRSxDQUFDLE1BQU0sVUFDVCxNQUFNO0lBRVQsSUFBSSxjQUFjLENBQUMsT0FBTztNQUN4QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLDRDQUE0QztJQUM1QyxJQUFJLE1BQU0sT0FBTyxFQUFFO01BQ2pCLFFBQVEsR0FBRyxDQUFDLGdDQUFnQyxNQUFNLE9BQU87TUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxTQUFTO1FBQU0sU0FBUyxNQUFNLE9BQU87UUFBRSxTQUFTO01BQXdCLElBQ3pGO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsaUNBQWlDO0lBQ2pDLElBQUksQ0FBQyxrQkFBa0IsTUFBTSxPQUFPLEtBQUssUUFBUTtNQUMvQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBaUMsSUFDekQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEseUNBQXlDO0lBQ3pDLElBQUksU0FBd0I7SUFDNUIsSUFBSSxNQUFNLFdBQVcsRUFBRTtNQUNyQixNQUFNLGNBQWMsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDO01BQzVDLElBQUksYUFBYTtRQUNmLFNBQVMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxJQUFJO01BQzlCO0lBQ0Y7SUFFQSwwQ0FBMEM7SUFDMUMsTUFBTSxVQUFVLFlBQVksTUFBTSxhQUFhO0lBRS9DLElBQUksQ0FBQyxRQUFRO01BQ1gsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxvQkFBb0I7SUFDcEIsTUFBTSxFQUFFLE1BQU0sWUFBWSxFQUFFLEdBQUcsTUFBTSxTQUNsQyxJQUFJLENBQUMsa0JBQ0wsTUFBTSxDQUFDLGlCQUNQLEVBQUUsQ0FBQyxRQUFRLGVBQ1gsTUFBTTtJQUVULElBQUksQ0FBQyxjQUFjO01BQ2pCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxjQUFjLENBQUMsRUFBRSxZQUFZLDBCQUEwQixDQUFDO0lBRTlELGtDQUFrQztJQUNsQyxNQUFNLFdBQVcsTUFBTSxNQUFNLCtDQUErQztNQUMxRSxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDO01BQzNDO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztRQUNuQixRQUFRO1FBQ1IsU0FBUztRQUNULGFBQWE7TUFDZjtJQUNGO0lBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0lBQ2xDLFFBQVEsR0FBRyxDQUFDLDBCQUEwQjtJQUV0QyxpRUFBaUU7SUFDakUsSUFBSSxPQUFPLElBQUksS0FBSyxPQUFPLE9BQU8sSUFBSSxFQUFFLFFBQVE7TUFDOUMsUUFBUSxHQUFHLENBQUM7TUFFWiwyRUFBMkU7TUFDM0UsTUFBTSxpQkFBaUIsTUFBTSxNQUFNLENBQUMsc0RBQXNELEVBQUUsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRTtRQUNoSCxRQUFRO1FBQ1IsU0FBUztVQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7UUFDM0M7TUFDRjtNQUVBLE1BQU0sZUFBZSxNQUFNLGVBQWUsSUFBSTtNQUM5QyxRQUFRLEdBQUcsQ0FBQyw2QkFBNkI7TUFFekMsa0ZBQWtGO01BQ2xGLElBQUksYUFBYSxJQUFJLEtBQUssT0FBTyxhQUFhLElBQUksRUFBRSxVQUFVLGFBQWE7UUFDekUsTUFBTSxTQUFTLGFBQWEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXO1FBQ3JELFFBQVEsR0FBRyxDQUFDLG1DQUFtQztRQUUvQyw0QkFBNEI7UUFDNUIsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztVQUNOLFNBQVM7VUFDVCxZQUFZLElBQUksT0FBTyxXQUFXO1FBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU07UUFFWixzQkFBc0I7UUFDdEIsTUFBTSxTQUFTLElBQUksQ0FBQyxnQkFBZ0IsTUFBTSxDQUFDO1VBQ3pDO1VBQ0Esa0JBQWtCLGFBQWEsRUFBRTtVQUNqQyxRQUFRO1VBQ1IsWUFBWTtVQUNaLFlBQVksSUFBSSxPQUFPLFdBQVc7UUFDcEMsR0FBRztVQUNELFlBQVk7UUFDZDtRQUVBLG9CQUFvQjtRQUNwQixNQUFNLFNBQVMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7VUFDMUMsU0FBUyxNQUFNLE9BQU87VUFDdEIsTUFBTTtVQUNOLE9BQU87VUFDUCxTQUFTLENBQUMsTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDLHlCQUF5QixDQUFDO1VBQ3hELGFBQWE7VUFDYixXQUFXO1VBQ1gsVUFBVTtZQUFFLFNBQVM7VUFBTztRQUM5QjtRQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsU0FBUztVQUFNLFNBQVM7VUFBUSxTQUFTO1FBQVksSUFDdEU7VUFBRSxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFdEU7TUFFQSxxQ0FBcUM7TUFDckMsTUFBTSxTQUFTLElBQUksQ0FBQyxnQkFBZ0IsTUFBTSxDQUFDO1FBQ3pDO1FBQ0Esa0JBQWtCLGFBQWEsRUFBRTtRQUNqQyxRQUFRO1FBQ1IsWUFBWSxLQUFLLFNBQVMsQ0FBQztVQUN6QixhQUFhLE9BQU8sSUFBSSxDQUFDLE1BQU07VUFDL0IsZUFBZTtRQUNqQjtRQUNBLFlBQVksSUFBSSxPQUFPLFdBQVc7TUFDcEMsR0FBRztRQUNELFlBQVk7TUFDZDtNQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsU0FBUztRQUFNLFFBQVEsT0FBTyxJQUFJLENBQUMsTUFBTTtRQUFFLFNBQVM7TUFBNkIsSUFDbEc7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxJQUFJLE9BQU8sSUFBSSxLQUFLLEtBQUs7TUFDdkIsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHLElBQUk7SUFDaEM7SUFFQSxnQ0FBZ0M7SUFDaEMsTUFBTSxTQUFTLElBQUksQ0FBQyxnQkFBZ0IsTUFBTSxDQUFDO01BQ3pDO01BQ0Esa0JBQWtCLGFBQWEsRUFBRTtNQUNqQyxRQUFRO01BQ1IsWUFBWSxLQUFLLFNBQVMsQ0FBQztRQUN6QixhQUFhLE9BQU8sSUFBSSxFQUFFO1FBQzFCLGVBQWU7TUFDakI7TUFDQSxZQUFZLElBQUksT0FBTyxXQUFXO0lBQ3BDLEdBQUc7TUFDRCxZQUFZO0lBQ2Q7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLFNBQVM7TUFBTSxRQUFRLE9BQU8sSUFBSSxFQUFFO0lBQU8sSUFDNUQ7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEUsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDRCQUE0QjtJQUMxQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
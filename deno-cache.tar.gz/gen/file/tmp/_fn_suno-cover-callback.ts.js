const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const BASE_URL = Deno.env.get("BASE_URL") || "https://aimuza.ru";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "http://api:3000";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
// Download external image and upload to local storage
async function downloadCoverToStorage(externalUrl, trackId, index) {
  try {
    console.log(`Downloading cover from: ${externalUrl}`);
    const resp = await fetch(externalUrl);
    if (!resp.ok) {
      console.log(`Download failed: ${resp.status}`);
      return null;
    }
    const blob = await resp.blob();
    const buffer = new Uint8Array(await blob.arrayBuffer());
    // Determine extension from content type
    const contentType = blob.type || "image/png";
    const ext = contentType.includes("jpeg") || contentType.includes("jpg") ? "jpg" : "png";
    const filePath = `covers/${trackId}-suno-${index}.${ext}`;
    // Upload to local storage API
    const uploadResp = await fetch(`${SUPABASE_URL}/storage/v1/object/tracks/${filePath}`, {
      method: "PUT",
      headers: {
        "Content-Type": contentType,
        "Authorization": `Bearer ${SERVICE_ROLE_KEY}`
      },
      body: buffer
    });
    if (!uploadResp.ok) {
      const errText = await uploadResp.text();
      console.log(`Upload to storage failed: ${uploadResp.status} ${errText}`);
      return null;
    }
    const localUrl = `${BASE_URL}/storage/v1/object/public/tracks/${filePath}`;
    console.log(`Cover saved to storage: ${localUrl}`);
    return localUrl;
  } catch (err) {
    console.error(`Error downloading cover:`, err);
    return null;
  }
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // Verify callback secret
    const callbackSecret = Deno.env.get("SUNO_CALLBACK_SECRET");
    if (callbackSecret) {
      const url = new URL(req.url);
      const headerToken = req.headers.get("x-callback-secret") || req.headers.get("authorization")?.replace("Bearer ", "");
      const queryToken = url.searchParams.get("secret");
      if (headerToken !== callbackSecret && queryToken !== callbackSecret) {
        console.error("Invalid callback secret provided");
        return new Response(JSON.stringify({
          error: "Unauthorized"
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      console.log("Cover callback secret verified");
    }
    const supabaseAdmin = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
    const callbackData = await req.json();
    console.log("Suno cover callback received:", JSON.stringify(callbackData));
    const code = callbackData?.code;
    const msg = callbackData?.msg;
    const coverTaskId = callbackData?.data?.taskId;
    const images = callbackData?.data?.images || [];
    console.log(`Cover callback: code=${code}, taskId=${coverTaskId}, images=${images.length}`);
    // Handle errors
    if (code !== 200) {
      console.error(`Cover generation failed: code=${code}, msg=${msg}`);
      // Remove cover_task_id marker from tracks (so it's clear it failed)
      if (coverTaskId) {
        const { data: failedTracks } = await supabaseAdmin.from("tracks").select("id, description").ilike("description", `%[cover_task_id: ${coverTaskId}]%`);
        for (const track of failedTracks || []){
          const cleanDesc = (track.description || "").replace(`\n\n[cover_task_id: ${coverTaskId}]`, "").replace(`[cover_task_id: ${coverTaskId}]`, "").trim();
          await supabaseAdmin.from("tracks").update({
            description: cleanDesc || null
          }).eq("id", track.id);
        }
      }
      return new Response(JSON.stringify({
        received: true,
        message: "Cover generation failed"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (images.length === 0) {
      console.log("No cover images in callback");
      return new Response(JSON.stringify({
        received: true,
        message: "No images"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Find tracks matching this cover_task_id
    let matchedTracks = [];
    if (coverTaskId) {
      const { data: tracks, error } = await supabaseAdmin.from("tracks").select("id, title, description, cover_url").ilike("description", `%[cover_task_id: ${coverTaskId}]%`).order("created_at", {
        ascending: true
      });
      if (error) {
        console.error("Error finding tracks by cover_task_id:", error);
      } else if (tracks && tracks.length > 0) {
        matchedTracks = tracks;
        console.log(`Found ${tracks.length} tracks for cover_task_id ${coverTaskId}`);
      }
    }
    if (matchedTracks.length === 0) {
      console.warn(`No tracks found for cover_task_id ${coverTaskId}`);
      return new Response(JSON.stringify({
        received: true,
        warning: "No matching tracks"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Assign images to tracks: image[0] → track[0], image[1] → track[1]
    // Suno usually generates 2 cover variants
    let updatedCount = 0;
    for(let i = 0; i < matchedTracks.length; i++){
      const track = matchedTracks[i];
      const imageUrl = images[i] || images[0]; // fallback to first image if fewer images than tracks
      if (!imageUrl) continue;
      // Download cover to local storage
      const localCoverUrl = await downloadCoverToStorage(imageUrl, track.id, i);
      const finalCoverUrl = localCoverUrl || imageUrl;
      // Clean description: remove cover_task_id marker
      const cleanDesc = (track.description || "").replace(`\n\n[cover_task_id: ${coverTaskId}]`, "").replace(`[cover_task_id: ${coverTaskId}]`, "").trim();
      const { error: updateError } = await supabaseAdmin.from("tracks").update({
        cover_url: finalCoverUrl,
        description: cleanDesc || null
      }).eq("id", track.id);
      if (updateError) {
        console.error(`Error updating track ${track.id} cover:`, updateError);
      } else {
        console.log(`Track ${track.id} (${track.title}) cover updated: ${finalCoverUrl}`);
        updatedCount++;
      }
    }
    console.log(`Cover callback processed: ${updatedCount} tracks updated`);
    return new Response(JSON.stringify({
      received: true,
      success: true,
      updated: updatedCount
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("suno-cover-callback error:", error);
    return new Response(JSON.stringify({
      received: true,
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9zdW5vLWNvdmVyLWNhbGxiYWNrLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcclxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XHJcblxyXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcclxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcclxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxyXG59O1xyXG5cclxuY29uc3QgQkFTRV9VUkwgPSBEZW5vLmVudi5nZXQoXCJCQVNFX1VSTFwiKSB8fCBcImh0dHBzOi8vYWltdXphLnJ1XCI7XHJcbmNvbnN0IFNVUEFCQVNFX1VSTCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSB8fCBcImh0dHA6Ly9hcGk6MzAwMFwiO1xyXG5jb25zdCBTRVJWSUNFX1JPTEVfS0VZID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSB8fCBcIlwiO1xyXG5cclxuLy8gRG93bmxvYWQgZXh0ZXJuYWwgaW1hZ2UgYW5kIHVwbG9hZCB0byBsb2NhbCBzdG9yYWdlXHJcbmFzeW5jIGZ1bmN0aW9uIGRvd25sb2FkQ292ZXJUb1N0b3JhZ2UoXHJcbiAgZXh0ZXJuYWxVcmw6IHN0cmluZyxcclxuICB0cmFja0lkOiBzdHJpbmcsXHJcbiAgaW5kZXg6IG51bWJlclxyXG4pOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcclxuICB0cnkge1xyXG4gICAgY29uc29sZS5sb2coYERvd25sb2FkaW5nIGNvdmVyIGZyb206ICR7ZXh0ZXJuYWxVcmx9YCk7XHJcbiAgICBjb25zdCByZXNwID0gYXdhaXQgZmV0Y2goZXh0ZXJuYWxVcmwpO1xyXG4gICAgaWYgKCFyZXNwLm9rKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGBEb3dubG9hZCBmYWlsZWQ6ICR7cmVzcC5zdGF0dXN9YCk7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgY29uc3QgYmxvYiA9IGF3YWl0IHJlc3AuYmxvYigpO1xyXG4gICAgY29uc3QgYnVmZmVyID0gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpKTtcclxuXHJcbiAgICAvLyBEZXRlcm1pbmUgZXh0ZW5zaW9uIGZyb20gY29udGVudCB0eXBlXHJcbiAgICBjb25zdCBjb250ZW50VHlwZSA9IGJsb2IudHlwZSB8fCBcImltYWdlL3BuZ1wiO1xyXG4gICAgY29uc3QgZXh0ID0gY29udGVudFR5cGUuaW5jbHVkZXMoXCJqcGVnXCIpIHx8IGNvbnRlbnRUeXBlLmluY2x1ZGVzKFwianBnXCIpID8gXCJqcGdcIiA6IFwicG5nXCI7XHJcbiAgICBjb25zdCBmaWxlUGF0aCA9IGBjb3ZlcnMvJHt0cmFja0lkfS1zdW5vLSR7aW5kZXh9LiR7ZXh0fWA7XHJcblxyXG4gICAgLy8gVXBsb2FkIHRvIGxvY2FsIHN0b3JhZ2UgQVBJXHJcbiAgICBjb25zdCB1cGxvYWRSZXNwID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgIGAke1NVUEFCQVNFX1VSTH0vc3RvcmFnZS92MS9vYmplY3QvdHJhY2tzLyR7ZmlsZVBhdGh9YCxcclxuICAgICAge1xyXG4gICAgICAgIG1ldGhvZDogXCJQVVRcIixcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBjb250ZW50VHlwZSxcclxuICAgICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U0VSVklDRV9ST0xFX0tFWX1gLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keTogYnVmZmVyLFxyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIGlmICghdXBsb2FkUmVzcC5vaykge1xyXG4gICAgICBjb25zdCBlcnJUZXh0ID0gYXdhaXQgdXBsb2FkUmVzcC50ZXh0KCk7XHJcbiAgICAgIGNvbnNvbGUubG9nKGBVcGxvYWQgdG8gc3RvcmFnZSBmYWlsZWQ6ICR7dXBsb2FkUmVzcC5zdGF0dXN9ICR7ZXJyVGV4dH1gKTtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbG9jYWxVcmwgPSBgJHtCQVNFX1VSTH0vc3RvcmFnZS92MS9vYmplY3QvcHVibGljL3RyYWNrcy8ke2ZpbGVQYXRofWA7XHJcbiAgICBjb25zb2xlLmxvZyhgQ292ZXIgc2F2ZWQgdG8gc3RvcmFnZTogJHtsb2NhbFVybH1gKTtcclxuICAgIHJldHVybiBsb2NhbFVybDtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGRvd25sb2FkaW5nIGNvdmVyOmAsIGVycik7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcclxuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcclxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcclxuICB9XHJcblxyXG4gIHRyeSB7XHJcbiAgICAvLyBWZXJpZnkgY2FsbGJhY2sgc2VjcmV0XHJcbiAgICBjb25zdCBjYWxsYmFja1NlY3JldCA9IERlbm8uZW52LmdldChcIlNVTk9fQ0FMTEJBQ0tfU0VDUkVUXCIpO1xyXG4gICAgaWYgKGNhbGxiYWNrU2VjcmV0KSB7XHJcbiAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmVxLnVybCk7XHJcbiAgICAgIGNvbnN0IGhlYWRlclRva2VuID0gcmVxLmhlYWRlcnMuZ2V0KFwieC1jYWxsYmFjay1zZWNyZXRcIikgfHwgcmVxLmhlYWRlcnMuZ2V0KFwiYXV0aG9yaXphdGlvblwiKT8ucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XHJcbiAgICAgIGNvbnN0IHF1ZXJ5VG9rZW4gPSB1cmwuc2VhcmNoUGFyYW1zLmdldChcInNlY3JldFwiKTtcclxuXHJcbiAgICAgIGlmIChoZWFkZXJUb2tlbiAhPT0gY2FsbGJhY2tTZWNyZXQgJiYgcXVlcnlUb2tlbiAhPT0gY2FsbGJhY2tTZWNyZXQpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiSW52YWxpZCBjYWxsYmFjayBzZWNyZXQgcHJvdmlkZWRcIik7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcclxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksXHJcbiAgICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiQ292ZXIgY2FsbGJhY2sgc2VjcmV0IHZlcmlmaWVkXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHN1cGFiYXNlQWRtaW4gPSBjcmVhdGVDbGllbnQoXHJcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiLFxyXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpID8/IFwiXCJcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgY2FsbGJhY2tEYXRhID0gYXdhaXQgcmVxLmpzb24oKTtcclxuICAgIGNvbnNvbGUubG9nKFwiU3VubyBjb3ZlciBjYWxsYmFjayByZWNlaXZlZDpcIiwgSlNPTi5zdHJpbmdpZnkoY2FsbGJhY2tEYXRhKSk7XHJcblxyXG4gICAgY29uc3QgY29kZSA9IGNhbGxiYWNrRGF0YT8uY29kZTtcclxuICAgIGNvbnN0IG1zZyA9IGNhbGxiYWNrRGF0YT8ubXNnO1xyXG4gICAgY29uc3QgY292ZXJUYXNrSWQgPSBjYWxsYmFja0RhdGE/LmRhdGE/LnRhc2tJZDtcclxuICAgIGNvbnN0IGltYWdlcyA9IGNhbGxiYWNrRGF0YT8uZGF0YT8uaW1hZ2VzIHx8IFtdO1xyXG5cclxuICAgIGNvbnNvbGUubG9nKGBDb3ZlciBjYWxsYmFjazogY29kZT0ke2NvZGV9LCB0YXNrSWQ9JHtjb3ZlclRhc2tJZH0sIGltYWdlcz0ke2ltYWdlcy5sZW5ndGh9YCk7XHJcblxyXG4gICAgLy8gSGFuZGxlIGVycm9yc1xyXG4gICAgaWYgKGNvZGUgIT09IDIwMCkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGBDb3ZlciBnZW5lcmF0aW9uIGZhaWxlZDogY29kZT0ke2NvZGV9LCBtc2c9JHttc2d9YCk7XHJcbiAgICAgIC8vIFJlbW92ZSBjb3Zlcl90YXNrX2lkIG1hcmtlciBmcm9tIHRyYWNrcyAoc28gaXQncyBjbGVhciBpdCBmYWlsZWQpXHJcbiAgICAgIGlmIChjb3ZlclRhc2tJZCkge1xyXG4gICAgICAgIGNvbnN0IHsgZGF0YTogZmFpbGVkVHJhY2tzIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXHJcbiAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxyXG4gICAgICAgICAgLnNlbGVjdChcImlkLCBkZXNjcmlwdGlvblwiKVxyXG4gICAgICAgICAgLmlsaWtlKFwiZGVzY3JpcHRpb25cIiwgYCVbY292ZXJfdGFza19pZDogJHtjb3ZlclRhc2tJZH1dJWApO1xyXG5cclxuICAgICAgICBmb3IgKGNvbnN0IHRyYWNrIG9mIGZhaWxlZFRyYWNrcyB8fCBbXSkge1xyXG4gICAgICAgICAgY29uc3QgY2xlYW5EZXNjID0gKHRyYWNrLmRlc2NyaXB0aW9uIHx8IFwiXCIpXHJcbiAgICAgICAgICAgIC5yZXBsYWNlKGBcXG5cXG5bY292ZXJfdGFza19pZDogJHtjb3ZlclRhc2tJZH1dYCwgXCJcIilcclxuICAgICAgICAgICAgLnJlcGxhY2UoYFtjb3Zlcl90YXNrX2lkOiAke2NvdmVyVGFza0lkfV1gLCBcIlwiKVxyXG4gICAgICAgICAgICAudHJpbSgpO1xyXG4gICAgICAgICAgYXdhaXQgc3VwYWJhc2VBZG1pblxyXG4gICAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxyXG4gICAgICAgICAgICAudXBkYXRlKHsgZGVzY3JpcHRpb246IGNsZWFuRGVzYyB8fCBudWxsIH0pXHJcbiAgICAgICAgICAgIC5lcShcImlkXCIsIHRyYWNrLmlkKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcclxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHJlY2VpdmVkOiB0cnVlLCBtZXNzYWdlOiBcIkNvdmVyIGdlbmVyYXRpb24gZmFpbGVkXCIgfSksXHJcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoaW1hZ2VzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIk5vIGNvdmVyIGltYWdlcyBpbiBjYWxsYmFja1wiKTtcclxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcclxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHJlY2VpdmVkOiB0cnVlLCBtZXNzYWdlOiBcIk5vIGltYWdlc1wiIH0pLFxyXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRmluZCB0cmFja3MgbWF0Y2hpbmcgdGhpcyBjb3Zlcl90YXNrX2lkXHJcbiAgICBsZXQgbWF0Y2hlZFRyYWNrczogQXJyYXk8eyBpZDogc3RyaW5nOyB0aXRsZTogc3RyaW5nIHwgbnVsbDsgZGVzY3JpcHRpb246IHN0cmluZyB8IG51bGw7IGNvdmVyX3VybDogc3RyaW5nIHwgbnVsbCB9PiA9IFtdO1xyXG5cclxuICAgIGlmIChjb3ZlclRhc2tJZCkge1xyXG4gICAgICBjb25zdCB7IGRhdGE6IHRyYWNrcywgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW5cclxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxyXG4gICAgICAgIC5zZWxlY3QoXCJpZCwgdGl0bGUsIGRlc2NyaXB0aW9uLCBjb3Zlcl91cmxcIilcclxuICAgICAgICAuaWxpa2UoXCJkZXNjcmlwdGlvblwiLCBgJVtjb3Zlcl90YXNrX2lkOiAke2NvdmVyVGFza0lkfV0lYClcclxuICAgICAgICAub3JkZXIoXCJjcmVhdGVkX2F0XCIsIHsgYXNjZW5kaW5nOiB0cnVlIH0pO1xyXG5cclxuICAgICAgaWYgKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZpbmRpbmcgdHJhY2tzIGJ5IGNvdmVyX3Rhc2tfaWQ6XCIsIGVycm9yKTtcclxuICAgICAgfSBlbHNlIGlmICh0cmFja3MgJiYgdHJhY2tzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBtYXRjaGVkVHJhY2tzID0gdHJhY2tzO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGBGb3VuZCAke3RyYWNrcy5sZW5ndGh9IHRyYWNrcyBmb3IgY292ZXJfdGFza19pZCAke2NvdmVyVGFza0lkfWApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKG1hdGNoZWRUcmFja3MubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIGNvbnNvbGUud2FybihgTm8gdHJhY2tzIGZvdW5kIGZvciBjb3Zlcl90YXNrX2lkICR7Y292ZXJUYXNrSWR9YCk7XHJcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXHJcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyByZWNlaXZlZDogdHJ1ZSwgd2FybmluZzogXCJObyBtYXRjaGluZyB0cmFja3NcIiB9KSxcclxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEFzc2lnbiBpbWFnZXMgdG8gdHJhY2tzOiBpbWFnZVswXSDihpIgdHJhY2tbMF0sIGltYWdlWzFdIOKGkiB0cmFja1sxXVxyXG4gICAgLy8gU3VubyB1c3VhbGx5IGdlbmVyYXRlcyAyIGNvdmVyIHZhcmlhbnRzXHJcbiAgICBsZXQgdXBkYXRlZENvdW50ID0gMDtcclxuXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1hdGNoZWRUcmFja3MubGVuZ3RoOyBpKyspIHtcclxuICAgICAgY29uc3QgdHJhY2sgPSBtYXRjaGVkVHJhY2tzW2ldO1xyXG4gICAgICBjb25zdCBpbWFnZVVybCA9IGltYWdlc1tpXSB8fCBpbWFnZXNbMF07IC8vIGZhbGxiYWNrIHRvIGZpcnN0IGltYWdlIGlmIGZld2VyIGltYWdlcyB0aGFuIHRyYWNrc1xyXG5cclxuICAgICAgaWYgKCFpbWFnZVVybCkgY29udGludWU7XHJcblxyXG4gICAgICAvLyBEb3dubG9hZCBjb3ZlciB0byBsb2NhbCBzdG9yYWdlXHJcbiAgICAgIGNvbnN0IGxvY2FsQ292ZXJVcmwgPSBhd2FpdCBkb3dubG9hZENvdmVyVG9TdG9yYWdlKGltYWdlVXJsLCB0cmFjay5pZCwgaSk7XHJcbiAgICAgIGNvbnN0IGZpbmFsQ292ZXJVcmwgPSBsb2NhbENvdmVyVXJsIHx8IGltYWdlVXJsO1xyXG5cclxuICAgICAgLy8gQ2xlYW4gZGVzY3JpcHRpb246IHJlbW92ZSBjb3Zlcl90YXNrX2lkIG1hcmtlclxyXG4gICAgICBjb25zdCBjbGVhbkRlc2MgPSAodHJhY2suZGVzY3JpcHRpb24gfHwgXCJcIilcclxuICAgICAgICAucmVwbGFjZShgXFxuXFxuW2NvdmVyX3Rhc2tfaWQ6ICR7Y292ZXJUYXNrSWR9XWAsIFwiXCIpXHJcbiAgICAgICAgLnJlcGxhY2UoYFtjb3Zlcl90YXNrX2lkOiAke2NvdmVyVGFza0lkfV1gLCBcIlwiKVxyXG4gICAgICAgIC50cmltKCk7XHJcblxyXG4gICAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VBZG1pblxyXG4gICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXHJcbiAgICAgICAgLnVwZGF0ZSh7XHJcbiAgICAgICAgICBjb3Zlcl91cmw6IGZpbmFsQ292ZXJVcmwsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogY2xlYW5EZXNjIHx8IG51bGwsXHJcbiAgICAgICAgfSlcclxuICAgICAgICAuZXEoXCJpZFwiLCB0cmFjay5pZCk7XHJcblxyXG4gICAgICBpZiAodXBkYXRlRXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciB1cGRhdGluZyB0cmFjayAke3RyYWNrLmlkfSBjb3ZlcjpgLCB1cGRhdGVFcnJvcik7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coYFRyYWNrICR7dHJhY2suaWR9ICgke3RyYWNrLnRpdGxlfSkgY292ZXIgdXBkYXRlZDogJHtmaW5hbENvdmVyVXJsfWApO1xyXG4gICAgICAgIHVwZGF0ZWRDb3VudCsrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc29sZS5sb2coYENvdmVyIGNhbGxiYWNrIHByb2Nlc3NlZDogJHt1cGRhdGVkQ291bnR9IHRyYWNrcyB1cGRhdGVkYCk7XHJcblxyXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcclxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyByZWNlaXZlZDogdHJ1ZSwgc3VjY2VzczogdHJ1ZSwgdXBkYXRlZDogdXBkYXRlZENvdW50IH0pLFxyXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxyXG4gICAgKTtcclxuXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJzdW5vLWNvdmVyLWNhbGxiYWNrIGVycm9yOlwiLCBlcnJvcik7XHJcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxyXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgcmVjZWl2ZWQ6IHRydWUsXHJcbiAgICAgICAgZXJyb3I6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCIsXHJcbiAgICAgIH0pLFxyXG4gICAgICB7XHJcbiAgICAgICAgc3RhdHVzOiA1MDAsXHJcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcclxuICAgICAgfVxyXG4gICAgKTtcclxuICB9XHJcbn0pO1xyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLFdBQVcsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGVBQWU7QUFDN0MsTUFBTSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUI7QUFDckQsTUFBTSxtQkFBbUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdDQUFnQztBQUV0RSxzREFBc0Q7QUFDdEQsZUFBZSx1QkFDYixXQUFtQixFQUNuQixPQUFlLEVBQ2YsS0FBYTtFQUViLElBQUk7SUFDRixRQUFRLEdBQUcsQ0FBQyxDQUFDLHdCQUF3QixFQUFFLFlBQVksQ0FBQztJQUNwRCxNQUFNLE9BQU8sTUFBTSxNQUFNO0lBQ3pCLElBQUksQ0FBQyxLQUFLLEVBQUUsRUFBRTtNQUNaLFFBQVEsR0FBRyxDQUFDLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxNQUFNLENBQUMsQ0FBQztNQUM3QyxPQUFPO0lBQ1Q7SUFDQSxNQUFNLE9BQU8sTUFBTSxLQUFLLElBQUk7SUFDNUIsTUFBTSxTQUFTLElBQUksV0FBVyxNQUFNLEtBQUssV0FBVztJQUVwRCx3Q0FBd0M7SUFDeEMsTUFBTSxjQUFjLEtBQUssSUFBSSxJQUFJO0lBQ2pDLE1BQU0sTUFBTSxZQUFZLFFBQVEsQ0FBQyxXQUFXLFlBQVksUUFBUSxDQUFDLFNBQVMsUUFBUTtJQUNsRixNQUFNLFdBQVcsQ0FBQyxPQUFPLEVBQUUsUUFBUSxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDO0lBRXpELDhCQUE4QjtJQUM5QixNQUFNLGFBQWEsTUFBTSxNQUN2QixDQUFDLEVBQUUsYUFBYSwwQkFBMEIsRUFBRSxTQUFTLENBQUMsRUFDdEQ7TUFDRSxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLENBQUM7TUFDL0M7TUFDQSxNQUFNO0lBQ1I7SUFHRixJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUU7TUFDbEIsTUFBTSxVQUFVLE1BQU0sV0FBVyxJQUFJO01BQ3JDLFFBQVEsR0FBRyxDQUFDLENBQUMsMEJBQTBCLEVBQUUsV0FBVyxNQUFNLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQztNQUN2RSxPQUFPO0lBQ1Q7SUFFQSxNQUFNLFdBQVcsQ0FBQyxFQUFFLFNBQVMsaUNBQWlDLEVBQUUsU0FBUyxDQUFDO0lBQzFFLFFBQVEsR0FBRyxDQUFDLENBQUMsd0JBQXdCLEVBQUUsU0FBUyxDQUFDO0lBQ2pELE9BQU87RUFDVCxFQUFFLE9BQU8sS0FBSztJQUNaLFFBQVEsS0FBSyxDQUFDLENBQUMsd0JBQXdCLENBQUMsRUFBRTtJQUMxQyxPQUFPO0VBQ1Q7QUFDRjtBQUVBLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLHlCQUF5QjtJQUN6QixNQUFNLGlCQUFpQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDcEMsSUFBSSxnQkFBZ0I7TUFDbEIsTUFBTSxNQUFNLElBQUksSUFBSSxJQUFJLEdBQUc7TUFDM0IsTUFBTSxjQUFjLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixRQUFRLFdBQVc7TUFDakgsTUFBTSxhQUFhLElBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQztNQUV4QyxJQUFJLGdCQUFnQixrQkFBa0IsZUFBZSxnQkFBZ0I7UUFDbkUsUUFBUSxLQUFLLENBQUM7UUFDZCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBZSxJQUN2QztVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFDQSxRQUFRLEdBQUcsQ0FBQztJQUNkO0lBRUEsTUFBTSxnQkFBZ0IsYUFDcEIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0lBRy9DLE1BQU0sZUFBZSxNQUFNLElBQUksSUFBSTtJQUNuQyxRQUFRLEdBQUcsQ0FBQyxpQ0FBaUMsS0FBSyxTQUFTLENBQUM7SUFFNUQsTUFBTSxPQUFPLGNBQWM7SUFDM0IsTUFBTSxNQUFNLGNBQWM7SUFDMUIsTUFBTSxjQUFjLGNBQWMsTUFBTTtJQUN4QyxNQUFNLFNBQVMsY0FBYyxNQUFNLFVBQVUsRUFBRTtJQUUvQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLEtBQUssU0FBUyxFQUFFLFlBQVksU0FBUyxFQUFFLE9BQU8sTUFBTSxDQUFDLENBQUM7SUFFMUYsZ0JBQWdCO0lBQ2hCLElBQUksU0FBUyxLQUFLO01BQ2hCLFFBQVEsS0FBSyxDQUFDLENBQUMsOEJBQThCLEVBQUUsS0FBSyxNQUFNLEVBQUUsSUFBSSxDQUFDO01BQ2pFLG9FQUFvRTtNQUNwRSxJQUFJLGFBQWE7UUFDZixNQUFNLEVBQUUsTUFBTSxZQUFZLEVBQUUsR0FBRyxNQUFNLGNBQ2xDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxtQkFDUCxLQUFLLENBQUMsZUFBZSxDQUFDLGlCQUFpQixFQUFFLFlBQVksRUFBRSxDQUFDO1FBRTNELEtBQUssTUFBTSxTQUFTLGdCQUFnQixFQUFFLENBQUU7VUFDdEMsTUFBTSxZQUFZLENBQUMsTUFBTSxXQUFXLElBQUksRUFBRSxFQUN2QyxPQUFPLENBQUMsQ0FBQyxvQkFBb0IsRUFBRSxZQUFZLENBQUMsQ0FBQyxFQUFFLElBQy9DLE9BQU8sQ0FBQyxDQUFDLGdCQUFnQixFQUFFLFlBQVksQ0FBQyxDQUFDLEVBQUUsSUFDM0MsSUFBSTtVQUNQLE1BQU0sY0FDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7WUFBRSxhQUFhLGFBQWE7VUFBSyxHQUN4QyxFQUFFLENBQUMsTUFBTSxNQUFNLEVBQUU7UUFDdEI7TUFDRjtNQUNBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsVUFBVTtRQUFNLFNBQVM7TUFBMEIsSUFDcEU7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxJQUFJLE9BQU8sTUFBTSxLQUFLLEdBQUc7TUFDdkIsUUFBUSxHQUFHLENBQUM7TUFDWixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLFVBQVU7UUFBTSxTQUFTO01BQVksSUFDdEQ7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSwwQ0FBMEM7SUFDMUMsSUFBSSxnQkFBbUgsRUFBRTtJQUV6SCxJQUFJLGFBQWE7TUFDZixNQUFNLEVBQUUsTUFBTSxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxjQUNuQyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMscUNBQ1AsS0FBSyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsRUFBRSxZQUFZLEVBQUUsQ0FBQyxFQUN4RCxLQUFLLENBQUMsY0FBYztRQUFFLFdBQVc7TUFBSztNQUV6QyxJQUFJLE9BQU87UUFDVCxRQUFRLEtBQUssQ0FBQywwQ0FBMEM7TUFDMUQsT0FBTyxJQUFJLFVBQVUsT0FBTyxNQUFNLEdBQUcsR0FBRztRQUN0QyxnQkFBZ0I7UUFDaEIsUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxNQUFNLENBQUMsMEJBQTBCLEVBQUUsWUFBWSxDQUFDO01BQzlFO0lBQ0Y7SUFFQSxJQUFJLGNBQWMsTUFBTSxLQUFLLEdBQUc7TUFDOUIsUUFBUSxJQUFJLENBQUMsQ0FBQyxrQ0FBa0MsRUFBRSxZQUFZLENBQUM7TUFDL0QsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxVQUFVO1FBQU0sU0FBUztNQUFxQixJQUMvRDtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLG9FQUFvRTtJQUNwRSwwQ0FBMEM7SUFDMUMsSUFBSSxlQUFlO0lBRW5CLElBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxjQUFjLE1BQU0sRUFBRSxJQUFLO01BQzdDLE1BQU0sUUFBUSxhQUFhLENBQUMsRUFBRTtNQUM5QixNQUFNLFdBQVcsTUFBTSxDQUFDLEVBQUUsSUFBSSxNQUFNLENBQUMsRUFBRSxFQUFFLHNEQUFzRDtNQUUvRixJQUFJLENBQUMsVUFBVTtNQUVmLGtDQUFrQztNQUNsQyxNQUFNLGdCQUFnQixNQUFNLHVCQUF1QixVQUFVLE1BQU0sRUFBRSxFQUFFO01BQ3ZFLE1BQU0sZ0JBQWdCLGlCQUFpQjtNQUV2QyxpREFBaUQ7TUFDakQsTUFBTSxZQUFZLENBQUMsTUFBTSxXQUFXLElBQUksRUFBRSxFQUN2QyxPQUFPLENBQUMsQ0FBQyxvQkFBb0IsRUFBRSxZQUFZLENBQUMsQ0FBQyxFQUFFLElBQy9DLE9BQU8sQ0FBQyxDQUFDLGdCQUFnQixFQUFFLFlBQVksQ0FBQyxDQUFDLEVBQUUsSUFDM0MsSUFBSTtNQUVQLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sY0FDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sV0FBVztRQUNYLGFBQWEsYUFBYTtNQUM1QixHQUNDLEVBQUUsQ0FBQyxNQUFNLE1BQU0sRUFBRTtNQUVwQixJQUFJLGFBQWE7UUFDZixRQUFRLEtBQUssQ0FBQyxDQUFDLHFCQUFxQixFQUFFLE1BQU0sRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQzNELE9BQU87UUFDTCxRQUFRLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsTUFBTSxLQUFLLENBQUMsaUJBQWlCLEVBQUUsY0FBYyxDQUFDO1FBQ2hGO01BQ0Y7SUFDRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsMEJBQTBCLEVBQUUsYUFBYSxlQUFlLENBQUM7SUFFdEUsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxVQUFVO01BQU0sU0FBUztNQUFNLFNBQVM7SUFBYSxJQUN0RTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLDhCQUE4QjtJQUM1QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFVBQVU7TUFDVixPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ2xELElBQ0E7TUFDRSxRQUFRO01BQ1IsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUNoRTtFQUVKO0FBQ0YifQ==
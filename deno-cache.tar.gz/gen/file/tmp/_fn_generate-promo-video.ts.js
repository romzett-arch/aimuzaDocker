/// <reference types="https://esm.sh/@anthropic-ai/sdk@0.25.0" />
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Verify user authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Authorization required");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      throw new Error("Invalid token");
    }
    const body = await req.json();
    const { track_id, style = "particles_glow", aspect_ratio = "9:16", duration = 30, text_artist, text_title, text_position = "bottom", cover_animation = "float", particles_color = "#00ffff", glow_intensity = 50, best_segment_auto = true } = body;
    if (!track_id) {
      throw new Error("track_id is required");
    }
    console.log(`Generating promo video for track: ${track_id}, style: ${style}`);
    // Get track info
    const { data: track, error: trackError } = await supabase.from("tracks").select("id, user_id, title, cover_url, audio_url, duration").eq("id", track_id).single();
    if (trackError || !track) {
      throw new Error("Track not found");
    }
    // Verify ownership or admin
    const { data: userRole } = await supabase.from("user_roles").select("role").eq("user_id", user.id).maybeSingle();
    const isAdmin = userRole?.role === "admin" || userRole?.role === "super_admin";
    if (track.user_id !== user.id && !isAdmin) {
      throw new Error("Access denied - not your track");
    }
    // Check if audio exists
    if (!track.audio_url) {
      throw new Error("Track has no audio file");
    }
    // Create promo video record
    const { data: promoVideo, error: insertError } = await supabase.from("promo_videos").insert({
      track_id,
      user_id: user.id,
      style,
      aspect_ratio,
      duration_seconds: duration,
      text_artist: text_artist || track.title,
      text_title: text_title || "",
      text_position,
      cover_animation,
      particles_color,
      glow_intensity,
      best_segment_auto,
      status: "pending",
      progress: 0
    }).select().single();
    if (insertError) {
      console.error("Insert error:", insertError);
      throw new Error("Failed to create promo video record");
    }
    console.log(`Created promo video record: ${promoVideo.id}`);
    // VPS endpoint for video rendering (FFmpeg + effects)
    const VPS_URL = Deno.env.get("VPS_FFMPEG_URL") || "http://217.199.254.170:3001";
    // Try to send to VPS for rendering
    const renderPayload = {
      promo_video_id: promoVideo.id,
      track_id,
      audio_url: track.audio_url,
      cover_url: track.cover_url,
      style,
      aspect_ratio,
      duration,
      text_artist: text_artist || track.title,
      text_title: text_title || "",
      text_position,
      cover_animation,
      particles_color,
      glow_intensity,
      best_segment_auto,
      callback_url: `${supabaseUrl}/functions/v1/promo-video-callback`
    };
    // Background task: send to VPS
    EdgeRuntime.waitUntil((async ()=>{
      try {
        // Update status to processing
        await supabase.from("promo_videos").update({
          status: "processing",
          progress: 5
        }).eq("id", promoVideo.id);
        const controller = new AbortController();
        const timeoutId = setTimeout(()=>controller.abort(), 10000);
        const vpsResponse = await fetch(`${VPS_URL}/render-promo`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(renderPayload),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!vpsResponse.ok) {
          throw new Error(`VPS error: ${vpsResponse.status}`);
        }
        const vpsResult = await vpsResponse.json();
        console.log("VPS render started:", vpsResult);
        // Update progress
        await supabase.from("promo_videos").update({
          status: "rendering",
          progress: 20
        }).eq("id", promoVideo.id);
      } catch (e) {
        console.error("VPS render failed, using simulation:", e);
        // Simulate video generation for development
        await simulateVideoGeneration(supabase, promoVideo.id, track);
      }
    })());
    return new Response(JSON.stringify({
      success: true,
      promo_video_id: promoVideo.id,
      message: "Promo video generation started"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Generate promo video error:", errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
// Simulate video generation for development/fallback
async function simulateVideoGeneration(supabase, promoVideoId, track) {
  console.log("Simulating video generation...");
  // Simulate progress updates
  const progressSteps = [
    30,
    50,
    70,
    90,
    100
  ];
  for (const progress of progressSteps){
    await new Promise((resolve)=>setTimeout(resolve, 2000));
    await supabase.from("promo_videos").update({
      status: progress < 100 ? "rendering" : "completed",
      progress,
      ...progress === 100 ? {
        // Use cover as thumbnail, generate placeholder video URL
        video_url: track.audio_url?.replace(".mp3", "_promo.mp4") || null,
        thumbnail_url: track.cover_url,
        completed_at: new Date().toISOString()
      } : {}
    }).eq("id", promoVideoId);
  }
  console.log(`Simulation complete for promo video: ${promoVideoId}`);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9nZW5lcmF0ZS1wcm9tby12aWRlby50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLy8gPHJlZmVyZW5jZSB0eXBlcz1cImh0dHBzOi8vZXNtLnNoL0BhbnRocm9waWMtYWkvc2RrQDAuMjUuMFwiIC8+XG5jb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDIuNDkuMVwiO1xuXG5kZWNsYXJlIGNvbnN0IEVkZ2VSdW50aW1lOiB7XG4gIHdhaXRVbnRpbChwcm9taXNlOiBQcm9taXNlPHVua25vd24+KTogdm9pZDtcbn07XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmludGVyZmFjZSBQcm9tb1ZpZGVvUmVxdWVzdCB7XG4gIHRyYWNrX2lkOiBzdHJpbmc7XG4gIHN0eWxlOiBzdHJpbmc7XG4gIGFzcGVjdF9yYXRpbzogc3RyaW5nO1xuICBkdXJhdGlvbjogbnVtYmVyO1xuICB0ZXh0X2FydGlzdD86IHN0cmluZztcbiAgdGV4dF90aXRsZT86IHN0cmluZztcbiAgdGV4dF9wb3NpdGlvbj86IHN0cmluZztcbiAgY292ZXJfYW5pbWF0aW9uPzogc3RyaW5nO1xuICBwYXJ0aWNsZXNfY29sb3I/OiBzdHJpbmc7XG4gIGdsb3dfaW50ZW5zaXR5PzogbnVtYmVyO1xuICBiZXN0X3NlZ21lbnRfYXV0bz86IGJvb2xlYW47XG59XG5cbnNlcnZlKGFzeW5jIChyZXE6IFJlcXVlc3QpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlU2VydmljZUtleSk7XG5cbiAgICAvLyBWZXJpZnkgdXNlciBhdXRoZW50aWNhdGlvblxuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQXV0aG9yaXphdGlvbiByZXF1aXJlZFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IGF1dGhFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKHRva2VuKTtcbiAgICBpZiAoYXV0aEVycm9yIHx8ICF1c2VyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHRva2VuXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IGJvZHk6IFByb21vVmlkZW9SZXF1ZXN0ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zdCB7IFxuICAgICAgdHJhY2tfaWQsIFxuICAgICAgc3R5bGUgPSBcInBhcnRpY2xlc19nbG93XCIsXG4gICAgICBhc3BlY3RfcmF0aW8gPSBcIjk6MTZcIixcbiAgICAgIGR1cmF0aW9uID0gMzAsXG4gICAgICB0ZXh0X2FydGlzdCxcbiAgICAgIHRleHRfdGl0bGUsXG4gICAgICB0ZXh0X3Bvc2l0aW9uID0gXCJib3R0b21cIixcbiAgICAgIGNvdmVyX2FuaW1hdGlvbiA9IFwiZmxvYXRcIixcbiAgICAgIHBhcnRpY2xlc19jb2xvciA9IFwiIzAwZmZmZlwiLFxuICAgICAgZ2xvd19pbnRlbnNpdHkgPSA1MCxcbiAgICAgIGJlc3Rfc2VnbWVudF9hdXRvID0gdHJ1ZSxcbiAgICB9ID0gYm9keTtcblxuICAgIGlmICghdHJhY2tfaWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcInRyYWNrX2lkIGlzIHJlcXVpcmVkXCIpO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBHZW5lcmF0aW5nIHByb21vIHZpZGVvIGZvciB0cmFjazogJHt0cmFja19pZH0sIHN0eWxlOiAke3N0eWxlfWApO1xuXG4gICAgLy8gR2V0IHRyYWNrIGluZm9cbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrLCBlcnJvcjogdHJhY2tFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAuc2VsZWN0KFwiaWQsIHVzZXJfaWQsIHRpdGxlLCBjb3Zlcl91cmwsIGF1ZGlvX3VybCwgZHVyYXRpb25cIilcbiAgICAgIC5lcShcImlkXCIsIHRyYWNrX2lkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKHRyYWNrRXJyb3IgfHwgIXRyYWNrKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUcmFjayBub3QgZm91bmRcIik7XG4gICAgfVxuXG4gICAgLy8gVmVyaWZ5IG93bmVyc2hpcCBvciBhZG1pblxuICAgIGNvbnN0IHsgZGF0YTogdXNlclJvbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInVzZXJfcm9sZXNcIilcbiAgICAgIC5zZWxlY3QoXCJyb2xlXCIpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpXG4gICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgIGNvbnN0IGlzQWRtaW4gPSB1c2VyUm9sZT8ucm9sZSA9PT0gXCJhZG1pblwiIHx8IHVzZXJSb2xlPy5yb2xlID09PSBcInN1cGVyX2FkbWluXCI7XG5cbiAgICBpZiAodHJhY2sudXNlcl9pZCAhPT0gdXNlci5pZCAmJiAhaXNBZG1pbikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQWNjZXNzIGRlbmllZCAtIG5vdCB5b3VyIHRyYWNrXCIpO1xuICAgIH1cblxuICAgIC8vIENoZWNrIGlmIGF1ZGlvIGV4aXN0c1xuICAgIGlmICghdHJhY2suYXVkaW9fdXJsKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUcmFjayBoYXMgbm8gYXVkaW8gZmlsZVwiKTtcbiAgICB9XG5cbiAgICAvLyBDcmVhdGUgcHJvbW8gdmlkZW8gcmVjb3JkXG4gICAgY29uc3QgeyBkYXRhOiBwcm9tb1ZpZGVvLCBlcnJvcjogaW5zZXJ0RXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInByb21vX3ZpZGVvc1wiKVxuICAgICAgLmluc2VydCh7XG4gICAgICAgIHRyYWNrX2lkLFxuICAgICAgICB1c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgICBzdHlsZSxcbiAgICAgICAgYXNwZWN0X3JhdGlvLFxuICAgICAgICBkdXJhdGlvbl9zZWNvbmRzOiBkdXJhdGlvbixcbiAgICAgICAgdGV4dF9hcnRpc3Q6IHRleHRfYXJ0aXN0IHx8IHRyYWNrLnRpdGxlLFxuICAgICAgICB0ZXh0X3RpdGxlOiB0ZXh0X3RpdGxlIHx8IFwiXCIsXG4gICAgICAgIHRleHRfcG9zaXRpb24sXG4gICAgICAgIGNvdmVyX2FuaW1hdGlvbixcbiAgICAgICAgcGFydGljbGVzX2NvbG9yLFxuICAgICAgICBnbG93X2ludGVuc2l0eSxcbiAgICAgICAgYmVzdF9zZWdtZW50X2F1dG8sXG4gICAgICAgIHN0YXR1czogXCJwZW5kaW5nXCIsXG4gICAgICAgIHByb2dyZXNzOiAwLFxuICAgICAgfSlcbiAgICAgIC5zZWxlY3QoKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKGluc2VydEVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiSW5zZXJ0IGVycm9yOlwiLCBpbnNlcnRFcnJvcik7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gY3JlYXRlIHByb21vIHZpZGVvIHJlY29yZFwiKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBwcm9tbyB2aWRlbyByZWNvcmQ6ICR7cHJvbW9WaWRlby5pZH1gKTtcblxuICAgIC8vIFZQUyBlbmRwb2ludCBmb3IgdmlkZW8gcmVuZGVyaW5nIChGRm1wZWcgKyBlZmZlY3RzKVxuICAgIGNvbnN0IFZQU19VUkwgPSBEZW5vLmVudi5nZXQoXCJWUFNfRkZNUEVHX1VSTFwiKSB8fCBcImh0dHA6Ly8yMTcuMTk5LjI1NC4xNzA6MzAwMVwiO1xuICAgIFxuICAgIC8vIFRyeSB0byBzZW5kIHRvIFZQUyBmb3IgcmVuZGVyaW5nXG4gICAgY29uc3QgcmVuZGVyUGF5bG9hZCA9IHtcbiAgICAgIHByb21vX3ZpZGVvX2lkOiBwcm9tb1ZpZGVvLmlkLFxuICAgICAgdHJhY2tfaWQsXG4gICAgICBhdWRpb191cmw6IHRyYWNrLmF1ZGlvX3VybCxcbiAgICAgIGNvdmVyX3VybDogdHJhY2suY292ZXJfdXJsLFxuICAgICAgc3R5bGUsXG4gICAgICBhc3BlY3RfcmF0aW8sXG4gICAgICBkdXJhdGlvbixcbiAgICAgIHRleHRfYXJ0aXN0OiB0ZXh0X2FydGlzdCB8fCB0cmFjay50aXRsZSxcbiAgICAgIHRleHRfdGl0bGU6IHRleHRfdGl0bGUgfHwgXCJcIixcbiAgICAgIHRleHRfcG9zaXRpb24sXG4gICAgICBjb3Zlcl9hbmltYXRpb24sXG4gICAgICBwYXJ0aWNsZXNfY29sb3IsXG4gICAgICBnbG93X2ludGVuc2l0eSxcbiAgICAgIGJlc3Rfc2VnbWVudF9hdXRvLFxuICAgICAgY2FsbGJhY2tfdXJsOiBgJHtzdXBhYmFzZVVybH0vZnVuY3Rpb25zL3YxL3Byb21vLXZpZGVvLWNhbGxiYWNrYCxcbiAgICB9O1xuXG4gICAgLy8gQmFja2dyb3VuZCB0YXNrOiBzZW5kIHRvIFZQU1xuICAgIEVkZ2VSdW50aW1lLndhaXRVbnRpbCgoYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gVXBkYXRlIHN0YXR1cyB0byBwcm9jZXNzaW5nXG4gICAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJwcm9tb192aWRlb3NcIilcbiAgICAgICAgICAudXBkYXRlKHsgc3RhdHVzOiBcInByb2Nlc3NpbmdcIiwgcHJvZ3Jlc3M6IDUgfSlcbiAgICAgICAgICAuZXEoXCJpZFwiLCBwcm9tb1ZpZGVvLmlkKTtcblxuICAgICAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgICAgICBjb25zdCB0aW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSwgMTAwMDApO1xuXG4gICAgICAgIGNvbnN0IHZwc1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7VlBTX1VSTH0vcmVuZGVyLXByb21vYCwge1xuICAgICAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlbmRlclBheWxvYWQpLFxuICAgICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuXG4gICAgICAgIGlmICghdnBzUmVzcG9uc2Uub2spIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFZQUyBlcnJvcjogJHt2cHNSZXNwb25zZS5zdGF0dXN9YCk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB2cHNSZXN1bHQgPSBhd2FpdCB2cHNSZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiVlBTIHJlbmRlciBzdGFydGVkOlwiLCB2cHNSZXN1bHQpO1xuXG4gICAgICAgIC8vIFVwZGF0ZSBwcm9ncmVzc1xuICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwicHJvbW9fdmlkZW9zXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJyZW5kZXJpbmdcIiwgcHJvZ3Jlc3M6IDIwIH0pXG4gICAgICAgICAgLmVxKFwiaWRcIiwgcHJvbW9WaWRlby5pZCk7XG5cbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIlZQUyByZW5kZXIgZmFpbGVkLCB1c2luZyBzaW11bGF0aW9uOlwiLCBlKTtcbiAgICAgICAgXG4gICAgICAgIC8vIFNpbXVsYXRlIHZpZGVvIGdlbmVyYXRpb24gZm9yIGRldmVsb3BtZW50XG4gICAgICAgIGF3YWl0IHNpbXVsYXRlVmlkZW9HZW5lcmF0aW9uKHN1cGFiYXNlLCBwcm9tb1ZpZGVvLmlkLCB0cmFjayk7XG4gICAgICB9XG4gICAgfSkoKSk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICBwcm9tb192aWRlb19pZDogcHJvbW9WaWRlby5pZCxcbiAgICAgICAgbWVzc2FnZTogXCJQcm9tbyB2aWRlbyBnZW5lcmF0aW9uIHN0YXJ0ZWRcIixcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICBjb25zb2xlLmVycm9yKFwiR2VuZXJhdGUgcHJvbW8gdmlkZW8gZXJyb3I6XCIsIGVycm9yTWVzc2FnZSk7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBlcnJvck1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcblxuLy8gU2ltdWxhdGUgdmlkZW8gZ2VuZXJhdGlvbiBmb3IgZGV2ZWxvcG1lbnQvZmFsbGJhY2tcbmFzeW5jIGZ1bmN0aW9uIHNpbXVsYXRlVmlkZW9HZW5lcmF0aW9uKHN1cGFiYXNlOiBhbnksIHByb21vVmlkZW9JZDogc3RyaW5nLCB0cmFjazogYW55KSB7XG4gIGNvbnNvbGUubG9nKFwiU2ltdWxhdGluZyB2aWRlbyBnZW5lcmF0aW9uLi4uXCIpO1xuXG4gIC8vIFNpbXVsYXRlIHByb2dyZXNzIHVwZGF0ZXNcbiAgY29uc3QgcHJvZ3Jlc3NTdGVwcyA9IFszMCwgNTAsIDcwLCA5MCwgMTAwXTtcbiAgXG4gIGZvciAoY29uc3QgcHJvZ3Jlc3Mgb2YgcHJvZ3Jlc3NTdGVwcykge1xuICAgIGF3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCAyMDAwKSk7XG4gICAgXG4gICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicHJvbW9fdmlkZW9zXCIpXG4gICAgICAudXBkYXRlKHsgXG4gICAgICAgIHN0YXR1czogcHJvZ3Jlc3MgPCAxMDAgPyBcInJlbmRlcmluZ1wiIDogXCJjb21wbGV0ZWRcIixcbiAgICAgICAgcHJvZ3Jlc3MsXG4gICAgICAgIC4uLihwcm9ncmVzcyA9PT0gMTAwID8ge1xuICAgICAgICAgIC8vIFVzZSBjb3ZlciBhcyB0aHVtYm5haWwsIGdlbmVyYXRlIHBsYWNlaG9sZGVyIHZpZGVvIFVSTFxuICAgICAgICAgIHZpZGVvX3VybDogdHJhY2suYXVkaW9fdXJsPy5yZXBsYWNlKFwiLm1wM1wiLCBcIl9wcm9tby5tcDRcIikgfHwgbnVsbCxcbiAgICAgICAgICB0aHVtYm5haWxfdXJsOiB0cmFjay5jb3Zlcl91cmwsXG4gICAgICAgICAgY29tcGxldGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIH0gOiB7fSlcbiAgICAgIH0pXG4gICAgICAuZXEoXCJpZFwiLCBwcm9tb1ZpZGVvSWQpO1xuICB9XG5cbiAgY29uc29sZS5sb2coYFNpbXVsYXRpb24gY29tcGxldGUgZm9yIHByb21vIHZpZGVvOiAke3Byb21vVmlkZW9JZH1gKTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxpRUFBaUU7QUFDakUsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSw4Q0FBOEM7QUFNM0UsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFnQkEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDeEMsTUFBTSxXQUFXLGFBQWEsYUFBYTtJQUUzQyw2QkFBNkI7SUFDN0IsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQ3pFLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLE9BQTBCLE1BQU0sSUFBSSxJQUFJO0lBQzlDLE1BQU0sRUFDSixRQUFRLEVBQ1IsUUFBUSxnQkFBZ0IsRUFDeEIsZUFBZSxNQUFNLEVBQ3JCLFdBQVcsRUFBRSxFQUNiLFdBQVcsRUFDWCxVQUFVLEVBQ1YsZ0JBQWdCLFFBQVEsRUFDeEIsa0JBQWtCLE9BQU8sRUFDekIsa0JBQWtCLFNBQVMsRUFDM0IsaUJBQWlCLEVBQUUsRUFDbkIsb0JBQW9CLElBQUksRUFDekIsR0FBRztJQUVKLElBQUksQ0FBQyxVQUFVO01BQ2IsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGtDQUFrQyxFQUFFLFNBQVMsU0FBUyxFQUFFLE1BQU0sQ0FBQztJQUU1RSxpQkFBaUI7SUFDakIsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxTQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsc0RBQ1AsRUFBRSxDQUFDLE1BQU0sVUFDVCxNQUFNO0lBRVQsSUFBSSxjQUFjLENBQUMsT0FBTztNQUN4QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLDRCQUE0QjtJQUM1QixNQUFNLEVBQUUsTUFBTSxRQUFRLEVBQUUsR0FBRyxNQUFNLFNBQzlCLElBQUksQ0FBQyxjQUNMLE1BQU0sQ0FBQyxRQUNQLEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRSxFQUNyQixXQUFXO0lBRWQsTUFBTSxVQUFVLFVBQVUsU0FBUyxXQUFXLFVBQVUsU0FBUztJQUVqRSxJQUFJLE1BQU0sT0FBTyxLQUFLLEtBQUssRUFBRSxJQUFJLENBQUMsU0FBUztNQUN6QyxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLHdCQUF3QjtJQUN4QixJQUFJLENBQUMsTUFBTSxTQUFTLEVBQUU7TUFDcEIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSw0QkFBNEI7SUFDNUIsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUNwRCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO01BQ047TUFDQSxTQUFTLEtBQUssRUFBRTtNQUNoQjtNQUNBO01BQ0Esa0JBQWtCO01BQ2xCLGFBQWEsZUFBZSxNQUFNLEtBQUs7TUFDdkMsWUFBWSxjQUFjO01BQzFCO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQSxRQUFRO01BQ1IsVUFBVTtJQUNaLEdBQ0MsTUFBTSxHQUNOLE1BQU07SUFFVCxJQUFJLGFBQWE7TUFDZixRQUFRLEtBQUssQ0FBQyxpQkFBaUI7TUFDL0IsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDRCQUE0QixFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUM7SUFFMUQsc0RBQXNEO0lBQ3RELE1BQU0sVUFBVSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMscUJBQXFCO0lBRWxELG1DQUFtQztJQUNuQyxNQUFNLGdCQUFnQjtNQUNwQixnQkFBZ0IsV0FBVyxFQUFFO01BQzdCO01BQ0EsV0FBVyxNQUFNLFNBQVM7TUFDMUIsV0FBVyxNQUFNLFNBQVM7TUFDMUI7TUFDQTtNQUNBO01BQ0EsYUFBYSxlQUFlLE1BQU0sS0FBSztNQUN2QyxZQUFZLGNBQWM7TUFDMUI7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLGNBQWMsQ0FBQyxFQUFFLFlBQVksa0NBQWtDLENBQUM7SUFDbEU7SUFFQSwrQkFBK0I7SUFDL0IsWUFBWSxTQUFTLENBQUMsQ0FBQztNQUNyQixJQUFJO1FBQ0YsOEJBQThCO1FBQzlCLE1BQU0sU0FDSCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO1VBQUUsUUFBUTtVQUFjLFVBQVU7UUFBRSxHQUMzQyxFQUFFLENBQUMsTUFBTSxXQUFXLEVBQUU7UUFFekIsTUFBTSxhQUFhLElBQUk7UUFDdkIsTUFBTSxZQUFZLFdBQVcsSUFBTSxXQUFXLEtBQUssSUFBSTtRQUV2RCxNQUFNLGNBQWMsTUFBTSxNQUFNLENBQUMsRUFBRSxRQUFRLGFBQWEsQ0FBQyxFQUFFO1VBQ3pELFFBQVE7VUFDUixTQUFTO1lBQUUsZ0JBQWdCO1VBQW1CO1VBQzlDLE1BQU0sS0FBSyxTQUFTLENBQUM7VUFDckIsUUFBUSxXQUFXLE1BQU07UUFDM0I7UUFFQSxhQUFhO1FBRWIsSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFO1VBQ25CLE1BQU0sSUFBSSxNQUFNLENBQUMsV0FBVyxFQUFFLFlBQVksTUFBTSxDQUFDLENBQUM7UUFDcEQ7UUFFQSxNQUFNLFlBQVksTUFBTSxZQUFZLElBQUk7UUFDeEMsUUFBUSxHQUFHLENBQUMsdUJBQXVCO1FBRW5DLGtCQUFrQjtRQUNsQixNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztVQUFFLFFBQVE7VUFBYSxVQUFVO1FBQUcsR0FDM0MsRUFBRSxDQUFDLE1BQU0sV0FBVyxFQUFFO01BRTNCLEVBQUUsT0FBTyxHQUFHO1FBQ1YsUUFBUSxLQUFLLENBQUMsd0NBQXdDO1FBRXRELDRDQUE0QztRQUM1QyxNQUFNLHdCQUF3QixVQUFVLFdBQVcsRUFBRSxFQUFFO01BQ3pEO0lBQ0YsQ0FBQztJQUVELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULGdCQUFnQixXQUFXLEVBQUU7TUFDN0IsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxNQUFNLGVBQWUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDOUQsUUFBUSxLQUFLLENBQUMsK0JBQStCO0lBQzdDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztNQUFPLE9BQU87SUFBYSxJQUNyRDtNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRjtBQUVBLHFEQUFxRDtBQUNyRCxlQUFlLHdCQUF3QixRQUFhLEVBQUUsWUFBb0IsRUFBRSxLQUFVO0VBQ3BGLFFBQVEsR0FBRyxDQUFDO0VBRVosNEJBQTRCO0VBQzVCLE1BQU0sZ0JBQWdCO0lBQUM7SUFBSTtJQUFJO0lBQUk7SUFBSTtHQUFJO0VBRTNDLEtBQUssTUFBTSxZQUFZLGNBQWU7SUFDcEMsTUFBTSxJQUFJLFFBQVEsQ0FBQSxVQUFXLFdBQVcsU0FBUztJQUVqRCxNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztNQUNOLFFBQVEsV0FBVyxNQUFNLGNBQWM7TUFDdkM7TUFDQSxHQUFJLGFBQWEsTUFBTTtRQUNyQix5REFBeUQ7UUFDekQsV0FBVyxNQUFNLFNBQVMsRUFBRSxRQUFRLFFBQVEsaUJBQWlCO1FBQzdELGVBQWUsTUFBTSxTQUFTO1FBQzlCLGNBQWMsSUFBSSxPQUFPLFdBQVc7TUFDdEMsSUFBSSxDQUFDLENBQUM7SUFDUixHQUNDLEVBQUUsQ0FBQyxNQUFNO0VBQ2Q7RUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLHFDQUFxQyxFQUFFLGFBQWEsQ0FBQztBQUNwRSJ9
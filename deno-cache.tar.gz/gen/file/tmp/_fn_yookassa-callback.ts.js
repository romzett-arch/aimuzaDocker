const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Helper function to verify YooKassa webhook signature
async function verifyWebhookSignature(body, signature, secretKey) {
  if (!signature) {
    return false;
  }
  // YooKassa uses HMAC-SHA256 for webhook signatures
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", encoder.encode(secretKey), {
    name: "HMAC",
    hash: "SHA-256"
  }, false, [
    "sign"
  ]);
  const signatureBuffer = await crypto.subtle.sign("HMAC", key, encoder.encode(body));
  // Convert to hex string
  const expectedSignature = Array.from(new Uint8Array(signatureBuffer)).map((b)=>b.toString(16).padStart(2, '0')).join('');
  // Constant-time comparison to prevent timing attacks
  if (signature.length !== expectedSignature.length) {
    return false;
  }
  let result = 0;
  for(let i = 0; i < signature.length; i++){
    result |= signature.charCodeAt(i) ^ expectedSignature.charCodeAt(i);
  }
  return result === 0;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const yookassaSecretKey = Deno.env.get("YOOKASSA_SECRET_KEY");
    // Get the raw body for signature verification
    const rawBody = await req.text();
    // Verify webhook signature - REQUIRED for security
    if (!yookassaSecretKey) {
      console.error("YOOKASSA_SECRET_KEY not configured - rejecting webhook request for security");
      return new Response(JSON.stringify({
        error: "Webhook secret not configured"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        },
        status: 500
      });
    }
    const signature = req.headers.get("X-YooKassa-Signature") || req.headers.get("x-yookassa-signature");
    const isValid = await verifyWebhookSignature(rawBody, signature, yookassaSecretKey);
    if (!isValid) {
      console.error("YooKassa webhook signature verification failed");
      return new Response(JSON.stringify({
        error: "Invalid webhook signature"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        },
        status: 401
      });
    }
    console.log("YooKassa webhook signature verified successfully");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const body = JSON.parse(rawBody);
    console.log("YooKassa webhook received:", JSON.stringify(body, null, 2));
    const { event, object } = body;
    if (!object || !object.id) {
      throw new Error("Invalid webhook payload");
    }
    // Find payment by external_id (YooKassa payment ID)
    const { data: payment, error: findError } = await supabase.from("payments").select("*").eq("external_id", object.id).eq("payment_system", "yookassa").single();
    if (findError || !payment) {
      console.error("Payment not found:", object.id);
      return new Response(JSON.stringify({
        error: "Payment not found"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        },
        status: 404
      });
    }
    let newStatus = payment.status;
    // Handle different YooKassa events
    switch(event){
      case "payment.succeeded":
        newStatus = "completed";
        break;
      case "payment.canceled":
        newStatus = "cancelled";
        break;
      case "payment.waiting_for_capture":
        newStatus = "pending";
        break;
      case "refund.succeeded":
        newStatus = "refunded";
        break;
      default:
        console.log("Unhandled event type:", event);
    }
    // Update payment status
    const { error: updateError } = await supabase.from("payments").update({
      status: newStatus,
      metadata: object,
      updated_at: new Date().toISOString()
    }).eq("id", payment.id);
    if (updateError) {
      console.error("Error updating payment:", updateError);
      throw new Error("Failed to update payment");
    }
    // Add balance to user profile if payment succeeded
    if (event === "payment.succeeded" && payment.status !== "completed") {
      const { data: profile, error: profileError } = await supabase.from("profiles").select("balance").eq("user_id", payment.user_id).single();
      if (!profileError && profile) {
        const newBalance = (profile.balance || 0) + payment.amount;
        await supabase.from("profiles").update({
          balance: newBalance
        }).eq("user_id", payment.user_id);
        // Log topup transaction
        await supabase.from("balance_transactions").insert({
          user_id: payment.user_id,
          amount: payment.amount,
          balance_after: newBalance,
          type: "topup",
          description: `Пополнение баланса (ЮKassa)`,
          reference_id: payment.id,
          reference_type: "payment"
        });
        console.log(`Balance updated for user ${payment.user_id}: ${newBalance}`);
      }
    }
    console.log("Payment updated:", payment.id, "Status:", newStatus);
    return new Response(JSON.stringify({
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 200
    });
  } catch (error) {
    console.error("YooKassa callback error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 500
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl95b29rYXNzYS1jYWxsYmFjay50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBzZXJ2ZSA9IChoYW5kbGVyOiBhbnkpID0+IHsgKGdsb2JhbFRoaXMgYXMgYW55KS5fX2NhcHR1cmVkSGFuZGxlciA9IGhhbmRsZXI7IH07XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuLy8gSGVscGVyIGZ1bmN0aW9uIHRvIHZlcmlmeSBZb29LYXNzYSB3ZWJob29rIHNpZ25hdHVyZVxuYXN5bmMgZnVuY3Rpb24gdmVyaWZ5V2ViaG9va1NpZ25hdHVyZShcbiAgYm9keTogc3RyaW5nLFxuICBzaWduYXR1cmU6IHN0cmluZyB8IG51bGwsXG4gIHNlY3JldEtleTogc3RyaW5nXG4pOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgaWYgKCFzaWduYXR1cmUpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICAvLyBZb29LYXNzYSB1c2VzIEhNQUMtU0hBMjU2IGZvciB3ZWJob29rIHNpZ25hdHVyZXNcbiAgY29uc3QgZW5jb2RlciA9IG5ldyBUZXh0RW5jb2RlcigpO1xuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleShcbiAgICBcInJhd1wiLFxuICAgIGVuY29kZXIuZW5jb2RlKHNlY3JldEtleSksXG4gICAgeyBuYW1lOiBcIkhNQUNcIiwgaGFzaDogXCJTSEEtMjU2XCIgfSxcbiAgICBmYWxzZSxcbiAgICBbXCJzaWduXCJdXG4gICk7XG5cbiAgY29uc3Qgc2lnbmF0dXJlQnVmZmVyID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5zaWduKFxuICAgIFwiSE1BQ1wiLFxuICAgIGtleSxcbiAgICBlbmNvZGVyLmVuY29kZShib2R5KVxuICApO1xuXG4gIC8vIENvbnZlcnQgdG8gaGV4IHN0cmluZ1xuICBjb25zdCBleHBlY3RlZFNpZ25hdHVyZSA9IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoc2lnbmF0dXJlQnVmZmVyKSlcbiAgICAubWFwKGIgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcbiAgICAuam9pbignJyk7XG5cbiAgLy8gQ29uc3RhbnQtdGltZSBjb21wYXJpc29uIHRvIHByZXZlbnQgdGltaW5nIGF0dGFja3NcbiAgaWYgKHNpZ25hdHVyZS5sZW5ndGggIT09IGV4cGVjdGVkU2lnbmF0dXJlLmxlbmd0aCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGxldCByZXN1bHQgPSAwO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHNpZ25hdHVyZS5sZW5ndGg7IGkrKykge1xuICAgIHJlc3VsdCB8PSBzaWduYXR1cmUuY2hhckNvZGVBdChpKSBeIGV4cGVjdGVkU2lnbmF0dXJlLmNoYXJDb2RlQXQoaSk7XG4gIH1cblxuICByZXR1cm4gcmVzdWx0ID09PSAwO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIGNvbnN0IHlvb2thc3NhU2VjcmV0S2V5ID0gRGVuby5lbnYuZ2V0KFwiWU9PS0FTU0FfU0VDUkVUX0tFWVwiKTtcblxuICAgIC8vIEdldCB0aGUgcmF3IGJvZHkgZm9yIHNpZ25hdHVyZSB2ZXJpZmljYXRpb25cbiAgICBjb25zdCByYXdCb2R5ID0gYXdhaXQgcmVxLnRleHQoKTtcbiAgICBcbiAgICAvLyBWZXJpZnkgd2ViaG9vayBzaWduYXR1cmUgLSBSRVFVSVJFRCBmb3Igc2VjdXJpdHlcbiAgICBpZiAoIXlvb2thc3NhU2VjcmV0S2V5KSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiWU9PS0FTU0FfU0VDUkVUX0tFWSBub3QgY29uZmlndXJlZCAtIHJlamVjdGluZyB3ZWJob29rIHJlcXVlc3QgZm9yIHNlY3VyaXR5XCIpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJXZWJob29rIHNlY3JldCBub3QgY29uZmlndXJlZFwiIH0pLFxuICAgICAgICB7IFxuICAgICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICAgICAgc3RhdHVzOiA1MDAgXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgc2lnbmF0dXJlID0gcmVxLmhlYWRlcnMuZ2V0KFwiWC1Zb29LYXNzYS1TaWduYXR1cmVcIikgfHwgXG4gICAgICAgICAgICAgICAgICAgICAgcmVxLmhlYWRlcnMuZ2V0KFwieC15b29rYXNzYS1zaWduYXR1cmVcIik7XG4gICAgXG4gICAgY29uc3QgaXNWYWxpZCA9IGF3YWl0IHZlcmlmeVdlYmhvb2tTaWduYXR1cmUocmF3Qm9keSwgc2lnbmF0dXJlLCB5b29rYXNzYVNlY3JldEtleSk7XG4gICAgXG4gICAgaWYgKCFpc1ZhbGlkKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiWW9vS2Fzc2Egd2ViaG9vayBzaWduYXR1cmUgdmVyaWZpY2F0aW9uIGZhaWxlZFwiKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiSW52YWxpZCB3ZWJob29rIHNpZ25hdHVyZVwiIH0pLFxuICAgICAgICB7IFxuICAgICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICAgICAgc3RhdHVzOiA0MDEgXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICAgIFxuICAgIGNvbnNvbGUubG9nKFwiWW9vS2Fzc2Egd2ViaG9vayBzaWduYXR1cmUgdmVyaWZpZWQgc3VjY2Vzc2Z1bGx5XCIpO1xuXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlU2VydmljZUtleSk7XG5cbiAgICBjb25zdCBib2R5ID0gSlNPTi5wYXJzZShyYXdCb2R5KTtcbiAgICBjb25zb2xlLmxvZyhcIllvb0thc3NhIHdlYmhvb2sgcmVjZWl2ZWQ6XCIsIEpTT04uc3RyaW5naWZ5KGJvZHksIG51bGwsIDIpKTtcblxuICAgIGNvbnN0IHsgZXZlbnQsIG9iamVjdCB9ID0gYm9keTtcblxuICAgIGlmICghb2JqZWN0IHx8ICFvYmplY3QuaWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgd2ViaG9vayBwYXlsb2FkXCIpO1xuICAgIH1cblxuICAgIC8vIEZpbmQgcGF5bWVudCBieSBleHRlcm5hbF9pZCAoWW9vS2Fzc2EgcGF5bWVudCBJRClcbiAgICBjb25zdCB7IGRhdGE6IHBheW1lbnQsIGVycm9yOiBmaW5kRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInBheW1lbnRzXCIpXG4gICAgICAuc2VsZWN0KFwiKlwiKVxuICAgICAgLmVxKFwiZXh0ZXJuYWxfaWRcIiwgb2JqZWN0LmlkKVxuICAgICAgLmVxKFwicGF5bWVudF9zeXN0ZW1cIiwgXCJ5b29rYXNzYVwiKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKGZpbmRFcnJvciB8fCAhcGF5bWVudCkge1xuICAgICAgY29uc29sZS5lcnJvcihcIlBheW1lbnQgbm90IGZvdW5kOlwiLCBvYmplY3QuaWQpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJQYXltZW50IG5vdCBmb3VuZFwiIH0pLFxuICAgICAgICB7IFxuICAgICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICAgICAgc3RhdHVzOiA0MDQgXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgbGV0IG5ld1N0YXR1cyA9IHBheW1lbnQuc3RhdHVzO1xuXG4gICAgLy8gSGFuZGxlIGRpZmZlcmVudCBZb29LYXNzYSBldmVudHNcbiAgICBzd2l0Y2ggKGV2ZW50KSB7XG4gICAgICBjYXNlIFwicGF5bWVudC5zdWNjZWVkZWRcIjpcbiAgICAgICAgbmV3U3RhdHVzID0gXCJjb21wbGV0ZWRcIjtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwicGF5bWVudC5jYW5jZWxlZFwiOlxuICAgICAgICBuZXdTdGF0dXMgPSBcImNhbmNlbGxlZFwiO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJwYXltZW50LndhaXRpbmdfZm9yX2NhcHR1cmVcIjpcbiAgICAgICAgbmV3U3RhdHVzID0gXCJwZW5kaW5nXCI7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcInJlZnVuZC5zdWNjZWVkZWRcIjpcbiAgICAgICAgbmV3U3RhdHVzID0gXCJyZWZ1bmRlZFwiO1xuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGNvbnNvbGUubG9nKFwiVW5oYW5kbGVkIGV2ZW50IHR5cGU6XCIsIGV2ZW50KTtcbiAgICB9XG5cbiAgICAvLyBVcGRhdGUgcGF5bWVudCBzdGF0dXNcbiAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicGF5bWVudHNcIilcbiAgICAgIC51cGRhdGUoeyBcbiAgICAgICAgc3RhdHVzOiBuZXdTdGF0dXMsXG4gICAgICAgIG1ldGFkYXRhOiBvYmplY3QsXG4gICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxuICAgICAgfSlcbiAgICAgIC5lcShcImlkXCIsIHBheW1lbnQuaWQpO1xuXG4gICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgcGF5bWVudDpcIiwgdXBkYXRlRXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSBwYXltZW50XCIpO1xuICAgIH1cblxuICAgIC8vIEFkZCBiYWxhbmNlIHRvIHVzZXIgcHJvZmlsZSBpZiBwYXltZW50IHN1Y2NlZWRlZFxuICAgIGlmIChldmVudCA9PT0gXCJwYXltZW50LnN1Y2NlZWRlZFwiICYmIHBheW1lbnQuc3RhdHVzICE9PSBcImNvbXBsZXRlZFwiKSB7XG4gICAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUsIGVycm9yOiBwcm9maWxlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgLnNlbGVjdChcImJhbGFuY2VcIilcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCBwYXltZW50LnVzZXJfaWQpXG4gICAgICAgIC5zaW5nbGUoKTtcblxuICAgICAgaWYgKCFwcm9maWxlRXJyb3IgJiYgcHJvZmlsZSkge1xuICAgICAgICBjb25zdCBuZXdCYWxhbmNlID0gKHByb2ZpbGUuYmFsYW5jZSB8fCAwKSArIHBheW1lbnQuYW1vdW50O1xuICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogbmV3QmFsYW5jZSB9KVxuICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgcGF5bWVudC51c2VyX2lkKTtcbiAgICAgICAgXG4gICAgICAgIC8vIExvZyB0b3B1cCB0cmFuc2FjdGlvblxuICAgICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwiYmFsYW5jZV90cmFuc2FjdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgICAgICB1c2VyX2lkOiBwYXltZW50LnVzZXJfaWQsXG4gICAgICAgICAgYW1vdW50OiBwYXltZW50LmFtb3VudCxcbiAgICAgICAgICBiYWxhbmNlX2FmdGVyOiBuZXdCYWxhbmNlLFxuICAgICAgICAgIHR5cGU6IFwidG9wdXBcIixcbiAgICAgICAgICBkZXNjcmlwdGlvbjogYNCf0L7Qv9C+0LvQvdC10L3QuNC1INCx0LDQu9Cw0L3RgdCwICjQrkthc3NhKWAsXG4gICAgICAgICAgcmVmZXJlbmNlX2lkOiBwYXltZW50LmlkLFxuICAgICAgICAgIHJlZmVyZW5jZV90eXBlOiBcInBheW1lbnRcIixcbiAgICAgICAgfSk7XG4gICAgICAgIFxuICAgICAgICBjb25zb2xlLmxvZyhgQmFsYW5jZSB1cGRhdGVkIGZvciB1c2VyICR7cGF5bWVudC51c2VyX2lkfTogJHtuZXdCYWxhbmNlfWApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKFwiUGF5bWVudCB1cGRhdGVkOlwiLCBwYXltZW50LmlkLCBcIlN0YXR1czpcIiwgbmV3U3RhdHVzKTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IHRydWUgfSksXG4gICAgICB7XG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICAgIHN0YXR1czogMjAwLFxuICAgICAgfVxuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XG4gICAgY29uc29sZS5lcnJvcihcIllvb0thc3NhIGNhbGxiYWNrIGVycm9yOlwiLCBlcnJvcik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IG1lc3NhZ2UgfSksXG4gICAgICB7XG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICAgIHN0YXR1czogNTAwLFxuICAgICAgfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sUUFBUSxDQUFDO0VBQW9CLFdBQW1CLGlCQUFpQixHQUFHO0FBQVM7QUFDbkYsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsdURBQXVEO0FBQ3ZELGVBQWUsdUJBQ2IsSUFBWSxFQUNaLFNBQXdCLEVBQ3hCLFNBQWlCO0VBRWpCLElBQUksQ0FBQyxXQUFXO0lBQ2QsT0FBTztFQUNUO0VBRUEsbURBQW1EO0VBQ25ELE1BQU0sVUFBVSxJQUFJO0VBQ3BCLE1BQU0sTUFBTSxNQUFNLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FDdkMsT0FDQSxRQUFRLE1BQU0sQ0FBQyxZQUNmO0lBQUUsTUFBTTtJQUFRLE1BQU07RUFBVSxHQUNoQyxPQUNBO0lBQUM7R0FBTztFQUdWLE1BQU0sa0JBQWtCLE1BQU0sT0FBTyxNQUFNLENBQUMsSUFBSSxDQUM5QyxRQUNBLEtBQ0EsUUFBUSxNQUFNLENBQUM7RUFHakIsd0JBQXdCO0VBQ3hCLE1BQU0sb0JBQW9CLE1BQU0sSUFBSSxDQUFDLElBQUksV0FBVyxrQkFDakQsR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxHQUFHLE1BQ3BDLElBQUksQ0FBQztFQUVSLHFEQUFxRDtFQUNyRCxJQUFJLFVBQVUsTUFBTSxLQUFLLGtCQUFrQixNQUFNLEVBQUU7SUFDakQsT0FBTztFQUNUO0VBRUEsSUFBSSxTQUFTO0VBQ2IsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsTUFBTSxFQUFFLElBQUs7SUFDekMsVUFBVSxVQUFVLFVBQVUsQ0FBQyxLQUFLLGtCQUFrQixVQUFVLENBQUM7RUFDbkU7RUFFQSxPQUFPLFdBQVc7QUFDcEI7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLG9CQUFvQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFFdkMsOENBQThDO0lBQzlDLE1BQU0sVUFBVSxNQUFNLElBQUksSUFBSTtJQUU5QixtREFBbUQ7SUFDbkQsSUFBSSxDQUFDLG1CQUFtQjtNQUN0QixRQUFRLEtBQUssQ0FBQztNQUNkLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFnQyxJQUN4RDtRQUNFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7UUFDOUQsUUFBUTtNQUNWO0lBRUo7SUFFQSxNQUFNLFlBQVksSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLDJCQUNoQixJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFFbEMsTUFBTSxVQUFVLE1BQU0sdUJBQXVCLFNBQVMsV0FBVztJQUVqRSxJQUFJLENBQUMsU0FBUztNQUNaLFFBQVEsS0FBSyxDQUFDO01BQ2QsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTRCLElBQ3BEO1FBQ0UsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtRQUM5RCxRQUFRO01BQ1Y7SUFFSjtJQUVBLFFBQVEsR0FBRyxDQUFDO0lBRVosTUFBTSxXQUFXLGFBQWEsYUFBYTtJQUUzQyxNQUFNLE9BQU8sS0FBSyxLQUFLLENBQUM7SUFDeEIsUUFBUSxHQUFHLENBQUMsOEJBQThCLEtBQUssU0FBUyxDQUFDLE1BQU0sTUFBTTtJQUVyRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHO0lBRTFCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEVBQUU7TUFDekIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxvREFBb0Q7SUFDcEQsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxTQUMvQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsS0FDUCxFQUFFLENBQUMsZUFBZSxPQUFPLEVBQUUsRUFDM0IsRUFBRSxDQUFDLGtCQUFrQixZQUNyQixNQUFNO0lBRVQsSUFBSSxhQUFhLENBQUMsU0FBUztNQUN6QixRQUFRLEtBQUssQ0FBQyxzQkFBc0IsT0FBTyxFQUFFO01BQzdDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFvQixJQUM1QztRQUNFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7UUFDOUQsUUFBUTtNQUNWO0lBRUo7SUFFQSxJQUFJLFlBQVksUUFBUSxNQUFNO0lBRTlCLG1DQUFtQztJQUNuQyxPQUFRO01BQ04sS0FBSztRQUNILFlBQVk7UUFDWjtNQUNGLEtBQUs7UUFDSCxZQUFZO1FBQ1o7TUFDRixLQUFLO1FBQ0gsWUFBWTtRQUNaO01BQ0YsS0FBSztRQUNILFlBQVk7UUFDWjtNQUNGO1FBQ0UsUUFBUSxHQUFHLENBQUMseUJBQXlCO0lBQ3pDO0lBRUEsd0JBQXdCO0lBQ3hCLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO01BQ04sUUFBUTtNQUNSLFVBQVU7TUFDVixZQUFZLElBQUksT0FBTyxXQUFXO0lBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sUUFBUSxFQUFFO0lBRXRCLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLDJCQUEyQjtNQUN6QyxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLG1EQUFtRDtJQUNuRCxJQUFJLFVBQVUsdUJBQXVCLFFBQVEsTUFBTSxLQUFLLGFBQWE7TUFDbkUsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLE9BQU8sWUFBWSxFQUFFLEdBQUcsTUFBTSxTQUNsRCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxRQUFRLE9BQU8sRUFDN0IsTUFBTTtNQUVULElBQUksQ0FBQyxnQkFBZ0IsU0FBUztRQUM1QixNQUFNLGFBQWEsQ0FBQyxRQUFRLE9BQU8sSUFBSSxDQUFDLElBQUksUUFBUSxNQUFNO1FBQzFELE1BQU0sU0FDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7VUFBRSxTQUFTO1FBQVcsR0FDN0IsRUFBRSxDQUFDLFdBQVcsUUFBUSxPQUFPO1FBRWhDLHdCQUF3QjtRQUN4QixNQUFNLFNBQVMsSUFBSSxDQUFDLHdCQUF3QixNQUFNLENBQUM7VUFDakQsU0FBUyxRQUFRLE9BQU87VUFDeEIsUUFBUSxRQUFRLE1BQU07VUFDdEIsZUFBZTtVQUNmLE1BQU07VUFDTixhQUFhLENBQUMsMkJBQTJCLENBQUM7VUFDMUMsY0FBYyxRQUFRLEVBQUU7VUFDeEIsZ0JBQWdCO1FBQ2xCO1FBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBRSxRQUFRLE9BQU8sQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDO01BQzFFO0lBQ0Y7SUFFQSxRQUFRLEdBQUcsQ0FBQyxvQkFBb0IsUUFBUSxFQUFFLEVBQUUsV0FBVztJQUV2RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLFNBQVM7SUFBSyxJQUMvQjtNQUNFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7TUFDOUQsUUFBUTtJQUNWO0VBRUosRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDRCQUE0QjtJQUMxQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFDRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO01BQzlELFFBQVE7SUFDVjtFQUVKO0FBQ0YifQ==
const serve = (handler)=>{
  globalThis.__capturedHandler = handler;
};
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version'
};
// Generate HMAC-SHA1 signature for ACRCloud
async function generateACRCloudSignature(accessKey, accessSecret, timestamp, signatureVersion, dataType) {
  const stringToSign = `POST\n/v1/identify\n${accessKey}\n${dataType}\n${signatureVersion}\n${timestamp}`;
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', encoder.encode(accessSecret), {
    name: 'HMAC',
    hash: 'SHA-1'
  }, false, [
    'sign'
  ]);
  const signature = await crypto.subtle.sign('HMAC', key, encoder.encode(stringToSign));
  return btoa(String.fromCharCode(...new Uint8Array(signature)));
}
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '');
    const ACOUSTID_API_KEY = Deno.env.get('ACOUSTID_API_KEY');
    const FFMPEG_API_URL = Deno.env.get('FFMPEG_API_URL');
    const FFMPEG_API_SECRET = Deno.env.get('FFMPEG_API_SECRET');
    const ACRCLOUD_HOST = Deno.env.get('ACRCLOUD_HOST');
    const ACRCLOUD_ACCESS_KEY = Deno.env.get('ACRCLOUD_ACCESS_KEY');
    const ACRCLOUD_ACCESS_SECRET = Deno.env.get('ACRCLOUD_ACCESS_SECRET');
    const { trackId, audioUrl } = await req.json();
    console.log(`[check-plagiarism] Starting check for track: ${trackId}`);
    if (!trackId || !audioUrl) {
      throw new Error('trackId and audioUrl are required');
    }
    // Get track data
    const { data: trackData } = await supabase.from('tracks').select('user_id, title').eq('id', trackId).single();
    const userId = trackData?.user_id;
    // Initialize check steps
    const steps = [
      {
        id: 'acoustid',
        name: 'AcoustID Fingerprint',
        database: 'MusicBrainz (45M+ треков)',
        status: 'pending'
      },
      {
        id: 'acrcloud',
        name: 'ACRCloud',
        database: 'Глобальная база (100M+ треков)',
        status: 'pending'
      },
      {
        id: 'internal',
        name: 'Внутренняя база',
        database: 'AI Planet Sound',
        status: 'pending'
      }
    ];
    // Update track status
    await supabase.from('tracks').update({
      copyright_check_status: 'checking',
      plagiarism_check_status: 'checking'
    }).eq('id', trackId);
    // Log start
    if (userId) {
      await supabase.from('distribution_logs').insert({
        track_id: trackId,
        user_id: userId,
        action: 'plagiarism_check_started',
        stage: 'upload',
        details: {
          audio_url: audioUrl,
          steps: steps.map((s)=>s.id)
        }
      });
    }
    let acoustidMatches = [];
    let acrcloudMatches = [];
    let internalMatches = [];
    let acoustidSuccess = false;
    let acoustidError = null;
    let acrcloudSuccess = false;
    let acrcloudError = null;
    // ============================================
    // STEP 1: AcoustID Check
    // ============================================
    steps[0].status = 'checking';
    console.log(`[check-plagiarism] Step 1: AcoustID fingerprint lookup`);
    try {
      if (!ACOUSTID_API_KEY) {
        throw new Error('ACOUSTID_API_KEY not configured');
      }
      // Get fingerprint from FFmpeg VPS (if available)
      let fingerprint = null;
      let duration = null;
      if (FFMPEG_API_URL && FFMPEG_API_SECRET) {
        console.log(`[check-plagiarism] Generating fingerprint via FFmpeg VPS`);
        const fpResponse = await fetch(`${FFMPEG_API_URL}/fingerprint`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${FFMPEG_API_SECRET}`
          },
          body: JSON.stringify({
            audioUrl
          })
        });
        if (fpResponse.ok) {
          const fpData = await fpResponse.json();
          fingerprint = fpData.fingerprint;
          duration = fpData.duration;
          console.log(`[check-plagiarism] Fingerprint generated, duration: ${duration}s`);
        } else {
          console.warn(`[check-plagiarism] FFmpeg fingerprint failed: ${fpResponse.status}`);
        }
      }
      // If we have fingerprint, query AcoustID
      if (fingerprint && duration) {
        const acoustidUrl = new URL('https://api.acoustid.org/v2/lookup');
        acoustidUrl.searchParams.set('client', ACOUSTID_API_KEY);
        acoustidUrl.searchParams.set('duration', String(Math.floor(duration)));
        acoustidUrl.searchParams.set('fingerprint', fingerprint);
        acoustidUrl.searchParams.set('meta', 'recordings');
        console.log(`[check-plagiarism] Querying AcoustID API...`);
        const acoustidResponse = await fetch(acoustidUrl.toString());
        if (acoustidResponse.ok) {
          const acoustidData = await acoustidResponse.json();
          console.log(`[check-plagiarism] AcoustID response:`, JSON.stringify(acoustidData).slice(0, 500));
          if (acoustidData.status === 'ok' && acoustidData.results) {
            for (const result of acoustidData.results){
              // Only consider matches with score > 0.8 (80% confidence)
              if (result.score >= 0.8 && result.recordings) {
                for (const recording of result.recordings){
                  const artistNames = recording.artists?.map((a)=>a.name).join(', ') || 'Unknown Artist';
                  acoustidMatches.push({
                    title: recording.title || 'Unknown Title',
                    artist: artistNames,
                    similarity: Math.round(result.score * 100),
                    source: 'AcoustID/MusicBrainz'
                  });
                }
              }
            }
          }
          acoustidSuccess = true;
        }
      } else {
        // Fallback: If no FFmpeg VPS, we can't generate fingerprint
        // In production, this would fail - but for demo we continue
        console.log(`[check-plagiarism] No fingerprint available, skipping AcoustID`);
        acoustidError = 'Fingerprint generation not available';
      }
      steps[0].status = 'done';
      steps[0].result = {
        found: acoustidMatches.length > 0,
        matches: acoustidMatches
      };
    } catch (error) {
      console.error(`[check-plagiarism] AcoustID error:`, error);
      steps[0].status = 'error';
      acoustidError = error instanceof Error ? error.message : 'Unknown error';
    }
    // ============================================
    // STEP 2: ACRCloud Check
    // ============================================
    steps[1].status = 'checking';
    console.log(`[check-plagiarism] Step 2: ACRCloud identification`);
    try {
      if (!ACRCLOUD_HOST || !ACRCLOUD_ACCESS_KEY || !ACRCLOUD_ACCESS_SECRET) {
        throw new Error('ACRCloud credentials not configured');
      }
      // Download audio file for ACRCloud
      console.log(`[check-plagiarism] Downloading audio for ACRCloud...`);
      const audioResponse = await fetch(audioUrl);
      if (!audioResponse.ok) {
        throw new Error(`Failed to download audio: ${audioResponse.status}`);
      }
      const audioBuffer = await audioResponse.arrayBuffer();
      const audioBytes = new Uint8Array(audioBuffer);
      // Take first 10 seconds worth of audio (approximately)
      // ACRCloud recommends 10-20 seconds for identification
      const sampleSize = Math.min(audioBytes.length, 1024 * 1024); // Max 1MB sample
      const audioSample = audioBytes.slice(0, sampleSize);
      // Generate signature
      const timestamp = Math.floor(Date.now() / 1000);
      const dataType = 'audio';
      const signatureVersion = '1';
      const signature = await generateACRCloudSignature(ACRCLOUD_ACCESS_KEY, ACRCLOUD_ACCESS_SECRET, timestamp, signatureVersion, dataType);
      // Prepare form data
      const formData = new FormData();
      formData.append('sample', new Blob([
        audioSample
      ]), 'sample.mp3');
      formData.append('sample_bytes', String(audioSample.length));
      formData.append('access_key', ACRCLOUD_ACCESS_KEY);
      formData.append('data_type', dataType);
      formData.append('signature', signature);
      formData.append('signature_version', signatureVersion);
      formData.append('timestamp', String(timestamp));
      console.log(`[check-plagiarism] Sending to ACRCloud...`);
      const acrResponse = await fetch(`https://${ACRCLOUD_HOST}/v1/identify`, {
        method: 'POST',
        body: formData
      });
      if (acrResponse.ok) {
        const acrData = await acrResponse.json();
        console.log(`[check-plagiarism] ACRCloud response code: ${acrData.status.code}`);
        if (acrData.status.code === 0 && acrData.metadata?.music) {
          for (const music of acrData.metadata.music){
            const artistNames = music.artists?.map((a)=>a.name).join(', ') || 'Unknown Artist';
            acrcloudMatches.push({
              title: music.title || 'Unknown Title',
              artist: artistNames,
              similarity: music.score,
              source: 'ACRCloud'
            });
          }
          acrcloudSuccess = true;
        } else if (acrData.status.code === 1001) {
          // No result found - this is success, just no matches
          acrcloudSuccess = true;
          console.log(`[check-plagiarism] ACRCloud: No matches found (clean)`);
        } else {
          acrcloudError = acrData.status.msg;
        }
      } else {
        acrcloudError = `HTTP ${acrResponse.status}`;
      }
      steps[1].status = 'done';
      steps[1].result = {
        found: acrcloudMatches.length > 0,
        matches: acrcloudMatches
      };
    } catch (error) {
      console.error(`[check-plagiarism] ACRCloud error:`, error);
      steps[1].status = 'error';
      acrcloudError = error instanceof Error ? error.message : 'Unknown error';
    }
    // ============================================
    // STEP 3: Internal Database Check
    // ============================================
    steps[2].status = 'checking';
    console.log(`[check-plagiarism] Step 3: Internal database check`);
    try {
      // Check against tracks in our own database
      const trackTitle = trackData?.title?.toLowerCase() || '';
      if (trackTitle) {
        const { data: similarTracks } = await supabase.from('tracks').select('id, title, user_id, profiles:user_id(username)').neq('id', trackId).neq('user_id', userId).ilike('title', `%${trackTitle.slice(0, 20)}%`).limit(5);
        if (similarTracks && similarTracks.length > 0) {
          for (const track of similarTracks){
            const similarity = calculateTitleSimilarity(trackTitle, track.title?.toLowerCase() || '');
            if (similarity > 70) {
              const profile = track.profiles;
              internalMatches.push({
                title: track.title || 'Untitled',
                artist: profile?.username || 'Unknown',
                similarity: similarity,
                source: 'AI Planet Sound'
              });
            }
          }
        }
      }
      steps[2].status = 'done';
      steps[2].result = {
        found: internalMatches.length > 0,
        matches: internalMatches
      };
    } catch (error) {
      console.error(`[check-plagiarism] Internal check error:`, error);
      steps[2].status = 'error';
    }
    // ============================================
    // Combine Results
    // ============================================
    const allMatches = [
      ...acoustidMatches,
      ...acrcloudMatches,
      ...internalMatches
    ];
    const isClean = allMatches.length === 0;
    const score = isClean ? 100 : Math.max(0, 100 - Math.max(...allMatches.map((m)=>m.similarity)));
    console.log(`[check-plagiarism] Result for ${trackId}: isClean=${isClean}, score=${score}, matches=${allMatches.length}`);
    // Update track with result
    const { error: updateError } = await supabase.from('tracks').update({
      copyright_check_status: isClean ? 'clean' : 'flagged',
      plagiarism_check_status: isClean ? 'clean' : 'flagged',
      plagiarism_check_result: {
        isClean,
        score,
        matches: allMatches,
        steps: steps.map((s)=>({
            id: s.id,
            name: s.name,
            database: s.database,
            status: s.status,
            matchCount: s.result?.matches?.length || 0
          })),
        checkedAt: new Date().toISOString(),
        acoustidAvailable: acoustidSuccess,
        acoustidError,
        acrcloudAvailable: acrcloudSuccess,
        acrcloudError
      }
    }).eq('id', trackId);
    if (updateError) {
      console.error('[check-plagiarism] Update error:', updateError);
      throw updateError;
    }
    // Log completion
    if (userId) {
      await supabase.from('distribution_logs').insert({
        track_id: trackId,
        user_id: userId,
        action: isClean ? 'plagiarism_check_clean' : 'plagiarism_check_flagged',
        stage: 'upload',
        details: {
          isClean,
          score,
          matchCount: allMatches.length,
          steps: steps.map((s)=>s.id)
        }
      });
    }
    // Return detailed result with processed steps (same format as saved to DB)
    const processedSteps = steps.map((s)=>({
        id: s.id,
        name: s.name,
        database: s.database,
        status: s.status,
        matchCount: s.result?.matches?.length || 0
      }));
    return new Response(JSON.stringify({
      success: true,
      isClean,
      score,
      matches: allMatches,
      steps: processedSteps,
      message: isClean ? 'Трек прошёл проверку' : 'Обнаружены совпадения'
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('[check-plagiarism] Error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({
      success: false,
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
// Simple title similarity using Levenshtein distance
function calculateTitleSimilarity(title1, title2) {
  const len1 = title1.length;
  const len2 = title2.length;
  if (len1 === 0) return len2 === 0 ? 100 : 0;
  if (len2 === 0) return 0;
  const matrix = [];
  for(let i = 0; i <= len1; i++){
    matrix[i] = [
      i
    ];
  }
  for(let j = 0; j <= len2; j++){
    matrix[0][j] = j;
  }
  for(let i = 1; i <= len1; i++){
    for(let j = 1; j <= len2; j++){
      const cost = title1[i - 1] === title2[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(matrix[i - 1][j] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j - 1] + cost);
    }
  }
  const distance = matrix[len1][len2];
  const maxLen = Math.max(len1, len2);
  return Math.round((1 - distance / maxLen) * 100);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdG1wL19mbl9jaGVjay1wbGFnaWFyaXNtLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHNlcnZlID0gKGhhbmRsZXI6IGFueSkgPT4geyAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fY2FwdHVyZWRIYW5kbGVyID0gaGFuZGxlcjsgfTtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcbiAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnMnOiAnYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb24nLFxufTtcblxuaW50ZXJmYWNlIFBsYWdpYXJpc21SZXF1ZXN0IHtcbiAgdHJhY2tJZDogc3RyaW5nO1xuICBhdWRpb1VybDogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgQ2hlY2tTdGVwIHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBkYXRhYmFzZTogc3RyaW5nO1xuICBzdGF0dXM6ICdwZW5kaW5nJyB8ICdjaGVja2luZycgfCAnZG9uZScgfCAnZXJyb3InO1xuICByZXN1bHQ/OiB7XG4gICAgZm91bmQ6IGJvb2xlYW47XG4gICAgbWF0Y2hlcz86IEFycmF5PHtcbiAgICAgIHRpdGxlOiBzdHJpbmc7XG4gICAgICBhcnRpc3Q6IHN0cmluZztcbiAgICAgIHNpbWlsYXJpdHk6IG51bWJlcjtcbiAgICAgIHNvdXJjZTogc3RyaW5nO1xuICAgIH0+O1xuICB9O1xufVxuXG5pbnRlcmZhY2UgQWNvdXN0SURSZXN1bHQge1xuICBzdGF0dXM6IHN0cmluZztcbiAgcmVzdWx0cz86IEFycmF5PHtcbiAgICBpZDogc3RyaW5nO1xuICAgIHNjb3JlOiBudW1iZXI7XG4gICAgcmVjb3JkaW5ncz86IEFycmF5PHtcbiAgICAgIGlkOiBzdHJpbmc7XG4gICAgICB0aXRsZT86IHN0cmluZztcbiAgICAgIGFydGlzdHM/OiBBcnJheTx7IG5hbWU6IHN0cmluZyB9PjtcbiAgICAgIGR1cmF0aW9uPzogbnVtYmVyO1xuICAgIH0+O1xuICB9Pjtcbn1cblxuaW50ZXJmYWNlIEFDUkNsb3VkUmVzdWx0IHtcbiAgc3RhdHVzOiB7XG4gICAgY29kZTogbnVtYmVyO1xuICAgIG1zZzogc3RyaW5nO1xuICB9O1xuICBtZXRhZGF0YT86IHtcbiAgICBtdXNpYz86IEFycmF5PHtcbiAgICAgIHRpdGxlOiBzdHJpbmc7XG4gICAgICBhcnRpc3RzPzogQXJyYXk8eyBuYW1lOiBzdHJpbmcgfT47XG4gICAgICBhbGJ1bT86IHsgbmFtZTogc3RyaW5nIH07XG4gICAgICBzY29yZTogbnVtYmVyO1xuICAgICAgZXh0ZXJuYWxfaWRzPzoge1xuICAgICAgICBpc3JjPzogc3RyaW5nO1xuICAgICAgICB1cGM/OiBzdHJpbmc7XG4gICAgICB9O1xuICAgIH0+O1xuICB9O1xufVxuXG4vLyBHZW5lcmF0ZSBITUFDLVNIQTEgc2lnbmF0dXJlIGZvciBBQ1JDbG91ZFxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVBQ1JDbG91ZFNpZ25hdHVyZShcbiAgYWNjZXNzS2V5OiBzdHJpbmcsXG4gIGFjY2Vzc1NlY3JldDogc3RyaW5nLFxuICB0aW1lc3RhbXA6IG51bWJlcixcbiAgc2lnbmF0dXJlVmVyc2lvbjogc3RyaW5nLFxuICBkYXRhVHlwZTogc3RyaW5nXG4pOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBzdHJpbmdUb1NpZ24gPSBgUE9TVFxcbi92MS9pZGVudGlmeVxcbiR7YWNjZXNzS2V5fVxcbiR7ZGF0YVR5cGV9XFxuJHtzaWduYXR1cmVWZXJzaW9ufVxcbiR7dGltZXN0YW1wfWA7XG4gIGNvbnN0IGVuY29kZXIgPSBuZXcgVGV4dEVuY29kZXIoKTtcbiAgY29uc3Qga2V5ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5pbXBvcnRLZXkoXG4gICAgJ3JhdycsXG4gICAgZW5jb2Rlci5lbmNvZGUoYWNjZXNzU2VjcmV0KSxcbiAgICB7IG5hbWU6ICdITUFDJywgaGFzaDogJ1NIQS0xJyB9LFxuICAgIGZhbHNlLFxuICAgIFsnc2lnbiddXG4gICk7XG4gIGNvbnN0IHNpZ25hdHVyZSA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuc2lnbignSE1BQycsIGtleSwgZW5jb2Rlci5lbmNvZGUoc3RyaW5nVG9TaWduKSk7XG4gIHJldHVybiBidG9hKFN0cmluZy5mcm9tQ2hhckNvZGUoLi4ubmV3IFVpbnQ4QXJyYXkoc2lnbmF0dXJlKSkpO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSAnT1BUSU9OUycpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKCdvaycsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9VUkwnKSA/PyAnJyxcbiAgICAgIERlbm8uZW52LmdldCgnU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWScpID8/ICcnXG4gICAgKTtcblxuICAgIGNvbnN0IEFDT1VTVElEX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoJ0FDT1VTVElEX0FQSV9LRVknKTtcbiAgICBjb25zdCBGRk1QRUdfQVBJX1VSTCA9IERlbm8uZW52LmdldCgnRkZNUEVHX0FQSV9VUkwnKTtcbiAgICBjb25zdCBGRk1QRUdfQVBJX1NFQ1JFVCA9IERlbm8uZW52LmdldCgnRkZNUEVHX0FQSV9TRUNSRVQnKTtcbiAgICBjb25zdCBBQ1JDTE9VRF9IT1NUID0gRGVuby5lbnYuZ2V0KCdBQ1JDTE9VRF9IT1NUJyk7XG4gICAgY29uc3QgQUNSQ0xPVURfQUNDRVNTX0tFWSA9IERlbm8uZW52LmdldCgnQUNSQ0xPVURfQUNDRVNTX0tFWScpO1xuICAgIGNvbnN0IEFDUkNMT1VEX0FDQ0VTU19TRUNSRVQgPSBEZW5vLmVudi5nZXQoJ0FDUkNMT1VEX0FDQ0VTU19TRUNSRVQnKTtcblxuICAgIGNvbnN0IHsgdHJhY2tJZCwgYXVkaW9VcmwgfTogUGxhZ2lhcmlzbVJlcXVlc3QgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKGBbY2hlY2stcGxhZ2lhcmlzbV0gU3RhcnRpbmcgY2hlY2sgZm9yIHRyYWNrOiAke3RyYWNrSWR9YCk7XG5cbiAgICBpZiAoIXRyYWNrSWQgfHwgIWF1ZGlvVXJsKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RyYWNrSWQgYW5kIGF1ZGlvVXJsIGFyZSByZXF1aXJlZCcpO1xuICAgIH1cblxuICAgIC8vIEdldCB0cmFjayBkYXRhXG4gICAgY29uc3QgeyBkYXRhOiB0cmFja0RhdGEgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgndHJhY2tzJylcbiAgICAgIC5zZWxlY3QoJ3VzZXJfaWQsIHRpdGxlJylcbiAgICAgIC5lcSgnaWQnLCB0cmFja0lkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgY29uc3QgdXNlcklkID0gdHJhY2tEYXRhPy51c2VyX2lkO1xuXG4gICAgLy8gSW5pdGlhbGl6ZSBjaGVjayBzdGVwc1xuICAgIGNvbnN0IHN0ZXBzOiBDaGVja1N0ZXBbXSA9IFtcbiAgICAgIHsgaWQ6ICdhY291c3RpZCcsIG5hbWU6ICdBY291c3RJRCBGaW5nZXJwcmludCcsIGRhdGFiYXNlOiAnTXVzaWNCcmFpbnogKDQ1TSsg0YLRgNC10LrQvtCyKScsIHN0YXR1czogJ3BlbmRpbmcnIH0sXG4gICAgICB7IGlkOiAnYWNyY2xvdWQnLCBuYW1lOiAnQUNSQ2xvdWQnLCBkYXRhYmFzZTogJ9CT0LvQvtCx0LDQu9GM0L3QsNGPINCx0LDQt9CwICgxMDBNKyDRgtGA0LXQutC+0LIpJywgc3RhdHVzOiAncGVuZGluZycgfSxcbiAgICAgIHsgaWQ6ICdpbnRlcm5hbCcsIG5hbWU6ICfQktC90YPRgtGA0LXQvdC90Y/RjyDQsdCw0LfQsCcsIGRhdGFiYXNlOiAnQUkgUGxhbmV0IFNvdW5kJywgc3RhdHVzOiAncGVuZGluZycgfSxcbiAgICBdO1xuXG4gICAgLy8gVXBkYXRlIHRyYWNrIHN0YXR1c1xuICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgndHJhY2tzJylcbiAgICAgIC51cGRhdGUoeyBcbiAgICAgICAgY29weXJpZ2h0X2NoZWNrX3N0YXR1czogJ2NoZWNraW5nJyxcbiAgICAgICAgcGxhZ2lhcmlzbV9jaGVja19zdGF0dXM6ICdjaGVja2luZydcbiAgICAgIH0pXG4gICAgICAuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICAvLyBMb2cgc3RhcnRcbiAgICBpZiAodXNlcklkKSB7XG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdkaXN0cmlidXRpb25fbG9ncycpLmluc2VydCh7XG4gICAgICAgIHRyYWNrX2lkOiB0cmFja0lkLFxuICAgICAgICB1c2VyX2lkOiB1c2VySWQsXG4gICAgICAgIGFjdGlvbjogJ3BsYWdpYXJpc21fY2hlY2tfc3RhcnRlZCcsXG4gICAgICAgIHN0YWdlOiAndXBsb2FkJyxcbiAgICAgICAgZGV0YWlsczogeyBhdWRpb191cmw6IGF1ZGlvVXJsLCBzdGVwczogc3RlcHMubWFwKHMgPT4gcy5pZCkgfVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgbGV0IGFjb3VzdGlkTWF0Y2hlczogQXJyYXk8eyB0aXRsZTogc3RyaW5nOyBhcnRpc3Q6IHN0cmluZzsgc2ltaWxhcml0eTogbnVtYmVyOyBzb3VyY2U6IHN0cmluZyB9PiA9IFtdO1xuICAgIGxldCBhY3JjbG91ZE1hdGNoZXM6IEFycmF5PHsgdGl0bGU6IHN0cmluZzsgYXJ0aXN0OiBzdHJpbmc7IHNpbWlsYXJpdHk6IG51bWJlcjsgc291cmNlOiBzdHJpbmcgfT4gPSBbXTtcbiAgICBsZXQgaW50ZXJuYWxNYXRjaGVzOiBBcnJheTx7IHRpdGxlOiBzdHJpbmc7IGFydGlzdDogc3RyaW5nOyBzaW1pbGFyaXR5OiBudW1iZXI7IHNvdXJjZTogc3RyaW5nIH0+ID0gW107XG4gICAgbGV0IGFjb3VzdGlkU3VjY2VzcyA9IGZhbHNlO1xuICAgIGxldCBhY291c3RpZEVycm9yOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgICBsZXQgYWNyY2xvdWRTdWNjZXNzID0gZmFsc2U7XG4gICAgbGV0IGFjcmNsb3VkRXJyb3I6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAvLyBTVEVQIDE6IEFjb3VzdElEIENoZWNrXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBzdGVwc1swXS5zdGF0dXMgPSAnY2hlY2tpbmcnO1xuICAgIGNvbnNvbGUubG9nKGBbY2hlY2stcGxhZ2lhcmlzbV0gU3RlcCAxOiBBY291c3RJRCBmaW5nZXJwcmludCBsb29rdXBgKTtcblxuICAgIHRyeSB7XG4gICAgICBpZiAoIUFDT1VTVElEX0FQSV9LRVkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdBQ09VU1RJRF9BUElfS0VZIG5vdCBjb25maWd1cmVkJyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEdldCBmaW5nZXJwcmludCBmcm9tIEZGbXBlZyBWUFMgKGlmIGF2YWlsYWJsZSlcbiAgICAgIGxldCBmaW5nZXJwcmludDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gICAgICBsZXQgZHVyYXRpb246IG51bWJlciB8IG51bGwgPSBudWxsO1xuXG4gICAgICBpZiAoRkZNUEVHX0FQSV9VUkwgJiYgRkZNUEVHX0FQSV9TRUNSRVQpIHtcbiAgICAgICAgY29uc29sZS5sb2coYFtjaGVjay1wbGFnaWFyaXNtXSBHZW5lcmF0aW5nIGZpbmdlcnByaW50IHZpYSBGRm1wZWcgVlBTYCk7XG4gICAgICAgIFxuICAgICAgICBjb25zdCBmcFJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7RkZNUEVHX0FQSV9VUkx9L2ZpbmdlcnByaW50YCwge1xuICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6IGBCZWFyZXIgJHtGRk1QRUdfQVBJX1NFQ1JFVH1gXG4gICAgICAgICAgfSxcbiAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGF1ZGlvVXJsIH0pXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmIChmcFJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgY29uc3QgZnBEYXRhID0gYXdhaXQgZnBSZXNwb25zZS5qc29uKCk7XG4gICAgICAgICAgZmluZ2VycHJpbnQgPSBmcERhdGEuZmluZ2VycHJpbnQ7XG4gICAgICAgICAgZHVyYXRpb24gPSBmcERhdGEuZHVyYXRpb247XG4gICAgICAgICAgY29uc29sZS5sb2coYFtjaGVjay1wbGFnaWFyaXNtXSBGaW5nZXJwcmludCBnZW5lcmF0ZWQsIGR1cmF0aW9uOiAke2R1cmF0aW9ufXNgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLndhcm4oYFtjaGVjay1wbGFnaWFyaXNtXSBGRm1wZWcgZmluZ2VycHJpbnQgZmFpbGVkOiAke2ZwUmVzcG9uc2Uuc3RhdHVzfWApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIElmIHdlIGhhdmUgZmluZ2VycHJpbnQsIHF1ZXJ5IEFjb3VzdElEXG4gICAgICBpZiAoZmluZ2VycHJpbnQgJiYgZHVyYXRpb24pIHtcbiAgICAgICAgY29uc3QgYWNvdXN0aWRVcmwgPSBuZXcgVVJMKCdodHRwczovL2FwaS5hY291c3RpZC5vcmcvdjIvbG9va3VwJyk7XG4gICAgICAgIGFjb3VzdGlkVXJsLnNlYXJjaFBhcmFtcy5zZXQoJ2NsaWVudCcsIEFDT1VTVElEX0FQSV9LRVkpO1xuICAgICAgICBhY291c3RpZFVybC5zZWFyY2hQYXJhbXMuc2V0KCdkdXJhdGlvbicsIFN0cmluZyhNYXRoLmZsb29yKGR1cmF0aW9uKSkpO1xuICAgICAgICBhY291c3RpZFVybC5zZWFyY2hQYXJhbXMuc2V0KCdmaW5nZXJwcmludCcsIGZpbmdlcnByaW50KTtcbiAgICAgICAgYWNvdXN0aWRVcmwuc2VhcmNoUGFyYW1zLnNldCgnbWV0YScsICdyZWNvcmRpbmdzJyk7XG5cbiAgICAgICAgY29uc29sZS5sb2coYFtjaGVjay1wbGFnaWFyaXNtXSBRdWVyeWluZyBBY291c3RJRCBBUEkuLi5gKTtcbiAgICAgICAgY29uc3QgYWNvdXN0aWRSZXNwb25zZSA9IGF3YWl0IGZldGNoKGFjb3VzdGlkVXJsLnRvU3RyaW5nKCkpO1xuICAgICAgICBcbiAgICAgICAgaWYgKGFjb3VzdGlkUmVzcG9uc2Uub2spIHtcbiAgICAgICAgICBjb25zdCBhY291c3RpZERhdGE6IEFjb3VzdElEUmVzdWx0ID0gYXdhaXQgYWNvdXN0aWRSZXNwb25zZS5qc29uKCk7XG4gICAgICAgICAgY29uc29sZS5sb2coYFtjaGVjay1wbGFnaWFyaXNtXSBBY291c3RJRCByZXNwb25zZTpgLCBKU09OLnN0cmluZ2lmeShhY291c3RpZERhdGEpLnNsaWNlKDAsIDUwMCkpO1xuICAgICAgICAgIFxuICAgICAgICAgIGlmIChhY291c3RpZERhdGEuc3RhdHVzID09PSAnb2snICYmIGFjb3VzdGlkRGF0YS5yZXN1bHRzKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHJlc3VsdCBvZiBhY291c3RpZERhdGEucmVzdWx0cykge1xuICAgICAgICAgICAgICAvLyBPbmx5IGNvbnNpZGVyIG1hdGNoZXMgd2l0aCBzY29yZSA+IDAuOCAoODAlIGNvbmZpZGVuY2UpXG4gICAgICAgICAgICAgIGlmIChyZXN1bHQuc2NvcmUgPj0gMC44ICYmIHJlc3VsdC5yZWNvcmRpbmdzKSB7XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCByZWNvcmRpbmcgb2YgcmVzdWx0LnJlY29yZGluZ3MpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGFydGlzdE5hbWVzID0gcmVjb3JkaW5nLmFydGlzdHM/Lm1hcChhID0+IGEubmFtZSkuam9pbignLCAnKSB8fCAnVW5rbm93biBBcnRpc3QnO1xuICAgICAgICAgICAgICAgICAgYWNvdXN0aWRNYXRjaGVzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICB0aXRsZTogcmVjb3JkaW5nLnRpdGxlIHx8ICdVbmtub3duIFRpdGxlJyxcbiAgICAgICAgICAgICAgICAgICAgYXJ0aXN0OiBhcnRpc3ROYW1lcyxcbiAgICAgICAgICAgICAgICAgICAgc2ltaWxhcml0eTogTWF0aC5yb3VuZChyZXN1bHQuc2NvcmUgKiAxMDApLFxuICAgICAgICAgICAgICAgICAgICBzb3VyY2U6ICdBY291c3RJRC9NdXNpY0JyYWlueidcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBhY291c3RpZFN1Y2Nlc3MgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBGYWxsYmFjazogSWYgbm8gRkZtcGVnIFZQUywgd2UgY2FuJ3QgZ2VuZXJhdGUgZmluZ2VycHJpbnRcbiAgICAgICAgLy8gSW4gcHJvZHVjdGlvbiwgdGhpcyB3b3VsZCBmYWlsIC0gYnV0IGZvciBkZW1vIHdlIGNvbnRpbnVlXG4gICAgICAgIGNvbnNvbGUubG9nKGBbY2hlY2stcGxhZ2lhcmlzbV0gTm8gZmluZ2VycHJpbnQgYXZhaWxhYmxlLCBza2lwcGluZyBBY291c3RJRGApO1xuICAgICAgICBhY291c3RpZEVycm9yID0gJ0ZpbmdlcnByaW50IGdlbmVyYXRpb24gbm90IGF2YWlsYWJsZSc7XG4gICAgICB9XG5cbiAgICAgIHN0ZXBzWzBdLnN0YXR1cyA9ICdkb25lJztcbiAgICAgIHN0ZXBzWzBdLnJlc3VsdCA9IHtcbiAgICAgICAgZm91bmQ6IGFjb3VzdGlkTWF0Y2hlcy5sZW5ndGggPiAwLFxuICAgICAgICBtYXRjaGVzOiBhY291c3RpZE1hdGNoZXNcbiAgICAgIH07XG5cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihgW2NoZWNrLXBsYWdpYXJpc21dIEFjb3VzdElEIGVycm9yOmAsIGVycm9yKTtcbiAgICAgIHN0ZXBzWzBdLnN0YXR1cyA9ICdlcnJvcic7XG4gICAgICBhY291c3RpZEVycm9yID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcic7XG4gICAgfVxuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAvLyBTVEVQIDI6IEFDUkNsb3VkIENoZWNrXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBzdGVwc1sxXS5zdGF0dXMgPSAnY2hlY2tpbmcnO1xuICAgIGNvbnNvbGUubG9nKGBbY2hlY2stcGxhZ2lhcmlzbV0gU3RlcCAyOiBBQ1JDbG91ZCBpZGVudGlmaWNhdGlvbmApO1xuXG4gICAgdHJ5IHtcbiAgICAgIGlmICghQUNSQ0xPVURfSE9TVCB8fCAhQUNSQ0xPVURfQUNDRVNTX0tFWSB8fCAhQUNSQ0xPVURfQUNDRVNTX1NFQ1JFVCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0FDUkNsb3VkIGNyZWRlbnRpYWxzIG5vdCBjb25maWd1cmVkJyk7XG4gICAgICB9XG5cbiAgICAgIC8vIERvd25sb2FkIGF1ZGlvIGZpbGUgZm9yIEFDUkNsb3VkXG4gICAgICBjb25zb2xlLmxvZyhgW2NoZWNrLXBsYWdpYXJpc21dIERvd25sb2FkaW5nIGF1ZGlvIGZvciBBQ1JDbG91ZC4uLmApO1xuICAgICAgY29uc3QgYXVkaW9SZXNwb25zZSA9IGF3YWl0IGZldGNoKGF1ZGlvVXJsKTtcbiAgICAgIGlmICghYXVkaW9SZXNwb25zZS5vaykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBkb3dubG9hZCBhdWRpbzogJHthdWRpb1Jlc3BvbnNlLnN0YXR1c31gKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGF1ZGlvQnVmZmVyID0gYXdhaXQgYXVkaW9SZXNwb25zZS5hcnJheUJ1ZmZlcigpO1xuICAgICAgY29uc3QgYXVkaW9CeXRlcyA9IG5ldyBVaW50OEFycmF5KGF1ZGlvQnVmZmVyKTtcbiAgICAgIFxuICAgICAgLy8gVGFrZSBmaXJzdCAxMCBzZWNvbmRzIHdvcnRoIG9mIGF1ZGlvIChhcHByb3hpbWF0ZWx5KVxuICAgICAgLy8gQUNSQ2xvdWQgcmVjb21tZW5kcyAxMC0yMCBzZWNvbmRzIGZvciBpZGVudGlmaWNhdGlvblxuICAgICAgY29uc3Qgc2FtcGxlU2l6ZSA9IE1hdGgubWluKGF1ZGlvQnl0ZXMubGVuZ3RoLCAxMDI0ICogMTAyNCk7IC8vIE1heCAxTUIgc2FtcGxlXG4gICAgICBjb25zdCBhdWRpb1NhbXBsZSA9IGF1ZGlvQnl0ZXMuc2xpY2UoMCwgc2FtcGxlU2l6ZSk7XG4gICAgICBcbiAgICAgIC8vIEdlbmVyYXRlIHNpZ25hdHVyZVxuICAgICAgY29uc3QgdGltZXN0YW1wID0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gICAgICBjb25zdCBkYXRhVHlwZSA9ICdhdWRpbyc7XG4gICAgICBjb25zdCBzaWduYXR1cmVWZXJzaW9uID0gJzEnO1xuICAgICAgY29uc3Qgc2lnbmF0dXJlID0gYXdhaXQgZ2VuZXJhdGVBQ1JDbG91ZFNpZ25hdHVyZShcbiAgICAgICAgQUNSQ0xPVURfQUNDRVNTX0tFWSxcbiAgICAgICAgQUNSQ0xPVURfQUNDRVNTX1NFQ1JFVCxcbiAgICAgICAgdGltZXN0YW1wLFxuICAgICAgICBzaWduYXR1cmVWZXJzaW9uLFxuICAgICAgICBkYXRhVHlwZVxuICAgICAgKTtcblxuICAgICAgLy8gUHJlcGFyZSBmb3JtIGRhdGFcbiAgICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XG4gICAgICBmb3JtRGF0YS5hcHBlbmQoJ3NhbXBsZScsIG5ldyBCbG9iKFthdWRpb1NhbXBsZV0pLCAnc2FtcGxlLm1wMycpO1xuICAgICAgZm9ybURhdGEuYXBwZW5kKCdzYW1wbGVfYnl0ZXMnLCBTdHJpbmcoYXVkaW9TYW1wbGUubGVuZ3RoKSk7XG4gICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FjY2Vzc19rZXknLCBBQ1JDTE9VRF9BQ0NFU1NfS0VZKTtcbiAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZGF0YV90eXBlJywgZGF0YVR5cGUpO1xuICAgICAgZm9ybURhdGEuYXBwZW5kKCdzaWduYXR1cmUnLCBzaWduYXR1cmUpO1xuICAgICAgZm9ybURhdGEuYXBwZW5kKCdzaWduYXR1cmVfdmVyc2lvbicsIHNpZ25hdHVyZVZlcnNpb24pO1xuICAgICAgZm9ybURhdGEuYXBwZW5kKCd0aW1lc3RhbXAnLCBTdHJpbmcodGltZXN0YW1wKSk7XG5cbiAgICAgIGNvbnNvbGUubG9nKGBbY2hlY2stcGxhZ2lhcmlzbV0gU2VuZGluZyB0byBBQ1JDbG91ZC4uLmApO1xuICAgICAgY29uc3QgYWNyUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgaHR0cHM6Ly8ke0FDUkNMT1VEX0hPU1R9L3YxL2lkZW50aWZ5YCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgYm9keTogZm9ybURhdGFcbiAgICAgIH0pO1xuXG4gICAgICBpZiAoYWNyUmVzcG9uc2Uub2spIHtcbiAgICAgICAgY29uc3QgYWNyRGF0YTogQUNSQ2xvdWRSZXN1bHQgPSBhd2FpdCBhY3JSZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbY2hlY2stcGxhZ2lhcmlzbV0gQUNSQ2xvdWQgcmVzcG9uc2UgY29kZTogJHthY3JEYXRhLnN0YXR1cy5jb2RlfWApO1xuXG4gICAgICAgIGlmIChhY3JEYXRhLnN0YXR1cy5jb2RlID09PSAwICYmIGFjckRhdGEubWV0YWRhdGE/Lm11c2ljKSB7XG4gICAgICAgICAgZm9yIChjb25zdCBtdXNpYyBvZiBhY3JEYXRhLm1ldGFkYXRhLm11c2ljKSB7XG4gICAgICAgICAgICBjb25zdCBhcnRpc3ROYW1lcyA9IG11c2ljLmFydGlzdHM/Lm1hcChhID0+IGEubmFtZSkuam9pbignLCAnKSB8fCAnVW5rbm93biBBcnRpc3QnO1xuICAgICAgICAgICAgYWNyY2xvdWRNYXRjaGVzLnB1c2goe1xuICAgICAgICAgICAgICB0aXRsZTogbXVzaWMudGl0bGUgfHwgJ1Vua25vd24gVGl0bGUnLFxuICAgICAgICAgICAgICBhcnRpc3Q6IGFydGlzdE5hbWVzLFxuICAgICAgICAgICAgICBzaW1pbGFyaXR5OiBtdXNpYy5zY29yZSxcbiAgICAgICAgICAgICAgc291cmNlOiAnQUNSQ2xvdWQnXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgYWNyY2xvdWRTdWNjZXNzID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIGlmIChhY3JEYXRhLnN0YXR1cy5jb2RlID09PSAxMDAxKSB7XG4gICAgICAgICAgLy8gTm8gcmVzdWx0IGZvdW5kIC0gdGhpcyBpcyBzdWNjZXNzLCBqdXN0IG5vIG1hdGNoZXNcbiAgICAgICAgICBhY3JjbG91ZFN1Y2Nlc3MgPSB0cnVlO1xuICAgICAgICAgIGNvbnNvbGUubG9nKGBbY2hlY2stcGxhZ2lhcmlzbV0gQUNSQ2xvdWQ6IE5vIG1hdGNoZXMgZm91bmQgKGNsZWFuKWApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGFjcmNsb3VkRXJyb3IgPSBhY3JEYXRhLnN0YXR1cy5tc2c7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGFjcmNsb3VkRXJyb3IgPSBgSFRUUCAke2FjclJlc3BvbnNlLnN0YXR1c31gO1xuICAgICAgfVxuXG4gICAgICBzdGVwc1sxXS5zdGF0dXMgPSAnZG9uZSc7XG4gICAgICBzdGVwc1sxXS5yZXN1bHQgPSB7XG4gICAgICAgIGZvdW5kOiBhY3JjbG91ZE1hdGNoZXMubGVuZ3RoID4gMCxcbiAgICAgICAgbWF0Y2hlczogYWNyY2xvdWRNYXRjaGVzXG4gICAgICB9O1xuXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYFtjaGVjay1wbGFnaWFyaXNtXSBBQ1JDbG91ZCBlcnJvcjpgLCBlcnJvcik7XG4gICAgICBzdGVwc1sxXS5zdGF0dXMgPSAnZXJyb3InO1xuICAgICAgYWNyY2xvdWRFcnJvciA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InO1xuICAgIH1cblxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLy8gU1RFUCAzOiBJbnRlcm5hbCBEYXRhYmFzZSBDaGVja1xuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgc3RlcHNbMl0uc3RhdHVzID0gJ2NoZWNraW5nJztcbiAgICBjb25zb2xlLmxvZyhgW2NoZWNrLXBsYWdpYXJpc21dIFN0ZXAgMzogSW50ZXJuYWwgZGF0YWJhc2UgY2hlY2tgKTtcblxuICAgIHRyeSB7XG4gICAgICAvLyBDaGVjayBhZ2FpbnN0IHRyYWNrcyBpbiBvdXIgb3duIGRhdGFiYXNlXG4gICAgICBjb25zdCB0cmFja1RpdGxlID0gdHJhY2tEYXRhPy50aXRsZT8udG9Mb3dlckNhc2UoKSB8fCAnJztcbiAgICAgIFxuICAgICAgaWYgKHRyYWNrVGl0bGUpIHtcbiAgICAgICAgY29uc3QgeyBkYXRhOiBzaW1pbGFyVHJhY2tzIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKCd0cmFja3MnKVxuICAgICAgICAgIC5zZWxlY3QoJ2lkLCB0aXRsZSwgdXNlcl9pZCwgcHJvZmlsZXM6dXNlcl9pZCh1c2VybmFtZSknKVxuICAgICAgICAgIC5uZXEoJ2lkJywgdHJhY2tJZClcbiAgICAgICAgICAubmVxKCd1c2VyX2lkJywgdXNlcklkKVxuICAgICAgICAgIC5pbGlrZSgndGl0bGUnLCBgJSR7dHJhY2tUaXRsZS5zbGljZSgwLCAyMCl9JWApXG4gICAgICAgICAgLmxpbWl0KDUpO1xuXG4gICAgICAgIGlmIChzaW1pbGFyVHJhY2tzICYmIHNpbWlsYXJUcmFja3MubGVuZ3RoID4gMCkge1xuICAgICAgICAgIGZvciAoY29uc3QgdHJhY2sgb2Ygc2ltaWxhclRyYWNrcykge1xuICAgICAgICAgICAgY29uc3Qgc2ltaWxhcml0eSA9IGNhbGN1bGF0ZVRpdGxlU2ltaWxhcml0eSh0cmFja1RpdGxlLCB0cmFjay50aXRsZT8udG9Mb3dlckNhc2UoKSB8fCAnJyk7XG4gICAgICAgICAgICBpZiAoc2ltaWxhcml0eSA+IDcwKSB7XG4gICAgICAgICAgICAgIGNvbnN0IHByb2ZpbGUgPSB0cmFjay5wcm9maWxlcyBhcyBhbnk7XG4gICAgICAgICAgICAgIGludGVybmFsTWF0Y2hlcy5wdXNoKHtcbiAgICAgICAgICAgICAgICB0aXRsZTogdHJhY2sudGl0bGUgfHwgJ1VudGl0bGVkJyxcbiAgICAgICAgICAgICAgICBhcnRpc3Q6IHByb2ZpbGU/LnVzZXJuYW1lIHx8ICdVbmtub3duJyxcbiAgICAgICAgICAgICAgICBzaW1pbGFyaXR5OiBzaW1pbGFyaXR5LFxuICAgICAgICAgICAgICAgIHNvdXJjZTogJ0FJIFBsYW5ldCBTb3VuZCdcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHN0ZXBzWzJdLnN0YXR1cyA9ICdkb25lJztcbiAgICAgIHN0ZXBzWzJdLnJlc3VsdCA9IHtcbiAgICAgICAgZm91bmQ6IGludGVybmFsTWF0Y2hlcy5sZW5ndGggPiAwLFxuICAgICAgICBtYXRjaGVzOiBpbnRlcm5hbE1hdGNoZXNcbiAgICAgIH07XG5cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihgW2NoZWNrLXBsYWdpYXJpc21dIEludGVybmFsIGNoZWNrIGVycm9yOmAsIGVycm9yKTtcbiAgICAgIHN0ZXBzWzJdLnN0YXR1cyA9ICdlcnJvcic7XG4gICAgfVxuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAvLyBDb21iaW5lIFJlc3VsdHNcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGNvbnN0IGFsbE1hdGNoZXMgPSBbLi4uYWNvdXN0aWRNYXRjaGVzLCAuLi5hY3JjbG91ZE1hdGNoZXMsIC4uLmludGVybmFsTWF0Y2hlc107XG4gICAgY29uc3QgaXNDbGVhbiA9IGFsbE1hdGNoZXMubGVuZ3RoID09PSAwO1xuICAgIGNvbnN0IHNjb3JlID0gaXNDbGVhbiA/IDEwMCA6IE1hdGgubWF4KDAsIDEwMCAtIE1hdGgubWF4KC4uLmFsbE1hdGNoZXMubWFwKG0gPT4gbS5zaW1pbGFyaXR5KSkpO1xuXG4gICAgY29uc29sZS5sb2coYFtjaGVjay1wbGFnaWFyaXNtXSBSZXN1bHQgZm9yICR7dHJhY2tJZH06IGlzQ2xlYW49JHtpc0NsZWFufSwgc2NvcmU9JHtzY29yZX0sIG1hdGNoZXM9JHthbGxNYXRjaGVzLmxlbmd0aH1gKTtcblxuICAgIC8vIFVwZGF0ZSB0cmFjayB3aXRoIHJlc3VsdFxuICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oJ3RyYWNrcycpXG4gICAgICAudXBkYXRlKHtcbiAgICAgICAgY29weXJpZ2h0X2NoZWNrX3N0YXR1czogaXNDbGVhbiA/ICdjbGVhbicgOiAnZmxhZ2dlZCcsXG4gICAgICAgIHBsYWdpYXJpc21fY2hlY2tfc3RhdHVzOiBpc0NsZWFuID8gJ2NsZWFuJyA6ICdmbGFnZ2VkJyxcbiAgICAgICAgcGxhZ2lhcmlzbV9jaGVja19yZXN1bHQ6IHsgXG4gICAgICAgICAgaXNDbGVhbiwgXG4gICAgICAgICAgc2NvcmUsIFxuICAgICAgICAgIG1hdGNoZXM6IGFsbE1hdGNoZXMsXG4gICAgICAgICAgc3RlcHM6IHN0ZXBzLm1hcChzID0+ICh7IFxuICAgICAgICAgICAgaWQ6IHMuaWQsIFxuICAgICAgICAgICAgbmFtZTogcy5uYW1lLCBcbiAgICAgICAgICAgIGRhdGFiYXNlOiBzLmRhdGFiYXNlLFxuICAgICAgICAgICAgc3RhdHVzOiBzLnN0YXR1cyxcbiAgICAgICAgICAgIG1hdGNoQ291bnQ6IHMucmVzdWx0Py5tYXRjaGVzPy5sZW5ndGggfHwgMFxuICAgICAgICAgIH0pKSxcbiAgICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICBhY291c3RpZEF2YWlsYWJsZTogYWNvdXN0aWRTdWNjZXNzLFxuICAgICAgICAgIGFjb3VzdGlkRXJyb3IsXG4gICAgICAgICAgYWNyY2xvdWRBdmFpbGFibGU6IGFjcmNsb3VkU3VjY2VzcyxcbiAgICAgICAgICBhY3JjbG91ZEVycm9yXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICAuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1tjaGVjay1wbGFnaWFyaXNtXSBVcGRhdGUgZXJyb3I6JywgdXBkYXRlRXJyb3IpO1xuICAgICAgdGhyb3cgdXBkYXRlRXJyb3I7XG4gICAgfVxuXG4gICAgLy8gTG9nIGNvbXBsZXRpb25cbiAgICBpZiAodXNlcklkKSB7XG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdkaXN0cmlidXRpb25fbG9ncycpLmluc2VydCh7XG4gICAgICAgIHRyYWNrX2lkOiB0cmFja0lkLFxuICAgICAgICB1c2VyX2lkOiB1c2VySWQsXG4gICAgICAgIGFjdGlvbjogaXNDbGVhbiA/ICdwbGFnaWFyaXNtX2NoZWNrX2NsZWFuJyA6ICdwbGFnaWFyaXNtX2NoZWNrX2ZsYWdnZWQnLFxuICAgICAgICBzdGFnZTogJ3VwbG9hZCcsXG4gICAgICAgIGRldGFpbHM6IHsgaXNDbGVhbiwgc2NvcmUsIG1hdGNoQ291bnQ6IGFsbE1hdGNoZXMubGVuZ3RoLCBzdGVwczogc3RlcHMubWFwKHMgPT4gcy5pZCkgfVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gUmV0dXJuIGRldGFpbGVkIHJlc3VsdCB3aXRoIHByb2Nlc3NlZCBzdGVwcyAoc2FtZSBmb3JtYXQgYXMgc2F2ZWQgdG8gREIpXG4gICAgY29uc3QgcHJvY2Vzc2VkU3RlcHMgPSBzdGVwcy5tYXAocyA9PiAoeyBcbiAgICAgIGlkOiBzLmlkLCBcbiAgICAgIG5hbWU6IHMubmFtZSwgXG4gICAgICBkYXRhYmFzZTogcy5kYXRhYmFzZSxcbiAgICAgIHN0YXR1czogcy5zdGF0dXMsXG4gICAgICBtYXRjaENvdW50OiBzLnJlc3VsdD8ubWF0Y2hlcz8ubGVuZ3RoIHx8IDBcbiAgICB9KSk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIGlzQ2xlYW4sXG4gICAgICAgIHNjb3JlLFxuICAgICAgICBtYXRjaGVzOiBhbGxNYXRjaGVzLFxuICAgICAgICBzdGVwczogcHJvY2Vzc2VkU3RlcHMsXG4gICAgICAgIG1lc3NhZ2U6IGlzQ2xlYW4gPyAn0KLRgNC10Log0L/RgNC+0YjRkdC7INC/0YDQvtCy0LXRgNC60YMnIDogJ9Ce0LHQvdCw0YDRg9C20LXQvdGLINGB0L7QstC/0LDQtNC10L3QuNGPJ1xuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tjaGVjay1wbGFnaWFyaXNtXSBFcnJvcjonLCBlcnJvcik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcbiAgfVxufSk7XG5cbi8vIFNpbXBsZSB0aXRsZSBzaW1pbGFyaXR5IHVzaW5nIExldmVuc2h0ZWluIGRpc3RhbmNlXG5mdW5jdGlvbiBjYWxjdWxhdGVUaXRsZVNpbWlsYXJpdHkodGl0bGUxOiBzdHJpbmcsIHRpdGxlMjogc3RyaW5nKTogbnVtYmVyIHtcbiAgY29uc3QgbGVuMSA9IHRpdGxlMS5sZW5ndGg7XG4gIGNvbnN0IGxlbjIgPSB0aXRsZTIubGVuZ3RoO1xuICBcbiAgaWYgKGxlbjEgPT09IDApIHJldHVybiBsZW4yID09PSAwID8gMTAwIDogMDtcbiAgaWYgKGxlbjIgPT09IDApIHJldHVybiAwO1xuICBcbiAgY29uc3QgbWF0cml4OiBudW1iZXJbXVtdID0gW107XG4gIFxuICBmb3IgKGxldCBpID0gMDsgaSA8PSBsZW4xOyBpKyspIHtcbiAgICBtYXRyaXhbaV0gPSBbaV07XG4gIH1cbiAgZm9yIChsZXQgaiA9IDA7IGogPD0gbGVuMjsgaisrKSB7XG4gICAgbWF0cml4WzBdW2pdID0gajtcbiAgfVxuICBcbiAgZm9yIChsZXQgaSA9IDE7IGkgPD0gbGVuMTsgaSsrKSB7XG4gICAgZm9yIChsZXQgaiA9IDE7IGogPD0gbGVuMjsgaisrKSB7XG4gICAgICBjb25zdCBjb3N0ID0gdGl0bGUxW2kgLSAxXSA9PT0gdGl0bGUyW2ogLSAxXSA/IDAgOiAxO1xuICAgICAgbWF0cml4W2ldW2pdID0gTWF0aC5taW4oXG4gICAgICAgIG1hdHJpeFtpIC0gMV1bal0gKyAxLFxuICAgICAgICBtYXRyaXhbaV1baiAtIDFdICsgMSxcbiAgICAgICAgbWF0cml4W2kgLSAxXVtqIC0gMV0gKyBjb3N0XG4gICAgICApO1xuICAgIH1cbiAgfVxuICBcbiAgY29uc3QgZGlzdGFuY2UgPSBtYXRyaXhbbGVuMV1bbGVuMl07XG4gIGNvbnN0IG1heExlbiA9IE1hdGgubWF4KGxlbjEsIGxlbjIpO1xuICByZXR1cm4gTWF0aC5yb3VuZCgoMSAtIGRpc3RhbmNlIC8gbWF4TGVuKSAqIDEwMCk7XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxRQUFRLENBQUM7RUFBb0IsV0FBbUIsaUJBQWlCLEdBQUc7QUFBUztBQUNuRixTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUF3REEsNENBQTRDO0FBQzVDLGVBQWUsMEJBQ2IsU0FBaUIsRUFDakIsWUFBb0IsRUFDcEIsU0FBaUIsRUFDakIsZ0JBQXdCLEVBQ3hCLFFBQWdCO0VBRWhCLE1BQU0sZUFBZSxDQUFDLG9CQUFvQixFQUFFLFVBQVUsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLGlCQUFpQixFQUFFLEVBQUUsVUFBVSxDQUFDO0VBQ3ZHLE1BQU0sVUFBVSxJQUFJO0VBQ3BCLE1BQU0sTUFBTSxNQUFNLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FDdkMsT0FDQSxRQUFRLE1BQU0sQ0FBQyxlQUNmO0lBQUUsTUFBTTtJQUFRLE1BQU07RUFBUSxHQUM5QixPQUNBO0lBQUM7R0FBTztFQUVWLE1BQU0sWUFBWSxNQUFNLE9BQU8sTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEtBQUssUUFBUSxNQUFNLENBQUM7RUFDdkUsT0FBTyxLQUFLLE9BQU8sWUFBWSxJQUFJLElBQUksV0FBVztBQUNwRDtBQUVBLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sV0FBVyxhQUNmLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFDaEMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdDQUFnQztJQUcvQyxNQUFNLG1CQUFtQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDdEMsTUFBTSxpQkFBaUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ3BDLE1BQU0sb0JBQW9CLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN2QyxNQUFNLGdCQUFnQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbkMsTUFBTSxzQkFBc0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ3pDLE1BQU0seUJBQXlCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUU1QyxNQUFNLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxHQUFzQixNQUFNLElBQUksSUFBSTtJQUMvRCxRQUFRLEdBQUcsQ0FBQyxDQUFDLDZDQUE2QyxFQUFFLFFBQVEsQ0FBQztJQUVyRSxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVU7TUFDekIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxpQkFBaUI7SUFDakIsTUFBTSxFQUFFLE1BQU0sU0FBUyxFQUFFLEdBQUcsTUFBTSxTQUMvQixJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsa0JBQ1AsRUFBRSxDQUFDLE1BQU0sU0FDVCxNQUFNO0lBRVQsTUFBTSxTQUFTLFdBQVc7SUFFMUIseUJBQXlCO0lBQ3pCLE1BQU0sUUFBcUI7TUFDekI7UUFBRSxJQUFJO1FBQVksTUFBTTtRQUF3QixVQUFVO1FBQTZCLFFBQVE7TUFBVTtNQUN6RztRQUFFLElBQUk7UUFBWSxNQUFNO1FBQVksVUFBVTtRQUFrQyxRQUFRO01BQVU7TUFDbEc7UUFBRSxJQUFJO1FBQVksTUFBTTtRQUFtQixVQUFVO1FBQW1CLFFBQVE7TUFBVTtLQUMzRjtJQUVELHNCQUFzQjtJQUN0QixNQUFNLFNBQ0gsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO01BQ04sd0JBQXdCO01BQ3hCLHlCQUF5QjtJQUMzQixHQUNDLEVBQUUsQ0FBQyxNQUFNO0lBRVosWUFBWTtJQUNaLElBQUksUUFBUTtNQUNWLE1BQU0sU0FBUyxJQUFJLENBQUMscUJBQXFCLE1BQU0sQ0FBQztRQUM5QyxVQUFVO1FBQ1YsU0FBUztRQUNULFFBQVE7UUFDUixPQUFPO1FBQ1AsU0FBUztVQUFFLFdBQVc7VUFBVSxPQUFPLE1BQU0sR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLEVBQUU7UUFBRTtNQUM5RDtJQUNGO0lBRUEsSUFBSSxrQkFBZ0csRUFBRTtJQUN0RyxJQUFJLGtCQUFnRyxFQUFFO0lBQ3RHLElBQUksa0JBQWdHLEVBQUU7SUFDdEcsSUFBSSxrQkFBa0I7SUFDdEIsSUFBSSxnQkFBK0I7SUFDbkMsSUFBSSxrQkFBa0I7SUFDdEIsSUFBSSxnQkFBK0I7SUFFbkMsK0NBQStDO0lBQy9DLHlCQUF5QjtJQUN6QiwrQ0FBK0M7SUFDL0MsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEdBQUc7SUFDbEIsUUFBUSxHQUFHLENBQUMsQ0FBQyxzREFBc0QsQ0FBQztJQUVwRSxJQUFJO01BQ0YsSUFBSSxDQUFDLGtCQUFrQjtRQUNyQixNQUFNLElBQUksTUFBTTtNQUNsQjtNQUVBLGlEQUFpRDtNQUNqRCxJQUFJLGNBQTZCO01BQ2pDLElBQUksV0FBMEI7TUFFOUIsSUFBSSxrQkFBa0IsbUJBQW1CO1FBQ3ZDLFFBQVEsR0FBRyxDQUFDLENBQUMsd0RBQXdELENBQUM7UUFFdEUsTUFBTSxhQUFhLE1BQU0sTUFBTSxDQUFDLEVBQUUsZUFBZSxZQUFZLENBQUMsRUFBRTtVQUM5RCxRQUFRO1VBQ1IsU0FBUztZQUNQLGdCQUFnQjtZQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsa0JBQWtCLENBQUM7VUFDaEQ7VUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO1lBQUU7VUFBUztRQUNsQztRQUVBLElBQUksV0FBVyxFQUFFLEVBQUU7VUFDakIsTUFBTSxTQUFTLE1BQU0sV0FBVyxJQUFJO1VBQ3BDLGNBQWMsT0FBTyxXQUFXO1VBQ2hDLFdBQVcsT0FBTyxRQUFRO1VBQzFCLFFBQVEsR0FBRyxDQUFDLENBQUMsb0RBQW9ELEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDaEYsT0FBTztVQUNMLFFBQVEsSUFBSSxDQUFDLENBQUMsOENBQThDLEVBQUUsV0FBVyxNQUFNLENBQUMsQ0FBQztRQUNuRjtNQUNGO01BRUEseUNBQXlDO01BQ3pDLElBQUksZUFBZSxVQUFVO1FBQzNCLE1BQU0sY0FBYyxJQUFJLElBQUk7UUFDNUIsWUFBWSxZQUFZLENBQUMsR0FBRyxDQUFDLFVBQVU7UUFDdkMsWUFBWSxZQUFZLENBQUMsR0FBRyxDQUFDLFlBQVksT0FBTyxLQUFLLEtBQUssQ0FBQztRQUMzRCxZQUFZLFlBQVksQ0FBQyxHQUFHLENBQUMsZUFBZTtRQUM1QyxZQUFZLFlBQVksQ0FBQyxHQUFHLENBQUMsUUFBUTtRQUVyQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLDJDQUEyQyxDQUFDO1FBQ3pELE1BQU0sbUJBQW1CLE1BQU0sTUFBTSxZQUFZLFFBQVE7UUFFekQsSUFBSSxpQkFBaUIsRUFBRSxFQUFFO1VBQ3ZCLE1BQU0sZUFBK0IsTUFBTSxpQkFBaUIsSUFBSTtVQUNoRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLHFDQUFxQyxDQUFDLEVBQUUsS0FBSyxTQUFTLENBQUMsY0FBYyxLQUFLLENBQUMsR0FBRztVQUUzRixJQUFJLGFBQWEsTUFBTSxLQUFLLFFBQVEsYUFBYSxPQUFPLEVBQUU7WUFDeEQsS0FBSyxNQUFNLFVBQVUsYUFBYSxPQUFPLENBQUU7Y0FDekMsMERBQTBEO2NBQzFELElBQUksT0FBTyxLQUFLLElBQUksT0FBTyxPQUFPLFVBQVUsRUFBRTtnQkFDNUMsS0FBSyxNQUFNLGFBQWEsT0FBTyxVQUFVLENBQUU7a0JBQ3pDLE1BQU0sY0FBYyxVQUFVLE9BQU8sRUFBRSxJQUFJLENBQUEsSUFBSyxFQUFFLElBQUksRUFBRSxLQUFLLFNBQVM7a0JBQ3RFLGdCQUFnQixJQUFJLENBQUM7b0JBQ25CLE9BQU8sVUFBVSxLQUFLLElBQUk7b0JBQzFCLFFBQVE7b0JBQ1IsWUFBWSxLQUFLLEtBQUssQ0FBQyxPQUFPLEtBQUssR0FBRztvQkFDdEMsUUFBUTtrQkFDVjtnQkFDRjtjQUNGO1lBQ0Y7VUFDRjtVQUNBLGtCQUFrQjtRQUNwQjtNQUNGLE9BQU87UUFDTCw0REFBNEQ7UUFDNUQsNERBQTREO1FBQzVELFFBQVEsR0FBRyxDQUFDLENBQUMsOERBQThELENBQUM7UUFDNUUsZ0JBQWdCO01BQ2xCO01BRUEsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEdBQUc7TUFDbEIsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEdBQUc7UUFDaEIsT0FBTyxnQkFBZ0IsTUFBTSxHQUFHO1FBQ2hDLFNBQVM7TUFDWDtJQUVGLEVBQUUsT0FBTyxPQUFPO01BQ2QsUUFBUSxLQUFLLENBQUMsQ0FBQyxrQ0FBa0MsQ0FBQyxFQUFFO01BQ3BELEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxHQUFHO01BQ2xCLGdCQUFnQixpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUMzRDtJQUVBLCtDQUErQztJQUMvQyx5QkFBeUI7SUFDekIsK0NBQStDO0lBQy9DLEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxHQUFHO0lBQ2xCLFFBQVEsR0FBRyxDQUFDLENBQUMsa0RBQWtELENBQUM7SUFFaEUsSUFBSTtNQUNGLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyx1QkFBdUIsQ0FBQyx3QkFBd0I7UUFDckUsTUFBTSxJQUFJLE1BQU07TUFDbEI7TUFFQSxtQ0FBbUM7TUFDbkMsUUFBUSxHQUFHLENBQUMsQ0FBQyxvREFBb0QsQ0FBQztNQUNsRSxNQUFNLGdCQUFnQixNQUFNLE1BQU07TUFDbEMsSUFBSSxDQUFDLGNBQWMsRUFBRSxFQUFFO1FBQ3JCLE1BQU0sSUFBSSxNQUFNLENBQUMsMEJBQTBCLEVBQUUsY0FBYyxNQUFNLENBQUMsQ0FBQztNQUNyRTtNQUNBLE1BQU0sY0FBYyxNQUFNLGNBQWMsV0FBVztNQUNuRCxNQUFNLGFBQWEsSUFBSSxXQUFXO01BRWxDLHVEQUF1RDtNQUN2RCx1REFBdUQ7TUFDdkQsTUFBTSxhQUFhLEtBQUssR0FBRyxDQUFDLFdBQVcsTUFBTSxFQUFFLE9BQU8sT0FBTyxpQkFBaUI7TUFDOUUsTUFBTSxjQUFjLFdBQVcsS0FBSyxDQUFDLEdBQUc7TUFFeEMscUJBQXFCO01BQ3JCLE1BQU0sWUFBWSxLQUFLLEtBQUssQ0FBQyxLQUFLLEdBQUcsS0FBSztNQUMxQyxNQUFNLFdBQVc7TUFDakIsTUFBTSxtQkFBbUI7TUFDekIsTUFBTSxZQUFZLE1BQU0sMEJBQ3RCLHFCQUNBLHdCQUNBLFdBQ0Esa0JBQ0E7TUFHRixvQkFBb0I7TUFDcEIsTUFBTSxXQUFXLElBQUk7TUFDckIsU0FBUyxNQUFNLENBQUMsVUFBVSxJQUFJLEtBQUs7UUFBQztPQUFZLEdBQUc7TUFDbkQsU0FBUyxNQUFNLENBQUMsZ0JBQWdCLE9BQU8sWUFBWSxNQUFNO01BQ3pELFNBQVMsTUFBTSxDQUFDLGNBQWM7TUFDOUIsU0FBUyxNQUFNLENBQUMsYUFBYTtNQUM3QixTQUFTLE1BQU0sQ0FBQyxhQUFhO01BQzdCLFNBQVMsTUFBTSxDQUFDLHFCQUFxQjtNQUNyQyxTQUFTLE1BQU0sQ0FBQyxhQUFhLE9BQU87TUFFcEMsUUFBUSxHQUFHLENBQUMsQ0FBQyx5Q0FBeUMsQ0FBQztNQUN2RCxNQUFNLGNBQWMsTUFBTSxNQUFNLENBQUMsUUFBUSxFQUFFLGNBQWMsWUFBWSxDQUFDLEVBQUU7UUFDdEUsUUFBUTtRQUNSLE1BQU07TUFDUjtNQUVBLElBQUksWUFBWSxFQUFFLEVBQUU7UUFDbEIsTUFBTSxVQUEwQixNQUFNLFlBQVksSUFBSTtRQUN0RCxRQUFRLEdBQUcsQ0FBQyxDQUFDLDJDQUEyQyxFQUFFLFFBQVEsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRS9FLElBQUksUUFBUSxNQUFNLENBQUMsSUFBSSxLQUFLLEtBQUssUUFBUSxRQUFRLEVBQUUsT0FBTztVQUN4RCxLQUFLLE1BQU0sU0FBUyxRQUFRLFFBQVEsQ0FBQyxLQUFLLENBQUU7WUFDMUMsTUFBTSxjQUFjLE1BQU0sT0FBTyxFQUFFLElBQUksQ0FBQSxJQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssU0FBUztZQUNsRSxnQkFBZ0IsSUFBSSxDQUFDO2NBQ25CLE9BQU8sTUFBTSxLQUFLLElBQUk7Y0FDdEIsUUFBUTtjQUNSLFlBQVksTUFBTSxLQUFLO2NBQ3ZCLFFBQVE7WUFDVjtVQUNGO1VBQ0Esa0JBQWtCO1FBQ3BCLE9BQU8sSUFBSSxRQUFRLE1BQU0sQ0FBQyxJQUFJLEtBQUssTUFBTTtVQUN2QyxxREFBcUQ7VUFDckQsa0JBQWtCO1VBQ2xCLFFBQVEsR0FBRyxDQUFDLENBQUMscURBQXFELENBQUM7UUFDckUsT0FBTztVQUNMLGdCQUFnQixRQUFRLE1BQU0sQ0FBQyxHQUFHO1FBQ3BDO01BQ0YsT0FBTztRQUNMLGdCQUFnQixDQUFDLEtBQUssRUFBRSxZQUFZLE1BQU0sQ0FBQyxDQUFDO01BQzlDO01BRUEsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEdBQUc7TUFDbEIsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEdBQUc7UUFDaEIsT0FBTyxnQkFBZ0IsTUFBTSxHQUFHO1FBQ2hDLFNBQVM7TUFDWDtJQUVGLEVBQUUsT0FBTyxPQUFPO01BQ2QsUUFBUSxLQUFLLENBQUMsQ0FBQyxrQ0FBa0MsQ0FBQyxFQUFFO01BQ3BELEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxHQUFHO01BQ2xCLGdCQUFnQixpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUMzRDtJQUVBLCtDQUErQztJQUMvQyxrQ0FBa0M7SUFDbEMsK0NBQStDO0lBQy9DLEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxHQUFHO0lBQ2xCLFFBQVEsR0FBRyxDQUFDLENBQUMsa0RBQWtELENBQUM7SUFFaEUsSUFBSTtNQUNGLDJDQUEyQztNQUMzQyxNQUFNLGFBQWEsV0FBVyxPQUFPLGlCQUFpQjtNQUV0RCxJQUFJLFlBQVk7UUFDZCxNQUFNLEVBQUUsTUFBTSxhQUFhLEVBQUUsR0FBRyxNQUFNLFNBQ25DLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxrREFDUCxHQUFHLENBQUMsTUFBTSxTQUNWLEdBQUcsQ0FBQyxXQUFXLFFBQ2YsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsV0FBVyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxFQUM3QyxLQUFLLENBQUM7UUFFVCxJQUFJLGlCQUFpQixjQUFjLE1BQU0sR0FBRyxHQUFHO1VBQzdDLEtBQUssTUFBTSxTQUFTLGNBQWU7WUFDakMsTUFBTSxhQUFhLHlCQUF5QixZQUFZLE1BQU0sS0FBSyxFQUFFLGlCQUFpQjtZQUN0RixJQUFJLGFBQWEsSUFBSTtjQUNuQixNQUFNLFVBQVUsTUFBTSxRQUFRO2NBQzlCLGdCQUFnQixJQUFJLENBQUM7Z0JBQ25CLE9BQU8sTUFBTSxLQUFLLElBQUk7Z0JBQ3RCLFFBQVEsU0FBUyxZQUFZO2dCQUM3QixZQUFZO2dCQUNaLFFBQVE7Y0FDVjtZQUNGO1VBQ0Y7UUFDRjtNQUNGO01BRUEsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEdBQUc7TUFDbEIsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEdBQUc7UUFDaEIsT0FBTyxnQkFBZ0IsTUFBTSxHQUFHO1FBQ2hDLFNBQVM7TUFDWDtJQUVGLEVBQUUsT0FBTyxPQUFPO01BQ2QsUUFBUSxLQUFLLENBQUMsQ0FBQyx3Q0FBd0MsQ0FBQyxFQUFFO01BQzFELEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxHQUFHO0lBQ3BCO0lBRUEsK0NBQStDO0lBQy9DLGtCQUFrQjtJQUNsQiwrQ0FBK0M7SUFDL0MsTUFBTSxhQUFhO1NBQUk7U0FBb0I7U0FBb0I7S0FBZ0I7SUFDL0UsTUFBTSxVQUFVLFdBQVcsTUFBTSxLQUFLO0lBQ3RDLE1BQU0sUUFBUSxVQUFVLE1BQU0sS0FBSyxHQUFHLENBQUMsR0FBRyxNQUFNLEtBQUssR0FBRyxJQUFJLFdBQVcsR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLFVBQVU7SUFFNUYsUUFBUSxHQUFHLENBQUMsQ0FBQyw4QkFBOEIsRUFBRSxRQUFRLFVBQVUsRUFBRSxRQUFRLFFBQVEsRUFBRSxNQUFNLFVBQVUsRUFBRSxXQUFXLE1BQU0sQ0FBQyxDQUFDO0lBRXhILDJCQUEyQjtJQUMzQixNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLFNBQ2xDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztNQUNOLHdCQUF3QixVQUFVLFVBQVU7TUFDNUMseUJBQXlCLFVBQVUsVUFBVTtNQUM3Qyx5QkFBeUI7UUFDdkI7UUFDQTtRQUNBLFNBQVM7UUFDVCxPQUFPLE1BQU0sR0FBRyxDQUFDLENBQUEsSUFBSyxDQUFDO1lBQ3JCLElBQUksRUFBRSxFQUFFO1lBQ1IsTUFBTSxFQUFFLElBQUk7WUFDWixVQUFVLEVBQUUsUUFBUTtZQUNwQixRQUFRLEVBQUUsTUFBTTtZQUNoQixZQUFZLEVBQUUsTUFBTSxFQUFFLFNBQVMsVUFBVTtVQUMzQyxDQUFDO1FBQ0QsV0FBVyxJQUFJLE9BQU8sV0FBVztRQUNqQyxtQkFBbUI7UUFDbkI7UUFDQSxtQkFBbUI7UUFDbkI7TUFDRjtJQUNGLEdBQ0MsRUFBRSxDQUFDLE1BQU07SUFFWixJQUFJLGFBQWE7TUFDZixRQUFRLEtBQUssQ0FBQyxvQ0FBb0M7TUFDbEQsTUFBTTtJQUNSO0lBRUEsaUJBQWlCO0lBQ2pCLElBQUksUUFBUTtNQUNWLE1BQU0sU0FBUyxJQUFJLENBQUMscUJBQXFCLE1BQU0sQ0FBQztRQUM5QyxVQUFVO1FBQ1YsU0FBUztRQUNULFFBQVEsVUFBVSwyQkFBMkI7UUFDN0MsT0FBTztRQUNQLFNBQVM7VUFBRTtVQUFTO1VBQU8sWUFBWSxXQUFXLE1BQU07VUFBRSxPQUFPLE1BQU0sR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLEVBQUU7UUFBRTtNQUN4RjtJQUNGO0lBRUEsMkVBQTJFO0lBQzNFLE1BQU0saUJBQWlCLE1BQU0sR0FBRyxDQUFDLENBQUEsSUFBSyxDQUFDO1FBQ3JDLElBQUksRUFBRSxFQUFFO1FBQ1IsTUFBTSxFQUFFLElBQUk7UUFDWixVQUFVLEVBQUUsUUFBUTtRQUNwQixRQUFRLEVBQUUsTUFBTTtRQUNoQixZQUFZLEVBQUUsTUFBTSxFQUFFLFNBQVMsVUFBVTtNQUMzQyxDQUFDO0lBRUQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1Q7TUFDQTtNQUNBLFNBQVM7TUFDVCxPQUFPO01BQ1AsU0FBUyxVQUFVLHlCQUF5QjtJQUM5QyxJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsNkJBQTZCO0lBQzNDLE1BQU0sVUFBVSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUN6RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLFNBQVM7TUFBTyxPQUFPO0lBQVEsSUFDaEQ7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0Y7QUFFQSxxREFBcUQ7QUFDckQsU0FBUyx5QkFBeUIsTUFBYyxFQUFFLE1BQWM7RUFDOUQsTUFBTSxPQUFPLE9BQU8sTUFBTTtFQUMxQixNQUFNLE9BQU8sT0FBTyxNQUFNO0VBRTFCLElBQUksU0FBUyxHQUFHLE9BQU8sU0FBUyxJQUFJLE1BQU07RUFDMUMsSUFBSSxTQUFTLEdBQUcsT0FBTztFQUV2QixNQUFNLFNBQXFCLEVBQUU7RUFFN0IsSUFBSyxJQUFJLElBQUksR0FBRyxLQUFLLE1BQU0sSUFBSztJQUM5QixNQUFNLENBQUMsRUFBRSxHQUFHO01BQUM7S0FBRTtFQUNqQjtFQUNBLElBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxNQUFNLElBQUs7SUFDOUIsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUc7RUFDakI7RUFFQSxJQUFLLElBQUksSUFBSSxHQUFHLEtBQUssTUFBTSxJQUFLO0lBQzlCLElBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxNQUFNLElBQUs7TUFDOUIsTUFBTSxPQUFPLE1BQU0sQ0FBQyxJQUFJLEVBQUUsS0FBSyxNQUFNLENBQUMsSUFBSSxFQUFFLEdBQUcsSUFBSTtNQUNuRCxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxLQUFLLEdBQUcsQ0FDckIsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsR0FBRyxHQUNuQixNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxHQUFHLEdBQ25CLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLEVBQUUsR0FBRztJQUUzQjtFQUNGO0VBRUEsTUFBTSxXQUFXLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSztFQUNuQyxNQUFNLFNBQVMsS0FBSyxHQUFHLENBQUMsTUFBTTtFQUM5QixPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsSUFBSSxXQUFXLE1BQU0sSUFBSTtBQUM5QyJ9
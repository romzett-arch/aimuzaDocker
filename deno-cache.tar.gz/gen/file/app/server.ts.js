/**
 * Deno HTTP Server — хостит все Supabase Edge Functions как HTTP endpoints
 * 
 * Supabase Edge Functions используют serve() из deno/std, который внутри
 * вызывает Deno.listen() + Deno.serveHttp(). Мы перехватываем оба,
 * чтобы захватить обработчик и не стартовать отдельный сервер для каждой функции.
 */ const PORT = parseInt(Deno.env.get("DENO_PORT") || "8081");
const FUNCTIONS_DIR = "./functions";
// ─── Polyfill: auth.getClaims() ─────────────────────────────────────
// Множество Deno-функций используют supabaseClient.auth.getClaims(token),
// но этот метод НЕ существует в @supabase/supabase-js@2.
// Добавляем его как клиентский JWT-декодер (проверка уже на стороне API-сервера).
try {
  const { createClient } = await import("https://esm.sh/@supabase/supabase-js@2");
  const _tmpClient = createClient("http://localhost:9999", "polyfill-key");
  const authProto = Object.getPrototypeOf(_tmpClient.auth);
  if (authProto && typeof authProto.getClaims !== 'function') {
    authProto.getClaims = async function(_token) {
      try {
        // Если передан токен — декодируем его; иначе пробуем getUser()
        const token = _token || this._getSessionToken?.();
        if (!token || typeof token !== 'string') {
          return {
            data: null,
            error: new Error("No token provided")
          };
        }
        // Декодируем JWT payload (base64url → JSON)
        const parts = token.split('.');
        if (parts.length !== 3) {
          return {
            data: null,
            error: new Error("Invalid token format")
          };
        }
        const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
        const jsonStr = atob(base64);
        const payload = JSON.parse(jsonStr);
        return {
          data: {
            claims: payload
          },
          error: null
        };
      } catch (err) {
        return {
          data: null,
          error: err
        };
      }
    };
    console.log("[Deno] Polyfill: auth.getClaims() installed");
  }
} catch (e) {
  console.warn("[Deno] Polyfill getClaims failed:", e);
}
// Хранилище обработчиков
const handlers = new Map();
// Текущее имя функции при загрузке
let _currentLoadingName = null;
// ─── Перехватываем Deno.serve ──────────────────────────────────────
const _originalServe = Deno.serve;
// @ts-ignore: override  
Deno.serve = function(optionsOrHandler, maybeHandler) {
  let handler;
  if (typeof optionsOrHandler === 'function') {
    handler = optionsOrHandler;
  } else if (typeof maybeHandler === 'function') {
    handler = maybeHandler;
  } else if (optionsOrHandler && typeof optionsOrHandler.handler === 'function') {
    handler = optionsOrHandler.handler;
  }
  if (handler && _currentLoadingName) {
    handlers.set(_currentLoadingName, handler);
  }
  // Mock Deno.Server object
  return {
    finished: Promise.resolve(),
    ref: ()=>{},
    unref: ()=>{},
    shutdown: ()=>Promise.resolve(),
    addr: {
      transport: "tcp",
      hostname: "0.0.0.0",
      port: 0
    }
  };
};
// ─── Перехватываем Deno.listen (для старой serve() из deno/std) ────
const _originalListen = Deno.listen;
// @ts-ignore: override
Deno.listen = function(options) {
  if (_currentLoadingName) {
    // Не запускаем реальный listener — возвращаем mock
    return {
      addr: {
        transport: "tcp",
        hostname: options?.hostname || "0.0.0.0",
        port: options?.port || 0
      },
      rid: -1,
      close: ()=>{},
      [Symbol.asyncIterator]: async function*() {},
      ref: ()=>{},
      unref: ()=>{},
      accept: ()=>new Promise(()=>{})
    };
  }
  return _originalListen.call(Deno, options);
};
// ─── Перехватываем Deno.serveHttp (для старой serve()) ─────────────
const _originalServeHttp = Deno.serveHttp;
// @ts-ignore: override
Deno.serveHttp = function(conn) {
  if (_currentLoadingName) {
    // Mock httpConn
    return {
      rid: -1,
      close: ()=>{},
      nextRequest: ()=>Promise.resolve(null),
      [Symbol.asyncIterator]: async function*() {}
    };
  }
  return _originalServeHttp?.call(Deno, conn);
};
// ─── Загрузка функций ──────────────────────────────────────────────
async function loadFunctions() {
  for await (const entry of Deno.readDir(FUNCTIONS_DIR)){
    if (!entry.isDirectory) continue;
    const indexPath = `${FUNCTIONS_DIR}/${entry.name}/index.ts`;
    try {
      await Deno.stat(indexPath);
    } catch  {
      continue; // нет index.ts
    }
    _currentLoadingName = entry.name;
    try {
      const mod = await import(`./${indexPath}`);
      // Если handler не захвачен через serve/Deno.serve, проверяем default export
      if (!handlers.has(entry.name) && typeof mod.default === 'function') {
        handlers.set(entry.name, mod.default);
      }
    // Если всё ещё нет — попробуем обработать serve() вызов
    // serve() из deno/std передаёт handler в первый аргумент
    // Наш перехват Deno.listen + mock уже должен был предотвратить краш
    } catch (err) {
      // Логируем но не крашимся
      const msg = err instanceof Error ? err.message : String(err);
      // Игнорируем ошибки адреса (уже обработаны моком)
      if (!msg.includes('AddrInUse') && !msg.includes('Address already')) {
        console.error(`[Deno] Error loading ${entry.name}: ${msg}`);
      }
    }
    _currentLoadingName = null;
    if (handlers.has(entry.name)) {
      console.log(`[Deno] Loaded: ${entry.name}`);
    }
  }
}
// Перехватываем serve из deno/std — она экспортируется как именованная функция
// и принимает handler как первый аргумент. Но мы не можем перехватить импорт.
// Вместо этого мы перехватываем Deno.listen + Deno.serveHttp
// и для serve()-based функций вручную парсим их handler из исходника.
/**
 * Fallback: для функций которые используют serve() из deno/std
 * и не были захвачены — создаём обработчик который парсит запрос 
 * и проксирует его
 */ async function loadServeBasedFunctions() {
  for await (const entry of Deno.readDir(FUNCTIONS_DIR)){
    if (!entry.isDirectory || handlers.has(entry.name)) continue;
    const indexPath = `${FUNCTIONS_DIR}/${entry.name}/index.ts`;
    try {
      const code = await Deno.readTextFile(indexPath);
      // Проверяем есть ли serve(async (req) => { ... }) паттерн
      if (code.includes('serve(async') || code.includes('serve(function')) {
        // Извлекаем handler из serve() вызова
        // Для этого динамически создаём модифицированный код
        const modifiedCode = code// Заменяем import serve на наш стаб
        .replace(/import\s*\{\s*serve\s*\}\s*from\s*"https:\/\/deno\.land\/std[^"]*\/http\/server\.ts"/g, `const serve = (handler: any) => { (globalThis as any).__capturedHandler = handler; }`);
        // Создаём temp файл с модифицированным кодом
        const tmpPath = `/tmp/_fn_${entry.name}.ts`;
        await Deno.writeTextFile(tmpPath, modifiedCode);
        try {
          globalThis.__capturedHandler = null;
          await import(tmpPath);
          const captured = globalThis.__capturedHandler;
          if (typeof captured === 'function') {
            handlers.set(entry.name, captured);
            console.log(`[Deno] Loaded (serve-compat): ${entry.name}`);
          }
        } catch (loadErr) {
          // Не критично — функция может требовать специфичные зависимости
          const msg = loadErr instanceof Error ? loadErr.message : String(loadErr);
          if (!msg.includes('AddrInUse') && !msg.includes('already')) {
            console.warn(`[Deno] Skipped ${entry.name}: ${msg.substring(0, 80)}`);
          }
        }
      }
    } catch  {
    // Файл не найден или ошибка чтения
    }
  }
}
await loadFunctions();
await loadServeBasedFunctions();
console.log(`[Deno] ${handlers.size} functions ready`);
// ─── Запускаем единый HTTP-сервер ──────────────────────────────────
_originalServe.call(Deno, {
  port: PORT,
  hostname: "0.0.0.0"
}, async (req)=>{
  const url = new URL(req.url);
  const pathParts = url.pathname.split('/').filter(Boolean);
  const functionName = pathParts[0];
  // Health check
  if (functionName === 'health' || !functionName) {
    return new Response(JSON.stringify({
      status: 'ok',
      functions: handlers.size,
      loaded: [
        ...handlers.keys()
      ]
    }), {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  // CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Authorization, Content-Type, apikey, x-client-info, x-supabase-client-platform, x-supabase-client-platform-version'
      }
    });
  }
  const handler = handlers.get(functionName);
  if (!handler) {
    // Для незагруженных функций: вернём заглушку вместо 404
    return new Response(JSON.stringify({
      error: `Function '${functionName}' not available`
    }), {
      status: 501,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    });
  }
  try {
    const response = await handler(req);
    const headers = new Headers(response.headers);
    headers.set('Access-Control-Allow-Origin', '*');
    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers
    });
  } catch (err) {
    console.error(`[Deno] Error in ${functionName}:`, err);
    return new Response(JSON.stringify({
      error: String(err)
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL3NlcnZlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIERlbm8gSFRUUCBTZXJ2ZXIg4oCUINGF0L7RgdGC0LjRgiDQstGB0LUgU3VwYWJhc2UgRWRnZSBGdW5jdGlvbnMg0LrQsNC6IEhUVFAgZW5kcG9pbnRzXG4gKiBcbiAqIFN1cGFiYXNlIEVkZ2UgRnVuY3Rpb25zINC40YHQv9C+0LvRjNC30YPRjtGCIHNlcnZlKCkg0LjQtyBkZW5vL3N0ZCwg0LrQvtGC0L7RgNGL0Lkg0LLQvdGD0YLRgNC4XG4gKiDQstGL0LfRi9Cy0LDQtdGCIERlbm8ubGlzdGVuKCkgKyBEZW5vLnNlcnZlSHR0cCgpLiDQnNGLINC/0LXRgNC10YXQstCw0YLRi9Cy0LDQtdC8INC+0LHQsCxcbiAqINGH0YLQvtCx0Ysg0LfQsNGF0LLQsNGC0LjRgtGMINC+0LHRgNCw0LHQvtGC0YfQuNC6INC4INC90LUg0YHRgtCw0YDRgtC+0LLQsNGC0Ywg0L7RgtC00LXQu9GM0L3Ri9C5INGB0LXRgNCy0LXRgCDQtNC70Y8g0LrQsNC20LTQvtC5INGE0YPQvdC60YbQuNC4LlxuICovXG5cbmNvbnN0IFBPUlQgPSBwYXJzZUludChEZW5vLmVudi5nZXQoXCJERU5PX1BPUlRcIikgfHwgXCI4MDgxXCIpO1xuY29uc3QgRlVOQ1RJT05TX0RJUiA9IFwiLi9mdW5jdGlvbnNcIjtcblxuLy8g4pSA4pSA4pSAIFBvbHlmaWxsOiBhdXRoLmdldENsYWltcygpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8g0JzQvdC+0LbQtdGB0YLQstC+IERlbm8t0YTRg9C90LrRhtC40Lkg0LjRgdC/0L7Qu9GM0LfRg9GO0YIgc3VwYWJhc2VDbGllbnQuYXV0aC5nZXRDbGFpbXModG9rZW4pLFxuLy8g0L3QviDRjdGC0L7RgiDQvNC10YLQvtC0INCd0JUg0YHRg9GJ0LXRgdGC0LLRg9C10YIg0LIgQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDIuXG4vLyDQlNC+0LHQsNCy0LvRj9C10Lwg0LXQs9C+INC60LDQuiDQutC70LjQtdC90YLRgdC60LjQuSBKV1Qt0LTQtdC60L7QtNC10YAgKNC/0YDQvtCy0LXRgNC60LAg0YPQttC1INC90LAg0YHRgtC+0YDQvtC90LUgQVBJLdGB0LXRgNCy0LXRgNCwKS5cbnRyeSB7XG4gIGNvbnN0IHsgY3JlYXRlQ2xpZW50IH0gPSBhd2FpdCBpbXBvcnQoXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiKTtcbiAgY29uc3QgX3RtcENsaWVudCA9IGNyZWF0ZUNsaWVudChcImh0dHA6Ly9sb2NhbGhvc3Q6OTk5OVwiLCBcInBvbHlmaWxsLWtleVwiKTtcbiAgY29uc3QgYXV0aFByb3RvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKF90bXBDbGllbnQuYXV0aCk7XG4gIGlmIChhdXRoUHJvdG8gJiYgdHlwZW9mIGF1dGhQcm90by5nZXRDbGFpbXMgIT09ICdmdW5jdGlvbicpIHtcbiAgICBhdXRoUHJvdG8uZ2V0Q2xhaW1zID0gYXN5bmMgZnVuY3Rpb24oX3Rva2VuPzogc3RyaW5nKSB7XG4gICAgICB0cnkge1xuICAgICAgICAvLyDQldGB0LvQuCDQv9C10YDQtdC00LDQvSDRgtC+0LrQtdC9IOKAlCDQtNC10LrQvtC00LjRgNGD0LXQvCDQtdCz0L47INC40L3QsNGH0LUg0L/RgNC+0LHRg9C10LwgZ2V0VXNlcigpXG4gICAgICAgIGNvbnN0IHRva2VuID0gX3Rva2VuIHx8IHRoaXMuX2dldFNlc3Npb25Ub2tlbj8uKCk7XG4gICAgICAgIGlmICghdG9rZW4gfHwgdHlwZW9mIHRva2VuICE9PSAnc3RyaW5nJykge1xuICAgICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yOiBuZXcgRXJyb3IoXCJObyB0b2tlbiBwcm92aWRlZFwiKSB9O1xuICAgICAgICB9XG4gICAgICAgIC8vINCU0LXQutC+0LTQuNGA0YPQtdC8IEpXVCBwYXlsb2FkIChiYXNlNjR1cmwg4oaSIEpTT04pXG4gICAgICAgIGNvbnN0IHBhcnRzID0gdG9rZW4uc3BsaXQoJy4nKTtcbiAgICAgICAgaWYgKHBhcnRzLmxlbmd0aCAhPT0gMykge1xuICAgICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yOiBuZXcgRXJyb3IoXCJJbnZhbGlkIHRva2VuIGZvcm1hdFwiKSB9O1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGJhc2U2NCA9IHBhcnRzWzFdLnJlcGxhY2UoLy0vZywgJysnKS5yZXBsYWNlKC9fL2csICcvJyk7XG4gICAgICAgIGNvbnN0IGpzb25TdHIgPSBhdG9iKGJhc2U2NCk7XG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSBKU09OLnBhcnNlKGpzb25TdHIpO1xuICAgICAgICByZXR1cm4geyBkYXRhOiB7IGNsYWltczogcGF5bG9hZCB9LCBlcnJvcjogbnVsbCB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHJldHVybiB7IGRhdGE6IG51bGwsIGVycm9yOiBlcnIgfTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnNvbGUubG9nKFwiW0Rlbm9dIFBvbHlmaWxsOiBhdXRoLmdldENsYWltcygpIGluc3RhbGxlZFwiKTtcbiAgfVxufSBjYXRjaCAoZSkge1xuICBjb25zb2xlLndhcm4oXCJbRGVub10gUG9seWZpbGwgZ2V0Q2xhaW1zIGZhaWxlZDpcIiwgZSk7XG59XG5cbi8vINCl0YDQsNC90LjQu9C40YnQtSDQvtCx0YDQsNCx0L7RgtGH0LjQutC+0LJcbmNvbnN0IGhhbmRsZXJzID0gbmV3IE1hcDxzdHJpbmcsIChyZXE6IFJlcXVlc3QpID0+IFByb21pc2U8UmVzcG9uc2U+IHwgUmVzcG9uc2U+KCk7XG5cbi8vINCi0LXQutGD0YnQtdC1INC40LzRjyDRhNGD0L3QutGG0LjQuCDQv9GA0Lgg0LfQsNCz0YDRg9C30LrQtVxubGV0IF9jdXJyZW50TG9hZGluZ05hbWU6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuXG4vLyDilIDilIDilIAg0J/QtdGA0LXRhdCy0LDRgtGL0LLQsNC10LwgRGVuby5zZXJ2ZSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmNvbnN0IF9vcmlnaW5hbFNlcnZlID0gRGVuby5zZXJ2ZTtcblxuLy8gQHRzLWlnbm9yZTogb3ZlcnJpZGUgIFxuRGVuby5zZXJ2ZSA9IGZ1bmN0aW9uKG9wdGlvbnNPckhhbmRsZXI6IGFueSwgbWF5YmVIYW5kbGVyPzogYW55KSB7XG4gIGxldCBoYW5kbGVyOiAoKHJlcTogUmVxdWVzdCkgPT4gUHJvbWlzZTxSZXNwb25zZT4gfCBSZXNwb25zZSkgfCB1bmRlZmluZWQ7XG4gIFxuICBpZiAodHlwZW9mIG9wdGlvbnNPckhhbmRsZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICBoYW5kbGVyID0gb3B0aW9uc09ySGFuZGxlcjtcbiAgfSBlbHNlIGlmICh0eXBlb2YgbWF5YmVIYW5kbGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgaGFuZGxlciA9IG1heWJlSGFuZGxlcjtcbiAgfSBlbHNlIGlmIChvcHRpb25zT3JIYW5kbGVyICYmIHR5cGVvZiBvcHRpb25zT3JIYW5kbGVyLmhhbmRsZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICBoYW5kbGVyID0gb3B0aW9uc09ySGFuZGxlci5oYW5kbGVyO1xuICB9XG5cbiAgaWYgKGhhbmRsZXIgJiYgX2N1cnJlbnRMb2FkaW5nTmFtZSkge1xuICAgIGhhbmRsZXJzLnNldChfY3VycmVudExvYWRpbmdOYW1lLCBoYW5kbGVyKTtcbiAgfVxuICBcbiAgLy8gTW9jayBEZW5vLlNlcnZlciBvYmplY3RcbiAgcmV0dXJuIHsgXG4gICAgZmluaXNoZWQ6IFByb21pc2UucmVzb2x2ZSgpLCBcbiAgICByZWY6ICgpID0+IHt9LCBcbiAgICB1bnJlZjogKCkgPT4ge30sIFxuICAgIHNodXRkb3duOiAoKSA9PiBQcm9taXNlLnJlc29sdmUoKSxcbiAgICBhZGRyOiB7IHRyYW5zcG9ydDogXCJ0Y3BcIiBhcyBjb25zdCwgaG9zdG5hbWU6IFwiMC4wLjAuMFwiLCBwb3J0OiAwIH0sXG4gIH07XG59O1xuXG4vLyDilIDilIDilIAg0J/QtdGA0LXRhdCy0LDRgtGL0LLQsNC10LwgRGVuby5saXN0ZW4gKNC00LvRjyDRgdGC0LDRgNC+0Lkgc2VydmUoKSDQuNC3IGRlbm8vc3RkKSDilIDilIDilIDilIBcbmNvbnN0IF9vcmlnaW5hbExpc3RlbiA9IERlbm8ubGlzdGVuO1xuXG4vLyBAdHMtaWdub3JlOiBvdmVycmlkZVxuRGVuby5saXN0ZW4gPSBmdW5jdGlvbihvcHRpb25zOiBhbnkpIHtcbiAgaWYgKF9jdXJyZW50TG9hZGluZ05hbWUpIHtcbiAgICAvLyDQndC1INC30LDQv9GD0YHQutCw0LXQvCDRgNC10LDQu9GM0L3Ri9C5IGxpc3RlbmVyIOKAlCDQstC+0LfQstGA0LDRidCw0LXQvCBtb2NrXG4gICAgcmV0dXJuIHtcbiAgICAgIGFkZHI6IHsgdHJhbnNwb3J0OiBcInRjcFwiLCBob3N0bmFtZTogb3B0aW9ucz8uaG9zdG5hbWUgfHwgXCIwLjAuMC4wXCIsIHBvcnQ6IG9wdGlvbnM/LnBvcnQgfHwgMCB9LFxuICAgICAgcmlkOiAtMSxcbiAgICAgIGNsb3NlOiAoKSA9PiB7fSxcbiAgICAgIFtTeW1ib2wuYXN5bmNJdGVyYXRvcl06IGFzeW5jIGZ1bmN0aW9uKigpIHsgLyogbm9vcCAqLyB9LFxuICAgICAgcmVmOiAoKSA9PiB7fSxcbiAgICAgIHVucmVmOiAoKSA9PiB7fSxcbiAgICAgIGFjY2VwdDogKCkgPT4gbmV3IFByb21pc2UoKCkgPT4ge30pLCAvLyBuZXZlciByZXNvbHZlc1xuICAgIH07XG4gIH1cbiAgcmV0dXJuIF9vcmlnaW5hbExpc3Rlbi5jYWxsKERlbm8sIG9wdGlvbnMpO1xufTtcblxuLy8g4pSA4pSA4pSAINCf0LXRgNC10YXQstCw0YLRi9Cy0LDQtdC8IERlbm8uc2VydmVIdHRwICjQtNC70Y8g0YHRgtCw0YDQvtC5IHNlcnZlKCkpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuY29uc3QgX29yaWdpbmFsU2VydmVIdHRwID0gKERlbm8gYXMgYW55KS5zZXJ2ZUh0dHA7XG5cbi8vIEB0cy1pZ25vcmU6IG92ZXJyaWRlXG4oRGVubyBhcyBhbnkpLnNlcnZlSHR0cCA9IGZ1bmN0aW9uKGNvbm46IGFueSkge1xuICBpZiAoX2N1cnJlbnRMb2FkaW5nTmFtZSkge1xuICAgIC8vIE1vY2sgaHR0cENvbm5cbiAgICByZXR1cm4ge1xuICAgICAgcmlkOiAtMSxcbiAgICAgIGNsb3NlOiAoKSA9PiB7fSxcbiAgICAgIG5leHRSZXF1ZXN0OiAoKSA9PiBQcm9taXNlLnJlc29sdmUobnVsbCksXG4gICAgICBbU3ltYm9sLmFzeW5jSXRlcmF0b3JdOiBhc3luYyBmdW5jdGlvbiooKSB7IC8qIG5vb3AgKi8gfSxcbiAgICB9O1xuICB9XG4gIHJldHVybiBfb3JpZ2luYWxTZXJ2ZUh0dHA/LmNhbGwoRGVubywgY29ubik7XG59O1xuXG4vLyDilIDilIDilIAg0JfQsNCz0YDRg9C30LrQsCDRhNGD0L3QutGG0LjQuSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmFzeW5jIGZ1bmN0aW9uIGxvYWRGdW5jdGlvbnMoKSB7XG4gIGZvciBhd2FpdCAoY29uc3QgZW50cnkgb2YgRGVuby5yZWFkRGlyKEZVTkNUSU9OU19ESVIpKSB7XG4gICAgaWYgKCFlbnRyeS5pc0RpcmVjdG9yeSkgY29udGludWU7XG4gICAgXG4gICAgY29uc3QgaW5kZXhQYXRoID0gYCR7RlVOQ1RJT05TX0RJUn0vJHtlbnRyeS5uYW1lfS9pbmRleC50c2A7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IERlbm8uc3RhdChpbmRleFBhdGgpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgY29udGludWU7IC8vINC90LXRgiBpbmRleC50c1xuICAgIH1cblxuICAgIF9jdXJyZW50TG9hZGluZ05hbWUgPSBlbnRyeS5uYW1lO1xuICAgIFxuICAgIHRyeSB7XG4gICAgICBjb25zdCBtb2QgPSBhd2FpdCBpbXBvcnQoYC4vJHtpbmRleFBhdGh9YCk7XG4gICAgICBcbiAgICAgIC8vINCV0YHQu9C4IGhhbmRsZXIg0L3QtSDQt9Cw0YXQstCw0YfQtdC9INGH0LXRgNC10Lcgc2VydmUvRGVuby5zZXJ2ZSwg0L/RgNC+0LLQtdGA0Y/QtdC8IGRlZmF1bHQgZXhwb3J0XG4gICAgICBpZiAoIWhhbmRsZXJzLmhhcyhlbnRyeS5uYW1lKSAmJiB0eXBlb2YgbW9kLmRlZmF1bHQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgaGFuZGxlcnMuc2V0KGVudHJ5Lm5hbWUsIG1vZC5kZWZhdWx0KTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgLy8g0JXRgdC70Lgg0LLRgdGRINC10YnRkSDQvdC10YIg4oCUINC/0L7Qv9GA0L7QsdGD0LXQvCDQvtCx0YDQsNCx0L7RgtCw0YLRjCBzZXJ2ZSgpINCy0YvQt9C+0LJcbiAgICAgIC8vIHNlcnZlKCkg0LjQtyBkZW5vL3N0ZCDQv9C10YDQtdC00LDRkdGCIGhhbmRsZXIg0LIg0L/QtdGA0LLRi9C5INCw0YDQs9GD0LzQtdC90YJcbiAgICAgIC8vINCd0LDRiCDQv9C10YDQtdGF0LLQsNGCIERlbm8ubGlzdGVuICsgbW9jayDRg9C20LUg0LTQvtC70LbQtdC9INCx0YvQuyDQv9GA0LXQtNC+0YLQstGA0LDRgtC40YLRjCDQutGA0LDRiFxuICAgICAgXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAvLyDQm9C+0LPQuNGA0YPQtdC8INC90L4g0L3QtSDQutGA0LDRiNC40LzRgdGPXG4gICAgICBjb25zdCBtc2cgPSBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVycik7XG4gICAgICAvLyDQmNCz0L3QvtGA0LjRgNGD0LXQvCDQvtGI0LjQsdC60Lgg0LDQtNGA0LXRgdCwICjRg9C20LUg0L7QsdGA0LDQsdC+0YLQsNC90Ysg0LzQvtC60L7QvClcbiAgICAgIGlmICghbXNnLmluY2x1ZGVzKCdBZGRySW5Vc2UnKSAmJiAhbXNnLmluY2x1ZGVzKCdBZGRyZXNzIGFscmVhZHknKSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBbRGVub10gRXJyb3IgbG9hZGluZyAke2VudHJ5Lm5hbWV9OiAke21zZ31gKTtcbiAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgX2N1cnJlbnRMb2FkaW5nTmFtZSA9IG51bGw7XG4gICAgXG4gICAgaWYgKGhhbmRsZXJzLmhhcyhlbnRyeS5uYW1lKSkge1xuICAgICAgY29uc29sZS5sb2coYFtEZW5vXSBMb2FkZWQ6ICR7ZW50cnkubmFtZX1gKTtcbiAgICB9XG4gIH1cbn1cblxuLy8g0J/QtdGA0LXRhdCy0LDRgtGL0LLQsNC10Lwgc2VydmUg0LjQtyBkZW5vL3N0ZCDigJQg0L7QvdCwINGN0LrRgdC/0L7RgNGC0LjRgNGD0LXRgtGB0Y8g0LrQsNC6INC40LzQtdC90L7QstCw0L3QvdCw0Y8g0YTRg9C90LrRhtC40Y9cbi8vINC4INC/0YDQuNC90LjQvNCw0LXRgiBoYW5kbGVyINC60LDQuiDQv9C10YDQstGL0Lkg0LDRgNCz0YPQvNC10L3Rgi4g0J3QviDQvNGLINC90LUg0LzQvtC20LXQvCDQv9C10YDQtdGF0LLQsNGC0LjRgtGMINC40LzQv9C+0YDRgi5cbi8vINCS0LzQtdGB0YLQviDRjdGC0L7Qs9C+INC80Ysg0L/QtdGA0LXRhdCy0LDRgtGL0LLQsNC10LwgRGVuby5saXN0ZW4gKyBEZW5vLnNlcnZlSHR0cFxuLy8g0Lgg0LTQu9GPIHNlcnZlKCktYmFzZWQg0YTRg9C90LrRhtC40Lkg0LLRgNGD0YfQvdGD0Y4g0L/QsNGA0YHQuNC8INC40YUgaGFuZGxlciDQuNC3INC40YHRhdC+0LTQvdC40LrQsC5cblxuLyoqXG4gKiBGYWxsYmFjazog0LTQu9GPINGE0YPQvdC60YbQuNC5INC60L7RgtC+0YDRi9C1INC40YHQv9C+0LvRjNC30YPRjtGCIHNlcnZlKCkg0LjQtyBkZW5vL3N0ZFxuICog0Lgg0L3QtSDQsdGL0LvQuCDQt9Cw0YXQstCw0YfQtdC90Ysg4oCUINGB0L7Qt9C00LDRkdC8INC+0LHRgNCw0LHQvtGC0YfQuNC6INC60L7RgtC+0YDRi9C5INC/0LDRgNGB0LjRgiDQt9Cw0L/RgNC+0YEgXG4gKiDQuCDQv9GA0L7QutGB0LjRgNGD0LXRgiDQtdCz0L5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gbG9hZFNlcnZlQmFzZWRGdW5jdGlvbnMoKSB7XG4gIGZvciBhd2FpdCAoY29uc3QgZW50cnkgb2YgRGVuby5yZWFkRGlyKEZVTkNUSU9OU19ESVIpKSB7XG4gICAgaWYgKCFlbnRyeS5pc0RpcmVjdG9yeSB8fCBoYW5kbGVycy5oYXMoZW50cnkubmFtZSkpIGNvbnRpbnVlO1xuXG4gICAgY29uc3QgaW5kZXhQYXRoID0gYCR7RlVOQ1RJT05TX0RJUn0vJHtlbnRyeS5uYW1lfS9pbmRleC50c2A7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvZGUgPSBhd2FpdCBEZW5vLnJlYWRUZXh0RmlsZShpbmRleFBhdGgpO1xuICAgICAgXG4gICAgICAvLyDQn9GA0L7QstC10YDRj9C10Lwg0LXRgdGC0Ywg0LvQuCBzZXJ2ZShhc3luYyAocmVxKSA9PiB7IC4uLiB9KSDQv9Cw0YLRgtC10YDQvVxuICAgICAgaWYgKGNvZGUuaW5jbHVkZXMoJ3NlcnZlKGFzeW5jJykgfHwgY29kZS5pbmNsdWRlcygnc2VydmUoZnVuY3Rpb24nKSkge1xuICAgICAgICAvLyDQmNC30LLQu9C10LrQsNC10LwgaGFuZGxlciDQuNC3IHNlcnZlKCkg0LLRi9C30L7QstCwXG4gICAgICAgIC8vINCU0LvRjyDRjdGC0L7Qs9C+INC00LjQvdCw0LzQuNGH0LXRgdC60Lgg0YHQvtC30LTQsNGR0Lwg0LzQvtC00LjRhNC40YbQuNGA0L7QstCw0L3QvdGL0Lkg0LrQvtC0XG4gICAgICAgIGNvbnN0IG1vZGlmaWVkQ29kZSA9IGNvZGVcbiAgICAgICAgICAvLyDQl9Cw0LzQtdC90Y/QtdC8IGltcG9ydCBzZXJ2ZSDQvdCwINC90LDRiCDRgdGC0LDQsVxuICAgICAgICAgIC5yZXBsYWNlKFxuICAgICAgICAgICAgL2ltcG9ydFxccypcXHtcXHMqc2VydmVcXHMqXFx9XFxzKmZyb21cXHMqXCJodHRwczpcXC9cXC9kZW5vXFwubGFuZFxcL3N0ZFteXCJdKlxcL2h0dHBcXC9zZXJ2ZXJcXC50c1wiL2csXG4gICAgICAgICAgICBgY29uc3Qgc2VydmUgPSAoaGFuZGxlcjogYW55KSA9PiB7IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBoYW5kbGVyOyB9YFxuICAgICAgICAgICk7XG4gICAgICAgIFxuICAgICAgICAvLyDQodC+0LfQtNCw0ZHQvCB0ZW1wINGE0LDQudC7INGBINC80L7QtNC40YTQuNGG0LjRgNC+0LLQsNC90L3Ri9C8INC60L7QtNC+0LxcbiAgICAgICAgY29uc3QgdG1wUGF0aCA9IGAvdG1wL19mbl8ke2VudHJ5Lm5hbWV9LnRzYDtcbiAgICAgICAgYXdhaXQgRGVuby53cml0ZVRleHRGaWxlKHRtcFBhdGgsIG1vZGlmaWVkQ29kZSk7XG4gICAgICAgIFxuICAgICAgICB0cnkge1xuICAgICAgICAgIChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXIgPSBudWxsO1xuICAgICAgICAgIGF3YWl0IGltcG9ydCh0bXBQYXRoKTtcbiAgICAgICAgICBcbiAgICAgICAgICBjb25zdCBjYXB0dXJlZCA9IChnbG9iYWxUaGlzIGFzIGFueSkuX19jYXB0dXJlZEhhbmRsZXI7XG4gICAgICAgICAgaWYgKHR5cGVvZiBjYXB0dXJlZCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgaGFuZGxlcnMuc2V0KGVudHJ5Lm5hbWUsIGNhcHR1cmVkKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBbRGVub10gTG9hZGVkIChzZXJ2ZS1jb21wYXQpOiAke2VudHJ5Lm5hbWV9YCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChsb2FkRXJyKSB7XG4gICAgICAgICAgLy8g0J3QtSDQutGA0LjRgtC40YfQvdC+IOKAlCDRhNGD0L3QutGG0LjRjyDQvNC+0LbQtdGCINGC0YDQtdCx0L7QstCw0YLRjCDRgdC/0LXRhtC40YTQuNGH0L3Ri9C1INC30LDQstC40YHQuNC80L7RgdGC0LhcbiAgICAgICAgICBjb25zdCBtc2cgPSBsb2FkRXJyIGluc3RhbmNlb2YgRXJyb3IgPyBsb2FkRXJyLm1lc3NhZ2UgOiBTdHJpbmcobG9hZEVycik7XG4gICAgICAgICAgaWYgKCFtc2cuaW5jbHVkZXMoJ0FkZHJJblVzZScpICYmICFtc2cuaW5jbHVkZXMoJ2FscmVhZHknKSkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGBbRGVub10gU2tpcHBlZCAke2VudHJ5Lm5hbWV9OiAke21zZy5zdWJzdHJpbmcoMCwgODApfWApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2gge1xuICAgICAgLy8g0KTQsNC50Lsg0L3QtSDQvdCw0LnQtNC10L0g0LjQu9C4INC+0YjQuNCx0LrQsCDRh9GC0LXQvdC40Y9cbiAgICB9XG4gIH1cbn1cblxuYXdhaXQgbG9hZEZ1bmN0aW9ucygpO1xuYXdhaXQgbG9hZFNlcnZlQmFzZWRGdW5jdGlvbnMoKTtcblxuY29uc29sZS5sb2coYFtEZW5vXSAke2hhbmRsZXJzLnNpemV9IGZ1bmN0aW9ucyByZWFkeWApO1xuXG4vLyDilIDilIDilIAg0JfQsNC/0YPRgdC60LDQtdC8INC10LTQuNC90YvQuSBIVFRQLdGB0LXRgNCy0LXRgCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbl9vcmlnaW5hbFNlcnZlLmNhbGwoRGVubywgeyBwb3J0OiBQT1JULCBob3N0bmFtZTogXCIwLjAuMC4wXCIgfSwgYXN5bmMgKHJlcTogUmVxdWVzdCkgPT4ge1xuICBjb25zdCB1cmwgPSBuZXcgVVJMKHJlcS51cmwpO1xuICBjb25zdCBwYXRoUGFydHMgPSB1cmwucGF0aG5hbWUuc3BsaXQoJy8nKS5maWx0ZXIoQm9vbGVhbik7XG4gIGNvbnN0IGZ1bmN0aW9uTmFtZSA9IHBhdGhQYXJ0c1swXTtcblxuICAvLyBIZWFsdGggY2hlY2tcbiAgaWYgKGZ1bmN0aW9uTmFtZSA9PT0gJ2hlYWx0aCcgfHwgIWZ1bmN0aW9uTmFtZSkge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgIHN0YXR1czogJ29rJywgXG4gICAgICBmdW5jdGlvbnM6IGhhbmRsZXJzLnNpemUsXG4gICAgICBsb2FkZWQ6IFsuLi5oYW5kbGVycy5rZXlzKCldLFxuICAgIH0pLCB7XG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIENPUlMgcHJlZmxpZ2h0XG4gIGlmIChyZXEubWV0aG9kID09PSAnT1BUSU9OUycpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHtcbiAgICAgIHN0YXR1czogMjA0LFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctTWV0aG9kcyc6ICdHRVQsIFBPU1QsIFBVVCwgREVMRVRFLCBPUFRJT05TJyxcbiAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnMnOiAnQXV0aG9yaXphdGlvbiwgQ29udGVudC1UeXBlLCBhcGlrZXksIHgtY2xpZW50LWluZm8sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICBjb25zdCBoYW5kbGVyID0gaGFuZGxlcnMuZ2V0KGZ1bmN0aW9uTmFtZSk7XG4gIGlmICghaGFuZGxlcikge1xuICAgIC8vINCU0LvRjyDQvdC10LfQsNCz0YDRg9C20LXQvdC90YvRhSDRhNGD0L3QutGG0LjQuTog0LLQtdGA0L3RkdC8INC30LDQs9C70YPRiNC60YMg0LLQvNC10YHRgtC+IDQwNFxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogYEZ1bmN0aW9uICcke2Z1bmN0aW9uTmFtZX0nIG5vdCBhdmFpbGFibGVgIH0pLCB7XG4gICAgICBzdGF0dXM6IDUwMSxcbiAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJywgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyB9LFxuICAgIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGhhbmRsZXIocmVxKTtcbiAgICBjb25zdCBoZWFkZXJzID0gbmV3IEhlYWRlcnMocmVzcG9uc2UuaGVhZGVycyk7XG4gICAgaGVhZGVycy5zZXQoJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbicsICcqJyk7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShyZXNwb25zZS5ib2R5LCB7XG4gICAgICBzdGF0dXM6IHJlc3BvbnNlLnN0YXR1cyxcbiAgICAgIHN0YXR1c1RleHQ6IHJlc3BvbnNlLnN0YXR1c1RleHQsXG4gICAgICBoZWFkZXJzLFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKGBbRGVub10gRXJyb3IgaW4gJHtmdW5jdGlvbk5hbWV9OmAsIGVycik7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBTdHJpbmcoZXJyKSB9KSwge1xuICAgICAgc3RhdHVzOiA1MDAsXG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicgfSxcbiAgICB9KTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7OztDQU1DLEdBRUQsTUFBTSxPQUFPLFNBQVMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdCQUFnQjtBQUNuRCxNQUFNLGdCQUFnQjtBQUV0Qix1RUFBdUU7QUFDdkUsMEVBQTBFO0FBQzFFLHlEQUF5RDtBQUN6RCxrRkFBa0Y7QUFDbEYsSUFBSTtFQUNGLE1BQU0sRUFBRSxZQUFZLEVBQUUsR0FBRyxNQUFNLE1BQU0sQ0FBQztFQUN0QyxNQUFNLGFBQWEsYUFBYSx5QkFBeUI7RUFDekQsTUFBTSxZQUFZLE9BQU8sY0FBYyxDQUFDLFdBQVcsSUFBSTtFQUN2RCxJQUFJLGFBQWEsT0FBTyxVQUFVLFNBQVMsS0FBSyxZQUFZO0lBQzFELFVBQVUsU0FBUyxHQUFHLGVBQWUsTUFBZTtNQUNsRCxJQUFJO1FBQ0YsK0RBQStEO1FBQy9ELE1BQU0sUUFBUSxVQUFVLElBQUksQ0FBQyxnQkFBZ0I7UUFDN0MsSUFBSSxDQUFDLFNBQVMsT0FBTyxVQUFVLFVBQVU7VUFDdkMsT0FBTztZQUFFLE1BQU07WUFBTSxPQUFPLElBQUksTUFBTTtVQUFxQjtRQUM3RDtRQUNBLDRDQUE0QztRQUM1QyxNQUFNLFFBQVEsTUFBTSxLQUFLLENBQUM7UUFDMUIsSUFBSSxNQUFNLE1BQU0sS0FBSyxHQUFHO1VBQ3RCLE9BQU87WUFBRSxNQUFNO1lBQU0sT0FBTyxJQUFJLE1BQU07VUFBd0I7UUFDaEU7UUFDQSxNQUFNLFNBQVMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBTSxLQUFLLE9BQU8sQ0FBQyxNQUFNO1FBQ3pELE1BQU0sVUFBVSxLQUFLO1FBQ3JCLE1BQU0sVUFBVSxLQUFLLEtBQUssQ0FBQztRQUMzQixPQUFPO1VBQUUsTUFBTTtZQUFFLFFBQVE7VUFBUTtVQUFHLE9BQU87UUFBSztNQUNsRCxFQUFFLE9BQU8sS0FBSztRQUNaLE9BQU87VUFBRSxNQUFNO1VBQU0sT0FBTztRQUFJO01BQ2xDO0lBQ0Y7SUFDQSxRQUFRLEdBQUcsQ0FBQztFQUNkO0FBQ0YsRUFBRSxPQUFPLEdBQUc7RUFDVixRQUFRLElBQUksQ0FBQyxxQ0FBcUM7QUFDcEQ7QUFFQSx5QkFBeUI7QUFDekIsTUFBTSxXQUFXLElBQUk7QUFFckIsbUNBQW1DO0FBQ25DLElBQUksc0JBQXFDO0FBRXpDLHNFQUFzRTtBQUN0RSxNQUFNLGlCQUFpQixLQUFLLEtBQUs7QUFFakMseUJBQXlCO0FBQ3pCLEtBQUssS0FBSyxHQUFHLFNBQVMsZ0JBQXFCLEVBQUUsWUFBa0I7RUFDN0QsSUFBSTtFQUVKLElBQUksT0FBTyxxQkFBcUIsWUFBWTtJQUMxQyxVQUFVO0VBQ1osT0FBTyxJQUFJLE9BQU8saUJBQWlCLFlBQVk7SUFDN0MsVUFBVTtFQUNaLE9BQU8sSUFBSSxvQkFBb0IsT0FBTyxpQkFBaUIsT0FBTyxLQUFLLFlBQVk7SUFDN0UsVUFBVSxpQkFBaUIsT0FBTztFQUNwQztFQUVBLElBQUksV0FBVyxxQkFBcUI7SUFDbEMsU0FBUyxHQUFHLENBQUMscUJBQXFCO0VBQ3BDO0VBRUEsMEJBQTBCO0VBQzFCLE9BQU87SUFDTCxVQUFVLFFBQVEsT0FBTztJQUN6QixLQUFLLEtBQU87SUFDWixPQUFPLEtBQU87SUFDZCxVQUFVLElBQU0sUUFBUSxPQUFPO0lBQy9CLE1BQU07TUFBRSxXQUFXO01BQWdCLFVBQVU7TUFBVyxNQUFNO0lBQUU7RUFDbEU7QUFDRjtBQUVBLHNFQUFzRTtBQUN0RSxNQUFNLGtCQUFrQixLQUFLLE1BQU07QUFFbkMsdUJBQXVCO0FBQ3ZCLEtBQUssTUFBTSxHQUFHLFNBQVMsT0FBWTtFQUNqQyxJQUFJLHFCQUFxQjtJQUN2QixtREFBbUQ7SUFDbkQsT0FBTztNQUNMLE1BQU07UUFBRSxXQUFXO1FBQU8sVUFBVSxTQUFTLFlBQVk7UUFBVyxNQUFNLFNBQVMsUUFBUTtNQUFFO01BQzdGLEtBQUssQ0FBQztNQUNOLE9BQU8sS0FBTztNQUNkLENBQUMsT0FBTyxhQUFhLENBQUMsRUFBRSxtQkFBK0I7TUFDdkQsS0FBSyxLQUFPO01BQ1osT0FBTyxLQUFPO01BQ2QsUUFBUSxJQUFNLElBQUksUUFBUSxLQUFPO0lBQ25DO0VBQ0Y7RUFDQSxPQUFPLGdCQUFnQixJQUFJLENBQUMsTUFBTTtBQUNwQztBQUVBLHNFQUFzRTtBQUN0RSxNQUFNLHFCQUFxQixBQUFDLEtBQWEsU0FBUztBQUVsRCx1QkFBdUI7QUFDdEIsS0FBYSxTQUFTLEdBQUcsU0FBUyxJQUFTO0VBQzFDLElBQUkscUJBQXFCO0lBQ3ZCLGdCQUFnQjtJQUNoQixPQUFPO01BQ0wsS0FBSyxDQUFDO01BQ04sT0FBTyxLQUFPO01BQ2QsYUFBYSxJQUFNLFFBQVEsT0FBTyxDQUFDO01BQ25DLENBQUMsT0FBTyxhQUFhLENBQUMsRUFBRSxtQkFBK0I7SUFDekQ7RUFDRjtFQUNBLE9BQU8sb0JBQW9CLEtBQUssTUFBTTtBQUN4QztBQUVBLHNFQUFzRTtBQUN0RSxlQUFlO0VBQ2IsV0FBVyxNQUFNLFNBQVMsS0FBSyxPQUFPLENBQUMsZUFBZ0I7SUFDckQsSUFBSSxDQUFDLE1BQU0sV0FBVyxFQUFFO0lBRXhCLE1BQU0sWUFBWSxDQUFDLEVBQUUsY0FBYyxDQUFDLEVBQUUsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQzNELElBQUk7TUFDRixNQUFNLEtBQUssSUFBSSxDQUFDO0lBQ2xCLEVBQUUsT0FBTTtNQUNOLFVBQVUsZUFBZTtJQUMzQjtJQUVBLHNCQUFzQixNQUFNLElBQUk7SUFFaEMsSUFBSTtNQUNGLE1BQU0sTUFBTSxNQUFNLE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBRSxVQUFVLENBQUM7TUFFekMsNEVBQTRFO01BQzVFLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxNQUFNLElBQUksS0FBSyxPQUFPLElBQUksT0FBTyxLQUFLLFlBQVk7UUFDbEUsU0FBUyxHQUFHLENBQUMsTUFBTSxJQUFJLEVBQUUsSUFBSSxPQUFPO01BQ3RDO0lBRUEsd0RBQXdEO0lBQ3hELHlEQUF5RDtJQUN6RCxvRUFBb0U7SUFFdEUsRUFBRSxPQUFPLEtBQUs7TUFDWiwwQkFBMEI7TUFDMUIsTUFBTSxNQUFNLGVBQWUsUUFBUSxJQUFJLE9BQU8sR0FBRyxPQUFPO01BQ3hELGtEQUFrRDtNQUNsRCxJQUFJLENBQUMsSUFBSSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxRQUFRLENBQUMsb0JBQW9CO1FBQ2xFLFFBQVEsS0FBSyxDQUFDLENBQUMscUJBQXFCLEVBQUUsTUFBTSxJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQztNQUM1RDtJQUNGO0lBRUEsc0JBQXNCO0lBRXRCLElBQUksU0FBUyxHQUFHLENBQUMsTUFBTSxJQUFJLEdBQUc7TUFDNUIsUUFBUSxHQUFHLENBQUMsQ0FBQyxlQUFlLEVBQUUsTUFBTSxJQUFJLENBQUMsQ0FBQztJQUM1QztFQUNGO0FBQ0Y7QUFFQSwrRUFBK0U7QUFDL0UsOEVBQThFO0FBQzlFLDZEQUE2RDtBQUM3RCxzRUFBc0U7QUFFdEU7Ozs7Q0FJQyxHQUNELGVBQWU7RUFDYixXQUFXLE1BQU0sU0FBUyxLQUFLLE9BQU8sQ0FBQyxlQUFnQjtJQUNyRCxJQUFJLENBQUMsTUFBTSxXQUFXLElBQUksU0FBUyxHQUFHLENBQUMsTUFBTSxJQUFJLEdBQUc7SUFFcEQsTUFBTSxZQUFZLENBQUMsRUFBRSxjQUFjLENBQUMsRUFBRSxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUM7SUFDM0QsSUFBSTtNQUNGLE1BQU0sT0FBTyxNQUFNLEtBQUssWUFBWSxDQUFDO01BRXJDLDBEQUEwRDtNQUMxRCxJQUFJLEtBQUssUUFBUSxDQUFDLGtCQUFrQixLQUFLLFFBQVEsQ0FBQyxtQkFBbUI7UUFDbkUsc0NBQXNDO1FBQ3RDLHFEQUFxRDtRQUNyRCxNQUFNLGVBQWUsSUFDbkIsb0NBQW9DO1NBQ25DLE9BQU8sQ0FDTix5RkFDQSxDQUFDLG9GQUFvRixDQUFDO1FBRzFGLDZDQUE2QztRQUM3QyxNQUFNLFVBQVUsQ0FBQyxTQUFTLEVBQUUsTUFBTSxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQzNDLE1BQU0sS0FBSyxhQUFhLENBQUMsU0FBUztRQUVsQyxJQUFJO1VBQ0QsV0FBbUIsaUJBQWlCLEdBQUc7VUFDeEMsTUFBTSxNQUFNLENBQUM7VUFFYixNQUFNLFdBQVcsQUFBQyxXQUFtQixpQkFBaUI7VUFDdEQsSUFBSSxPQUFPLGFBQWEsWUFBWTtZQUNsQyxTQUFTLEdBQUcsQ0FBQyxNQUFNLElBQUksRUFBRTtZQUN6QixRQUFRLEdBQUcsQ0FBQyxDQUFDLDhCQUE4QixFQUFFLE1BQU0sSUFBSSxDQUFDLENBQUM7VUFDM0Q7UUFDRixFQUFFLE9BQU8sU0FBUztVQUNoQixnRUFBZ0U7VUFDaEUsTUFBTSxNQUFNLG1CQUFtQixRQUFRLFFBQVEsT0FBTyxHQUFHLE9BQU87VUFDaEUsSUFBSSxDQUFDLElBQUksUUFBUSxDQUFDLGdCQUFnQixDQUFDLElBQUksUUFBUSxDQUFDLFlBQVk7WUFDMUQsUUFBUSxJQUFJLENBQUMsQ0FBQyxlQUFlLEVBQUUsTUFBTSxJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDO1VBQ3RFO1FBQ0Y7TUFDRjtJQUNGLEVBQUUsT0FBTTtJQUNOLG1DQUFtQztJQUNyQztFQUNGO0FBQ0Y7QUFFQSxNQUFNO0FBQ04sTUFBTTtBQUVOLFFBQVEsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLFNBQVMsSUFBSSxDQUFDLGdCQUFnQixDQUFDO0FBRXJELHNFQUFzRTtBQUN0RSxlQUFlLElBQUksQ0FBQyxNQUFNO0VBQUUsTUFBTTtFQUFNLFVBQVU7QUFBVSxHQUFHLE9BQU87RUFDcEUsTUFBTSxNQUFNLElBQUksSUFBSSxJQUFJLEdBQUc7RUFDM0IsTUFBTSxZQUFZLElBQUksUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLE1BQU0sQ0FBQztFQUNqRCxNQUFNLGVBQWUsU0FBUyxDQUFDLEVBQUU7RUFFakMsZUFBZTtFQUNmLElBQUksaUJBQWlCLFlBQVksQ0FBQyxjQUFjO0lBQzlDLE9BQU8sSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDO01BQ2pDLFFBQVE7TUFDUixXQUFXLFNBQVMsSUFBSTtNQUN4QixRQUFRO1dBQUksU0FBUyxJQUFJO09BQUc7SUFDOUIsSUFBSTtNQUNGLFNBQVM7UUFBRSxnQkFBZ0I7TUFBbUI7SUFDaEQ7RUFDRjtFQUVBLGlCQUFpQjtFQUNqQixJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUN4QixRQUFRO01BQ1IsU0FBUztRQUNQLCtCQUErQjtRQUMvQixnQ0FBZ0M7UUFDaEMsZ0NBQWdDO01BQ2xDO0lBQ0Y7RUFDRjtFQUVBLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztFQUM3QixJQUFJLENBQUMsU0FBUztJQUNaLHdEQUF3RDtJQUN4RCxPQUFPLElBQUksU0FBUyxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsYUFBYSxlQUFlLENBQUM7SUFBQyxJQUFJO01BQ3pGLFFBQVE7TUFDUixTQUFTO1FBQUUsZ0JBQWdCO1FBQW9CLCtCQUErQjtNQUFJO0lBQ3BGO0VBQ0Y7RUFFQSxJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sUUFBUTtJQUMvQixNQUFNLFVBQVUsSUFBSSxRQUFRLFNBQVMsT0FBTztJQUM1QyxRQUFRLEdBQUcsQ0FBQywrQkFBK0I7SUFDM0MsT0FBTyxJQUFJLFNBQVMsU0FBUyxJQUFJLEVBQUU7TUFDakMsUUFBUSxTQUFTLE1BQU07TUFDdkIsWUFBWSxTQUFTLFVBQVU7TUFDL0I7SUFDRjtFQUNGLEVBQUUsT0FBTyxLQUFLO0lBQ1osUUFBUSxLQUFLLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLENBQUMsQ0FBQyxFQUFFO0lBQ2xELE9BQU8sSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTyxPQUFPO0lBQUssSUFBSTtNQUMxRCxRQUFRO01BQ1IsU0FBUztRQUFFLGdCQUFnQjtRQUFvQiwrQkFBK0I7TUFBSTtJQUNwRjtFQUNGO0FBQ0YifQ==
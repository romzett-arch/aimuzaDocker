import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type"
};
const SITE_URL = "https://aiplanetsound.lovable.app";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseKey);
    // Fetch all visible topics (limited to 5000 for performance)
    const { data: topics, error: topicsError } = await supabase.from("forum_topics").select("id, updated_at, title").eq("is_hidden", false).order("updated_at", {
      ascending: false
    }).limit(5000);
    if (topicsError) {
      console.error("Error fetching topics:", topicsError);
      throw topicsError;
    }
    // Fetch categories
    const { data: categories, error: catsError } = await supabase.from("forum_categories").select("slug, updated_at").eq("is_active", true);
    if (catsError) {
      console.error("Error fetching categories:", catsError);
      throw catsError;
    }
    // Fetch tags
    const { data: tags, error: tagsError } = await supabase.from("forum_tags").select("name").gt("usage_count", 0);
    if (tagsError) {
      console.error("Error fetching tags:", tagsError);
    }
    // Build XML sitemap
    let xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${SITE_URL}/forum</loc>
    <changefreq>hourly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${SITE_URL}/forum/tags</loc>
    <changefreq>daily</changefreq>
    <priority>0.5</priority>
  </url>`;
    // Categories
    for (const cat of categories || []){
      xml += `
  <url>
    <loc>${SITE_URL}/forum/c/${cat.slug}</loc>
    <lastmod>${new Date(cat.updated_at).toISOString()}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.7</priority>
  </url>`;
    }
    // Topics
    for (const topic of topics || []){
      xml += `
  <url>
    <loc>${SITE_URL}/forum/t/${topic.id}</loc>
    <lastmod>${new Date(topic.updated_at).toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.6</priority>
  </url>`;
    }
    // Tags
    for (const tag of tags || []){
      xml += `
  <url>
    <loc>${SITE_URL}/forum/tag/${encodeURIComponent(tag.name)}</loc>
    <changefreq>weekly</changefreq>
    <priority>0.4</priority>
  </url>`;
    }
    xml += `
</urlset>`;
    console.log(`[forum-sitemap] Generated sitemap with ${categories?.length || 0} categories, ${topics?.length || 0} topics, ${tags?.length || 0} tags`);
    return new Response(xml, {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, max-age=3600"
      }
    });
  } catch (error) {
    console.error("[forum-sitemap] Error:", error);
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9mb3J1bS1zaXRlbWFwL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE2OC4wL2h0dHAvc2VydmVyLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDIuMzkuM1wiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlXCIsXG59O1xuXG5jb25zdCBTSVRFX1VSTCA9IFwiaHR0cHM6Ly9haXBsYW5ldHNvdW5kLmxvdmFibGUuYXBwXCI7XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcIm9rXCIsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZUtleSk7XG5cbiAgICAvLyBGZXRjaCBhbGwgdmlzaWJsZSB0b3BpY3MgKGxpbWl0ZWQgdG8gNTAwMCBmb3IgcGVyZm9ybWFuY2UpXG4gICAgY29uc3QgeyBkYXRhOiB0b3BpY3MsIGVycm9yOiB0b3BpY3NFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiZm9ydW1fdG9waWNzXCIpXG4gICAgICAuc2VsZWN0KFwiaWQsIHVwZGF0ZWRfYXQsIHRpdGxlXCIpXG4gICAgICAuZXEoXCJpc19oaWRkZW5cIiwgZmFsc2UpXG4gICAgICAub3JkZXIoXCJ1cGRhdGVkX2F0XCIsIHsgYXNjZW5kaW5nOiBmYWxzZSB9KVxuICAgICAgLmxpbWl0KDUwMDApO1xuXG4gICAgaWYgKHRvcGljc0Vycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdG9waWNzOlwiLCB0b3BpY3NFcnJvcik7XG4gICAgICB0aHJvdyB0b3BpY3NFcnJvcjtcbiAgICB9XG5cbiAgICAvLyBGZXRjaCBjYXRlZ29yaWVzXG4gICAgY29uc3QgeyBkYXRhOiBjYXRlZ29yaWVzLCBlcnJvcjogY2F0c0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJmb3J1bV9jYXRlZ29yaWVzXCIpXG4gICAgICAuc2VsZWN0KFwic2x1ZywgdXBkYXRlZF9hdFwiKVxuICAgICAgLmVxKFwiaXNfYWN0aXZlXCIsIHRydWUpO1xuXG4gICAgaWYgKGNhdHNFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGNhdGVnb3JpZXM6XCIsIGNhdHNFcnJvcik7XG4gICAgICB0aHJvdyBjYXRzRXJyb3I7XG4gICAgfVxuXG4gICAgLy8gRmV0Y2ggdGFnc1xuICAgIGNvbnN0IHsgZGF0YTogdGFncywgZXJyb3I6IHRhZ3NFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiZm9ydW1fdGFnc1wiKVxuICAgICAgLnNlbGVjdChcIm5hbWVcIilcbiAgICAgIC5ndChcInVzYWdlX2NvdW50XCIsIDApO1xuXG4gICAgaWYgKHRhZ3NFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHRhZ3M6XCIsIHRhZ3NFcnJvcik7XG4gICAgfVxuXG4gICAgLy8gQnVpbGQgWE1MIHNpdGVtYXBcbiAgICBsZXQgeG1sID0gYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PlxuPHVybHNldCB4bWxucz1cImh0dHA6Ly93d3cuc2l0ZW1hcHMub3JnL3NjaGVtYXMvc2l0ZW1hcC8wLjlcIj5cbiAgPHVybD5cbiAgICA8bG9jPiR7U0lURV9VUkx9L2ZvcnVtPC9sb2M+XG4gICAgPGNoYW5nZWZyZXE+aG91cmx5PC9jaGFuZ2VmcmVxPlxuICAgIDxwcmlvcml0eT4wLjg8L3ByaW9yaXR5PlxuICA8L3VybD5cbiAgPHVybD5cbiAgICA8bG9jPiR7U0lURV9VUkx9L2ZvcnVtL3RhZ3M8L2xvYz5cbiAgICA8Y2hhbmdlZnJlcT5kYWlseTwvY2hhbmdlZnJlcT5cbiAgICA8cHJpb3JpdHk+MC41PC9wcmlvcml0eT5cbiAgPC91cmw+YDtcblxuICAgIC8vIENhdGVnb3JpZXNcbiAgICBmb3IgKGNvbnN0IGNhdCBvZiBjYXRlZ29yaWVzIHx8IFtdKSB7XG4gICAgICB4bWwgKz0gYFxuICA8dXJsPlxuICAgIDxsb2M+JHtTSVRFX1VSTH0vZm9ydW0vYy8ke2NhdC5zbHVnfTwvbG9jPlxuICAgIDxsYXN0bW9kPiR7bmV3IERhdGUoY2F0LnVwZGF0ZWRfYXQpLnRvSVNPU3RyaW5nKCl9PC9sYXN0bW9kPlxuICAgIDxjaGFuZ2VmcmVxPmRhaWx5PC9jaGFuZ2VmcmVxPlxuICAgIDxwcmlvcml0eT4wLjc8L3ByaW9yaXR5PlxuICA8L3VybD5gO1xuICAgIH1cblxuICAgIC8vIFRvcGljc1xuICAgIGZvciAoY29uc3QgdG9waWMgb2YgdG9waWNzIHx8IFtdKSB7XG4gICAgICB4bWwgKz0gYFxuICA8dXJsPlxuICAgIDxsb2M+JHtTSVRFX1VSTH0vZm9ydW0vdC8ke3RvcGljLmlkfTwvbG9jPlxuICAgIDxsYXN0bW9kPiR7bmV3IERhdGUodG9waWMudXBkYXRlZF9hdCkudG9JU09TdHJpbmcoKX08L2xhc3Rtb2Q+XG4gICAgPGNoYW5nZWZyZXE+d2Vla2x5PC9jaGFuZ2VmcmVxPlxuICAgIDxwcmlvcml0eT4wLjY8L3ByaW9yaXR5PlxuICA8L3VybD5gO1xuICAgIH1cblxuICAgIC8vIFRhZ3NcbiAgICBmb3IgKGNvbnN0IHRhZyBvZiB0YWdzIHx8IFtdKSB7XG4gICAgICB4bWwgKz0gYFxuICA8dXJsPlxuICAgIDxsb2M+JHtTSVRFX1VSTH0vZm9ydW0vdGFnLyR7ZW5jb2RlVVJJQ29tcG9uZW50KHRhZy5uYW1lKX08L2xvYz5cbiAgICA8Y2hhbmdlZnJlcT53ZWVrbHk8L2NoYW5nZWZyZXE+XG4gICAgPHByaW9yaXR5PjAuNDwvcHJpb3JpdHk+XG4gIDwvdXJsPmA7XG4gICAgfVxuXG4gICAgeG1sICs9IGBcbjwvdXJsc2V0PmA7XG5cbiAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLXNpdGVtYXBdIEdlbmVyYXRlZCBzaXRlbWFwIHdpdGggJHsoY2F0ZWdvcmllcz8ubGVuZ3RoIHx8IDApfSBjYXRlZ29yaWVzLCAkeyh0b3BpY3M/Lmxlbmd0aCB8fCAwKX0gdG9waWNzLCAkeyh0YWdzPy5sZW5ndGggfHwgMCl9IHRhZ3NgKTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoeG1sLCB7XG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIC4uLmNvcnNIZWFkZXJzLFxuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL3htbDsgY2hhcnNldD11dGYtOFwiLFxuICAgICAgICBcIkNhY2hlLUNvbnRyb2xcIjogXCJwdWJsaWMsIG1heC1hZ2U9MzYwMFwiLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiW2ZvcnVtLXNpdGVtYXBdIEVycm9yOlwiLCBlcnJvcik7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBlcnJvci5tZXNzYWdlIH0pLCB7XG4gICAgICBzdGF0dXM6IDUwMCxcbiAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgfSk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSw4Q0FBOEM7QUFFM0UsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLFdBQVc7QUFFakIsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0MsNkRBQTZEO0lBQzdELE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDaEQsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyx5QkFDUCxFQUFFLENBQUMsYUFBYSxPQUNoQixLQUFLLENBQUMsY0FBYztNQUFFLFdBQVc7SUFBTSxHQUN2QyxLQUFLLENBQUM7SUFFVCxJQUFJLGFBQWE7TUFDZixRQUFRLEtBQUssQ0FBQywwQkFBMEI7TUFDeEMsTUFBTTtJQUNSO0lBRUEsbUJBQW1CO0lBQ25CLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FDbEQsSUFBSSxDQUFDLG9CQUNMLE1BQU0sQ0FBQyxvQkFDUCxFQUFFLENBQUMsYUFBYTtJQUVuQixJQUFJLFdBQVc7TUFDYixRQUFRLEtBQUssQ0FBQyw4QkFBOEI7TUFDNUMsTUFBTTtJQUNSO0lBRUEsYUFBYTtJQUNiLE1BQU0sRUFBRSxNQUFNLElBQUksRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FDNUMsSUFBSSxDQUFDLGNBQ0wsTUFBTSxDQUFDLFFBQ1AsRUFBRSxDQUFDLGVBQWU7SUFFckIsSUFBSSxXQUFXO01BQ2IsUUFBUSxLQUFLLENBQUMsd0JBQXdCO0lBQ3hDO0lBRUEsb0JBQW9CO0lBQ3BCLElBQUksTUFBTSxDQUFDOzs7U0FHTixFQUFFLFNBQVM7Ozs7O1NBS1gsRUFBRSxTQUFTOzs7UUFHWixDQUFDO0lBRUwsYUFBYTtJQUNiLEtBQUssTUFBTSxPQUFPLGNBQWMsRUFBRSxDQUFFO01BQ2xDLE9BQU8sQ0FBQzs7U0FFTCxFQUFFLFNBQVMsU0FBUyxFQUFFLElBQUksSUFBSSxDQUFDO2FBQzNCLEVBQUUsSUFBSSxLQUFLLElBQUksVUFBVSxFQUFFLFdBQVcsR0FBRzs7O1FBRzlDLENBQUM7SUFDTDtJQUVBLFNBQVM7SUFDVCxLQUFLLE1BQU0sU0FBUyxVQUFVLEVBQUUsQ0FBRTtNQUNoQyxPQUFPLENBQUM7O1NBRUwsRUFBRSxTQUFTLFNBQVMsRUFBRSxNQUFNLEVBQUUsQ0FBQzthQUMzQixFQUFFLElBQUksS0FBSyxNQUFNLFVBQVUsRUFBRSxXQUFXLEdBQUc7OztRQUdoRCxDQUFDO0lBQ0w7SUFFQSxPQUFPO0lBQ1AsS0FBSyxNQUFNLE9BQU8sUUFBUSxFQUFFLENBQUU7TUFDNUIsT0FBTyxDQUFDOztTQUVMLEVBQUUsU0FBUyxXQUFXLEVBQUUsbUJBQW1CLElBQUksSUFBSSxFQUFFOzs7UUFHdEQsQ0FBQztJQUNMO0lBRUEsT0FBTyxDQUFDO1NBQ0gsQ0FBQztJQUVOLFFBQVEsR0FBRyxDQUFDLENBQUMsdUNBQXVDLEVBQUcsWUFBWSxVQUFVLEVBQUcsYUFBYSxFQUFHLFFBQVEsVUFBVSxFQUFHLFNBQVMsRUFBRyxNQUFNLFVBQVUsRUFBRyxLQUFLLENBQUM7SUFFMUosT0FBTyxJQUFJLFNBQVMsS0FBSztNQUN2QixTQUFTO1FBQ1AsR0FBRyxXQUFXO1FBQ2QsZ0JBQWdCO1FBQ2hCLGlCQUFpQjtNQUNuQjtJQUNGO0VBQ0YsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQywwQkFBMEI7SUFDeEMsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPLE1BQU0sT0FBTztJQUFDLElBQUk7TUFDNUQsUUFBUTtNQUNSLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFDaEU7RUFDRjtBQUNGIn0=
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // Security: Verify request comes from service role (internal calls only)
    const authHeader = req.headers.get("Authorization");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (authHeader !== `Bearer ${supabaseServiceKey}`) {
      return new Response(JSON.stringify({
        error: "Unauthorized - internal use only"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { track_id, task_id, audio_id } = await req.json();
    console.log("Get timestamped lyrics request:", {
      track_id,
      task_id,
      audio_id
    });
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    if (!SUNO_API_KEY) {
      throw new Error("SUNO_API_KEY not configured");
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), supabaseServiceKey);
    // Call Suno API to get timestamped lyrics
    const response = await fetch("https://api.sunoapi.org/api/v1/generate/get-timestamped-lyrics", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify({
        taskId: task_id,
        audioId: audio_id
      })
    });
    const result = await response.json();
    console.log("Suno Timestamped Lyrics API response:", result);
    if (result.code !== 200) {
      throw new Error(result.msg || "Failed to get timestamped lyrics");
    }
    // Store the result
    const { data: service } = await supabase.from("addon_services").select("id").eq("name", "timestamped_lyrics").maybeSingle();
    if (service && track_id) {
      await supabase.from("track_addons").insert({
        track_id,
        addon_service_id: service.id,
        status: "completed",
        result_url: JSON.stringify(result.data)
      });
    }
    return new Response(JSON.stringify({
      success: true,
      data: result.data
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in get-timestamped-lyrics:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9nZXQtdGltZXN0YW1wZWQtbHlyaWNzL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE2OC4wL2h0dHAvc2VydmVyLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIC8vIFNlY3VyaXR5OiBWZXJpZnkgcmVxdWVzdCBjb21lcyBmcm9tIHNlcnZpY2Ugcm9sZSAoaW50ZXJuYWwgY2FsbHMgb25seSlcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBcbiAgICBpZiAoYXV0aEhlYWRlciAhPT0gYEJlYXJlciAke3N1cGFiYXNlU2VydmljZUtleX1gKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZCAtIGludGVybmFsIHVzZSBvbmx5XCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB7IHRyYWNrX2lkLCB0YXNrX2lkLCBhdWRpb19pZCB9ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBcbiAgICBjb25zb2xlLmxvZyhcIkdldCB0aW1lc3RhbXBlZCBseXJpY3MgcmVxdWVzdDpcIiwgeyB0cmFja19pZCwgdGFza19pZCwgYXVkaW9faWQgfSk7XG5cbiAgICBjb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG4gICAgaWYgKCFTVU5PX0FQSV9LRVkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlNVTk9fQVBJX0tFWSBub3QgY29uZmlndXJlZFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSEsXG4gICAgICBzdXBhYmFzZVNlcnZpY2VLZXlcbiAgICApO1xuXG4gICAgLy8gQ2FsbCBTdW5vIEFQSSB0byBnZXQgdGltZXN0YW1wZWQgbHlyaWNzXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcImh0dHBzOi8vYXBpLnN1bm9hcGkub3JnL2FwaS92MS9nZW5lcmF0ZS9nZXQtdGltZXN0YW1wZWQtbHlyaWNzXCIsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NVTk9fQVBJX0tFWX1gLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGFza0lkOiB0YXNrX2lkLFxuICAgICAgICBhdWRpb0lkOiBhdWRpb19pZCxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKFwiU3VubyBUaW1lc3RhbXBlZCBMeXJpY3MgQVBJIHJlc3BvbnNlOlwiLCByZXN1bHQpO1xuXG4gICAgaWYgKHJlc3VsdC5jb2RlICE9PSAyMDApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihyZXN1bHQubXNnIHx8IFwiRmFpbGVkIHRvIGdldCB0aW1lc3RhbXBlZCBseXJpY3NcIik7XG4gICAgfVxuXG4gICAgLy8gU3RvcmUgdGhlIHJlc3VsdFxuICAgIGNvbnN0IHsgZGF0YTogc2VydmljZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiYWRkb25fc2VydmljZXNcIilcbiAgICAgIC5zZWxlY3QoXCJpZFwiKVxuICAgICAgLmVxKFwibmFtZVwiLCBcInRpbWVzdGFtcGVkX2x5cmljc1wiKVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICBpZiAoc2VydmljZSAmJiB0cmFja19pZCkge1xuICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcInRyYWNrX2FkZG9uc1wiKS5pbnNlcnQoe1xuICAgICAgICB0cmFja19pZCxcbiAgICAgICAgYWRkb25fc2VydmljZV9pZDogc2VydmljZS5pZCxcbiAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICByZXN1bHRfdXJsOiBKU09OLnN0cmluZ2lmeShyZXN1bHQuZGF0YSksXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIGRhdGE6IHJlc3VsdC5kYXRhLFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIGdldC10aW1lc3RhbXBlZC1seXJpY3M6XCIsIGVycm9yKTtcbiAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRix5RUFBeUU7SUFDekUsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFFeEMsSUFBSSxlQUFlLENBQUMsT0FBTyxFQUFFLG1CQUFtQixDQUFDLEVBQUU7TUFDakQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQW1DLElBQzNEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxHQUFHLE1BQU0sSUFBSSxJQUFJO0lBRXRELFFBQVEsR0FBRyxDQUFDLG1DQUFtQztNQUFFO01BQVU7TUFBUztJQUFTO0lBRTdFLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbEMsSUFBSSxDQUFDLGNBQWM7TUFDakIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLFdBQVcsYUFDZixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsaUJBQ2I7SUFHRiwwQ0FBMEM7SUFDMUMsTUFBTSxXQUFXLE1BQU0sTUFBTSxrRUFBa0U7TUFDN0YsUUFBUTtNQUNSLFNBQVM7UUFDUCxnQkFBZ0I7UUFDaEIsaUJBQWlCLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQztNQUMzQztNQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7UUFDbkIsUUFBUTtRQUNSLFNBQVM7TUFDWDtJQUNGO0lBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0lBQ2xDLFFBQVEsR0FBRyxDQUFDLHlDQUF5QztJQUVyRCxJQUFJLE9BQU8sSUFBSSxLQUFLLEtBQUs7TUFDdkIsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHLElBQUk7SUFDaEM7SUFFQSxtQkFBbUI7SUFDbkIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxTQUM3QixJQUFJLENBQUMsa0JBQ0wsTUFBTSxDQUFDLE1BQ1AsRUFBRSxDQUFDLFFBQVEsc0JBQ1gsV0FBVztJQUVkLElBQUksV0FBVyxVQUFVO01BQ3ZCLE1BQU0sU0FBUyxJQUFJLENBQUMsZ0JBQWdCLE1BQU0sQ0FBQztRQUN6QztRQUNBLGtCQUFrQixRQUFRLEVBQUU7UUFDNUIsUUFBUTtRQUNSLFlBQVksS0FBSyxTQUFTLENBQUMsT0FBTyxJQUFJO01BQ3hDO0lBQ0Y7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxNQUFNLE9BQU8sSUFBSTtJQUNuQixJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRXRFLEVBQUUsT0FBTyxPQUFnQjtJQUN2QixRQUFRLEtBQUssQ0FBQyxvQ0FBb0M7SUFDbEQsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFRLElBQ2hDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
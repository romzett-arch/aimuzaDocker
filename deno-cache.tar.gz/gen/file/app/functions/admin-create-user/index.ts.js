import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
/**
 * Admin-only edge function to create new users without affecting the caller's session.
 * Uses the service role key to create users server-side.
 */ Deno.serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Verify the caller is an admin
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const token = authHeader.replace("Bearer ", "");
    const { data: claims, error: claimsError } = await userClient.auth.getUser(token);
    if (claimsError || !claims.user) {
      return new Response(JSON.stringify({
        error: "Invalid token"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Check if user is admin or super_admin
    const { data: roles } = await userClient.from("user_roles").select("role").eq("user_id", claims.user.id);
    const isAdmin = roles?.some((r)=>r.role === "admin" || r.role === "super_admin");
    if (!isAdmin) {
      return new Response(JSON.stringify({
        error: "Только администраторы могут создавать пользователей"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Parse request body
    const { email, password, username } = await req.json();
    if (!email || !password) {
      return new Response(JSON.stringify({
        error: "Email и пароль обязательны"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Create user using service role (doesn't affect caller's session)
    const adminClient = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });
    const { data: newUser, error: createError } = await adminClient.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: {
        username: username || email.split("@")[0]
      }
    });
    if (createError) {
      console.error("Create user error:", createError);
      return new Response(JSON.stringify({
        error: createError.message
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Update profile with username if provided
    if (newUser.user && username) {
      await adminClient.from("profiles").update({
        username
      }).eq("user_id", newUser.user.id);
    }
    return new Response(JSON.stringify({
      success: true,
      user: {
        id: newUser.user?.id,
        email: newUser.user?.email
      }
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error:", error);
    const message = error instanceof Error ? error.message : "Internal server error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9hZG1pbi1jcmVhdGUtdXNlci9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDIuNDkuMVwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG4vKipcbiAqIEFkbWluLW9ubHkgZWRnZSBmdW5jdGlvbiB0byBjcmVhdGUgbmV3IHVzZXJzIHdpdGhvdXQgYWZmZWN0aW5nIHRoZSBjYWxsZXIncyBzZXNzaW9uLlxuICogVXNlcyB0aGUgc2VydmljZSByb2xlIGtleSB0byBjcmVhdGUgdXNlcnMgc2VydmVyLXNpZGUuXG4gKi9cbkRlbm8uc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcj8uc3RhcnRzV2l0aChcIkJlYXJlciBcIikpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBWZXJpZnkgdGhlIGNhbGxlciBpcyBhbiBhZG1pblxuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZUFub25LZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG5cbiAgICBjb25zdCB1c2VyQ2xpZW50ID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZUFub25LZXksIHtcbiAgICAgIGdsb2JhbDogeyBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGF1dGhIZWFkZXIgfSB9XG4gICAgfSk7XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgY29uc3QgeyBkYXRhOiBjbGFpbXMsIGVycm9yOiBjbGFpbXNFcnJvciB9ID0gYXdhaXQgdXNlckNsaWVudC5hdXRoLmdldFVzZXIodG9rZW4pO1xuICAgIFxuICAgIGlmIChjbGFpbXNFcnJvciB8fCAhY2xhaW1zLnVzZXIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiSW52YWxpZCB0b2tlblwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgaWYgdXNlciBpcyBhZG1pbiBvciBzdXBlcl9hZG1pblxuICAgIGNvbnN0IHsgZGF0YTogcm9sZXMgfSA9IGF3YWl0IHVzZXJDbGllbnRcbiAgICAgIC5mcm9tKFwidXNlcl9yb2xlc1wiKVxuICAgICAgLnNlbGVjdChcInJvbGVcIilcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgY2xhaW1zLnVzZXIuaWQpO1xuXG4gICAgY29uc3QgaXNBZG1pbiA9IHJvbGVzPy5zb21lKHIgPT4gci5yb2xlID09PSBcImFkbWluXCIgfHwgci5yb2xlID09PSBcInN1cGVyX2FkbWluXCIpO1xuICAgIGlmICghaXNBZG1pbikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQotC+0LvRjNC60L4g0LDQtNC80LjQvdC40YHRgtGA0LDRgtC+0YDRiyDQvNC+0LPRg9GCINGB0L7Qt9C00LDQstCw0YLRjCDQv9C+0LvRjNC30L7QstCw0YLQtdC70LXQuVwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gUGFyc2UgcmVxdWVzdCBib2R5XG4gICAgY29uc3QgeyBlbWFpbCwgcGFzc3dvcmQsIHVzZXJuYW1lIH0gPSBhd2FpdCByZXEuanNvbigpO1xuXG4gICAgaWYgKCFlbWFpbCB8fCAhcGFzc3dvcmQpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiRW1haWwg0Lgg0L/QsNGA0L7Qu9GMINC+0LHRj9C30LDRgtC10LvRjNC90YtcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZSB1c2VyIHVzaW5nIHNlcnZpY2Ugcm9sZSAoZG9lc24ndCBhZmZlY3QgY2FsbGVyJ3Mgc2Vzc2lvbilcbiAgICBjb25zdCBhZG1pbkNsaWVudCA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5LCB7XG4gICAgICBhdXRoOiB7IGF1dG9SZWZyZXNoVG9rZW46IGZhbHNlLCBwZXJzaXN0U2Vzc2lvbjogZmFsc2UgfVxuICAgIH0pO1xuXG4gICAgY29uc3QgeyBkYXRhOiBuZXdVc2VyLCBlcnJvcjogY3JlYXRlRXJyb3IgfSA9IGF3YWl0IGFkbWluQ2xpZW50LmF1dGguYWRtaW4uY3JlYXRlVXNlcih7XG4gICAgICBlbWFpbCxcbiAgICAgIHBhc3N3b3JkLFxuICAgICAgZW1haWxfY29uZmlybTogdHJ1ZSwgLy8gQXV0by1jb25maXJtIGVtYWlsXG4gICAgICB1c2VyX21ldGFkYXRhOiB7IHVzZXJuYW1lOiB1c2VybmFtZSB8fCBlbWFpbC5zcGxpdChcIkBcIilbMF0gfVxuICAgIH0pO1xuXG4gICAgaWYgKGNyZWF0ZUVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiQ3JlYXRlIHVzZXIgZXJyb3I6XCIsIGNyZWF0ZUVycm9yKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGNyZWF0ZUVycm9yLm1lc3NhZ2UgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBVcGRhdGUgcHJvZmlsZSB3aXRoIHVzZXJuYW1lIGlmIHByb3ZpZGVkXG4gICAgaWYgKG5ld1VzZXIudXNlciAmJiB1c2VybmFtZSkge1xuICAgICAgYXdhaXQgYWRtaW5DbGllbnRcbiAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAudXBkYXRlKHsgdXNlcm5hbWUgfSlcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCBuZXdVc2VyLnVzZXIuaWQpO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgdXNlcjogeyBpZDogbmV3VXNlci51c2VyPy5pZCwgZW1haWw6IG5ld1VzZXIudXNlcj8uZW1haWwgfSBcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yOlwiLCBlcnJvcik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJJbnRlcm5hbCBzZXJ2ZXIgZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsWUFBWSxRQUFRLDhDQUE4QztBQUUzRSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBOzs7Q0FHQyxHQUNELEtBQUssS0FBSyxDQUFDLE9BQU87RUFDaEIsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWSxXQUFXLFlBQVk7TUFDdEMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWUsSUFDdkM7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsZ0NBQWdDO0lBQ2hDLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDakMsTUFBTSxrQkFBa0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ3JDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUV4QyxNQUFNLGFBQWEsYUFBYSxhQUFhLGlCQUFpQjtNQUM1RCxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQ25EO0lBRUEsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxXQUFXLElBQUksQ0FBQyxPQUFPLENBQUM7SUFFM0UsSUFBSSxlQUFlLENBQUMsT0FBTyxJQUFJLEVBQUU7TUFDL0IsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWdCLElBQ3hDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLHdDQUF3QztJQUN4QyxNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsR0FBRyxNQUFNLFdBQzNCLElBQUksQ0FBQyxjQUNMLE1BQU0sQ0FBQyxRQUNQLEVBQUUsQ0FBQyxXQUFXLE9BQU8sSUFBSSxDQUFDLEVBQUU7SUFFL0IsTUFBTSxVQUFVLE9BQU8sS0FBSyxDQUFBLElBQUssRUFBRSxJQUFJLEtBQUssV0FBVyxFQUFFLElBQUksS0FBSztJQUNsRSxJQUFJLENBQUMsU0FBUztNQUNaLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFzRCxJQUM5RTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxxQkFBcUI7SUFDckIsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEdBQUcsTUFBTSxJQUFJLElBQUk7SUFFcEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVO01BQ3ZCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE2QixJQUNyRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxtRUFBbUU7SUFDbkUsTUFBTSxjQUFjLGFBQWEsYUFBYSxvQkFBb0I7TUFDaEUsTUFBTTtRQUFFLGtCQUFrQjtRQUFPLGdCQUFnQjtNQUFNO0lBQ3pEO0lBRUEsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxZQUFZLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDO01BQ3BGO01BQ0E7TUFDQSxlQUFlO01BQ2YsZUFBZTtRQUFFLFVBQVUsWUFBWSxNQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRTtNQUFDO0lBQzdEO0lBRUEsSUFBSSxhQUFhO01BQ2YsUUFBUSxLQUFLLENBQUMsc0JBQXNCO01BQ3BDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTyxZQUFZLE9BQU87TUFBQyxJQUM1QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSwyQ0FBMkM7SUFDM0MsSUFBSSxRQUFRLElBQUksSUFBSSxVQUFVO01BQzVCLE1BQU0sWUFDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7UUFBRTtNQUFTLEdBQ2xCLEVBQUUsQ0FBQyxXQUFXLFFBQVEsSUFBSSxDQUFDLEVBQUU7SUFDbEM7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxNQUFNO1FBQUUsSUFBSSxRQUFRLElBQUksRUFBRTtRQUFJLE9BQU8sUUFBUSxJQUFJLEVBQUU7TUFBTTtJQUMzRCxJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFnQjtJQUN2QixRQUFRLEtBQUssQ0FBQyxVQUFVO0lBQ3hCLE1BQU0sVUFBVSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUN6RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBUSxJQUNoQztNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRiJ9
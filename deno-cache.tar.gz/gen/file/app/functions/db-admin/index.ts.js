import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
// SHA-256 hash function
async function sha256(message) {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b)=>b.toString(16).padStart(2, '0')).join('');
}
// Verify super_admin and PIN
async function verifySuperAdminAndPin(authHeader, pin, supabaseUrl, supabaseServiceKey, supabaseAnonKey) {
  if (!authHeader?.startsWith('Bearer ')) {
    return {
      success: false,
      error: 'Unauthorized'
    };
  }
  if (!pin || typeof pin !== 'string' || pin.length !== 6) {
    return {
      success: false,
      error: 'Требуется 6-значный PIN-код'
    };
  }
  const userClient = createClient(supabaseUrl, supabaseAnonKey, {
    global: {
      headers: {
        Authorization: authHeader
      }
    }
  });
  const token = authHeader.replace('Bearer ', '');
  const { data: claims, error: claimsError } = await userClient.auth.getClaims(token);
  if (claimsError || !claims?.claims) {
    return {
      success: false,
      error: 'Invalid token'
    };
  }
  const userId = claims.claims.sub;
  const adminClient = createClient(supabaseUrl, supabaseServiceKey);
  // Check super_admin role
  const { data: userRole } = await adminClient.from('user_roles').select('role').eq('user_id', userId).single();
  if (!userRole || userRole.role !== 'super_admin') {
    return {
      success: false,
      error: 'Доступ запрещён. Только для super_admin.'
    };
  }
  // Verify PIN
  const { data: pinSetting } = await adminClient.from('settings').select('value').eq('key', 'backup_pin_hash').single();
  if (!pinSetting?.value) {
    return {
      success: false,
      error: 'PIN-код не настроен'
    };
  }
  const pinHash = await sha256(pin);
  if (pinHash !== pinSetting.value) {
    return {
      success: false,
      error: 'Неверный PIN-код'
    };
  }
  return {
    success: true,
    userId
  };
}
Deno.serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get('Authorization');
    const body = await req.json().catch(()=>({}));
    const { pin, action, table, data, id, query, limit = 100, offset = 0 } = body;
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY');
    // Verify access
    const verification = await verifySuperAdminAndPin(authHeader || '', pin, supabaseUrl, supabaseServiceKey, supabaseAnonKey);
    if (!verification.success) {
      return new Response(JSON.stringify({
        error: verification.error
      }), {
        status: verification.error === 'Unauthorized' ? 401 : 403,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);
    console.log(`DB Admin action: ${action} by super_admin: ${verification.userId}`);
    switch(action){
      case 'list_tables':
        {
          // Get list of public tables
          const { data: tables, error } = await adminClient.from('information_schema.tables').select('table_name').eq('table_schema', 'public').eq('table_type', 'BASE TABLE');
          if (error) {
            // Fallback: return predefined list
            const knownTables = [
              'profiles',
              'tracks',
              'genres',
              'genre_categories',
              'ai_models',
              'vocal_types',
              'templates',
              'artist_styles',
              'addon_services',
              'user_prompts',
              'generated_lyrics',
              'lyrics_items',
              'playlists',
              'playlist_tracks',
              'track_likes',
              'track_comments',
              'user_follows',
              'payments',
              'subscriptions',
              'subscription_plans',
              'user_roles',
              'settings',
              'notifications',
              'contests',
              'contest_entries',
              'achievements',
              'user_achievements',
              'referral_codes',
              'referrals',
              'store_items',
              'item_purchases',
              'support_tickets',
              'ticket_messages',
              'conversations',
              'messages',
              'user_blocks',
              'error_logs',
              'performance_alerts',
              'role_change_logs',
              'security_audit_log'
            ];
            return new Response(JSON.stringify({
              tables: knownTables
            }), {
              headers: {
                ...corsHeaders,
                'Content-Type': 'application/json'
              }
            });
          }
          return new Response(JSON.stringify({
            tables: tables?.map((t)=>t.table_name) || []
          }), {
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json'
            }
          });
        }
      case 'get_table_data':
        {
          if (!table) {
            return new Response(JSON.stringify({
              error: 'Table name required'
            }), {
              status: 400,
              headers: {
                ...corsHeaders,
                'Content-Type': 'application/json'
              }
            });
          }
          // Get count
          const { count } = await adminClient.from(table).select('*', {
            count: 'exact',
            head: true
          });
          // Get data with pagination
          const { data: rows, error } = await adminClient.from(table).select('*').range(offset, offset + limit - 1).order('created_at', {
            ascending: false,
            nullsFirst: false
          });
          if (error) {
            return new Response(JSON.stringify({
              error: error.message
            }), {
              status: 400,
              headers: {
                ...corsHeaders,
                'Content-Type': 'application/json'
              }
            });
          }
          return new Response(JSON.stringify({
            data: rows || [],
            count: count || 0,
            limit,
            offset
          }), {
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json'
            }
          });
        }
      case 'update_row':
        {
          if (!table || !id || !data) {
            return new Response(JSON.stringify({
              error: 'Table, id, and data required'
            }), {
              status: 400,
              headers: {
                ...corsHeaders,
                'Content-Type': 'application/json'
              }
            });
          }
          const { error } = await adminClient.from(table).update(data).eq('id', id);
          if (error) {
            return new Response(JSON.stringify({
              error: error.message
            }), {
              status: 400,
              headers: {
                ...corsHeaders,
                'Content-Type': 'application/json'
              }
            });
          }
          console.log(`Updated row ${id} in ${table}`);
          return new Response(JSON.stringify({
            success: true
          }), {
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json'
            }
          });
        }
      case 'delete_row':
        {
          if (!table || !id) {
            return new Response(JSON.stringify({
              error: 'Table and id required'
            }), {
              status: 400,
              headers: {
                ...corsHeaders,
                'Content-Type': 'application/json'
              }
            });
          }
          const { error } = await adminClient.from(table).delete().eq('id', id);
          if (error) {
            return new Response(JSON.stringify({
              error: error.message
            }), {
              status: 400,
              headers: {
                ...corsHeaders,
                'Content-Type': 'application/json'
              }
            });
          }
          console.log(`Deleted row ${id} from ${table}`);
          return new Response(JSON.stringify({
            success: true
          }), {
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json'
            }
          });
        }
      case 'insert_row':
        {
          if (!table || !data) {
            return new Response(JSON.stringify({
              error: 'Table and data required'
            }), {
              status: 400,
              headers: {
                ...corsHeaders,
                'Content-Type': 'application/json'
              }
            });
          }
          const { data: inserted, error } = await adminClient.from(table).insert(data).select().single();
          if (error) {
            return new Response(JSON.stringify({
              error: error.message
            }), {
              status: 400,
              headers: {
                ...corsHeaders,
                'Content-Type': 'application/json'
              }
            });
          }
          console.log(`Inserted row in ${table}`);
          return new Response(JSON.stringify({
            success: true,
            data: inserted
          }), {
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json'
            }
          });
        }
      case 'export_table':
        {
          if (!table) {
            return new Response(JSON.stringify({
              error: 'Table name required'
            }), {
              status: 400,
              headers: {
                ...corsHeaders,
                'Content-Type': 'application/json'
              }
            });
          }
          const { data: rows, error } = await adminClient.from(table).select('*').limit(50000);
          if (error) {
            return new Response(JSON.stringify({
              error: error.message
            }), {
              status: 400,
              headers: {
                ...corsHeaders,
                'Content-Type': 'application/json'
              }
            });
          }
          return new Response(JSON.stringify({
            table,
            count: rows?.length || 0,
            data: rows || []
          }), {
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json'
            }
          });
        }
      case 'export_all':
        {
          const knownTables = [
            'profiles',
            'tracks',
            'genres',
            'genre_categories',
            'ai_models',
            'vocal_types',
            'templates',
            'artist_styles',
            'addon_services',
            'user_prompts',
            'generated_lyrics',
            'lyrics_items',
            'playlists',
            'playlist_tracks',
            'track_likes',
            'track_comments',
            'user_follows',
            'payments',
            'subscriptions',
            'subscription_plans',
            'user_roles',
            'settings',
            'notifications',
            'contests',
            'contest_entries',
            'achievements',
            'user_achievements',
            'referral_codes',
            'referrals',
            'store_items',
            'item_purchases'
          ];
          const exportData = {
            exported_at: new Date().toISOString(),
            exported_by: verification.userId,
            tables: {}
          };
          for (const tableName of knownTables){
            try {
              const { data: rows } = await adminClient.from(tableName).select('*').limit(10000);
              exportData.tables[tableName] = {
                count: rows?.length || 0,
                data: rows || []
              };
            } catch  {
              exportData.tables[tableName] = {
                error: 'Failed to export',
                count: 0
              };
            }
          }
          return new Response(JSON.stringify(exportData, null, 2), {
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json'
            }
          });
        }
      default:
        return new Response(JSON.stringify({
          error: 'Unknown action'
        }), {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error('DB Admin error:', errorMessage);
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9kYi1hZG1pbi9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ2F1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlJyxcbn07XG5cbi8vIFNIQS0yNTYgaGFzaCBmdW5jdGlvblxuYXN5bmMgZnVuY3Rpb24gc2hhMjU2KG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IG1zZ0J1ZmZlciA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShtZXNzYWdlKTtcbiAgY29uc3QgaGFzaEJ1ZmZlciA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgbXNnQnVmZmVyKTtcbiAgY29uc3QgaGFzaEFycmF5ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShoYXNoQnVmZmVyKSk7XG4gIHJldHVybiBoYXNoQXJyYXkubWFwKGIgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSkuam9pbignJyk7XG59XG5cbi8vIFZlcmlmeSBzdXBlcl9hZG1pbiBhbmQgUElOXG5hc3luYyBmdW5jdGlvbiB2ZXJpZnlTdXBlckFkbWluQW5kUGluKFxuICBhdXRoSGVhZGVyOiBzdHJpbmcsXG4gIHBpbjogc3RyaW5nLFxuICBzdXBhYmFzZVVybDogc3RyaW5nLFxuICBzdXBhYmFzZVNlcnZpY2VLZXk6IHN0cmluZyxcbiAgc3VwYWJhc2VBbm9uS2V5OiBzdHJpbmdcbik6IFByb21pc2U8eyBzdWNjZXNzOiBib29sZWFuOyBlcnJvcj86IHN0cmluZzsgdXNlcklkPzogc3RyaW5nIH0+IHtcbiAgaWYgKCFhdXRoSGVhZGVyPy5zdGFydHNXaXRoKCdCZWFyZXIgJykpIHtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdVbmF1dGhvcml6ZWQnIH07XG4gIH1cblxuICBpZiAoIXBpbiB8fCB0eXBlb2YgcGluICE9PSAnc3RyaW5nJyB8fCBwaW4ubGVuZ3RoICE9PSA2KSB7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAn0KLRgNC10LHRg9C10YLRgdGPIDYt0LfQvdCw0YfQvdGL0LkgUElOLdC60L7QtCcgfTtcbiAgfVxuXG4gIGNvbnN0IHVzZXJDbGllbnQgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlQW5vbktleSwge1xuICAgIGdsb2JhbDogeyBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGF1dGhIZWFkZXIgfSB9XG4gIH0pO1xuXG4gIGNvbnN0IHRva2VuID0gYXV0aEhlYWRlci5yZXBsYWNlKCdCZWFyZXIgJywgJycpO1xuICBjb25zdCB7IGRhdGE6IGNsYWltcywgZXJyb3I6IGNsYWltc0Vycm9yIH0gPSBhd2FpdCB1c2VyQ2xpZW50LmF1dGguZ2V0Q2xhaW1zKHRva2VuKTtcbiAgXG4gIGlmIChjbGFpbXNFcnJvciB8fCAhY2xhaW1zPy5jbGFpbXMpIHtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdJbnZhbGlkIHRva2VuJyB9O1xuICB9XG5cbiAgY29uc3QgdXNlcklkID0gY2xhaW1zLmNsYWltcy5zdWIgYXMgc3RyaW5nO1xuICBjb25zdCBhZG1pbkNsaWVudCA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAvLyBDaGVjayBzdXBlcl9hZG1pbiByb2xlXG4gIGNvbnN0IHsgZGF0YTogdXNlclJvbGUgfSA9IGF3YWl0IGFkbWluQ2xpZW50XG4gICAgLmZyb20oJ3VzZXJfcm9sZXMnKVxuICAgIC5zZWxlY3QoJ3JvbGUnKVxuICAgIC5lcSgndXNlcl9pZCcsIHVzZXJJZClcbiAgICAuc2luZ2xlKCk7XG5cbiAgaWYgKCF1c2VyUm9sZSB8fCB1c2VyUm9sZS5yb2xlICE9PSAnc3VwZXJfYWRtaW4nKSB7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAn0JTQvtGB0YLRg9C/INC30LDQv9GA0LXRidGR0L0uINCi0L7Qu9GM0LrQviDQtNC70Y8gc3VwZXJfYWRtaW4uJyB9O1xuICB9XG5cbiAgLy8gVmVyaWZ5IFBJTlxuICBjb25zdCB7IGRhdGE6IHBpblNldHRpbmcgfSA9IGF3YWl0IGFkbWluQ2xpZW50XG4gICAgLmZyb20oJ3NldHRpbmdzJylcbiAgICAuc2VsZWN0KCd2YWx1ZScpXG4gICAgLmVxKCdrZXknLCAnYmFja3VwX3Bpbl9oYXNoJylcbiAgICAuc2luZ2xlKCk7XG5cbiAgaWYgKCFwaW5TZXR0aW5nPy52YWx1ZSkge1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ1BJTi3QutC+0LQg0L3QtSDQvdCw0YHRgtGA0L7QtdC9JyB9O1xuICB9XG5cbiAgY29uc3QgcGluSGFzaCA9IGF3YWl0IHNoYTI1NihwaW4pO1xuICBpZiAocGluSGFzaCAhPT0gcGluU2V0dGluZy52YWx1ZSkge1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ9Cd0LXQstC10YDQvdGL0LkgUElOLdC60L7QtCcgfTtcbiAgfVxuXG4gIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIHVzZXJJZCB9O1xufVxuXG5EZW5vLnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09ICdPUFRJT05TJykge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoJ29rJywgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldCgnQXV0aG9yaXphdGlvbicpO1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXEuanNvbigpLmNhdGNoKCgpID0+ICh7fSkpO1xuICAgIGNvbnN0IHsgcGluLCBhY3Rpb24sIHRhYmxlLCBkYXRhLCBpZCwgcXVlcnksIGxpbWl0ID0gMTAwLCBvZmZzZXQgPSAwIH0gPSBib2R5O1xuXG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoJ1NVUEFCQVNFX1VSTCcpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoJ1NVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVknKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VBbm9uS2V5ID0gRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9BTk9OX0tFWScpITtcblxuICAgIC8vIFZlcmlmeSBhY2Nlc3NcbiAgICBjb25zdCB2ZXJpZmljYXRpb24gPSBhd2FpdCB2ZXJpZnlTdXBlckFkbWluQW5kUGluKFxuICAgICAgYXV0aEhlYWRlciB8fCAnJyxcbiAgICAgIHBpbixcbiAgICAgIHN1cGFiYXNlVXJsLFxuICAgICAgc3VwYWJhc2VTZXJ2aWNlS2V5LFxuICAgICAgc3VwYWJhc2VBbm9uS2V5XG4gICAgKTtcblxuICAgIGlmICghdmVyaWZpY2F0aW9uLnN1Y2Nlc3MpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IHZlcmlmaWNhdGlvbi5lcnJvciB9KSxcbiAgICAgICAgeyBzdGF0dXM6IHZlcmlmaWNhdGlvbi5lcnJvciA9PT0gJ1VuYXV0aG9yaXplZCcgPyA0MDEgOiA0MDMsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGFkbWluQ2xpZW50ID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuICAgIGNvbnNvbGUubG9nKGBEQiBBZG1pbiBhY3Rpb246ICR7YWN0aW9ufSBieSBzdXBlcl9hZG1pbjogJHt2ZXJpZmljYXRpb24udXNlcklkfWApO1xuXG4gICAgc3dpdGNoIChhY3Rpb24pIHtcbiAgICAgIGNhc2UgJ2xpc3RfdGFibGVzJzoge1xuICAgICAgICAvLyBHZXQgbGlzdCBvZiBwdWJsaWMgdGFibGVzXG4gICAgICAgIGNvbnN0IHsgZGF0YTogdGFibGVzLCBlcnJvciB9ID0gYXdhaXQgYWRtaW5DbGllbnRcbiAgICAgICAgICAuZnJvbSgnaW5mb3JtYXRpb25fc2NoZW1hLnRhYmxlcycgYXMgYW55KVxuICAgICAgICAgIC5zZWxlY3QoJ3RhYmxlX25hbWUnKVxuICAgICAgICAgIC5lcSgndGFibGVfc2NoZW1hJywgJ3B1YmxpYycpXG4gICAgICAgICAgLmVxKCd0YWJsZV90eXBlJywgJ0JBU0UgVEFCTEUnKTtcblxuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAvLyBGYWxsYmFjazogcmV0dXJuIHByZWRlZmluZWQgbGlzdFxuICAgICAgICAgIGNvbnN0IGtub3duVGFibGVzID0gW1xuICAgICAgICAgICAgJ3Byb2ZpbGVzJywgJ3RyYWNrcycsICdnZW5yZXMnLCAnZ2VucmVfY2F0ZWdvcmllcycsICdhaV9tb2RlbHMnLFxuICAgICAgICAgICAgJ3ZvY2FsX3R5cGVzJywgJ3RlbXBsYXRlcycsICdhcnRpc3Rfc3R5bGVzJywgJ2FkZG9uX3NlcnZpY2VzJyxcbiAgICAgICAgICAgICd1c2VyX3Byb21wdHMnLCAnZ2VuZXJhdGVkX2x5cmljcycsICdseXJpY3NfaXRlbXMnLCAncGxheWxpc3RzJyxcbiAgICAgICAgICAgICdwbGF5bGlzdF90cmFja3MnLCAndHJhY2tfbGlrZXMnLCAndHJhY2tfY29tbWVudHMnLCAndXNlcl9mb2xsb3dzJyxcbiAgICAgICAgICAgICdwYXltZW50cycsICdzdWJzY3JpcHRpb25zJywgJ3N1YnNjcmlwdGlvbl9wbGFucycsICd1c2VyX3JvbGVzJyxcbiAgICAgICAgICAgICdzZXR0aW5ncycsICdub3RpZmljYXRpb25zJywgJ2NvbnRlc3RzJywgJ2NvbnRlc3RfZW50cmllcycsXG4gICAgICAgICAgICAnYWNoaWV2ZW1lbnRzJywgJ3VzZXJfYWNoaWV2ZW1lbnRzJywgJ3JlZmVycmFsX2NvZGVzJywgJ3JlZmVycmFscycsXG4gICAgICAgICAgICAnc3RvcmVfaXRlbXMnLCAnaXRlbV9wdXJjaGFzZXMnLCAnc3VwcG9ydF90aWNrZXRzJywgJ3RpY2tldF9tZXNzYWdlcycsXG4gICAgICAgICAgICAnY29udmVyc2F0aW9ucycsICdtZXNzYWdlcycsICd1c2VyX2Jsb2NrcycsICdlcnJvcl9sb2dzJyxcbiAgICAgICAgICAgICdwZXJmb3JtYW5jZV9hbGVydHMnLCAncm9sZV9jaGFuZ2VfbG9ncycsICdzZWN1cml0eV9hdWRpdF9sb2cnXG4gICAgICAgICAgXTtcbiAgICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyB0YWJsZXM6IGtub3duVGFibGVzIH0pLFxuICAgICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgdGFibGVzOiB0YWJsZXM/Lm1hcCgodDogYW55KSA9PiB0LnRhYmxlX25hbWUpIHx8IFtdIH0pLFxuICAgICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgY2FzZSAnZ2V0X3RhYmxlX2RhdGEnOiB7XG4gICAgICAgIGlmICghdGFibGUpIHtcbiAgICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ1RhYmxlIG5hbWUgcmVxdWlyZWQnIH0pLFxuICAgICAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gR2V0IGNvdW50XG4gICAgICAgIGNvbnN0IHsgY291bnQgfSA9IGF3YWl0IGFkbWluQ2xpZW50XG4gICAgICAgICAgLmZyb20odGFibGUpXG4gICAgICAgICAgLnNlbGVjdCgnKicsIHsgY291bnQ6ICdleGFjdCcsIGhlYWQ6IHRydWUgfSk7XG5cbiAgICAgICAgLy8gR2V0IGRhdGEgd2l0aCBwYWdpbmF0aW9uXG4gICAgICAgIGNvbnN0IHsgZGF0YTogcm93cywgZXJyb3IgfSA9IGF3YWl0IGFkbWluQ2xpZW50XG4gICAgICAgICAgLmZyb20odGFibGUpXG4gICAgICAgICAgLnNlbGVjdCgnKicpXG4gICAgICAgICAgLnJhbmdlKG9mZnNldCwgb2Zmc2V0ICsgbGltaXQgLSAxKVxuICAgICAgICAgIC5vcmRlcignY3JlYXRlZF9hdCcsIHsgYXNjZW5kaW5nOiBmYWxzZSwgbnVsbHNGaXJzdDogZmFsc2UgfSk7XG5cbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfSksXG4gICAgICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZGF0YTogcm93cyB8fCBbXSwgY291bnQ6IGNvdW50IHx8IDAsIGxpbWl0LCBvZmZzZXQgfSksXG4gICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBjYXNlICd1cGRhdGVfcm93Jzoge1xuICAgICAgICBpZiAoIXRhYmxlIHx8ICFpZCB8fCAhZGF0YSkge1xuICAgICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAnVGFibGUsIGlkLCBhbmQgZGF0YSByZXF1aXJlZCcgfSksXG4gICAgICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBhZG1pbkNsaWVudFxuICAgICAgICAgIC5mcm9tKHRhYmxlKVxuICAgICAgICAgIC51cGRhdGUoZGF0YSlcbiAgICAgICAgICAuZXEoJ2lkJywgaWQpO1xuXG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBlcnJvci5tZXNzYWdlIH0pLFxuICAgICAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgcm93ICR7aWR9IGluICR7dGFibGV9YCk7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiB0cnVlIH0pLFxuICAgICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgY2FzZSAnZGVsZXRlX3Jvdyc6IHtcbiAgICAgICAgaWYgKCF0YWJsZSB8fCAhaWQpIHtcbiAgICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ1RhYmxlIGFuZCBpZCByZXF1aXJlZCcgfSksXG4gICAgICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBhZG1pbkNsaWVudFxuICAgICAgICAgIC5mcm9tKHRhYmxlKVxuICAgICAgICAgIC5kZWxldGUoKVxuICAgICAgICAgIC5lcSgnaWQnLCBpZCk7XG5cbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfSksXG4gICAgICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zb2xlLmxvZyhgRGVsZXRlZCByb3cgJHtpZH0gZnJvbSAke3RhYmxlfWApO1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGNhc2UgJ2luc2VydF9yb3cnOiB7XG4gICAgICAgIGlmICghdGFibGUgfHwgIWRhdGEpIHtcbiAgICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ1RhYmxlIGFuZCBkYXRhIHJlcXVpcmVkJyB9KSxcbiAgICAgICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHsgZGF0YTogaW5zZXJ0ZWQsIGVycm9yIH0gPSBhd2FpdCBhZG1pbkNsaWVudFxuICAgICAgICAgIC5mcm9tKHRhYmxlKVxuICAgICAgICAgIC5pbnNlcnQoZGF0YSlcbiAgICAgICAgICAuc2VsZWN0KClcbiAgICAgICAgICAuc2luZ2xlKCk7XG5cbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfSksXG4gICAgICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zb2xlLmxvZyhgSW5zZXJ0ZWQgcm93IGluICR7dGFibGV9YCk7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiB0cnVlLCBkYXRhOiBpbnNlcnRlZCB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGNhc2UgJ2V4cG9ydF90YWJsZSc6IHtcbiAgICAgICAgaWYgKCF0YWJsZSkge1xuICAgICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAnVGFibGUgbmFtZSByZXF1aXJlZCcgfSksXG4gICAgICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB7IGRhdGE6IHJvd3MsIGVycm9yIH0gPSBhd2FpdCBhZG1pbkNsaWVudFxuICAgICAgICAgIC5mcm9tKHRhYmxlKVxuICAgICAgICAgIC5zZWxlY3QoJyonKVxuICAgICAgICAgIC5saW1pdCg1MDAwMCk7XG5cbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfSksXG4gICAgICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgdGFibGUsIGNvdW50OiByb3dzPy5sZW5ndGggfHwgMCwgZGF0YTogcm93cyB8fCBbXSB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGNhc2UgJ2V4cG9ydF9hbGwnOiB7XG4gICAgICAgIGNvbnN0IGtub3duVGFibGVzID0gW1xuICAgICAgICAgICdwcm9maWxlcycsICd0cmFja3MnLCAnZ2VucmVzJywgJ2dlbnJlX2NhdGVnb3JpZXMnLCAnYWlfbW9kZWxzJyxcbiAgICAgICAgICAndm9jYWxfdHlwZXMnLCAndGVtcGxhdGVzJywgJ2FydGlzdF9zdHlsZXMnLCAnYWRkb25fc2VydmljZXMnLFxuICAgICAgICAgICd1c2VyX3Byb21wdHMnLCAnZ2VuZXJhdGVkX2x5cmljcycsICdseXJpY3NfaXRlbXMnLCAncGxheWxpc3RzJyxcbiAgICAgICAgICAncGxheWxpc3RfdHJhY2tzJywgJ3RyYWNrX2xpa2VzJywgJ3RyYWNrX2NvbW1lbnRzJywgJ3VzZXJfZm9sbG93cycsXG4gICAgICAgICAgJ3BheW1lbnRzJywgJ3N1YnNjcmlwdGlvbnMnLCAnc3Vic2NyaXB0aW9uX3BsYW5zJywgJ3VzZXJfcm9sZXMnLFxuICAgICAgICAgICdzZXR0aW5ncycsICdub3RpZmljYXRpb25zJywgJ2NvbnRlc3RzJywgJ2NvbnRlc3RfZW50cmllcycsXG4gICAgICAgICAgJ2FjaGlldmVtZW50cycsICd1c2VyX2FjaGlldmVtZW50cycsICdyZWZlcnJhbF9jb2RlcycsICdyZWZlcnJhbHMnLFxuICAgICAgICAgICdzdG9yZV9pdGVtcycsICdpdGVtX3B1cmNoYXNlcydcbiAgICAgICAgXTtcblxuICAgICAgICBjb25zdCBleHBvcnREYXRhOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHtcbiAgICAgICAgICBleHBvcnRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIGV4cG9ydGVkX2J5OiB2ZXJpZmljYXRpb24udXNlcklkLFxuICAgICAgICAgIHRhYmxlczoge31cbiAgICAgICAgfTtcblxuICAgICAgICBmb3IgKGNvbnN0IHRhYmxlTmFtZSBvZiBrbm93blRhYmxlcykge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCB7IGRhdGE6IHJvd3MgfSA9IGF3YWl0IGFkbWluQ2xpZW50XG4gICAgICAgICAgICAgIC5mcm9tKHRhYmxlTmFtZSlcbiAgICAgICAgICAgICAgLnNlbGVjdCgnKicpXG4gICAgICAgICAgICAgIC5saW1pdCgxMDAwMCk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIChleHBvcnREYXRhLnRhYmxlcyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilbdGFibGVOYW1lXSA9IHtcbiAgICAgICAgICAgICAgY291bnQ6IHJvd3M/Lmxlbmd0aCB8fCAwLFxuICAgICAgICAgICAgICBkYXRhOiByb3dzIHx8IFtdXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgKGV4cG9ydERhdGEudGFibGVzIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVt0YWJsZU5hbWVdID0geyBlcnJvcjogJ0ZhaWxlZCB0byBleHBvcnQnLCBjb3VudDogMCB9O1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoZXhwb3J0RGF0YSwgbnVsbCwgMiksXG4gICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICdVbmtub3duIGFjdGlvbicgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICAgKTtcbiAgICB9XG5cbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFN0cmluZyhlcnJvcik7XG4gICAgY29uc29sZS5lcnJvcignREIgQWRtaW4gZXJyb3I6JywgZXJyb3JNZXNzYWdlKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogZXJyb3JNZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSx3QkFBd0I7QUFDeEIsZUFBZSxPQUFPLE9BQWU7RUFDbkMsTUFBTSxZQUFZLElBQUksY0FBYyxNQUFNLENBQUM7RUFDM0MsTUFBTSxhQUFhLE1BQU0sT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVc7RUFDekQsTUFBTSxZQUFZLE1BQU0sSUFBSSxDQUFDLElBQUksV0FBVztFQUM1QyxPQUFPLFVBQVUsR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBQ2xFO0FBRUEsNkJBQTZCO0FBQzdCLGVBQWUsdUJBQ2IsVUFBa0IsRUFDbEIsR0FBVyxFQUNYLFdBQW1CLEVBQ25CLGtCQUEwQixFQUMxQixlQUF1QjtFQUV2QixJQUFJLENBQUMsWUFBWSxXQUFXLFlBQVk7SUFDdEMsT0FBTztNQUFFLFNBQVM7TUFBTyxPQUFPO0lBQWU7RUFDakQ7RUFFQSxJQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsWUFBWSxJQUFJLE1BQU0sS0FBSyxHQUFHO0lBQ3ZELE9BQU87TUFBRSxTQUFTO01BQU8sT0FBTztJQUE4QjtFQUNoRTtFQUVBLE1BQU0sYUFBYSxhQUFhLGFBQWEsaUJBQWlCO0lBQzVELFFBQVE7TUFBRSxTQUFTO1FBQUUsZUFBZTtNQUFXO0lBQUU7RUFDbkQ7RUFFQSxNQUFNLFFBQVEsV0FBVyxPQUFPLENBQUMsV0FBVztFQUM1QyxNQUFNLEVBQUUsTUFBTSxNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLFdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQztFQUU3RSxJQUFJLGVBQWUsQ0FBQyxRQUFRLFFBQVE7SUFDbEMsT0FBTztNQUFFLFNBQVM7TUFBTyxPQUFPO0lBQWdCO0VBQ2xEO0VBRUEsTUFBTSxTQUFTLE9BQU8sTUFBTSxDQUFDLEdBQUc7RUFDaEMsTUFBTSxjQUFjLGFBQWEsYUFBYTtFQUU5Qyx5QkFBeUI7RUFDekIsTUFBTSxFQUFFLE1BQU0sUUFBUSxFQUFFLEdBQUcsTUFBTSxZQUM5QixJQUFJLENBQUMsY0FDTCxNQUFNLENBQUMsUUFDUCxFQUFFLENBQUMsV0FBVyxRQUNkLE1BQU07RUFFVCxJQUFJLENBQUMsWUFBWSxTQUFTLElBQUksS0FBSyxlQUFlO0lBQ2hELE9BQU87TUFBRSxTQUFTO01BQU8sT0FBTztJQUEyQztFQUM3RTtFQUVBLGFBQWE7RUFDYixNQUFNLEVBQUUsTUFBTSxVQUFVLEVBQUUsR0FBRyxNQUFNLFlBQ2hDLElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQyxTQUNQLEVBQUUsQ0FBQyxPQUFPLG1CQUNWLE1BQU07RUFFVCxJQUFJLENBQUMsWUFBWSxPQUFPO0lBQ3RCLE9BQU87TUFBRSxTQUFTO01BQU8sT0FBTztJQUFzQjtFQUN4RDtFQUVBLE1BQU0sVUFBVSxNQUFNLE9BQU87RUFDN0IsSUFBSSxZQUFZLFdBQVcsS0FBSyxFQUFFO0lBQ2hDLE9BQU87TUFBRSxTQUFTO01BQU8sT0FBTztJQUFtQjtFQUNyRDtFQUVBLE9BQU87SUFBRSxTQUFTO0lBQU07RUFBTztBQUNqQztBQUVBLEtBQUssS0FBSyxDQUFDLE9BQU87RUFDaEIsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxNQUFNLE9BQU8sTUFBTSxJQUFJLElBQUksR0FBRyxLQUFLLENBQUMsSUFBTSxDQUFDLENBQUMsQ0FBQztJQUM3QyxNQUFNLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsUUFBUSxHQUFHLEVBQUUsU0FBUyxDQUFDLEVBQUUsR0FBRztJQUV6RSxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFFckMsZ0JBQWdCO0lBQ2hCLE1BQU0sZUFBZSxNQUFNLHVCQUN6QixjQUFjLElBQ2QsS0FDQSxhQUNBLG9CQUNBO0lBR0YsSUFBSSxDQUFDLGFBQWEsT0FBTyxFQUFFO01BQ3pCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTyxhQUFhLEtBQUs7TUFBQyxJQUMzQztRQUFFLFFBQVEsYUFBYSxLQUFLLEtBQUssaUJBQWlCLE1BQU07UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFakk7SUFFQSxNQUFNLGNBQWMsYUFBYSxhQUFhO0lBQzlDLFFBQVEsR0FBRyxDQUFDLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxpQkFBaUIsRUFBRSxhQUFhLE1BQU0sQ0FBQyxDQUFDO0lBRS9FLE9BQVE7TUFDTixLQUFLO1FBQWU7VUFDbEIsNEJBQTRCO1VBQzVCLE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFlBQ25DLElBQUksQ0FBQyw2QkFDTCxNQUFNLENBQUMsY0FDUCxFQUFFLENBQUMsZ0JBQWdCLFVBQ25CLEVBQUUsQ0FBQyxjQUFjO1VBRXBCLElBQUksT0FBTztZQUNULG1DQUFtQztZQUNuQyxNQUFNLGNBQWM7Y0FDbEI7Y0FBWTtjQUFVO2NBQVU7Y0FBb0I7Y0FDcEQ7Y0FBZTtjQUFhO2NBQWlCO2NBQzdDO2NBQWdCO2NBQW9CO2NBQWdCO2NBQ3BEO2NBQW1CO2NBQWU7Y0FBa0I7Y0FDcEQ7Y0FBWTtjQUFpQjtjQUFzQjtjQUNuRDtjQUFZO2NBQWlCO2NBQVk7Y0FDekM7Y0FBZ0I7Y0FBcUI7Y0FBa0I7Y0FDdkQ7Y0FBZTtjQUFrQjtjQUFtQjtjQUNwRDtjQUFpQjtjQUFZO2NBQWU7Y0FDNUM7Y0FBc0I7Y0FBb0I7YUFDM0M7WUFDRCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztjQUFFLFFBQVE7WUFBWSxJQUNyQztjQUFFLFNBQVM7Z0JBQUUsR0FBRyxXQUFXO2dCQUFFLGdCQUFnQjtjQUFtQjtZQUFFO1VBRXRFO1VBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7WUFBRSxRQUFRLFFBQVEsSUFBSSxDQUFDLElBQVcsRUFBRSxVQUFVLEtBQUssRUFBRTtVQUFDLElBQ3JFO1lBQUUsU0FBUztjQUFFLEdBQUcsV0FBVztjQUFFLGdCQUFnQjtZQUFtQjtVQUFFO1FBRXRFO01BRUEsS0FBSztRQUFrQjtVQUNyQixJQUFJLENBQUMsT0FBTztZQUNWLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO2NBQUUsT0FBTztZQUFzQixJQUM5QztjQUFFLFFBQVE7Y0FBSyxTQUFTO2dCQUFFLEdBQUcsV0FBVztnQkFBRSxnQkFBZ0I7Y0FBbUI7WUFBRTtVQUVuRjtVQUVBLFlBQVk7VUFDWixNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxZQUNyQixJQUFJLENBQUMsT0FDTCxNQUFNLENBQUMsS0FBSztZQUFFLE9BQU87WUFBUyxNQUFNO1VBQUs7VUFFNUMsMkJBQTJCO1VBQzNCLE1BQU0sRUFBRSxNQUFNLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFlBQ2pDLElBQUksQ0FBQyxPQUNMLE1BQU0sQ0FBQyxLQUNQLEtBQUssQ0FBQyxRQUFRLFNBQVMsUUFBUSxHQUMvQixLQUFLLENBQUMsY0FBYztZQUFFLFdBQVc7WUFBTyxZQUFZO1VBQU07VUFFN0QsSUFBSSxPQUFPO1lBQ1QsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7Y0FBRSxPQUFPLE1BQU0sT0FBTztZQUFDLElBQ3RDO2NBQUUsUUFBUTtjQUFLLFNBQVM7Z0JBQUUsR0FBRyxXQUFXO2dCQUFFLGdCQUFnQjtjQUFtQjtZQUFFO1VBRW5GO1VBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7WUFBRSxNQUFNLFFBQVEsRUFBRTtZQUFFLE9BQU8sU0FBUztZQUFHO1lBQU87VUFBTyxJQUNwRTtZQUFFLFNBQVM7Y0FBRSxHQUFHLFdBQVc7Y0FBRSxnQkFBZ0I7WUFBbUI7VUFBRTtRQUV0RTtNQUVBLEtBQUs7UUFBYztVQUNqQixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNO1lBQzFCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO2NBQUUsT0FBTztZQUErQixJQUN2RDtjQUFFLFFBQVE7Y0FBSyxTQUFTO2dCQUFFLEdBQUcsV0FBVztnQkFBRSxnQkFBZ0I7Y0FBbUI7WUFBRTtVQUVuRjtVQUVBLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFlBQ3JCLElBQUksQ0FBQyxPQUNMLE1BQU0sQ0FBQyxNQUNQLEVBQUUsQ0FBQyxNQUFNO1VBRVosSUFBSSxPQUFPO1lBQ1QsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7Y0FBRSxPQUFPLE1BQU0sT0FBTztZQUFDLElBQ3RDO2NBQUUsUUFBUTtjQUFLLFNBQVM7Z0JBQUUsR0FBRyxXQUFXO2dCQUFFLGdCQUFnQjtjQUFtQjtZQUFFO1VBRW5GO1VBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxZQUFZLEVBQUUsR0FBRyxJQUFJLEVBQUUsTUFBTSxDQUFDO1VBQzNDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1lBQUUsU0FBUztVQUFLLElBQy9CO1lBQUUsU0FBUztjQUFFLEdBQUcsV0FBVztjQUFFLGdCQUFnQjtZQUFtQjtVQUFFO1FBRXRFO01BRUEsS0FBSztRQUFjO1VBQ2pCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSTtZQUNqQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztjQUFFLE9BQU87WUFBd0IsSUFDaEQ7Y0FBRSxRQUFRO2NBQUssU0FBUztnQkFBRSxHQUFHLFdBQVc7Z0JBQUUsZ0JBQWdCO2NBQW1CO1lBQUU7VUFFbkY7VUFFQSxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxZQUNyQixJQUFJLENBQUMsT0FDTCxNQUFNLEdBQ04sRUFBRSxDQUFDLE1BQU07VUFFWixJQUFJLE9BQU87WUFDVCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztjQUFFLE9BQU8sTUFBTSxPQUFPO1lBQUMsSUFDdEM7Y0FBRSxRQUFRO2NBQUssU0FBUztnQkFBRSxHQUFHLFdBQVc7Z0JBQUUsZ0JBQWdCO2NBQW1CO1lBQUU7VUFFbkY7VUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLFlBQVksRUFBRSxHQUFHLE1BQU0sRUFBRSxNQUFNLENBQUM7VUFDN0MsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7WUFBRSxTQUFTO1VBQUssSUFDL0I7WUFBRSxTQUFTO2NBQUUsR0FBRyxXQUFXO2NBQUUsZ0JBQWdCO1lBQW1CO1VBQUU7UUFFdEU7TUFFQSxLQUFLO1FBQWM7VUFDakIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNO1lBQ25CLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO2NBQUUsT0FBTztZQUEwQixJQUNsRDtjQUFFLFFBQVE7Y0FBSyxTQUFTO2dCQUFFLEdBQUcsV0FBVztnQkFBRSxnQkFBZ0I7Y0FBbUI7WUFBRTtVQUVuRjtVQUVBLE1BQU0sRUFBRSxNQUFNLFFBQVEsRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFlBQ3JDLElBQUksQ0FBQyxPQUNMLE1BQU0sQ0FBQyxNQUNQLE1BQU0sR0FDTixNQUFNO1VBRVQsSUFBSSxPQUFPO1lBQ1QsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7Y0FBRSxPQUFPLE1BQU0sT0FBTztZQUFDLElBQ3RDO2NBQUUsUUFBUTtjQUFLLFNBQVM7Z0JBQUUsR0FBRyxXQUFXO2dCQUFFLGdCQUFnQjtjQUFtQjtZQUFFO1VBRW5GO1VBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxNQUFNLENBQUM7VUFDdEMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7WUFBRSxTQUFTO1lBQU0sTUFBTTtVQUFTLElBQy9DO1lBQUUsU0FBUztjQUFFLEdBQUcsV0FBVztjQUFFLGdCQUFnQjtZQUFtQjtVQUFFO1FBRXRFO01BRUEsS0FBSztRQUFnQjtVQUNuQixJQUFJLENBQUMsT0FBTztZQUNWLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO2NBQUUsT0FBTztZQUFzQixJQUM5QztjQUFFLFFBQVE7Y0FBSyxTQUFTO2dCQUFFLEdBQUcsV0FBVztnQkFBRSxnQkFBZ0I7Y0FBbUI7WUFBRTtVQUVuRjtVQUVBLE1BQU0sRUFBRSxNQUFNLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFlBQ2pDLElBQUksQ0FBQyxPQUNMLE1BQU0sQ0FBQyxLQUNQLEtBQUssQ0FBQztVQUVULElBQUksT0FBTztZQUNULE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO2NBQUUsT0FBTyxNQUFNLE9BQU87WUFBQyxJQUN0QztjQUFFLFFBQVE7Y0FBSyxTQUFTO2dCQUFFLEdBQUcsV0FBVztnQkFBRSxnQkFBZ0I7Y0FBbUI7WUFBRTtVQUVuRjtVQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1lBQUU7WUFBTyxPQUFPLE1BQU0sVUFBVTtZQUFHLE1BQU0sUUFBUSxFQUFFO1VBQUMsSUFDbkU7WUFBRSxTQUFTO2NBQUUsR0FBRyxXQUFXO2NBQUUsZ0JBQWdCO1lBQW1CO1VBQUU7UUFFdEU7TUFFQSxLQUFLO1FBQWM7VUFDakIsTUFBTSxjQUFjO1lBQ2xCO1lBQVk7WUFBVTtZQUFVO1lBQW9CO1lBQ3BEO1lBQWU7WUFBYTtZQUFpQjtZQUM3QztZQUFnQjtZQUFvQjtZQUFnQjtZQUNwRDtZQUFtQjtZQUFlO1lBQWtCO1lBQ3BEO1lBQVk7WUFBaUI7WUFBc0I7WUFDbkQ7WUFBWTtZQUFpQjtZQUFZO1lBQ3pDO1lBQWdCO1lBQXFCO1lBQWtCO1lBQ3ZEO1lBQWU7V0FDaEI7VUFFRCxNQUFNLGFBQXNDO1lBQzFDLGFBQWEsSUFBSSxPQUFPLFdBQVc7WUFDbkMsYUFBYSxhQUFhLE1BQU07WUFDaEMsUUFBUSxDQUFDO1VBQ1g7VUFFQSxLQUFLLE1BQU0sYUFBYSxZQUFhO1lBQ25DLElBQUk7Y0FDRixNQUFNLEVBQUUsTUFBTSxJQUFJLEVBQUUsR0FBRyxNQUFNLFlBQzFCLElBQUksQ0FBQyxXQUNMLE1BQU0sQ0FBQyxLQUNQLEtBQUssQ0FBQztjQUVSLFdBQVcsTUFBTSxBQUE0QixDQUFDLFVBQVUsR0FBRztnQkFDMUQsT0FBTyxNQUFNLFVBQVU7Z0JBQ3ZCLE1BQU0sUUFBUSxFQUFFO2NBQ2xCO1lBQ0YsRUFBRSxPQUFNO2NBQ0wsV0FBVyxNQUFNLEFBQTRCLENBQUMsVUFBVSxHQUFHO2dCQUFFLE9BQU87Z0JBQW9CLE9BQU87Y0FBRTtZQUNwRztVQUNGO1VBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUMsWUFBWSxNQUFNLElBQ2pDO1lBQUUsU0FBUztjQUFFLEdBQUcsV0FBVztjQUFFLGdCQUFnQjtZQUFtQjtVQUFFO1FBRXRFO01BRUE7UUFDRSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBaUIsSUFDekM7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO0lBRXJGO0VBRUYsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLE1BQU0sZUFBZSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRyxPQUFPO0lBQ3JFLFFBQVEsS0FBSyxDQUFDLG1CQUFtQjtJQUNqQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBYSxJQUNyQztNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRiJ9
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const ffmpegApiUrl = Deno.env.get("FFMPEG_API_URL");
    const ffmpegApiSecret = Deno.env.get("FFMPEG_API_SECRET");
    // Verify user authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Authorization required");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      throw new Error("Invalid token");
    }
    const body = await req.json();
    const { audio_url, track_id } = body;
    if (!audio_url) {
      throw new Error("audio_url is required");
    }
    console.log(`Analyzing audio: ${audio_url}`);
    let analysisResult;
    // Try FFmpeg API with auth
    const vpsAnalysis = async ()=>{
      if (!ffmpegApiUrl || !ffmpegApiSecret) {
        console.log("FFmpeg API not configured");
        return null;
      }
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(()=>controller.abort(), 10000);
        const baseUrl = ffmpegApiUrl.replace(/\/(clean-metadata|analyze|normalize)\/?$/, "");
        const probeResponse = await fetch(`${baseUrl}/analyze`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": ffmpegApiSecret
          },
          body: JSON.stringify({
            audio_url
          }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!probeResponse.ok) {
          console.log("FFmpeg API analyze error:", probeResponse.status);
          return null;
        }
        const vpsResult = await probeResponse.json();
        return parseVpsResult(vpsResult);
      } catch (e) {
        console.log("FFmpeg API call failed:", e);
        return null;
      }
    };
    const vpsResult = await vpsAnalysis();
    if (vpsResult) {
      analysisResult = vpsResult;
      console.log("Using FFmpeg API analysis result");
    } else {
      console.log("FFmpeg API unavailable, using simulated analysis");
      analysisResult = simulateAnalysis(audio_url);
    }
    // Save analysis to track_health_reports table if track_id provided
    if (track_id) {
      const { error: healthError } = await supabase.from("track_health_reports").upsert({
        track_id,
        quality_score: analysisResult.quality_score,
        lufs_original: analysisResult.original_lufs,
        peak_db: analysisResult.peak_db,
        dynamic_range: analysisResult.dynamic_range,
        spectrum_ok: analysisResult.spectrum_ok,
        high_freq_cutoff: analysisResult.high_freq_cutoff,
        upscale_detected: analysisResult.upscale_detected,
        sample_rate: analysisResult.sample_rate,
        bit_depth: analysisResult.bit_depth,
        channels: analysisResult.channels,
        duration: analysisResult.duration,
        format: analysisResult.format,
        master_quality: analysisResult.master_quality,
        recommendations: analysisResult.recommendations,
        analysis_status: "completed",
        updated_at: new Date().toISOString()
      }, {
        onConflict: "track_id"
      });
      if (healthError) {
        console.error("Error saving health report:", healthError);
      } else {
        console.log("Health report saved for track:", track_id);
      }
      // Also update legacy fields on tracks table
      await supabase.from("tracks").update({
        audio_quality_score: analysisResult.quality_score,
        audio_sample_rate: analysisResult.sample_rate,
        audio_bit_depth: analysisResult.bit_depth,
        audio_lufs: analysisResult.original_lufs,
        audio_peak_db: analysisResult.peak_db,
        upscale_detected: analysisResult.upscale_detected,
        needs_master_wav: !analysisResult.master_quality
      }).eq("id", track_id);
    }
    return new Response(JSON.stringify({
      success: true,
      analysis: analysisResult
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Analysis error:", errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
function parseVpsResult(vpsResult) {
  const { format, streams, lufs, spectrum } = vpsResult;
  const audioStream = streams?.find((s)=>s.codec_type === "audio") || {};
  const highFreqCutoff = spectrum?.high_freq_cutoff || 20000;
  const upscaleDetected = highFreqCutoff < 16000;
  let qualityScore = 10;
  if (upscaleDetected) qualityScore -= 3;
  if (audioStream.sample_rate < 44100) qualityScore -= 2;
  if (audioStream.bits_per_sample < 16) qualityScore -= 2;
  if (lufs?.integrated > -8) qualityScore -= 1;
  qualityScore = Math.max(1, Math.min(10, qualityScore));
  const sampleRate = parseInt(audioStream.sample_rate) || 44100;
  const bitDepth = audioStream.bits_per_sample || (audioStream.codec_name === "flac" ? 24 : 16);
  const originalLufs = lufs?.integrated || -16;
  const recommendations = [];
  if (upscaleDetected) {
    recommendations.push("Обнаружен апскейл. Рекомендуется загрузить оригинальный файл высокого качества.");
  }
  if (originalLufs > -12 || originalLufs < -18) {
    recommendations.push("Громкость будет нормализована до -14 LUFS для стриминговых платформ.");
  }
  if (bitDepth < 24 || ![
    "wav",
    "flac",
    "aiff"
  ].includes(format?.format_name || "")) {
    recommendations.push("Для дистрибуции рекомендуется WAV 24-bit.");
  }
  return {
    spectrum_ok: !upscaleDetected,
    high_freq_cutoff: highFreqCutoff,
    upscale_detected: upscaleDetected,
    quality_score: qualityScore,
    original_lufs: originalLufs,
    peak_db: lufs?.true_peak || -1,
    dynamic_range: lufs?.range || 8,
    needs_normalization: Math.abs(originalLufs - -14) > 1,
    sample_rate: sampleRate,
    bit_depth: bitDepth,
    channels: audioStream.channels || 2,
    duration: parseFloat(format?.duration) || 0,
    format: format?.format_name || "unknown",
    master_quality: bitDepth >= 24 && [
      "wav",
      "flac",
      "aiff"
    ].includes(format?.format_name || ""),
    recommendations
  };
}
function simulateAnalysis(audioUrl) {
  const urlLower = audioUrl.toLowerCase();
  const isWav = urlLower.includes(".wav");
  const isFlac = urlLower.includes(".flac");
  const isMp3 = urlLower.includes(".mp3");
  const format = isWav ? "wav" : isFlac ? "flac" : "mp3";
  const bitDepth = isWav ? 24 : isFlac ? 24 : 16;
  const sampleRate = 44100;
  const originalLufs = -14 + (Math.random() * 8 - 4);
  const upscaleDetected = isMp3 && Math.random() > 0.7;
  let qualityScore = isWav || isFlac ? 9 : 7;
  if (upscaleDetected) qualityScore -= 2;
  const recommendations = [];
  if (isMp3) {
    recommendations.push("MP3 формат. Для дистрибуции рекомендуется WAV 24-bit.");
  }
  if (Math.abs(originalLufs - -14) > 1) {
    recommendations.push("Громкость будет нормализована до -14 LUFS.");
  }
  return {
    spectrum_ok: !upscaleDetected,
    high_freq_cutoff: upscaleDetected ? 15500 : 20000,
    upscale_detected: upscaleDetected,
    quality_score: qualityScore,
    original_lufs: Math.round(originalLufs * 10) / 10,
    peak_db: -0.5 + Math.random() * -2,
    dynamic_range: 6 + Math.random() * 6,
    needs_normalization: Math.abs(originalLufs - -14) > 1,
    sample_rate: sampleRate,
    bit_depth: bitDepth,
    channels: 2,
    duration: 180 + Math.random() * 120,
    format,
    master_quality: bitDepth >= 24 && (isWav || isFlac),
    recommendations
  };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9hbmFseXplLWF1ZGlvL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE5MC4wL2h0dHAvc2VydmVyLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDIuNDkuMVwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5pbnRlcmZhY2UgQW5hbHlzaXNSZXN1bHQge1xuICBzcGVjdHJ1bV9vazogYm9vbGVhbjtcbiAgaGlnaF9mcmVxX2N1dG9mZjogbnVtYmVyO1xuICB1cHNjYWxlX2RldGVjdGVkOiBib29sZWFuO1xuICBxdWFsaXR5X3Njb3JlOiBudW1iZXI7XG4gIG9yaWdpbmFsX2x1ZnM6IG51bWJlcjtcbiAgcGVha19kYjogbnVtYmVyO1xuICBkeW5hbWljX3JhbmdlOiBudW1iZXI7XG4gIG5lZWRzX25vcm1hbGl6YXRpb246IGJvb2xlYW47XG4gIHNhbXBsZV9yYXRlOiBudW1iZXI7XG4gIGJpdF9kZXB0aDogbnVtYmVyO1xuICBjaGFubmVsczogbnVtYmVyO1xuICBkdXJhdGlvbjogbnVtYmVyO1xuICBmb3JtYXQ6IHN0cmluZztcbiAgbWFzdGVyX3F1YWxpdHk6IGJvb2xlYW47XG4gIHJlY29tbWVuZGF0aW9uczogc3RyaW5nW107XG59XG5cbnNlcnZlKGFzeW5jIChyZXE6IFJlcXVlc3QpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlU2VydmljZUtleSk7XG5cbiAgICBjb25zdCBmZm1wZWdBcGlVcmwgPSBEZW5vLmVudi5nZXQoXCJGRk1QRUdfQVBJX1VSTFwiKTtcbiAgICBjb25zdCBmZm1wZWdBcGlTZWNyZXQgPSBEZW5vLmVudi5nZXQoXCJGRk1QRUdfQVBJX1NFQ1JFVFwiKTtcblxuICAgIC8vIFZlcmlmeSB1c2VyIGF1dGhlbnRpY2F0aW9uXG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJBdXRob3JpemF0aW9uIHJlcXVpcmVkXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHRva2VuID0gYXV0aEhlYWRlci5yZXBsYWNlKFwiQmVhcmVyIFwiLCBcIlwiKTtcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9LCBlcnJvcjogYXV0aEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIodG9rZW4pO1xuICAgIGlmIChhdXRoRXJyb3IgfHwgIXVzZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgdG9rZW5cIik7XG4gICAgfVxuXG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc3QgeyBhdWRpb191cmwsIHRyYWNrX2lkIH0gPSBib2R5O1xuXG4gICAgaWYgKCFhdWRpb191cmwpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcImF1ZGlvX3VybCBpcyByZXF1aXJlZFwiKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgQW5hbHl6aW5nIGF1ZGlvOiAke2F1ZGlvX3VybH1gKTtcblxuICAgIGxldCBhbmFseXNpc1Jlc3VsdDogQW5hbHlzaXNSZXN1bHQ7XG5cbiAgICAvLyBUcnkgRkZtcGVnIEFQSSB3aXRoIGF1dGhcbiAgICBjb25zdCB2cHNBbmFseXNpcyA9IGFzeW5jICgpOiBQcm9taXNlPEFuYWx5c2lzUmVzdWx0IHwgbnVsbD4gPT4ge1xuICAgICAgaWYgKCFmZm1wZWdBcGlVcmwgfHwgIWZmbXBlZ0FwaVNlY3JldCkge1xuICAgICAgICBjb25zb2xlLmxvZyhcIkZGbXBlZyBBUEkgbm90IGNvbmZpZ3VyZWRcIik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIDEwMDAwKTtcblxuICAgICAgICBjb25zdCBiYXNlVXJsID0gZmZtcGVnQXBpVXJsIS5yZXBsYWNlKC9cXC8oY2xlYW4tbWV0YWRhdGF8YW5hbHl6ZXxub3JtYWxpemUpXFwvPyQvLCBcIlwiKTtcbiAgICAgICAgY29uc3QgcHJvYmVSZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke2Jhc2VVcmx9L2FuYWx5emVgLCB7XG4gICAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgICAgIFwieC1hcGkta2V5XCI6IGZmbXBlZ0FwaVNlY3JldCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgYXVkaW9fdXJsIH0pLFxuICAgICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuXG4gICAgICAgIGlmICghcHJvYmVSZXNwb25zZS5vaykge1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRkZtcGVnIEFQSSBhbmFseXplIGVycm9yOlwiLCBwcm9iZVJlc3BvbnNlLnN0YXR1cyk7XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB2cHNSZXN1bHQgPSBhd2FpdCBwcm9iZVJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIHBhcnNlVnBzUmVzdWx0KHZwc1Jlc3VsdCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiRkZtcGVnIEFQSSBjYWxsIGZhaWxlZDpcIiwgZSk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCB2cHNSZXN1bHQgPSBhd2FpdCB2cHNBbmFseXNpcygpO1xuICAgIGlmICh2cHNSZXN1bHQpIHtcbiAgICAgIGFuYWx5c2lzUmVzdWx0ID0gdnBzUmVzdWx0O1xuICAgICAgY29uc29sZS5sb2coXCJVc2luZyBGRm1wZWcgQVBJIGFuYWx5c2lzIHJlc3VsdFwiKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc29sZS5sb2coXCJGRm1wZWcgQVBJIHVuYXZhaWxhYmxlLCB1c2luZyBzaW11bGF0ZWQgYW5hbHlzaXNcIik7XG4gICAgICBhbmFseXNpc1Jlc3VsdCA9IHNpbXVsYXRlQW5hbHlzaXMoYXVkaW9fdXJsKTtcbiAgICB9XG5cbiAgICAvLyBTYXZlIGFuYWx5c2lzIHRvIHRyYWNrX2hlYWx0aF9yZXBvcnRzIHRhYmxlIGlmIHRyYWNrX2lkIHByb3ZpZGVkXG4gICAgaWYgKHRyYWNrX2lkKSB7XG4gICAgICBjb25zdCB7IGVycm9yOiBoZWFsdGhFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJ0cmFja19oZWFsdGhfcmVwb3J0c1wiKVxuICAgICAgICAudXBzZXJ0KHtcbiAgICAgICAgICB0cmFja19pZCxcbiAgICAgICAgICBxdWFsaXR5X3Njb3JlOiBhbmFseXNpc1Jlc3VsdC5xdWFsaXR5X3Njb3JlLFxuICAgICAgICAgIGx1ZnNfb3JpZ2luYWw6IGFuYWx5c2lzUmVzdWx0Lm9yaWdpbmFsX2x1ZnMsXG4gICAgICAgICAgcGVha19kYjogYW5hbHlzaXNSZXN1bHQucGVha19kYixcbiAgICAgICAgICBkeW5hbWljX3JhbmdlOiBhbmFseXNpc1Jlc3VsdC5keW5hbWljX3JhbmdlLFxuICAgICAgICAgIHNwZWN0cnVtX29rOiBhbmFseXNpc1Jlc3VsdC5zcGVjdHJ1bV9vayxcbiAgICAgICAgICBoaWdoX2ZyZXFfY3V0b2ZmOiBhbmFseXNpc1Jlc3VsdC5oaWdoX2ZyZXFfY3V0b2ZmLFxuICAgICAgICAgIHVwc2NhbGVfZGV0ZWN0ZWQ6IGFuYWx5c2lzUmVzdWx0LnVwc2NhbGVfZGV0ZWN0ZWQsXG4gICAgICAgICAgc2FtcGxlX3JhdGU6IGFuYWx5c2lzUmVzdWx0LnNhbXBsZV9yYXRlLFxuICAgICAgICAgIGJpdF9kZXB0aDogYW5hbHlzaXNSZXN1bHQuYml0X2RlcHRoLFxuICAgICAgICAgIGNoYW5uZWxzOiBhbmFseXNpc1Jlc3VsdC5jaGFubmVscyxcbiAgICAgICAgICBkdXJhdGlvbjogYW5hbHlzaXNSZXN1bHQuZHVyYXRpb24sXG4gICAgICAgICAgZm9ybWF0OiBhbmFseXNpc1Jlc3VsdC5mb3JtYXQsXG4gICAgICAgICAgbWFzdGVyX3F1YWxpdHk6IGFuYWx5c2lzUmVzdWx0Lm1hc3Rlcl9xdWFsaXR5LFxuICAgICAgICAgIHJlY29tbWVuZGF0aW9uczogYW5hbHlzaXNSZXN1bHQucmVjb21tZW5kYXRpb25zLFxuICAgICAgICAgIGFuYWx5c2lzX3N0YXR1czogXCJjb21wbGV0ZWRcIixcbiAgICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIH0sIHtcbiAgICAgICAgICBvbkNvbmZsaWN0OiBcInRyYWNrX2lkXCIsXG4gICAgICAgIH0pO1xuXG4gICAgICBpZiAoaGVhbHRoRXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHNhdmluZyBoZWFsdGggcmVwb3J0OlwiLCBoZWFsdGhFcnJvcik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhcIkhlYWx0aCByZXBvcnQgc2F2ZWQgZm9yIHRyYWNrOlwiLCB0cmFja19pZCk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFsc28gdXBkYXRlIGxlZ2FjeSBmaWVsZHMgb24gdHJhY2tzIHRhYmxlXG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICBhdWRpb19xdWFsaXR5X3Njb3JlOiBhbmFseXNpc1Jlc3VsdC5xdWFsaXR5X3Njb3JlLFxuICAgICAgICAgIGF1ZGlvX3NhbXBsZV9yYXRlOiBhbmFseXNpc1Jlc3VsdC5zYW1wbGVfcmF0ZSxcbiAgICAgICAgICBhdWRpb19iaXRfZGVwdGg6IGFuYWx5c2lzUmVzdWx0LmJpdF9kZXB0aCxcbiAgICAgICAgICBhdWRpb19sdWZzOiBhbmFseXNpc1Jlc3VsdC5vcmlnaW5hbF9sdWZzLFxuICAgICAgICAgIGF1ZGlvX3BlYWtfZGI6IGFuYWx5c2lzUmVzdWx0LnBlYWtfZGIsXG4gICAgICAgICAgdXBzY2FsZV9kZXRlY3RlZDogYW5hbHlzaXNSZXN1bHQudXBzY2FsZV9kZXRlY3RlZCxcbiAgICAgICAgICBuZWVkc19tYXN0ZXJfd2F2OiAhYW5hbHlzaXNSZXN1bHQubWFzdGVyX3F1YWxpdHksXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHRyYWNrX2lkKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiB0cnVlLCBhbmFseXNpczogYW5hbHlzaXNSZXN1bHQgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIGNvbnNvbGUuZXJyb3IoXCJBbmFseXNpcyBlcnJvcjpcIiwgZXJyb3JNZXNzYWdlKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGVycm9yTWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuXG5mdW5jdGlvbiBwYXJzZVZwc1Jlc3VsdCh2cHNSZXN1bHQ6IGFueSk6IEFuYWx5c2lzUmVzdWx0IHtcbiAgY29uc3QgeyBmb3JtYXQsIHN0cmVhbXMsIGx1ZnMsIHNwZWN0cnVtIH0gPSB2cHNSZXN1bHQ7XG4gIGNvbnN0IGF1ZGlvU3RyZWFtID0gc3RyZWFtcz8uZmluZCgoczogYW55KSA9PiBzLmNvZGVjX3R5cGUgPT09IFwiYXVkaW9cIikgfHwge307XG5cbiAgY29uc3QgaGlnaEZyZXFDdXRvZmYgPSBzcGVjdHJ1bT8uaGlnaF9mcmVxX2N1dG9mZiB8fCAyMDAwMDtcbiAgY29uc3QgdXBzY2FsZURldGVjdGVkID0gaGlnaEZyZXFDdXRvZmYgPCAxNjAwMDtcblxuICBsZXQgcXVhbGl0eVNjb3JlID0gMTA7XG4gIGlmICh1cHNjYWxlRGV0ZWN0ZWQpIHF1YWxpdHlTY29yZSAtPSAzO1xuICBpZiAoYXVkaW9TdHJlYW0uc2FtcGxlX3JhdGUgPCA0NDEwMCkgcXVhbGl0eVNjb3JlIC09IDI7XG4gIGlmIChhdWRpb1N0cmVhbS5iaXRzX3Blcl9zYW1wbGUgPCAxNikgcXVhbGl0eVNjb3JlIC09IDI7XG4gIGlmIChsdWZzPy5pbnRlZ3JhdGVkID4gLTgpIHF1YWxpdHlTY29yZSAtPSAxO1xuICBxdWFsaXR5U2NvcmUgPSBNYXRoLm1heCgxLCBNYXRoLm1pbigxMCwgcXVhbGl0eVNjb3JlKSk7XG5cbiAgY29uc3Qgc2FtcGxlUmF0ZSA9IHBhcnNlSW50KGF1ZGlvU3RyZWFtLnNhbXBsZV9yYXRlKSB8fCA0NDEwMDtcbiAgY29uc3QgYml0RGVwdGggPSBhdWRpb1N0cmVhbS5iaXRzX3Blcl9zYW1wbGUgfHwgKGF1ZGlvU3RyZWFtLmNvZGVjX25hbWUgPT09IFwiZmxhY1wiID8gMjQgOiAxNik7XG4gIGNvbnN0IG9yaWdpbmFsTHVmcyA9IGx1ZnM/LmludGVncmF0ZWQgfHwgLTE2O1xuXG4gIGNvbnN0IHJlY29tbWVuZGF0aW9uczogc3RyaW5nW10gPSBbXTtcbiAgaWYgKHVwc2NhbGVEZXRlY3RlZCkge1xuICAgIHJlY29tbWVuZGF0aW9ucy5wdXNoKFwi0J7QsdC90LDRgNGD0LbQtdC9INCw0L/RgdC60LXQudC7LiDQoNC10LrQvtC80LXQvdC00YPQtdGC0YHRjyDQt9Cw0LPRgNGD0LfQuNGC0Ywg0L7RgNC40LPQuNC90LDQu9GM0L3Ri9C5INGE0LDQudC7INCy0YvRgdC+0LrQvtCz0L4g0LrQsNGH0LXRgdGC0LLQsC5cIik7XG4gIH1cbiAgaWYgKG9yaWdpbmFsTHVmcyA+IC0xMiB8fCBvcmlnaW5hbEx1ZnMgPCAtMTgpIHtcbiAgICByZWNvbW1lbmRhdGlvbnMucHVzaChcItCT0YDQvtC80LrQvtGB0YLRjCDQsdGD0LTQtdGCINC90L7RgNC80LDQu9C40LfQvtCy0LDQvdCwINC00L4gLTE0IExVRlMg0LTQu9GPINGB0YLRgNC40LzQuNC90LPQvtCy0YvRhSDQv9C70LDRgtGE0L7RgNC8LlwiKTtcbiAgfVxuICBpZiAoYml0RGVwdGggPCAyNCB8fCAhW1wid2F2XCIsIFwiZmxhY1wiLCBcImFpZmZcIl0uaW5jbHVkZXMoZm9ybWF0Py5mb3JtYXRfbmFtZSB8fCBcIlwiKSkge1xuICAgIHJlY29tbWVuZGF0aW9ucy5wdXNoKFwi0JTQu9GPINC00LjRgdGC0YDQuNCx0YPRhtC40Lgg0YDQtdC60L7QvNC10L3QtNGD0LXRgtGB0Y8gV0FWIDI0LWJpdC5cIik7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIHNwZWN0cnVtX29rOiAhdXBzY2FsZURldGVjdGVkLFxuICAgIGhpZ2hfZnJlcV9jdXRvZmY6IGhpZ2hGcmVxQ3V0b2ZmLFxuICAgIHVwc2NhbGVfZGV0ZWN0ZWQ6IHVwc2NhbGVEZXRlY3RlZCxcbiAgICBxdWFsaXR5X3Njb3JlOiBxdWFsaXR5U2NvcmUsXG4gICAgb3JpZ2luYWxfbHVmczogb3JpZ2luYWxMdWZzLFxuICAgIHBlYWtfZGI6IGx1ZnM/LnRydWVfcGVhayB8fCAtMSxcbiAgICBkeW5hbWljX3JhbmdlOiBsdWZzPy5yYW5nZSB8fCA4LFxuICAgIG5lZWRzX25vcm1hbGl6YXRpb246IE1hdGguYWJzKG9yaWdpbmFsTHVmcyAtICgtMTQpKSA+IDEsXG4gICAgc2FtcGxlX3JhdGU6IHNhbXBsZVJhdGUsXG4gICAgYml0X2RlcHRoOiBiaXREZXB0aCxcbiAgICBjaGFubmVsczogYXVkaW9TdHJlYW0uY2hhbm5lbHMgfHwgMixcbiAgICBkdXJhdGlvbjogcGFyc2VGbG9hdChmb3JtYXQ/LmR1cmF0aW9uKSB8fCAwLFxuICAgIGZvcm1hdDogZm9ybWF0Py5mb3JtYXRfbmFtZSB8fCBcInVua25vd25cIixcbiAgICBtYXN0ZXJfcXVhbGl0eTogYml0RGVwdGggPj0gMjQgJiYgW1wid2F2XCIsIFwiZmxhY1wiLCBcImFpZmZcIl0uaW5jbHVkZXMoZm9ybWF0Py5mb3JtYXRfbmFtZSB8fCBcIlwiKSxcbiAgICByZWNvbW1lbmRhdGlvbnMsXG4gIH07XG59XG5cbmZ1bmN0aW9uIHNpbXVsYXRlQW5hbHlzaXMoYXVkaW9Vcmw6IHN0cmluZyk6IEFuYWx5c2lzUmVzdWx0IHtcbiAgY29uc3QgdXJsTG93ZXIgPSBhdWRpb1VybC50b0xvd2VyQ2FzZSgpO1xuICBjb25zdCBpc1dhdiA9IHVybExvd2VyLmluY2x1ZGVzKFwiLndhdlwiKTtcbiAgY29uc3QgaXNGbGFjID0gdXJsTG93ZXIuaW5jbHVkZXMoXCIuZmxhY1wiKTtcbiAgY29uc3QgaXNNcDMgPSB1cmxMb3dlci5pbmNsdWRlcyhcIi5tcDNcIik7XG5cbiAgY29uc3QgZm9ybWF0ID0gaXNXYXYgPyBcIndhdlwiIDogaXNGbGFjID8gXCJmbGFjXCIgOiBcIm1wM1wiO1xuICBjb25zdCBiaXREZXB0aCA9IGlzV2F2ID8gMjQgOiBpc0ZsYWMgPyAyNCA6IDE2O1xuICBjb25zdCBzYW1wbGVSYXRlID0gNDQxMDA7XG5cbiAgY29uc3Qgb3JpZ2luYWxMdWZzID0gLTE0ICsgKE1hdGgucmFuZG9tKCkgKiA4IC0gNCk7XG4gIGNvbnN0IHVwc2NhbGVEZXRlY3RlZCA9IGlzTXAzICYmIE1hdGgucmFuZG9tKCkgPiAwLjc7XG5cbiAgbGV0IHF1YWxpdHlTY29yZSA9IGlzV2F2IHx8IGlzRmxhYyA/IDkgOiA3O1xuICBpZiAodXBzY2FsZURldGVjdGVkKSBxdWFsaXR5U2NvcmUgLT0gMjtcblxuICBjb25zdCByZWNvbW1lbmRhdGlvbnM6IHN0cmluZ1tdID0gW107XG4gIGlmIChpc01wMykge1xuICAgIHJlY29tbWVuZGF0aW9ucy5wdXNoKFwiTVAzINGE0L7RgNC80LDRgi4g0JTQu9GPINC00LjRgdGC0YDQuNCx0YPRhtC40Lgg0YDQtdC60L7QvNC10L3QtNGD0LXRgtGB0Y8gV0FWIDI0LWJpdC5cIik7XG4gIH1cbiAgaWYgKE1hdGguYWJzKG9yaWdpbmFsTHVmcyAtICgtMTQpKSA+IDEpIHtcbiAgICByZWNvbW1lbmRhdGlvbnMucHVzaChcItCT0YDQvtC80LrQvtGB0YLRjCDQsdGD0LTQtdGCINC90L7RgNC80LDQu9C40LfQvtCy0LDQvdCwINC00L4gLTE0IExVRlMuXCIpO1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBzcGVjdHJ1bV9vazogIXVwc2NhbGVEZXRlY3RlZCxcbiAgICBoaWdoX2ZyZXFfY3V0b2ZmOiB1cHNjYWxlRGV0ZWN0ZWQgPyAxNTUwMCA6IDIwMDAwLFxuICAgIHVwc2NhbGVfZGV0ZWN0ZWQ6IHVwc2NhbGVEZXRlY3RlZCxcbiAgICBxdWFsaXR5X3Njb3JlOiBxdWFsaXR5U2NvcmUsXG4gICAgb3JpZ2luYWxfbHVmczogTWF0aC5yb3VuZChvcmlnaW5hbEx1ZnMgKiAxMCkgLyAxMCxcbiAgICBwZWFrX2RiOiAtMC41ICsgTWF0aC5yYW5kb20oKSAqIC0yLFxuICAgIGR5bmFtaWNfcmFuZ2U6IDYgKyBNYXRoLnJhbmRvbSgpICogNixcbiAgICBuZWVkc19ub3JtYWxpemF0aW9uOiBNYXRoLmFicyhvcmlnaW5hbEx1ZnMgLSAoLTE0KSkgPiAxLFxuICAgIHNhbXBsZV9yYXRlOiBzYW1wbGVSYXRlLFxuICAgIGJpdF9kZXB0aDogYml0RGVwdGgsXG4gICAgY2hhbm5lbHM6IDIsXG4gICAgZHVyYXRpb246IDE4MCArIE1hdGgucmFuZG9tKCkgKiAxMjAsXG4gICAgZm9ybWF0LFxuICAgIG1hc3Rlcl9xdWFsaXR5OiBiaXREZXB0aCA+PSAyNCAmJiAoaXNXYXYgfHwgaXNGbGFjKSxcbiAgICByZWNvbW1lbmRhdGlvbnMsXG4gIH07XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxLQUFLLFFBQVEsK0NBQStDO0FBQ3JFLFNBQVMsWUFBWSxRQUFRLDhDQUE4QztBQUUzRSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQW9CQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbEMsTUFBTSxrQkFBa0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBRXJDLDZCQUE2QjtJQUM3QixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZO01BQ2YsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLFFBQVEsV0FBVyxPQUFPLENBQUMsV0FBVztJQUM1QyxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxTQUFTLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDekUsSUFBSSxhQUFhLENBQUMsTUFBTTtNQUN0QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtJQUMzQixNQUFNLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxHQUFHO0lBRWhDLElBQUksQ0FBQyxXQUFXO01BQ2QsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGlCQUFpQixFQUFFLFVBQVUsQ0FBQztJQUUzQyxJQUFJO0lBRUosMkJBQTJCO0lBQzNCLE1BQU0sY0FBYztNQUNsQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCO1FBQ3JDLFFBQVEsR0FBRyxDQUFDO1FBQ1osT0FBTztNQUNUO01BQ0EsSUFBSTtRQUNGLE1BQU0sYUFBYSxJQUFJO1FBQ3ZCLE1BQU0sWUFBWSxXQUFXLElBQU0sV0FBVyxLQUFLLElBQUk7UUFFdkQsTUFBTSxVQUFVLGFBQWMsT0FBTyxDQUFDLDRDQUE0QztRQUNsRixNQUFNLGdCQUFnQixNQUFNLE1BQU0sQ0FBQyxFQUFFLFFBQVEsUUFBUSxDQUFDLEVBQUU7VUFDdEQsUUFBUTtVQUNSLFNBQVM7WUFDUCxnQkFBZ0I7WUFDaEIsYUFBYTtVQUNmO1VBQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztZQUFFO1VBQVU7VUFDakMsUUFBUSxXQUFXLE1BQU07UUFDM0I7UUFFQSxhQUFhO1FBRWIsSUFBSSxDQUFDLGNBQWMsRUFBRSxFQUFFO1VBQ3JCLFFBQVEsR0FBRyxDQUFDLDZCQUE2QixjQUFjLE1BQU07VUFDN0QsT0FBTztRQUNUO1FBRUEsTUFBTSxZQUFZLE1BQU0sY0FBYyxJQUFJO1FBQzFDLE9BQU8sZUFBZTtNQUN4QixFQUFFLE9BQU8sR0FBRztRQUNWLFFBQVEsR0FBRyxDQUFDLDJCQUEyQjtRQUN2QyxPQUFPO01BQ1Q7SUFDRjtJQUVBLE1BQU0sWUFBWSxNQUFNO0lBQ3hCLElBQUksV0FBVztNQUNiLGlCQUFpQjtNQUNqQixRQUFRLEdBQUcsQ0FBQztJQUNkLE9BQU87TUFDTCxRQUFRLEdBQUcsQ0FBQztNQUNaLGlCQUFpQixpQkFBaUI7SUFDcEM7SUFFQSxtRUFBbUU7SUFDbkUsSUFBSSxVQUFVO01BQ1osTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUNsQyxJQUFJLENBQUMsd0JBQ0wsTUFBTSxDQUFDO1FBQ047UUFDQSxlQUFlLGVBQWUsYUFBYTtRQUMzQyxlQUFlLGVBQWUsYUFBYTtRQUMzQyxTQUFTLGVBQWUsT0FBTztRQUMvQixlQUFlLGVBQWUsYUFBYTtRQUMzQyxhQUFhLGVBQWUsV0FBVztRQUN2QyxrQkFBa0IsZUFBZSxnQkFBZ0I7UUFDakQsa0JBQWtCLGVBQWUsZ0JBQWdCO1FBQ2pELGFBQWEsZUFBZSxXQUFXO1FBQ3ZDLFdBQVcsZUFBZSxTQUFTO1FBQ25DLFVBQVUsZUFBZSxRQUFRO1FBQ2pDLFVBQVUsZUFBZSxRQUFRO1FBQ2pDLFFBQVEsZUFBZSxNQUFNO1FBQzdCLGdCQUFnQixlQUFlLGNBQWM7UUFDN0MsaUJBQWlCLGVBQWUsZUFBZTtRQUMvQyxpQkFBaUI7UUFDakIsWUFBWSxJQUFJLE9BQU8sV0FBVztNQUNwQyxHQUFHO1FBQ0QsWUFBWTtNQUNkO01BRUYsSUFBSSxhQUFhO1FBQ2YsUUFBUSxLQUFLLENBQUMsK0JBQStCO01BQy9DLE9BQU87UUFDTCxRQUFRLEdBQUcsQ0FBQyxrQ0FBa0M7TUFDaEQ7TUFFQSw0Q0FBNEM7TUFDNUMsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztRQUNOLHFCQUFxQixlQUFlLGFBQWE7UUFDakQsbUJBQW1CLGVBQWUsV0FBVztRQUM3QyxpQkFBaUIsZUFBZSxTQUFTO1FBQ3pDLFlBQVksZUFBZSxhQUFhO1FBQ3hDLGVBQWUsZUFBZSxPQUFPO1FBQ3JDLGtCQUFrQixlQUFlLGdCQUFnQjtRQUNqRCxrQkFBa0IsQ0FBQyxlQUFlLGNBQWM7TUFDbEQsR0FDQyxFQUFFLENBQUMsTUFBTTtJQUNkO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU0sVUFBVTtJQUFlLElBQ3pEO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsTUFBTSxlQUFlLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQzlELFFBQVEsS0FBSyxDQUFDLG1CQUFtQjtJQUNqQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLFNBQVM7TUFBTyxPQUFPO0lBQWEsSUFDckQ7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsU0FBYztFQUNwQyxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUc7RUFDNUMsTUFBTSxjQUFjLFNBQVMsS0FBSyxDQUFDLElBQVcsRUFBRSxVQUFVLEtBQUssWUFBWSxDQUFDO0VBRTVFLE1BQU0saUJBQWlCLFVBQVUsb0JBQW9CO0VBQ3JELE1BQU0sa0JBQWtCLGlCQUFpQjtFQUV6QyxJQUFJLGVBQWU7RUFDbkIsSUFBSSxpQkFBaUIsZ0JBQWdCO0VBQ3JDLElBQUksWUFBWSxXQUFXLEdBQUcsT0FBTyxnQkFBZ0I7RUFDckQsSUFBSSxZQUFZLGVBQWUsR0FBRyxJQUFJLGdCQUFnQjtFQUN0RCxJQUFJLE1BQU0sYUFBYSxDQUFDLEdBQUcsZ0JBQWdCO0VBQzNDLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQyxJQUFJO0VBRXhDLE1BQU0sYUFBYSxTQUFTLFlBQVksV0FBVyxLQUFLO0VBQ3hELE1BQU0sV0FBVyxZQUFZLGVBQWUsSUFBSSxDQUFDLFlBQVksVUFBVSxLQUFLLFNBQVMsS0FBSyxFQUFFO0VBQzVGLE1BQU0sZUFBZSxNQUFNLGNBQWMsQ0FBQztFQUUxQyxNQUFNLGtCQUE0QixFQUFFO0VBQ3BDLElBQUksaUJBQWlCO0lBQ25CLGdCQUFnQixJQUFJLENBQUM7RUFDdkI7RUFDQSxJQUFJLGVBQWUsQ0FBQyxNQUFNLGVBQWUsQ0FBQyxJQUFJO0lBQzVDLGdCQUFnQixJQUFJLENBQUM7RUFDdkI7RUFDQSxJQUFJLFdBQVcsTUFBTSxDQUFDO0lBQUM7SUFBTztJQUFRO0dBQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxlQUFlLEtBQUs7SUFDakYsZ0JBQWdCLElBQUksQ0FBQztFQUN2QjtFQUVBLE9BQU87SUFDTCxhQUFhLENBQUM7SUFDZCxrQkFBa0I7SUFDbEIsa0JBQWtCO0lBQ2xCLGVBQWU7SUFDZixlQUFlO0lBQ2YsU0FBUyxNQUFNLGFBQWEsQ0FBQztJQUM3QixlQUFlLE1BQU0sU0FBUztJQUM5QixxQkFBcUIsS0FBSyxHQUFHLENBQUMsZUFBZ0IsQ0FBQyxNQUFPO0lBQ3RELGFBQWE7SUFDYixXQUFXO0lBQ1gsVUFBVSxZQUFZLFFBQVEsSUFBSTtJQUNsQyxVQUFVLFdBQVcsUUFBUSxhQUFhO0lBQzFDLFFBQVEsUUFBUSxlQUFlO0lBQy9CLGdCQUFnQixZQUFZLE1BQU07TUFBQztNQUFPO01BQVE7S0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFRLGVBQWU7SUFDMUY7RUFDRjtBQUNGO0FBRUEsU0FBUyxpQkFBaUIsUUFBZ0I7RUFDeEMsTUFBTSxXQUFXLFNBQVMsV0FBVztFQUNyQyxNQUFNLFFBQVEsU0FBUyxRQUFRLENBQUM7RUFDaEMsTUFBTSxTQUFTLFNBQVMsUUFBUSxDQUFDO0VBQ2pDLE1BQU0sUUFBUSxTQUFTLFFBQVEsQ0FBQztFQUVoQyxNQUFNLFNBQVMsUUFBUSxRQUFRLFNBQVMsU0FBUztFQUNqRCxNQUFNLFdBQVcsUUFBUSxLQUFLLFNBQVMsS0FBSztFQUM1QyxNQUFNLGFBQWE7RUFFbkIsTUFBTSxlQUFlLENBQUMsS0FBSyxDQUFDLEtBQUssTUFBTSxLQUFLLElBQUksQ0FBQztFQUNqRCxNQUFNLGtCQUFrQixTQUFTLEtBQUssTUFBTSxLQUFLO0VBRWpELElBQUksZUFBZSxTQUFTLFNBQVMsSUFBSTtFQUN6QyxJQUFJLGlCQUFpQixnQkFBZ0I7RUFFckMsTUFBTSxrQkFBNEIsRUFBRTtFQUNwQyxJQUFJLE9BQU87SUFDVCxnQkFBZ0IsSUFBSSxDQUFDO0VBQ3ZCO0VBQ0EsSUFBSSxLQUFLLEdBQUcsQ0FBQyxlQUFnQixDQUFDLE1BQU8sR0FBRztJQUN0QyxnQkFBZ0IsSUFBSSxDQUFDO0VBQ3ZCO0VBRUEsT0FBTztJQUNMLGFBQWEsQ0FBQztJQUNkLGtCQUFrQixrQkFBa0IsUUFBUTtJQUM1QyxrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLGVBQWUsS0FBSyxLQUFLLENBQUMsZUFBZSxNQUFNO0lBQy9DLFNBQVMsQ0FBQyxNQUFNLEtBQUssTUFBTSxLQUFLLENBQUM7SUFDakMsZUFBZSxJQUFJLEtBQUssTUFBTSxLQUFLO0lBQ25DLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxlQUFnQixDQUFDLE1BQU87SUFDdEQsYUFBYTtJQUNiLFdBQVc7SUFDWCxVQUFVO0lBQ1YsVUFBVSxNQUFNLEtBQUssTUFBTSxLQUFLO0lBQ2hDO0lBQ0EsZ0JBQWdCLFlBQVksTUFBTSxDQUFDLFNBQVMsTUFBTTtJQUNsRDtFQUNGO0FBQ0YifQ==
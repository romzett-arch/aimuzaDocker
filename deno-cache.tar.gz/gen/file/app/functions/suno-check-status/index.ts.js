import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "http://api:3000";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
const BASE_URL = Deno.env.get("BASE_URL") || "http://localhost";
// Download external file and save to local storage via API
async function downloadToLocalStorage(externalUrl, bucket, filePath) {
  try {
    console.log(`Downloading ${externalUrl} → ${bucket}/${filePath}`);
    const resp = await fetch(externalUrl);
    if (!resp.ok) {
      console.log(`Download failed: ${resp.status}`);
      return null;
    }
    const blob = await resp.blob();
    const buffer = new Uint8Array(await blob.arrayBuffer());
    // Upload to local storage API (PUT for upsert)
    const uploadResp = await fetch(`${SUPABASE_URL}/storage/v1/object/${bucket}/${filePath}`, {
      method: "PUT",
      headers: {
        "Content-Type": blob.type || "application/octet-stream",
        "Authorization": `Bearer ${SERVICE_ROLE_KEY}`
      },
      body: buffer
    });
    if (!uploadResp.ok) {
      const errText = await uploadResp.text();
      console.log(`Upload to storage failed: ${uploadResp.status} ${errText}`);
      return null;
    }
    const localUrl = `${BASE_URL}/storage/v1/object/public/${bucket}/${filePath}`;
    console.log(`Saved to local storage: ${localUrl}`);
    return localUrl;
  } catch (err) {
    console.error(`Error downloading to storage:`, err);
    return null;
  }
}
// Fetch with retry logic for connection issues
async function fetchWithRetry(url, options, maxRetries = 2) {
  let lastError = null;
  for(let attempt = 0; attempt <= maxRetries; attempt++){
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(()=>controller.abort(), 10000); // 10s timeout
      const response = await fetch(url, {
        ...options,
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      return response;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      console.log(`Fetch attempt ${attempt + 1} failed:`, lastError.message);
      // Don't retry on abort
      if (lastError.name === 'AbortError') {
        throw new Error("Request timeout");
      }
      // Wait before retry (exponential backoff)
      if (attempt < maxRetries) {
        await new Promise((resolve)=>setTimeout(resolve, 1000 * (attempt + 1)));
      }
    }
  }
  throw lastError || new Error("Failed after retries");
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    // Get user via API-compatible auth endpoint
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      console.error("Auth error:", userError);
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const userId = user.id;
    const { taskId: rawTaskId, trackId } = await req.json();
    // Trim whitespace from taskId to prevent URL encoding issues
    const taskId = rawTaskId?.trim();
    if (!taskId) {
      return new Response(JSON.stringify({
        error: "Missing taskId"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Checking status for task ${taskId}`);
    let statusData;
    try {
      const statusResponse = await fetchWithRetry(`${SUNO_API_BASE}/api/v1/generate/record-info?taskId=${encodeURIComponent(taskId)}`, {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${SUNO_API_KEY}`
        }
      });
      statusData = await statusResponse.json();
    } catch (fetchError) {
      // Network error - don't mark track as failed, just return processing status
      console.log(`Network error checking status (will retry via polling):`, fetchError);
      return new Response(JSON.stringify({
        success: false,
        status: "processing",
        message: "Network issue, waiting for callback"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log("Status response:", JSON.stringify(statusData));
    if (statusData.code === 200 && statusData.data) {
      const records = statusData.data.response?.sunoData || statusData.data.data || [];
      const taskStatus = statusData.data.status;
      console.log(`Task status: ${taskStatus}, Records: ${records.length}`);
      // Check for failed status - handle GENERATE_AUDIO_FAILED and other failure states
      if (taskStatus === "GENERATE_AUDIO_FAILED" || taskStatus === "FAILED" || taskStatus === "ERROR") {
        console.log(`Task ${taskId} failed with status: ${taskStatus}`);
        if (trackId) {
          const errorMessage = statusData.data.fail_reason || statusData.data.error_message || statusData.msg || "Генерация отклонена сервисом";
          const { error: updateError } = await supabaseClient.from("tracks").update({
            status: "failed",
            error_message: errorMessage
          }).eq("id", trackId).eq("user_id", userId);
          if (updateError) {
            console.error("Error updating failed track:", updateError);
          }
        }
        return new Response(JSON.stringify({
          success: false,
          status: taskStatus,
          error: statusData.data.fail_reason || "Generation failed"
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Suno record-info returns camelCase fields (audioUrl, imageUrl)
      // while callback uses snake_case (audio_url, image_url)
      // Normalize to handle both formats
      const normalizedRecords = records.map((r)=>({
          audioUrl: r.audioUrl || r.audio_url || r.source_audio_url || r.sourceAudioUrl,
          imageUrl: r.imageUrl || r.image_url || r.source_image_url || r.sourceImageUrl,
          duration: r.duration,
          id: r.id
        }));
      // Check if ANY record has a real audio URL (not empty string, null, undefined)
      const hasAnyAudio = normalizedRecords.some((r)=>r.audioUrl && String(r.audioUrl) !== "" && String(r.audioUrl) !== "null");
      if (normalizedRecords.length > 0 && hasAnyAudio) {
        // Find ALL tracks matching this task_id (both v1 and v2)
        const { data: matchedTracks } = await supabaseClient.from("tracks").select("id, title, description").eq("user_id", userId).in("status", [
          "processing",
          "pending"
        ]).order("created_at", {
          ascending: true
        });
        // Filter to tracks that have this task_id
        const tracksWithTask = (matchedTracks || []).filter((t)=>t.description?.includes(`[task_id: ${taskId}]`) || t.description?.includes(`[task_id:${taskId}]`));
        console.log(`Found ${tracksWithTask.length} tracks matching task_id ${taskId}`);
        // Update each track with corresponding Suno record (by order: first→v1, second→v2)
        // Download files to local storage for persistent access
        // CRITICAL: Only update tracks where the corresponding record has a valid audio URL
        for(let i = 0; i < tracksWithTask.length && i < normalizedRecords.length; i++){
          const rec = normalizedRecords[i];
          const trk = tracksWithTask[i];
          // CRITICAL: Skip records without valid audio URL
          // When status is FIRST_SUCCESS, only one of two records has audio
          const rawAudioUrl = rec.audioUrl ? String(rec.audioUrl) : "";
          if (!rawAudioUrl || rawAudioUrl === "" || rawAudioUrl === "null" || rawAudioUrl === "undefined") {
            console.log(`Track ${trk.id} (${trk.title}) — no audio URL yet, skipping (status: ${taskStatus})`);
            continue;
          }
          // Download audio to local storage
          let finalAudioUrl = rawAudioUrl;
          const localAudio = await downloadToLocalStorage(finalAudioUrl, "tracks", `audio/${trk.id}.mp3`);
          if (localAudio) finalAudioUrl = localAudio;
          // Download cover to local storage
          let finalCoverUrl = rec.imageUrl ? String(rec.imageUrl) : null;
          if (finalCoverUrl && (finalCoverUrl === "null" || finalCoverUrl === "undefined")) {
            finalCoverUrl = null;
          }
          if (finalCoverUrl) {
            const localCover = await downloadToLocalStorage(finalCoverUrl, "tracks", `covers/${trk.id}.jpg`);
            if (localCover) finalCoverUrl = localCover;
          }
          const { error: updateError } = await supabaseClient.from("tracks").update({
            audio_url: finalAudioUrl,
            cover_url: finalCoverUrl,
            duration: rec.duration ? Math.round(Number(rec.duration)) : null,
            status: "completed"
          }).eq("id", trk.id).eq("user_id", userId);
          if (updateError) {
            console.error(`Error updating track ${trk.id}:`, updateError);
          } else {
            console.log(`Track ${trk.id} (${trk.title}) completed via polling with local storage`);
          }
        }
      } else if (normalizedRecords.length > 0) {
        console.log(`Task ${taskId}: records exist but no audio URLs ready yet (status: ${taskStatus})`);
      }
      return new Response(JSON.stringify({
        success: true,
        status: taskStatus,
        records: normalizedRecords
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Handle API error response - but don't mark as failed for 404 (still processing)
    if (statusData.code !== 200) {
      console.log(`Suno API response: code=${statusData.code}, status=${statusData.status}`);
      // 404 often means the task is still being processed - don't mark as failed
      if (statusData.status === 404 || statusData.error === "Not Found") {
        console.log("Task not found in API - still processing, waiting for callback");
        return new Response(JSON.stringify({
          success: false,
          status: "processing",
          message: "Still processing, waiting for callback"
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // For other errors, mark as failed only if explicitly an error
      if (trackId && statusData.code && statusData.code >= 400 && statusData.code < 500 && statusData.code !== 404) {
        const { error: updateError } = await supabaseClient.from("tracks").update({
          status: "failed",
          error_message: statusData.msg || "API error"
        }).eq("id", trackId).eq("user_id", userId);
        if (updateError) {
          console.error("Error updating failed track:", updateError);
        }
      }
      return new Response(JSON.stringify({
        success: false,
        status: "processing",
        error: statusData.msg || "API error"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    return new Response(JSON.stringify({
      success: false,
      status: "pending",
      data: statusData
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in suno-check-status:", error);
    // Don't return 500 for network issues - just indicate still processing
    return new Response(JSON.stringify({
      success: false,
      status: "processing",
      message: "Checking status, waiting for callback"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9zdW5vLWNoZWNrLXN0YXR1cy9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmNvbnN0IFNVTk9fQVBJX0tFWSA9IERlbm8uZW52LmdldChcIlNVTk9fQVBJX0tFWVwiKTtcbmNvbnN0IFNVTk9fQVBJX0JBU0UgPSBcImh0dHBzOi8vYXBpYm94LmVyd2VpbWEuYWlcIjtcbmNvbnN0IFNVUEFCQVNFX1VSTCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSB8fCBcImh0dHA6Ly9hcGk6MzAwMFwiO1xuY29uc3QgU0VSVklDRV9ST0xFX0tFWSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikgfHwgXCJcIjtcbmNvbnN0IEJBU0VfVVJMID0gRGVuby5lbnYuZ2V0KFwiQkFTRV9VUkxcIikgfHwgXCJodHRwOi8vbG9jYWxob3N0XCI7XG5cbi8vIERvd25sb2FkIGV4dGVybmFsIGZpbGUgYW5kIHNhdmUgdG8gbG9jYWwgc3RvcmFnZSB2aWEgQVBJXG5hc3luYyBmdW5jdGlvbiBkb3dubG9hZFRvTG9jYWxTdG9yYWdlKFxuICBleHRlcm5hbFVybDogc3RyaW5nLFxuICBidWNrZXQ6IHN0cmluZyxcbiAgZmlsZVBhdGg6IHN0cmluZ1xuKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gIHRyeSB7XG4gICAgY29uc29sZS5sb2coYERvd25sb2FkaW5nICR7ZXh0ZXJuYWxVcmx9IOKGkiAke2J1Y2tldH0vJHtmaWxlUGF0aH1gKTtcbiAgICBjb25zdCByZXNwID0gYXdhaXQgZmV0Y2goZXh0ZXJuYWxVcmwpO1xuICAgIGlmICghcmVzcC5vaykge1xuICAgICAgY29uc29sZS5sb2coYERvd25sb2FkIGZhaWxlZDogJHtyZXNwLnN0YXR1c31gKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzcC5ibG9iKCk7XG4gICAgY29uc3QgYnVmZmVyID0gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpKTtcblxuICAgIC8vIFVwbG9hZCB0byBsb2NhbCBzdG9yYWdlIEFQSSAoUFVUIGZvciB1cHNlcnQpXG4gICAgY29uc3QgdXBsb2FkUmVzcCA9IGF3YWl0IGZldGNoKFxuICAgICAgYCR7U1VQQUJBU0VfVVJMfS9zdG9yYWdlL3YxL29iamVjdC8ke2J1Y2tldH0vJHtmaWxlUGF0aH1gLFxuICAgICAge1xuICAgICAgICBtZXRob2Q6IFwiUFVUXCIsXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBibG9iLnR5cGUgfHwgXCJhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW1cIixcbiAgICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NFUlZJQ0VfUk9MRV9LRVl9YCxcbiAgICAgICAgfSxcbiAgICAgICAgYm9keTogYnVmZmVyLFxuICAgICAgfVxuICAgICk7XG5cbiAgICBpZiAoIXVwbG9hZFJlc3Aub2spIHtcbiAgICAgIGNvbnN0IGVyclRleHQgPSBhd2FpdCB1cGxvYWRSZXNwLnRleHQoKTtcbiAgICAgIGNvbnNvbGUubG9nKGBVcGxvYWQgdG8gc3RvcmFnZSBmYWlsZWQ6ICR7dXBsb2FkUmVzcC5zdGF0dXN9ICR7ZXJyVGV4dH1gKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGNvbnN0IGxvY2FsVXJsID0gYCR7QkFTRV9VUkx9L3N0b3JhZ2UvdjEvb2JqZWN0L3B1YmxpYy8ke2J1Y2tldH0vJHtmaWxlUGF0aH1gO1xuICAgIGNvbnNvbGUubG9nKGBTYXZlZCB0byBsb2NhbCBzdG9yYWdlOiAke2xvY2FsVXJsfWApO1xuICAgIHJldHVybiBsb2NhbFVybDtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcihgRXJyb3IgZG93bmxvYWRpbmcgdG8gc3RvcmFnZTpgLCBlcnIpO1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbi8vIEZldGNoIHdpdGggcmV0cnkgbG9naWMgZm9yIGNvbm5lY3Rpb24gaXNzdWVzXG5hc3luYyBmdW5jdGlvbiBmZXRjaFdpdGhSZXRyeSh1cmw6IHN0cmluZywgb3B0aW9uczogUmVxdWVzdEluaXQsIG1heFJldHJpZXMgPSAyKTogUHJvbWlzZTxSZXNwb25zZT4ge1xuICBsZXQgbGFzdEVycm9yOiBFcnJvciB8IG51bGwgPSBudWxsO1xuICBcbiAgZm9yIChsZXQgYXR0ZW1wdCA9IDA7IGF0dGVtcHQgPD0gbWF4UmV0cmllczsgYXR0ZW1wdCsrKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICBjb25zdCB0aW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSwgMTAwMDApOyAvLyAxMHMgdGltZW91dFxuICAgICAgXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgfSk7XG4gICAgICBcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsYXN0RXJyb3IgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IgOiBuZXcgRXJyb3IoU3RyaW5nKGVycm9yKSk7XG4gICAgICBjb25zb2xlLmxvZyhgRmV0Y2ggYXR0ZW1wdCAke2F0dGVtcHQgKyAxfSBmYWlsZWQ6YCwgbGFzdEVycm9yLm1lc3NhZ2UpO1xuICAgICAgXG4gICAgICAvLyBEb24ndCByZXRyeSBvbiBhYm9ydFxuICAgICAgaWYgKGxhc3RFcnJvci5uYW1lID09PSAnQWJvcnRFcnJvcicpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUmVxdWVzdCB0aW1lb3V0XCIpO1xuICAgICAgfVxuICAgICAgXG4gICAgICAvLyBXYWl0IGJlZm9yZSByZXRyeSAoZXhwb25lbnRpYWwgYmFja29mZilcbiAgICAgIGlmIChhdHRlbXB0IDwgbWF4UmV0cmllcykge1xuICAgICAgICBhd2FpdCBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgMTAwMCAqIChhdHRlbXB0ICsgMSkpKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgXG4gIHRocm93IGxhc3RFcnJvciB8fCBuZXcgRXJyb3IoXCJGYWlsZWQgYWZ0ZXIgcmV0cmllc1wiKTtcbn1cblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcj8uc3RhcnRzV2l0aChcIkJlYXJlciBcIikpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiTm8gYXV0aG9yaXphdGlvbiBoZWFkZXJcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlQ2xpZW50ID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpID8/IFwiXCIsXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSA/PyBcIlwiLFxuICAgICAgeyBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfSB9XG4gICAgKTtcblxuICAgIC8vIEdldCB1c2VyIHZpYSBBUEktY29tcGF0aWJsZSBhdXRoIGVuZHBvaW50XG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IHVzZXJFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnQuYXV0aC5nZXRVc2VyKCk7XG4gICAgXG4gICAgaWYgKHVzZXJFcnJvciB8fCAhdXNlcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkF1dGggZXJyb3I6XCIsIHVzZXJFcnJvcik7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHVzZXJJZCA9IHVzZXIuaWQ7XG5cbiAgICBjb25zdCB7IHRhc2tJZDogcmF3VGFza0lkLCB0cmFja0lkIH0gPSBhd2FpdCByZXEuanNvbigpO1xuICAgIFxuICAgIC8vIFRyaW0gd2hpdGVzcGFjZSBmcm9tIHRhc2tJZCB0byBwcmV2ZW50IFVSTCBlbmNvZGluZyBpc3N1ZXNcbiAgICBjb25zdCB0YXNrSWQgPSByYXdUYXNrSWQ/LnRyaW0oKTtcblxuICAgIGlmICghdGFza0lkKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk1pc3NpbmcgdGFza0lkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgQ2hlY2tpbmcgc3RhdHVzIGZvciB0YXNrICR7dGFza0lkfWApO1xuXG4gICAgbGV0IHN0YXR1c0RhdGE7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0YXR1c1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2hXaXRoUmV0cnkoXG4gICAgICAgIGAke1NVTk9fQVBJX0JBU0V9L2FwaS92MS9nZW5lcmF0ZS9yZWNvcmQtaW5mbz90YXNrSWQ9JHtlbmNvZGVVUklDb21wb25lbnQodGFza0lkKX1gLFxuICAgICAgICB7XG4gICAgICAgICAgbWV0aG9kOiBcIkdFVFwiLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICAgICAgfSxcbiAgICAgICAgfVxuICAgICAgKTtcbiAgICAgIHN0YXR1c0RhdGEgPSBhd2FpdCBzdGF0dXNSZXNwb25zZS5qc29uKCk7XG4gICAgfSBjYXRjaCAoZmV0Y2hFcnJvcikge1xuICAgICAgLy8gTmV0d29yayBlcnJvciAtIGRvbid0IG1hcmsgdHJhY2sgYXMgZmFpbGVkLCBqdXN0IHJldHVybiBwcm9jZXNzaW5nIHN0YXR1c1xuICAgICAgY29uc29sZS5sb2coYE5ldHdvcmsgZXJyb3IgY2hlY2tpbmcgc3RhdHVzICh3aWxsIHJldHJ5IHZpYSBwb2xsaW5nKTpgLCBmZXRjaEVycm9yKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgICAgc3RhdHVzOiBcInByb2Nlc3NpbmdcIixcbiAgICAgICAgICBtZXNzYWdlOiBcIk5ldHdvcmsgaXNzdWUsIHdhaXRpbmcgZm9yIGNhbGxiYWNrXCJcbiAgICAgICAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKFwiU3RhdHVzIHJlc3BvbnNlOlwiLCBKU09OLnN0cmluZ2lmeShzdGF0dXNEYXRhKSk7XG5cbiAgICBpZiAoc3RhdHVzRGF0YS5jb2RlID09PSAyMDAgJiYgc3RhdHVzRGF0YS5kYXRhKSB7XG4gICAgICBjb25zdCByZWNvcmRzID0gc3RhdHVzRGF0YS5kYXRhLnJlc3BvbnNlPy5zdW5vRGF0YSB8fCBzdGF0dXNEYXRhLmRhdGEuZGF0YSB8fCBbXTtcbiAgICAgIGNvbnN0IHRhc2tTdGF0dXMgPSBzdGF0dXNEYXRhLmRhdGEuc3RhdHVzO1xuICAgICAgXG4gICAgICBjb25zb2xlLmxvZyhgVGFzayBzdGF0dXM6ICR7dGFza1N0YXR1c30sIFJlY29yZHM6ICR7cmVjb3Jkcy5sZW5ndGh9YCk7XG4gICAgICBcbiAgICAgIC8vIENoZWNrIGZvciBmYWlsZWQgc3RhdHVzIC0gaGFuZGxlIEdFTkVSQVRFX0FVRElPX0ZBSUxFRCBhbmQgb3RoZXIgZmFpbHVyZSBzdGF0ZXNcbiAgICAgIGlmICh0YXNrU3RhdHVzID09PSBcIkdFTkVSQVRFX0FVRElPX0ZBSUxFRFwiIHx8IHRhc2tTdGF0dXMgPT09IFwiRkFJTEVEXCIgfHwgdGFza1N0YXR1cyA9PT0gXCJFUlJPUlwiKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBUYXNrICR7dGFza0lkfSBmYWlsZWQgd2l0aCBzdGF0dXM6ICR7dGFza1N0YXR1c31gKTtcbiAgICAgICAgXG4gICAgICAgIGlmICh0cmFja0lkKSB7XG4gICAgICAgICAgY29uc3QgZXJyb3JNZXNzYWdlID0gc3RhdHVzRGF0YS5kYXRhLmZhaWxfcmVhc29uIHx8IHN0YXR1c0RhdGEuZGF0YS5lcnJvcl9tZXNzYWdlIHx8IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c0RhdGEubXNnIHx8IFwi0JPQtdC90LXRgNCw0YbQuNGPINC+0YLQutC70L7QvdC10L3QsCDRgdC10YDQstC40YHQvtC8XCI7XG4gICAgICAgICAgXG4gICAgICAgICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgICAgICAgZXJyb3JfbWVzc2FnZTogZXJyb3JNZXNzYWdlLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpXG4gICAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZCk7XG5cbiAgICAgICAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBmYWlsZWQgdHJhY2s6XCIsIHVwZGF0ZUVycm9yKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgICAgc3RhdHVzOiB0YXNrU3RhdHVzLFxuICAgICAgICAgICAgZXJyb3I6IHN0YXR1c0RhdGEuZGF0YS5mYWlsX3JlYXNvbiB8fCBcIkdlbmVyYXRpb24gZmFpbGVkXCJcbiAgICAgICAgICB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgXG4gICAgICAvLyBTdW5vIHJlY29yZC1pbmZvIHJldHVybnMgY2FtZWxDYXNlIGZpZWxkcyAoYXVkaW9VcmwsIGltYWdlVXJsKVxuICAgICAgLy8gd2hpbGUgY2FsbGJhY2sgdXNlcyBzbmFrZV9jYXNlIChhdWRpb191cmwsIGltYWdlX3VybClcbiAgICAgIC8vIE5vcm1hbGl6ZSB0byBoYW5kbGUgYm90aCBmb3JtYXRzXG4gICAgICBjb25zdCBub3JtYWxpemVkUmVjb3JkcyA9IHJlY29yZHMubWFwKChyOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikgPT4gKHtcbiAgICAgICAgYXVkaW9Vcmw6IHIuYXVkaW9VcmwgfHwgci5hdWRpb191cmwgfHwgci5zb3VyY2VfYXVkaW9fdXJsIHx8IHIuc291cmNlQXVkaW9VcmwsXG4gICAgICAgIGltYWdlVXJsOiByLmltYWdlVXJsIHx8IHIuaW1hZ2VfdXJsIHx8IHIuc291cmNlX2ltYWdlX3VybCB8fCByLnNvdXJjZUltYWdlVXJsLFxuICAgICAgICBkdXJhdGlvbjogci5kdXJhdGlvbixcbiAgICAgICAgaWQ6IHIuaWQsXG4gICAgICB9KSk7XG5cbiAgICAgIC8vIENoZWNrIGlmIEFOWSByZWNvcmQgaGFzIGEgcmVhbCBhdWRpbyBVUkwgKG5vdCBlbXB0eSBzdHJpbmcsIG51bGwsIHVuZGVmaW5lZClcbiAgICAgIGNvbnN0IGhhc0FueUF1ZGlvID0gbm9ybWFsaXplZFJlY29yZHMuc29tZShcbiAgICAgICAgKHI6IHsgYXVkaW9Vcmw6IHVua25vd24gfSkgPT4gci5hdWRpb1VybCAmJiBTdHJpbmcoci5hdWRpb1VybCkgIT09IFwiXCIgJiYgU3RyaW5nKHIuYXVkaW9VcmwpICE9PSBcIm51bGxcIlxuICAgICAgKTtcblxuICAgICAgaWYgKG5vcm1hbGl6ZWRSZWNvcmRzLmxlbmd0aCA+IDAgJiYgaGFzQW55QXVkaW8pIHtcbiAgICAgICAgLy8gRmluZCBBTEwgdHJhY2tzIG1hdGNoaW5nIHRoaXMgdGFza19pZCAoYm90aCB2MSBhbmQgdjIpXG4gICAgICAgIGNvbnN0IHsgZGF0YTogbWF0Y2hlZFRyYWNrcyB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgIC5zZWxlY3QoXCJpZCwgdGl0bGUsIGRlc2NyaXB0aW9uXCIpXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpXG4gICAgICAgICAgLmluKFwic3RhdHVzXCIsIFtcInByb2Nlc3NpbmdcIiwgXCJwZW5kaW5nXCJdKVxuICAgICAgICAgIC5vcmRlcihcImNyZWF0ZWRfYXRcIiwgeyBhc2NlbmRpbmc6IHRydWUgfSk7XG5cbiAgICAgICAgLy8gRmlsdGVyIHRvIHRyYWNrcyB0aGF0IGhhdmUgdGhpcyB0YXNrX2lkXG4gICAgICAgIGNvbnN0IHRyYWNrc1dpdGhUYXNrID0gKG1hdGNoZWRUcmFja3MgfHwgW10pLmZpbHRlcihcbiAgICAgICAgICAodDogeyBkZXNjcmlwdGlvbj86IHN0cmluZyB9KSA9PiB0LmRlc2NyaXB0aW9uPy5pbmNsdWRlcyhgW3Rhc2tfaWQ6ICR7dGFza0lkfV1gKSB8fCB0LmRlc2NyaXB0aW9uPy5pbmNsdWRlcyhgW3Rhc2tfaWQ6JHt0YXNrSWR9XWApXG4gICAgICAgICk7XG5cbiAgICAgICAgY29uc29sZS5sb2coYEZvdW5kICR7dHJhY2tzV2l0aFRhc2subGVuZ3RofSB0cmFja3MgbWF0Y2hpbmcgdGFza19pZCAke3Rhc2tJZH1gKTtcblxuICAgICAgICAvLyBVcGRhdGUgZWFjaCB0cmFjayB3aXRoIGNvcnJlc3BvbmRpbmcgU3VubyByZWNvcmQgKGJ5IG9yZGVyOiBmaXJzdOKGknYxLCBzZWNvbmTihpJ2MilcbiAgICAgICAgLy8gRG93bmxvYWQgZmlsZXMgdG8gbG9jYWwgc3RvcmFnZSBmb3IgcGVyc2lzdGVudCBhY2Nlc3NcbiAgICAgICAgLy8gQ1JJVElDQUw6IE9ubHkgdXBkYXRlIHRyYWNrcyB3aGVyZSB0aGUgY29ycmVzcG9uZGluZyByZWNvcmQgaGFzIGEgdmFsaWQgYXVkaW8gVVJMXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdHJhY2tzV2l0aFRhc2subGVuZ3RoICYmIGkgPCBub3JtYWxpemVkUmVjb3Jkcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGNvbnN0IHJlYyA9IG5vcm1hbGl6ZWRSZWNvcmRzW2ldO1xuICAgICAgICAgIGNvbnN0IHRyayA9IHRyYWNrc1dpdGhUYXNrW2ldO1xuICAgICAgICAgIFxuICAgICAgICAgIC8vIENSSVRJQ0FMOiBTa2lwIHJlY29yZHMgd2l0aG91dCB2YWxpZCBhdWRpbyBVUkxcbiAgICAgICAgICAvLyBXaGVuIHN0YXR1cyBpcyBGSVJTVF9TVUNDRVNTLCBvbmx5IG9uZSBvZiB0d28gcmVjb3JkcyBoYXMgYXVkaW9cbiAgICAgICAgICBjb25zdCByYXdBdWRpb1VybCA9IHJlYy5hdWRpb1VybCA/IFN0cmluZyhyZWMuYXVkaW9VcmwpIDogXCJcIjtcbiAgICAgICAgICBpZiAoIXJhd0F1ZGlvVXJsIHx8IHJhd0F1ZGlvVXJsID09PSBcIlwiIHx8IHJhd0F1ZGlvVXJsID09PSBcIm51bGxcIiB8fCByYXdBdWRpb1VybCA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYFRyYWNrICR7dHJrLmlkfSAoJHt0cmsudGl0bGV9KSDigJQgbm8gYXVkaW8gVVJMIHlldCwgc2tpcHBpbmcgKHN0YXR1czogJHt0YXNrU3RhdHVzfSlgKTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBcbiAgICAgICAgICAvLyBEb3dubG9hZCBhdWRpbyB0byBsb2NhbCBzdG9yYWdlXG4gICAgICAgICAgbGV0IGZpbmFsQXVkaW9VcmwgPSByYXdBdWRpb1VybDtcbiAgICAgICAgICBjb25zdCBsb2NhbEF1ZGlvID0gYXdhaXQgZG93bmxvYWRUb0xvY2FsU3RvcmFnZShcbiAgICAgICAgICAgIGZpbmFsQXVkaW9VcmwsXG4gICAgICAgICAgICBcInRyYWNrc1wiLFxuICAgICAgICAgICAgYGF1ZGlvLyR7dHJrLmlkfS5tcDNgXG4gICAgICAgICAgKTtcbiAgICAgICAgICBpZiAobG9jYWxBdWRpbykgZmluYWxBdWRpb1VybCA9IGxvY2FsQXVkaW87XG5cbiAgICAgICAgICAvLyBEb3dubG9hZCBjb3ZlciB0byBsb2NhbCBzdG9yYWdlXG4gICAgICAgICAgbGV0IGZpbmFsQ292ZXJVcmw6IHN0cmluZyB8IG51bGwgPSByZWMuaW1hZ2VVcmwgPyBTdHJpbmcocmVjLmltYWdlVXJsKSA6IG51bGw7XG4gICAgICAgICAgaWYgKGZpbmFsQ292ZXJVcmwgJiYgKGZpbmFsQ292ZXJVcmwgPT09IFwibnVsbFwiIHx8IGZpbmFsQ292ZXJVcmwgPT09IFwidW5kZWZpbmVkXCIpKSB7XG4gICAgICAgICAgICBmaW5hbENvdmVyVXJsID0gbnVsbDtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGZpbmFsQ292ZXJVcmwpIHtcbiAgICAgICAgICAgIGNvbnN0IGxvY2FsQ292ZXIgPSBhd2FpdCBkb3dubG9hZFRvTG9jYWxTdG9yYWdlKFxuICAgICAgICAgICAgICBmaW5hbENvdmVyVXJsLFxuICAgICAgICAgICAgICBcInRyYWNrc1wiLFxuICAgICAgICAgICAgICBgY292ZXJzLyR7dHJrLmlkfS5qcGdgXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgaWYgKGxvY2FsQ292ZXIpIGZpbmFsQ292ZXJVcmwgPSBsb2NhbENvdmVyO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgICAgICBhdWRpb191cmw6IGZpbmFsQXVkaW9VcmwsXG4gICAgICAgICAgICAgIGNvdmVyX3VybDogZmluYWxDb3ZlclVybCxcbiAgICAgICAgICAgICAgZHVyYXRpb246IHJlYy5kdXJhdGlvbiA/IE1hdGgucm91bmQoTnVtYmVyKHJlYy5kdXJhdGlvbikpIDogbnVsbCxcbiAgICAgICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5lcShcImlkXCIsIHRyay5pZClcbiAgICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKTtcblxuICAgICAgICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgdXBkYXRpbmcgdHJhY2sgJHt0cmsuaWR9OmAsIHVwZGF0ZUVycm9yKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYFRyYWNrICR7dHJrLmlkfSAoJHt0cmsudGl0bGV9KSBjb21wbGV0ZWQgdmlhIHBvbGxpbmcgd2l0aCBsb2NhbCBzdG9yYWdlYCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKG5vcm1hbGl6ZWRSZWNvcmRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgY29uc29sZS5sb2coYFRhc2sgJHt0YXNrSWR9OiByZWNvcmRzIGV4aXN0IGJ1dCBubyBhdWRpbyBVUkxzIHJlYWR5IHlldCAoc3RhdHVzOiAke3Rhc2tTdGF0dXN9KWApO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgc3RhdHVzOiB0YXNrU3RhdHVzLFxuICAgICAgICAgIHJlY29yZHM6IG5vcm1hbGl6ZWRSZWNvcmRzIFxuICAgICAgICB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuICAgIFxuICAgIC8vIEhhbmRsZSBBUEkgZXJyb3IgcmVzcG9uc2UgLSBidXQgZG9uJ3QgbWFyayBhcyBmYWlsZWQgZm9yIDQwNCAoc3RpbGwgcHJvY2Vzc2luZylcbiAgICBpZiAoc3RhdHVzRGF0YS5jb2RlICE9PSAyMDApIHtcbiAgICAgIGNvbnNvbGUubG9nKGBTdW5vIEFQSSByZXNwb25zZTogY29kZT0ke3N0YXR1c0RhdGEuY29kZX0sIHN0YXR1cz0ke3N0YXR1c0RhdGEuc3RhdHVzfWApO1xuICAgICAgXG4gICAgICAvLyA0MDQgb2Z0ZW4gbWVhbnMgdGhlIHRhc2sgaXMgc3RpbGwgYmVpbmcgcHJvY2Vzc2VkIC0gZG9uJ3QgbWFyayBhcyBmYWlsZWRcbiAgICAgIGlmIChzdGF0dXNEYXRhLnN0YXR1cyA9PT0gNDA0IHx8IHN0YXR1c0RhdGEuZXJyb3IgPT09IFwiTm90IEZvdW5kXCIpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJUYXNrIG5vdCBmb3VuZCBpbiBBUEkgLSBzdGlsbCBwcm9jZXNzaW5nLCB3YWl0aW5nIGZvciBjYWxsYmFja1wiKTtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgICAgICBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJTdGlsbCBwcm9jZXNzaW5nLCB3YWl0aW5nIGZvciBjYWxsYmFja1wiXG4gICAgICAgICAgfSksXG4gICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgLy8gRm9yIG90aGVyIGVycm9ycywgbWFyayBhcyBmYWlsZWQgb25seSBpZiBleHBsaWNpdGx5IGFuIGVycm9yXG4gICAgICBpZiAodHJhY2tJZCAmJiBzdGF0dXNEYXRhLmNvZGUgJiYgc3RhdHVzRGF0YS5jb2RlID49IDQwMCAmJiBzdGF0dXNEYXRhLmNvZGUgPCA1MDAgJiYgc3RhdHVzRGF0YS5jb2RlICE9PSA0MDQpIHtcbiAgICAgICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgICAgIGVycm9yX21lc3NhZ2U6IHN0YXR1c0RhdGEubXNnIHx8IFwiQVBJIGVycm9yXCIsXG4gICAgICAgICAgfSlcbiAgICAgICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKVxuICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKTtcblxuICAgICAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgZmFpbGVkIHRyYWNrOlwiLCB1cGRhdGVFcnJvcik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIFxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiLFxuICAgICAgICAgIGVycm9yOiBzdGF0dXNEYXRhLm1zZyB8fCBcIkFQSSBlcnJvclwiXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIHN0YXR1czogXCJwZW5kaW5nXCIsXG4gICAgICAgIGRhdGE6IHN0YXR1c0RhdGFcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIHN1bm8tY2hlY2stc3RhdHVzOlwiLCBlcnJvcik7XG4gICAgLy8gRG9uJ3QgcmV0dXJuIDUwMCBmb3IgbmV0d29yayBpc3N1ZXMgLSBqdXN0IGluZGljYXRlIHN0aWxsIHByb2Nlc3NpbmdcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIHN0YXR1czogXCJwcm9jZXNzaW5nXCIsXG4gICAgICAgIG1lc3NhZ2U6IFwiQ2hlY2tpbmcgc3RhdHVzLCB3YWl0aW5nIGZvciBjYWxsYmFja1wiXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2xDLE1BQU0sZ0JBQWdCO0FBQ3RCLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CO0FBQ3JELE1BQU0sbUJBQW1CLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0M7QUFDdEUsTUFBTSxXQUFXLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxlQUFlO0FBRTdDLDJEQUEyRDtBQUMzRCxlQUFlLHVCQUNiLFdBQW1CLEVBQ25CLE1BQWMsRUFDZCxRQUFnQjtFQUVoQixJQUFJO0lBQ0YsUUFBUSxHQUFHLENBQUMsQ0FBQyxZQUFZLEVBQUUsWUFBWSxHQUFHLEVBQUUsT0FBTyxDQUFDLEVBQUUsU0FBUyxDQUFDO0lBQ2hFLE1BQU0sT0FBTyxNQUFNLE1BQU07SUFDekIsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFO01BQ1osUUFBUSxHQUFHLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLE1BQU0sQ0FBQyxDQUFDO01BQzdDLE9BQU87SUFDVDtJQUNBLE1BQU0sT0FBTyxNQUFNLEtBQUssSUFBSTtJQUM1QixNQUFNLFNBQVMsSUFBSSxXQUFXLE1BQU0sS0FBSyxXQUFXO0lBRXBELCtDQUErQztJQUMvQyxNQUFNLGFBQWEsTUFBTSxNQUN2QixDQUFDLEVBQUUsYUFBYSxtQkFBbUIsRUFBRSxPQUFPLENBQUMsRUFBRSxTQUFTLENBQUMsRUFDekQ7TUFDRSxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQixLQUFLLElBQUksSUFBSTtRQUM3QixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLENBQUM7TUFDL0M7TUFDQSxNQUFNO0lBQ1I7SUFHRixJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUU7TUFDbEIsTUFBTSxVQUFVLE1BQU0sV0FBVyxJQUFJO01BQ3JDLFFBQVEsR0FBRyxDQUFDLENBQUMsMEJBQTBCLEVBQUUsV0FBVyxNQUFNLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQztNQUN2RSxPQUFPO0lBQ1Q7SUFFQSxNQUFNLFdBQVcsQ0FBQyxFQUFFLFNBQVMsMEJBQTBCLEVBQUUsT0FBTyxDQUFDLEVBQUUsU0FBUyxDQUFDO0lBQzdFLFFBQVEsR0FBRyxDQUFDLENBQUMsd0JBQXdCLEVBQUUsU0FBUyxDQUFDO0lBQ2pELE9BQU87RUFDVCxFQUFFLE9BQU8sS0FBSztJQUNaLFFBQVEsS0FBSyxDQUFDLENBQUMsNkJBQTZCLENBQUMsRUFBRTtJQUMvQyxPQUFPO0VBQ1Q7QUFDRjtBQUVBLCtDQUErQztBQUMvQyxlQUFlLGVBQWUsR0FBVyxFQUFFLE9BQW9CLEVBQUUsYUFBYSxDQUFDO0VBQzdFLElBQUksWUFBMEI7RUFFOUIsSUFBSyxJQUFJLFVBQVUsR0FBRyxXQUFXLFlBQVksVUFBVztJQUN0RCxJQUFJO01BQ0YsTUFBTSxhQUFhLElBQUk7TUFDdkIsTUFBTSxZQUFZLFdBQVcsSUFBTSxXQUFXLEtBQUssSUFBSSxRQUFRLGNBQWM7TUFFN0UsTUFBTSxXQUFXLE1BQU0sTUFBTSxLQUFLO1FBQ2hDLEdBQUcsT0FBTztRQUNWLFFBQVEsV0FBVyxNQUFNO01BQzNCO01BRUEsYUFBYTtNQUNiLE9BQU87SUFDVCxFQUFFLE9BQU8sT0FBTztNQUNkLFlBQVksaUJBQWlCLFFBQVEsUUFBUSxJQUFJLE1BQU0sT0FBTztNQUM5RCxRQUFRLEdBQUcsQ0FBQyxDQUFDLGNBQWMsRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDLEVBQUUsVUFBVSxPQUFPO01BRXJFLHVCQUF1QjtNQUN2QixJQUFJLFVBQVUsSUFBSSxLQUFLLGNBQWM7UUFDbkMsTUFBTSxJQUFJLE1BQU07TUFDbEI7TUFFQSwwQ0FBMEM7TUFDMUMsSUFBSSxVQUFVLFlBQVk7UUFDeEIsTUFBTSxJQUFJLFFBQVEsQ0FBQSxVQUFXLFdBQVcsU0FBUyxPQUFPLENBQUMsVUFBVSxDQUFDO01BQ3RFO0lBQ0Y7RUFDRjtFQUVBLE1BQU0sYUFBYSxJQUFJLE1BQU07QUFDL0I7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZLFdBQVcsWUFBWTtNQUN0QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBMEIsSUFDbEQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxpQkFBaUIsYUFDckIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLElBQ3JDO01BQUUsUUFBUTtRQUFFLFNBQVM7VUFBRSxlQUFlO1FBQVc7TUFBRTtJQUFFO0lBR3ZELDRDQUE0QztJQUM1QyxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxPQUFPO0lBRTlFLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsUUFBUSxLQUFLLENBQUMsZUFBZTtNQUM3QixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFNBQVMsS0FBSyxFQUFFO0lBRXRCLE1BQU0sRUFBRSxRQUFRLFNBQVMsRUFBRSxPQUFPLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUVyRCw2REFBNkQ7SUFDN0QsTUFBTSxTQUFTLFdBQVc7SUFFMUIsSUFBSSxDQUFDLFFBQVE7TUFDWCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBaUIsSUFDekM7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBRSxPQUFPLENBQUM7SUFFaEQsSUFBSTtJQUNKLElBQUk7TUFDRixNQUFNLGlCQUFpQixNQUFNLGVBQzNCLENBQUMsRUFBRSxjQUFjLG9DQUFvQyxFQUFFLG1CQUFtQixRQUFRLENBQUMsRUFDbkY7UUFDRSxRQUFRO1FBQ1IsU0FBUztVQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7UUFDM0M7TUFDRjtNQUVGLGFBQWEsTUFBTSxlQUFlLElBQUk7SUFDeEMsRUFBRSxPQUFPLFlBQVk7TUFDbkIsNEVBQTRFO01BQzVFLFFBQVEsR0FBRyxDQUFDLENBQUMsdURBQXVELENBQUMsRUFBRTtNQUN2RSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVCxRQUFRO1FBQ1IsU0FBUztNQUNYLElBQ0E7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxRQUFRLEdBQUcsQ0FBQyxvQkFBb0IsS0FBSyxTQUFTLENBQUM7SUFFL0MsSUFBSSxXQUFXLElBQUksS0FBSyxPQUFPLFdBQVcsSUFBSSxFQUFFO01BQzlDLE1BQU0sVUFBVSxXQUFXLElBQUksQ0FBQyxRQUFRLEVBQUUsWUFBWSxXQUFXLElBQUksQ0FBQyxJQUFJLElBQUksRUFBRTtNQUNoRixNQUFNLGFBQWEsV0FBVyxJQUFJLENBQUMsTUFBTTtNQUV6QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLGFBQWEsRUFBRSxXQUFXLFdBQVcsRUFBRSxRQUFRLE1BQU0sQ0FBQyxDQUFDO01BRXBFLGtGQUFrRjtNQUNsRixJQUFJLGVBQWUsMkJBQTJCLGVBQWUsWUFBWSxlQUFlLFNBQVM7UUFDL0YsUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxxQkFBcUIsRUFBRSxXQUFXLENBQUM7UUFFOUQsSUFBSSxTQUFTO1VBQ1gsTUFBTSxlQUFlLFdBQVcsSUFBSSxDQUFDLFdBQVcsSUFBSSxXQUFXLElBQUksQ0FBQyxhQUFhLElBQzVELFdBQVcsR0FBRyxJQUFJO1VBRXZDLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sZUFDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1lBQ04sUUFBUTtZQUNSLGVBQWU7VUFDakIsR0FDQyxFQUFFLENBQUMsTUFBTSxTQUNULEVBQUUsQ0FBQyxXQUFXO1VBRWpCLElBQUksYUFBYTtZQUNmLFFBQVEsS0FBSyxDQUFDLGdDQUFnQztVQUNoRDtRQUNGO1FBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsUUFBUTtVQUNSLE9BQU8sV0FBVyxJQUFJLENBQUMsV0FBVyxJQUFJO1FBQ3hDLElBQ0E7VUFBRSxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFdEU7TUFFQSxpRUFBaUU7TUFDakUsd0RBQXdEO01BQ3hELG1DQUFtQztNQUNuQyxNQUFNLG9CQUFvQixRQUFRLEdBQUcsQ0FBQyxDQUFDLElBQStCLENBQUM7VUFDckUsVUFBVSxFQUFFLFFBQVEsSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLGdCQUFnQixJQUFJLEVBQUUsY0FBYztVQUM3RSxVQUFVLEVBQUUsUUFBUSxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsZ0JBQWdCLElBQUksRUFBRSxjQUFjO1VBQzdFLFVBQVUsRUFBRSxRQUFRO1VBQ3BCLElBQUksRUFBRSxFQUFFO1FBQ1YsQ0FBQztNQUVELCtFQUErRTtNQUMvRSxNQUFNLGNBQWMsa0JBQWtCLElBQUksQ0FDeEMsQ0FBQyxJQUE2QixFQUFFLFFBQVEsSUFBSSxPQUFPLEVBQUUsUUFBUSxNQUFNLE1BQU0sT0FBTyxFQUFFLFFBQVEsTUFBTTtNQUdsRyxJQUFJLGtCQUFrQixNQUFNLEdBQUcsS0FBSyxhQUFhO1FBQy9DLHlEQUF5RDtRQUN6RCxNQUFNLEVBQUUsTUFBTSxhQUFhLEVBQUUsR0FBRyxNQUFNLGVBQ25DLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQywwQkFDUCxFQUFFLENBQUMsV0FBVyxRQUNkLEVBQUUsQ0FBQyxVQUFVO1VBQUM7VUFBYztTQUFVLEVBQ3RDLEtBQUssQ0FBQyxjQUFjO1VBQUUsV0FBVztRQUFLO1FBRXpDLDBDQUEwQztRQUMxQyxNQUFNLGlCQUFpQixDQUFDLGlCQUFpQixFQUFFLEVBQUUsTUFBTSxDQUNqRCxDQUFDLElBQWdDLEVBQUUsV0FBVyxFQUFFLFNBQVMsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxTQUFTLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBR25JLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLGVBQWUsTUFBTSxDQUFDLHlCQUF5QixFQUFFLE9BQU8sQ0FBQztRQUU5RSxtRkFBbUY7UUFDbkYsd0RBQXdEO1FBQ3hELG9GQUFvRjtRQUNwRixJQUFLLElBQUksSUFBSSxHQUFHLElBQUksZUFBZSxNQUFNLElBQUksSUFBSSxrQkFBa0IsTUFBTSxFQUFFLElBQUs7VUFDOUUsTUFBTSxNQUFNLGlCQUFpQixDQUFDLEVBQUU7VUFDaEMsTUFBTSxNQUFNLGNBQWMsQ0FBQyxFQUFFO1VBRTdCLGlEQUFpRDtVQUNqRCxrRUFBa0U7VUFDbEUsTUFBTSxjQUFjLElBQUksUUFBUSxHQUFHLE9BQU8sSUFBSSxRQUFRLElBQUk7VUFDMUQsSUFBSSxDQUFDLGVBQWUsZ0JBQWdCLE1BQU0sZ0JBQWdCLFVBQVUsZ0JBQWdCLGFBQWE7WUFDL0YsUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFLElBQUksS0FBSyxDQUFDLHdDQUF3QyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBQ2pHO1VBQ0Y7VUFFQSxrQ0FBa0M7VUFDbEMsSUFBSSxnQkFBZ0I7VUFDcEIsTUFBTSxhQUFhLE1BQU0sdUJBQ3ZCLGVBQ0EsVUFDQSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUM7VUFFdkIsSUFBSSxZQUFZLGdCQUFnQjtVQUVoQyxrQ0FBa0M7VUFDbEMsSUFBSSxnQkFBK0IsSUFBSSxRQUFRLEdBQUcsT0FBTyxJQUFJLFFBQVEsSUFBSTtVQUN6RSxJQUFJLGlCQUFpQixDQUFDLGtCQUFrQixVQUFVLGtCQUFrQixXQUFXLEdBQUc7WUFDaEYsZ0JBQWdCO1VBQ2xCO1VBQ0EsSUFBSSxlQUFlO1lBQ2pCLE1BQU0sYUFBYSxNQUFNLHVCQUN2QixlQUNBLFVBQ0EsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDO1lBRXhCLElBQUksWUFBWSxnQkFBZ0I7VUFDbEM7VUFFQSxNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLGVBQ2xDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztZQUNOLFdBQVc7WUFDWCxXQUFXO1lBQ1gsVUFBVSxJQUFJLFFBQVEsR0FBRyxLQUFLLEtBQUssQ0FBQyxPQUFPLElBQUksUUFBUSxLQUFLO1lBQzVELFFBQVE7VUFDVixHQUNDLEVBQUUsQ0FBQyxNQUFNLElBQUksRUFBRSxFQUNmLEVBQUUsQ0FBQyxXQUFXO1VBRWpCLElBQUksYUFBYTtZQUNmLFFBQVEsS0FBSyxDQUFDLENBQUMscUJBQXFCLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUU7VUFDbkQsT0FBTztZQUNMLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsRUFBRSxJQUFJLEtBQUssQ0FBQywwQ0FBMEMsQ0FBQztVQUN2RjtRQUNGO01BQ0YsT0FBTyxJQUFJLGtCQUFrQixNQUFNLEdBQUcsR0FBRztRQUN2QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxPQUFPLHFEQUFxRCxFQUFFLFdBQVcsQ0FBQyxDQUFDO01BQ2pHO01BRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixTQUFTO1FBQ1QsUUFBUTtRQUNSLFNBQVM7TUFDWCxJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsa0ZBQWtGO0lBQ2xGLElBQUksV0FBVyxJQUFJLEtBQUssS0FBSztNQUMzQixRQUFRLEdBQUcsQ0FBQyxDQUFDLHdCQUF3QixFQUFFLFdBQVcsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLE1BQU0sQ0FBQyxDQUFDO01BRXJGLDJFQUEyRTtNQUMzRSxJQUFJLFdBQVcsTUFBTSxLQUFLLE9BQU8sV0FBVyxLQUFLLEtBQUssYUFBYTtRQUNqRSxRQUFRLEdBQUcsQ0FBQztRQUNaLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQ2IsU0FBUztVQUNULFFBQVE7VUFDUixTQUFTO1FBQ1gsSUFDQTtVQUFFLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUV0RTtNQUVBLCtEQUErRDtNQUMvRCxJQUFJLFdBQVcsV0FBVyxJQUFJLElBQUksV0FBVyxJQUFJLElBQUksT0FBTyxXQUFXLElBQUksR0FBRyxPQUFPLFdBQVcsSUFBSSxLQUFLLEtBQUs7UUFDNUcsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxlQUNsQyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7VUFDTixRQUFRO1VBQ1IsZUFBZSxXQUFXLEdBQUcsSUFBSTtRQUNuQyxHQUNDLEVBQUUsQ0FBQyxNQUFNLFNBQ1QsRUFBRSxDQUFDLFdBQVc7UUFFakIsSUFBSSxhQUFhO1VBQ2YsUUFBUSxLQUFLLENBQUMsZ0NBQWdDO1FBQ2hEO01BQ0Y7TUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVCxRQUFRO1FBQ1IsT0FBTyxXQUFXLEdBQUcsSUFBSTtNQUMzQixJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsUUFBUTtNQUNSLE1BQU07SUFDUixJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsK0JBQStCO0lBQzdDLHVFQUF1RTtJQUN2RSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxRQUFRO01BQ1IsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEU7QUFDRiJ9
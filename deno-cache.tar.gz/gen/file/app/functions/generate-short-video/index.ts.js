import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
  try {
    const authHeader = req.headers.get("Authorization");
    let userId = null;
    let isInternalCall = false;
    // Check if this is an internal call (from suno-callback) with service key
    if (authHeader === `Bearer ${supabaseServiceKey}`) {
      isInternalCall = true;
      console.log("Internal service call detected");
    } else if (authHeader?.startsWith("Bearer ")) {
      // User JWT - validate and get user
      const userClient = createClient(supabaseUrl, supabaseAnonKey, {
        global: {
          headers: {
            Authorization: authHeader
          }
        }
      });
      const token = authHeader.replace("Bearer ", "");
      const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
      if (claimsError || !claimsData?.claims) {
        return new Response(JSON.stringify({
          error: "Unauthorized"
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      userId = claimsData.claims.sub;
      console.log(`User call from: ${userId}`);
    } else {
      return new Response(JSON.stringify({
        error: "Unauthorized - missing auth"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const body = await req.json();
    const { track_id, suno_task_id, suno_audio_id, author } = body;
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    if (!SUNO_API_KEY) {
      throw new Error("SUNO_API_KEY is not configured");
    }
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    console.log(`Generating music video for track: ${track_id}, suno_task_id: ${suno_task_id}, suno_audio_id: ${suno_audio_id}`);
    // Get track info to verify ownership and get suno_audio_id if not provided
    const { data: track, error: trackError } = await supabase.from("tracks").select("id, user_id, suno_audio_id, title, description").eq("id", track_id).single();
    if (trackError || !track) {
      throw new Error("Track not found");
    }
    // If user call, verify ownership
    if (!isInternalCall && track.user_id !== userId) {
      return new Response(JSON.stringify({
        error: "Access denied - not your track"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Use provided suno_audio_id or get from track
    const audioId = suno_audio_id || track.suno_audio_id;
    // Extract task_id from track description (format: [task_id: xxx])
    let taskId = suno_task_id;
    if (!taskId && track.description) {
      const taskIdMatch = track.description.match(/\[task_id:\s*([^\]]+)\]/);
      if (taskIdMatch) {
        taskId = taskIdMatch[1].trim();
        console.log(`Extracted task_id from description: ${taskId}`);
      }
    }
    // Validate we have required parameters - Suno API requires taskId
    if (!taskId) {
      throw new Error("Track has no Suno task ID for video generation");
    }
    // Get addon service price
    const { data: addonService } = await supabase.from("addon_services").select("id, price_rub").eq("name", "short_video").single();
    if (!addonService) {
      throw new Error("Video addon service not found");
    }
    const price = addonService.price_rub;
    // If user call (not internal from addon processing), check balance and deduct
    if (!isInternalCall && userId) {
      // Check user balance
      const { data: profile, error: profileError } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
      if (profileError || !profile) {
        throw new Error("User profile not found");
      }
      if ((profile.balance || 0) < price) {
        return new Response(JSON.stringify({
          error: "Insufficient balance",
          required: price,
          current: profile.balance
        }), {
          status: 402,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Deduct balance
      const newBalance = (profile.balance || 0) - price;
      const { error: deductError } = await supabase.from("profiles").update({
        balance: newBalance
      }).eq("user_id", userId);
      if (deductError) {
        throw new Error("Failed to deduct balance");
      }
      // Log transaction
      await supabase.from("balance_transactions").insert({
        user_id: userId,
        amount: -price,
        balance_after: newBalance,
        type: "video",
        description: "Промо-видео",
        reference_id: track_id,
        reference_type: "track"
      });
      // Create track_addon record
      await supabase.from("track_addons").insert({
        track_id: track_id,
        addon_service_id: addonService.id,
        status: "processing",
        result_url: JSON.stringify({
          status: "starting"
        })
      });
    }
    // Build callback URL for Suno
    const callbackUrl = `${supabaseUrl}/functions/v1/suno-video-callback`;
    // Request music video generation from Suno API
    // According to Suno docs, both taskId and audioId can be provided
    // taskId is required, audioId is optional but more specific
    const requestBody = {
      callBackUrl: callbackUrl,
      taskId: taskId
    };
    // Add audioId if available (more specific)
    if (audioId) {
      requestBody.audioId = audioId;
    }
    if (author) {
      requestBody.author = author;
    }
    console.log("Requesting Suno music video:", JSON.stringify(requestBody));
    const response = await fetch("https://api.sunoapi.org/api/v1/mp4/generate", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${SUNO_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(requestBody)
    });
    const responseText = await response.text();
    console.log("Suno video response:", response.status, responseText);
    let data;
    try {
      data = JSON.parse(responseText);
    } catch  {
      throw new Error(`Invalid JSON response from Suno: ${responseText}`);
    }
    // Handle "Mp4 record already exists" - means video is already generated
    // Try to fetch the existing video URL
    if (data.code !== 200 && data.msg?.includes("Mp4 record already exists")) {
      console.log("Video already exists, fetching status...");
      // Try to get existing video via status API
      const statusResponse = await fetch(`https://api.sunoapi.org/api/v1/mp4/query?taskId=${taskId}`, {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${SUNO_API_KEY}`,
          "Content-Type": "application/json"
        }
      });
      const statusText = await statusResponse.text();
      console.log("Suno video status response:", statusResponse.status, statusText);
      let statusData;
      try {
        statusData = JSON.parse(statusText);
      } catch  {
        // If status API fails, refund and error
        if (!isInternalCall && userId) {
          const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
          await supabase.from("profiles").update({
            balance: (currentProfile?.balance || 0) + price
          }).eq("user_id", userId);
        }
        throw new Error("Video already exists but failed to fetch URL");
      }
      if (statusData.code === 200 && statusData.data) {
        // Video exists - extract URL
        const videoUrl = statusData.data.video_url || statusData.data.mp4_url || statusData.data.url;
        if (videoUrl) {
          console.log(`Found existing video: ${videoUrl}`);
          // Refund user since video already exists
          if (!isInternalCall && userId) {
            const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
            await supabase.from("profiles").update({
              balance: (currentProfile?.balance || 0) + price
            }).eq("user_id", userId);
          }
          // Update addon to completed with existing URL
          await supabase.from("track_addons").update({
            status: "completed",
            result_url: videoUrl,
            updated_at: new Date().toISOString()
          }).eq("track_id", track_id).eq("addon_service_id", addonService.id);
          return new Response(JSON.stringify({
            success: true,
            video_url: videoUrl,
            message: "Video already exists",
            already_exists: true
          }), {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json"
            }
          });
        }
      }
      // Refund and error if we couldn't get video URL
      if (!isInternalCall && userId) {
        const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
        await supabase.from("profiles").update({
          balance: (currentProfile?.balance || 0) + price
        }).eq("user_id", userId);
      }
      throw new Error("Video exists but could not retrieve URL");
    }
    if (!response.ok) {
      // Refund if user call
      if (!isInternalCall && userId) {
        const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
        await supabase.from("profiles").update({
          balance: (currentProfile?.balance || 0) + price
        }).eq("user_id", userId);
        await supabase.from("track_addons").update({
          status: "failed",
          result_url: JSON.stringify({
            error: "Suno API error"
          })
        }).eq("track_id", track_id).eq("addon_service_id", addonService.id);
      }
      throw new Error(`Suno API error: ${response.status} - ${responseText}`);
    }
    if (data.code !== 200) {
      // Refund if user call
      if (!isInternalCall && userId) {
        const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", userId).single();
        await supabase.from("profiles").update({
          balance: (currentProfile?.balance || 0) + price
        }).eq("user_id", userId);
        await supabase.from("track_addons").update({
          status: "failed",
          result_url: JSON.stringify({
            error: data.msg
          })
        }).eq("track_id", track_id).eq("addon_service_id", addonService.id);
      }
      throw new Error(`Suno API error: ${data.msg || "Unknown error"}`);
    }
    const videoTaskId = data.data?.taskId;
    if (!videoTaskId) {
      throw new Error("No video taskId received from Suno");
    }
    console.log(`Video generation started, Suno video task ID: ${videoTaskId}`);
    // Update the track_addons table with processing status and video task ID
    const { error: updateError } = await supabase.from("track_addons").update({
      status: "processing",
      result_url: JSON.stringify({
        video_task_id: videoTaskId,
        track_id: track_id,
        suno_audio_id: audioId || null,
        status: "processing"
      }),
      updated_at: new Date().toISOString()
    }).eq("track_id", track_id).eq("addon_service_id", addonService.id);
    if (updateError) {
      console.error("Update addon error:", updateError);
    }
    return new Response(JSON.stringify({
      success: true,
      video_task_id: videoTaskId,
      message: "Music video generation started"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("generate-short-video error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9nZW5lcmF0ZS1zaG9ydC12aWRlby9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgY29uc3Qgc3VwYWJhc2VBbm9uS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikhO1xuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgbGV0IHVzZXJJZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gICAgbGV0IGlzSW50ZXJuYWxDYWxsID0gZmFsc2U7XG5cbiAgICAvLyBDaGVjayBpZiB0aGlzIGlzIGFuIGludGVybmFsIGNhbGwgKGZyb20gc3Vuby1jYWxsYmFjaykgd2l0aCBzZXJ2aWNlIGtleVxuICAgIGlmIChhdXRoSGVhZGVyID09PSBgQmVhcmVyICR7c3VwYWJhc2VTZXJ2aWNlS2V5fWApIHtcbiAgICAgIGlzSW50ZXJuYWxDYWxsID0gdHJ1ZTtcbiAgICAgIGNvbnNvbGUubG9nKFwiSW50ZXJuYWwgc2VydmljZSBjYWxsIGRldGVjdGVkXCIpO1xuICAgIH0gZWxzZSBpZiAoYXV0aEhlYWRlcj8uc3RhcnRzV2l0aChcIkJlYXJlciBcIikpIHtcbiAgICAgIC8vIFVzZXIgSldUIC0gdmFsaWRhdGUgYW5kIGdldCB1c2VyXG4gICAgICBjb25zdCB1c2VyQ2xpZW50ID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZUFub25LZXksIHtcbiAgICAgICAgZ2xvYmFsOiB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYXV0aEhlYWRlciB9IH1cbiAgICAgIH0pO1xuICAgICAgXG4gICAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgICBjb25zdCB7IGRhdGE6IGNsYWltc0RhdGEsIGVycm9yOiBjbGFpbXNFcnJvciB9ID0gYXdhaXQgdXNlckNsaWVudC5hdXRoLmdldENsYWltcyh0b2tlbik7XG4gICAgICBcbiAgICAgIGlmIChjbGFpbXNFcnJvciB8fCAhY2xhaW1zRGF0YT8uY2xhaW1zKSB7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgdXNlcklkID0gY2xhaW1zRGF0YS5jbGFpbXMuc3ViIGFzIHN0cmluZztcbiAgICAgIGNvbnNvbGUubG9nKGBVc2VyIGNhbGwgZnJvbTogJHt1c2VySWR9YCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkIC0gbWlzc2luZyBhdXRoXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zdCB7IHRyYWNrX2lkLCBzdW5vX3Rhc2tfaWQsIHN1bm9fYXVkaW9faWQsIGF1dGhvciB9ID0gYm9keTtcbiAgICBcbiAgICBjb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG4gICAgaWYgKCFTVU5PX0FQSV9LRVkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlNVTk9fQVBJX0tFWSBpcyBub3QgY29uZmlndXJlZFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIGNvbnNvbGUubG9nKGBHZW5lcmF0aW5nIG11c2ljIHZpZGVvIGZvciB0cmFjazogJHt0cmFja19pZH0sIHN1bm9fdGFza19pZDogJHtzdW5vX3Rhc2tfaWR9LCBzdW5vX2F1ZGlvX2lkOiAke3N1bm9fYXVkaW9faWR9YCk7XG5cbiAgICAvLyBHZXQgdHJhY2sgaW5mbyB0byB2ZXJpZnkgb3duZXJzaGlwIGFuZCBnZXQgc3Vub19hdWRpb19pZCBpZiBub3QgcHJvdmlkZWRcbiAgICBjb25zdCB7IGRhdGE6IHRyYWNrLCBlcnJvcjogdHJhY2tFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAuc2VsZWN0KFwiaWQsIHVzZXJfaWQsIHN1bm9fYXVkaW9faWQsIHRpdGxlLCBkZXNjcmlwdGlvblwiKVxuICAgICAgLmVxKFwiaWRcIiwgdHJhY2tfaWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAodHJhY2tFcnJvciB8fCAhdHJhY2spIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRyYWNrIG5vdCBmb3VuZFwiKTtcbiAgICB9XG5cbiAgICAvLyBJZiB1c2VyIGNhbGwsIHZlcmlmeSBvd25lcnNoaXBcbiAgICBpZiAoIWlzSW50ZXJuYWxDYWxsICYmIHRyYWNrLnVzZXJfaWQgIT09IHVzZXJJZCkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJBY2Nlc3MgZGVuaWVkIC0gbm90IHlvdXIgdHJhY2tcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMywgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIFVzZSBwcm92aWRlZCBzdW5vX2F1ZGlvX2lkIG9yIGdldCBmcm9tIHRyYWNrXG4gICAgY29uc3QgYXVkaW9JZCA9IHN1bm9fYXVkaW9faWQgfHwgdHJhY2suc3Vub19hdWRpb19pZDtcbiAgICBcbiAgICAvLyBFeHRyYWN0IHRhc2tfaWQgZnJvbSB0cmFjayBkZXNjcmlwdGlvbiAoZm9ybWF0OiBbdGFza19pZDogeHh4XSlcbiAgICBsZXQgdGFza0lkID0gc3Vub190YXNrX2lkO1xuICAgIGlmICghdGFza0lkICYmIHRyYWNrLmRlc2NyaXB0aW9uKSB7XG4gICAgICBjb25zdCB0YXNrSWRNYXRjaCA9IHRyYWNrLmRlc2NyaXB0aW9uLm1hdGNoKC9cXFt0YXNrX2lkOlxccyooW15cXF1dKylcXF0vKTtcbiAgICAgIGlmICh0YXNrSWRNYXRjaCkge1xuICAgICAgICB0YXNrSWQgPSB0YXNrSWRNYXRjaFsxXS50cmltKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBFeHRyYWN0ZWQgdGFza19pZCBmcm9tIGRlc2NyaXB0aW9uOiAke3Rhc2tJZH1gKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSB3ZSBoYXZlIHJlcXVpcmVkIHBhcmFtZXRlcnMgLSBTdW5vIEFQSSByZXF1aXJlcyB0YXNrSWRcbiAgICBpZiAoIXRhc2tJZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVHJhY2sgaGFzIG5vIFN1bm8gdGFzayBJRCBmb3IgdmlkZW8gZ2VuZXJhdGlvblwiKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgYWRkb24gc2VydmljZSBwcmljZVxuICAgIGNvbnN0IHsgZGF0YTogYWRkb25TZXJ2aWNlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJhZGRvbl9zZXJ2aWNlc1wiKVxuICAgICAgLnNlbGVjdChcImlkLCBwcmljZV9ydWJcIilcbiAgICAgIC5lcShcIm5hbWVcIiwgXCJzaG9ydF92aWRlb1wiKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKCFhZGRvblNlcnZpY2UpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlZpZGVvIGFkZG9uIHNlcnZpY2Ugbm90IGZvdW5kXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHByaWNlID0gYWRkb25TZXJ2aWNlLnByaWNlX3J1YjtcblxuICAgIC8vIElmIHVzZXIgY2FsbCAobm90IGludGVybmFsIGZyb20gYWRkb24gcHJvY2Vzc2luZyksIGNoZWNrIGJhbGFuY2UgYW5kIGRlZHVjdFxuICAgIGlmICghaXNJbnRlcm5hbENhbGwgJiYgdXNlcklkKSB7XG4gICAgICAvLyBDaGVjayB1c2VyIGJhbGFuY2VcbiAgICAgIGNvbnN0IHsgZGF0YTogcHJvZmlsZSwgZXJyb3I6IHByb2ZpbGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAuc2VsZWN0KFwiYmFsYW5jZVwiKVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZClcbiAgICAgICAgLnNpbmdsZSgpO1xuXG4gICAgICBpZiAocHJvZmlsZUVycm9yIHx8ICFwcm9maWxlKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIlVzZXIgcHJvZmlsZSBub3QgZm91bmRcIik7XG4gICAgICB9XG5cbiAgICAgIGlmICgocHJvZmlsZS5iYWxhbmNlIHx8IDApIDwgcHJpY2UpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkluc3VmZmljaWVudCBiYWxhbmNlXCIsIHJlcXVpcmVkOiBwcmljZSwgY3VycmVudDogcHJvZmlsZS5iYWxhbmNlIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA0MDIsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICAvLyBEZWR1Y3QgYmFsYW5jZVxuICAgICAgY29uc3QgbmV3QmFsYW5jZSA9IChwcm9maWxlLmJhbGFuY2UgfHwgMCkgLSBwcmljZTtcbiAgICAgIGNvbnN0IHsgZXJyb3I6IGRlZHVjdEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBuZXdCYWxhbmNlIH0pXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKTtcblxuICAgICAgaWYgKGRlZHVjdEVycm9yKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBkZWR1Y3QgYmFsYW5jZVwiKTtcbiAgICAgIH1cblxuICAgICAgLy8gTG9nIHRyYW5zYWN0aW9uXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwiYmFsYW5jZV90cmFuc2FjdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogdXNlcklkLFxuICAgICAgICBhbW91bnQ6IC1wcmljZSxcbiAgICAgICAgYmFsYW5jZV9hZnRlcjogbmV3QmFsYW5jZSxcbiAgICAgICAgdHlwZTogXCJ2aWRlb1wiLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCLQn9GA0L7QvNC+LdCy0LjQtNC10L5cIixcbiAgICAgICAgcmVmZXJlbmNlX2lkOiB0cmFja19pZCxcbiAgICAgICAgcmVmZXJlbmNlX3R5cGU6IFwidHJhY2tcIixcbiAgICAgIH0pO1xuXG4gICAgICAvLyBDcmVhdGUgdHJhY2tfYWRkb24gcmVjb3JkXG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgICAuaW5zZXJ0KHtcbiAgICAgICAgICB0cmFja19pZDogdHJhY2tfaWQsXG4gICAgICAgICAgYWRkb25fc2VydmljZV9pZDogYWRkb25TZXJ2aWNlLmlkLFxuICAgICAgICAgIHN0YXR1czogXCJwcm9jZXNzaW5nXCIsXG4gICAgICAgICAgcmVzdWx0X3VybDogSlNPTi5zdHJpbmdpZnkoeyBzdGF0dXM6IFwic3RhcnRpbmdcIiB9KSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gQnVpbGQgY2FsbGJhY2sgVVJMIGZvciBTdW5vXG4gICAgY29uc3QgY2FsbGJhY2tVcmwgPSBgJHtzdXBhYmFzZVVybH0vZnVuY3Rpb25zL3YxL3N1bm8tdmlkZW8tY2FsbGJhY2tgO1xuXG4gICAgLy8gUmVxdWVzdCBtdXNpYyB2aWRlbyBnZW5lcmF0aW9uIGZyb20gU3VubyBBUElcbiAgICAvLyBBY2NvcmRpbmcgdG8gU3VubyBkb2NzLCBib3RoIHRhc2tJZCBhbmQgYXVkaW9JZCBjYW4gYmUgcHJvdmlkZWRcbiAgICAvLyB0YXNrSWQgaXMgcmVxdWlyZWQsIGF1ZGlvSWQgaXMgb3B0aW9uYWwgYnV0IG1vcmUgc3BlY2lmaWNcbiAgICBjb25zdCByZXF1ZXN0Qm9keTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICBjYWxsQmFja1VybDogY2FsbGJhY2tVcmwsXG4gICAgICB0YXNrSWQ6IHRhc2tJZCwgLy8gUmVxdWlyZWRcbiAgICB9O1xuXG4gICAgLy8gQWRkIGF1ZGlvSWQgaWYgYXZhaWxhYmxlIChtb3JlIHNwZWNpZmljKVxuICAgIGlmIChhdWRpb0lkKSB7XG4gICAgICByZXF1ZXN0Qm9keS5hdWRpb0lkID0gYXVkaW9JZDtcbiAgICB9XG4gICAgXG4gICAgaWYgKGF1dGhvcikge1xuICAgICAgcmVxdWVzdEJvZHkuYXV0aG9yID0gYXV0aG9yO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKFwiUmVxdWVzdGluZyBTdW5vIG11c2ljIHZpZGVvOlwiLCBKU09OLnN0cmluZ2lmeShyZXF1ZXN0Qm9keSkpO1xuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcImh0dHBzOi8vYXBpLnN1bm9hcGkub3JnL2FwaS92MS9tcDQvZ2VuZXJhdGVcIiwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocmVxdWVzdEJvZHkpLFxuICAgIH0pO1xuXG4gICAgY29uc3QgcmVzcG9uc2VUZXh0ID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICAgIGNvbnNvbGUubG9nKFwiU3VubyB2aWRlbyByZXNwb25zZTpcIiwgcmVzcG9uc2Uuc3RhdHVzLCByZXNwb25zZVRleHQpO1xuXG4gICAgbGV0IGRhdGE7XG4gICAgdHJ5IHtcbiAgICAgIGRhdGEgPSBKU09OLnBhcnNlKHJlc3BvbnNlVGV4dCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEludmFsaWQgSlNPTiByZXNwb25zZSBmcm9tIFN1bm86ICR7cmVzcG9uc2VUZXh0fWApO1xuICAgIH1cblxuICAgIC8vIEhhbmRsZSBcIk1wNCByZWNvcmQgYWxyZWFkeSBleGlzdHNcIiAtIG1lYW5zIHZpZGVvIGlzIGFscmVhZHkgZ2VuZXJhdGVkXG4gICAgLy8gVHJ5IHRvIGZldGNoIHRoZSBleGlzdGluZyB2aWRlbyBVUkxcbiAgICBpZiAoZGF0YS5jb2RlICE9PSAyMDAgJiYgZGF0YS5tc2c/LmluY2x1ZGVzKFwiTXA0IHJlY29yZCBhbHJlYWR5IGV4aXN0c1wiKSkge1xuICAgICAgY29uc29sZS5sb2coXCJWaWRlbyBhbHJlYWR5IGV4aXN0cywgZmV0Y2hpbmcgc3RhdHVzLi4uXCIpO1xuICAgICAgXG4gICAgICAvLyBUcnkgdG8gZ2V0IGV4aXN0aW5nIHZpZGVvIHZpYSBzdGF0dXMgQVBJXG4gICAgICBjb25zdCBzdGF0dXNSZXNwb25zZSA9IGF3YWl0IGZldGNoKGBodHRwczovL2FwaS5zdW5vYXBpLm9yZy9hcGkvdjEvbXA0L3F1ZXJ5P3Rhc2tJZD0ke3Rhc2tJZH1gLCB7XG4gICAgICAgIG1ldGhvZDogXCJHRVRcIixcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICAgIFxuICAgICAgY29uc3Qgc3RhdHVzVGV4dCA9IGF3YWl0IHN0YXR1c1Jlc3BvbnNlLnRleHQoKTtcbiAgICAgIGNvbnNvbGUubG9nKFwiU3VubyB2aWRlbyBzdGF0dXMgcmVzcG9uc2U6XCIsIHN0YXR1c1Jlc3BvbnNlLnN0YXR1cywgc3RhdHVzVGV4dCk7XG4gICAgICBcbiAgICAgIGxldCBzdGF0dXNEYXRhO1xuICAgICAgdHJ5IHtcbiAgICAgICAgc3RhdHVzRGF0YSA9IEpTT04ucGFyc2Uoc3RhdHVzVGV4dCk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gSWYgc3RhdHVzIEFQSSBmYWlscywgcmVmdW5kIGFuZCBlcnJvclxuICAgICAgICBpZiAoIWlzSW50ZXJuYWxDYWxsICYmIHVzZXJJZCkge1xuICAgICAgICAgIGNvbnN0IHsgZGF0YTogY3VycmVudFByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgICAuc2VsZWN0KFwiYmFsYW5jZVwiKVxuICAgICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpXG4gICAgICAgICAgICAuc2luZ2xlKCk7XG4gICAgICAgICAgXG4gICAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiAoY3VycmVudFByb2ZpbGU/LmJhbGFuY2UgfHwgMCkgKyBwcmljZSB9KVxuICAgICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuICAgICAgICB9XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIlZpZGVvIGFscmVhZHkgZXhpc3RzIGJ1dCBmYWlsZWQgdG8gZmV0Y2ggVVJMXCIpO1xuICAgICAgfVxuICAgICAgXG4gICAgICBpZiAoc3RhdHVzRGF0YS5jb2RlID09PSAyMDAgJiYgc3RhdHVzRGF0YS5kYXRhKSB7XG4gICAgICAgIC8vIFZpZGVvIGV4aXN0cyAtIGV4dHJhY3QgVVJMXG4gICAgICAgIGNvbnN0IHZpZGVvVXJsID0gc3RhdHVzRGF0YS5kYXRhLnZpZGVvX3VybCB8fCBzdGF0dXNEYXRhLmRhdGEubXA0X3VybCB8fCBzdGF0dXNEYXRhLmRhdGEudXJsO1xuICAgICAgICBcbiAgICAgICAgaWYgKHZpZGVvVXJsKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coYEZvdW5kIGV4aXN0aW5nIHZpZGVvOiAke3ZpZGVvVXJsfWApO1xuICAgICAgICAgIFxuICAgICAgICAgIC8vIFJlZnVuZCB1c2VyIHNpbmNlIHZpZGVvIGFscmVhZHkgZXhpc3RzXG4gICAgICAgICAgaWYgKCFpc0ludGVybmFsQ2FsbCAmJiB1c2VySWQpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgZGF0YTogY3VycmVudFByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAgICAgLnNlbGVjdChcImJhbGFuY2VcIilcbiAgICAgICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpXG4gICAgICAgICAgICAgIC5zaW5nbGUoKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogKGN1cnJlbnRQcm9maWxlPy5iYWxhbmNlIHx8IDApICsgcHJpY2UgfSlcbiAgICAgICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBcbiAgICAgICAgICAvLyBVcGRhdGUgYWRkb24gdG8gY29tcGxldGVkIHdpdGggZXhpc3RpbmcgVVJMXG4gICAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgICAgICAudXBkYXRlKHsgXG4gICAgICAgICAgICAgIHN0YXR1czogXCJjb21wbGV0ZWRcIiwgXG4gICAgICAgICAgICAgIHJlc3VsdF91cmw6IHZpZGVvVXJsLFxuICAgICAgICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuZXEoXCJ0cmFja19pZFwiLCB0cmFja19pZClcbiAgICAgICAgICAgIC5lcShcImFkZG9uX3NlcnZpY2VfaWRcIiwgYWRkb25TZXJ2aWNlLmlkKTtcbiAgICAgICAgICBcbiAgICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgICB2aWRlb191cmw6IHZpZGVvVXJsLFxuICAgICAgICAgICAgICBtZXNzYWdlOiBcIlZpZGVvIGFscmVhZHkgZXhpc3RzXCIsXG4gICAgICAgICAgICAgIGFscmVhZHlfZXhpc3RzOiB0cnVlLFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgXG4gICAgICAvLyBSZWZ1bmQgYW5kIGVycm9yIGlmIHdlIGNvdWxkbid0IGdldCB2aWRlbyBVUkxcbiAgICAgIGlmICghaXNJbnRlcm5hbENhbGwgJiYgdXNlcklkKSB7XG4gICAgICAgIGNvbnN0IHsgZGF0YTogY3VycmVudFByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpXG4gICAgICAgICAgLnNpbmdsZSgpO1xuICAgICAgICBcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IChjdXJyZW50UHJvZmlsZT8uYmFsYW5jZSB8fCAwKSArIHByaWNlIH0pXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVmlkZW8gZXhpc3RzIGJ1dCBjb3VsZCBub3QgcmV0cmlldmUgVVJMXCIpO1xuICAgIH1cblxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIC8vIFJlZnVuZCBpZiB1c2VyIGNhbGxcbiAgICAgIGlmICghaXNJbnRlcm5hbENhbGwgJiYgdXNlcklkKSB7XG4gICAgICAgIGNvbnN0IHsgZGF0YTogY3VycmVudFByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpXG4gICAgICAgICAgLnNpbmdsZSgpO1xuXG4gICAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiAoY3VycmVudFByb2ZpbGU/LmJhbGFuY2UgfHwgMCkgKyBwcmljZSB9KVxuICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKTtcbiAgICAgICAgXG4gICAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJ0cmFja19hZGRvbnNcIilcbiAgICAgICAgICAudXBkYXRlKHsgc3RhdHVzOiBcImZhaWxlZFwiLCByZXN1bHRfdXJsOiBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlN1bm8gQVBJIGVycm9yXCIgfSkgfSlcbiAgICAgICAgICAuZXEoXCJ0cmFja19pZFwiLCB0cmFja19pZClcbiAgICAgICAgICAuZXEoXCJhZGRvbl9zZXJ2aWNlX2lkXCIsIGFkZG9uU2VydmljZS5pZCk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFN1bm8gQVBJIGVycm9yOiAke3Jlc3BvbnNlLnN0YXR1c30gLSAke3Jlc3BvbnNlVGV4dH1gKTtcbiAgICB9XG5cbiAgICBpZiAoZGF0YS5jb2RlICE9PSAyMDApIHtcbiAgICAgIC8vIFJlZnVuZCBpZiB1c2VyIGNhbGxcbiAgICAgIGlmICghaXNJbnRlcm5hbENhbGwgJiYgdXNlcklkKSB7XG4gICAgICAgIGNvbnN0IHsgZGF0YTogY3VycmVudFByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpXG4gICAgICAgICAgLnNpbmdsZSgpO1xuICAgICAgICBcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IChjdXJyZW50UHJvZmlsZT8uYmFsYW5jZSB8fCAwKSArIHByaWNlIH0pXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuICAgICAgICBcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwiZmFpbGVkXCIsIHJlc3VsdF91cmw6IEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGRhdGEubXNnIH0pIH0pXG4gICAgICAgICAgLmVxKFwidHJhY2tfaWRcIiwgdHJhY2tfaWQpXG4gICAgICAgICAgLmVxKFwiYWRkb25fc2VydmljZV9pZFwiLCBhZGRvblNlcnZpY2UuaWQpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IEVycm9yKGBTdW5vIEFQSSBlcnJvcjogJHtkYXRhLm1zZyB8fCBcIlVua25vd24gZXJyb3JcIn1gKTtcbiAgICB9XG5cbiAgICBjb25zdCB2aWRlb1Rhc2tJZCA9IGRhdGEuZGF0YT8udGFza0lkO1xuICAgIGlmICghdmlkZW9UYXNrSWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vIHZpZGVvIHRhc2tJZCByZWNlaXZlZCBmcm9tIFN1bm9cIik7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFZpZGVvIGdlbmVyYXRpb24gc3RhcnRlZCwgU3VubyB2aWRlbyB0YXNrIElEOiAke3ZpZGVvVGFza0lkfWApO1xuXG4gICAgLy8gVXBkYXRlIHRoZSB0cmFja19hZGRvbnMgdGFibGUgd2l0aCBwcm9jZXNzaW5nIHN0YXR1cyBhbmQgdmlkZW8gdGFzayBJRFxuICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJ0cmFja19hZGRvbnNcIilcbiAgICAgIC51cGRhdGUoe1xuICAgICAgICBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiLFxuICAgICAgICByZXN1bHRfdXJsOiBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHZpZGVvX3Rhc2tfaWQ6IHZpZGVvVGFza0lkLFxuICAgICAgICAgIHRyYWNrX2lkOiB0cmFja19pZCxcbiAgICAgICAgICBzdW5vX2F1ZGlvX2lkOiBhdWRpb0lkIHx8IG51bGwsXG4gICAgICAgICAgc3RhdHVzOiBcInByb2Nlc3NpbmdcIlxuICAgICAgICB9KSxcbiAgICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfSlcbiAgICAgIC5lcShcInRyYWNrX2lkXCIsIHRyYWNrX2lkKVxuICAgICAgLmVxKFwiYWRkb25fc2VydmljZV9pZFwiLCBhZGRvblNlcnZpY2UuaWQpO1xuXG4gICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiVXBkYXRlIGFkZG9uIGVycm9yOlwiLCB1cGRhdGVFcnJvcik7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgdmlkZW9fdGFza19pZDogdmlkZW9UYXNrSWQsXG4gICAgICAgIG1lc3NhZ2U6IFwiTXVzaWMgdmlkZW8gZ2VuZXJhdGlvbiBzdGFydGVkXCIsXG4gICAgICB9KSxcbiAgICAgIHtcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgIH1cbiAgICApO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJnZW5lcmF0ZS1zaG9ydC12aWRlbyBlcnJvcjpcIiwgZXJyb3IpO1xuICAgIFxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICBlcnJvcjogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIixcbiAgICAgIH0pLFxuICAgICAge1xuICAgICAgICBzdGF0dXM6IDUwMCxcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgIH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0VBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUN4QyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFFckMsSUFBSTtJQUNGLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxTQUF3QjtJQUM1QixJQUFJLGlCQUFpQjtJQUVyQiwwRUFBMEU7SUFDMUUsSUFBSSxlQUFlLENBQUMsT0FBTyxFQUFFLG1CQUFtQixDQUFDLEVBQUU7TUFDakQsaUJBQWlCO01BQ2pCLFFBQVEsR0FBRyxDQUFDO0lBQ2QsT0FBTyxJQUFJLFlBQVksV0FBVyxZQUFZO01BQzVDLG1DQUFtQztNQUNuQyxNQUFNLGFBQWEsYUFBYSxhQUFhLGlCQUFpQjtRQUM1RCxRQUFRO1VBQUUsU0FBUztZQUFFLGVBQWU7VUFBVztRQUFFO01BQ25EO01BRUEsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7TUFDNUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxXQUFXLElBQUksQ0FBQyxTQUFTLENBQUM7TUFFakYsSUFBSSxlQUFlLENBQUMsWUFBWSxRQUFRO1FBQ3RDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUFlLElBQ3ZDO1VBQUUsUUFBUTtVQUFLLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUVuRjtNQUVBLFNBQVMsV0FBVyxNQUFNLENBQUMsR0FBRztNQUM5QixRQUFRLEdBQUcsQ0FBQyxDQUFDLGdCQUFnQixFQUFFLE9BQU8sQ0FBQztJQUN6QyxPQUFPO01BQ0wsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQThCLElBQ3REO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtJQUMzQixNQUFNLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsTUFBTSxFQUFFLEdBQUc7SUFFMUQsTUFBTSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNsQyxJQUFJLENBQUMsY0FBYztNQUNqQixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0MsUUFBUSxHQUFHLENBQUMsQ0FBQyxrQ0FBa0MsRUFBRSxTQUFTLGdCQUFnQixFQUFFLGFBQWEsaUJBQWlCLEVBQUUsY0FBYyxDQUFDO0lBRTNILDJFQUEyRTtJQUMzRSxNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxVQUFVLEVBQUUsR0FBRyxNQUFNLFNBQzlDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxrREFDUCxFQUFFLENBQUMsTUFBTSxVQUNULE1BQU07SUFFVCxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsaUNBQWlDO0lBQ2pDLElBQUksQ0FBQyxrQkFBa0IsTUFBTSxPQUFPLEtBQUssUUFBUTtNQUMvQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBaUMsSUFDekQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsK0NBQStDO0lBQy9DLE1BQU0sVUFBVSxpQkFBaUIsTUFBTSxhQUFhO0lBRXBELGtFQUFrRTtJQUNsRSxJQUFJLFNBQVM7SUFDYixJQUFJLENBQUMsVUFBVSxNQUFNLFdBQVcsRUFBRTtNQUNoQyxNQUFNLGNBQWMsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDO01BQzVDLElBQUksYUFBYTtRQUNmLFNBQVMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxJQUFJO1FBQzVCLFFBQVEsR0FBRyxDQUFDLENBQUMsb0NBQW9DLEVBQUUsT0FBTyxDQUFDO01BQzdEO0lBQ0Y7SUFFQSxrRUFBa0U7SUFDbEUsSUFBSSxDQUFDLFFBQVE7TUFDWCxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLDBCQUEwQjtJQUMxQixNQUFNLEVBQUUsTUFBTSxZQUFZLEVBQUUsR0FBRyxNQUFNLFNBQ2xDLElBQUksQ0FBQyxrQkFDTCxNQUFNLENBQUMsaUJBQ1AsRUFBRSxDQUFDLFFBQVEsZUFDWCxNQUFNO0lBRVQsSUFBSSxDQUFDLGNBQWM7TUFDakIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLFFBQVEsYUFBYSxTQUFTO0lBRXBDLDhFQUE4RTtJQUM5RSxJQUFJLENBQUMsa0JBQWtCLFFBQVE7TUFDN0IscUJBQXFCO01BQ3JCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbEQsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsUUFDZCxNQUFNO01BRVQsSUFBSSxnQkFBZ0IsQ0FBQyxTQUFTO1FBQzVCLE1BQU0sSUFBSSxNQUFNO01BQ2xCO01BRUEsSUFBSSxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSSxPQUFPO1FBQ2xDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztVQUF3QixVQUFVO1VBQU8sU0FBUyxRQUFRLE9BQU87UUFBQyxJQUMxRjtVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSxpQkFBaUI7TUFDakIsTUFBTSxhQUFhLENBQUMsUUFBUSxPQUFPLElBQUksQ0FBQyxJQUFJO01BQzVDLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1FBQUUsU0FBUztNQUFXLEdBQzdCLEVBQUUsQ0FBQyxXQUFXO01BRWpCLElBQUksYUFBYTtRQUNmLE1BQU0sSUFBSSxNQUFNO01BQ2xCO01BRUEsa0JBQWtCO01BQ2xCLE1BQU0sU0FBUyxJQUFJLENBQUMsd0JBQXdCLE1BQU0sQ0FBQztRQUNqRCxTQUFTO1FBQ1QsUUFBUSxDQUFDO1FBQ1QsZUFBZTtRQUNmLE1BQU07UUFDTixhQUFhO1FBQ2IsY0FBYztRQUNkLGdCQUFnQjtNQUNsQjtNQUVBLDRCQUE0QjtNQUM1QixNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztRQUNOLFVBQVU7UUFDVixrQkFBa0IsYUFBYSxFQUFFO1FBQ2pDLFFBQVE7UUFDUixZQUFZLEtBQUssU0FBUyxDQUFDO1VBQUUsUUFBUTtRQUFXO01BQ2xEO0lBQ0o7SUFFQSw4QkFBOEI7SUFDOUIsTUFBTSxjQUFjLENBQUMsRUFBRSxZQUFZLGlDQUFpQyxDQUFDO0lBRXJFLCtDQUErQztJQUMvQyxrRUFBa0U7SUFDbEUsNERBQTREO0lBQzVELE1BQU0sY0FBdUM7TUFDM0MsYUFBYTtNQUNiLFFBQVE7SUFDVjtJQUVBLDJDQUEyQztJQUMzQyxJQUFJLFNBQVM7TUFDWCxZQUFZLE9BQU8sR0FBRztJQUN4QjtJQUVBLElBQUksUUFBUTtNQUNWLFlBQVksTUFBTSxHQUFHO0lBQ3ZCO0lBRUEsUUFBUSxHQUFHLENBQUMsZ0NBQWdDLEtBQUssU0FBUyxDQUFDO0lBRTNELE1BQU0sV0FBVyxNQUFNLE1BQU0sK0NBQStDO01BQzFFLFFBQVE7TUFDUixTQUFTO1FBQ1AsaUJBQWlCLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQztRQUN6QyxnQkFBZ0I7TUFDbEI7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO0lBQ3ZCO0lBRUEsTUFBTSxlQUFlLE1BQU0sU0FBUyxJQUFJO0lBQ3hDLFFBQVEsR0FBRyxDQUFDLHdCQUF3QixTQUFTLE1BQU0sRUFBRTtJQUVyRCxJQUFJO0lBQ0osSUFBSTtNQUNGLE9BQU8sS0FBSyxLQUFLLENBQUM7SUFDcEIsRUFBRSxPQUFNO01BQ04sTUFBTSxJQUFJLE1BQU0sQ0FBQyxpQ0FBaUMsRUFBRSxhQUFhLENBQUM7SUFDcEU7SUFFQSx3RUFBd0U7SUFDeEUsc0NBQXNDO0lBQ3RDLElBQUksS0FBSyxJQUFJLEtBQUssT0FBTyxLQUFLLEdBQUcsRUFBRSxTQUFTLDhCQUE4QjtNQUN4RSxRQUFRLEdBQUcsQ0FBQztNQUVaLDJDQUEyQztNQUMzQyxNQUFNLGlCQUFpQixNQUFNLE1BQU0sQ0FBQyxnREFBZ0QsRUFBRSxPQUFPLENBQUMsRUFBRTtRQUM5RixRQUFRO1FBQ1IsU0FBUztVQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7VUFDekMsZ0JBQWdCO1FBQ2xCO01BQ0Y7TUFFQSxNQUFNLGFBQWEsTUFBTSxlQUFlLElBQUk7TUFDNUMsUUFBUSxHQUFHLENBQUMsK0JBQStCLGVBQWUsTUFBTSxFQUFFO01BRWxFLElBQUk7TUFDSixJQUFJO1FBQ0YsYUFBYSxLQUFLLEtBQUssQ0FBQztNQUMxQixFQUFFLE9BQU07UUFDTix3Q0FBd0M7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixRQUFRO1VBQzdCLE1BQU0sRUFBRSxNQUFNLGNBQWMsRUFBRSxHQUFHLE1BQU0sU0FDcEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsUUFDZCxNQUFNO1VBRVQsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztZQUFFLFNBQVMsQ0FBQyxnQkFBZ0IsV0FBVyxDQUFDLElBQUk7VUFBTSxHQUN6RCxFQUFFLENBQUMsV0FBVztRQUNuQjtRQUNBLE1BQU0sSUFBSSxNQUFNO01BQ2xCO01BRUEsSUFBSSxXQUFXLElBQUksS0FBSyxPQUFPLFdBQVcsSUFBSSxFQUFFO1FBQzlDLDZCQUE2QjtRQUM3QixNQUFNLFdBQVcsV0FBVyxJQUFJLENBQUMsU0FBUyxJQUFJLFdBQVcsSUFBSSxDQUFDLE9BQU8sSUFBSSxXQUFXLElBQUksQ0FBQyxHQUFHO1FBRTVGLElBQUksVUFBVTtVQUNaLFFBQVEsR0FBRyxDQUFDLENBQUMsc0JBQXNCLEVBQUUsU0FBUyxDQUFDO1VBRS9DLHlDQUF5QztVQUN6QyxJQUFJLENBQUMsa0JBQWtCLFFBQVE7WUFDN0IsTUFBTSxFQUFFLE1BQU0sY0FBYyxFQUFFLEdBQUcsTUFBTSxTQUNwQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxRQUNkLE1BQU07WUFFVCxNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO2NBQUUsU0FBUyxDQUFDLGdCQUFnQixXQUFXLENBQUMsSUFBSTtZQUFNLEdBQ3pELEVBQUUsQ0FBQyxXQUFXO1VBQ25CO1VBRUEsOENBQThDO1VBQzlDLE1BQU0sU0FDSCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO1lBQ04sUUFBUTtZQUNSLFlBQVk7WUFDWixZQUFZLElBQUksT0FBTyxXQUFXO1VBQ3BDLEdBQ0MsRUFBRSxDQUFDLFlBQVksVUFDZixFQUFFLENBQUMsb0JBQW9CLGFBQWEsRUFBRTtVQUV6QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztZQUNiLFNBQVM7WUFDVCxXQUFXO1lBQ1gsU0FBUztZQUNULGdCQUFnQjtVQUNsQixJQUNBO1lBQ0UsU0FBUztjQUFFLEdBQUcsV0FBVztjQUFFLGdCQUFnQjtZQUFtQjtVQUNoRTtRQUVKO01BQ0Y7TUFFQSxnREFBZ0Q7TUFDaEQsSUFBSSxDQUFDLGtCQUFrQixRQUFRO1FBQzdCLE1BQU0sRUFBRSxNQUFNLGNBQWMsRUFBRSxHQUFHLE1BQU0sU0FDcEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsUUFDZCxNQUFNO1FBRVQsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztVQUFFLFNBQVMsQ0FBQyxnQkFBZ0IsV0FBVyxDQUFDLElBQUk7UUFBTSxHQUN6RCxFQUFFLENBQUMsV0FBVztNQUNuQjtNQUNBLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLHNCQUFzQjtNQUN0QixJQUFJLENBQUMsa0JBQWtCLFFBQVE7UUFDN0IsTUFBTSxFQUFFLE1BQU0sY0FBYyxFQUFFLEdBQUcsTUFBTSxTQUNwQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxRQUNkLE1BQU07UUFFVCxNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1VBQUUsU0FBUyxDQUFDLGdCQUFnQixXQUFXLENBQUMsSUFBSTtRQUFNLEdBQ3pELEVBQUUsQ0FBQyxXQUFXO1FBRWpCLE1BQU0sU0FDSCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO1VBQUUsUUFBUTtVQUFVLFlBQVksS0FBSyxTQUFTLENBQUM7WUFBRSxPQUFPO1VBQWlCO1FBQUcsR0FDbkYsRUFBRSxDQUFDLFlBQVksVUFDZixFQUFFLENBQUMsb0JBQW9CLGFBQWEsRUFBRTtNQUMzQztNQUNBLE1BQU0sSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxNQUFNLENBQUMsR0FBRyxFQUFFLGFBQWEsQ0FBQztJQUN4RTtJQUVBLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSztNQUNyQixzQkFBc0I7TUFDdEIsSUFBSSxDQUFDLGtCQUFrQixRQUFRO1FBQzdCLE1BQU0sRUFBRSxNQUFNLGNBQWMsRUFBRSxHQUFHLE1BQU0sU0FDcEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsUUFDZCxNQUFNO1FBRVQsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztVQUFFLFNBQVMsQ0FBQyxnQkFBZ0IsV0FBVyxDQUFDLElBQUk7UUFBTSxHQUN6RCxFQUFFLENBQUMsV0FBVztRQUVqQixNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztVQUFFLFFBQVE7VUFBVSxZQUFZLEtBQUssU0FBUyxDQUFDO1lBQUUsT0FBTyxLQUFLLEdBQUc7VUFBQztRQUFHLEdBQzNFLEVBQUUsQ0FBQyxZQUFZLFVBQ2YsRUFBRSxDQUFDLG9CQUFvQixhQUFhLEVBQUU7TUFDM0M7TUFDQSxNQUFNLElBQUksTUFBTSxDQUFDLGdCQUFnQixFQUFFLEtBQUssR0FBRyxJQUFJLGdCQUFnQixDQUFDO0lBQ2xFO0lBRUEsTUFBTSxjQUFjLEtBQUssSUFBSSxFQUFFO0lBQy9CLElBQUksQ0FBQyxhQUFhO01BQ2hCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyw4Q0FBOEMsRUFBRSxZQUFZLENBQUM7SUFFMUUseUVBQXlFO0lBQ3pFLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztNQUNOLFFBQVE7TUFDUixZQUFZLEtBQUssU0FBUyxDQUFDO1FBQ3pCLGVBQWU7UUFDZixVQUFVO1FBQ1YsZUFBZSxXQUFXO1FBQzFCLFFBQVE7TUFDVjtNQUNBLFlBQVksSUFBSSxPQUFPLFdBQVc7SUFDcEMsR0FDQyxFQUFFLENBQUMsWUFBWSxVQUNmLEVBQUUsQ0FBQyxvQkFBb0IsYUFBYSxFQUFFO0lBRXpDLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLHVCQUF1QjtJQUN2QztJQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULGVBQWU7TUFDZixTQUFTO0lBQ1gsSUFDQTtNQUNFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFDaEU7RUFFSixFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLCtCQUErQjtJQUU3QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ2xELElBQ0E7TUFDRSxRQUFRO01BQ1IsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUNoRTtFQUVKO0FBQ0YifQ==
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
function toBool(value) {
  return (value ?? "").toLowerCase() === "true";
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const supabaseClient = createClient(supabaseUrl, serviceRoleKey || anonKey);
    // Read settings keys with retry for transient connection resets
    let data = null;
    let lastError = null;
    for(let attempt = 0; attempt < 3; attempt++){
      const res = await supabaseClient.from("settings").select("key,value,updated_at").in("key", [
        "maintenance_mode",
        "maintenance_eta",
        "maintenance_message"
      ]);
      if (!res.error) {
        data = res.data;
        lastError = null;
        break;
      }
      lastError = res.error;
      if (attempt < 2) await new Promise((r)=>setTimeout(r, 200 * (attempt + 1)));
    }
    if (lastError) throw lastError;
    const map = new Map();
    (data ?? []).forEach((row)=>map.set(row.key, {
        value: row.value,
        updated_at: row.updated_at
      }));
    const enabled = toBool(map.get("maintenance_mode")?.value);
    const eta = map.get("maintenance_eta")?.value ?? null;
    const message = map.get("maintenance_message")?.value ?? null;
    const updatedAt = map.get("maintenance_mode")?.updated_at ?? null;
    // Check if user is whitelisted (only if maintenance is enabled)
    let whitelisted = false;
    if (enabled) {
      const authHeader = req.headers.get("authorization");
      if (authHeader?.startsWith("Bearer ")) {
        const token = authHeader.slice(7);
        try {
          const { data: claims } = await supabaseClient.auth.getUser(token);
          if (claims?.user?.id) {
            const { data: whitelist } = await supabaseClient.from("maintenance_whitelist").select("id").eq("user_id", claims.user.id).maybeSingle();
            whitelisted = !!whitelist;
          }
        } catch  {
        // Ignore auth errors, just don't whitelist
        }
      }
    }
    const payload = {
      enabled,
      eta,
      message,
      updated_at: updatedAt,
      whitelisted
    };
    return new Response(JSON.stringify(payload), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
        // If enabled and ETA provided, clients can re-check later; fallback to 5 min.
        "Cache-Control": enabled ? "public, max-age=60" : "public, max-age=30"
      }
    });
  } catch (err) {
    console.error("maintenance-status error:", err);
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(JSON.stringify({
      enabled: false,
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9tYWludGVuYW5jZS1zdGF0dXMvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTY4LjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG50eXBlIE1haW50ZW5hbmNlU3RhdHVzID0ge1xuICBlbmFibGVkOiBib29sZWFuO1xuICBldGE6IHN0cmluZyB8IG51bGw7XG4gIG1lc3NhZ2U6IHN0cmluZyB8IG51bGw7XG4gIHVwZGF0ZWRfYXQ6IHN0cmluZyB8IG51bGw7XG4gIHdoaXRlbGlzdGVkPzogYm9vbGVhbjtcbn07XG5cbmZ1bmN0aW9uIHRvQm9vbCh2YWx1ZTogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZCk6IGJvb2xlYW4ge1xuICByZXR1cm4gKHZhbHVlID8/IFwiXCIpLnRvTG93ZXJDYXNlKCkgPT09IFwidHJ1ZVwiO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgPz8gXCJcIjtcbiAgICBjb25zdCBhbm9uS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikgPz8gXCJcIjtcbiAgICBjb25zdCBzZXJ2aWNlUm9sZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikgPz8gXCJcIjtcblxuICAgIGNvbnN0IHN1cGFiYXNlQ2xpZW50ID0gY3JlYXRlQ2xpZW50KFxuICAgICAgc3VwYWJhc2VVcmwsXG4gICAgICBzZXJ2aWNlUm9sZUtleSB8fCBhbm9uS2V5XG4gICAgKTtcblxuICAgIC8vIFJlYWQgc2V0dGluZ3Mga2V5cyB3aXRoIHJldHJ5IGZvciB0cmFuc2llbnQgY29ubmVjdGlvbiByZXNldHNcbiAgICBsZXQgZGF0YTogYW55ID0gbnVsbDtcbiAgICBsZXQgbGFzdEVycm9yOiBhbnkgPSBudWxsO1xuICAgIGZvciAobGV0IGF0dGVtcHQgPSAwOyBhdHRlbXB0IDwgMzsgYXR0ZW1wdCsrKSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAuZnJvbShcInNldHRpbmdzXCIpXG4gICAgICAgIC5zZWxlY3QoXCJrZXksdmFsdWUsdXBkYXRlZF9hdFwiKVxuICAgICAgICAuaW4oXCJrZXlcIiwgW1wibWFpbnRlbmFuY2VfbW9kZVwiLCBcIm1haW50ZW5hbmNlX2V0YVwiLCBcIm1haW50ZW5hbmNlX21lc3NhZ2VcIl0pO1xuICAgICAgaWYgKCFyZXMuZXJyb3IpIHsgZGF0YSA9IHJlcy5kYXRhOyBsYXN0RXJyb3IgPSBudWxsOyBicmVhazsgfVxuICAgICAgbGFzdEVycm9yID0gcmVzLmVycm9yO1xuICAgICAgaWYgKGF0dGVtcHQgPCAyKSBhd2FpdCBuZXcgUHJvbWlzZShyID0+IHNldFRpbWVvdXQociwgMjAwICogKGF0dGVtcHQgKyAxKSkpO1xuICAgIH1cbiAgICBpZiAobGFzdEVycm9yKSB0aHJvdyBsYXN0RXJyb3I7XG5cbiAgICBjb25zdCBtYXAgPSBuZXcgTWFwPHN0cmluZywgeyB2YWx1ZTogc3RyaW5nOyB1cGRhdGVkX2F0OiBzdHJpbmcgfT4oKTtcbiAgICAoZGF0YSA/PyBbXSkuZm9yRWFjaCgocm93OiBhbnkpID0+IG1hcC5zZXQocm93LmtleSwgeyB2YWx1ZTogcm93LnZhbHVlLCB1cGRhdGVkX2F0OiByb3cudXBkYXRlZF9hdCB9KSk7XG5cbiAgICBjb25zdCBlbmFibGVkID0gdG9Cb29sKG1hcC5nZXQoXCJtYWludGVuYW5jZV9tb2RlXCIpPy52YWx1ZSk7XG4gICAgY29uc3QgZXRhID0gbWFwLmdldChcIm1haW50ZW5hbmNlX2V0YVwiKT8udmFsdWUgPz8gbnVsbDtcbiAgICBjb25zdCBtZXNzYWdlID0gbWFwLmdldChcIm1haW50ZW5hbmNlX21lc3NhZ2VcIik/LnZhbHVlID8/IG51bGw7XG4gICAgY29uc3QgdXBkYXRlZEF0ID0gbWFwLmdldChcIm1haW50ZW5hbmNlX21vZGVcIik/LnVwZGF0ZWRfYXQgPz8gbnVsbDtcblxuICAgIC8vIENoZWNrIGlmIHVzZXIgaXMgd2hpdGVsaXN0ZWQgKG9ubHkgaWYgbWFpbnRlbmFuY2UgaXMgZW5hYmxlZClcbiAgICBsZXQgd2hpdGVsaXN0ZWQgPSBmYWxzZTtcbiAgICBpZiAoZW5hYmxlZCkge1xuICAgICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcImF1dGhvcml6YXRpb25cIik7XG4gICAgICBpZiAoYXV0aEhlYWRlcj8uc3RhcnRzV2l0aChcIkJlYXJlciBcIikpIHtcbiAgICAgICAgY29uc3QgdG9rZW4gPSBhdXRoSGVhZGVyLnNsaWNlKDcpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHsgZGF0YTogY2xhaW1zIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudC5hdXRoLmdldFVzZXIodG9rZW4pO1xuICAgICAgICAgIGlmIChjbGFpbXM/LnVzZXI/LmlkKSB7XG4gICAgICAgICAgICBjb25zdCB7IGRhdGE6IHdoaXRlbGlzdCB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgICAgICAgLmZyb20oXCJtYWludGVuYW5jZV93aGl0ZWxpc3RcIilcbiAgICAgICAgICAgICAgLnNlbGVjdChcImlkXCIpXG4gICAgICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgY2xhaW1zLnVzZXIuaWQpXG4gICAgICAgICAgICAgIC5tYXliZVNpbmdsZSgpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB3aGl0ZWxpc3RlZCA9ICEhd2hpdGVsaXN0O1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLy8gSWdub3JlIGF1dGggZXJyb3JzLCBqdXN0IGRvbid0IHdoaXRlbGlzdFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgcGF5bG9hZDogTWFpbnRlbmFuY2VTdGF0dXMgPSB7XG4gICAgICBlbmFibGVkLFxuICAgICAgZXRhLFxuICAgICAgbWVzc2FnZSxcbiAgICAgIHVwZGF0ZWRfYXQ6IHVwZGF0ZWRBdCxcbiAgICAgIHdoaXRlbGlzdGVkLFxuICAgIH07XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHBheWxvYWQpLCB7XG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIC4uLmNvcnNIZWFkZXJzLFxuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgLy8gSWYgZW5hYmxlZCBhbmQgRVRBIHByb3ZpZGVkLCBjbGllbnRzIGNhbiByZS1jaGVjayBsYXRlcjsgZmFsbGJhY2sgdG8gNSBtaW4uXG4gICAgICAgIFwiQ2FjaGUtQ29udHJvbFwiOiBlbmFibGVkID8gXCJwdWJsaWMsIG1heC1hZ2U9NjBcIiA6IFwicHVibGljLCBtYXgtYWdlPTMwXCIsXG4gICAgICB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKFwibWFpbnRlbmFuY2Utc3RhdHVzIGVycm9yOlwiLCBlcnIpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeSh7IGVuYWJsZWQ6IGZhbHNlLCBlcnJvcjogbWVzc2FnZSB9KSwge1xuICAgICAgc3RhdHVzOiA1MDAsXG4gICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgIH0pO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBVUEsU0FBUyxPQUFPLEtBQWdDO0VBQzlDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsRUFBRSxXQUFXLE9BQU87QUFDekM7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQjtJQUNwRCxNQUFNLFVBQVUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLHdCQUF3QjtJQUNyRCxNQUFNLGlCQUFpQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0lBRXBFLE1BQU0saUJBQWlCLGFBQ3JCLGFBQ0Esa0JBQWtCO0lBR3BCLGdFQUFnRTtJQUNoRSxJQUFJLE9BQVk7SUFDaEIsSUFBSSxZQUFpQjtJQUNyQixJQUFLLElBQUksVUFBVSxHQUFHLFVBQVUsR0FBRyxVQUFXO01BQzVDLE1BQU0sTUFBTSxNQUFNLGVBQ2YsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLHdCQUNQLEVBQUUsQ0FBQyxPQUFPO1FBQUM7UUFBb0I7UUFBbUI7T0FBc0I7TUFDM0UsSUFBSSxDQUFDLElBQUksS0FBSyxFQUFFO1FBQUUsT0FBTyxJQUFJLElBQUk7UUFBRSxZQUFZO1FBQU07TUFBTztNQUM1RCxZQUFZLElBQUksS0FBSztNQUNyQixJQUFJLFVBQVUsR0FBRyxNQUFNLElBQUksUUFBUSxDQUFBLElBQUssV0FBVyxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUM7SUFDMUU7SUFDQSxJQUFJLFdBQVcsTUFBTTtJQUVyQixNQUFNLE1BQU0sSUFBSTtJQUNoQixDQUFDLFFBQVEsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDLE1BQWEsSUFBSSxHQUFHLENBQUMsSUFBSSxHQUFHLEVBQUU7UUFBRSxPQUFPLElBQUksS0FBSztRQUFFLFlBQVksSUFBSSxVQUFVO01BQUM7SUFFbkcsTUFBTSxVQUFVLE9BQU8sSUFBSSxHQUFHLENBQUMscUJBQXFCO0lBQ3BELE1BQU0sTUFBTSxJQUFJLEdBQUcsQ0FBQyxvQkFBb0IsU0FBUztJQUNqRCxNQUFNLFVBQVUsSUFBSSxHQUFHLENBQUMsd0JBQXdCLFNBQVM7SUFDekQsTUFBTSxZQUFZLElBQUksR0FBRyxDQUFDLHFCQUFxQixjQUFjO0lBRTdELGdFQUFnRTtJQUNoRSxJQUFJLGNBQWM7SUFDbEIsSUFBSSxTQUFTO01BQ1gsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztNQUNuQyxJQUFJLFlBQVksV0FBVyxZQUFZO1FBQ3JDLE1BQU0sUUFBUSxXQUFXLEtBQUssQ0FBQztRQUMvQixJQUFJO1VBQ0YsTUFBTSxFQUFFLE1BQU0sTUFBTSxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxPQUFPLENBQUM7VUFDM0QsSUFBSSxRQUFRLE1BQU0sSUFBSTtZQUNwQixNQUFNLEVBQUUsTUFBTSxTQUFTLEVBQUUsR0FBRyxNQUFNLGVBQy9CLElBQUksQ0FBQyx5QkFDTCxNQUFNLENBQUMsTUFDUCxFQUFFLENBQUMsV0FBVyxPQUFPLElBQUksQ0FBQyxFQUFFLEVBQzVCLFdBQVc7WUFFZCxjQUFjLENBQUMsQ0FBQztVQUNsQjtRQUNGLEVBQUUsT0FBTTtRQUNOLDJDQUEyQztRQUM3QztNQUNGO0lBQ0Y7SUFFQSxNQUFNLFVBQTZCO01BQ2pDO01BQ0E7TUFDQTtNQUNBLFlBQVk7TUFDWjtJQUNGO0lBRUEsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUMsVUFBVTtNQUMzQyxTQUFTO1FBQ1AsR0FBRyxXQUFXO1FBQ2QsZ0JBQWdCO1FBQ2hCLDhFQUE4RTtRQUM5RSxpQkFBaUIsVUFBVSx1QkFBdUI7TUFDcEQ7SUFDRjtFQUNGLEVBQUUsT0FBTyxLQUFLO0lBQ1osUUFBUSxLQUFLLENBQUMsNkJBQTZCO0lBQzNDLE1BQU0sVUFBVSxlQUFlLFFBQVEsSUFBSSxPQUFPLEdBQUc7SUFDckQsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU8sT0FBTztJQUFRLElBQUk7TUFDdEUsUUFBUTtNQUNSLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFDaEU7RUFDRjtBQUNGIn0=
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Style presets for AI cover generation
const stylePrompts = {
  abstract: "Abstract modern art style with flowing shapes, vibrant color gradients, dynamic composition",
  neon: "Neon cyberpunk aesthetic with glowing lights, dark background, electric blue and pink colors, futuristic city vibes",
  minimal: "Minimalist design with clean lines, geometric shapes, limited color palette, elegant simplicity",
  retro: "Retro 80s synthwave style with sunset gradients, palm trees silhouettes, grid patterns, VHS aesthetic",
  nature: "Organic natural elements, forest or ocean imagery, ethereal atmosphere, dreamy soft lighting",
  space: "Cosmic space theme with galaxies, nebulas, stars, planets, deep purple and blue cosmic colors",
  grunge: "Dark grunge aesthetic with textures, distressed elements, moody atmosphere, industrial feel",
  pop_art: "Bold pop art style with bright colors, comic book dots, strong outlines, Andy Warhol inspired",
  watercolor: "Soft watercolor painting style with flowing colors, artistic brushstrokes, delicate textures",
  futuristic: "Futuristic high-tech design with holographic elements, chrome surfaces, AI-generated patterns"
};
const moodPrompts = {
  energetic: "high energy, dynamic movement, explosive, powerful",
  calm: "peaceful, serene, tranquil, meditative",
  dark: "mysterious, shadowy, intense, dramatic",
  bright: "cheerful, uplifting, sunny, optimistic",
  melancholic: "emotional, nostalgic, bittersweet, thoughtful",
  aggressive: "fierce, bold, raw, powerful impact"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Verify user
    const supabaseClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY"), {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { track_id, track_title, genre, style = "abstract", mood = "energetic", custom_prompt, color_scheme, include_text = false } = await req.json();
    if (!track_id) {
      return new Response(JSON.stringify({
        error: "track_id is required"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Generating AI cover for track: ${track_id}, style: ${style}, mood: ${mood}`);
    // Build the comprehensive prompt
    const styleDescription = stylePrompts[style] || stylePrompts.abstract;
    const moodDescription = moodPrompts[mood] || moodPrompts.energetic;
    let prompt = `Create a stunning, professional album cover art (1024x1024 pixels) for a music track.

Track Information:
- Title: "${track_title || 'Untitled'}"
- Genre: ${genre || "electronic music"}

Visual Style: ${styleDescription}
Mood & Atmosphere: ${moodDescription}
${color_scheme ? `Color Palette: ${color_scheme}` : ""}

Requirements:
- Ultra high resolution, professional quality
- Modern, visually striking design suitable for music streaming platforms
- Square 1:1 aspect ratio album artwork
- No text or typography on the image
- Rich details and artistic composition
- Should evoke emotions matching the music style

${custom_prompt ? `Additional creative direction: ${custom_prompt}` : ""}

Create artwork that would stand out on Spotify, Apple Music, and other streaming platforms.`;
    console.log("Prompt:", prompt);
    // Call Lovable AI with image generation
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "google/gemini-3-pro-image-preview",
        messages: [
          {
            role: "user",
            content: prompt
          }
        ],
        modalities: [
          "image",
          "text"
        ]
      })
    });
    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      if (response.status === 429) {
        return new Response(JSON.stringify({
          error: "Rate limit exceeded. Please try again later."
        }), {
          status: 429,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({
          error: "Payment required. Please add funds to your workspace."
        }), {
          status: 402,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      throw new Error(`AI gateway error: ${response.status}`);
    }
    const data = await response.json();
    const imageUrl = data.choices?.[0]?.message?.images?.[0]?.image_url?.url;
    if (!imageUrl) {
      console.error("No image in response:", JSON.stringify(data));
      throw new Error("No image generated by AI");
    }
    console.log("AI cover generated successfully");
    // Upload the base64 image to Supabase Storage
    const base64Data = imageUrl.replace(/^data:image\/\w+;base64,/, "");
    const imageBuffer = Uint8Array.from(atob(base64Data), (c)=>c.charCodeAt(0));
    const fileName = `ai-covers/${track_id}-${Date.now()}.png`;
    const { data: uploadData, error: uploadError } = await supabase.storage.from("tracks").upload(fileName, imageBuffer, {
      contentType: "image/png",
      upsert: true
    });
    if (uploadError) {
      console.error("Storage upload error:", uploadError);
      throw new Error("Failed to upload AI cover to storage");
    }
    const { data: publicUrl } = supabase.storage.from("tracks").getPublicUrl(fileName);
    // Store in gallery_items for user's gallery
    await supabase.from("gallery_items").insert({
      user_id: user.id,
      track_id: track_id,
      type: "ai_cover",
      url: publicUrl.publicUrl,
      title: `AI Cover - ${track_title || 'Untitled'}`,
      prompt: prompt,
      style: style,
      is_public: false
    });
    console.log("Cover saved to gallery:", publicUrl.publicUrl);
    return new Response(JSON.stringify({
      success: true,
      cover_url: publicUrl.publicUrl,
      style: style,
      mood: mood,
      message: "AI cover generated successfully"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("generate-ai-cover error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9nZW5lcmF0ZS1haS1jb3Zlci9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbi8vIFN0eWxlIHByZXNldHMgZm9yIEFJIGNvdmVyIGdlbmVyYXRpb25cbmNvbnN0IHN0eWxlUHJvbXB0czogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgYWJzdHJhY3Q6IFwiQWJzdHJhY3QgbW9kZXJuIGFydCBzdHlsZSB3aXRoIGZsb3dpbmcgc2hhcGVzLCB2aWJyYW50IGNvbG9yIGdyYWRpZW50cywgZHluYW1pYyBjb21wb3NpdGlvblwiLFxuICBuZW9uOiBcIk5lb24gY3liZXJwdW5rIGFlc3RoZXRpYyB3aXRoIGdsb3dpbmcgbGlnaHRzLCBkYXJrIGJhY2tncm91bmQsIGVsZWN0cmljIGJsdWUgYW5kIHBpbmsgY29sb3JzLCBmdXR1cmlzdGljIGNpdHkgdmliZXNcIixcbiAgbWluaW1hbDogXCJNaW5pbWFsaXN0IGRlc2lnbiB3aXRoIGNsZWFuIGxpbmVzLCBnZW9tZXRyaWMgc2hhcGVzLCBsaW1pdGVkIGNvbG9yIHBhbGV0dGUsIGVsZWdhbnQgc2ltcGxpY2l0eVwiLFxuICByZXRybzogXCJSZXRybyA4MHMgc3ludGh3YXZlIHN0eWxlIHdpdGggc3Vuc2V0IGdyYWRpZW50cywgcGFsbSB0cmVlcyBzaWxob3VldHRlcywgZ3JpZCBwYXR0ZXJucywgVkhTIGFlc3RoZXRpY1wiLFxuICBuYXR1cmU6IFwiT3JnYW5pYyBuYXR1cmFsIGVsZW1lbnRzLCBmb3Jlc3Qgb3Igb2NlYW4gaW1hZ2VyeSwgZXRoZXJlYWwgYXRtb3NwaGVyZSwgZHJlYW15IHNvZnQgbGlnaHRpbmdcIixcbiAgc3BhY2U6IFwiQ29zbWljIHNwYWNlIHRoZW1lIHdpdGggZ2FsYXhpZXMsIG5lYnVsYXMsIHN0YXJzLCBwbGFuZXRzLCBkZWVwIHB1cnBsZSBhbmQgYmx1ZSBjb3NtaWMgY29sb3JzXCIsXG4gIGdydW5nZTogXCJEYXJrIGdydW5nZSBhZXN0aGV0aWMgd2l0aCB0ZXh0dXJlcywgZGlzdHJlc3NlZCBlbGVtZW50cywgbW9vZHkgYXRtb3NwaGVyZSwgaW5kdXN0cmlhbCBmZWVsXCIsXG4gIHBvcF9hcnQ6IFwiQm9sZCBwb3AgYXJ0IHN0eWxlIHdpdGggYnJpZ2h0IGNvbG9ycywgY29taWMgYm9vayBkb3RzLCBzdHJvbmcgb3V0bGluZXMsIEFuZHkgV2FyaG9sIGluc3BpcmVkXCIsXG4gIHdhdGVyY29sb3I6IFwiU29mdCB3YXRlcmNvbG9yIHBhaW50aW5nIHN0eWxlIHdpdGggZmxvd2luZyBjb2xvcnMsIGFydGlzdGljIGJydXNoc3Ryb2tlcywgZGVsaWNhdGUgdGV4dHVyZXNcIixcbiAgZnV0dXJpc3RpYzogXCJGdXR1cmlzdGljIGhpZ2gtdGVjaCBkZXNpZ24gd2l0aCBob2xvZ3JhcGhpYyBlbGVtZW50cywgY2hyb21lIHN1cmZhY2VzLCBBSS1nZW5lcmF0ZWQgcGF0dGVybnNcIixcbn07XG5cbmNvbnN0IG1vb2RQcm9tcHRzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICBlbmVyZ2V0aWM6IFwiaGlnaCBlbmVyZ3ksIGR5bmFtaWMgbW92ZW1lbnQsIGV4cGxvc2l2ZSwgcG93ZXJmdWxcIixcbiAgY2FsbTogXCJwZWFjZWZ1bCwgc2VyZW5lLCB0cmFucXVpbCwgbWVkaXRhdGl2ZVwiLFxuICBkYXJrOiBcIm15c3RlcmlvdXMsIHNoYWRvd3ksIGludGVuc2UsIGRyYW1hdGljXCIsXG4gIGJyaWdodDogXCJjaGVlcmZ1bCwgdXBsaWZ0aW5nLCBzdW5ueSwgb3B0aW1pc3RpY1wiLFxuICBtZWxhbmNob2xpYzogXCJlbW90aW9uYWwsIG5vc3RhbGdpYywgYml0dGVyc3dlZXQsIHRob3VnaHRmdWxcIixcbiAgYWdncmVzc2l2ZTogXCJmaWVyY2UsIGJvbGQsIHJhdywgcG93ZXJmdWwgaW1wYWN0XCIsXG59O1xuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk5vIGF1dGhvcml6YXRpb24gaGVhZGVyXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gICAgY29uc3QgTE9WQUJMRV9BUElfS0VZID0gRGVuby5lbnYuZ2V0KFwiTE9WQUJMRV9BUElfS0VZXCIpO1xuXG4gICAgaWYgKCFMT1ZBQkxFX0FQSV9LRVkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkxPVkFCTEVfQVBJX0tFWSBpcyBub3QgY29uZmlndXJlZFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIC8vIFZlcmlmeSB1c2VyXG4gICAgY29uc3Qgc3VwYWJhc2VDbGllbnQgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIERlbm8uZW52LmdldChcIlNVUEFCQVNFX0FOT05fS0VZXCIpISwge1xuICAgICAgZ2xvYmFsOiB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYXV0aEhlYWRlciB9IH0sXG4gICAgfSk7XG4gICAgXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IHVzZXJFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnQuYXV0aC5nZXRVc2VyKCk7XG4gICAgaWYgKHVzZXJFcnJvciB8fCAhdXNlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHsgXG4gICAgICB0cmFja19pZCwgXG4gICAgICB0cmFja190aXRsZSwgXG4gICAgICBnZW5yZSxcbiAgICAgIHN0eWxlID0gXCJhYnN0cmFjdFwiLFxuICAgICAgbW9vZCA9IFwiZW5lcmdldGljXCIsXG4gICAgICBjdXN0b21fcHJvbXB0LFxuICAgICAgY29sb3Jfc2NoZW1lLFxuICAgICAgaW5jbHVkZV90ZXh0ID0gZmFsc2UsXG4gICAgfSA9IGF3YWl0IHJlcS5qc29uKCk7XG5cbiAgICBpZiAoIXRyYWNrX2lkKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcInRyYWNrX2lkIGlzIHJlcXVpcmVkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgR2VuZXJhdGluZyBBSSBjb3ZlciBmb3IgdHJhY2s6ICR7dHJhY2tfaWR9LCBzdHlsZTogJHtzdHlsZX0sIG1vb2Q6ICR7bW9vZH1gKTtcblxuICAgIC8vIEJ1aWxkIHRoZSBjb21wcmVoZW5zaXZlIHByb21wdFxuICAgIGNvbnN0IHN0eWxlRGVzY3JpcHRpb24gPSBzdHlsZVByb21wdHNbc3R5bGVdIHx8IHN0eWxlUHJvbXB0cy5hYnN0cmFjdDtcbiAgICBjb25zdCBtb29kRGVzY3JpcHRpb24gPSBtb29kUHJvbXB0c1ttb29kXSB8fCBtb29kUHJvbXB0cy5lbmVyZ2V0aWM7XG4gICAgXG4gICAgbGV0IHByb21wdCA9IGBDcmVhdGUgYSBzdHVubmluZywgcHJvZmVzc2lvbmFsIGFsYnVtIGNvdmVyIGFydCAoMTAyNHgxMDI0IHBpeGVscykgZm9yIGEgbXVzaWMgdHJhY2suXG5cblRyYWNrIEluZm9ybWF0aW9uOlxuLSBUaXRsZTogXCIke3RyYWNrX3RpdGxlIHx8ICdVbnRpdGxlZCd9XCJcbi0gR2VucmU6ICR7Z2VucmUgfHwgXCJlbGVjdHJvbmljIG11c2ljXCJ9XG5cblZpc3VhbCBTdHlsZTogJHtzdHlsZURlc2NyaXB0aW9ufVxuTW9vZCAmIEF0bW9zcGhlcmU6ICR7bW9vZERlc2NyaXB0aW9ufVxuJHtjb2xvcl9zY2hlbWUgPyBgQ29sb3IgUGFsZXR0ZTogJHtjb2xvcl9zY2hlbWV9YCA6IFwiXCJ9XG5cblJlcXVpcmVtZW50czpcbi0gVWx0cmEgaGlnaCByZXNvbHV0aW9uLCBwcm9mZXNzaW9uYWwgcXVhbGl0eVxuLSBNb2Rlcm4sIHZpc3VhbGx5IHN0cmlraW5nIGRlc2lnbiBzdWl0YWJsZSBmb3IgbXVzaWMgc3RyZWFtaW5nIHBsYXRmb3Jtc1xuLSBTcXVhcmUgMToxIGFzcGVjdCByYXRpbyBhbGJ1bSBhcnR3b3JrXG4tIE5vIHRleHQgb3IgdHlwb2dyYXBoeSBvbiB0aGUgaW1hZ2Vcbi0gUmljaCBkZXRhaWxzIGFuZCBhcnRpc3RpYyBjb21wb3NpdGlvblxuLSBTaG91bGQgZXZva2UgZW1vdGlvbnMgbWF0Y2hpbmcgdGhlIG11c2ljIHN0eWxlXG5cbiR7Y3VzdG9tX3Byb21wdCA/IGBBZGRpdGlvbmFsIGNyZWF0aXZlIGRpcmVjdGlvbjogJHtjdXN0b21fcHJvbXB0fWAgOiBcIlwifVxuXG5DcmVhdGUgYXJ0d29yayB0aGF0IHdvdWxkIHN0YW5kIG91dCBvbiBTcG90aWZ5LCBBcHBsZSBNdXNpYywgYW5kIG90aGVyIHN0cmVhbWluZyBwbGF0Zm9ybXMuYDtcblxuICAgIGNvbnNvbGUubG9nKFwiUHJvbXB0OlwiLCBwcm9tcHQpO1xuXG4gICAgLy8gQ2FsbCBMb3ZhYmxlIEFJIHdpdGggaW1hZ2UgZ2VuZXJhdGlvblxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXCJodHRwczovL2FpLmdhdGV3YXkubG92YWJsZS5kZXYvdjEvY2hhdC9jb21wbGV0aW9uc1wiLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7TE9WQUJMRV9BUElfS0VZfWAsXG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgbW9kZWw6IFwiZ29vZ2xlL2dlbWluaS0zLXByby1pbWFnZS1wcmV2aWV3XCIsXG4gICAgICAgIG1lc3NhZ2VzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgcm9sZTogXCJ1c2VyXCIsXG4gICAgICAgICAgICBjb250ZW50OiBwcm9tcHQsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgbW9kYWxpdGllczogW1wiaW1hZ2VcIiwgXCJ0ZXh0XCJdLFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICBjb25zdCBlcnJvclRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICBjb25zb2xlLmVycm9yKFwiQUkgZ2F0ZXdheSBlcnJvcjpcIiwgcmVzcG9uc2Uuc3RhdHVzLCBlcnJvclRleHQpO1xuICAgICAgXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MjkpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlJhdGUgbGltaXQgZXhjZWVkZWQuIFBsZWFzZSB0cnkgYWdhaW4gbGF0ZXIuXCIgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDQyOSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDIpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlBheW1lbnQgcmVxdWlyZWQuIFBsZWFzZSBhZGQgZnVuZHMgdG8geW91ciB3b3Jrc3BhY2UuXCIgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDQwMiwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEFJIGdhdGV3YXkgZXJyb3I6ICR7cmVzcG9uc2Uuc3RhdHVzfWApO1xuICAgIH1cblxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgY29uc3QgaW1hZ2VVcmwgPSBkYXRhLmNob2ljZXM/LlswXT8ubWVzc2FnZT8uaW1hZ2VzPy5bMF0/LmltYWdlX3VybD8udXJsO1xuXG4gICAgaWYgKCFpbWFnZVVybCkge1xuICAgICAgY29uc29sZS5lcnJvcihcIk5vIGltYWdlIGluIHJlc3BvbnNlOlwiLCBKU09OLnN0cmluZ2lmeShkYXRhKSk7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBpbWFnZSBnZW5lcmF0ZWQgYnkgQUlcIik7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coXCJBSSBjb3ZlciBnZW5lcmF0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xuXG4gICAgLy8gVXBsb2FkIHRoZSBiYXNlNjQgaW1hZ2UgdG8gU3VwYWJhc2UgU3RvcmFnZVxuICAgIGNvbnN0IGJhc2U2NERhdGEgPSBpbWFnZVVybC5yZXBsYWNlKC9eZGF0YTppbWFnZVxcL1xcdys7YmFzZTY0LC8sIFwiXCIpO1xuICAgIGNvbnN0IGltYWdlQnVmZmVyID0gVWludDhBcnJheS5mcm9tKGF0b2IoYmFzZTY0RGF0YSksIChjKSA9PiBjLmNoYXJDb2RlQXQoMCkpO1xuICAgIFxuICAgIGNvbnN0IGZpbGVOYW1lID0gYGFpLWNvdmVycy8ke3RyYWNrX2lkfS0ke0RhdGUubm93KCl9LnBuZ2A7XG4gICAgXG4gICAgY29uc3QgeyBkYXRhOiB1cGxvYWREYXRhLCBlcnJvcjogdXBsb2FkRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLnN0b3JhZ2VcbiAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAudXBsb2FkKGZpbGVOYW1lLCBpbWFnZUJ1ZmZlciwge1xuICAgICAgICBjb250ZW50VHlwZTogXCJpbWFnZS9wbmdcIixcbiAgICAgICAgdXBzZXJ0OiB0cnVlLFxuICAgICAgfSk7XG5cbiAgICBpZiAodXBsb2FkRXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJTdG9yYWdlIHVwbG9hZCBlcnJvcjpcIiwgdXBsb2FkRXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHVwbG9hZCBBSSBjb3ZlciB0byBzdG9yYWdlXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHsgZGF0YTogcHVibGljVXJsIH0gPSBzdXBhYmFzZS5zdG9yYWdlXG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLmdldFB1YmxpY1VybChmaWxlTmFtZSk7XG5cbiAgICAvLyBTdG9yZSBpbiBnYWxsZXJ5X2l0ZW1zIGZvciB1c2VyJ3MgZ2FsbGVyeVxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oXCJnYWxsZXJ5X2l0ZW1zXCIpLmluc2VydCh7XG4gICAgICB1c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgdHJhY2tfaWQ6IHRyYWNrX2lkLFxuICAgICAgdHlwZTogXCJhaV9jb3ZlclwiLFxuICAgICAgdXJsOiBwdWJsaWNVcmwucHVibGljVXJsLFxuICAgICAgdGl0bGU6IGBBSSBDb3ZlciAtICR7dHJhY2tfdGl0bGUgfHwgJ1VudGl0bGVkJ31gLFxuICAgICAgcHJvbXB0OiBwcm9tcHQsXG4gICAgICBzdHlsZTogc3R5bGUsXG4gICAgICBpc19wdWJsaWM6IGZhbHNlLFxuICAgIH0pO1xuXG4gICAgY29uc29sZS5sb2coXCJDb3ZlciBzYXZlZCB0byBnYWxsZXJ5OlwiLCBwdWJsaWNVcmwucHVibGljVXJsKTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgIGNvdmVyX3VybDogcHVibGljVXJsLnB1YmxpY1VybCxcbiAgICAgICAgc3R5bGU6IHN0eWxlLFxuICAgICAgICBtb29kOiBtb29kLFxuICAgICAgICBtZXNzYWdlOiBcIkFJIGNvdmVyIGdlbmVyYXRlZCBzdWNjZXNzZnVsbHlcIixcbiAgICAgIH0pLFxuICAgICAge1xuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgfVxuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcImdlbmVyYXRlLWFpLWNvdmVyIGVycm9yOlwiLCBlcnJvcik7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIGVycm9yOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiLFxuICAgICAgfSksXG4gICAgICB7XG4gICAgICAgIHN0YXR1czogNTAwLFxuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSx3Q0FBd0M7QUFDeEMsTUFBTSxlQUF1QztFQUMzQyxVQUFVO0VBQ1YsTUFBTTtFQUNOLFNBQVM7RUFDVCxPQUFPO0VBQ1AsUUFBUTtFQUNSLE9BQU87RUFDUCxRQUFRO0VBQ1IsU0FBUztFQUNULFlBQVk7RUFDWixZQUFZO0FBQ2Q7QUFFQSxNQUFNLGNBQXNDO0VBQzFDLFdBQVc7RUFDWCxNQUFNO0VBQ04sTUFBTTtFQUNOLFFBQVE7RUFDUixhQUFhO0VBQ2IsWUFBWTtBQUNkO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEwQixJQUNsRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFFckMsSUFBSSxDQUFDLGlCQUFpQjtNQUNwQixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0MsY0FBYztJQUNkLE1BQU0saUJBQWlCLGFBQWEsYUFBYSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsc0JBQXVCO01BQ25GLFFBQVE7UUFBRSxTQUFTO1VBQUUsZUFBZTtRQUFXO01BQUU7SUFDbkQ7SUFFQSxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxPQUFPO0lBQzlFLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWUsSUFDdkM7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxFQUNKLFFBQVEsRUFDUixXQUFXLEVBQ1gsS0FBSyxFQUNMLFFBQVEsVUFBVSxFQUNsQixPQUFPLFdBQVcsRUFDbEIsYUFBYSxFQUNiLFlBQVksRUFDWixlQUFlLEtBQUssRUFDckIsR0FBRyxNQUFNLElBQUksSUFBSTtJQUVsQixJQUFJLENBQUMsVUFBVTtNQUNiLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF1QixJQUMvQztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLCtCQUErQixFQUFFLFNBQVMsU0FBUyxFQUFFLE1BQU0sUUFBUSxFQUFFLEtBQUssQ0FBQztJQUV4RixpQ0FBaUM7SUFDakMsTUFBTSxtQkFBbUIsWUFBWSxDQUFDLE1BQU0sSUFBSSxhQUFhLFFBQVE7SUFDckUsTUFBTSxrQkFBa0IsV0FBVyxDQUFDLEtBQUssSUFBSSxZQUFZLFNBQVM7SUFFbEUsSUFBSSxTQUFTLENBQUM7OztVQUdSLEVBQUUsZUFBZSxXQUFXO1NBQzdCLEVBQUUsU0FBUyxtQkFBbUI7O2NBRXpCLEVBQUUsaUJBQWlCO21CQUNkLEVBQUUsZ0JBQWdCO0FBQ3JDLEVBQUUsZUFBZSxDQUFDLGVBQWUsRUFBRSxhQUFhLENBQUMsR0FBRyxHQUFHOzs7Ozs7Ozs7O0FBVXZELEVBQUUsZ0JBQWdCLENBQUMsK0JBQStCLEVBQUUsY0FBYyxDQUFDLEdBQUcsR0FBRzs7MkZBRWtCLENBQUM7SUFFeEYsUUFBUSxHQUFHLENBQUMsV0FBVztJQUV2Qix3Q0FBd0M7SUFDeEMsTUFBTSxXQUFXLE1BQU0sTUFBTSxzREFBc0Q7TUFDakYsUUFBUTtNQUNSLFNBQVM7UUFDUCxlQUFlLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDO1FBQzFDLGdCQUFnQjtNQUNsQjtNQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7UUFDbkIsT0FBTztRQUNQLFVBQVU7VUFDUjtZQUNFLE1BQU07WUFDTixTQUFTO1VBQ1g7U0FDRDtRQUNELFlBQVk7VUFBQztVQUFTO1NBQU87TUFDL0I7SUFDRjtJQUVBLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRTtNQUNoQixNQUFNLFlBQVksTUFBTSxTQUFTLElBQUk7TUFDckMsUUFBUSxLQUFLLENBQUMscUJBQXFCLFNBQVMsTUFBTSxFQUFFO01BRXBELElBQUksU0FBUyxNQUFNLEtBQUssS0FBSztRQUMzQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBK0MsSUFDdkU7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BQ0EsSUFBSSxTQUFTLE1BQU0sS0FBSyxLQUFLO1FBQzNCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUF3RCxJQUNoRjtVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFDQSxNQUFNLElBQUksTUFBTSxDQUFDLGtCQUFrQixFQUFFLFNBQVMsTUFBTSxDQUFDLENBQUM7SUFDeEQ7SUFFQSxNQUFNLE9BQU8sTUFBTSxTQUFTLElBQUk7SUFDaEMsTUFBTSxXQUFXLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRSxFQUFFLFNBQVMsUUFBUSxDQUFDLEVBQUUsRUFBRSxXQUFXO0lBRXJFLElBQUksQ0FBQyxVQUFVO01BQ2IsUUFBUSxLQUFLLENBQUMseUJBQXlCLEtBQUssU0FBUyxDQUFDO01BQ3RELE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsUUFBUSxHQUFHLENBQUM7SUFFWiw4Q0FBOEM7SUFDOUMsTUFBTSxhQUFhLFNBQVMsT0FBTyxDQUFDLDRCQUE0QjtJQUNoRSxNQUFNLGNBQWMsV0FBVyxJQUFJLENBQUMsS0FBSyxhQUFhLENBQUMsSUFBTSxFQUFFLFVBQVUsQ0FBQztJQUUxRSxNQUFNLFdBQVcsQ0FBQyxVQUFVLEVBQUUsU0FBUyxDQUFDLEVBQUUsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBRTFELE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FBUyxPQUFPLENBQ3BFLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxVQUFVLGFBQWE7TUFDN0IsYUFBYTtNQUNiLFFBQVE7SUFDVjtJQUVGLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLHlCQUF5QjtNQUN2QyxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sRUFBRSxNQUFNLFNBQVMsRUFBRSxHQUFHLFNBQVMsT0FBTyxDQUN6QyxJQUFJLENBQUMsVUFDTCxZQUFZLENBQUM7SUFFaEIsNENBQTRDO0lBQzVDLE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztNQUMxQyxTQUFTLEtBQUssRUFBRTtNQUNoQixVQUFVO01BQ1YsTUFBTTtNQUNOLEtBQUssVUFBVSxTQUFTO01BQ3hCLE9BQU8sQ0FBQyxXQUFXLEVBQUUsZUFBZSxXQUFXLENBQUM7TUFDaEQsUUFBUTtNQUNSLE9BQU87TUFDUCxXQUFXO0lBQ2I7SUFFQSxRQUFRLEdBQUcsQ0FBQywyQkFBMkIsVUFBVSxTQUFTO0lBRTFELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULFdBQVcsVUFBVSxTQUFTO01BQzlCLE9BQU87TUFDUCxNQUFNO01BQ04sU0FBUztJQUNYLElBQ0E7TUFDRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQ2hFO0VBRUosRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFDMUMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsT0FBTyxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUNsRCxJQUNBO01BQ0UsUUFBUTtNQUNSLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFDaEU7RUFFSjtBQUNGIn0=
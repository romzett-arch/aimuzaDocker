import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  let trackId = null;
  try {
    // Security: Verify request comes from service role (internal calls only)
    const authHeader = req.headers.get("Authorization");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (authHeader !== `Bearer ${supabaseServiceKey}`) {
      return new Response(JSON.stringify({
        error: "Unauthorized - internal use only"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const body = await req.json();
    const { track_id, audio_url, track_title, start_time = 0, duration = 30 } = body;
    trackId = track_id;
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    console.log(`Creating ringtone for track: ${track_id}, title: ${track_title}`);
    if (!audio_url) {
      throw new Error("Audio URL is required for ringtone generation");
    }
    // Update the track_addons table with the result (use original audio as ringtone)
    const { data: addonService } = await supabase.from("addon_services").select("id").eq("name", "ringtone").single();
    if (addonService) {
      const { error: updateError } = await supabase.from("track_addons").update({
        result_url: audio_url,
        status: "completed",
        updated_at: new Date().toISOString()
      }).eq("track_id", track_id).eq("addon_service_id", addonService.id);
      if (updateError) {
        console.error("Update addon error:", updateError);
        throw new Error("Failed to update addon status");
      }
    }
    console.log(`Ringtone created successfully for track: ${track_id}`);
    return new Response(JSON.stringify({
      success: true,
      ringtone_url: audio_url,
      message: "Ringtone created successfully"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("generate-ringtone error:", error);
    // Update addon status to failed if we have trackId
    if (trackId) {
      try {
        const supabaseUrl = Deno.env.get("SUPABASE_URL");
        const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
        const supabase = createClient(supabaseUrl, supabaseServiceKey);
        const { data: addonService } = await supabase.from("addon_services").select("id").eq("name", "ringtone").single();
        if (addonService) {
          await supabase.from("track_addons").update({
            status: "failed",
            updated_at: new Date().toISOString()
          }).eq("track_id", trackId).eq("addon_service_id", addonService.id);
        }
      } catch (e) {
        console.error("Failed to update addon status:", e);
      }
    }
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9nZW5lcmF0ZS1yaW5ndG9uZS9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgbGV0IHRyYWNrSWQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuXG4gIHRyeSB7XG4gICAgLy8gU2VjdXJpdHk6IFZlcmlmeSByZXF1ZXN0IGNvbWVzIGZyb20gc2VydmljZSByb2xlIChpbnRlcm5hbCBjYWxscyBvbmx5KVxuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIFxuICAgIGlmIChhdXRoSGVhZGVyICE9PSBgQmVhcmVyICR7c3VwYWJhc2VTZXJ2aWNlS2V5fWApIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkIC0gaW50ZXJuYWwgdXNlIG9ubHlcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnN0IHsgdHJhY2tfaWQsIGF1ZGlvX3VybCwgdHJhY2tfdGl0bGUsIHN0YXJ0X3RpbWUgPSAwLCBkdXJhdGlvbiA9IDMwIH0gPSBib2R5O1xuICAgIHRyYWNrSWQgPSB0cmFja19pZDtcbiAgICBcbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlU2VydmljZUtleSk7XG5cbiAgICBjb25zb2xlLmxvZyhgQ3JlYXRpbmcgcmluZ3RvbmUgZm9yIHRyYWNrOiAke3RyYWNrX2lkfSwgdGl0bGU6ICR7dHJhY2tfdGl0bGV9YCk7XG5cbiAgICBpZiAoIWF1ZGlvX3VybCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQXVkaW8gVVJMIGlzIHJlcXVpcmVkIGZvciByaW5ndG9uZSBnZW5lcmF0aW9uXCIpO1xuICAgIH1cblxuICAgIC8vIFVwZGF0ZSB0aGUgdHJhY2tfYWRkb25zIHRhYmxlIHdpdGggdGhlIHJlc3VsdCAodXNlIG9yaWdpbmFsIGF1ZGlvIGFzIHJpbmd0b25lKVxuICAgIGNvbnN0IHsgZGF0YTogYWRkb25TZXJ2aWNlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJhZGRvbl9zZXJ2aWNlc1wiKVxuICAgICAgLnNlbGVjdChcImlkXCIpXG4gICAgICAuZXEoXCJuYW1lXCIsIFwicmluZ3RvbmVcIilcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmIChhZGRvblNlcnZpY2UpIHtcbiAgICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICByZXN1bHRfdXJsOiBhdWRpb191cmwsXG4gICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwidHJhY2tfaWRcIiwgdHJhY2tfaWQpXG4gICAgICAgIC5lcShcImFkZG9uX3NlcnZpY2VfaWRcIiwgYWRkb25TZXJ2aWNlLmlkKTtcblxuICAgICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJVcGRhdGUgYWRkb24gZXJyb3I6XCIsIHVwZGF0ZUVycm9yKTtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSBhZGRvbiBzdGF0dXNcIik7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFJpbmd0b25lIGNyZWF0ZWQgc3VjY2Vzc2Z1bGx5IGZvciB0cmFjazogJHt0cmFja19pZH1gKTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgIHJpbmd0b25lX3VybDogYXVkaW9fdXJsLFxuICAgICAgICBtZXNzYWdlOiBcIlJpbmd0b25lIGNyZWF0ZWQgc3VjY2Vzc2Z1bGx5XCIsXG4gICAgICB9KSxcbiAgICAgIHtcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgIH1cbiAgICApO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJnZW5lcmF0ZS1yaW5ndG9uZSBlcnJvcjpcIiwgZXJyb3IpO1xuICAgIFxuICAgIC8vIFVwZGF0ZSBhZGRvbiBzdGF0dXMgdG8gZmFpbGVkIGlmIHdlIGhhdmUgdHJhY2tJZFxuICAgIGlmICh0cmFja0lkKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgICAgIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgICAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcbiAgICAgICAgXG4gICAgICAgIGNvbnN0IHsgZGF0YTogYWRkb25TZXJ2aWNlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwiYWRkb25fc2VydmljZXNcIilcbiAgICAgICAgICAuc2VsZWN0KFwiaWRcIilcbiAgICAgICAgICAuZXEoXCJuYW1lXCIsIFwicmluZ3RvbmVcIilcbiAgICAgICAgICAuc2luZ2xlKCk7XG4gICAgICAgICAgXG4gICAgICAgIGlmIChhZGRvblNlcnZpY2UpIHtcbiAgICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgICAgLmZyb20oXCJ0cmFja19hZGRvbnNcIilcbiAgICAgICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgICAgICBzdGF0dXM6IFwiZmFpbGVkXCIsXG4gICAgICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuZXEoXCJ0cmFja19pZFwiLCB0cmFja0lkKVxuICAgICAgICAgICAgLmVxKFwiYWRkb25fc2VydmljZV9pZFwiLCBhZGRvblNlcnZpY2UuaWQpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIGFkZG9uIHN0YXR1czpcIiwgZSk7XG4gICAgICB9XG4gICAgfVxuICAgIFxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICBlcnJvcjogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIixcbiAgICAgIH0pLFxuICAgICAge1xuICAgICAgICBzdGF0dXM6IDUwMCxcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgIH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJLFVBQXlCO0VBRTdCLElBQUk7SUFDRix5RUFBeUU7SUFDekUsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFFeEMsSUFBSSxlQUFlLENBQUMsT0FBTyxFQUFFLG1CQUFtQixDQUFDLEVBQUU7TUFDakQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQW1DLElBQzNEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtJQUMzQixNQUFNLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsYUFBYSxDQUFDLEVBQUUsV0FBVyxFQUFFLEVBQUUsR0FBRztJQUM1RSxVQUFVO0lBRVYsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLFFBQVEsR0FBRyxDQUFDLENBQUMsNkJBQTZCLEVBQUUsU0FBUyxTQUFTLEVBQUUsWUFBWSxDQUFDO0lBRTdFLElBQUksQ0FBQyxXQUFXO01BQ2QsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxpRkFBaUY7SUFDakYsTUFBTSxFQUFFLE1BQU0sWUFBWSxFQUFFLEdBQUcsTUFBTSxTQUNsQyxJQUFJLENBQUMsa0JBQ0wsTUFBTSxDQUFDLE1BQ1AsRUFBRSxDQUFDLFFBQVEsWUFDWCxNQUFNO0lBRVQsSUFBSSxjQUFjO01BQ2hCLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztRQUNOLFlBQVk7UUFDWixRQUFRO1FBQ1IsWUFBWSxJQUFJLE9BQU8sV0FBVztNQUNwQyxHQUNDLEVBQUUsQ0FBQyxZQUFZLFVBQ2YsRUFBRSxDQUFDLG9CQUFvQixhQUFhLEVBQUU7TUFFekMsSUFBSSxhQUFhO1FBQ2YsUUFBUSxLQUFLLENBQUMsdUJBQXVCO1FBQ3JDLE1BQU0sSUFBSSxNQUFNO01BQ2xCO0lBQ0Y7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLHlDQUF5QyxFQUFFLFNBQVMsQ0FBQztJQUVsRSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxjQUFjO01BQ2QsU0FBUztJQUNYLElBQ0E7TUFDRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQ2hFO0VBRUosRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFFMUMsbURBQW1EO0lBQ25ELElBQUksU0FBUztNQUNYLElBQUk7UUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO1FBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztRQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO1FBRTNDLE1BQU0sRUFBRSxNQUFNLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGtCQUNMLE1BQU0sQ0FBQyxNQUNQLEVBQUUsQ0FBQyxRQUFRLFlBQ1gsTUFBTTtRQUVULElBQUksY0FBYztVQUNoQixNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztZQUNOLFFBQVE7WUFDUixZQUFZLElBQUksT0FBTyxXQUFXO1VBQ3BDLEdBQ0MsRUFBRSxDQUFDLFlBQVksU0FDZixFQUFFLENBQUMsb0JBQW9CLGFBQWEsRUFBRTtRQUMzQztNQUNGLEVBQUUsT0FBTyxHQUFHO1FBQ1YsUUFBUSxLQUFLLENBQUMsa0NBQWtDO01BQ2xEO0lBQ0Y7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ2xELElBQ0E7TUFDRSxRQUFRO01BQ1IsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUNoRTtFQUVKO0FBQ0YifQ==
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Timeweb Agent ID for lyrics/prompt generation
const AGENT_ACCESS_ID = '0846d064-4950-4d79-a54c-62ba315cdb34';
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // Authenticate user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "Необходима авторизация"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
    const token = authHeader.replace("Bearer ", "");
    const { data, error: authError } = await supabase.auth.getClaims(token);
    if (authError || !data?.claims?.sub) {
      console.error("Auth error:", authError);
      return new Response(JSON.stringify({
        error: "Неверный токен авторизации"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const user_id = data.claims.sub;
    const { mode, lyrics, style, theme, userRequest } = await req.json();
    console.log("Timeweb lyrics request:", {
      mode,
      user_id,
      hasLyrics: !!lyrics,
      style,
      theme
    });
    const TIMEWEB_TOKEN = Deno.env.get("TIMEWEB_AGENT_TOKEN");
    if (!TIMEWEB_TOKEN) {
      throw new Error("TIMEWEB_AGENT_TOKEN not configured");
    }
    // Get service price (use existing generate_lyrics service)
    const { data: service } = await supabase.from("addon_services").select("price_rub").eq("name", "generate_lyrics").maybeSingle();
    const price = service?.price_rub || 5;
    // Check user balance
    const { data: profile } = await supabase.from("profiles").select("balance").eq("user_id", user_id).maybeSingle();
    if (!profile || (profile.balance || 0) < price) {
      return new Response(JSON.stringify({
        error: "Недостаточно средств на балансе"
      }), {
        status: 402,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Deduct balance
    const newBalance = (profile.balance || 0) - price;
    const { error: balanceError } = await supabase.from("profiles").update({
      balance: newBalance
    }).eq("user_id", user_id);
    if (balanceError) {
      throw new Error("Ошибка списания баланса");
    }
    // Log transaction
    await supabase.from("balance_transactions").insert({
      user_id: user_id,
      amount: -price,
      balance_after: newBalance,
      type: "lyrics_gen",
      description: `Генерация текста (${mode})`,
      metadata: {
        mode
      }
    });
    // Build prompt based on mode
    let systemPrompt;
    let userPrompt;
    if (mode === "improve") {
      systemPrompt = `Ты профессиональный поэт-песенник. Твоя задача — улучшить текст песни, сохраняя его смысл и настроение.

Правила:
- Улучши рифмы, ритм и звучание
- Сохрани оригинальную идею и эмоции
- Исправь грамматические ошибки
- Сделай текст более выразительным и поэтичным
- НЕ добавляй теги разметки типа [Verse], [Chorus] — только чистый текст
- Отвечай ТОЛЬКО текстом песни, без пояснений`;
      userPrompt = `Улучши этот текст песни${style ? ` в стиле ${style}` : ""}:

${lyrics}`;
    } else if (mode === "markup") {
      // Режим разметки текста тегами
      systemPrompt = `Ты эксперт по разметке текстов песен для AI-генераторов музыки (Suno, Udio).

Твоя задача — добавить структурную разметку к тексту песни.

Правила:
1. УЧИТЫВАЙ ПОЖЕЛАНИЕ ПОЛЬЗОВАТЕЛЯ — на основе его пожеланий разработай разметку
2. Используй теги структуры: [Verse], [Chorus], [Bridge], [Outro], [Intro], [Pre-Chorus], [Hook]
3. Добавляй теги вокала при необходимости: [Male Vocal], [Female Vocal], [Duet], [Whisper], [Shout]
4. Добавляй теги настроения и динамики: [Soft], [Powerful], [Emotional], [Energetic]
5. Используй инструментальные указания: [Guitar Solo], [Piano Break], [Drop], [Build-up]
6. Сохраняй оригинальный текст без изменений — только добавляй теги
7. Теги ставь в начале строки или секции
8. ОБЯЗАТЕЛЬНО добавляй секцию [Outro] в конце песни с инструкциями затухания/окончания
9. Отвечай ТОЛЬКО размеченным текстом, без пояснений

ВАЖНО — ОКОНЧАНИЕ ПЕСНИ:
После последнего текстового блока ВСЕГДА добавляй блок [Outro] с описанием того, как песня заканчивается.
Используй комбинацию тегов и ремарок в скобках для создания атмосферного завершения.
Если пользователь указал своё видение окончания — следуй ему. Если нет — создай подходящее по настроению.

Пример окончания:
[Outro]
[Bassline filtering out]
[Minimalist percussion and pads]
(Breathy whisper: повтор ключевой фразы...)
[Soft synth swell]
[Fade out]
[End]

Примеры тегов:
[Verse 1]
[Chorus] [Powerful, layered harmonies]
[Bridge] [Soft, piano only]
[Outro] [Fade out]`;
      const userWish = userRequest?.trim() ? `\nПожелание пользователя: ${userRequest}` : "";
      userPrompt = `Разметь этот текст песни тегами структуры:${userWish}

${lyrics}`;
    } else if (mode === "create_prompt") {
      systemPrompt = `Ты эксперт по созданию музыкальных промптов для AI-генераторов музыки (Suno, Udio).

Твоя задача — проанализировать текст песни и создать оптимальный промт стиля на АНГЛИЙСКОМ языке.

Правила:
- Определи жанр, настроение, темп, вокал
- Укажи инструменты и звучание
- Используй музыкальную терминологию
- Формат: теги через запятую, без скобок
- Максимум 150 символов
- Пиши ТОЛЬКО НА АНГЛИЙСКОМ
- Отвечай ТОЛЬКО промтом, без пояснений

Примеры хороших промптов:
- "dark trap, 808 bass, aggressive vocals, minor key, 140 bpm"
- "acoustic indie folk, warm vocals, fingerpicking guitar, nostalgic, autumn vibes"
- "synthwave, retro 80s, female vocals, dreamy, neon lights, pulsing synths"`;
      userPrompt = `Проанализируй этот текст песни и создай промт стиля:

${lyrics}

${style ? `Текущий стиль (учти при создании): ${style}` : ""}`;
    } else if (mode === "ideas") {
      // Generate 3 random song ideas
      systemPrompt = `Ты креативный генератор идей для песен. Твоя задача — придумать 3 оригинальные, неожиданные идеи для песен.

Для КАЖДОЙ идеи укажи:
1. **Название** — яркое, запоминающееся название песни
2. **Настроение** — эмоциональный тон (грустная, весёлая, меланхоличная, энергичная, романтичная и т.д.)
3. **Концепция** — краткое описание истории/сюжета песни (2-3 предложения)
4. **Теги стиля** — музыкальные теги для генерации на английском через запятую (например: indie pop, acoustic guitar, soft female vocals, nostalgic)
5. **Первые строки** — 4-6 строк начала текста песни

Формат ответа (строго соблюдай):

---IDEA_1---
НАЗВАНИЕ: [название]
НАСТРОЕНИЕ: [настроение]
КОНЦЕПЦИЯ: [концепция]
ТЕГИ: [теги через запятую, на английском]
ТЕКСТ:
[первые 4-6 строк]

---IDEA_2---
...

---IDEA_3---
...

Правила:
- Идеи должны быть РАЗНООБРАЗНЫМИ по жанру и настроению
- Используй неизбитые темы и метафоры
- Тексты пиши на русском языке
- Теги стиля пиши ТОЛЬКО на английском
- НЕ добавляй никаких пояснений, только идеи в заданном формате`;
      userPrompt = `Сгенерируй 3 креативные и разнообразные идеи для песен. Удиви меня!`;
    } else {
      // Generate new
      systemPrompt = `Ты профессиональный поэт-песенник. Твоя задача — написать оригинальный текст песни.

Правила:
- Создай уникальный, запоминающийся текст
- Используй чёткую структуру: куплеты, припев, бридж
- НЕ добавляй теги разметки типа [Verse], [Chorus] — только чистый текст
- Разделяй секции пустыми строками
- Рифмы должны быть естественными
- Текст должен быть эмоциональным и цепляющим
- Пиши на русском языке если не указано иное
- Отвечай ТОЛЬКО текстом песни, без пояснений`;
      const baseText = lyrics?.trim() || theme || "";
      userPrompt = baseText ? `Напиши новый текст песни${style ? ` в стиле ${style}` : ""}, вдохновляясь этой идеей/темой:

${baseText}` : `Напиши оригинальный текст песни${style ? ` в стиле ${style}` : ""}. Тема на твой выбор — что-то эмоциональное и современное.`;
    }
    // Call Timeweb Agent API
    const apiUrl = `https://agent.timeweb.cloud/api/v1/cloud-ai/agents/${AGENT_ACCESS_ID}/v1/chat/completions`;
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${TIMEWEB_TOKEN}`,
        "x-proxy-source": "lovable-app"
      },
      body: JSON.stringify({
        model: "deepseek-v3",
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: userPrompt
          }
        ],
        temperature: 0.8
      })
    });
    console.log("Timeweb response status:", response.status);
    if (!response.ok) {
      // Refund on API error
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user_id);
      const errorText = await response.text();
      console.error("Timeweb API error:", response.status, errorText);
      throw new Error("Ошибка API Timeweb");
    }
    const result = await response.json();
    console.log("Timeweb response received");
    const generatedContent = result.choices?.[0]?.message?.content;
    if (!generatedContent) {
      // Refund on empty result
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user_id);
      throw new Error("Не удалось сгенерировать текст");
    }
    // Save to history (only for lyrics modes, not markup or create_prompt)
    if (mode !== "create_prompt" && mode !== "markup") {
      await supabase.from("generated_lyrics").insert({
        user_id: user_id,
        prompt: mode === "improve" ? `[IMPROVE] ${style || ""}` : `[GENERATE] ${theme || style || ""}`,
        lyrics: generatedContent,
        title: null
      });
    }
    // Different response based on mode
    if (mode === "create_prompt") {
      return new Response(JSON.stringify({
        success: true,
        stylePrompt: generatedContent.trim(),
        mode,
        message: "Промт создан!"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (mode === "markup") {
      return new Response(JSON.stringify({
        success: true,
        lyrics: generatedContent.trim(),
        mode,
        message: "Текст размечен!"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (mode === "ideas") {
      // Parse ideas from response
      const ideas = [];
      const ideaBlocks = generatedContent.split(/---IDEA_\d+---/).filter((b)=>b.trim());
      for (const block of ideaBlocks){
        const titleMatch = block.match(/НАЗВАНИЕ:\s*(.+)/i);
        const moodMatch = block.match(/НАСТРОЕНИЕ:\s*(.+)/i);
        const conceptMatch = block.match(/КОНЦЕПЦИЯ:\s*(.+)/i);
        const tagsMatch = block.match(/ТЕГИ:\s*(.+)/i);
        const lyricsMatch = block.match(/ТЕКСТ:\s*([\s\S]+?)(?=(?:---IDEA_|$))/i);
        if (titleMatch) {
          ideas.push({
            title: titleMatch[1].trim(),
            mood: moodMatch?.[1]?.trim() || "",
            concept: conceptMatch?.[1]?.trim() || "",
            tags: tagsMatch?.[1]?.trim() || "",
            lyrics: lyricsMatch?.[1]?.trim() || ""
          });
        }
      }
      return new Response(JSON.stringify({
        success: true,
        ideas,
        mode,
        message: "Идеи сгенерированы!"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    return new Response(JSON.stringify({
      success: true,
      lyrics: generatedContent.trim(),
      mode,
      message: mode === "improve" ? "Текст улучшен!" : "Текст сгенерирован!"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in deepseek-lyrics:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9kZWVwc2Vlay1seXJpY3MvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTY4LjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG50eXBlIE1vZGUgPSBcImltcHJvdmVcIiB8IFwiZ2VuZXJhdGVcIiB8IFwiY3JlYXRlX3Byb21wdFwiIHwgXCJtYXJrdXBcIiB8IFwiaWRlYXNcIjtcblxuLy8gVGltZXdlYiBBZ2VudCBJRCBmb3IgbHlyaWNzL3Byb21wdCBnZW5lcmF0aW9uXG5jb25zdCBBR0VOVF9BQ0NFU1NfSUQgPSAnMDg0NmQwNjQtNDk1MC00ZDc5LWE1NGMtNjJiYTMxNWNkYjM0Jztcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIC8vIEF1dGhlbnRpY2F0ZSB1c2VyXG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyPy5zdGFydHNXaXRoKFwiQmVhcmVyIFwiKSkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQndC10L7QsdGF0L7QtNC40LzQsCDQsNCy0YLQvtGA0LjQt9Cw0YbQuNGPXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSEsXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpIVxuICAgICk7XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgY29uc3QgeyBkYXRhLCBlcnJvcjogYXV0aEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldENsYWltcyh0b2tlbik7XG4gICAgXG4gICAgaWYgKGF1dGhFcnJvciB8fCAhZGF0YT8uY2xhaW1zPy5zdWIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJBdXRoIGVycm9yOlwiLCBhdXRoRXJyb3IpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQndC10LLQtdGA0L3Ri9C5INGC0L7QutC10L0g0LDQstGC0L7RgNC40LfQsNGG0LjQuFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgdXNlcl9pZCA9IGRhdGEuY2xhaW1zLnN1YiBhcyBzdHJpbmc7XG4gICAgY29uc3QgeyBtb2RlLCBseXJpY3MsIHN0eWxlLCB0aGVtZSwgdXNlclJlcXVlc3QgfSA9IGF3YWl0IHJlcS5qc29uKCkgYXMge1xuICAgICAgbW9kZTogTW9kZTtcbiAgICAgIGx5cmljcz86IHN0cmluZztcbiAgICAgIHN0eWxlPzogc3RyaW5nO1xuICAgICAgdGhlbWU/OiBzdHJpbmc7XG4gICAgICB1c2VyUmVxdWVzdD86IHN0cmluZzsgLy8g0J/QvtC20LXQu9Cw0L3QuNC1INC/0L7Qu9GM0LfQvtCy0LDRgtC10LvRjyDQtNC70Y8g0YDQsNC30LzQtdGC0LrQuFxuICAgIH07XG5cbiAgICBjb25zb2xlLmxvZyhcIlRpbWV3ZWIgbHlyaWNzIHJlcXVlc3Q6XCIsIHsgbW9kZSwgdXNlcl9pZCwgaGFzTHlyaWNzOiAhIWx5cmljcywgc3R5bGUsIHRoZW1lIH0pO1xuXG4gICAgY29uc3QgVElNRVdFQl9UT0tFTiA9IERlbm8uZW52LmdldChcIlRJTUVXRUJfQUdFTlRfVE9LRU5cIik7XG4gICAgaWYgKCFUSU1FV0VCX1RPS0VOKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUSU1FV0VCX0FHRU5UX1RPS0VOIG5vdCBjb25maWd1cmVkXCIpO1xuICAgIH1cblxuICAgIC8vIEdldCBzZXJ2aWNlIHByaWNlICh1c2UgZXhpc3RpbmcgZ2VuZXJhdGVfbHlyaWNzIHNlcnZpY2UpXG4gICAgY29uc3QgeyBkYXRhOiBzZXJ2aWNlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJhZGRvbl9zZXJ2aWNlc1wiKVxuICAgICAgLnNlbGVjdChcInByaWNlX3J1YlwiKVxuICAgICAgLmVxKFwibmFtZVwiLCBcImdlbmVyYXRlX2x5cmljc1wiKVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICBjb25zdCBwcmljZSA9IHNlcnZpY2U/LnByaWNlX3J1YiB8fCA1O1xuXG4gICAgLy8gQ2hlY2sgdXNlciBiYWxhbmNlXG4gICAgY29uc3QgeyBkYXRhOiBwcm9maWxlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgLnNlbGVjdChcImJhbGFuY2VcIilcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcl9pZClcbiAgICAgIC5tYXliZVNpbmdsZSgpO1xuXG4gICAgaWYgKCFwcm9maWxlIHx8IChwcm9maWxlLmJhbGFuY2UgfHwgMCkgPCBwcmljZSkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQndC10LTQvtGB0YLQsNGC0L7Rh9C90L4g0YHRgNC10LTRgdGC0LIg0L3QsCDQsdCw0LvQsNC90YHQtVwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAyLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gRGVkdWN0IGJhbGFuY2VcbiAgICBjb25zdCBuZXdCYWxhbmNlID0gKHByb2ZpbGUuYmFsYW5jZSB8fCAwKSAtIHByaWNlO1xuICAgIGNvbnN0IHsgZXJyb3I6IGJhbGFuY2VFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBuZXdCYWxhbmNlIH0pXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJfaWQpO1xuXG4gICAgaWYgKGJhbGFuY2VFcnJvcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwi0J7RiNC40LHQutCwINGB0L/QuNGB0LDQvdC40Y8g0LHQsNC70LDQvdGB0LBcIik7XG4gICAgfVxuXG4gICAgLy8gTG9nIHRyYW5zYWN0aW9uXG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcImJhbGFuY2VfdHJhbnNhY3Rpb25zXCIpLmluc2VydCh7XG4gICAgICB1c2VyX2lkOiB1c2VyX2lkLFxuICAgICAgYW1vdW50OiAtcHJpY2UsXG4gICAgICBiYWxhbmNlX2FmdGVyOiBuZXdCYWxhbmNlLFxuICAgICAgdHlwZTogXCJseXJpY3NfZ2VuXCIsXG4gICAgICBkZXNjcmlwdGlvbjogYNCT0LXQvdC10YDQsNGG0LjRjyDRgtC10LrRgdGC0LAgKCR7bW9kZX0pYCxcbiAgICAgIG1ldGFkYXRhOiB7IG1vZGUgfSxcbiAgICB9KTtcblxuICAgIC8vIEJ1aWxkIHByb21wdCBiYXNlZCBvbiBtb2RlXG4gICAgbGV0IHN5c3RlbVByb21wdDogc3RyaW5nO1xuICAgIGxldCB1c2VyUHJvbXB0OiBzdHJpbmc7XG5cbiAgICBpZiAobW9kZSA9PT0gXCJpbXByb3ZlXCIpIHtcbiAgICAgIHN5c3RlbVByb21wdCA9IGDQotGLINC/0YDQvtGE0LXRgdGB0LjQvtC90LDQu9GM0L3Ri9C5INC/0L7RjdGCLdC/0LXRgdC10L3QvdC40LouINCi0LLQvtGPINC30LDQtNCw0YfQsCDigJQg0YPQu9GD0YfRiNC40YLRjCDRgtC10LrRgdGCINC/0LXRgdC90LgsINGB0L7RhdGA0LDQvdGP0Y8g0LXQs9C+INGB0LzRi9GB0Lsg0Lgg0L3QsNGB0YLRgNC+0LXQvdC40LUuXG5cbtCf0YDQsNCy0LjQu9CwOlxuLSDQo9C70YPRh9GI0Lgg0YDQuNGE0LzRiywg0YDQuNGC0Lwg0Lgg0LfQstGD0YfQsNC90LjQtVxuLSDQodC+0YXRgNCw0L3QuCDQvtGA0LjQs9C40L3QsNC70YzQvdGD0Y4g0LjQtNC10Y4g0Lgg0Y3QvNC+0YbQuNC4XG4tINCY0YHQv9GA0LDQstGMINCz0YDQsNC80LzQsNGC0LjRh9C10YHQutC40LUg0L7RiNC40LHQutC4XG4tINCh0LTQtdC70LDQuSDRgtC10LrRgdGCINCx0L7Qu9C10LUg0LLRi9GA0LDQt9C40YLQtdC70YzQvdGL0Lwg0Lgg0L/QvtGN0YLQuNGH0L3Ri9C8XG4tINCd0JUg0LTQvtCx0LDQstC70Y/QuSDRgtC10LPQuCDRgNCw0LfQvNC10YLQutC4INGC0LjQv9CwIFtWZXJzZV0sIFtDaG9ydXNdIOKAlCDRgtC+0LvRjNC60L4g0YfQuNGB0YLRi9C5INGC0LXQutGB0YJcbi0g0J7RgtCy0LXRh9Cw0Lkg0KLQntCb0KzQmtCeINGC0LXQutGB0YLQvtC8INC/0LXRgdC90LgsINCx0LXQtyDQv9C+0Y/RgdC90LXQvdC40LlgO1xuXG4gICAgICB1c2VyUHJvbXB0ID0gYNCj0LvRg9GH0YjQuCDRjdGC0L7RgiDRgtC10LrRgdGCINC/0LXRgdC90Lgke3N0eWxlID8gYCDQsiDRgdGC0LjQu9C1ICR7c3R5bGV9YCA6IFwiXCJ9OlxuXG4ke2x5cmljc31gO1xuICAgIH0gZWxzZSBpZiAobW9kZSA9PT0gXCJtYXJrdXBcIikge1xuICAgICAgLy8g0KDQtdC20LjQvCDRgNCw0LfQvNC10YLQutC4INGC0LXQutGB0YLQsCDRgtC10LPQsNC80LhcbiAgICAgIHN5c3RlbVByb21wdCA9IGDQotGLINGN0LrRgdC/0LXRgNGCINC/0L4g0YDQsNC30LzQtdGC0LrQtSDRgtC10LrRgdGC0L7QsiDQv9C10YHQtdC9INC00LvRjyBBSS3Qs9C10L3QtdGA0LDRgtC+0YDQvtCyINC80YPQt9GL0LrQuCAoU3VubywgVWRpbykuXG5cbtCi0LLQvtGPINC30LDQtNCw0YfQsCDigJQg0LTQvtCx0LDQstC40YLRjCDRgdGC0YDRg9C60YLRg9GA0L3Rg9GOINGA0LDQt9C80LXRgtC60YMg0Log0YLQtdC60YHRgtGDINC/0LXRgdC90LguXG5cbtCf0YDQsNCy0LjQu9CwOlxuMS4g0KPQp9CY0KLQq9CS0JDQmSDQn9Ce0JbQldCb0JDQndCY0JUg0J/QntCb0KzQl9Ce0JLQkNCi0JXQm9CvIOKAlCDQvdCwINC+0YHQvdC+0LLQtSDQtdCz0L4g0L/QvtC20LXQu9Cw0L3QuNC5INGA0LDQt9GA0LDQsdC+0YLQsNC5INGA0LDQt9C80LXRgtC60YNcbjIuINCY0YHQv9C+0LvRjNC30YPQuSDRgtC10LPQuCDRgdGC0YDRg9C60YLRg9GA0Ys6IFtWZXJzZV0sIFtDaG9ydXNdLCBbQnJpZGdlXSwgW091dHJvXSwgW0ludHJvXSwgW1ByZS1DaG9ydXNdLCBbSG9va11cbjMuINCU0L7QsdCw0LLQu9GP0Lkg0YLQtdCz0Lgg0LLQvtC60LDQu9CwINC/0YDQuCDQvdC10L7QsdGF0L7QtNC40LzQvtGB0YLQuDogW01hbGUgVm9jYWxdLCBbRmVtYWxlIFZvY2FsXSwgW0R1ZXRdLCBbV2hpc3Blcl0sIFtTaG91dF1cbjQuINCU0L7QsdCw0LLQu9GP0Lkg0YLQtdCz0Lgg0L3QsNGB0YLRgNC+0LXQvdC40Y8g0Lgg0LTQuNC90LDQvNC40LrQuDogW1NvZnRdLCBbUG93ZXJmdWxdLCBbRW1vdGlvbmFsXSwgW0VuZXJnZXRpY11cbjUuINCY0YHQv9C+0LvRjNC30YPQuSDQuNC90YHRgtGA0YPQvNC10L3RgtCw0LvRjNC90YvQtSDRg9C60LDQt9Cw0L3QuNGPOiBbR3VpdGFyIFNvbG9dLCBbUGlhbm8gQnJlYWtdLCBbRHJvcF0sIFtCdWlsZC11cF1cbjYuINCh0L7RhdGA0LDQvdGP0Lkg0L7RgNC40LPQuNC90LDQu9GM0L3Ri9C5INGC0LXQutGB0YIg0LHQtdC3INC40LfQvNC10L3QtdC90LjQuSDigJQg0YLQvtC70YzQutC+INC00L7QsdCw0LLQu9GP0Lkg0YLQtdCz0LhcbjcuINCi0LXQs9C4INGB0YLQsNCy0Ywg0LIg0L3QsNGH0LDQu9C1INGB0YLRgNC+0LrQuCDQuNC70Lgg0YHQtdC60YbQuNC4XG44LiDQntCR0K/Ql9CQ0KLQldCb0KzQndCeINC00L7QsdCw0LLQu9GP0Lkg0YHQtdC60YbQuNGOIFtPdXRyb10g0LIg0LrQvtC90YbQtSDQv9C10YHQvdC4INGBINC40L3RgdGC0YDRg9C60YbQuNGP0LzQuCDQt9Cw0YLRg9GF0LDQvdC40Y8v0L7QutC+0L3Rh9Cw0L3QuNGPXG45LiDQntGC0LLQtdGH0LDQuSDQotCe0JvQrNCa0J4g0YDQsNC30LzQtdGH0LXQvdC90YvQvCDRgtC10LrRgdGC0L7QvCwg0LHQtdC3INC/0L7Rj9GB0L3QtdC90LjQuVxuXG7QktCQ0JbQndCeIOKAlCDQntCa0J7QndCn0JDQndCY0JUg0J/QldCh0J3QmDpcbtCf0L7RgdC70LUg0L/QvtGB0LvQtdC00L3QtdCz0L4g0YLQtdC60YHRgtC+0LLQvtCz0L4g0LHQu9C+0LrQsCDQktCh0JXQk9CU0JAg0LTQvtCx0LDQstC70Y/QuSDQsdC70L7QuiBbT3V0cm9dINGBINC+0L/QuNGB0LDQvdC40LXQvCDRgtC+0LPQviwg0LrQsNC6INC/0LXRgdC90Y8g0LfQsNC60LDQvdGH0LjQstCw0LXRgtGB0Y8uXG7QmNGB0L/QvtC70YzQt9GD0Lkg0LrQvtC80LHQuNC90LDRhtC40Y4g0YLQtdCz0L7QsiDQuCDRgNC10LzQsNGA0L7QuiDQsiDRgdC60L7QsdC60LDRhSDQtNC70Y8g0YHQvtC30LTQsNC90LjRjyDQsNGC0LzQvtGB0YTQtdGA0L3QvtCz0L4g0LfQsNCy0LXRgNGI0LXQvdC40Y8uXG7QldGB0LvQuCDQv9C+0LvRjNC30L7QstCw0YLQtdC70Ywg0YPQutCw0LfQsNC7INGB0LLQvtGRINCy0LjQtNC10L3QuNC1INC+0LrQvtC90YfQsNC90LjRjyDigJQg0YHQu9C10LTRg9C5INC10LzRgy4g0JXRgdC70Lgg0L3QtdGCIOKAlCDRgdC+0LfQtNCw0Lkg0L/QvtC00YXQvtC00Y/RidC10LUg0L/QviDQvdCw0YHRgtGA0L7QtdC90LjRji5cblxu0J/RgNC40LzQtdGAINC+0LrQvtC90YfQsNC90LjRjzpcbltPdXRyb11cbltCYXNzbGluZSBmaWx0ZXJpbmcgb3V0XVxuW01pbmltYWxpc3QgcGVyY3Vzc2lvbiBhbmQgcGFkc11cbihCcmVhdGh5IHdoaXNwZXI6INC/0L7QstGC0L7RgCDQutC70Y7Rh9C10LLQvtC5INGE0YDQsNC30YsuLi4pXG5bU29mdCBzeW50aCBzd2VsbF1cbltGYWRlIG91dF1cbltFbmRdXG5cbtCf0YDQuNC80LXRgNGLINGC0LXQs9C+0LI6XG5bVmVyc2UgMV1cbltDaG9ydXNdIFtQb3dlcmZ1bCwgbGF5ZXJlZCBoYXJtb25pZXNdXG5bQnJpZGdlXSBbU29mdCwgcGlhbm8gb25seV1cbltPdXRyb10gW0ZhZGUgb3V0XWA7XG5cbiAgICAgIGNvbnN0IHVzZXJXaXNoID0gdXNlclJlcXVlc3Q/LnRyaW0oKSA/IGBcXG7Qn9C+0LbQtdC70LDQvdC40LUg0L/QvtC70YzQt9C+0LLQsNGC0LXQu9GPOiAke3VzZXJSZXF1ZXN0fWAgOiBcIlwiO1xuICAgICAgdXNlclByb21wdCA9IGDQoNCw0LfQvNC10YLRjCDRjdGC0L7RgiDRgtC10LrRgdGCINC/0LXRgdC90Lgg0YLQtdCz0LDQvNC4INGB0YLRgNGD0LrRgtGD0YDRizoke3VzZXJXaXNofVxuXG4ke2x5cmljc31gO1xuICAgIH0gZWxzZSBpZiAobW9kZSA9PT0gXCJjcmVhdGVfcHJvbXB0XCIpIHtcbiAgICAgIHN5c3RlbVByb21wdCA9IGDQotGLINGN0LrRgdC/0LXRgNGCINC/0L4g0YHQvtC30LTQsNC90LjRjiDQvNGD0LfRi9C60LDQu9GM0L3Ri9GFINC/0YDQvtC80L/RgtC+0LIg0LTQu9GPIEFJLdCz0LXQvdC10YDQsNGC0L7RgNC+0LIg0LzRg9C30YvQutC4IChTdW5vLCBVZGlvKS5cblxu0KLQstC+0Y8g0LfQsNC00LDRh9CwIOKAlCDQv9GA0L7QsNC90LDQu9C40LfQuNGA0L7QstCw0YLRjCDRgtC10LrRgdGCINC/0LXRgdC90Lgg0Lgg0YHQvtC30LTQsNGC0Ywg0L7Qv9GC0LjQvNCw0LvRjNC90YvQuSDQv9GA0L7QvNGCINGB0YLQuNC70Y8g0L3QsCDQkNCd0JPQm9CY0JnQodCa0J7QnCDRj9C30YvQutC1LlxuXG7Qn9GA0LDQstC40LvQsDpcbi0g0J7Qv9GA0LXQtNC10LvQuCDQttCw0L3RgCwg0L3QsNGB0YLRgNC+0LXQvdC40LUsINGC0LXQvNC/LCDQstC+0LrQsNC7XG4tINCj0LrQsNC20Lgg0LjQvdGB0YLRgNGD0LzQtdC90YLRiyDQuCDQt9Cy0YPRh9Cw0L3QuNC1XG4tINCY0YHQv9C+0LvRjNC30YPQuSDQvNGD0LfRi9C60LDQu9GM0L3Rg9GOINGC0LXRgNC80LjQvdC+0LvQvtCz0LjRjlxuLSDQpNC+0YDQvNCw0YI6INGC0LXQs9C4INGH0LXRgNC10Lcg0LfQsNC/0Y/RgtGD0Y4sINCx0LXQtyDRgdC60L7QsdC+0Lpcbi0g0JzQsNC60YHQuNC80YPQvCAxNTAg0YHQuNC80LLQvtC70L7QslxuLSDQn9C40YjQuCDQotCe0JvQrNCa0J4g0J3QkCDQkNCd0JPQm9CY0JnQodCa0J7QnFxuLSDQntGC0LLQtdGH0LDQuSDQotCe0JvQrNCa0J4g0L/RgNC+0LzRgtC+0LwsINCx0LXQtyDQv9C+0Y/RgdC90LXQvdC40Llcblxu0J/RgNC40LzQtdGA0Ysg0YXQvtGA0L7RiNC40YUg0L/RgNC+0LzQv9GC0L7Qsjpcbi0gXCJkYXJrIHRyYXAsIDgwOCBiYXNzLCBhZ2dyZXNzaXZlIHZvY2FscywgbWlub3Iga2V5LCAxNDAgYnBtXCJcbi0gXCJhY291c3RpYyBpbmRpZSBmb2xrLCB3YXJtIHZvY2FscywgZmluZ2VycGlja2luZyBndWl0YXIsIG5vc3RhbGdpYywgYXV0dW1uIHZpYmVzXCJcbi0gXCJzeW50aHdhdmUsIHJldHJvIDgwcywgZmVtYWxlIHZvY2FscywgZHJlYW15LCBuZW9uIGxpZ2h0cywgcHVsc2luZyBzeW50aHNcImA7XG5cbiAgICAgIHVzZXJQcm9tcHQgPSBg0J/RgNC+0LDQvdCw0LvQuNC30LjRgNGD0Lkg0Y3RgtC+0YIg0YLQtdC60YHRgiDQv9C10YHQvdC4INC4INGB0L7Qt9C00LDQuSDQv9GA0L7QvNGCINGB0YLQuNC70Y86XG5cbiR7bHlyaWNzfVxuXG4ke3N0eWxlID8gYNCi0LXQutGD0YnQuNC5INGB0YLQuNC70YwgKNGD0YfRgtC4INC/0YDQuCDRgdC+0LfQtNCw0L3QuNC4KTogJHtzdHlsZX1gIDogXCJcIn1gO1xuICAgIH0gZWxzZSBpZiAobW9kZSA9PT0gXCJpZGVhc1wiKSB7XG4gICAgICAvLyBHZW5lcmF0ZSAzIHJhbmRvbSBzb25nIGlkZWFzXG4gICAgICBzeXN0ZW1Qcm9tcHQgPSBg0KLRiyDQutGA0LXQsNGC0LjQstC90YvQuSDQs9C10L3QtdGA0LDRgtC+0YAg0LjQtNC10Lkg0LTQu9GPINC/0LXRgdC10L0uINCi0LLQvtGPINC30LDQtNCw0YfQsCDigJQg0L/RgNC40LTRg9C80LDRgtGMIDMg0L7RgNC40LPQuNC90LDQu9GM0L3Ri9C1LCDQvdC10L7QttC40LTQsNC90L3Ri9C1INC40LTQtdC4INC00LvRjyDQv9C10YHQtdC9LlxuXG7QlNC70Y8g0JrQkNCW0JTQntCZINC40LTQtdC4INGD0LrQsNC20Lg6XG4xLiAqKtCd0LDQt9Cy0LDQvdC40LUqKiDigJQg0Y/RgNC60L7QtSwg0LfQsNC/0L7QvNC40L3QsNGO0YnQtdC10YHRjyDQvdCw0LfQstCw0L3QuNC1INC/0LXRgdC90LhcbjIuICoq0J3QsNGB0YLRgNC+0LXQvdC40LUqKiDigJQg0Y3QvNC+0YbQuNC+0L3QsNC70YzQvdGL0Lkg0YLQvtC9ICjQs9GA0YPRgdGC0L3QsNGPLCDQstC10YHRkdC70LDRjywg0LzQtdC70LDQvdGF0L7Qu9C40YfQvdCw0Y8sINGN0L3QtdGA0LPQuNGH0L3QsNGPLCDRgNC+0LzQsNC90YLQuNGH0L3QsNGPINC4INGCLtC0LilcbjMuICoq0JrQvtC90YbQtdC/0YbQuNGPKiog4oCUINC60YDQsNGC0LrQvtC1INC+0L/QuNGB0LDQvdC40LUg0LjRgdGC0L7RgNC40Lgv0YHRjtC20LXRgtCwINC/0LXRgdC90LggKDItMyDQv9GA0LXQtNC70L7QttC10L3QuNGPKVxuNC4gKirQotC10LPQuCDRgdGC0LjQu9GPKiog4oCUINC80YPQt9GL0LrQsNC70YzQvdGL0LUg0YLQtdCz0Lgg0LTQu9GPINCz0LXQvdC10YDQsNGG0LjQuCDQvdCwINCw0L3Qs9C70LjQudGB0LrQvtC8INGH0LXRgNC10Lcg0LfQsNC/0Y/RgtGD0Y4gKNC90LDQv9GA0LjQvNC10YA6IGluZGllIHBvcCwgYWNvdXN0aWMgZ3VpdGFyLCBzb2Z0IGZlbWFsZSB2b2NhbHMsIG5vc3RhbGdpYylcbjUuICoq0J/QtdGA0LLRi9C1INGB0YLRgNC+0LrQuCoqIOKAlCA0LTYg0YHRgtGA0L7QuiDQvdCw0YfQsNC70LAg0YLQtdC60YHRgtCwINC/0LXRgdC90Lhcblxu0KTQvtGA0LzQsNGCINC+0YLQstC10YLQsCAo0YHRgtGA0L7Qs9C+INGB0L7QsdC70Y7QtNCw0LkpOlxuXG4tLS1JREVBXzEtLS1cbtCd0JDQl9CS0JDQndCY0JU6IFvQvdCw0LfQstCw0L3QuNC1XVxu0J3QkNCh0KLQoNCe0JXQndCY0JU6IFvQvdCw0YHRgtGA0L7QtdC90LjQtV1cbtCa0J7QndCm0JXQn9Cm0JjQrzogW9C60L7QvdGG0LXQv9GG0LjRj11cbtCi0JXQk9CYOiBb0YLQtdCz0Lgg0YfQtdGA0LXQtyDQt9Cw0L/Rj9GC0YPRjiwg0L3QsCDQsNC90LPQu9C40LnRgdC60L7QvF1cbtCi0JXQmtCh0KI6XG5b0L/QtdGA0LLRi9C1IDQtNiDRgdGC0YDQvtC6XVxuXG4tLS1JREVBXzItLS1cbi4uLlxuXG4tLS1JREVBXzMtLS1cbi4uLlxuXG7Qn9GA0LDQstC40LvQsDpcbi0g0JjQtNC10Lgg0LTQvtC70LbQvdGLINCx0YvRgtGMINCg0JDQl9Cd0J7QntCR0KDQkNCX0J3Qq9Cc0Jgg0L/QviDQttCw0L3RgNGDINC4INC90LDRgdGC0YDQvtC10L3QuNGOXG4tINCY0YHQv9C+0LvRjNC30YPQuSDQvdC10LjQt9Cx0LjRgtGL0LUg0YLQtdC80Ysg0Lgg0LzQtdGC0LDRhNC+0YDRi1xuLSDQotC10LrRgdGC0Ysg0L/QuNGI0Lgg0L3QsCDRgNGD0YHRgdC60L7QvCDRj9C30YvQutC1XG4tINCi0LXQs9C4INGB0YLQuNC70Y8g0L/QuNGI0Lgg0KLQntCb0KzQmtCeINC90LAg0LDQvdCz0LvQuNC50YHQutC+0Lxcbi0g0J3QlSDQtNC+0LHQsNCy0LvRj9C5INC90LjQutCw0LrQuNGFINC/0L7Rj9GB0L3QtdC90LjQuSwg0YLQvtC70YzQutC+INC40LTQtdC4INCyINC30LDQtNCw0L3QvdC+0Lwg0YTQvtGA0LzQsNGC0LVgO1xuXG4gICAgICB1c2VyUHJvbXB0ID0gYNCh0LPQtdC90LXRgNC40YDRg9C5IDMg0LrRgNC10LDRgtC40LLQvdGL0LUg0Lgg0YDQsNC30L3QvtC+0LHRgNCw0LfQvdGL0LUg0LjQtNC10Lgg0LTQu9GPINC/0LXRgdC10L0uINCj0LTQuNCy0Lgg0LzQtdC90Y8hYDtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gR2VuZXJhdGUgbmV3XG4gICAgICBzeXN0ZW1Qcm9tcHQgPSBg0KLRiyDQv9GA0L7RhNC10YHRgdC40L7QvdCw0LvRjNC90YvQuSDQv9C+0Y3Rgi3Qv9C10YHQtdC90L3QuNC6LiDQotCy0L7RjyDQt9Cw0LTQsNGH0LAg4oCUINC90LDQv9C40YHQsNGC0Ywg0L7RgNC40LPQuNC90LDQu9GM0L3Ri9C5INGC0LXQutGB0YIg0L/QtdGB0L3QuC5cblxu0J/RgNCw0LLQuNC70LA6XG4tINCh0L7Qt9C00LDQuSDRg9C90LjQutCw0LvRjNC90YvQuSwg0LfQsNC/0L7QvNC40L3QsNGO0YnQuNC50YHRjyDRgtC10LrRgdGCXG4tINCY0YHQv9C+0LvRjNC30YPQuSDRh9GR0YLQutGD0Y4g0YHRgtGA0YPQutGC0YPRgNGDOiDQutGD0L/Qu9C10YLRiywg0L/RgNC40L/QtdCyLCDQsdGA0LjQtNC2XG4tINCd0JUg0LTQvtCx0LDQstC70Y/QuSDRgtC10LPQuCDRgNCw0LfQvNC10YLQutC4INGC0LjQv9CwIFtWZXJzZV0sIFtDaG9ydXNdIOKAlCDRgtC+0LvRjNC60L4g0YfQuNGB0YLRi9C5INGC0LXQutGB0YJcbi0g0KDQsNC30LTQtdC70Y/QuSDRgdC10LrRhtC40Lgg0L/Rg9GB0YLRi9C80Lgg0YHRgtGA0L7QutCw0LzQuFxuLSDQoNC40YTQvNGLINC00L7Qu9C20L3RiyDQsdGL0YLRjCDQtdGB0YLQtdGB0YLQstC10L3QvdGL0LzQuFxuLSDQotC10LrRgdGCINC00L7Qu9C20LXQvSDQsdGL0YLRjCDRjdC80L7RhtC40L7QvdCw0LvRjNC90YvQvCDQuCDRhtC10L/Qu9GP0Y7RidC40Lxcbi0g0J/QuNGI0Lgg0L3QsCDRgNGD0YHRgdC60L7QvCDRj9C30YvQutC1INC10YHQu9C4INC90LUg0YPQutCw0LfQsNC90L4g0LjQvdC+0LVcbi0g0J7RgtCy0LXRh9Cw0Lkg0KLQntCb0KzQmtCeINGC0LXQutGB0YLQvtC8INC/0LXRgdC90LgsINCx0LXQtyDQv9C+0Y/RgdC90LXQvdC40LlgO1xuXG4gICAgICBjb25zdCBiYXNlVGV4dCA9IGx5cmljcz8udHJpbSgpIHx8IHRoZW1lIHx8IFwiXCI7XG4gICAgICB1c2VyUHJvbXB0ID0gYmFzZVRleHQgXG4gICAgICAgID8gYNCd0LDQv9C40YjQuCDQvdC+0LLRi9C5INGC0LXQutGB0YIg0L/QtdGB0L3QuCR7c3R5bGUgPyBgINCyINGB0YLQuNC70LUgJHtzdHlsZX1gIDogXCJcIn0sINCy0LTQvtGF0L3QvtCy0LvRj9GP0YHRjCDRjdGC0L7QuSDQuNC00LXQtdC5L9GC0LXQvNC+0Lk6XG5cbiR7YmFzZVRleHR9YFxuICAgICAgICA6IGDQndCw0L/QuNGI0Lgg0L7RgNC40LPQuNC90LDQu9GM0L3Ri9C5INGC0LXQutGB0YIg0L/QtdGB0L3QuCR7c3R5bGUgPyBgINCyINGB0YLQuNC70LUgJHtzdHlsZX1gIDogXCJcIn0uINCi0LXQvNCwINC90LAg0YLQstC+0Lkg0LLRi9Cx0L7RgCDigJQg0YfRgtC+LdGC0L4g0Y3QvNC+0YbQuNC+0L3QsNC70YzQvdC+0LUg0Lgg0YHQvtCy0YDQtdC80LXQvdC90L7QtS5gO1xuICAgIH1cblxuICAgIC8vIENhbGwgVGltZXdlYiBBZ2VudCBBUElcbiAgICBjb25zdCBhcGlVcmwgPSBgaHR0cHM6Ly9hZ2VudC50aW1ld2ViLmNsb3VkL2FwaS92MS9jbG91ZC1haS9hZ2VudHMvJHtBR0VOVF9BQ0NFU1NfSUR9L3YxL2NoYXQvY29tcGxldGlvbnNgO1xuICAgIFxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYXBpVXJsLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtUSU1FV0VCX1RPS0VOfWAsXG4gICAgICAgIFwieC1wcm94eS1zb3VyY2VcIjogXCJsb3ZhYmxlLWFwcFwiLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgbW9kZWw6IFwiZGVlcHNlZWstdjNcIixcbiAgICAgICAgbWVzc2FnZXM6IFtcbiAgICAgICAgICB7IHJvbGU6IFwic3lzdGVtXCIsIGNvbnRlbnQ6IHN5c3RlbVByb21wdCB9LFxuICAgICAgICAgIHsgcm9sZTogXCJ1c2VyXCIsIGNvbnRlbnQ6IHVzZXJQcm9tcHQgfSxcbiAgICAgICAgXSxcbiAgICAgICAgdGVtcGVyYXR1cmU6IDAuOCxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgY29uc29sZS5sb2coXCJUaW1ld2ViIHJlc3BvbnNlIHN0YXR1czpcIiwgcmVzcG9uc2Uuc3RhdHVzKTtcblxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIC8vIFJlZnVuZCBvbiBBUEkgZXJyb3JcbiAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IHByb2ZpbGUuYmFsYW5jZSB9KVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJfaWQpO1xuXG4gICAgICBjb25zdCBlcnJvclRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICBjb25zb2xlLmVycm9yKFwiVGltZXdlYiBBUEkgZXJyb3I6XCIsIHJlc3BvbnNlLnN0YXR1cywgZXJyb3JUZXh0KTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCe0YjQuNCx0LrQsCBBUEkgVGltZXdlYlwiKTtcbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJUaW1ld2ViIHJlc3BvbnNlIHJlY2VpdmVkXCIpO1xuXG4gICAgY29uc3QgZ2VuZXJhdGVkQ29udGVudCA9IHJlc3VsdC5jaG9pY2VzPy5bMF0/Lm1lc3NhZ2U/LmNvbnRlbnQ7XG4gICAgXG4gICAgaWYgKCFnZW5lcmF0ZWRDb250ZW50KSB7XG4gICAgICAvLyBSZWZ1bmQgb24gZW1wdHkgcmVzdWx0XG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBwcm9maWxlLmJhbGFuY2UgfSlcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyX2lkKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0YHQs9C10L3QtdGA0LjRgNC+0LLQsNGC0Ywg0YLQtdC60YHRglwiKTtcbiAgICB9XG5cbiAgICAvLyBTYXZlIHRvIGhpc3RvcnkgKG9ubHkgZm9yIGx5cmljcyBtb2Rlcywgbm90IG1hcmt1cCBvciBjcmVhdGVfcHJvbXB0KVxuICAgIGlmIChtb2RlICE9PSBcImNyZWF0ZV9wcm9tcHRcIiAmJiBtb2RlICE9PSBcIm1hcmt1cFwiKSB7XG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcImdlbmVyYXRlZF9seXJpY3NcIilcbiAgICAgICAgLmluc2VydCh7XG4gICAgICAgICAgdXNlcl9pZDogdXNlcl9pZCxcbiAgICAgICAgICBwcm9tcHQ6IG1vZGUgPT09IFwiaW1wcm92ZVwiID8gYFtJTVBST1ZFXSAke3N0eWxlIHx8IFwiXCJ9YCA6IGBbR0VORVJBVEVdICR7dGhlbWUgfHwgc3R5bGUgfHwgXCJcIn1gLFxuICAgICAgICAgIGx5cmljczogZ2VuZXJhdGVkQ29udGVudCxcbiAgICAgICAgICB0aXRsZTogbnVsbCxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gRGlmZmVyZW50IHJlc3BvbnNlIGJhc2VkIG9uIG1vZGVcbiAgICBpZiAobW9kZSA9PT0gXCJjcmVhdGVfcHJvbXB0XCIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgICAgc3R5bGVQcm9tcHQ6IGdlbmVyYXRlZENvbnRlbnQudHJpbSgpLFxuICAgICAgICAgIG1vZGUsXG4gICAgICAgICAgbWVzc2FnZTogXCLQn9GA0L7QvNGCINGB0L7Qt9C00LDQvSFcIiBcbiAgICAgICAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGlmIChtb2RlID09PSBcIm1hcmt1cFwiKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICAgIGx5cmljczogZ2VuZXJhdGVkQ29udGVudC50cmltKCksXG4gICAgICAgICAgbW9kZSxcbiAgICAgICAgICBtZXNzYWdlOiBcItCi0LXQutGB0YIg0YDQsNC30LzQtdGH0LXQvSFcIiBcbiAgICAgICAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGlmIChtb2RlID09PSBcImlkZWFzXCIpIHtcbiAgICAgIC8vIFBhcnNlIGlkZWFzIGZyb20gcmVzcG9uc2VcbiAgICAgIGNvbnN0IGlkZWFzOiBBcnJheTx7XG4gICAgICAgIHRpdGxlOiBzdHJpbmc7XG4gICAgICAgIG1vb2Q6IHN0cmluZztcbiAgICAgICAgY29uY2VwdDogc3RyaW5nO1xuICAgICAgICB0YWdzOiBzdHJpbmc7XG4gICAgICAgIGx5cmljczogc3RyaW5nO1xuICAgICAgfT4gPSBbXTtcblxuICAgICAgY29uc3QgaWRlYUJsb2NrcyA9IGdlbmVyYXRlZENvbnRlbnQuc3BsaXQoLy0tLUlERUFfXFxkKy0tLS8pLmZpbHRlcigoYjogc3RyaW5nKSA9PiBiLnRyaW0oKSk7XG4gICAgICBcbiAgICAgIGZvciAoY29uc3QgYmxvY2sgb2YgaWRlYUJsb2Nrcykge1xuICAgICAgICBjb25zdCB0aXRsZU1hdGNoID0gYmxvY2subWF0Y2goL9Cd0JDQl9CS0JDQndCY0JU6XFxzKiguKykvaSk7XG4gICAgICAgIGNvbnN0IG1vb2RNYXRjaCA9IGJsb2NrLm1hdGNoKC/QndCQ0KHQotCg0J7QldCd0JjQlTpcXHMqKC4rKS9pKTtcbiAgICAgICAgY29uc3QgY29uY2VwdE1hdGNoID0gYmxvY2subWF0Y2goL9Ca0J7QndCm0JXQn9Cm0JjQrzpcXHMqKC4rKS9pKTtcbiAgICAgICAgY29uc3QgdGFnc01hdGNoID0gYmxvY2subWF0Y2goL9Ci0JXQk9CYOlxccyooLispL2kpO1xuICAgICAgICBjb25zdCBseXJpY3NNYXRjaCA9IGJsb2NrLm1hdGNoKC/QotCV0JrQodCiOlxccyooW1xcc1xcU10rPykoPz0oPzotLS1JREVBX3wkKSkvaSk7XG5cbiAgICAgICAgaWYgKHRpdGxlTWF0Y2gpIHtcbiAgICAgICAgICBpZGVhcy5wdXNoKHtcbiAgICAgICAgICAgIHRpdGxlOiB0aXRsZU1hdGNoWzFdLnRyaW0oKSxcbiAgICAgICAgICAgIG1vb2Q6IG1vb2RNYXRjaD8uWzFdPy50cmltKCkgfHwgXCJcIixcbiAgICAgICAgICAgIGNvbmNlcHQ6IGNvbmNlcHRNYXRjaD8uWzFdPy50cmltKCkgfHwgXCJcIixcbiAgICAgICAgICAgIHRhZ3M6IHRhZ3NNYXRjaD8uWzFdPy50cmltKCkgfHwgXCJcIixcbiAgICAgICAgICAgIGx5cmljczogbHlyaWNzTWF0Y2g/LlsxXT8udHJpbSgpIHx8IFwiXCIsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgICBpZGVhcyxcbiAgICAgICAgICBtb2RlLFxuICAgICAgICAgIG1lc3NhZ2U6IFwi0JjQtNC10Lgg0YHQs9C10L3QtdGA0LjRgNC+0LLQsNC90YshXCIgXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIGx5cmljczogZ2VuZXJhdGVkQ29udGVudC50cmltKCksXG4gICAgICAgIG1vZGUsXG4gICAgICAgIG1lc3NhZ2U6IG1vZGUgPT09IFwiaW1wcm92ZVwiID8gXCLQotC10LrRgdGCINGD0LvRg9GH0YjQtdC9IVwiIDogXCLQotC10LrRgdGCINGB0LPQtdC90LXRgNC40YDQvtCy0LDQvSFcIiBcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBkZWVwc2Vlay1seXJpY3M6XCIsIGVycm9yKTtcbiAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFJQSxnREFBZ0Q7QUFDaEQsTUFBTSxrQkFBa0I7QUFFeEIsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0Ysb0JBQW9CO0lBQ3BCLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVksV0FBVyxZQUFZO01BQ3RDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF5QixJQUNqRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFdBQVcsYUFDZixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsaUJBQ2IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBR2YsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBRWpFLElBQUksYUFBYSxDQUFDLE1BQU0sUUFBUSxLQUFLO01BQ25DLFFBQVEsS0FBSyxDQUFDLGVBQWU7TUFDN0IsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTZCLElBQ3JEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sVUFBVSxLQUFLLE1BQU0sQ0FBQyxHQUFHO0lBQy9CLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEdBQUcsTUFBTSxJQUFJLElBQUk7SUFRbEUsUUFBUSxHQUFHLENBQUMsMkJBQTJCO01BQUU7TUFBTTtNQUFTLFdBQVcsQ0FBQyxDQUFDO01BQVE7TUFBTztJQUFNO0lBRTFGLE1BQU0sZ0JBQWdCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsZUFBZTtNQUNsQixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLDJEQUEyRDtJQUMzRCxNQUFNLEVBQUUsTUFBTSxPQUFPLEVBQUUsR0FBRyxNQUFNLFNBQzdCLElBQUksQ0FBQyxrQkFDTCxNQUFNLENBQUMsYUFDUCxFQUFFLENBQUMsUUFBUSxtQkFDWCxXQUFXO0lBRWQsTUFBTSxRQUFRLFNBQVMsYUFBYTtJQUVwQyxxQkFBcUI7SUFDckIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxTQUM3QixJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxTQUNkLFdBQVc7SUFFZCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSSxPQUFPO01BQzlDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFrQyxJQUMxRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxpQkFBaUI7SUFDakIsTUFBTSxhQUFhLENBQUMsUUFBUSxPQUFPLElBQUksQ0FBQyxJQUFJO0lBQzVDLE1BQU0sRUFBRSxPQUFPLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbkMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO01BQUUsU0FBUztJQUFXLEdBQzdCLEVBQUUsQ0FBQyxXQUFXO0lBRWpCLElBQUksY0FBYztNQUNoQixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLGtCQUFrQjtJQUNsQixNQUFNLFNBQVMsSUFBSSxDQUFDLHdCQUF3QixNQUFNLENBQUM7TUFDakQsU0FBUztNQUNULFFBQVEsQ0FBQztNQUNULGVBQWU7TUFDZixNQUFNO01BQ04sYUFBYSxDQUFDLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxDQUFDO01BQ3pDLFVBQVU7UUFBRTtNQUFLO0lBQ25CO0lBRUEsNkJBQTZCO0lBQzdCLElBQUk7SUFDSixJQUFJO0lBRUosSUFBSSxTQUFTLFdBQVc7TUFDdEIsZUFBZSxDQUFDOzs7Ozs7Ozs2Q0FRdUIsQ0FBQztNQUV4QyxhQUFhLENBQUMsdUJBQXVCLEVBQUUsUUFBUSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsR0FBRyxHQUFHOztBQUU5RSxFQUFFLE9BQU8sQ0FBQztJQUNOLE9BQU8sSUFBSSxTQUFTLFVBQVU7TUFDNUIsK0JBQStCO01BQy9CLGVBQWUsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tCQWlDSixDQUFDO01BRWIsTUFBTSxXQUFXLGFBQWEsU0FBUyxDQUFDLDBCQUEwQixFQUFFLFlBQVksQ0FBQyxHQUFHO01BQ3BGLGFBQWEsQ0FBQywwQ0FBMEMsRUFBRSxTQUFTOztBQUV6RSxFQUFFLE9BQU8sQ0FBQztJQUNOLE9BQU8sSUFBSSxTQUFTLGlCQUFpQjtNQUNuQyxlQUFlLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7NEVBZ0JzRCxDQUFDO01BRXZFLGFBQWEsQ0FBQzs7QUFFcEIsRUFBRSxPQUFPOztBQUVULEVBQUUsUUFBUSxDQUFDLG1DQUFtQyxFQUFFLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUMxRCxPQUFPLElBQUksU0FBUyxTQUFTO01BQzNCLCtCQUErQjtNQUMvQixlQUFlLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsrREE4QnlDLENBQUM7TUFFMUQsYUFBYSxDQUFDLG1FQUFtRSxDQUFDO0lBQ3BGLE9BQU87TUFDTCxlQUFlO01BQ2YsZUFBZSxDQUFDOzs7Ozs7Ozs7OzZDQVV1QixDQUFDO01BRXhDLE1BQU0sV0FBVyxRQUFRLFVBQVUsU0FBUztNQUM1QyxhQUFhLFdBQ1QsQ0FBQyx3QkFBd0IsRUFBRSxRQUFRLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxHQUFHLEdBQUc7O0FBRXRFLEVBQUUsU0FBUyxDQUFDLEdBQ0YsQ0FBQywrQkFBK0IsRUFBRSxRQUFRLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxHQUFHLEdBQUcsMERBQTBELENBQUM7SUFDcEk7SUFFQSx5QkFBeUI7SUFDekIsTUFBTSxTQUFTLENBQUMsbURBQW1ELEVBQUUsZ0JBQWdCLG9CQUFvQixDQUFDO0lBRTFHLE1BQU0sV0FBVyxNQUFNLE1BQU0sUUFBUTtNQUNuQyxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO1FBQzFDLGtCQUFrQjtNQUNwQjtNQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7UUFDbkIsT0FBTztRQUNQLFVBQVU7VUFDUjtZQUFFLE1BQU07WUFBVSxTQUFTO1VBQWE7VUFDeEM7WUFBRSxNQUFNO1lBQVEsU0FBUztVQUFXO1NBQ3JDO1FBQ0QsYUFBYTtNQUNmO0lBQ0Y7SUFFQSxRQUFRLEdBQUcsQ0FBQyw0QkFBNEIsU0FBUyxNQUFNO0lBRXZELElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRTtNQUNoQixzQkFBc0I7TUFDdEIsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztRQUFFLFNBQVMsUUFBUSxPQUFPO01BQUMsR0FDbEMsRUFBRSxDQUFDLFdBQVc7TUFFakIsTUFBTSxZQUFZLE1BQU0sU0FBUyxJQUFJO01BQ3JDLFFBQVEsS0FBSyxDQUFDLHNCQUFzQixTQUFTLE1BQU0sRUFBRTtNQUNyRCxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sU0FBUyxNQUFNLFNBQVMsSUFBSTtJQUNsQyxRQUFRLEdBQUcsQ0FBQztJQUVaLE1BQU0sbUJBQW1CLE9BQU8sT0FBTyxFQUFFLENBQUMsRUFBRSxFQUFFLFNBQVM7SUFFdkQsSUFBSSxDQUFDLGtCQUFrQjtNQUNyQix5QkFBeUI7TUFDekIsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztRQUFFLFNBQVMsUUFBUSxPQUFPO01BQUMsR0FDbEMsRUFBRSxDQUFDLFdBQVc7TUFDakIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSx1RUFBdUU7SUFDdkUsSUFBSSxTQUFTLG1CQUFtQixTQUFTLFVBQVU7TUFDakQsTUFBTSxTQUNILElBQUksQ0FBQyxvQkFDTCxNQUFNLENBQUM7UUFDTixTQUFTO1FBQ1QsUUFBUSxTQUFTLFlBQVksQ0FBQyxVQUFVLEVBQUUsU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxTQUFTLFNBQVMsR0FBRyxDQUFDO1FBQzlGLFFBQVE7UUFDUixPQUFPO01BQ1Q7SUFDSjtJQUVBLG1DQUFtQztJQUNuQyxJQUFJLFNBQVMsaUJBQWlCO01BQzVCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQ2IsU0FBUztRQUNULGFBQWEsaUJBQWlCLElBQUk7UUFDbEM7UUFDQSxTQUFTO01BQ1gsSUFDQTtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLElBQUksU0FBUyxVQUFVO01BQ3JCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQ2IsU0FBUztRQUNULFFBQVEsaUJBQWlCLElBQUk7UUFDN0I7UUFDQSxTQUFTO01BQ1gsSUFDQTtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLElBQUksU0FBUyxTQUFTO01BQ3BCLDRCQUE0QjtNQUM1QixNQUFNLFFBTUQsRUFBRTtNQUVQLE1BQU0sYUFBYSxpQkFBaUIsS0FBSyxDQUFDLGtCQUFrQixNQUFNLENBQUMsQ0FBQyxJQUFjLEVBQUUsSUFBSTtNQUV4RixLQUFLLE1BQU0sU0FBUyxXQUFZO1FBQzlCLE1BQU0sYUFBYSxNQUFNLEtBQUssQ0FBQztRQUMvQixNQUFNLFlBQVksTUFBTSxLQUFLLENBQUM7UUFDOUIsTUFBTSxlQUFlLE1BQU0sS0FBSyxDQUFDO1FBQ2pDLE1BQU0sWUFBWSxNQUFNLEtBQUssQ0FBQztRQUM5QixNQUFNLGNBQWMsTUFBTSxLQUFLLENBQUM7UUFFaEMsSUFBSSxZQUFZO1VBQ2QsTUFBTSxJQUFJLENBQUM7WUFDVCxPQUFPLFVBQVUsQ0FBQyxFQUFFLENBQUMsSUFBSTtZQUN6QixNQUFNLFdBQVcsQ0FBQyxFQUFFLEVBQUUsVUFBVTtZQUNoQyxTQUFTLGNBQWMsQ0FBQyxFQUFFLEVBQUUsVUFBVTtZQUN0QyxNQUFNLFdBQVcsQ0FBQyxFQUFFLEVBQUUsVUFBVTtZQUNoQyxRQUFRLGFBQWEsQ0FBQyxFQUFFLEVBQUUsVUFBVTtVQUN0QztRQUNGO01BQ0Y7TUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVDtRQUNBO1FBQ0EsU0FBUztNQUNYLElBQ0E7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxRQUFRLGlCQUFpQixJQUFJO01BQzdCO01BQ0EsU0FBUyxTQUFTLFlBQVksbUJBQW1CO0lBQ25ELElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEUsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDZCQUE2QjtJQUMzQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
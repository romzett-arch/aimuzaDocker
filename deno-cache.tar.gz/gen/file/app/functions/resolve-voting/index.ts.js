import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Get tracks with expired voting
    const { data: expiredTracks, error: fetchError } = await supabase.from("tracks").select("id, title, voting_likes_count, voting_dislikes_count, voting_ends_at, user_id").eq("moderation_status", "voting").lt("voting_ends_at", new Date().toISOString());
    if (fetchError) {
      throw fetchError;
    }
    if (!expiredTracks?.length) {
      return new Response(JSON.stringify({
        message: "No expired voting tracks found",
        processed: 0
      }), {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    console.log(`Processing ${expiredTracks.length} expired voting tracks`);
    // Get voting settings
    const { data: settings } = await supabase.from("settings").select("key, value").in("key", [
      "voting_min_votes",
      "voting_approval_ratio",
      "voting_notify_artist"
    ]);
    const settingsMap = new Map(settings?.map((s)=>[
        s.key,
        s.value
      ]) || []);
    const minVotes = parseInt(settingsMap.get("voting_min_votes") || "10", 10);
    const approvalRatio = parseFloat(settingsMap.get("voting_approval_ratio") || "0.6");
    const notifyArtist = settingsMap.get("voting_notify_artist") !== "false"; // default true
    const results = [];
    for (const track of expiredTracks){
      const totalVotes = (track.voting_likes_count || 0) + (track.voting_dislikes_count || 0);
      let votingResult;
      let newModerationStatus;
      let reason;
      if (totalVotes < minVotes) {
        votingResult = "rejected";
        newModerationStatus = "rejected";
        reason = `Недостаточно голосов: ${totalVotes} из ${minVotes} минимальных`;
      } else {
        const likeRatio = (track.voting_likes_count || 0) / totalVotes;
        if (likeRatio >= approvalRatio) {
          votingResult = "voting_approved";
          newModerationStatus = "pending"; // Back to moderation queue for final label decision
          reason = `Голосование пройдено: ${Math.round(likeRatio * 100)}% положительных голосов. Возвращён на модерацию для финального решения.`;
        } else {
          votingResult = "rejected";
          newModerationStatus = "rejected";
          reason = `Отклонено: ${Math.round(likeRatio * 100)}% положительных (нужно ${Math.round(approvalRatio * 100)}%)`;
        }
      }
      // Update track status
      // CRITICAL: Do NOT auto-publish! Track goes back to moderation queue
      const { error: updateError } = await supabase.from("tracks").update({
        moderation_status: newModerationStatus,
        voting_result: votingResult,
        is_public: false
      }).eq("id", track.id);
      if (updateError) {
        console.error(`Failed to update track ${track.id}:`, updateError);
        continue;
      }
      // Notify artist
      if (notifyArtist && track.user_id) {
        await supabase.from("notifications").insert({
          user_id: track.user_id,
          type: "voting_result",
          title: votingResult === "voting_approved" ? "🎉 Голосование пройдено!" : "Голосование завершено",
          message: votingResult === "voting_approved" ? `Трек "${track.title}" успешно прошёл голосование и отправлен на финальное рассмотрение лейбла.` : `К сожалению, трек "${track.title}" не набрал достаточно голосов. ${reason}`,
          target_type: "track",
          target_id: track.id
        });
      }
      results.push({
        trackId: track.id,
        title: track.title,
        result: votingResult,
        reason
      });
      console.log(`Track "${track.title}" (${track.id}): ${votingResult} -> moderation_status=${newModerationStatus}`);
    }
    return new Response(JSON.stringify({
      success: true,
      processed: results.length,
      results
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('Error in resolve-voting:', error);
    return new Response(JSON.stringify({
      error: error instanceof Error ? error.message : 'Unknown error'
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9yZXNvbHZlLXZvdGluZy9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6ICdhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZScsXG59O1xuXG5pbnRlcmZhY2UgVm90aW5nVHJhY2sge1xuICBpZDogc3RyaW5nO1xuICB0aXRsZTogc3RyaW5nO1xuICB2b3RpbmdfbGlrZXNfY291bnQ6IG51bWJlcjtcbiAgdm90aW5nX2Rpc2xpa2VzX2NvdW50OiBudW1iZXI7XG4gIHZvdGluZ19lbmRzX2F0OiBzdHJpbmc7XG4gIHVzZXJfaWQ6IHN0cmluZztcbn1cblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gJ09QVElPTlMnKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlU2VydmljZUtleSk7XG5cbiAgICAvLyBHZXQgdHJhY2tzIHdpdGggZXhwaXJlZCB2b3RpbmdcbiAgICBjb25zdCB7IGRhdGE6IGV4cGlyZWRUcmFja3MsIGVycm9yOiBmZXRjaEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgIC5zZWxlY3QoXCJpZCwgdGl0bGUsIHZvdGluZ19saWtlc19jb3VudCwgdm90aW5nX2Rpc2xpa2VzX2NvdW50LCB2b3RpbmdfZW5kc19hdCwgdXNlcl9pZFwiKVxuICAgICAgLmVxKFwibW9kZXJhdGlvbl9zdGF0dXNcIiwgXCJ2b3RpbmdcIilcbiAgICAgIC5sdChcInZvdGluZ19lbmRzX2F0XCIsIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG5cbiAgICBpZiAoZmV0Y2hFcnJvcikge1xuICAgICAgdGhyb3cgZmV0Y2hFcnJvcjtcbiAgICB9XG5cbiAgICBpZiAoIWV4cGlyZWRUcmFja3M/Lmxlbmd0aCkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBtZXNzYWdlOiBcIk5vIGV4cGlyZWQgdm90aW5nIHRyYWNrcyBmb3VuZFwiLCBwcm9jZXNzZWQ6IDAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFByb2Nlc3NpbmcgJHtleHBpcmVkVHJhY2tzLmxlbmd0aH0gZXhwaXJlZCB2b3RpbmcgdHJhY2tzYCk7XG5cbiAgICAvLyBHZXQgdm90aW5nIHNldHRpbmdzXG4gICAgY29uc3QgeyBkYXRhOiBzZXR0aW5ncyB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwic2V0dGluZ3NcIilcbiAgICAgIC5zZWxlY3QoXCJrZXksIHZhbHVlXCIpXG4gICAgICAuaW4oXCJrZXlcIiwgW1widm90aW5nX21pbl92b3Rlc1wiLCBcInZvdGluZ19hcHByb3ZhbF9yYXRpb1wiLCBcInZvdGluZ19ub3RpZnlfYXJ0aXN0XCJdKTtcblxuICAgIGNvbnN0IHNldHRpbmdzTWFwID0gbmV3IE1hcChzZXR0aW5ncz8ubWFwKHMgPT4gW3Mua2V5LCBzLnZhbHVlXSkgfHwgW10pO1xuICAgIGNvbnN0IG1pblZvdGVzID0gcGFyc2VJbnQoc2V0dGluZ3NNYXAuZ2V0KFwidm90aW5nX21pbl92b3Rlc1wiKSB8fCBcIjEwXCIsIDEwKTtcbiAgICBjb25zdCBhcHByb3ZhbFJhdGlvID0gcGFyc2VGbG9hdChzZXR0aW5nc01hcC5nZXQoXCJ2b3RpbmdfYXBwcm92YWxfcmF0aW9cIikgfHwgXCIwLjZcIik7XG4gICAgY29uc3Qgbm90aWZ5QXJ0aXN0ID0gc2V0dGluZ3NNYXAuZ2V0KFwidm90aW5nX25vdGlmeV9hcnRpc3RcIikgIT09IFwiZmFsc2VcIjsgLy8gZGVmYXVsdCB0cnVlXG5cbiAgICBjb25zdCByZXN1bHRzOiBBcnJheTx7IHRyYWNrSWQ6IHN0cmluZzsgdGl0bGU6IHN0cmluZzsgcmVzdWx0OiBzdHJpbmc7IHJlYXNvbjogc3RyaW5nIH0+ID0gW107XG5cbiAgICBmb3IgKGNvbnN0IHRyYWNrIG9mIGV4cGlyZWRUcmFja3MgYXMgVm90aW5nVHJhY2tbXSkge1xuICAgICAgY29uc3QgdG90YWxWb3RlcyA9ICh0cmFjay52b3RpbmdfbGlrZXNfY291bnQgfHwgMCkgKyAodHJhY2sudm90aW5nX2Rpc2xpa2VzX2NvdW50IHx8IDApO1xuICAgICAgbGV0IHZvdGluZ1Jlc3VsdDogXCJ2b3RpbmdfYXBwcm92ZWRcIiB8IFwicmVqZWN0ZWRcIjtcbiAgICAgIGxldCBuZXdNb2RlcmF0aW9uU3RhdHVzOiBcInBlbmRpbmdcIiB8IFwicmVqZWN0ZWRcIjtcbiAgICAgIGxldCByZWFzb246IHN0cmluZztcblxuICAgICAgaWYgKHRvdGFsVm90ZXMgPCBtaW5Wb3Rlcykge1xuICAgICAgICB2b3RpbmdSZXN1bHQgPSBcInJlamVjdGVkXCI7XG4gICAgICAgIG5ld01vZGVyYXRpb25TdGF0dXMgPSBcInJlamVjdGVkXCI7XG4gICAgICAgIHJlYXNvbiA9IGDQndC10LTQvtGB0YLQsNGC0L7Rh9C90L4g0LPQvtC70L7RgdC+0LI6ICR7dG90YWxWb3Rlc30g0LjQtyAke21pblZvdGVzfSDQvNC40L3QuNC80LDQu9GM0L3Ri9GFYDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGxpa2VSYXRpbyA9ICh0cmFjay52b3RpbmdfbGlrZXNfY291bnQgfHwgMCkgLyB0b3RhbFZvdGVzO1xuICAgICAgICBpZiAobGlrZVJhdGlvID49IGFwcHJvdmFsUmF0aW8pIHtcbiAgICAgICAgICB2b3RpbmdSZXN1bHQgPSBcInZvdGluZ19hcHByb3ZlZFwiO1xuICAgICAgICAgIG5ld01vZGVyYXRpb25TdGF0dXMgPSBcInBlbmRpbmdcIjsgLy8gQmFjayB0byBtb2RlcmF0aW9uIHF1ZXVlIGZvciBmaW5hbCBsYWJlbCBkZWNpc2lvblxuICAgICAgICAgIHJlYXNvbiA9IGDQk9C+0LvQvtGB0L7QstCw0L3QuNC1INC/0YDQvtC50LTQtdC90L46ICR7TWF0aC5yb3VuZChsaWtlUmF0aW8gKiAxMDApfSUg0L/QvtC70L7QttC40YLQtdC70YzQvdGL0YUg0LPQvtC70L7RgdC+0LIuINCS0L7Qt9Cy0YDQsNGJ0ZHQvSDQvdCwINC80L7QtNC10YDQsNGG0LjRjiDQtNC70Y8g0YTQuNC90LDQu9GM0L3QvtCz0L4g0YDQtdGI0LXQvdC40Y8uYDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB2b3RpbmdSZXN1bHQgPSBcInJlamVjdGVkXCI7XG4gICAgICAgICAgbmV3TW9kZXJhdGlvblN0YXR1cyA9IFwicmVqZWN0ZWRcIjtcbiAgICAgICAgICByZWFzb24gPSBg0J7RgtC60LvQvtC90LXQvdC+OiAke01hdGgucm91bmQobGlrZVJhdGlvICogMTAwKX0lINC/0L7Qu9C+0LbQuNGC0LXQu9GM0L3Ri9GFICjQvdGD0LbQvdC+ICR7TWF0aC5yb3VuZChhcHByb3ZhbFJhdGlvICogMTAwKX0lKWA7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gVXBkYXRlIHRyYWNrIHN0YXR1c1xuICAgICAgLy8gQ1JJVElDQUw6IERvIE5PVCBhdXRvLXB1Ymxpc2ghIFRyYWNrIGdvZXMgYmFjayB0byBtb2RlcmF0aW9uIHF1ZXVlXG4gICAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgbW9kZXJhdGlvbl9zdGF0dXM6IG5ld01vZGVyYXRpb25TdGF0dXMsXG4gICAgICAgICAgdm90aW5nX3Jlc3VsdDogdm90aW5nUmVzdWx0LFxuICAgICAgICAgIGlzX3B1YmxpYzogZmFsc2UsIC8vIEtlZXAgaGlkZGVuIC0gbGFiZWwgbWFrZXMgZmluYWwgZGVjaXNpb25cbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2suaWQpO1xuXG4gICAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRmFpbGVkIHRvIHVwZGF0ZSB0cmFjayAke3RyYWNrLmlkfTpgLCB1cGRhdGVFcnJvcik7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICAvLyBOb3RpZnkgYXJ0aXN0XG4gICAgICBpZiAobm90aWZ5QXJ0aXN0ICYmIHRyYWNrLnVzZXJfaWQpIHtcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcIm5vdGlmaWNhdGlvbnNcIilcbiAgICAgICAgICAuaW5zZXJ0KHtcbiAgICAgICAgICAgIHVzZXJfaWQ6IHRyYWNrLnVzZXJfaWQsXG4gICAgICAgICAgICB0eXBlOiBcInZvdGluZ19yZXN1bHRcIixcbiAgICAgICAgICAgIHRpdGxlOiB2b3RpbmdSZXN1bHQgPT09IFwidm90aW5nX2FwcHJvdmVkXCIgXG4gICAgICAgICAgICAgID8gXCLwn46JINCT0L7Qu9C+0YHQvtCy0LDQvdC40LUg0L/RgNC+0LnQtNC10L3QviFcIiBcbiAgICAgICAgICAgICAgOiBcItCT0L7Qu9C+0YHQvtCy0LDQvdC40LUg0LfQsNCy0LXRgNGI0LXQvdC+XCIsXG4gICAgICAgICAgICBtZXNzYWdlOiB2b3RpbmdSZXN1bHQgPT09IFwidm90aW5nX2FwcHJvdmVkXCJcbiAgICAgICAgICAgICAgPyBg0KLRgNC10LogXCIke3RyYWNrLnRpdGxlfVwiINGD0YHQv9C10YjQvdC+INC/0YDQvtGI0ZHQuyDQs9C+0LvQvtGB0L7QstCw0L3QuNC1INC4INC+0YLQv9GA0LDQstC70LXQvSDQvdCwINGE0LjQvdCw0LvRjNC90L7QtSDRgNCw0YHRgdC80L7RgtGA0LXQvdC40LUg0LvQtdC50LHQu9CwLmBcbiAgICAgICAgICAgICAgOiBg0Jog0YHQvtC20LDQu9C10L3QuNGOLCDRgtGA0LXQuiBcIiR7dHJhY2sudGl0bGV9XCIg0L3QtSDQvdCw0LHRgNCw0Lsg0LTQvtGB0YLQsNGC0L7Rh9C90L4g0LPQvtC70L7RgdC+0LIuICR7cmVhc29ufWAsXG4gICAgICAgICAgICB0YXJnZXRfdHlwZTogXCJ0cmFja1wiLFxuICAgICAgICAgICAgdGFyZ2V0X2lkOiB0cmFjay5pZCxcbiAgICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgcmVzdWx0cy5wdXNoKHtcbiAgICAgICAgdHJhY2tJZDogdHJhY2suaWQsXG4gICAgICAgIHRpdGxlOiB0cmFjay50aXRsZSxcbiAgICAgICAgcmVzdWx0OiB2b3RpbmdSZXN1bHQsXG4gICAgICAgIHJlYXNvbixcbiAgICAgIH0pO1xuXG4gICAgICBjb25zb2xlLmxvZyhgVHJhY2sgXCIke3RyYWNrLnRpdGxlfVwiICgke3RyYWNrLmlkfSk6ICR7dm90aW5nUmVzdWx0fSAtPiBtb2RlcmF0aW9uX3N0YXR1cz0ke25ld01vZGVyYXRpb25TdGF0dXN9YCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICBwcm9jZXNzZWQ6IHJlc3VsdHMubGVuZ3RoLFxuICAgICAgICByZXN1bHRzLFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGluIHJlc29sdmUtdm90aW5nOicsIGVycm9yKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcicgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFXQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLGlDQUFpQztJQUNqQyxNQUFNLEVBQUUsTUFBTSxhQUFhLEVBQUUsT0FBTyxVQUFVLEVBQUUsR0FBRyxNQUFNLFNBQ3RELElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxpRkFDUCxFQUFFLENBQUMscUJBQXFCLFVBQ3hCLEVBQUUsQ0FBQyxrQkFBa0IsSUFBSSxPQUFPLFdBQVc7SUFFOUMsSUFBSSxZQUFZO01BQ2QsTUFBTTtJQUNSO0lBRUEsSUFBSSxDQUFDLGVBQWUsUUFBUTtNQUMxQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLFNBQVM7UUFBa0MsV0FBVztNQUFFLElBQ3pFO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsY0FBYyxNQUFNLENBQUMsc0JBQXNCLENBQUM7SUFFdEUsc0JBQXNCO0lBQ3RCLE1BQU0sRUFBRSxNQUFNLFFBQVEsRUFBRSxHQUFHLE1BQU0sU0FDOUIsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLGNBQ1AsRUFBRSxDQUFDLE9BQU87TUFBQztNQUFvQjtNQUF5QjtLQUF1QjtJQUVsRixNQUFNLGNBQWMsSUFBSSxJQUFJLFVBQVUsSUFBSSxDQUFBLElBQUs7UUFBQyxFQUFFLEdBQUc7UUFBRSxFQUFFLEtBQUs7T0FBQyxLQUFLLEVBQUU7SUFDdEUsTUFBTSxXQUFXLFNBQVMsWUFBWSxHQUFHLENBQUMsdUJBQXVCLE1BQU07SUFDdkUsTUFBTSxnQkFBZ0IsV0FBVyxZQUFZLEdBQUcsQ0FBQyw0QkFBNEI7SUFDN0UsTUFBTSxlQUFlLFlBQVksR0FBRyxDQUFDLDRCQUE0QixTQUFTLGVBQWU7SUFFekYsTUFBTSxVQUFxRixFQUFFO0lBRTdGLEtBQUssTUFBTSxTQUFTLGNBQWdDO01BQ2xELE1BQU0sYUFBYSxDQUFDLE1BQU0sa0JBQWtCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxxQkFBcUIsSUFBSSxDQUFDO01BQ3RGLElBQUk7TUFDSixJQUFJO01BQ0osSUFBSTtNQUVKLElBQUksYUFBYSxVQUFVO1FBQ3pCLGVBQWU7UUFDZixzQkFBc0I7UUFDdEIsU0FBUyxDQUFDLHNCQUFzQixFQUFFLFdBQVcsSUFBSSxFQUFFLFNBQVMsWUFBWSxDQUFDO01BQzNFLE9BQU87UUFDTCxNQUFNLFlBQVksQ0FBQyxNQUFNLGtCQUFrQixJQUFJLENBQUMsSUFBSTtRQUNwRCxJQUFJLGFBQWEsZUFBZTtVQUM5QixlQUFlO1VBQ2Ysc0JBQXNCLFdBQVcsb0RBQW9EO1VBQ3JGLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLEtBQUssQ0FBQyxZQUFZLEtBQUssdUVBQXVFLENBQUM7UUFDeEksT0FBTztVQUNMLGVBQWU7VUFDZixzQkFBc0I7VUFDdEIsU0FBUyxDQUFDLFdBQVcsRUFBRSxLQUFLLEtBQUssQ0FBQyxZQUFZLEtBQUssdUJBQXVCLEVBQUUsS0FBSyxLQUFLLENBQUMsZ0JBQWdCLEtBQUssRUFBRSxDQUFDO1FBQ2pIO01BQ0Y7TUFFQSxzQkFBc0I7TUFDdEIscUVBQXFFO01BQ3JFLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sbUJBQW1CO1FBQ25CLGVBQWU7UUFDZixXQUFXO01BQ2IsR0FDQyxFQUFFLENBQUMsTUFBTSxNQUFNLEVBQUU7TUFFcEIsSUFBSSxhQUFhO1FBQ2YsUUFBUSxLQUFLLENBQUMsQ0FBQyx1QkFBdUIsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRTtRQUNyRDtNQUNGO01BRUEsZ0JBQWdCO01BQ2hCLElBQUksZ0JBQWdCLE1BQU0sT0FBTyxFQUFFO1FBQ2pDLE1BQU0sU0FDSCxJQUFJLENBQUMsaUJBQ0wsTUFBTSxDQUFDO1VBQ04sU0FBUyxNQUFNLE9BQU87VUFDdEIsTUFBTTtVQUNOLE9BQU8saUJBQWlCLG9CQUNwQiw2QkFDQTtVQUNKLFNBQVMsaUJBQWlCLG9CQUN0QixDQUFDLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQywwRUFBMEUsQ0FBQyxHQUNoRyxDQUFDLG1CQUFtQixFQUFFLE1BQU0sS0FBSyxDQUFDLGdDQUFnQyxFQUFFLE9BQU8sQ0FBQztVQUNoRixhQUFhO1VBQ2IsV0FBVyxNQUFNLEVBQUU7UUFDckI7TUFDSjtNQUVBLFFBQVEsSUFBSSxDQUFDO1FBQ1gsU0FBUyxNQUFNLEVBQUU7UUFDakIsT0FBTyxNQUFNLEtBQUs7UUFDbEIsUUFBUTtRQUNSO01BQ0Y7TUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEtBQUssQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLENBQUMsR0FBRyxFQUFFLGFBQWEsc0JBQXNCLEVBQUUsb0JBQW9CLENBQUM7SUFDakg7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxXQUFXLFFBQVEsTUFBTTtNQUN6QjtJQUNGLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFDMUMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQWdCLElBQ2pGO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
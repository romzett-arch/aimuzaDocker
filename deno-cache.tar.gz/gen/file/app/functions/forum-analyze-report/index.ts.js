/**
 * forum-analyze-report
 * AI-powered report analysis: when a user reports content,
 * this function analyzes it with DeepSeek and auto-actions if confident.
 *
 * Flow:
 * 1. Fetch reported content (post or topic)
 * 2. Run AI analysis (is it a real violation?)
 * 3. Update report with AI verdict
 * 4. If high confidence: auto-hide content + auto-warn author
 * 5. If multiple reports on same target: escalate priority
 */ import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const TIMEWEB_AGENT_ACCESS_ID = "0846d064-4950-4d79-a54c-62ba315cdb34";
Deno.serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: corsHeaders
    });
  }
  try {
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
    const { reportId } = await req.json();
    if (!reportId) {
      return jsonResponse({
        error: "reportId required"
      }, 400);
    }
    console.log(`[analyze-report] Processing report ${reportId}`);
    // ── 1. Fetch the report ──
    const { data: report, error: reportError } = await supabase.from("forum_reports").select("*").eq("id", reportId).maybeSingle();
    if (reportError || !report) {
      console.error("[analyze-report] Report not found:", reportError);
      return jsonResponse({
        error: "Report not found"
      }, 404);
    }
    if (report.status !== "pending") {
      console.log("[analyze-report] Report already processed, skipping");
      return jsonResponse({
        status: "skipped",
        reason: "already_processed"
      });
    }
    // ── 2. Fetch the reported content ──
    let contentText = "";
    let contentAuthorId = null;
    let contentTitle = null;
    if (report.post_id) {
      const { data: post } = await supabase.from("forum_posts").select("content, user_id").eq("id", report.post_id).maybeSingle();
      if (post) {
        contentText = post.content;
        contentAuthorId = post.user_id;
      }
    } else if (report.topic_id) {
      const { data: topic } = await supabase.from("forum_topics").select("title, content, user_id").eq("id", report.topic_id).maybeSingle();
      if (topic) {
        contentText = `${topic.title}\n\n${topic.content}`;
        contentTitle = topic.title;
        contentAuthorId = topic.user_id;
      }
    }
    if (!contentText) {
      console.warn("[analyze-report] No content found for report");
      await supabase.from("forum_reports").update({
        ai_verdict: "error",
        ai_reason: "Контент не найден",
        target_user_id: contentAuthorId
      }).eq("id", reportId);
      return jsonResponse({
        status: "error",
        reason: "content_not_found"
      });
    }
    // Save content snapshot for admin reference
    const snapshot = contentText.substring(0, 500);
    // ── 3. Fetch settings ──
    const { data: settings } = await supabase.from("forum_automod_settings").select("key, value").in("key", [
      "ai_moderation",
      "report_auto_action"
    ]);
    const settingsMap = {};
    (settings || []).forEach((s)=>{
      settingsMap[s.key] = s.value;
    });
    const aiConfig = settingsMap["ai_moderation"] || {};
    const reportConfig = settingsMap["report_auto_action"] || {};
    const autoActionThreshold = reportConfig.confidence_threshold || 0.8;
    const autoActionEnabled = reportConfig.enabled !== false; // default true
    const autoWarnEnabled = reportConfig.auto_warn !== false; // default true
    // ── 4. Run AI analysis ──
    const aiResult = await analyzeWithAI(contentText, report.reason, report.details);
    console.log(`[analyze-report] AI verdict: ${aiResult.verdict}, confidence: ${aiResult.confidence}, category: ${aiResult.category}`);
    // ── 5. Update report with AI result ──
    await supabase.from("forum_reports").update({
      ai_verdict: aiResult.verdict,
      ai_confidence: aiResult.confidence,
      ai_category: aiResult.category,
      ai_reason: aiResult.reason,
      content_snapshot: snapshot,
      target_user_id: contentAuthorId
    }).eq("id", reportId);
    // ── 6. Check report count for this target ──
    let reportCount = 1;
    if (report.post_id) {
      const { count } = await supabase.from("forum_reports").select("*", {
        count: "exact",
        head: true
      }).eq("post_id", report.post_id).eq("status", "pending");
      reportCount = count || 1;
    } else if (report.topic_id) {
      const { count } = await supabase.from("forum_reports").select("*", {
        count: "exact",
        head: true
      }).eq("topic_id", report.topic_id).is("post_id", null).eq("status", "pending");
      reportCount = count || 1;
    }
    // ── 7. Auto-action if confident enough OR multiple reports ──
    const shouldAutoAction = autoActionEnabled && aiResult.verdict === "violation" && (aiResult.confidence >= autoActionThreshold || reportCount >= 3);
    if (shouldAutoAction && contentAuthorId) {
      console.log(`[analyze-report] Auto-actioning: confidence=${aiResult.confidence}, reportCount=${reportCount}`);
      // Hide content
      const table = report.post_id ? "forum_posts" : "forum_topics";
      const targetId = report.post_id || report.topic_id;
      await supabase.from(table).update({
        is_hidden: true,
        hidden_by: "00000000-0000-0000-0000-000000000000",
        hidden_at: new Date().toISOString(),
        hidden_reason: `AI-модерация: ${aiResult.reason}`
      }).eq("id", targetId);
      // Auto-resolve the report
      await supabase.from("forum_reports").update({
        status: "resolved",
        resolution_note: `AI авто-модерация: ${aiResult.category} (${Math.round(aiResult.confidence * 100)}%)`,
        resolved_by: "00000000-0000-0000-0000-000000000000",
        resolved_at: new Date().toISOString(),
        auto_actioned: true
      }).eq("id", reportId);
      // Auto-warn the author (with quote of violation)
      if (autoWarnEnabled) {
        const violationQuote = contentText.substring(0, 200);
        const warningReason = `Автоматическое предупреждение за нарушение правил форума.\n\nКатегория: ${getCategoryLabel(aiResult.category)}\nЦитата: «${violationQuote}»${violationQuote.length < contentText.length ? "..." : ""}`;
        // Fetch default warning expiry
        const { data: expirySetting } = await supabase.from("forum_automod_settings").select("value").eq("key", "warn_expiry_days").maybeSingle();
        const expiryDays = expirySetting ? Number(expirySetting.value) : 90;
        const expiresAt = new Date(Date.now() + expiryDays * 86400000).toISOString();
        await supabase.from("forum_warnings").insert({
          user_id: contentAuthorId,
          issued_by: "00000000-0000-0000-0000-000000000000",
          reason: warningReason,
          severity: aiResult.confidence >= 0.9 ? "warning" : "notice",
          expires_at: expiresAt,
          post_id: report.post_id || null,
          topic_id: report.topic_id || null
        });
        // Update warning count in user stats
        const { count: warnCount } = await supabase.from("forum_warnings").select("*", {
          count: "exact",
          head: true
        }).eq("user_id", contentAuthorId).eq("is_active", true);
        await supabase.from("forum_user_stats").update({
          warnings_count: warnCount || 0,
          updated_at: new Date().toISOString()
        }).eq("user_id", contentAuthorId);
      }
      // Log mod action
      await supabase.from("forum_mod_logs").insert([
        {
          moderator_id: "00000000-0000-0000-0000-000000000000",
          action: "ai_auto_moderate",
          target_type: report.post_id ? "post" : "topic",
          target_id: report.post_id || report.topic_id,
          details: {
            report_id: reportId,
            ai_verdict: aiResult.verdict,
            ai_confidence: aiResult.confidence,
            ai_category: aiResult.category,
            report_count: reportCount,
            auto_warned: autoWarnEnabled,
            author_id: contentAuthorId
          }
        }
      ]);
      return jsonResponse({
        status: "auto_actioned",
        verdict: aiResult.verdict,
        confidence: aiResult.confidence,
        category: aiResult.category,
        hidden: true,
        warned: autoWarnEnabled
      });
    }
    return jsonResponse({
      status: "analyzed",
      verdict: aiResult.verdict,
      confidence: aiResult.confidence,
      category: aiResult.category,
      auto_actioned: false
    });
  } catch (error) {
    console.error("[analyze-report] Error:", error);
    return jsonResponse({
      error: error instanceof Error ? error.message : "Unknown error"
    }, 500);
  }
});
// ── Helpers ──
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json"
    }
  });
}
function getCategoryLabel(category) {
  const labels = {
    toxicity: "Токсичность / Оскорбления",
    spam: "Спам / Реклама",
    threats: "Угрозы / Буллинг",
    nsfw: "NSFW-контент",
    fraud: "Мошенничество",
    offtopic: "Оффтопик",
    copyright: "Нарушение авторских прав",
    none: "Нарушение не обнаружено"
  };
  return labels[category] || category;
}
async function analyzeWithAI(content, reportReason, reportDetails) {
  const TIMEWEB_TOKEN = Deno.env.get("TIMEWEB_AGENT_TOKEN");
  if (!TIMEWEB_TOKEN) {
    console.warn("[analyze-report] TIMEWEB_AGENT_TOKEN not configured, using heuristic");
    return heuristicAnalysis(content);
  }
  const systemPrompt = `Ты — AI-модератор музыкального форума. На этот пост/тему поступила жалоба.

Причина жалобы: "${reportReason}"
${reportDetails ? `Детали: "${reportDetails}"` : ""}

Проанализируй контент и определи:
1. Является ли контент РЕАЛЬНЫМ нарушением правил?
2. Категория нарушения (если есть)

Категории нарушений:
- toxicity: прямые оскорбления, мат, hate speech, унижение
- spam: реклама, промо, бессмысленный флуд
- threats: угрозы, буллинг, запугивание
- nsfw: откровенный контент
- fraud: мошенничество, фейки
- offtopic: полностью не по теме
- copyright: нарушение авторских прав

ВАЖНО:
- НЕ считай нарушением: критику музыки, сарказм, мнения, дискуссии, профессиональные споры
- Учитывай КОНТЕКСТ музыкального форума
- Будь строг к реальным оскорблениям, но лоялен к креативным дискуссиям

Отвечай СТРОГО JSON: {"verdict": "violation"|"clean"|"uncertain", "confidence": 0.0-1.0, "category": "...", "reason": "краткое пояснение на русском до 100 символов"}`;
  try {
    const apiUrl = `https://agent.timeweb.cloud/api/v1/cloud-ai/agents/${TIMEWEB_AGENT_ACCESS_ID}/v1/chat/completions`;
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${TIMEWEB_TOKEN}`
      },
      body: JSON.stringify({
        model: "deepseek-v3",
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: content.substring(0, 1500)
          }
        ],
        temperature: 0.1,
        max_tokens: 300
      })
    });
    if (!response.ok) {
      console.warn(`[analyze-report] DeepSeek API error: ${response.status}`);
      return heuristicAnalysis(content);
    }
    const data = await response.json();
    const resultText = data.choices?.[0]?.message?.content;
    if (!resultText) return heuristicAnalysis(content);
    const jsonMatch = resultText.match(/\{[^}]*\}/s);
    if (!jsonMatch) return heuristicAnalysis(content);
    const parsed = JSON.parse(jsonMatch[0]);
    return {
      verdict: parsed.verdict || "uncertain",
      confidence: Math.min(1, Math.max(0, parsed.confidence || 0)),
      category: parsed.category || "none",
      reason: (parsed.reason || "Анализ завершён").substring(0, 200)
    };
  } catch (error) {
    console.warn("[analyze-report] AI analysis failed:", error);
    return heuristicAnalysis(content);
  }
}
/**
 * Fallback heuristic when AI is unavailable
 */ function heuristicAnalysis(content) {
  const lowerContent = content.toLowerCase();
  // Basic profanity check (same words as stopwords list)
  const profanityPatterns = [
    /\bбля[дть]?\b/i,
    /\bхуй/i,
    /\bпизд/i,
    /\bебл[аоя]/i,
    /\bсука?\b/i,
    /\bмуда[кч]/i,
    /\bгандон/i,
    /\bдолбо[её]б/i,
    /\bдебил/i,
    /\bидиот/i,
    /\bтупой/i,
    /\bурод/i
  ];
  const matched = profanityPatterns.filter((p)=>p.test(lowerContent));
  if (matched.length >= 2) {
    return {
      verdict: "violation",
      confidence: 0.85,
      category: "toxicity",
      reason: "Обнаружена нецензурная лексика (эвристика)"
    };
  }
  if (matched.length === 1) {
    return {
      verdict: "uncertain",
      confidence: 0.6,
      category: "toxicity",
      reason: "Возможная нецензурная лексика (требует ручной проверки)"
    };
  }
  return {
    verdict: "uncertain",
    confidence: 0.3,
    category: "none",
    reason: "Автоматический анализ не обнаружил явных нарушений"
  };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9mb3J1bS1hbmFseXplLXJlcG9ydC9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIGZvcnVtLWFuYWx5emUtcmVwb3J0XG4gKiBBSS1wb3dlcmVkIHJlcG9ydCBhbmFseXNpczogd2hlbiBhIHVzZXIgcmVwb3J0cyBjb250ZW50LFxuICogdGhpcyBmdW5jdGlvbiBhbmFseXplcyBpdCB3aXRoIERlZXBTZWVrIGFuZCBhdXRvLWFjdGlvbnMgaWYgY29uZmlkZW50LlxuICpcbiAqIEZsb3c6XG4gKiAxLiBGZXRjaCByZXBvcnRlZCBjb250ZW50IChwb3N0IG9yIHRvcGljKVxuICogMi4gUnVuIEFJIGFuYWx5c2lzIChpcyBpdCBhIHJlYWwgdmlvbGF0aW9uPylcbiAqIDMuIFVwZGF0ZSByZXBvcnQgd2l0aCBBSSB2ZXJkaWN0XG4gKiA0LiBJZiBoaWdoIGNvbmZpZGVuY2U6IGF1dG8taGlkZSBjb250ZW50ICsgYXV0by13YXJuIGF1dGhvclxuICogNS4gSWYgbXVsdGlwbGUgcmVwb3J0cyBvbiBzYW1lIHRhcmdldDogZXNjYWxhdGUgcHJpb3JpdHlcbiAqL1xuXG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjpcbiAgICBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5jb25zdCBUSU1FV0VCX0FHRU5UX0FDQ0VTU19JRCA9IFwiMDg0NmQwNjQtNDk1MC00ZDc5LWE1NGMtNjJiYTMxNWNkYjM0XCI7XG5cbmludGVyZmFjZSBBbmFseXplUmVxdWVzdCB7XG4gIHJlcG9ydElkOiBzdHJpbmc7XG59XG5cbkRlbm8uc2VydmUoYXN5bmMgKHJlcTogUmVxdWVzdCkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFwib2tcIiwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSFcbiAgICApO1xuXG4gICAgY29uc3QgeyByZXBvcnRJZCB9OiBBbmFseXplUmVxdWVzdCA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgaWYgKCFyZXBvcnRJZCkge1xuICAgICAgcmV0dXJuIGpzb25SZXNwb25zZSh7IGVycm9yOiBcInJlcG9ydElkIHJlcXVpcmVkXCIgfSwgNDAwKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgW2FuYWx5emUtcmVwb3J0XSBQcm9jZXNzaW5nIHJlcG9ydCAke3JlcG9ydElkfWApO1xuXG4gICAgLy8g4pSA4pSAIDEuIEZldGNoIHRoZSByZXBvcnQg4pSA4pSAXG4gICAgY29uc3QgeyBkYXRhOiByZXBvcnQsIGVycm9yOiByZXBvcnRFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiZm9ydW1fcmVwb3J0c1wiKVxuICAgICAgLnNlbGVjdChcIipcIilcbiAgICAgIC5lcShcImlkXCIsIHJlcG9ydElkKVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICBpZiAocmVwb3J0RXJyb3IgfHwgIXJlcG9ydCkge1xuICAgICAgY29uc29sZS5lcnJvcihcIlthbmFseXplLXJlcG9ydF0gUmVwb3J0IG5vdCBmb3VuZDpcIiwgcmVwb3J0RXJyb3IpO1xuICAgICAgcmV0dXJuIGpzb25SZXNwb25zZSh7IGVycm9yOiBcIlJlcG9ydCBub3QgZm91bmRcIiB9LCA0MDQpO1xuICAgIH1cblxuICAgIGlmIChyZXBvcnQuc3RhdHVzICE9PSBcInBlbmRpbmdcIikge1xuICAgICAgY29uc29sZS5sb2coXCJbYW5hbHl6ZS1yZXBvcnRdIFJlcG9ydCBhbHJlYWR5IHByb2Nlc3NlZCwgc2tpcHBpbmdcIik7XG4gICAgICByZXR1cm4ganNvblJlc3BvbnNlKHsgc3RhdHVzOiBcInNraXBwZWRcIiwgcmVhc29uOiBcImFscmVhZHlfcHJvY2Vzc2VkXCIgfSk7XG4gICAgfVxuXG4gICAgLy8g4pSA4pSAIDIuIEZldGNoIHRoZSByZXBvcnRlZCBjb250ZW50IOKUgOKUgFxuICAgIGxldCBjb250ZW50VGV4dCA9IFwiXCI7XG4gICAgbGV0IGNvbnRlbnRBdXRob3JJZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gICAgbGV0IGNvbnRlbnRUaXRsZTogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG5cbiAgICBpZiAocmVwb3J0LnBvc3RfaWQpIHtcbiAgICAgIGNvbnN0IHsgZGF0YTogcG9zdCB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJmb3J1bV9wb3N0c1wiKVxuICAgICAgICAuc2VsZWN0KFwiY29udGVudCwgdXNlcl9pZFwiKVxuICAgICAgICAuZXEoXCJpZFwiLCByZXBvcnQucG9zdF9pZClcbiAgICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICAgIGlmIChwb3N0KSB7XG4gICAgICAgIGNvbnRlbnRUZXh0ID0gcG9zdC5jb250ZW50O1xuICAgICAgICBjb250ZW50QXV0aG9ySWQgPSBwb3N0LnVzZXJfaWQ7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChyZXBvcnQudG9waWNfaWQpIHtcbiAgICAgIGNvbnN0IHsgZGF0YTogdG9waWMgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwiZm9ydW1fdG9waWNzXCIpXG4gICAgICAgIC5zZWxlY3QoXCJ0aXRsZSwgY29udGVudCwgdXNlcl9pZFwiKVxuICAgICAgICAuZXEoXCJpZFwiLCByZXBvcnQudG9waWNfaWQpXG4gICAgICAgIC5tYXliZVNpbmdsZSgpO1xuXG4gICAgICBpZiAodG9waWMpIHtcbiAgICAgICAgY29udGVudFRleHQgPSBgJHt0b3BpYy50aXRsZX1cXG5cXG4ke3RvcGljLmNvbnRlbnR9YDtcbiAgICAgICAgY29udGVudFRpdGxlID0gdG9waWMudGl0bGU7XG4gICAgICAgIGNvbnRlbnRBdXRob3JJZCA9IHRvcGljLnVzZXJfaWQ7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKCFjb250ZW50VGV4dCkge1xuICAgICAgY29uc29sZS53YXJuKFwiW2FuYWx5emUtcmVwb3J0XSBObyBjb250ZW50IGZvdW5kIGZvciByZXBvcnRcIik7XG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcImZvcnVtX3JlcG9ydHNcIilcbiAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgYWlfdmVyZGljdDogXCJlcnJvclwiLFxuICAgICAgICAgIGFpX3JlYXNvbjogXCLQmtC+0L3RgtC10L3RgiDQvdC1INC90LDQudC00LXQvVwiLFxuICAgICAgICAgIHRhcmdldF91c2VyX2lkOiBjb250ZW50QXV0aG9ySWQsXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHJlcG9ydElkKTtcbiAgICAgIHJldHVybiBqc29uUmVzcG9uc2UoeyBzdGF0dXM6IFwiZXJyb3JcIiwgcmVhc29uOiBcImNvbnRlbnRfbm90X2ZvdW5kXCIgfSk7XG4gICAgfVxuXG4gICAgLy8gU2F2ZSBjb250ZW50IHNuYXBzaG90IGZvciBhZG1pbiByZWZlcmVuY2VcbiAgICBjb25zdCBzbmFwc2hvdCA9IGNvbnRlbnRUZXh0LnN1YnN0cmluZygwLCA1MDApO1xuXG4gICAgLy8g4pSA4pSAIDMuIEZldGNoIHNldHRpbmdzIOKUgOKUgFxuICAgIGNvbnN0IHsgZGF0YTogc2V0dGluZ3MgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImZvcnVtX2F1dG9tb2Rfc2V0dGluZ3NcIilcbiAgICAgIC5zZWxlY3QoXCJrZXksIHZhbHVlXCIpXG4gICAgICAuaW4oXCJrZXlcIiwgW1wiYWlfbW9kZXJhdGlvblwiLCBcInJlcG9ydF9hdXRvX2FjdGlvblwiXSk7XG5cbiAgICBjb25zdCBzZXR0aW5nc01hcDogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9O1xuICAgIChzZXR0aW5ncyB8fCBbXSkuZm9yRWFjaCgoczogYW55KSA9PiB7XG4gICAgICBzZXR0aW5nc01hcFtzLmtleV0gPSBzLnZhbHVlO1xuICAgIH0pO1xuXG4gICAgY29uc3QgYWlDb25maWcgPSBzZXR0aW5nc01hcFtcImFpX21vZGVyYXRpb25cIl0gfHwge307XG4gICAgY29uc3QgcmVwb3J0Q29uZmlnID0gc2V0dGluZ3NNYXBbXCJyZXBvcnRfYXV0b19hY3Rpb25cIl0gfHwge307XG4gICAgY29uc3QgYXV0b0FjdGlvblRocmVzaG9sZCA9IHJlcG9ydENvbmZpZy5jb25maWRlbmNlX3RocmVzaG9sZCB8fCAwLjg7XG4gICAgY29uc3QgYXV0b0FjdGlvbkVuYWJsZWQgPSByZXBvcnRDb25maWcuZW5hYmxlZCAhPT0gZmFsc2U7IC8vIGRlZmF1bHQgdHJ1ZVxuICAgIGNvbnN0IGF1dG9XYXJuRW5hYmxlZCA9IHJlcG9ydENvbmZpZy5hdXRvX3dhcm4gIT09IGZhbHNlOyAvLyBkZWZhdWx0IHRydWVcblxuICAgIC8vIOKUgOKUgCA0LiBSdW4gQUkgYW5hbHlzaXMg4pSA4pSAXG4gICAgY29uc3QgYWlSZXN1bHQgPSBhd2FpdCBhbmFseXplV2l0aEFJKGNvbnRlbnRUZXh0LCByZXBvcnQucmVhc29uLCByZXBvcnQuZGV0YWlscyk7XG5cbiAgICBjb25zb2xlLmxvZyhcbiAgICAgIGBbYW5hbHl6ZS1yZXBvcnRdIEFJIHZlcmRpY3Q6ICR7YWlSZXN1bHQudmVyZGljdH0sIGNvbmZpZGVuY2U6ICR7YWlSZXN1bHQuY29uZmlkZW5jZX0sIGNhdGVnb3J5OiAke2FpUmVzdWx0LmNhdGVnb3J5fWBcbiAgICApO1xuXG4gICAgLy8g4pSA4pSAIDUuIFVwZGF0ZSByZXBvcnQgd2l0aCBBSSByZXN1bHQg4pSA4pSAXG4gICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiZm9ydW1fcmVwb3J0c1wiKVxuICAgICAgLnVwZGF0ZSh7XG4gICAgICAgIGFpX3ZlcmRpY3Q6IGFpUmVzdWx0LnZlcmRpY3QsXG4gICAgICAgIGFpX2NvbmZpZGVuY2U6IGFpUmVzdWx0LmNvbmZpZGVuY2UsXG4gICAgICAgIGFpX2NhdGVnb3J5OiBhaVJlc3VsdC5jYXRlZ29yeSxcbiAgICAgICAgYWlfcmVhc29uOiBhaVJlc3VsdC5yZWFzb24sXG4gICAgICAgIGNvbnRlbnRfc25hcHNob3Q6IHNuYXBzaG90LFxuICAgICAgICB0YXJnZXRfdXNlcl9pZDogY29udGVudEF1dGhvcklkLFxuICAgICAgfSlcbiAgICAgIC5lcShcImlkXCIsIHJlcG9ydElkKTtcblxuICAgIC8vIOKUgOKUgCA2LiBDaGVjayByZXBvcnQgY291bnQgZm9yIHRoaXMgdGFyZ2V0IOKUgOKUgFxuICAgIGxldCByZXBvcnRDb3VudCA9IDE7XG4gICAgaWYgKHJlcG9ydC5wb3N0X2lkKSB7XG4gICAgICBjb25zdCB7IGNvdW50IH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcImZvcnVtX3JlcG9ydHNcIilcbiAgICAgICAgLnNlbGVjdChcIipcIiwgeyBjb3VudDogXCJleGFjdFwiLCBoZWFkOiB0cnVlIH0pXG4gICAgICAgIC5lcShcInBvc3RfaWRcIiwgcmVwb3J0LnBvc3RfaWQpXG4gICAgICAgIC5lcShcInN0YXR1c1wiLCBcInBlbmRpbmdcIik7XG4gICAgICByZXBvcnRDb3VudCA9IGNvdW50IHx8IDE7XG4gICAgfSBlbHNlIGlmIChyZXBvcnQudG9waWNfaWQpIHtcbiAgICAgIGNvbnN0IHsgY291bnQgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwiZm9ydW1fcmVwb3J0c1wiKVxuICAgICAgICAuc2VsZWN0KFwiKlwiLCB7IGNvdW50OiBcImV4YWN0XCIsIGhlYWQ6IHRydWUgfSlcbiAgICAgICAgLmVxKFwidG9waWNfaWRcIiwgcmVwb3J0LnRvcGljX2lkKVxuICAgICAgICAuaXMoXCJwb3N0X2lkXCIsIG51bGwpXG4gICAgICAgIC5lcShcInN0YXR1c1wiLCBcInBlbmRpbmdcIik7XG4gICAgICByZXBvcnRDb3VudCA9IGNvdW50IHx8IDE7XG4gICAgfVxuXG4gICAgLy8g4pSA4pSAIDcuIEF1dG8tYWN0aW9uIGlmIGNvbmZpZGVudCBlbm91Z2ggT1IgbXVsdGlwbGUgcmVwb3J0cyDilIDilIBcbiAgICBjb25zdCBzaG91bGRBdXRvQWN0aW9uID1cbiAgICAgIGF1dG9BY3Rpb25FbmFibGVkICYmXG4gICAgICBhaVJlc3VsdC52ZXJkaWN0ID09PSBcInZpb2xhdGlvblwiICYmXG4gICAgICAoYWlSZXN1bHQuY29uZmlkZW5jZSA+PSBhdXRvQWN0aW9uVGhyZXNob2xkIHx8IHJlcG9ydENvdW50ID49IDMpO1xuXG4gICAgaWYgKHNob3VsZEF1dG9BY3Rpb24gJiYgY29udGVudEF1dGhvcklkKSB7XG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgYFthbmFseXplLXJlcG9ydF0gQXV0by1hY3Rpb25pbmc6IGNvbmZpZGVuY2U9JHthaVJlc3VsdC5jb25maWRlbmNlfSwgcmVwb3J0Q291bnQ9JHtyZXBvcnRDb3VudH1gXG4gICAgICApO1xuXG4gICAgICAvLyBIaWRlIGNvbnRlbnRcbiAgICAgIGNvbnN0IHRhYmxlID0gcmVwb3J0LnBvc3RfaWQgPyBcImZvcnVtX3Bvc3RzXCIgOiBcImZvcnVtX3RvcGljc1wiO1xuICAgICAgY29uc3QgdGFyZ2V0SWQgPSByZXBvcnQucG9zdF9pZCB8fCByZXBvcnQudG9waWNfaWQ7XG5cbiAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKHRhYmxlKVxuICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICBpc19oaWRkZW46IHRydWUsXG4gICAgICAgICAgaGlkZGVuX2J5OiBcIjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMFwiLFxuICAgICAgICAgIGhpZGRlbl9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIGhpZGRlbl9yZWFzb246IGBBSS3QvNC+0LTQtdGA0LDRhtC40Y86ICR7YWlSZXN1bHQucmVhc29ufWAsXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHRhcmdldElkKTtcblxuICAgICAgLy8gQXV0by1yZXNvbHZlIHRoZSByZXBvcnRcbiAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwiZm9ydW1fcmVwb3J0c1wiKVxuICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICBzdGF0dXM6IFwicmVzb2x2ZWRcIixcbiAgICAgICAgICByZXNvbHV0aW9uX25vdGU6IGBBSSDQsNCy0YLQvi3QvNC+0LTQtdGA0LDRhtC40Y86ICR7YWlSZXN1bHQuY2F0ZWdvcnl9ICgke01hdGgucm91bmQoYWlSZXN1bHQuY29uZmlkZW5jZSAqIDEwMCl9JSlgLFxuICAgICAgICAgIHJlc29sdmVkX2J5OiBcIjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMFwiLFxuICAgICAgICAgIHJlc29sdmVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgYXV0b19hY3Rpb25lZDogdHJ1ZSxcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgcmVwb3J0SWQpO1xuXG4gICAgICAvLyBBdXRvLXdhcm4gdGhlIGF1dGhvciAod2l0aCBxdW90ZSBvZiB2aW9sYXRpb24pXG4gICAgICBpZiAoYXV0b1dhcm5FbmFibGVkKSB7XG4gICAgICAgIGNvbnN0IHZpb2xhdGlvblF1b3RlID0gY29udGVudFRleHQuc3Vic3RyaW5nKDAsIDIwMCk7XG4gICAgICAgIGNvbnN0IHdhcm5pbmdSZWFzb24gPSBg0JDQstGC0L7QvNCw0YLQuNGH0LXRgdC60L7QtSDQv9GA0LXQtNGD0L/RgNC10LbQtNC10L3QuNC1INC30LAg0L3QsNGA0YPRiNC10L3QuNC1INC/0YDQsNCy0LjQuyDRhNC+0YDRg9C80LAuXFxuXFxu0JrQsNGC0LXQs9C+0YDQuNGPOiAke2dldENhdGVnb3J5TGFiZWwoYWlSZXN1bHQuY2F0ZWdvcnkpfVxcbtCm0LjRgtCw0YLQsDogwqske3Zpb2xhdGlvblF1b3RlfcK7JHt2aW9sYXRpb25RdW90ZS5sZW5ndGggPCBjb250ZW50VGV4dC5sZW5ndGggPyBcIi4uLlwiIDogXCJcIn1gO1xuXG4gICAgICAgIC8vIEZldGNoIGRlZmF1bHQgd2FybmluZyBleHBpcnlcbiAgICAgICAgY29uc3QgeyBkYXRhOiBleHBpcnlTZXR0aW5nIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwiZm9ydW1fYXV0b21vZF9zZXR0aW5nc1wiKVxuICAgICAgICAgIC5zZWxlY3QoXCJ2YWx1ZVwiKVxuICAgICAgICAgIC5lcShcImtleVwiLCBcIndhcm5fZXhwaXJ5X2RheXNcIilcbiAgICAgICAgICAubWF5YmVTaW5nbGUoKTtcbiAgICAgICAgY29uc3QgZXhwaXJ5RGF5cyA9IGV4cGlyeVNldHRpbmcgPyBOdW1iZXIoZXhwaXJ5U2V0dGluZy52YWx1ZSkgOiA5MDtcbiAgICAgICAgY29uc3QgZXhwaXJlc0F0ID0gbmV3IERhdGUoRGF0ZS5ub3coKSArIGV4cGlyeURheXMgKiA4NjQwMDAwMCkudG9JU09TdHJpbmcoKTtcblxuICAgICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwiZm9ydW1fd2FybmluZ3NcIikuaW5zZXJ0KHtcbiAgICAgICAgICB1c2VyX2lkOiBjb250ZW50QXV0aG9ySWQsXG4gICAgICAgICAgaXNzdWVkX2J5OiBcIjAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMFwiLFxuICAgICAgICAgIHJlYXNvbjogd2FybmluZ1JlYXNvbixcbiAgICAgICAgICBzZXZlcml0eTogYWlSZXN1bHQuY29uZmlkZW5jZSA+PSAwLjkgPyBcIndhcm5pbmdcIiA6IFwibm90aWNlXCIsXG4gICAgICAgICAgZXhwaXJlc19hdDogZXhwaXJlc0F0LFxuICAgICAgICAgIHBvc3RfaWQ6IHJlcG9ydC5wb3N0X2lkIHx8IG51bGwsXG4gICAgICAgICAgdG9waWNfaWQ6IHJlcG9ydC50b3BpY19pZCB8fCBudWxsLFxuICAgICAgICB9KTtcblxuICAgICAgICAvLyBVcGRhdGUgd2FybmluZyBjb3VudCBpbiB1c2VyIHN0YXRzXG4gICAgICAgIGNvbnN0IHsgY291bnQ6IHdhcm5Db3VudCB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcImZvcnVtX3dhcm5pbmdzXCIpXG4gICAgICAgICAgLnNlbGVjdChcIipcIiwgeyBjb3VudDogXCJleGFjdFwiLCBoZWFkOiB0cnVlIH0pXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCBjb250ZW50QXV0aG9ySWQpXG4gICAgICAgICAgLmVxKFwiaXNfYWN0aXZlXCIsIHRydWUpO1xuXG4gICAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJmb3J1bV91c2VyX3N0YXRzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgICB3YXJuaW5nc19jb3VudDogd2FybkNvdW50IHx8IDAsXG4gICAgICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgfSlcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIGNvbnRlbnRBdXRob3JJZCk7XG4gICAgICB9XG5cbiAgICAgIC8vIExvZyBtb2QgYWN0aW9uXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwiZm9ydW1fbW9kX2xvZ3NcIikuaW5zZXJ0KFtcbiAgICAgICAge1xuICAgICAgICAgIG1vZGVyYXRvcl9pZDogXCIwMDAwMDAwMC0wMDAwLTAwMDAtMDAwMC0wMDAwMDAwMDAwMDBcIixcbiAgICAgICAgICBhY3Rpb246IFwiYWlfYXV0b19tb2RlcmF0ZVwiLFxuICAgICAgICAgIHRhcmdldF90eXBlOiByZXBvcnQucG9zdF9pZCA/IFwicG9zdFwiIDogXCJ0b3BpY1wiLFxuICAgICAgICAgIHRhcmdldF9pZDogcmVwb3J0LnBvc3RfaWQgfHwgcmVwb3J0LnRvcGljX2lkLFxuICAgICAgICAgIGRldGFpbHM6IHtcbiAgICAgICAgICAgIHJlcG9ydF9pZDogcmVwb3J0SWQsXG4gICAgICAgICAgICBhaV92ZXJkaWN0OiBhaVJlc3VsdC52ZXJkaWN0LFxuICAgICAgICAgICAgYWlfY29uZmlkZW5jZTogYWlSZXN1bHQuY29uZmlkZW5jZSxcbiAgICAgICAgICAgIGFpX2NhdGVnb3J5OiBhaVJlc3VsdC5jYXRlZ29yeSxcbiAgICAgICAgICAgIHJlcG9ydF9jb3VudDogcmVwb3J0Q291bnQsXG4gICAgICAgICAgICBhdXRvX3dhcm5lZDogYXV0b1dhcm5FbmFibGVkLFxuICAgICAgICAgICAgYXV0aG9yX2lkOiBjb250ZW50QXV0aG9ySWQsXG4gICAgICAgICAgfSBhcyBhbnksXG4gICAgICAgIH0sXG4gICAgICBdKTtcblxuICAgICAgcmV0dXJuIGpzb25SZXNwb25zZSh7XG4gICAgICAgIHN0YXR1czogXCJhdXRvX2FjdGlvbmVkXCIsXG4gICAgICAgIHZlcmRpY3Q6IGFpUmVzdWx0LnZlcmRpY3QsXG4gICAgICAgIGNvbmZpZGVuY2U6IGFpUmVzdWx0LmNvbmZpZGVuY2UsXG4gICAgICAgIGNhdGVnb3J5OiBhaVJlc3VsdC5jYXRlZ29yeSxcbiAgICAgICAgaGlkZGVuOiB0cnVlLFxuICAgICAgICB3YXJuZWQ6IGF1dG9XYXJuRW5hYmxlZCxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiBqc29uUmVzcG9uc2Uoe1xuICAgICAgc3RhdHVzOiBcImFuYWx5emVkXCIsXG4gICAgICB2ZXJkaWN0OiBhaVJlc3VsdC52ZXJkaWN0LFxuICAgICAgY29uZmlkZW5jZTogYWlSZXN1bHQuY29uZmlkZW5jZSxcbiAgICAgIGNhdGVnb3J5OiBhaVJlc3VsdC5jYXRlZ29yeSxcbiAgICAgIGF1dG9fYWN0aW9uZWQ6IGZhbHNlLFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJbYW5hbHl6ZS1yZXBvcnRdIEVycm9yOlwiLCBlcnJvcik7XG4gICAgcmV0dXJuIGpzb25SZXNwb25zZShcbiAgICAgIHsgZXJyb3I6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCIgfSxcbiAgICAgIDUwMFxuICAgICk7XG4gIH1cbn0pO1xuXG4vLyDilIDilIAgSGVscGVycyDilIDilIBcblxuZnVuY3Rpb24ganNvblJlc3BvbnNlKGRhdGE6IGFueSwgc3RhdHVzID0gMjAwKSB7XG4gIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoZGF0YSksIHtcbiAgICBzdGF0dXMsXG4gICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIGdldENhdGVnb3J5TGFiZWwoY2F0ZWdvcnk6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IGxhYmVsczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgICB0b3hpY2l0eTogXCLQotC+0LrRgdC40YfQvdC+0YHRgtGMIC8g0J7RgdC60L7RgNCx0LvQtdC90LjRj1wiLFxuICAgIHNwYW06IFwi0KHQv9Cw0LwgLyDQoNC10LrQu9Cw0LzQsFwiLFxuICAgIHRocmVhdHM6IFwi0KPQs9GA0L7Qt9GLIC8g0JHRg9C70LvQuNC90LNcIixcbiAgICBuc2Z3OiBcIk5TRlct0LrQvtC90YLQtdC90YJcIixcbiAgICBmcmF1ZDogXCLQnNC+0YjQtdC90L3QuNGH0LXRgdGC0LLQvlwiLFxuICAgIG9mZnRvcGljOiBcItCe0YTRhNGC0L7Qv9C40LpcIixcbiAgICBjb3B5cmlnaHQ6IFwi0J3QsNGA0YPRiNC10L3QuNC1INCw0LLRgtC+0YDRgdC60LjRhSDQv9GA0LDQslwiLFxuICAgIG5vbmU6IFwi0J3QsNGA0YPRiNC10L3QuNC1INC90LUg0L7QsdC90LDRgNGD0LbQtdC90L5cIixcbiAgfTtcbiAgcmV0dXJuIGxhYmVsc1tjYXRlZ29yeV0gfHwgY2F0ZWdvcnk7XG59XG5cbmludGVyZmFjZSBBSUFuYWx5c2lzUmVzdWx0IHtcbiAgdmVyZGljdDogXCJ2aW9sYXRpb25cIiB8IFwiY2xlYW5cIiB8IFwidW5jZXJ0YWluXCI7XG4gIGNvbmZpZGVuY2U6IG51bWJlcjtcbiAgY2F0ZWdvcnk6IHN0cmluZztcbiAgcmVhc29uOiBzdHJpbmc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGFuYWx5emVXaXRoQUkoXG4gIGNvbnRlbnQ6IHN0cmluZyxcbiAgcmVwb3J0UmVhc29uOiBzdHJpbmcsXG4gIHJlcG9ydERldGFpbHM6IHN0cmluZyB8IG51bGxcbik6IFByb21pc2U8QUlBbmFseXNpc1Jlc3VsdD4ge1xuICBjb25zdCBUSU1FV0VCX1RPS0VOID0gRGVuby5lbnYuZ2V0KFwiVElNRVdFQl9BR0VOVF9UT0tFTlwiKTtcbiAgaWYgKCFUSU1FV0VCX1RPS0VOKSB7XG4gICAgY29uc29sZS53YXJuKFwiW2FuYWx5emUtcmVwb3J0XSBUSU1FV0VCX0FHRU5UX1RPS0VOIG5vdCBjb25maWd1cmVkLCB1c2luZyBoZXVyaXN0aWNcIik7XG4gICAgcmV0dXJuIGhldXJpc3RpY0FuYWx5c2lzKGNvbnRlbnQpO1xuICB9XG5cbiAgY29uc3Qgc3lzdGVtUHJvbXB0ID0gYNCi0Ysg4oCUIEFJLdC80L7QtNC10YDQsNGC0L7RgCDQvNGD0LfRi9C60LDQu9GM0L3QvtCz0L4g0YTQvtGA0YPQvNCwLiDQndCwINGN0YLQvtGCINC/0L7RgdGCL9GC0LXQvNGDINC/0L7RgdGC0YPQv9C40LvQsCDQttCw0LvQvtCx0LAuXG5cbtCf0YDQuNGH0LjQvdCwINC20LDQu9C+0LHRizogXCIke3JlcG9ydFJlYXNvbn1cIlxuJHtyZXBvcnREZXRhaWxzID8gYNCU0LXRgtCw0LvQuDogXCIke3JlcG9ydERldGFpbHN9XCJgIDogXCJcIn1cblxu0J/RgNC+0LDQvdCw0LvQuNC30LjRgNGD0Lkg0LrQvtC90YLQtdC90YIg0Lgg0L7Qv9GA0LXQtNC10LvQuDpcbjEuINCv0LLQu9GP0LXRgtGB0Y8g0LvQuCDQutC+0L3RgtC10L3RgiDQoNCV0JDQm9Cs0J3Qq9CcINC90LDRgNGD0YjQtdC90LjQtdC8INC/0YDQsNCy0LjQuz9cbjIuINCa0LDRgtC10LPQvtGA0LjRjyDQvdCw0YDRg9GI0LXQvdC40Y8gKNC10YHQu9C4INC10YHRgtGMKVxuXG7QmtCw0YLQtdCz0L7RgNC40Lgg0L3QsNGA0YPRiNC10L3QuNC5OlxuLSB0b3hpY2l0eTog0L/RgNGP0LzRi9C1INC+0YHQutC+0YDQsdC70LXQvdC40Y8sINC80LDRgiwgaGF0ZSBzcGVlY2gsINGD0L3QuNC20LXQvdC40LVcbi0gc3BhbTog0YDQtdC60LvQsNC80LAsINC/0YDQvtC80L4sINCx0LXRgdGB0LzRi9GB0LvQtdC90L3Ri9C5INGE0LvRg9C0XG4tIHRocmVhdHM6INGD0LPRgNC+0LfRiywg0LHRg9C70LvQuNC90LMsINC30LDQv9GD0LPQuNCy0LDQvdC40LVcbi0gbnNmdzog0L7RgtC60YDQvtCy0LXQvdC90YvQuSDQutC+0L3RgtC10L3RglxuLSBmcmF1ZDog0LzQvtGI0LXQvdC90LjRh9C10YHRgtCy0L4sINGE0LXQudC60Lhcbi0gb2ZmdG9waWM6INC/0L7Qu9C90L7RgdGC0YzRjiDQvdC1INC/0L4g0YLQtdC80LVcbi0gY29weXJpZ2h0OiDQvdCw0YDRg9GI0LXQvdC40LUg0LDQstGC0L7RgNGB0LrQuNGFINC/0YDQsNCyXG5cbtCS0JDQltCd0J46XG4tINCd0JUg0YHRh9C40YLQsNC5INC90LDRgNGD0YjQtdC90LjQtdC8OiDQutGA0LjRgtC40LrRgyDQvNGD0LfRi9C60LgsINGB0LDRgNC60LDQt9C8LCDQvNC90LXQvdC40Y8sINC00LjRgdC60YPRgdGB0LjQuCwg0L/RgNC+0YTQtdGB0YHQuNC+0L3QsNC70YzQvdGL0LUg0YHQv9C+0YDRi1xuLSDQo9GH0LjRgtGL0LLQsNC5INCa0J7QndCi0JXQmtCh0KIg0LzRg9C30YvQutCw0LvRjNC90L7Qs9C+INGE0L7RgNGD0LzQsFxuLSDQkdGD0LTRjCDRgdGC0YDQvtCzINC6INGA0LXQsNC70YzQvdGL0Lwg0L7RgdC60L7RgNCx0LvQtdC90LjRj9C8LCDQvdC+INC70L7Rj9C70LXQvSDQuiDQutGA0LXQsNGC0LjQstC90YvQvCDQtNC40YHQutGD0YHRgdC40Y/QvFxuXG7QntGC0LLQtdGH0LDQuSDQodCi0KDQntCT0J4gSlNPTjoge1widmVyZGljdFwiOiBcInZpb2xhdGlvblwifFwiY2xlYW5cInxcInVuY2VydGFpblwiLCBcImNvbmZpZGVuY2VcIjogMC4wLTEuMCwgXCJjYXRlZ29yeVwiOiBcIi4uLlwiLCBcInJlYXNvblwiOiBcItC60YDQsNGC0LrQvtC1INC/0L7Rj9GB0L3QtdC90LjQtSDQvdCwINGA0YPRgdGB0LrQvtC8INC00L4gMTAwINGB0LjQvNCy0L7Qu9C+0LJcIn1gO1xuXG4gIHRyeSB7XG4gICAgY29uc3QgYXBpVXJsID0gYGh0dHBzOi8vYWdlbnQudGltZXdlYi5jbG91ZC9hcGkvdjEvY2xvdWQtYWkvYWdlbnRzLyR7VElNRVdFQl9BR0VOVF9BQ0NFU1NfSUR9L3YxL2NoYXQvY29tcGxldGlvbnNgO1xuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7VElNRVdFQl9UT0tFTn1gLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgbW9kZWw6IFwiZGVlcHNlZWstdjNcIixcbiAgICAgICAgbWVzc2FnZXM6IFtcbiAgICAgICAgICB7IHJvbGU6IFwic3lzdGVtXCIsIGNvbnRlbnQ6IHN5c3RlbVByb21wdCB9LFxuICAgICAgICAgIHsgcm9sZTogXCJ1c2VyXCIsIGNvbnRlbnQ6IGNvbnRlbnQuc3Vic3RyaW5nKDAsIDE1MDApIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHRlbXBlcmF0dXJlOiAwLjEsXG4gICAgICAgIG1heF90b2tlbnM6IDMwMCxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgY29uc29sZS53YXJuKGBbYW5hbHl6ZS1yZXBvcnRdIERlZXBTZWVrIEFQSSBlcnJvcjogJHtyZXNwb25zZS5zdGF0dXN9YCk7XG4gICAgICByZXR1cm4gaGV1cmlzdGljQW5hbHlzaXMoY29udGVudCk7XG4gICAgfVxuXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zdCByZXN1bHRUZXh0ID0gZGF0YS5jaG9pY2VzPy5bMF0/Lm1lc3NhZ2U/LmNvbnRlbnQ7XG4gICAgaWYgKCFyZXN1bHRUZXh0KSByZXR1cm4gaGV1cmlzdGljQW5hbHlzaXMoY29udGVudCk7XG5cbiAgICBjb25zdCBqc29uTWF0Y2ggPSByZXN1bHRUZXh0Lm1hdGNoKC9cXHtbXn1dKlxcfS9zKTtcbiAgICBpZiAoIWpzb25NYXRjaCkgcmV0dXJuIGhldXJpc3RpY0FuYWx5c2lzKGNvbnRlbnQpO1xuXG4gICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShqc29uTWF0Y2hbMF0pO1xuICAgIHJldHVybiB7XG4gICAgICB2ZXJkaWN0OiBwYXJzZWQudmVyZGljdCB8fCBcInVuY2VydGFpblwiLFxuICAgICAgY29uZmlkZW5jZTogTWF0aC5taW4oMSwgTWF0aC5tYXgoMCwgcGFyc2VkLmNvbmZpZGVuY2UgfHwgMCkpLFxuICAgICAgY2F0ZWdvcnk6IHBhcnNlZC5jYXRlZ29yeSB8fCBcIm5vbmVcIixcbiAgICAgIHJlYXNvbjogKHBhcnNlZC5yZWFzb24gfHwgXCLQkNC90LDQu9C40Lcg0LfQsNCy0LXRgNGI0ZHQvVwiKS5zdWJzdHJpbmcoMCwgMjAwKSxcbiAgICB9O1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUud2FybihcIlthbmFseXplLXJlcG9ydF0gQUkgYW5hbHlzaXMgZmFpbGVkOlwiLCBlcnJvcik7XG4gICAgcmV0dXJuIGhldXJpc3RpY0FuYWx5c2lzKGNvbnRlbnQpO1xuICB9XG59XG5cbi8qKlxuICogRmFsbGJhY2sgaGV1cmlzdGljIHdoZW4gQUkgaXMgdW5hdmFpbGFibGVcbiAqL1xuZnVuY3Rpb24gaGV1cmlzdGljQW5hbHlzaXMoY29udGVudDogc3RyaW5nKTogQUlBbmFseXNpc1Jlc3VsdCB7XG4gIGNvbnN0IGxvd2VyQ29udGVudCA9IGNvbnRlbnQudG9Mb3dlckNhc2UoKTtcblxuICAvLyBCYXNpYyBwcm9mYW5pdHkgY2hlY2sgKHNhbWUgd29yZHMgYXMgc3RvcHdvcmRzIGxpc3QpXG4gIGNvbnN0IHByb2Zhbml0eVBhdHRlcm5zID0gW1xuICAgIC9cXGLQsdC70Y9b0LTRgtGMXT9cXGIvaSxcbiAgICAvXFxi0YXRg9C5L2ksXG4gICAgL1xcYtC/0LjQt9C0L2ksXG4gICAgL1xcYtC10LHQu1vQsNC+0Y9dL2ksXG4gICAgL1xcYtGB0YPQutCwP1xcYi9pLFxuICAgIC9cXGLQvNGD0LTQsFvQutGHXS9pLFxuICAgIC9cXGLQs9Cw0L3QtNC+0L0vaSxcbiAgICAvXFxi0LTQvtC70LHQvlvQtdGRXdCxL2ksXG4gICAgL1xcYtC00LXQsdC40LsvaSxcbiAgICAvXFxi0LjQtNC40L7Rgi9pLFxuICAgIC9cXGLRgtGD0L/QvtC5L2ksXG4gICAgL1xcYtGD0YDQvtC0L2ksXG4gIF07XG5cbiAgY29uc3QgbWF0Y2hlZCA9IHByb2Zhbml0eVBhdHRlcm5zLmZpbHRlcigocCkgPT4gcC50ZXN0KGxvd2VyQ29udGVudCkpO1xuXG4gIGlmIChtYXRjaGVkLmxlbmd0aCA+PSAyKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHZlcmRpY3Q6IFwidmlvbGF0aW9uXCIsXG4gICAgICBjb25maWRlbmNlOiAwLjg1LFxuICAgICAgY2F0ZWdvcnk6IFwidG94aWNpdHlcIixcbiAgICAgIHJlYXNvbjogXCLQntCx0L3QsNGA0YPQttC10L3QsCDQvdC10YbQtdC90LfRg9GA0L3QsNGPINC70LXQutGB0LjQutCwICjRjdCy0YDQuNGB0YLQuNC60LApXCIsXG4gICAgfTtcbiAgfVxuXG4gIGlmIChtYXRjaGVkLmxlbmd0aCA9PT0gMSkge1xuICAgIHJldHVybiB7XG4gICAgICB2ZXJkaWN0OiBcInVuY2VydGFpblwiLFxuICAgICAgY29uZmlkZW5jZTogMC42LFxuICAgICAgY2F0ZWdvcnk6IFwidG94aWNpdHlcIixcbiAgICAgIHJlYXNvbjogXCLQktC+0LfQvNC+0LbQvdCw0Y8g0L3QtdGG0LXQvdC30YPRgNC90LDRjyDQu9C10LrRgdC40LrQsCAo0YLRgNC10LHRg9C10YIg0YDRg9GH0L3QvtC5INC/0YDQvtCy0LXRgNC60LgpXCIsXG4gICAgfTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgdmVyZGljdDogXCJ1bmNlcnRhaW5cIixcbiAgICBjb25maWRlbmNlOiAwLjMsXG4gICAgY2F0ZWdvcnk6IFwibm9uZVwiLFxuICAgIHJlYXNvbjogXCLQkNCy0YLQvtC80LDRgtC40YfQtdGB0LrQuNC5INCw0L3QsNC70LjQtyDQvdC1INC+0LHQvdCw0YDRg9C20LjQuyDRj9Cy0L3Ri9GFINC90LDRgNGD0YjQtdC90LjQuVwiLFxuICB9O1xufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztDQVdDLEdBRUQsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQ0U7QUFDSjtBQUVBLE1BQU0sMEJBQTBCO0FBTWhDLEtBQUssS0FBSyxDQUFDLE9BQU87RUFDaEIsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxXQUFXLGFBQ2YsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGlCQUNiLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUdmLE1BQU0sRUFBRSxRQUFRLEVBQUUsR0FBbUIsTUFBTSxJQUFJLElBQUk7SUFDbkQsSUFBSSxDQUFDLFVBQVU7TUFDYixPQUFPLGFBQWE7UUFBRSxPQUFPO01BQW9CLEdBQUc7SUFDdEQ7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLG1DQUFtQyxFQUFFLFNBQVMsQ0FBQztJQUU1RCw0QkFBNEI7SUFDNUIsTUFBTSxFQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUNoRCxJQUFJLENBQUMsaUJBQ0wsTUFBTSxDQUFDLEtBQ1AsRUFBRSxDQUFDLE1BQU0sVUFDVCxXQUFXO0lBRWQsSUFBSSxlQUFlLENBQUMsUUFBUTtNQUMxQixRQUFRLEtBQUssQ0FBQyxzQ0FBc0M7TUFDcEQsT0FBTyxhQUFhO1FBQUUsT0FBTztNQUFtQixHQUFHO0lBQ3JEO0lBRUEsSUFBSSxPQUFPLE1BQU0sS0FBSyxXQUFXO01BQy9CLFFBQVEsR0FBRyxDQUFDO01BQ1osT0FBTyxhQUFhO1FBQUUsUUFBUTtRQUFXLFFBQVE7TUFBb0I7SUFDdkU7SUFFQSxzQ0FBc0M7SUFDdEMsSUFBSSxjQUFjO0lBQ2xCLElBQUksa0JBQWlDO0lBQ3JDLElBQUksZUFBOEI7SUFFbEMsSUFBSSxPQUFPLE9BQU8sRUFBRTtNQUNsQixNQUFNLEVBQUUsTUFBTSxJQUFJLEVBQUUsR0FBRyxNQUFNLFNBQzFCLElBQUksQ0FBQyxlQUNMLE1BQU0sQ0FBQyxvQkFDUCxFQUFFLENBQUMsTUFBTSxPQUFPLE9BQU8sRUFDdkIsV0FBVztNQUVkLElBQUksTUFBTTtRQUNSLGNBQWMsS0FBSyxPQUFPO1FBQzFCLGtCQUFrQixLQUFLLE9BQU87TUFDaEM7SUFDRixPQUFPLElBQUksT0FBTyxRQUFRLEVBQUU7TUFDMUIsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLEdBQUcsTUFBTSxTQUMzQixJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDLDJCQUNQLEVBQUUsQ0FBQyxNQUFNLE9BQU8sUUFBUSxFQUN4QixXQUFXO01BRWQsSUFBSSxPQUFPO1FBQ1QsY0FBYyxDQUFDLEVBQUUsTUFBTSxLQUFLLENBQUMsSUFBSSxFQUFFLE1BQU0sT0FBTyxDQUFDLENBQUM7UUFDbEQsZUFBZSxNQUFNLEtBQUs7UUFDMUIsa0JBQWtCLE1BQU0sT0FBTztNQUNqQztJQUNGO0lBRUEsSUFBSSxDQUFDLGFBQWE7TUFDaEIsUUFBUSxJQUFJLENBQUM7TUFDYixNQUFNLFNBQ0gsSUFBSSxDQUFDLGlCQUNMLE1BQU0sQ0FBQztRQUNOLFlBQVk7UUFDWixXQUFXO1FBQ1gsZ0JBQWdCO01BQ2xCLEdBQ0MsRUFBRSxDQUFDLE1BQU07TUFDWixPQUFPLGFBQWE7UUFBRSxRQUFRO1FBQVMsUUFBUTtNQUFvQjtJQUNyRTtJQUVBLDRDQUE0QztJQUM1QyxNQUFNLFdBQVcsWUFBWSxTQUFTLENBQUMsR0FBRztJQUUxQywwQkFBMEI7SUFDMUIsTUFBTSxFQUFFLE1BQU0sUUFBUSxFQUFFLEdBQUcsTUFBTSxTQUM5QixJQUFJLENBQUMsMEJBQ0wsTUFBTSxDQUFDLGNBQ1AsRUFBRSxDQUFDLE9BQU87TUFBQztNQUFpQjtLQUFxQjtJQUVwRCxNQUFNLGNBQW1DLENBQUM7SUFDMUMsQ0FBQyxZQUFZLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztNQUN4QixXQUFXLENBQUMsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLEtBQUs7SUFDOUI7SUFFQSxNQUFNLFdBQVcsV0FBVyxDQUFDLGdCQUFnQixJQUFJLENBQUM7SUFDbEQsTUFBTSxlQUFlLFdBQVcsQ0FBQyxxQkFBcUIsSUFBSSxDQUFDO0lBQzNELE1BQU0sc0JBQXNCLGFBQWEsb0JBQW9CLElBQUk7SUFDakUsTUFBTSxvQkFBb0IsYUFBYSxPQUFPLEtBQUssT0FBTyxlQUFlO0lBQ3pFLE1BQU0sa0JBQWtCLGFBQWEsU0FBUyxLQUFLLE9BQU8sZUFBZTtJQUV6RSwyQkFBMkI7SUFDM0IsTUFBTSxXQUFXLE1BQU0sY0FBYyxhQUFhLE9BQU8sTUFBTSxFQUFFLE9BQU8sT0FBTztJQUUvRSxRQUFRLEdBQUcsQ0FDVCxDQUFDLDZCQUE2QixFQUFFLFNBQVMsT0FBTyxDQUFDLGNBQWMsRUFBRSxTQUFTLFVBQVUsQ0FBQyxZQUFZLEVBQUUsU0FBUyxRQUFRLENBQUMsQ0FBQztJQUd4SCx3Q0FBd0M7SUFDeEMsTUFBTSxTQUNILElBQUksQ0FBQyxpQkFDTCxNQUFNLENBQUM7TUFDTixZQUFZLFNBQVMsT0FBTztNQUM1QixlQUFlLFNBQVMsVUFBVTtNQUNsQyxhQUFhLFNBQVMsUUFBUTtNQUM5QixXQUFXLFNBQVMsTUFBTTtNQUMxQixrQkFBa0I7TUFDbEIsZ0JBQWdCO0lBQ2xCLEdBQ0MsRUFBRSxDQUFDLE1BQU07SUFFWiw4Q0FBOEM7SUFDOUMsSUFBSSxjQUFjO0lBQ2xCLElBQUksT0FBTyxPQUFPLEVBQUU7TUFDbEIsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sU0FDckIsSUFBSSxDQUFDLGlCQUNMLE1BQU0sQ0FBQyxLQUFLO1FBQUUsT0FBTztRQUFTLE1BQU07TUFBSyxHQUN6QyxFQUFFLENBQUMsV0FBVyxPQUFPLE9BQU8sRUFDNUIsRUFBRSxDQUFDLFVBQVU7TUFDaEIsY0FBYyxTQUFTO0lBQ3pCLE9BQU8sSUFBSSxPQUFPLFFBQVEsRUFBRTtNQUMxQixNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxTQUNyQixJQUFJLENBQUMsaUJBQ0wsTUFBTSxDQUFDLEtBQUs7UUFBRSxPQUFPO1FBQVMsTUFBTTtNQUFLLEdBQ3pDLEVBQUUsQ0FBQyxZQUFZLE9BQU8sUUFBUSxFQUM5QixFQUFFLENBQUMsV0FBVyxNQUNkLEVBQUUsQ0FBQyxVQUFVO01BQ2hCLGNBQWMsU0FBUztJQUN6QjtJQUVBLCtEQUErRDtJQUMvRCxNQUFNLG1CQUNKLHFCQUNBLFNBQVMsT0FBTyxLQUFLLGVBQ3JCLENBQUMsU0FBUyxVQUFVLElBQUksdUJBQXVCLGVBQWUsQ0FBQztJQUVqRSxJQUFJLG9CQUFvQixpQkFBaUI7TUFDdkMsUUFBUSxHQUFHLENBQ1QsQ0FBQyw0Q0FBNEMsRUFBRSxTQUFTLFVBQVUsQ0FBQyxjQUFjLEVBQUUsWUFBWSxDQUFDO01BR2xHLGVBQWU7TUFDZixNQUFNLFFBQVEsT0FBTyxPQUFPLEdBQUcsZ0JBQWdCO01BQy9DLE1BQU0sV0FBVyxPQUFPLE9BQU8sSUFBSSxPQUFPLFFBQVE7TUFFbEQsTUFBTSxTQUNILElBQUksQ0FBQyxPQUNMLE1BQU0sQ0FBQztRQUNOLFdBQVc7UUFDWCxXQUFXO1FBQ1gsV0FBVyxJQUFJLE9BQU8sV0FBVztRQUNqQyxlQUFlLENBQUMsY0FBYyxFQUFFLFNBQVMsTUFBTSxDQUFDLENBQUM7TUFDbkQsR0FDQyxFQUFFLENBQUMsTUFBTTtNQUVaLDBCQUEwQjtNQUMxQixNQUFNLFNBQ0gsSUFBSSxDQUFDLGlCQUNMLE1BQU0sQ0FBQztRQUNOLFFBQVE7UUFDUixpQkFBaUIsQ0FBQyxtQkFBbUIsRUFBRSxTQUFTLFFBQVEsQ0FBQyxFQUFFLEVBQUUsS0FBSyxLQUFLLENBQUMsU0FBUyxVQUFVLEdBQUcsS0FBSyxFQUFFLENBQUM7UUFDdEcsYUFBYTtRQUNiLGFBQWEsSUFBSSxPQUFPLFdBQVc7UUFDbkMsZUFBZTtNQUNqQixHQUNDLEVBQUUsQ0FBQyxNQUFNO01BRVosaURBQWlEO01BQ2pELElBQUksaUJBQWlCO1FBQ25CLE1BQU0saUJBQWlCLFlBQVksU0FBUyxDQUFDLEdBQUc7UUFDaEQsTUFBTSxnQkFBZ0IsQ0FBQyx3RUFBd0UsRUFBRSxpQkFBaUIsU0FBUyxRQUFRLEVBQUUsV0FBVyxFQUFFLGVBQWUsQ0FBQyxFQUFFLGVBQWUsTUFBTSxHQUFHLFlBQVksTUFBTSxHQUFHLFFBQVEsR0FBRyxDQUFDO1FBRTdOLCtCQUErQjtRQUMvQixNQUFNLEVBQUUsTUFBTSxhQUFhLEVBQUUsR0FBRyxNQUFNLFNBQ25DLElBQUksQ0FBQywwQkFDTCxNQUFNLENBQUMsU0FDUCxFQUFFLENBQUMsT0FBTyxvQkFDVixXQUFXO1FBQ2QsTUFBTSxhQUFhLGdCQUFnQixPQUFPLGNBQWMsS0FBSyxJQUFJO1FBQ2pFLE1BQU0sWUFBWSxJQUFJLEtBQUssS0FBSyxHQUFHLEtBQUssYUFBYSxVQUFVLFdBQVc7UUFFMUUsTUFBTSxTQUFTLElBQUksQ0FBQyxrQkFBa0IsTUFBTSxDQUFDO1VBQzNDLFNBQVM7VUFDVCxXQUFXO1VBQ1gsUUFBUTtVQUNSLFVBQVUsU0FBUyxVQUFVLElBQUksTUFBTSxZQUFZO1VBQ25ELFlBQVk7VUFDWixTQUFTLE9BQU8sT0FBTyxJQUFJO1VBQzNCLFVBQVUsT0FBTyxRQUFRLElBQUk7UUFDL0I7UUFFQSxxQ0FBcUM7UUFDckMsTUFBTSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxTQUNoQyxJQUFJLENBQUMsa0JBQ0wsTUFBTSxDQUFDLEtBQUs7VUFBRSxPQUFPO1VBQVMsTUFBTTtRQUFLLEdBQ3pDLEVBQUUsQ0FBQyxXQUFXLGlCQUNkLEVBQUUsQ0FBQyxhQUFhO1FBRW5CLE1BQU0sU0FDSCxJQUFJLENBQUMsb0JBQ0wsTUFBTSxDQUFDO1VBQ04sZ0JBQWdCLGFBQWE7VUFDN0IsWUFBWSxJQUFJLE9BQU8sV0FBVztRQUNwQyxHQUNDLEVBQUUsQ0FBQyxXQUFXO01BQ25CO01BRUEsaUJBQWlCO01BQ2pCLE1BQU0sU0FBUyxJQUFJLENBQUMsa0JBQWtCLE1BQU0sQ0FBQztRQUMzQztVQUNFLGNBQWM7VUFDZCxRQUFRO1VBQ1IsYUFBYSxPQUFPLE9BQU8sR0FBRyxTQUFTO1VBQ3ZDLFdBQVcsT0FBTyxPQUFPLElBQUksT0FBTyxRQUFRO1VBQzVDLFNBQVM7WUFDUCxXQUFXO1lBQ1gsWUFBWSxTQUFTLE9BQU87WUFDNUIsZUFBZSxTQUFTLFVBQVU7WUFDbEMsYUFBYSxTQUFTLFFBQVE7WUFDOUIsY0FBYztZQUNkLGFBQWE7WUFDYixXQUFXO1VBQ2I7UUFDRjtPQUNEO01BRUQsT0FBTyxhQUFhO1FBQ2xCLFFBQVE7UUFDUixTQUFTLFNBQVMsT0FBTztRQUN6QixZQUFZLFNBQVMsVUFBVTtRQUMvQixVQUFVLFNBQVMsUUFBUTtRQUMzQixRQUFRO1FBQ1IsUUFBUTtNQUNWO0lBQ0Y7SUFFQSxPQUFPLGFBQWE7TUFDbEIsUUFBUTtNQUNSLFNBQVMsU0FBUyxPQUFPO01BQ3pCLFlBQVksU0FBUyxVQUFVO01BQy9CLFVBQVUsU0FBUyxRQUFRO01BQzNCLGVBQWU7SUFDakI7RUFDRixFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLDJCQUEyQjtJQUN6QyxPQUFPLGFBQ0w7TUFBRSxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQWdCLEdBQ2xFO0VBRUo7QUFDRjtBQUVBLGdCQUFnQjtBQUVoQixTQUFTLGFBQWEsSUFBUyxFQUFFLFNBQVMsR0FBRztFQUMzQyxPQUFPLElBQUksU0FBUyxLQUFLLFNBQVMsQ0FBQyxPQUFPO0lBQ3hDO0lBQ0EsU0FBUztNQUFFLEdBQUcsV0FBVztNQUFFLGdCQUFnQjtJQUFtQjtFQUNoRTtBQUNGO0FBRUEsU0FBUyxpQkFBaUIsUUFBZ0I7RUFDeEMsTUFBTSxTQUFpQztJQUNyQyxVQUFVO0lBQ1YsTUFBTTtJQUNOLFNBQVM7SUFDVCxNQUFNO0lBQ04sT0FBTztJQUNQLFVBQVU7SUFDVixXQUFXO0lBQ1gsTUFBTTtFQUNSO0VBQ0EsT0FBTyxNQUFNLENBQUMsU0FBUyxJQUFJO0FBQzdCO0FBU0EsZUFBZSxjQUNiLE9BQWUsRUFDZixZQUFvQixFQUNwQixhQUE0QjtFQUU1QixNQUFNLGdCQUFnQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFDbkMsSUFBSSxDQUFDLGVBQWU7SUFDbEIsUUFBUSxJQUFJLENBQUM7SUFDYixPQUFPLGtCQUFrQjtFQUMzQjtFQUVBLE1BQU0sZUFBZSxDQUFDOztpQkFFUCxFQUFFLGFBQWE7QUFDaEMsRUFBRSxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsY0FBYyxDQUFDLENBQUMsR0FBRyxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxS0FvQmlILENBQUM7RUFFcEssSUFBSTtJQUNGLE1BQU0sU0FBUyxDQUFDLG1EQUFtRCxFQUFFLHdCQUF3QixvQkFBb0IsQ0FBQztJQUVsSCxNQUFNLFdBQVcsTUFBTSxNQUFNLFFBQVE7TUFDbkMsUUFBUTtNQUNSLFNBQVM7UUFDUCxnQkFBZ0I7UUFDaEIsZUFBZSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUM7TUFDMUM7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQ25CLE9BQU87UUFDUCxVQUFVO1VBQ1I7WUFBRSxNQUFNO1lBQVUsU0FBUztVQUFhO1VBQ3hDO1lBQUUsTUFBTTtZQUFRLFNBQVMsUUFBUSxTQUFTLENBQUMsR0FBRztVQUFNO1NBQ3JEO1FBQ0QsYUFBYTtRQUNiLFlBQVk7TUFDZDtJQUNGO0lBRUEsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLFFBQVEsSUFBSSxDQUFDLENBQUMscUNBQXFDLEVBQUUsU0FBUyxNQUFNLENBQUMsQ0FBQztNQUN0RSxPQUFPLGtCQUFrQjtJQUMzQjtJQUVBLE1BQU0sT0FBTyxNQUFNLFNBQVMsSUFBSTtJQUNoQyxNQUFNLGFBQWEsS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEVBQUUsU0FBUztJQUMvQyxJQUFJLENBQUMsWUFBWSxPQUFPLGtCQUFrQjtJQUUxQyxNQUFNLFlBQVksV0FBVyxLQUFLLENBQUM7SUFDbkMsSUFBSSxDQUFDLFdBQVcsT0FBTyxrQkFBa0I7SUFFekMsTUFBTSxTQUFTLEtBQUssS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFFO0lBQ3RDLE9BQU87TUFDTCxTQUFTLE9BQU8sT0FBTyxJQUFJO01BQzNCLFlBQVksS0FBSyxHQUFHLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQyxHQUFHLE9BQU8sVUFBVSxJQUFJO01BQ3pELFVBQVUsT0FBTyxRQUFRLElBQUk7TUFDN0IsUUFBUSxDQUFDLE9BQU8sTUFBTSxJQUFJLGlCQUFpQixFQUFFLFNBQVMsQ0FBQyxHQUFHO0lBQzVEO0VBQ0YsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLElBQUksQ0FBQyx3Q0FBd0M7SUFDckQsT0FBTyxrQkFBa0I7RUFDM0I7QUFDRjtBQUVBOztDQUVDLEdBQ0QsU0FBUyxrQkFBa0IsT0FBZTtFQUN4QyxNQUFNLGVBQWUsUUFBUSxXQUFXO0VBRXhDLHVEQUF1RDtFQUN2RCxNQUFNLG9CQUFvQjtJQUN4QjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDRDtFQUVELE1BQU0sVUFBVSxrQkFBa0IsTUFBTSxDQUFDLENBQUMsSUFBTSxFQUFFLElBQUksQ0FBQztFQUV2RCxJQUFJLFFBQVEsTUFBTSxJQUFJLEdBQUc7SUFDdkIsT0FBTztNQUNMLFNBQVM7TUFDVCxZQUFZO01BQ1osVUFBVTtNQUNWLFFBQVE7SUFDVjtFQUNGO0VBRUEsSUFBSSxRQUFRLE1BQU0sS0FBSyxHQUFHO0lBQ3hCLE9BQU87TUFDTCxTQUFTO01BQ1QsWUFBWTtNQUNaLFVBQVU7TUFDVixRQUFRO0lBQ1Y7RUFDRjtFQUVBLE9BQU87SUFDTCxTQUFTO0lBQ1QsWUFBWTtJQUNaLFVBQVU7SUFDVixRQUFRO0VBQ1Y7QUFDRiJ9
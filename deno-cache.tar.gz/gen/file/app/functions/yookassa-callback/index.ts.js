import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Helper function to verify YooKassa webhook signature
async function verifyWebhookSignature(body, signature, secretKey) {
  if (!signature) {
    return false;
  }
  // YooKassa uses HMAC-SHA256 for webhook signatures
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", encoder.encode(secretKey), {
    name: "HMAC",
    hash: "SHA-256"
  }, false, [
    "sign"
  ]);
  const signatureBuffer = await crypto.subtle.sign("HMAC", key, encoder.encode(body));
  // Convert to hex string
  const expectedSignature = Array.from(new Uint8Array(signatureBuffer)).map((b)=>b.toString(16).padStart(2, '0')).join('');
  // Constant-time comparison to prevent timing attacks
  if (signature.length !== expectedSignature.length) {
    return false;
  }
  let result = 0;
  for(let i = 0; i < signature.length; i++){
    result |= signature.charCodeAt(i) ^ expectedSignature.charCodeAt(i);
  }
  return result === 0;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const yookassaSecretKey = Deno.env.get("YOOKASSA_SECRET_KEY");
    // Get the raw body for signature verification
    const rawBody = await req.text();
    // Verify webhook signature - REQUIRED for security
    if (!yookassaSecretKey) {
      console.error("YOOKASSA_SECRET_KEY not configured - rejecting webhook request for security");
      return new Response(JSON.stringify({
        error: "Webhook secret not configured"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        },
        status: 500
      });
    }
    const signature = req.headers.get("X-YooKassa-Signature") || req.headers.get("x-yookassa-signature");
    const isValid = await verifyWebhookSignature(rawBody, signature, yookassaSecretKey);
    if (!isValid) {
      console.error("YooKassa webhook signature verification failed");
      return new Response(JSON.stringify({
        error: "Invalid webhook signature"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        },
        status: 401
      });
    }
    console.log("YooKassa webhook signature verified successfully");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const body = JSON.parse(rawBody);
    console.log("YooKassa webhook received:", JSON.stringify(body, null, 2));
    const { event, object } = body;
    if (!object || !object.id) {
      throw new Error("Invalid webhook payload");
    }
    // Find payment by external_id (YooKassa payment ID)
    const { data: payment, error: findError } = await supabase.from("payments").select("*").eq("external_id", object.id).eq("payment_system", "yookassa").single();
    if (findError || !payment) {
      console.error("Payment not found:", object.id);
      return new Response(JSON.stringify({
        error: "Payment not found"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        },
        status: 404
      });
    }
    let newStatus = payment.status;
    // Handle different YooKassa events
    switch(event){
      case "payment.succeeded":
        newStatus = "completed";
        break;
      case "payment.canceled":
        newStatus = "cancelled";
        break;
      case "payment.waiting_for_capture":
        newStatus = "pending";
        break;
      case "refund.succeeded":
        newStatus = "refunded";
        break;
      default:
        console.log("Unhandled event type:", event);
    }
    // Update payment status
    const { error: updateError } = await supabase.from("payments").update({
      status: newStatus,
      metadata: object,
      updated_at: new Date().toISOString()
    }).eq("id", payment.id);
    if (updateError) {
      console.error("Error updating payment:", updateError);
      throw new Error("Failed to update payment");
    }
    // Add balance to user profile if payment succeeded
    if (event === "payment.succeeded" && payment.status !== "completed") {
      const { data: profile, error: profileError } = await supabase.from("profiles").select("balance").eq("user_id", payment.user_id).single();
      if (!profileError && profile) {
        const newBalance = (profile.balance || 0) + payment.amount;
        await supabase.from("profiles").update({
          balance: newBalance
        }).eq("user_id", payment.user_id);
        // Log topup transaction
        await supabase.from("balance_transactions").insert({
          user_id: payment.user_id,
          amount: payment.amount,
          balance_after: newBalance,
          type: "topup",
          description: `Пополнение баланса (ЮKassa)`,
          reference_id: payment.id,
          reference_type: "payment"
        });
        console.log(`Balance updated for user ${payment.user_id}: ${newBalance}`);
      }
    }
    console.log("Payment updated:", payment.id, "Status:", newStatus);
    return new Response(JSON.stringify({
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 200
    });
  } catch (error) {
    console.error("YooKassa callback error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 500
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy95b29rYXNzYS1jYWxsYmFjay9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbi8vIEhlbHBlciBmdW5jdGlvbiB0byB2ZXJpZnkgWW9vS2Fzc2Egd2ViaG9vayBzaWduYXR1cmVcbmFzeW5jIGZ1bmN0aW9uIHZlcmlmeVdlYmhvb2tTaWduYXR1cmUoXG4gIGJvZHk6IHN0cmluZyxcbiAgc2lnbmF0dXJlOiBzdHJpbmcgfCBudWxsLFxuICBzZWNyZXRLZXk6IHN0cmluZ1xuKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGlmICghc2lnbmF0dXJlKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLy8gWW9vS2Fzc2EgdXNlcyBITUFDLVNIQTI1NiBmb3Igd2ViaG9vayBzaWduYXR1cmVzXG4gIGNvbnN0IGVuY29kZXIgPSBuZXcgVGV4dEVuY29kZXIoKTtcbiAgY29uc3Qga2V5ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5pbXBvcnRLZXkoXG4gICAgXCJyYXdcIixcbiAgICBlbmNvZGVyLmVuY29kZShzZWNyZXRLZXkpLFxuICAgIHsgbmFtZTogXCJITUFDXCIsIGhhc2g6IFwiU0hBLTI1NlwiIH0sXG4gICAgZmFsc2UsXG4gICAgW1wic2lnblwiXVxuICApO1xuXG4gIGNvbnN0IHNpZ25hdHVyZUJ1ZmZlciA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuc2lnbihcbiAgICBcIkhNQUNcIixcbiAgICBrZXksXG4gICAgZW5jb2Rlci5lbmNvZGUoYm9keSlcbiAgKTtcblxuICAvLyBDb252ZXJ0IHRvIGhleCBzdHJpbmdcbiAgY29uc3QgZXhwZWN0ZWRTaWduYXR1cmUgPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KHNpZ25hdHVyZUJ1ZmZlcikpXG4gICAgLm1hcChiID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG4gICAgLmpvaW4oJycpO1xuXG4gIC8vIENvbnN0YW50LXRpbWUgY29tcGFyaXNvbiB0byBwcmV2ZW50IHRpbWluZyBhdHRhY2tzXG4gIGlmIChzaWduYXR1cmUubGVuZ3RoICE9PSBleHBlY3RlZFNpZ25hdHVyZS5sZW5ndGgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBsZXQgcmVzdWx0ID0gMDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzaWduYXR1cmUubGVuZ3RoOyBpKyspIHtcbiAgICByZXN1bHQgfD0gc2lnbmF0dXJlLmNoYXJDb2RlQXQoaSkgXiBleHBlY3RlZFNpZ25hdHVyZS5jaGFyQ29kZUF0KGkpO1xuICB9XG5cbiAgcmV0dXJuIHJlc3VsdCA9PT0gMDtcbn1cblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBjb25zdCB5b29rYXNzYVNlY3JldEtleSA9IERlbm8uZW52LmdldChcIllPT0tBU1NBX1NFQ1JFVF9LRVlcIik7XG5cbiAgICAvLyBHZXQgdGhlIHJhdyBib2R5IGZvciBzaWduYXR1cmUgdmVyaWZpY2F0aW9uXG4gICAgY29uc3QgcmF3Qm9keSA9IGF3YWl0IHJlcS50ZXh0KCk7XG4gICAgXG4gICAgLy8gVmVyaWZ5IHdlYmhvb2sgc2lnbmF0dXJlIC0gUkVRVUlSRUQgZm9yIHNlY3VyaXR5XG4gICAgaWYgKCF5b29rYXNzYVNlY3JldEtleSkge1xuICAgICAgY29uc29sZS5lcnJvcihcIllPT0tBU1NBX1NFQ1JFVF9LRVkgbm90IGNvbmZpZ3VyZWQgLSByZWplY3Rpbmcgd2ViaG9vayByZXF1ZXN0IGZvciBzZWN1cml0eVwiKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiV2ViaG9vayBzZWNyZXQgbm90IGNvbmZpZ3VyZWRcIiB9KSxcbiAgICAgICAgeyBcbiAgICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgICAgIHN0YXR1czogNTAwIFxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHNpZ25hdHVyZSA9IHJlcS5oZWFkZXJzLmdldChcIlgtWW9vS2Fzc2EtU2lnbmF0dXJlXCIpIHx8IFxuICAgICAgICAgICAgICAgICAgICAgIHJlcS5oZWFkZXJzLmdldChcIngteW9va2Fzc2Etc2lnbmF0dXJlXCIpO1xuICAgIFxuICAgIGNvbnN0IGlzVmFsaWQgPSBhd2FpdCB2ZXJpZnlXZWJob29rU2lnbmF0dXJlKHJhd0JvZHksIHNpZ25hdHVyZSwgeW9va2Fzc2FTZWNyZXRLZXkpO1xuICAgIFxuICAgIGlmICghaXNWYWxpZCkge1xuICAgICAgY29uc29sZS5lcnJvcihcIllvb0thc3NhIHdlYmhvb2sgc2lnbmF0dXJlIHZlcmlmaWNhdGlvbiBmYWlsZWRcIik7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkludmFsaWQgd2ViaG9vayBzaWduYXR1cmVcIiB9KSxcbiAgICAgICAgeyBcbiAgICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgICAgIHN0YXR1czogNDAxIFxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgICBcbiAgICBjb25zb2xlLmxvZyhcIllvb0thc3NhIHdlYmhvb2sgc2lnbmF0dXJlIHZlcmlmaWVkIHN1Y2Nlc3NmdWxseVwiKTtcblxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgY29uc3QgYm9keSA9IEpTT04ucGFyc2UocmF3Qm9keSk7XG4gICAgY29uc29sZS5sb2coXCJZb29LYXNzYSB3ZWJob29rIHJlY2VpdmVkOlwiLCBKU09OLnN0cmluZ2lmeShib2R5LCBudWxsLCAyKSk7XG5cbiAgICBjb25zdCB7IGV2ZW50LCBvYmplY3QgfSA9IGJvZHk7XG5cbiAgICBpZiAoIW9iamVjdCB8fCAhb2JqZWN0LmlkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHdlYmhvb2sgcGF5bG9hZFwiKTtcbiAgICB9XG5cbiAgICAvLyBGaW5kIHBheW1lbnQgYnkgZXh0ZXJuYWxfaWQgKFlvb0thc3NhIHBheW1lbnQgSUQpXG4gICAgY29uc3QgeyBkYXRhOiBwYXltZW50LCBlcnJvcjogZmluZEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwYXltZW50c1wiKVxuICAgICAgLnNlbGVjdChcIipcIilcbiAgICAgIC5lcShcImV4dGVybmFsX2lkXCIsIG9iamVjdC5pZClcbiAgICAgIC5lcShcInBheW1lbnRfc3lzdGVtXCIsIFwieW9va2Fzc2FcIilcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmIChmaW5kRXJyb3IgfHwgIXBheW1lbnQpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJQYXltZW50IG5vdCBmb3VuZDpcIiwgb2JqZWN0LmlkKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiUGF5bWVudCBub3QgZm91bmRcIiB9KSxcbiAgICAgICAgeyBcbiAgICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgICAgIHN0YXR1czogNDA0IFxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGxldCBuZXdTdGF0dXMgPSBwYXltZW50LnN0YXR1cztcblxuICAgIC8vIEhhbmRsZSBkaWZmZXJlbnQgWW9vS2Fzc2EgZXZlbnRzXG4gICAgc3dpdGNoIChldmVudCkge1xuICAgICAgY2FzZSBcInBheW1lbnQuc3VjY2VlZGVkXCI6XG4gICAgICAgIG5ld1N0YXR1cyA9IFwiY29tcGxldGVkXCI7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcInBheW1lbnQuY2FuY2VsZWRcIjpcbiAgICAgICAgbmV3U3RhdHVzID0gXCJjYW5jZWxsZWRcIjtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwicGF5bWVudC53YWl0aW5nX2Zvcl9jYXB0dXJlXCI6XG4gICAgICAgIG5ld1N0YXR1cyA9IFwicGVuZGluZ1wiO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJyZWZ1bmQuc3VjY2VlZGVkXCI6XG4gICAgICAgIG5ld1N0YXR1cyA9IFwicmVmdW5kZWRcIjtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBjb25zb2xlLmxvZyhcIlVuaGFuZGxlZCBldmVudCB0eXBlOlwiLCBldmVudCk7XG4gICAgfVxuXG4gICAgLy8gVXBkYXRlIHBheW1lbnQgc3RhdHVzXG4gICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInBheW1lbnRzXCIpXG4gICAgICAudXBkYXRlKHsgXG4gICAgICAgIHN0YXR1czogbmV3U3RhdHVzLFxuICAgICAgICBtZXRhZGF0YTogb2JqZWN0LFxuICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgIH0pXG4gICAgICAuZXEoXCJpZFwiLCBwYXltZW50LmlkKTtcblxuICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHBheW1lbnQ6XCIsIHVwZGF0ZUVycm9yKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgcGF5bWVudFwiKTtcbiAgICB9XG5cbiAgICAvLyBBZGQgYmFsYW5jZSB0byB1c2VyIHByb2ZpbGUgaWYgcGF5bWVudCBzdWNjZWVkZWRcbiAgICBpZiAoZXZlbnQgPT09IFwicGF5bWVudC5zdWNjZWVkZWRcIiAmJiBwYXltZW50LnN0YXR1cyAhPT0gXCJjb21wbGV0ZWRcIikge1xuICAgICAgY29uc3QgeyBkYXRhOiBwcm9maWxlLCBlcnJvcjogcHJvZmlsZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgcGF5bWVudC51c2VyX2lkKVxuICAgICAgICAuc2luZ2xlKCk7XG5cbiAgICAgIGlmICghcHJvZmlsZUVycm9yICYmIHByb2ZpbGUpIHtcbiAgICAgICAgY29uc3QgbmV3QmFsYW5jZSA9IChwcm9maWxlLmJhbGFuY2UgfHwgMCkgKyBwYXltZW50LmFtb3VudDtcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IG5ld0JhbGFuY2UgfSlcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHBheW1lbnQudXNlcl9pZCk7XG4gICAgICAgIFxuICAgICAgICAvLyBMb2cgdG9wdXAgdHJhbnNhY3Rpb25cbiAgICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcImJhbGFuY2VfdHJhbnNhY3Rpb25zXCIpLmluc2VydCh7XG4gICAgICAgICAgdXNlcl9pZDogcGF5bWVudC51c2VyX2lkLFxuICAgICAgICAgIGFtb3VudDogcGF5bWVudC5hbW91bnQsXG4gICAgICAgICAgYmFsYW5jZV9hZnRlcjogbmV3QmFsYW5jZSxcbiAgICAgICAgICB0eXBlOiBcInRvcHVwXCIsXG4gICAgICAgICAgZGVzY3JpcHRpb246IGDQn9C+0L/QvtC70L3QtdC90LjQtSDQsdCw0LvQsNC90YHQsCAo0K5LYXNzYSlgLFxuICAgICAgICAgIHJlZmVyZW5jZV9pZDogcGF5bWVudC5pZCxcbiAgICAgICAgICByZWZlcmVuY2VfdHlwZTogXCJwYXltZW50XCIsXG4gICAgICAgIH0pO1xuICAgICAgICBcbiAgICAgICAgY29uc29sZS5sb2coYEJhbGFuY2UgdXBkYXRlZCBmb3IgdXNlciAke3BheW1lbnQudXNlcl9pZH06ICR7bmV3QmFsYW5jZX1gKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhcIlBheW1lbnQgdXBkYXRlZDpcIiwgcGF5bWVudC5pZCwgXCJTdGF0dXM6XCIsIG5ld1N0YXR1cyk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiB0cnVlIH0pLFxuICAgICAge1xuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgICBzdGF0dXM6IDIwMCxcbiAgICAgIH1cbiAgICApO1xuICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJZb29LYXNzYSBjYWxsYmFjayBlcnJvcjpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBtZXNzYWdlIH0pLFxuICAgICAge1xuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgICBzdGF0dXM6IDUwMCxcbiAgICAgIH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsdURBQXVEO0FBQ3ZELGVBQWUsdUJBQ2IsSUFBWSxFQUNaLFNBQXdCLEVBQ3hCLFNBQWlCO0VBRWpCLElBQUksQ0FBQyxXQUFXO0lBQ2QsT0FBTztFQUNUO0VBRUEsbURBQW1EO0VBQ25ELE1BQU0sVUFBVSxJQUFJO0VBQ3BCLE1BQU0sTUFBTSxNQUFNLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FDdkMsT0FDQSxRQUFRLE1BQU0sQ0FBQyxZQUNmO0lBQUUsTUFBTTtJQUFRLE1BQU07RUFBVSxHQUNoQyxPQUNBO0lBQUM7R0FBTztFQUdWLE1BQU0sa0JBQWtCLE1BQU0sT0FBTyxNQUFNLENBQUMsSUFBSSxDQUM5QyxRQUNBLEtBQ0EsUUFBUSxNQUFNLENBQUM7RUFHakIsd0JBQXdCO0VBQ3hCLE1BQU0sb0JBQW9CLE1BQU0sSUFBSSxDQUFDLElBQUksV0FBVyxrQkFDakQsR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxHQUFHLE1BQ3BDLElBQUksQ0FBQztFQUVSLHFEQUFxRDtFQUNyRCxJQUFJLFVBQVUsTUFBTSxLQUFLLGtCQUFrQixNQUFNLEVBQUU7SUFDakQsT0FBTztFQUNUO0VBRUEsSUFBSSxTQUFTO0VBQ2IsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsTUFBTSxFQUFFLElBQUs7SUFDekMsVUFBVSxVQUFVLFVBQVUsQ0FBQyxLQUFLLGtCQUFrQixVQUFVLENBQUM7RUFDbkU7RUFFQSxPQUFPLFdBQVc7QUFDcEI7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLG9CQUFvQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFFdkMsOENBQThDO0lBQzlDLE1BQU0sVUFBVSxNQUFNLElBQUksSUFBSTtJQUU5QixtREFBbUQ7SUFDbkQsSUFBSSxDQUFDLG1CQUFtQjtNQUN0QixRQUFRLEtBQUssQ0FBQztNQUNkLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFnQyxJQUN4RDtRQUNFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7UUFDOUQsUUFBUTtNQUNWO0lBRUo7SUFFQSxNQUFNLFlBQVksSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLDJCQUNoQixJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFFbEMsTUFBTSxVQUFVLE1BQU0sdUJBQXVCLFNBQVMsV0FBVztJQUVqRSxJQUFJLENBQUMsU0FBUztNQUNaLFFBQVEsS0FBSyxDQUFDO01BQ2QsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTRCLElBQ3BEO1FBQ0UsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtRQUM5RCxRQUFRO01BQ1Y7SUFFSjtJQUVBLFFBQVEsR0FBRyxDQUFDO0lBRVosTUFBTSxXQUFXLGFBQWEsYUFBYTtJQUUzQyxNQUFNLE9BQU8sS0FBSyxLQUFLLENBQUM7SUFDeEIsUUFBUSxHQUFHLENBQUMsOEJBQThCLEtBQUssU0FBUyxDQUFDLE1BQU0sTUFBTTtJQUVyRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHO0lBRTFCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEVBQUU7TUFDekIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxvREFBb0Q7SUFDcEQsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxTQUMvQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsS0FDUCxFQUFFLENBQUMsZUFBZSxPQUFPLEVBQUUsRUFDM0IsRUFBRSxDQUFDLGtCQUFrQixZQUNyQixNQUFNO0lBRVQsSUFBSSxhQUFhLENBQUMsU0FBUztNQUN6QixRQUFRLEtBQUssQ0FBQyxzQkFBc0IsT0FBTyxFQUFFO01BQzdDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFvQixJQUM1QztRQUNFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7UUFDOUQsUUFBUTtNQUNWO0lBRUo7SUFFQSxJQUFJLFlBQVksUUFBUSxNQUFNO0lBRTlCLG1DQUFtQztJQUNuQyxPQUFRO01BQ04sS0FBSztRQUNILFlBQVk7UUFDWjtNQUNGLEtBQUs7UUFDSCxZQUFZO1FBQ1o7TUFDRixLQUFLO1FBQ0gsWUFBWTtRQUNaO01BQ0YsS0FBSztRQUNILFlBQVk7UUFDWjtNQUNGO1FBQ0UsUUFBUSxHQUFHLENBQUMseUJBQXlCO0lBQ3pDO0lBRUEsd0JBQXdCO0lBQ3hCLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO01BQ04sUUFBUTtNQUNSLFVBQVU7TUFDVixZQUFZLElBQUksT0FBTyxXQUFXO0lBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sUUFBUSxFQUFFO0lBRXRCLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLDJCQUEyQjtNQUN6QyxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLG1EQUFtRDtJQUNuRCxJQUFJLFVBQVUsdUJBQXVCLFFBQVEsTUFBTSxLQUFLLGFBQWE7TUFDbkUsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLE9BQU8sWUFBWSxFQUFFLEdBQUcsTUFBTSxTQUNsRCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxRQUFRLE9BQU8sRUFDN0IsTUFBTTtNQUVULElBQUksQ0FBQyxnQkFBZ0IsU0FBUztRQUM1QixNQUFNLGFBQWEsQ0FBQyxRQUFRLE9BQU8sSUFBSSxDQUFDLElBQUksUUFBUSxNQUFNO1FBQzFELE1BQU0sU0FDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7VUFBRSxTQUFTO1FBQVcsR0FDN0IsRUFBRSxDQUFDLFdBQVcsUUFBUSxPQUFPO1FBRWhDLHdCQUF3QjtRQUN4QixNQUFNLFNBQVMsSUFBSSxDQUFDLHdCQUF3QixNQUFNLENBQUM7VUFDakQsU0FBUyxRQUFRLE9BQU87VUFDeEIsUUFBUSxRQUFRLE1BQU07VUFDdEIsZUFBZTtVQUNmLE1BQU07VUFDTixhQUFhLENBQUMsMkJBQTJCLENBQUM7VUFDMUMsY0FBYyxRQUFRLEVBQUU7VUFDeEIsZ0JBQWdCO1FBQ2xCO1FBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBRSxRQUFRLE9BQU8sQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDO01BQzFFO0lBQ0Y7SUFFQSxRQUFRLEdBQUcsQ0FBQyxvQkFBb0IsUUFBUSxFQUFFLEVBQUUsV0FBVztJQUV2RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLFNBQVM7SUFBSyxJQUMvQjtNQUNFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7TUFDOUQsUUFBUTtJQUNWO0VBRUosRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDRCQUE0QjtJQUMxQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFDRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO01BQzlELFFBQVE7SUFDVjtFQUVKO0FBQ0YifQ==
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import nodemailer from "npm:nodemailer@6.9.10";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const APP_NAME = "AI Planet Sound";
const APP_URL = "https://aiplanetsound.lovable.app";
function wrapInTemplate(bodyHtml, senderType, unsubscribeUrl) {
  const senderLabel = senderType === "personal" ? "Личное сообщение от администратора" : APP_NAME;
  return `
    <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); border-radius: 16px; overflow: hidden; color: #e0e0e0;">
      <div style="padding: 32px 24px 16px; text-align: center;">
        <h1 style="color: #a78bfa; font-size: 24px; margin: 0;">🎵 ${APP_NAME}</h1>
        <p style="font-size: 12px; color: #888; margin-top: 4px;">${senderLabel}</p>
      </div>
      <div style="padding: 16px 24px 32px;">
        ${bodyHtml}
      </div>
      <div style="padding: 16px 24px 24px; text-align: center; font-size: 12px; color: #666; border-top: 1px solid rgba(255,255,255,0.05);">
        <p>Это письмо от ${APP_NAME}.</p>
        ${unsubscribeUrl ? `<p><a href="${unsubscribeUrl}" style="color: #888; text-decoration: underline;">Отписаться от рассылки</a></p>` : ""}
      </div>
    </div>
  `;
}
async function sendEmail(to, subject, html) {
  const transporter = nodemailer.createTransport({
    host: Deno.env.get("SMTP_HOST"),
    port: parseInt(Deno.env.get("SMTP_PORT") || "465"),
    secure: true,
    auth: {
      user: Deno.env.get("SMTP_USER"),
      pass: Deno.env.get("SMTP_PASS")
    }
  });
  await transporter.sendMail({
    from: `"${APP_NAME}" <${Deno.env.get("SMTP_USER")}>`,
    to,
    subject,
    html
  });
}
Deno.serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // Verify admin
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    // Verify the caller is admin
    const userClient = createClient(supabaseUrl, anonKey, {
      global: {
        headers: {
          Authorization: authHeader
        }
      },
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });
    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const adminClient = createClient(supabaseUrl, serviceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });
    // Check admin role
    const { data: roleCheck } = await adminClient.rpc("has_role", {
      _user_id: user.id,
      _role: "admin"
    });
    const { data: superCheck } = await adminClient.rpc("has_role", {
      _user_id: user.id,
      _role: "super_admin"
    });
    if (!roleCheck && !superCheck) {
      return new Response(JSON.stringify({
        error: "Forbidden"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const body = await req.json();
    const { action } = body;
    // ---- SEND EMAIL ----
    if (action === "send") {
      const { recipients, subject, body_html, sender_type, template_id } = body;
      // recipients: array of { user_id, email }
      if (!recipients?.length || !subject || !body_html) {
        return new Response(JSON.stringify({
          error: "Missing fields"
        }), {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      let sent = 0;
      let failed = 0;
      const errors = [];
      for (const r of recipients){
        try {
          const unsubscribeUrl = `${APP_URL}/unsubscribe?uid=${r.user_id}`;
          const html = wrapInTemplate(body_html, sender_type || "project", unsubscribeUrl);
          await sendEmail(r.email, subject, html);
          await adminClient.from("admin_emails").insert({
            sender_id: user.id,
            sender_type: sender_type || "project",
            recipient_id: r.user_id || null,
            recipient_email: r.email,
            subject,
            body_html,
            template_id: template_id || null,
            status: "sent"
          });
          sent++;
        } catch (err) {
          failed++;
          errors.push(`${r.email}: ${err.message}`);
          await adminClient.from("admin_emails").insert({
            sender_id: user.id,
            sender_type: sender_type || "project",
            recipient_id: r.user_id || null,
            recipient_email: r.email,
            subject,
            body_html,
            template_id: template_id || null,
            status: "failed",
            error_message: err.message
          });
        }
      }
      console.log(`[send-admin-email] Sent: ${sent}, Failed: ${failed}`);
      return new Response(JSON.stringify({
        success: true,
        sent,
        failed,
        errors
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // ---- UNSUBSCRIBE ----
    if (action === "unsubscribe") {
      const { user_id } = body;
      if (!user_id) {
        return new Response(JSON.stringify({
          error: "user_id required"
        }), {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      await adminClient.from("profiles").update({
        email_unsubscribed: true
      }).eq("user_id", user_id);
      return new Response(JSON.stringify({
        success: true
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    return new Response(JSON.stringify({
      error: "Unknown action"
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("[send-admin-email] Error:", error);
    const message = error instanceof Error ? error.message : "Internal server error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9zZW5kLWFkbWluLWVtYWlsL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMi40OS4xXCI7XG5pbXBvcnQgbm9kZW1haWxlciBmcm9tIFwibnBtOm5vZGVtYWlsZXJANi45LjEwXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6XG4gICAgXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuY29uc3QgQVBQX05BTUUgPSBcIkFJIFBsYW5ldCBTb3VuZFwiO1xuY29uc3QgQVBQX1VSTCA9IFwiaHR0cHM6Ly9haXBsYW5ldHNvdW5kLmxvdmFibGUuYXBwXCI7XG5cbmZ1bmN0aW9uIHdyYXBJblRlbXBsYXRlKGJvZHlIdG1sOiBzdHJpbmcsIHNlbmRlclR5cGU6IHN0cmluZywgdW5zdWJzY3JpYmVVcmw/OiBzdHJpbmcpIHtcbiAgY29uc3Qgc2VuZGVyTGFiZWwgPSBzZW5kZXJUeXBlID09PSBcInBlcnNvbmFsXCIgPyBcItCb0LjRh9C90L7QtSDRgdC+0L7QsdGJ0LXQvdC40LUg0L7RgiDQsNC00LzQuNC90LjRgdGC0YDQsNGC0L7RgNCwXCIgOiBBUFBfTkFNRTtcblxuICByZXR1cm4gYFxuICAgIDxkaXYgc3R5bGU9XCJmb250LWZhbWlseTogJ1NlZ29lIFVJJywgQXJpYWwsIHNhbnMtc2VyaWY7IG1heC13aWR0aDogNjAwcHg7IG1hcmdpbjogMCBhdXRvOyBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjMWExYTJlIDAlLCAjMTYyMTNlIDUwJSwgIzBmMzQ2MCAxMDAlKTsgYm9yZGVyLXJhZGl1czogMTZweDsgb3ZlcmZsb3c6IGhpZGRlbjsgY29sb3I6ICNlMGUwZTA7XCI+XG4gICAgICA8ZGl2IHN0eWxlPVwicGFkZGluZzogMzJweCAyNHB4IDE2cHg7IHRleHQtYWxpZ246IGNlbnRlcjtcIj5cbiAgICAgICAgPGgxIHN0eWxlPVwiY29sb3I6ICNhNzhiZmE7IGZvbnQtc2l6ZTogMjRweDsgbWFyZ2luOiAwO1wiPvCfjrUgJHtBUFBfTkFNRX08L2gxPlxuICAgICAgICA8cCBzdHlsZT1cImZvbnQtc2l6ZTogMTJweDsgY29sb3I6ICM4ODg7IG1hcmdpbi10b3A6IDRweDtcIj4ke3NlbmRlckxhYmVsfTwvcD5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBzdHlsZT1cInBhZGRpbmc6IDE2cHggMjRweCAzMnB4O1wiPlxuICAgICAgICAke2JvZHlIdG1sfVxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IHN0eWxlPVwicGFkZGluZzogMTZweCAyNHB4IDI0cHg7IHRleHQtYWxpZ246IGNlbnRlcjsgZm9udC1zaXplOiAxMnB4OyBjb2xvcjogIzY2NjsgYm9yZGVyLXRvcDogMXB4IHNvbGlkIHJnYmEoMjU1LDI1NSwyNTUsMC4wNSk7XCI+XG4gICAgICAgIDxwPtCt0YLQviDQv9C40YHRjNC80L4g0L7RgiAke0FQUF9OQU1FfS48L3A+XG4gICAgICAgICR7dW5zdWJzY3JpYmVVcmwgPyBgPHA+PGEgaHJlZj1cIiR7dW5zdWJzY3JpYmVVcmx9XCIgc3R5bGU9XCJjb2xvcjogIzg4ODsgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XCI+0J7RgtC/0LjRgdCw0YLRjNGB0Y8g0L7RgiDRgNCw0YHRgdGL0LvQutC4PC9hPjwvcD5gIDogXCJcIn1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICBgO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZW5kRW1haWwodG86IHN0cmluZywgc3ViamVjdDogc3RyaW5nLCBodG1sOiBzdHJpbmcpIHtcbiAgY29uc3QgdHJhbnNwb3J0ZXIgPSBub2RlbWFpbGVyLmNyZWF0ZVRyYW5zcG9ydCh7XG4gICAgaG9zdDogRGVuby5lbnYuZ2V0KFwiU01UUF9IT1NUXCIpLFxuICAgIHBvcnQ6IHBhcnNlSW50KERlbm8uZW52LmdldChcIlNNVFBfUE9SVFwiKSB8fCBcIjQ2NVwiKSxcbiAgICBzZWN1cmU6IHRydWUsXG4gICAgYXV0aDoge1xuICAgICAgdXNlcjogRGVuby5lbnYuZ2V0KFwiU01UUF9VU0VSXCIpLFxuICAgICAgcGFzczogRGVuby5lbnYuZ2V0KFwiU01UUF9QQVNTXCIpLFxuICAgIH0sXG4gIH0pO1xuICBhd2FpdCB0cmFuc3BvcnRlci5zZW5kTWFpbCh7XG4gICAgZnJvbTogYFwiJHtBUFBfTkFNRX1cIiA8JHtEZW5vLmVudi5nZXQoXCJTTVRQX1VTRVJcIil9PmAsXG4gICAgdG8sXG4gICAgc3ViamVjdCxcbiAgICBodG1sLFxuICB9KTtcbn1cblxuRGVuby5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgLy8gVmVyaWZ5IGFkbWluXG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksIHtcbiAgICAgICAgc3RhdHVzOiA0MDEsXG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgY29uc3Qgc2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIGNvbnN0IGFub25LZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSE7XG5cbiAgICAvLyBWZXJpZnkgdGhlIGNhbGxlciBpcyBhZG1pblxuICAgIGNvbnN0IHVzZXJDbGllbnQgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIGFub25LZXksIHtcbiAgICAgIGdsb2JhbDogeyBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGF1dGhIZWFkZXIgfSB9LFxuICAgICAgYXV0aDogeyBhdXRvUmVmcmVzaFRva2VuOiBmYWxzZSwgcGVyc2lzdFNlc3Npb246IGZhbHNlIH0sXG4gICAgfSk7XG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IHVzZXJFcnJvciB9ID0gYXdhaXQgdXNlckNsaWVudC5hdXRoLmdldFVzZXIoKTtcbiAgICBpZiAodXNlckVycm9yIHx8ICF1c2VyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksIHtcbiAgICAgICAgc3RhdHVzOiA0MDEsXG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBjb25zdCBhZG1pbkNsaWVudCA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc2VydmljZUtleSwge1xuICAgICAgYXV0aDogeyBhdXRvUmVmcmVzaFRva2VuOiBmYWxzZSwgcGVyc2lzdFNlc3Npb246IGZhbHNlIH0sXG4gICAgfSk7XG5cbiAgICAvLyBDaGVjayBhZG1pbiByb2xlXG4gICAgY29uc3QgeyBkYXRhOiByb2xlQ2hlY2sgfSA9IGF3YWl0IGFkbWluQ2xpZW50LnJwYyhcImhhc19yb2xlXCIsIHtcbiAgICAgIF91c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgX3JvbGU6IFwiYWRtaW5cIixcbiAgICB9KTtcbiAgICBjb25zdCB7IGRhdGE6IHN1cGVyQ2hlY2sgfSA9IGF3YWl0IGFkbWluQ2xpZW50LnJwYyhcImhhc19yb2xlXCIsIHtcbiAgICAgIF91c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgX3JvbGU6IFwic3VwZXJfYWRtaW5cIixcbiAgICB9KTtcbiAgICBpZiAoIXJvbGVDaGVjayAmJiAhc3VwZXJDaGVjaykge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkZvcmJpZGRlblwiIH0pLCB7XG4gICAgICAgIHN0YXR1czogNDAzLFxuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc3QgeyBhY3Rpb24gfSA9IGJvZHk7XG5cbiAgICAvLyAtLS0tIFNFTkQgRU1BSUwgLS0tLVxuICAgIGlmIChhY3Rpb24gPT09IFwic2VuZFwiKSB7XG4gICAgICBjb25zdCB7IHJlY2lwaWVudHMsIHN1YmplY3QsIGJvZHlfaHRtbCwgc2VuZGVyX3R5cGUsIHRlbXBsYXRlX2lkIH0gPSBib2R5O1xuICAgICAgLy8gcmVjaXBpZW50czogYXJyYXkgb2YgeyB1c2VyX2lkLCBlbWFpbCB9XG5cbiAgICAgIGlmICghcmVjaXBpZW50cz8ubGVuZ3RoIHx8ICFzdWJqZWN0IHx8ICFib2R5X2h0bWwpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk1pc3NpbmcgZmllbGRzXCIgfSksIHtcbiAgICAgICAgICBzdGF0dXM6IDQwMCxcbiAgICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgbGV0IHNlbnQgPSAwO1xuICAgICAgbGV0IGZhaWxlZCA9IDA7XG4gICAgICBjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG5cbiAgICAgIGZvciAoY29uc3QgciBvZiByZWNpcGllbnRzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgdW5zdWJzY3JpYmVVcmwgPSBgJHtBUFBfVVJMfS91bnN1YnNjcmliZT91aWQ9JHtyLnVzZXJfaWR9YDtcbiAgICAgICAgICBjb25zdCBodG1sID0gd3JhcEluVGVtcGxhdGUoYm9keV9odG1sLCBzZW5kZXJfdHlwZSB8fCBcInByb2plY3RcIiwgdW5zdWJzY3JpYmVVcmwpO1xuICAgICAgICAgIGF3YWl0IHNlbmRFbWFpbChyLmVtYWlsLCBzdWJqZWN0LCBodG1sKTtcblxuICAgICAgICAgIGF3YWl0IGFkbWluQ2xpZW50LmZyb20oXCJhZG1pbl9lbWFpbHNcIikuaW5zZXJ0KHtcbiAgICAgICAgICAgIHNlbmRlcl9pZDogdXNlci5pZCxcbiAgICAgICAgICAgIHNlbmRlcl90eXBlOiBzZW5kZXJfdHlwZSB8fCBcInByb2plY3RcIixcbiAgICAgICAgICAgIHJlY2lwaWVudF9pZDogci51c2VyX2lkIHx8IG51bGwsXG4gICAgICAgICAgICByZWNpcGllbnRfZW1haWw6IHIuZW1haWwsXG4gICAgICAgICAgICBzdWJqZWN0LFxuICAgICAgICAgICAgYm9keV9odG1sLFxuICAgICAgICAgICAgdGVtcGxhdGVfaWQ6IHRlbXBsYXRlX2lkIHx8IG51bGwsXG4gICAgICAgICAgICBzdGF0dXM6IFwic2VudFwiLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHNlbnQrKztcbiAgICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgICBmYWlsZWQrKztcbiAgICAgICAgICBlcnJvcnMucHVzaChgJHtyLmVtYWlsfTogJHtlcnIubWVzc2FnZX1gKTtcbiAgICAgICAgICBhd2FpdCBhZG1pbkNsaWVudC5mcm9tKFwiYWRtaW5fZW1haWxzXCIpLmluc2VydCh7XG4gICAgICAgICAgICBzZW5kZXJfaWQ6IHVzZXIuaWQsXG4gICAgICAgICAgICBzZW5kZXJfdHlwZTogc2VuZGVyX3R5cGUgfHwgXCJwcm9qZWN0XCIsXG4gICAgICAgICAgICByZWNpcGllbnRfaWQ6IHIudXNlcl9pZCB8fCBudWxsLFxuICAgICAgICAgICAgcmVjaXBpZW50X2VtYWlsOiByLmVtYWlsLFxuICAgICAgICAgICAgc3ViamVjdCxcbiAgICAgICAgICAgIGJvZHlfaHRtbCxcbiAgICAgICAgICAgIHRlbXBsYXRlX2lkOiB0ZW1wbGF0ZV9pZCB8fCBudWxsLFxuICAgICAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLFxuICAgICAgICAgICAgZXJyb3JfbWVzc2FnZTogZXJyLm1lc3NhZ2UsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc29sZS5sb2coYFtzZW5kLWFkbWluLWVtYWlsXSBTZW50OiAke3NlbnR9LCBGYWlsZWQ6ICR7ZmFpbGVkfWApO1xuXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IHRydWUsIHNlbnQsIGZhaWxlZCwgZXJyb3JzIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyAtLS0tIFVOU1VCU0NSSUJFIC0tLS1cbiAgICBpZiAoYWN0aW9uID09PSBcInVuc3Vic2NyaWJlXCIpIHtcbiAgICAgIGNvbnN0IHsgdXNlcl9pZCB9ID0gYm9keTtcbiAgICAgIGlmICghdXNlcl9pZCkge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwidXNlcl9pZCByZXF1aXJlZFwiIH0pLCB7XG4gICAgICAgICAgc3RhdHVzOiA0MDAsXG4gICAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGF3YWl0IGFkbWluQ2xpZW50LmZyb20oXCJwcm9maWxlc1wiKS51cGRhdGUoeyBlbWFpbF91bnN1YnNjcmliZWQ6IHRydWUgfSkuZXEoXCJ1c2VyX2lkXCIsIHVzZXJfaWQpO1xuXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IHRydWUgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmtub3duIGFjdGlvblwiIH0pLCB7XG4gICAgICBzdGF0dXM6IDQwMCxcbiAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XG4gICAgY29uc29sZS5lcnJvcihcIltzZW5kLWFkbWluLWVtYWlsXSBFcnJvcjpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiSW50ZXJuYWwgc2VydmVyIGVycm9yXCI7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IG1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFlBQVksUUFBUSw4Q0FBOEM7QUFDM0UsT0FBTyxnQkFBZ0Isd0JBQXdCO0FBRS9DLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQ0U7QUFDSjtBQUVBLE1BQU0sV0FBVztBQUNqQixNQUFNLFVBQVU7QUFFaEIsU0FBUyxlQUFlLFFBQWdCLEVBQUUsVUFBa0IsRUFBRSxjQUF1QjtFQUNuRixNQUFNLGNBQWMsZUFBZSxhQUFhLHVDQUF1QztFQUV2RixPQUFPLENBQUM7OzttRUFHeUQsRUFBRSxTQUFTO2tFQUNaLEVBQUUsWUFBWTs7O1FBR3hFLEVBQUUsU0FBUzs7O3lCQUdNLEVBQUUsU0FBUztRQUM1QixFQUFFLGlCQUFpQixDQUFDLFlBQVksRUFBRSxlQUFlLGlGQUFpRixDQUFDLEdBQUcsR0FBRzs7O0VBRy9JLENBQUM7QUFDSDtBQUVBLGVBQWUsVUFBVSxFQUFVLEVBQUUsT0FBZSxFQUFFLElBQVk7RUFDaEUsTUFBTSxjQUFjLFdBQVcsZUFBZSxDQUFDO0lBQzdDLE1BQU0sS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ25CLE1BQU0sU0FBUyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCO0lBQzVDLFFBQVE7SUFDUixNQUFNO01BQ0osTUFBTSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7TUFDbkIsTUFBTSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDckI7RUFDRjtFQUNBLE1BQU0sWUFBWSxRQUFRLENBQUM7SUFDekIsTUFBTSxDQUFDLENBQUMsRUFBRSxTQUFTLEdBQUcsRUFBRSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDcEQ7SUFDQTtJQUNBO0VBQ0Y7QUFDRjtBQUVBLEtBQUssS0FBSyxDQUFDLE9BQU87RUFDaEIsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsZUFBZTtJQUNmLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVk7TUFDZixPQUFPLElBQUksU0FBUyxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUFJO1FBQzdELFFBQVE7UUFDUixTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQ2hFO0lBQ0Y7SUFFQSxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0sYUFBYSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDaEMsTUFBTSxVQUFVLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUU3Qiw2QkFBNkI7SUFDN0IsTUFBTSxhQUFhLGFBQWEsYUFBYSxTQUFTO01BQ3BELFFBQVE7UUFBRSxTQUFTO1VBQUUsZUFBZTtRQUFXO01BQUU7TUFDakQsTUFBTTtRQUFFLGtCQUFrQjtRQUFPLGdCQUFnQjtNQUFNO0lBQ3pEO0lBQ0EsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sV0FBVyxJQUFJLENBQUMsT0FBTztJQUMxRSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE9BQU8sSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFlLElBQUk7UUFDN0QsUUFBUTtRQUNSLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFDaEU7SUFDRjtJQUVBLE1BQU0sY0FBYyxhQUFhLGFBQWEsWUFBWTtNQUN4RCxNQUFNO1FBQUUsa0JBQWtCO1FBQU8sZ0JBQWdCO01BQU07SUFDekQ7SUFFQSxtQkFBbUI7SUFDbkIsTUFBTSxFQUFFLE1BQU0sU0FBUyxFQUFFLEdBQUcsTUFBTSxZQUFZLEdBQUcsQ0FBQyxZQUFZO01BQzVELFVBQVUsS0FBSyxFQUFFO01BQ2pCLE9BQU87SUFDVDtJQUNBLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxHQUFHLE1BQU0sWUFBWSxHQUFHLENBQUMsWUFBWTtNQUM3RCxVQUFVLEtBQUssRUFBRTtNQUNqQixPQUFPO0lBQ1Q7SUFDQSxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVk7TUFDN0IsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQVksSUFBSTtRQUMxRCxRQUFRO1FBQ1IsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUNoRTtJQUNGO0lBRUEsTUFBTSxPQUFPLE1BQU0sSUFBSSxJQUFJO0lBQzNCLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRztJQUVuQix1QkFBdUI7SUFDdkIsSUFBSSxXQUFXLFFBQVE7TUFDckIsTUFBTSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsR0FBRztNQUNyRSwwQ0FBMEM7TUFFMUMsSUFBSSxDQUFDLFlBQVksVUFBVSxDQUFDLFdBQVcsQ0FBQyxXQUFXO1FBQ2pELE9BQU8sSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUFpQixJQUFJO1VBQy9ELFFBQVE7VUFDUixTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQ2hFO01BQ0Y7TUFFQSxJQUFJLE9BQU87TUFDWCxJQUFJLFNBQVM7TUFDYixNQUFNLFNBQW1CLEVBQUU7TUFFM0IsS0FBSyxNQUFNLEtBQUssV0FBWTtRQUMxQixJQUFJO1VBQ0YsTUFBTSxpQkFBaUIsQ0FBQyxFQUFFLFFBQVEsaUJBQWlCLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztVQUNoRSxNQUFNLE9BQU8sZUFBZSxXQUFXLGVBQWUsV0FBVztVQUNqRSxNQUFNLFVBQVUsRUFBRSxLQUFLLEVBQUUsU0FBUztVQUVsQyxNQUFNLFlBQVksSUFBSSxDQUFDLGdCQUFnQixNQUFNLENBQUM7WUFDNUMsV0FBVyxLQUFLLEVBQUU7WUFDbEIsYUFBYSxlQUFlO1lBQzVCLGNBQWMsRUFBRSxPQUFPLElBQUk7WUFDM0IsaUJBQWlCLEVBQUUsS0FBSztZQUN4QjtZQUNBO1lBQ0EsYUFBYSxlQUFlO1lBQzVCLFFBQVE7VUFDVjtVQUNBO1FBQ0YsRUFBRSxPQUFPLEtBQVU7VUFDakI7VUFDQSxPQUFPLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLElBQUksT0FBTyxDQUFDLENBQUM7VUFDeEMsTUFBTSxZQUFZLElBQUksQ0FBQyxnQkFBZ0IsTUFBTSxDQUFDO1lBQzVDLFdBQVcsS0FBSyxFQUFFO1lBQ2xCLGFBQWEsZUFBZTtZQUM1QixjQUFjLEVBQUUsT0FBTyxJQUFJO1lBQzNCLGlCQUFpQixFQUFFLEtBQUs7WUFDeEI7WUFDQTtZQUNBLGFBQWEsZUFBZTtZQUM1QixRQUFRO1lBQ1IsZUFBZSxJQUFJLE9BQU87VUFDNUI7UUFDRjtNQUNGO01BRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBRSxLQUFLLFVBQVUsRUFBRSxPQUFPLENBQUM7TUFFakUsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxTQUFTO1FBQU07UUFBTTtRQUFRO01BQU8sSUFDckQ7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSx3QkFBd0I7SUFDeEIsSUFBSSxXQUFXLGVBQWU7TUFDNUIsTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUFHO01BQ3BCLElBQUksQ0FBQyxTQUFTO1FBQ1osT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQW1CLElBQUk7VUFDakUsUUFBUTtVQUNSLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFDaEU7TUFDRjtNQUVBLE1BQU0sWUFBWSxJQUFJLENBQUMsWUFBWSxNQUFNLENBQUM7UUFBRSxvQkFBb0I7TUFBSyxHQUFHLEVBQUUsQ0FBQyxXQUFXO01BRXRGLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsU0FBUztNQUFLLElBQy9CO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQWlCLElBQUk7TUFDL0QsUUFBUTtNQUNSLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFDaEU7RUFDRixFQUFFLE9BQU8sT0FBZ0I7SUFDdkIsUUFBUSxLQUFLLENBQUMsNkJBQTZCO0lBQzNDLE1BQU0sVUFBVSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUN6RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBUSxJQUNoQztNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRiJ9
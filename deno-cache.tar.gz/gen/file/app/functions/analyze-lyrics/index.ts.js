import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
const AGENT_ACCESS_ID = '0846d064-4950-4d79-a54c-62ba315cdb34';
// System prompt for generating style prompts from lyrics
const SYSTEM_PROMPT = `Ты эксперт по созданию музыки с помощью Suno AI. Твоя задача - анализировать текст песни и создавать промт для генерации музыки.

## ТВОЙ ПОДХОД

1. Внимательно прочитай текст песни
2. Если пользователь указал свои требования - ОБЯЗАТЕЛЬНО учитывай их в первую очередь
3. Определи настроение, жанр, темп, вокал на основе текста
4. Сгенерируй оптимальный промт для Suno на РУССКОМ языке

## ФОРМАТ ПРОМТА

Промт должен быть кратким и ёмким (до 200 символов), включать:
- Жанр и стиль музыки
- Настроение и атмосферу
- Тип вокала (если не инструментал)
- Темп и энергетику

## ПРИМЕРЫ ХОРОШИХ ПРОМПТОВ

- "Меланхоличный инди-поп, нежный женский вокал, медленный темп, атмосферная электроника"
- "Энергичный рок, мощный мужской вокал, драйвовые гитары, быстрый темп"
- "Лирический рэп, глубокий бас, минималистичный бит, городская атмосфера"
- "Романтическая баллада, акустическая гитара, тёплый вокал, интимная атмосфера"

## ФОРМАТ ОТВЕТА

Верни ТОЛЬКО валидный JSON (без markdown):
{
  "stylePrompt": "промт для Suno на русском языке (до 200 символов)",
  "genre": "определённый жанр",
  "mood": "настроение трека",
  "tempo": "медленный/средний/быстрый",
  "vocalStyle": "описание вокала"
}`;
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const { lyrics, userPrompt } = await req.json();
    if (!lyrics || typeof lyrics !== 'string') {
      return new Response(JSON.stringify({
        error: 'Текст песни обязателен'
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const TIMEWEB_TOKEN = Deno.env.get('TIMEWEB_AGENT_TOKEN');
    if (!TIMEWEB_TOKEN) {
      console.error('TIMEWEB_AGENT_TOKEN is not configured');
      return new Response(JSON.stringify({
        error: 'Timeweb Agent token не настроен'
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    console.log('Генерация промта для текста, длина:', lyrics.length);
    // Build user prompt with optional requirements
    let userMessage = `Проанализируй этот текст песни и создай оптимальный промт для генерации музыки:\n\n${lyrics}`;
    if (userPrompt && userPrompt.trim()) {
      userMessage = `ТРЕБОВАНИЯ ПОЛЬЗОВАТЕЛЯ (учти их в первую очередь): ${userPrompt}\n\n${userMessage}`;
    }
    const apiUrl = `https://agent.timeweb.cloud/api/v1/cloud-ai/agents/${AGENT_ACCESS_ID}/v1/chat/completions`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${TIMEWEB_TOKEN}`,
        'Content-Type': 'application/json',
        'x-proxy-source': 'lovable-app'
      },
      body: JSON.stringify({
        model: 'deepseek-v3',
        messages: [
          {
            role: 'system',
            content: SYSTEM_PROMPT
          },
          {
            role: 'user',
            content: userMessage
          }
        ],
        temperature: 0.7
      })
    });
    console.log('Timeweb response status:', response.status);
    if (!response.ok) {
      const errorText = await response.text();
      console.error('Timeweb API error:', response.status, errorText);
      if (response.status === 401) {
        return new Response(JSON.stringify({
          error: 'Неверный токен Timeweb'
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      if (response.status === 429) {
        return new Response(JSON.stringify({
          error: 'Превышен лимит запросов'
        }), {
          status: 429,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      return new Response(JSON.stringify({
        error: 'Ошибка генерации промта',
        details: errorText
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const data = await response.json();
    console.log('Ответ получен, парсинг...');
    const content = data.choices?.[0]?.message?.content;
    if (!content) {
      console.error('Пустой ответ от AI');
      return new Response(JSON.stringify({
        error: 'Пустой ответ от AI'
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    let result;
    try {
      let jsonStr = content;
      const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (jsonMatch) {
        jsonStr = jsonMatch[1].trim();
      }
      result = JSON.parse(jsonStr);
    } catch (parseError) {
      console.error('JSON parse failed:', parseError);
      // Fallback: use content as stylePrompt
      result = {
        stylePrompt: content.slice(0, 200),
        genre: 'Неизвестно',
        mood: 'Неизвестно',
        tempo: 'средний',
        vocalStyle: 'Неизвестно'
      };
    }
    console.log('Промт создан:', result.stylePrompt?.slice(0, 50));
    return new Response(JSON.stringify(result), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('Ошибка в analyze-lyrics:', error);
    return new Response(JSON.stringify({
      error: error instanceof Error ? error.message : 'Неизвестная ошибка'
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9hbmFseXplLWx5cmljcy9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcbiAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnMnOiAnYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUnLFxufTtcblxuY29uc3QgQUdFTlRfQUNDRVNTX0lEID0gJzA4NDZkMDY0LTQ5NTAtNGQ3OS1hNTRjLTYyYmEzMTVjZGIzNCc7XG5cbi8vIFN5c3RlbSBwcm9tcHQgZm9yIGdlbmVyYXRpbmcgc3R5bGUgcHJvbXB0cyBmcm9tIGx5cmljc1xuY29uc3QgU1lTVEVNX1BST01QVCA9IGDQotGLINGN0LrRgdC/0LXRgNGCINC/0L4g0YHQvtC30LTQsNC90LjRjiDQvNGD0LfRi9C60Lgg0YEg0L/QvtC80L7RidGM0Y4gU3VubyBBSS4g0KLQstC+0Y8g0LfQsNC00LDRh9CwIC0g0LDQvdCw0LvQuNC30LjRgNC+0LLQsNGC0Ywg0YLQtdC60YHRgiDQv9C10YHQvdC4INC4INGB0L7Qt9C00LDQstCw0YLRjCDQv9GA0L7QvNGCINC00LvRjyDQs9C10L3QtdGA0LDRhtC40Lgg0LzRg9C30YvQutC4LlxuXG4jIyDQotCS0J7QmSDQn9Ce0JTQpdCe0JRcblxuMS4g0JLQvdC40LzQsNGC0LXQu9GM0L3QviDQv9GA0L7Rh9C40YLQsNC5INGC0LXQutGB0YIg0L/QtdGB0L3QuFxuMi4g0JXRgdC70Lgg0L/QvtC70YzQt9C+0LLQsNGC0LXQu9GMINGD0LrQsNC30LDQuyDRgdCy0L7QuCDRgtGA0LXQsdC+0LLQsNC90LjRjyAtINCe0JHQr9CX0JDQotCV0JvQrNCd0J4g0YPRh9C40YLRi9Cy0LDQuSDQuNGFINCyINC/0LXRgNCy0YPRjiDQvtGH0LXRgNC10LTRjFxuMy4g0J7Qv9GA0LXQtNC10LvQuCDQvdCw0YHRgtGA0L7QtdC90LjQtSwg0LbQsNC90YAsINGC0LXQvNC/LCDQstC+0LrQsNC7INC90LAg0L7RgdC90L7QstC1INGC0LXQutGB0YLQsFxuNC4g0KHQs9C10L3QtdGA0LjRgNGD0Lkg0L7Qv9GC0LjQvNCw0LvRjNC90YvQuSDQv9GA0L7QvNGCINC00LvRjyBTdW5vINC90LAg0KDQo9Ch0KHQmtCe0Jwg0Y/Qt9GL0LrQtVxuXG4jIyDQpNCe0KDQnNCQ0KIg0J/QoNCe0JzQotCQXG5cbtCf0YDQvtC80YIg0LTQvtC70LbQtdC9INCx0YvRgtGMINC60YDQsNGC0LrQuNC8INC4INGR0LzQutC40LwgKNC00L4gMjAwINGB0LjQvNCy0L7Qu9C+0LIpLCDQstC60LvRjtGH0LDRgtGMOlxuLSDQltCw0L3RgCDQuCDRgdGC0LjQu9GMINC80YPQt9GL0LrQuFxuLSDQndCw0YHRgtGA0L7QtdC90LjQtSDQuCDQsNGC0LzQvtGB0YTQtdGA0YNcbi0g0KLQuNC/INCy0L7QutCw0LvQsCAo0LXRgdC70Lgg0L3QtSDQuNC90YHRgtGA0YPQvNC10L3RgtCw0LspXG4tINCi0LXQvNC/INC4INGN0L3QtdGA0LPQtdGC0LjQutGDXG5cbiMjINCf0KDQmNCc0JXQoNCrINCl0J7QoNCe0KjQmNClINCf0KDQntCc0J/QotCe0JJcblxuLSBcItCc0LXQu9Cw0L3RhdC+0LvQuNGH0L3Ri9C5INC40L3QtNC4LdC/0L7Qvywg0L3QtdC20L3Ri9C5INC20LXQvdGB0LrQuNC5INCy0L7QutCw0LssINC80LXQtNC70LXQvdC90YvQuSDRgtC10LzQvywg0LDRgtC80L7RgdGE0LXRgNC90LDRjyDRjdC70LXQutGC0YDQvtC90LjQutCwXCJcbi0gXCLQrdC90LXRgNCz0LjRh9C90YvQuSDRgNC+0LosINC80L7RidC90YvQuSDQvNGD0LbRgdC60L7QuSDQstC+0LrQsNC7LCDQtNGA0LDQudCy0L7QstGL0LUg0LPQuNGC0LDRgNGLLCDQsdGL0YHRgtGA0YvQuSDRgtC10LzQv1wiXG4tIFwi0JvQuNGA0LjRh9C10YHQutC40Lkg0YDRjdC/LCDQs9C70YPQsdC+0LrQuNC5INCx0LDRgSwg0LzQuNC90LjQvNCw0LvQuNGB0YLQuNGH0L3Ri9C5INCx0LjRgiwg0LPQvtGA0L7QtNGB0LrQsNGPINCw0YLQvNC+0YHRhNC10YDQsFwiXG4tIFwi0KDQvtC80LDQvdGC0LjRh9C10YHQutCw0Y8g0LHQsNC70LvQsNC00LAsINCw0LrRg9GB0YLQuNGH0LXRgdC60LDRjyDQs9C40YLQsNGA0LAsINGC0ZHQv9C70YvQuSDQstC+0LrQsNC7LCDQuNC90YLQuNC80L3QsNGPINCw0YLQvNC+0YHRhNC10YDQsFwiXG5cbiMjINCk0J7QoNCc0JDQoiDQntCi0JLQldCi0JBcblxu0JLQtdGA0L3QuCDQotCe0JvQrNCa0J4g0LLQsNC70LjQtNC90YvQuSBKU09OICjQsdC10LcgbWFya2Rvd24pOlxue1xuICBcInN0eWxlUHJvbXB0XCI6IFwi0L/RgNC+0LzRgiDQtNC70Y8gU3VubyDQvdCwINGA0YPRgdGB0LrQvtC8INGP0LfRi9C60LUgKNC00L4gMjAwINGB0LjQvNCy0L7Qu9C+0LIpXCIsXG4gIFwiZ2VucmVcIjogXCLQvtC/0YDQtdC00LXQu9GR0L3QvdGL0Lkg0LbQsNC90YBcIixcbiAgXCJtb29kXCI6IFwi0L3QsNGB0YLRgNC+0LXQvdC40LUg0YLRgNC10LrQsFwiLFxuICBcInRlbXBvXCI6IFwi0LzQtdC00LvQtdC90L3Ri9C5L9GB0YDQtdC00L3QuNC5L9Cx0YvRgdGC0YDRi9C5XCIsXG4gIFwidm9jYWxTdHlsZVwiOiBcItC+0L/QuNGB0LDQvdC40LUg0LLQvtC60LDQu9CwXCJcbn1gO1xuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSAnT1BUSU9OUycpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHsgbHlyaWNzLCB1c2VyUHJvbXB0IH0gPSBhd2FpdCByZXEuanNvbigpO1xuXG4gICAgaWYgKCFseXJpY3MgfHwgdHlwZW9mIGx5cmljcyAhPT0gJ3N0cmluZycpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICfQotC10LrRgdGCINC/0LXRgdC90Lgg0L7QsdGP0LfQsNGC0LXQu9C10L0nIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBUSU1FV0VCX1RPS0VOID0gRGVuby5lbnYuZ2V0KCdUSU1FV0VCX0FHRU5UX1RPS0VOJyk7XG4gICAgaWYgKCFUSU1FV0VCX1RPS0VOKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdUSU1FV0VCX0FHRU5UX1RPS0VOIGlzIG5vdCBjb25maWd1cmVkJyk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAnVGltZXdlYiBBZ2VudCB0b2tlbiDQvdC1INC90LDRgdGC0YDQvtC10L0nIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZygn0JPQtdC90LXRgNCw0YbQuNGPINC/0YDQvtC80YLQsCDQtNC70Y8g0YLQtdC60YHRgtCwLCDQtNC70LjQvdCwOicsIGx5cmljcy5sZW5ndGgpO1xuXG4gICAgLy8gQnVpbGQgdXNlciBwcm9tcHQgd2l0aCBvcHRpb25hbCByZXF1aXJlbWVudHNcbiAgICBsZXQgdXNlck1lc3NhZ2UgPSBg0J/RgNC+0LDQvdCw0LvQuNC30LjRgNGD0Lkg0Y3RgtC+0YIg0YLQtdC60YHRgiDQv9C10YHQvdC4INC4INGB0L7Qt9C00LDQuSDQvtC/0YLQuNC80LDQu9GM0L3Ri9C5INC/0YDQvtC80YIg0LTQu9GPINCz0LXQvdC10YDQsNGG0LjQuCDQvNGD0LfRi9C60Lg6XFxuXFxuJHtseXJpY3N9YDtcbiAgICBcbiAgICBpZiAodXNlclByb21wdCAmJiB1c2VyUHJvbXB0LnRyaW0oKSkge1xuICAgICAgdXNlck1lc3NhZ2UgPSBg0KLQoNCV0JHQntCS0JDQndCY0K8g0J/QntCb0KzQl9Ce0JLQkNCi0JXQm9CvICjRg9GH0YLQuCDQuNGFINCyINC/0LXRgNCy0YPRjiDQvtGH0LXRgNC10LTRjCk6ICR7dXNlclByb21wdH1cXG5cXG4ke3VzZXJNZXNzYWdlfWA7XG4gICAgfVxuXG4gICAgY29uc3QgYXBpVXJsID0gYGh0dHBzOi8vYWdlbnQudGltZXdlYi5jbG91ZC9hcGkvdjEvY2xvdWQtYWkvYWdlbnRzLyR7QUdFTlRfQUNDRVNTX0lEfS92MS9jaGF0L2NvbXBsZXRpb25zYDtcblxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYXBpVXJsLCB7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0F1dGhvcml6YXRpb24nOiBgQmVhcmVyICR7VElNRVdFQl9UT0tFTn1gLFxuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAneC1wcm94eS1zb3VyY2UnOiAnbG92YWJsZS1hcHAnLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgbW9kZWw6ICdkZWVwc2Vlay12MycsXG4gICAgICAgIG1lc3NhZ2VzOiBbXG4gICAgICAgICAgeyByb2xlOiAnc3lzdGVtJywgY29udGVudDogU1lTVEVNX1BST01QVCB9LFxuICAgICAgICAgIHsgcm9sZTogJ3VzZXInLCBjb250ZW50OiB1c2VyTWVzc2FnZSB9XG4gICAgICAgIF0sXG4gICAgICAgIHRlbXBlcmF0dXJlOiAwLjcsXG4gICAgICB9KSxcbiAgICB9KTtcblxuICAgIGNvbnNvbGUubG9nKCdUaW1ld2ViIHJlc3BvbnNlIHN0YXR1czonLCByZXNwb25zZS5zdGF0dXMpO1xuXG4gICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgY29uc3QgZXJyb3JUZXh0ID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICAgICAgY29uc29sZS5lcnJvcignVGltZXdlYiBBUEkgZXJyb3I6JywgcmVzcG9uc2Uuc3RhdHVzLCBlcnJvclRleHQpO1xuICAgICAgXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDEpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAn0J3QtdCy0LXRgNC90YvQuSDRgtC+0LrQtdC9IFRpbWV3ZWInIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQyOSkge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICfQn9GA0LXQstGL0YjQtdC9INC70LjQvNC40YIg0LfQsNC/0YDQvtGB0L7QsicgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDQyOSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ9Ce0YjQuNCx0LrQsCDQs9C10L3QtdGA0LDRhtC40Lgg0L/RgNC+0LzRgtCwJywgZGV0YWlsczogZXJyb3JUZXh0IH0pLFxuICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKCfQntGC0LLQtdGCINC/0L7Qu9GD0YfQtdC9LCDQv9Cw0YDRgdC40L3Qsy4uLicpO1xuXG4gICAgY29uc3QgY29udGVudCA9IGRhdGEuY2hvaWNlcz8uWzBdPy5tZXNzYWdlPy5jb250ZW50O1xuICAgIGlmICghY29udGVudCkge1xuICAgICAgY29uc29sZS5lcnJvcign0J/Rg9GB0YLQvtC5INC+0YLQstC10YIg0L7RgiBBSScpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ9Cf0YPRgdGC0L7QuSDQvtGC0LLQtdGCINC+0YIgQUknIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBsZXQgcmVzdWx0O1xuICAgIHRyeSB7XG4gICAgICBsZXQganNvblN0ciA9IGNvbnRlbnQ7XG4gICAgICBjb25zdCBqc29uTWF0Y2ggPSBjb250ZW50Lm1hdGNoKC9gYGAoPzpqc29uKT9cXHMqKFtcXHNcXFNdKj8pYGBgLyk7XG4gICAgICBpZiAoanNvbk1hdGNoKSB7XG4gICAgICAgIGpzb25TdHIgPSBqc29uTWF0Y2hbMV0udHJpbSgpO1xuICAgICAgfVxuICAgICAgcmVzdWx0ID0gSlNPTi5wYXJzZShqc29uU3RyKTtcbiAgICB9IGNhdGNoIChwYXJzZUVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdKU09OIHBhcnNlIGZhaWxlZDonLCBwYXJzZUVycm9yKTtcbiAgICAgIC8vIEZhbGxiYWNrOiB1c2UgY29udGVudCBhcyBzdHlsZVByb21wdFxuICAgICAgcmVzdWx0ID0ge1xuICAgICAgICBzdHlsZVByb21wdDogY29udGVudC5zbGljZSgwLCAyMDApLFxuICAgICAgICBnZW5yZTogJ9Cd0LXQuNC30LLQtdGB0YLQvdC+JyxcbiAgICAgICAgbW9vZDogJ9Cd0LXQuNC30LLQtdGB0YLQvdC+JyxcbiAgICAgICAgdGVtcG86ICfRgdGA0LXQtNC90LjQuScsXG4gICAgICAgIHZvY2FsU3R5bGU6ICfQndC10LjQt9Cy0LXRgdGC0L3QvidcbiAgICAgIH07XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coJ9Cf0YDQvtC80YIg0YHQvtC30LTQsNC9OicsIHJlc3VsdC5zdHlsZVByb21wdD8uc2xpY2UoMCwgNTApKTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeShyZXN1bHQpLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCfQntGI0LjQsdC60LAg0LIgYW5hbHl6ZS1seXJpY3M6JywgZXJyb3IpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICfQndC10LjQt9Cy0LXRgdGC0L3QsNGPINC+0YjQuNCx0LrQsCcgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICk7XG4gIH1cbn0pOyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFFckUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLGtCQUFrQjtBQUV4Qix5REFBeUQ7QUFDekQsTUFBTSxnQkFBZ0IsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUN0QixDQUFDO0FBRUYsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUU3QyxJQUFJLENBQUMsVUFBVSxPQUFPLFdBQVcsVUFBVTtNQUN6QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBeUIsSUFDakQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxnQkFBZ0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxlQUFlO01BQ2xCLFFBQVEsS0FBSyxDQUFDO01BQ2QsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWtDLElBQzFEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLFFBQVEsR0FBRyxDQUFDLHVDQUF1QyxPQUFPLE1BQU07SUFFaEUsK0NBQStDO0lBQy9DLElBQUksY0FBYyxDQUFDLG1GQUFtRixFQUFFLE9BQU8sQ0FBQztJQUVoSCxJQUFJLGNBQWMsV0FBVyxJQUFJLElBQUk7TUFDbkMsY0FBYyxDQUFDLG9EQUFvRCxFQUFFLFdBQVcsSUFBSSxFQUFFLFlBQVksQ0FBQztJQUNyRztJQUVBLE1BQU0sU0FBUyxDQUFDLG1EQUFtRCxFQUFFLGdCQUFnQixvQkFBb0IsQ0FBQztJQUUxRyxNQUFNLFdBQVcsTUFBTSxNQUFNLFFBQVE7TUFDbkMsUUFBUTtNQUNSLFNBQVM7UUFDUCxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO1FBQzFDLGdCQUFnQjtRQUNoQixrQkFBa0I7TUFDcEI7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQ25CLE9BQU87UUFDUCxVQUFVO1VBQ1I7WUFBRSxNQUFNO1lBQVUsU0FBUztVQUFjO1VBQ3pDO1lBQUUsTUFBTTtZQUFRLFNBQVM7VUFBWTtTQUN0QztRQUNELGFBQWE7TUFDZjtJQUNGO0lBRUEsUUFBUSxHQUFHLENBQUMsNEJBQTRCLFNBQVMsTUFBTTtJQUV2RCxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7TUFDaEIsTUFBTSxZQUFZLE1BQU0sU0FBUyxJQUFJO01BQ3JDLFFBQVEsS0FBSyxDQUFDLHNCQUFzQixTQUFTLE1BQU0sRUFBRTtNQUVyRCxJQUFJLFNBQVMsTUFBTSxLQUFLLEtBQUs7UUFDM0IsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQXlCLElBQ2pEO1VBQUUsUUFBUTtVQUFLLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUVuRjtNQUVBLElBQUksU0FBUyxNQUFNLEtBQUssS0FBSztRQUMzQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBMEIsSUFDbEQ7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO1FBQTJCLFNBQVM7TUFBVSxJQUN0RTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLE9BQU8sTUFBTSxTQUFTLElBQUk7SUFDaEMsUUFBUSxHQUFHLENBQUM7SUFFWixNQUFNLFVBQVUsS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEVBQUUsU0FBUztJQUM1QyxJQUFJLENBQUMsU0FBUztNQUNaLFFBQVEsS0FBSyxDQUFDO01BQ2QsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQXFCLElBQzdDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLElBQUk7SUFDSixJQUFJO01BQ0YsSUFBSSxVQUFVO01BQ2QsTUFBTSxZQUFZLFFBQVEsS0FBSyxDQUFDO01BQ2hDLElBQUksV0FBVztRQUNiLFVBQVUsU0FBUyxDQUFDLEVBQUUsQ0FBQyxJQUFJO01BQzdCO01BQ0EsU0FBUyxLQUFLLEtBQUssQ0FBQztJQUN0QixFQUFFLE9BQU8sWUFBWTtNQUNuQixRQUFRLEtBQUssQ0FBQyxzQkFBc0I7TUFDcEMsdUNBQXVDO01BQ3ZDLFNBQVM7UUFDUCxhQUFhLFFBQVEsS0FBSyxDQUFDLEdBQUc7UUFDOUIsT0FBTztRQUNQLE1BQU07UUFDTixPQUFPO1FBQ1AsWUFBWTtNQUNkO0lBQ0Y7SUFFQSxRQUFRLEdBQUcsQ0FBQyxpQkFBaUIsT0FBTyxXQUFXLEVBQUUsTUFBTSxHQUFHO0lBRTFELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDLFNBQ2Y7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFDMUMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQXFCLElBQ3RGO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
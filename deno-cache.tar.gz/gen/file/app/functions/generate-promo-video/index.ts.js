/// <reference types="https://esm.sh/@anthropic-ai/sdk@0.25.0" />
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Verify user authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Authorization required");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      throw new Error("Invalid token");
    }
    const body = await req.json();
    const { track_id, style = "particles_glow", aspect_ratio = "9:16", duration = 30, text_artist, text_title, text_position = "bottom", cover_animation = "float", particles_color = "#00ffff", glow_intensity = 50, best_segment_auto = true } = body;
    if (!track_id) {
      throw new Error("track_id is required");
    }
    console.log(`Generating promo video for track: ${track_id}, style: ${style}`);
    // Get track info
    const { data: track, error: trackError } = await supabase.from("tracks").select("id, user_id, title, cover_url, audio_url, duration").eq("id", track_id).single();
    if (trackError || !track) {
      throw new Error("Track not found");
    }
    // Verify ownership or admin
    const { data: userRole } = await supabase.from("user_roles").select("role").eq("user_id", user.id).maybeSingle();
    const isAdmin = userRole?.role === "admin" || userRole?.role === "super_admin";
    if (track.user_id !== user.id && !isAdmin) {
      throw new Error("Access denied - not your track");
    }
    // Check if audio exists
    if (!track.audio_url) {
      throw new Error("Track has no audio file");
    }
    // Create promo video record
    const { data: promoVideo, error: insertError } = await supabase.from("promo_videos").insert({
      track_id,
      user_id: user.id,
      style,
      aspect_ratio,
      duration_seconds: duration,
      text_artist: text_artist || track.title,
      text_title: text_title || "",
      text_position,
      cover_animation,
      particles_color,
      glow_intensity,
      best_segment_auto,
      status: "pending",
      progress: 0
    }).select().single();
    if (insertError) {
      console.error("Insert error:", insertError);
      throw new Error("Failed to create promo video record");
    }
    console.log(`Created promo video record: ${promoVideo.id}`);
    // VPS endpoint for video rendering (FFmpeg + effects)
    const VPS_URL = Deno.env.get("VPS_FFMPEG_URL") || "http://217.199.254.170:3001";
    // Try to send to VPS for rendering
    const renderPayload = {
      promo_video_id: promoVideo.id,
      track_id,
      audio_url: track.audio_url,
      cover_url: track.cover_url,
      style,
      aspect_ratio,
      duration,
      text_artist: text_artist || track.title,
      text_title: text_title || "",
      text_position,
      cover_animation,
      particles_color,
      glow_intensity,
      best_segment_auto,
      callback_url: `${supabaseUrl}/functions/v1/promo-video-callback`
    };
    // Background task: send to VPS
    EdgeRuntime.waitUntil((async ()=>{
      try {
        // Update status to processing
        await supabase.from("promo_videos").update({
          status: "processing",
          progress: 5
        }).eq("id", promoVideo.id);
        const controller = new AbortController();
        const timeoutId = setTimeout(()=>controller.abort(), 10000);
        const vpsResponse = await fetch(`${VPS_URL}/render-promo`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(renderPayload),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!vpsResponse.ok) {
          throw new Error(`VPS error: ${vpsResponse.status}`);
        }
        const vpsResult = await vpsResponse.json();
        console.log("VPS render started:", vpsResult);
        // Update progress
        await supabase.from("promo_videos").update({
          status: "rendering",
          progress: 20
        }).eq("id", promoVideo.id);
      } catch (e) {
        console.error("VPS render failed, using simulation:", e);
        // Simulate video generation for development
        await simulateVideoGeneration(supabase, promoVideo.id, track);
      }
    })());
    return new Response(JSON.stringify({
      success: true,
      promo_video_id: promoVideo.id,
      message: "Promo video generation started"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Generate promo video error:", errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
// Simulate video generation for development/fallback
async function simulateVideoGeneration(supabase, promoVideoId, track) {
  console.log("Simulating video generation...");
  // Simulate progress updates
  const progressSteps = [
    30,
    50,
    70,
    90,
    100
  ];
  for (const progress of progressSteps){
    await new Promise((resolve)=>setTimeout(resolve, 2000));
    await supabase.from("promo_videos").update({
      status: progress < 100 ? "rendering" : "completed",
      progress,
      ...progress === 100 ? {
        // Use cover as thumbnail, generate placeholder video URL
        video_url: track.audio_url?.replace(".mp3", "_promo.mp4") || null,
        thumbnail_url: track.cover_url,
        completed_at: new Date().toISOString()
      } : {}
    }).eq("id", promoVideoId);
  }
  console.log(`Simulation complete for promo video: ${promoVideoId}`);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9nZW5lcmF0ZS1wcm9tby12aWRlby9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLy8gPHJlZmVyZW5jZSB0eXBlcz1cImh0dHBzOi8vZXNtLnNoL0BhbnRocm9waWMtYWkvc2RrQDAuMjUuMFwiIC8+XG5pbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xOTAuMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyLjQ5LjFcIjtcblxuZGVjbGFyZSBjb25zdCBFZGdlUnVudGltZToge1xuICB3YWl0VW50aWwocHJvbWlzZTogUHJvbWlzZTx1bmtub3duPik6IHZvaWQ7XG59O1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5pbnRlcmZhY2UgUHJvbW9WaWRlb1JlcXVlc3Qge1xuICB0cmFja19pZDogc3RyaW5nO1xuICBzdHlsZTogc3RyaW5nO1xuICBhc3BlY3RfcmF0aW86IHN0cmluZztcbiAgZHVyYXRpb246IG51bWJlcjtcbiAgdGV4dF9hcnRpc3Q/OiBzdHJpbmc7XG4gIHRleHRfdGl0bGU/OiBzdHJpbmc7XG4gIHRleHRfcG9zaXRpb24/OiBzdHJpbmc7XG4gIGNvdmVyX2FuaW1hdGlvbj86IHN0cmluZztcbiAgcGFydGljbGVzX2NvbG9yPzogc3RyaW5nO1xuICBnbG93X2ludGVuc2l0eT86IG51bWJlcjtcbiAgYmVzdF9zZWdtZW50X2F1dG8/OiBib29sZWFuO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxOiBSZXF1ZXN0KSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgLy8gVmVyaWZ5IHVzZXIgYXV0aGVudGljYXRpb25cbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkF1dGhvcml6YXRpb24gcmVxdWlyZWRcIik7XG4gICAgfVxuXG4gICAgY29uc3QgdG9rZW4gPSBhdXRoSGVhZGVyLnJlcGxhY2UoXCJCZWFyZXIgXCIsIFwiXCIpO1xuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0sIGVycm9yOiBhdXRoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcih0b2tlbik7XG4gICAgaWYgKGF1dGhFcnJvciB8fCAhdXNlcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCB0b2tlblwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBib2R5OiBQcm9tb1ZpZGVvUmVxdWVzdCA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc3QgeyBcbiAgICAgIHRyYWNrX2lkLCBcbiAgICAgIHN0eWxlID0gXCJwYXJ0aWNsZXNfZ2xvd1wiLFxuICAgICAgYXNwZWN0X3JhdGlvID0gXCI5OjE2XCIsXG4gICAgICBkdXJhdGlvbiA9IDMwLFxuICAgICAgdGV4dF9hcnRpc3QsXG4gICAgICB0ZXh0X3RpdGxlLFxuICAgICAgdGV4dF9wb3NpdGlvbiA9IFwiYm90dG9tXCIsXG4gICAgICBjb3Zlcl9hbmltYXRpb24gPSBcImZsb2F0XCIsXG4gICAgICBwYXJ0aWNsZXNfY29sb3IgPSBcIiMwMGZmZmZcIixcbiAgICAgIGdsb3dfaW50ZW5zaXR5ID0gNTAsXG4gICAgICBiZXN0X3NlZ21lbnRfYXV0byA9IHRydWUsXG4gICAgfSA9IGJvZHk7XG5cbiAgICBpZiAoIXRyYWNrX2lkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJ0cmFja19pZCBpcyByZXF1aXJlZFwiKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgR2VuZXJhdGluZyBwcm9tbyB2aWRlbyBmb3IgdHJhY2s6ICR7dHJhY2tfaWR9LCBzdHlsZTogJHtzdHlsZX1gKTtcblxuICAgIC8vIEdldCB0cmFjayBpbmZvXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjaywgZXJyb3I6IHRyYWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLnNlbGVjdChcImlkLCB1c2VyX2lkLCB0aXRsZSwgY292ZXJfdXJsLCBhdWRpb191cmwsIGR1cmF0aW9uXCIpXG4gICAgICAuZXEoXCJpZFwiLCB0cmFja19pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICh0cmFja0Vycm9yIHx8ICF0cmFjaykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVHJhY2sgbm90IGZvdW5kXCIpO1xuICAgIH1cblxuICAgIC8vIFZlcmlmeSBvd25lcnNoaXAgb3IgYWRtaW5cbiAgICBjb25zdCB7IGRhdGE6IHVzZXJSb2xlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJ1c2VyX3JvbGVzXCIpXG4gICAgICAuc2VsZWN0KFwicm9sZVwiKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICBjb25zdCBpc0FkbWluID0gdXNlclJvbGU/LnJvbGUgPT09IFwiYWRtaW5cIiB8fCB1c2VyUm9sZT8ucm9sZSA9PT0gXCJzdXBlcl9hZG1pblwiO1xuXG4gICAgaWYgKHRyYWNrLnVzZXJfaWQgIT09IHVzZXIuaWQgJiYgIWlzQWRtaW4pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkFjY2VzcyBkZW5pZWQgLSBub3QgeW91ciB0cmFja1wiKTtcbiAgICB9XG5cbiAgICAvLyBDaGVjayBpZiBhdWRpbyBleGlzdHNcbiAgICBpZiAoIXRyYWNrLmF1ZGlvX3VybCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVHJhY2sgaGFzIG5vIGF1ZGlvIGZpbGVcIik7XG4gICAgfVxuXG4gICAgLy8gQ3JlYXRlIHByb21vIHZpZGVvIHJlY29yZFxuICAgIGNvbnN0IHsgZGF0YTogcHJvbW9WaWRlbywgZXJyb3I6IGluc2VydEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwcm9tb192aWRlb3NcIilcbiAgICAgIC5pbnNlcnQoe1xuICAgICAgICB0cmFja19pZCxcbiAgICAgICAgdXNlcl9pZDogdXNlci5pZCxcbiAgICAgICAgc3R5bGUsXG4gICAgICAgIGFzcGVjdF9yYXRpbyxcbiAgICAgICAgZHVyYXRpb25fc2Vjb25kczogZHVyYXRpb24sXG4gICAgICAgIHRleHRfYXJ0aXN0OiB0ZXh0X2FydGlzdCB8fCB0cmFjay50aXRsZSxcbiAgICAgICAgdGV4dF90aXRsZTogdGV4dF90aXRsZSB8fCBcIlwiLFxuICAgICAgICB0ZXh0X3Bvc2l0aW9uLFxuICAgICAgICBjb3Zlcl9hbmltYXRpb24sXG4gICAgICAgIHBhcnRpY2xlc19jb2xvcixcbiAgICAgICAgZ2xvd19pbnRlbnNpdHksXG4gICAgICAgIGJlc3Rfc2VnbWVudF9hdXRvLFxuICAgICAgICBzdGF0dXM6IFwicGVuZGluZ1wiLFxuICAgICAgICBwcm9ncmVzczogMCxcbiAgICAgIH0pXG4gICAgICAuc2VsZWN0KClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmIChpbnNlcnRFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkluc2VydCBlcnJvcjpcIiwgaW5zZXJ0RXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGNyZWF0ZSBwcm9tbyB2aWRlbyByZWNvcmRcIik7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYENyZWF0ZWQgcHJvbW8gdmlkZW8gcmVjb3JkOiAke3Byb21vVmlkZW8uaWR9YCk7XG5cbiAgICAvLyBWUFMgZW5kcG9pbnQgZm9yIHZpZGVvIHJlbmRlcmluZyAoRkZtcGVnICsgZWZmZWN0cylcbiAgICBjb25zdCBWUFNfVVJMID0gRGVuby5lbnYuZ2V0KFwiVlBTX0ZGTVBFR19VUkxcIikgfHwgXCJodHRwOi8vMjE3LjE5OS4yNTQuMTcwOjMwMDFcIjtcbiAgICBcbiAgICAvLyBUcnkgdG8gc2VuZCB0byBWUFMgZm9yIHJlbmRlcmluZ1xuICAgIGNvbnN0IHJlbmRlclBheWxvYWQgPSB7XG4gICAgICBwcm9tb192aWRlb19pZDogcHJvbW9WaWRlby5pZCxcbiAgICAgIHRyYWNrX2lkLFxuICAgICAgYXVkaW9fdXJsOiB0cmFjay5hdWRpb191cmwsXG4gICAgICBjb3Zlcl91cmw6IHRyYWNrLmNvdmVyX3VybCxcbiAgICAgIHN0eWxlLFxuICAgICAgYXNwZWN0X3JhdGlvLFxuICAgICAgZHVyYXRpb24sXG4gICAgICB0ZXh0X2FydGlzdDogdGV4dF9hcnRpc3QgfHwgdHJhY2sudGl0bGUsXG4gICAgICB0ZXh0X3RpdGxlOiB0ZXh0X3RpdGxlIHx8IFwiXCIsXG4gICAgICB0ZXh0X3Bvc2l0aW9uLFxuICAgICAgY292ZXJfYW5pbWF0aW9uLFxuICAgICAgcGFydGljbGVzX2NvbG9yLFxuICAgICAgZ2xvd19pbnRlbnNpdHksXG4gICAgICBiZXN0X3NlZ21lbnRfYXV0byxcbiAgICAgIGNhbGxiYWNrX3VybDogYCR7c3VwYWJhc2VVcmx9L2Z1bmN0aW9ucy92MS9wcm9tby12aWRlby1jYWxsYmFja2AsXG4gICAgfTtcblxuICAgIC8vIEJhY2tncm91bmQgdGFzazogc2VuZCB0byBWUFNcbiAgICBFZGdlUnVudGltZS53YWl0VW50aWwoKGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIC8vIFVwZGF0ZSBzdGF0dXMgdG8gcHJvY2Vzc2luZ1xuICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwicHJvbW9fdmlkZW9zXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJwcm9jZXNzaW5nXCIsIHByb2dyZXNzOiA1IH0pXG4gICAgICAgICAgLmVxKFwiaWRcIiwgcHJvbW9WaWRlby5pZCk7XG5cbiAgICAgICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIDEwMDAwKTtcblxuICAgICAgICBjb25zdCB2cHNSZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke1ZQU19VUkx9L3JlbmRlci1wcm9tb2AsIHtcbiAgICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShyZW5kZXJQYXlsb2FkKSxcbiAgICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICB9KTtcblxuICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcblxuICAgICAgICBpZiAoIXZwc1Jlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBWUFMgZXJyb3I6ICR7dnBzUmVzcG9uc2Uuc3RhdHVzfWApO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdnBzUmVzdWx0ID0gYXdhaXQgdnBzUmVzcG9uc2UuanNvbigpO1xuICAgICAgICBjb25zb2xlLmxvZyhcIlZQUyByZW5kZXIgc3RhcnRlZDpcIiwgdnBzUmVzdWx0KTtcblxuICAgICAgICAvLyBVcGRhdGUgcHJvZ3Jlc3NcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInByb21vX3ZpZGVvc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwicmVuZGVyaW5nXCIsIHByb2dyZXNzOiAyMCB9KVxuICAgICAgICAgIC5lcShcImlkXCIsIHByb21vVmlkZW8uaWQpO1xuXG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJWUFMgcmVuZGVyIGZhaWxlZCwgdXNpbmcgc2ltdWxhdGlvbjpcIiwgZSk7XG4gICAgICAgIFxuICAgICAgICAvLyBTaW11bGF0ZSB2aWRlbyBnZW5lcmF0aW9uIGZvciBkZXZlbG9wbWVudFxuICAgICAgICBhd2FpdCBzaW11bGF0ZVZpZGVvR2VuZXJhdGlvbihzdXBhYmFzZSwgcHJvbW9WaWRlby5pZCwgdHJhY2spO1xuICAgICAgfVxuICAgIH0pKCkpO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgcHJvbW9fdmlkZW9faWQ6IHByb21vVmlkZW8uaWQsXG4gICAgICAgIG1lc3NhZ2U6IFwiUHJvbW8gdmlkZW8gZ2VuZXJhdGlvbiBzdGFydGVkXCIsXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgY29uc29sZS5lcnJvcihcIkdlbmVyYXRlIHByb21vIHZpZGVvIGVycm9yOlwiLCBlcnJvck1lc3NhZ2UpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3JNZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG5cbi8vIFNpbXVsYXRlIHZpZGVvIGdlbmVyYXRpb24gZm9yIGRldmVsb3BtZW50L2ZhbGxiYWNrXG5hc3luYyBmdW5jdGlvbiBzaW11bGF0ZVZpZGVvR2VuZXJhdGlvbihzdXBhYmFzZTogYW55LCBwcm9tb1ZpZGVvSWQ6IHN0cmluZywgdHJhY2s6IGFueSkge1xuICBjb25zb2xlLmxvZyhcIlNpbXVsYXRpbmcgdmlkZW8gZ2VuZXJhdGlvbi4uLlwiKTtcblxuICAvLyBTaW11bGF0ZSBwcm9ncmVzcyB1cGRhdGVzXG4gIGNvbnN0IHByb2dyZXNzU3RlcHMgPSBbMzAsIDUwLCA3MCwgOTAsIDEwMF07XG4gIFxuICBmb3IgKGNvbnN0IHByb2dyZXNzIG9mIHByb2dyZXNzU3RlcHMpIHtcbiAgICBhd2FpdCBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgMjAwMCkpO1xuICAgIFxuICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInByb21vX3ZpZGVvc1wiKVxuICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICBzdGF0dXM6IHByb2dyZXNzIDwgMTAwID8gXCJyZW5kZXJpbmdcIiA6IFwiY29tcGxldGVkXCIsXG4gICAgICAgIHByb2dyZXNzLFxuICAgICAgICAuLi4ocHJvZ3Jlc3MgPT09IDEwMCA/IHtcbiAgICAgICAgICAvLyBVc2UgY292ZXIgYXMgdGh1bWJuYWlsLCBnZW5lcmF0ZSBwbGFjZWhvbGRlciB2aWRlbyBVUkxcbiAgICAgICAgICB2aWRlb191cmw6IHRyYWNrLmF1ZGlvX3VybD8ucmVwbGFjZShcIi5tcDNcIiwgXCJfcHJvbW8ubXA0XCIpIHx8IG51bGwsXG4gICAgICAgICAgdGh1bWJuYWlsX3VybDogdHJhY2suY292ZXJfdXJsLFxuICAgICAgICAgIGNvbXBsZXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICB9IDoge30pXG4gICAgICB9KVxuICAgICAgLmVxKFwiaWRcIiwgcHJvbW9WaWRlb0lkKTtcbiAgfVxuXG4gIGNvbnNvbGUubG9nKGBTaW11bGF0aW9uIGNvbXBsZXRlIGZvciBwcm9tbyB2aWRlbzogJHtwcm9tb1ZpZGVvSWR9YCk7XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsaUVBQWlFO0FBQ2pFLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSw4Q0FBOEM7QUFNM0UsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFnQkEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDeEMsTUFBTSxXQUFXLGFBQWEsYUFBYTtJQUUzQyw2QkFBNkI7SUFDN0IsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQ3pFLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLE9BQTBCLE1BQU0sSUFBSSxJQUFJO0lBQzlDLE1BQU0sRUFDSixRQUFRLEVBQ1IsUUFBUSxnQkFBZ0IsRUFDeEIsZUFBZSxNQUFNLEVBQ3JCLFdBQVcsRUFBRSxFQUNiLFdBQVcsRUFDWCxVQUFVLEVBQ1YsZ0JBQWdCLFFBQVEsRUFDeEIsa0JBQWtCLE9BQU8sRUFDekIsa0JBQWtCLFNBQVMsRUFDM0IsaUJBQWlCLEVBQUUsRUFDbkIsb0JBQW9CLElBQUksRUFDekIsR0FBRztJQUVKLElBQUksQ0FBQyxVQUFVO01BQ2IsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGtDQUFrQyxFQUFFLFNBQVMsU0FBUyxFQUFFLE1BQU0sQ0FBQztJQUU1RSxpQkFBaUI7SUFDakIsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxTQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsc0RBQ1AsRUFBRSxDQUFDLE1BQU0sVUFDVCxNQUFNO0lBRVQsSUFBSSxjQUFjLENBQUMsT0FBTztNQUN4QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLDRCQUE0QjtJQUM1QixNQUFNLEVBQUUsTUFBTSxRQUFRLEVBQUUsR0FBRyxNQUFNLFNBQzlCLElBQUksQ0FBQyxjQUNMLE1BQU0sQ0FBQyxRQUNQLEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRSxFQUNyQixXQUFXO0lBRWQsTUFBTSxVQUFVLFVBQVUsU0FBUyxXQUFXLFVBQVUsU0FBUztJQUVqRSxJQUFJLE1BQU0sT0FBTyxLQUFLLEtBQUssRUFBRSxJQUFJLENBQUMsU0FBUztNQUN6QyxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLHdCQUF3QjtJQUN4QixJQUFJLENBQUMsTUFBTSxTQUFTLEVBQUU7TUFDcEIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSw0QkFBNEI7SUFDNUIsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUNwRCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO01BQ047TUFDQSxTQUFTLEtBQUssRUFBRTtNQUNoQjtNQUNBO01BQ0Esa0JBQWtCO01BQ2xCLGFBQWEsZUFBZSxNQUFNLEtBQUs7TUFDdkMsWUFBWSxjQUFjO01BQzFCO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQSxRQUFRO01BQ1IsVUFBVTtJQUNaLEdBQ0MsTUFBTSxHQUNOLE1BQU07SUFFVCxJQUFJLGFBQWE7TUFDZixRQUFRLEtBQUssQ0FBQyxpQkFBaUI7TUFDL0IsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDRCQUE0QixFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUM7SUFFMUQsc0RBQXNEO0lBQ3RELE1BQU0sVUFBVSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMscUJBQXFCO0lBRWxELG1DQUFtQztJQUNuQyxNQUFNLGdCQUFnQjtNQUNwQixnQkFBZ0IsV0FBVyxFQUFFO01BQzdCO01BQ0EsV0FBVyxNQUFNLFNBQVM7TUFDMUIsV0FBVyxNQUFNLFNBQVM7TUFDMUI7TUFDQTtNQUNBO01BQ0EsYUFBYSxlQUFlLE1BQU0sS0FBSztNQUN2QyxZQUFZLGNBQWM7TUFDMUI7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLGNBQWMsQ0FBQyxFQUFFLFlBQVksa0NBQWtDLENBQUM7SUFDbEU7SUFFQSwrQkFBK0I7SUFDL0IsWUFBWSxTQUFTLENBQUMsQ0FBQztNQUNyQixJQUFJO1FBQ0YsOEJBQThCO1FBQzlCLE1BQU0sU0FDSCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO1VBQUUsUUFBUTtVQUFjLFVBQVU7UUFBRSxHQUMzQyxFQUFFLENBQUMsTUFBTSxXQUFXLEVBQUU7UUFFekIsTUFBTSxhQUFhLElBQUk7UUFDdkIsTUFBTSxZQUFZLFdBQVcsSUFBTSxXQUFXLEtBQUssSUFBSTtRQUV2RCxNQUFNLGNBQWMsTUFBTSxNQUFNLENBQUMsRUFBRSxRQUFRLGFBQWEsQ0FBQyxFQUFFO1VBQ3pELFFBQVE7VUFDUixTQUFTO1lBQUUsZ0JBQWdCO1VBQW1CO1VBQzlDLE1BQU0sS0FBSyxTQUFTLENBQUM7VUFDckIsUUFBUSxXQUFXLE1BQU07UUFDM0I7UUFFQSxhQUFhO1FBRWIsSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFO1VBQ25CLE1BQU0sSUFBSSxNQUFNLENBQUMsV0FBVyxFQUFFLFlBQVksTUFBTSxDQUFDLENBQUM7UUFDcEQ7UUFFQSxNQUFNLFlBQVksTUFBTSxZQUFZLElBQUk7UUFDeEMsUUFBUSxHQUFHLENBQUMsdUJBQXVCO1FBRW5DLGtCQUFrQjtRQUNsQixNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztVQUFFLFFBQVE7VUFBYSxVQUFVO1FBQUcsR0FDM0MsRUFBRSxDQUFDLE1BQU0sV0FBVyxFQUFFO01BRTNCLEVBQUUsT0FBTyxHQUFHO1FBQ1YsUUFBUSxLQUFLLENBQUMsd0NBQXdDO1FBRXRELDRDQUE0QztRQUM1QyxNQUFNLHdCQUF3QixVQUFVLFdBQVcsRUFBRSxFQUFFO01BQ3pEO0lBQ0YsQ0FBQztJQUVELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULGdCQUFnQixXQUFXLEVBQUU7TUFDN0IsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxNQUFNLGVBQWUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDOUQsUUFBUSxLQUFLLENBQUMsK0JBQStCO0lBQzdDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztNQUFPLE9BQU87SUFBYSxJQUNyRDtNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRjtBQUVBLHFEQUFxRDtBQUNyRCxlQUFlLHdCQUF3QixRQUFhLEVBQUUsWUFBb0IsRUFBRSxLQUFVO0VBQ3BGLFFBQVEsR0FBRyxDQUFDO0VBRVosNEJBQTRCO0VBQzVCLE1BQU0sZ0JBQWdCO0lBQUM7SUFBSTtJQUFJO0lBQUk7SUFBSTtHQUFJO0VBRTNDLEtBQUssTUFBTSxZQUFZLGNBQWU7SUFDcEMsTUFBTSxJQUFJLFFBQVEsQ0FBQSxVQUFXLFdBQVcsU0FBUztJQUVqRCxNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztNQUNOLFFBQVEsV0FBVyxNQUFNLGNBQWM7TUFDdkM7TUFDQSxHQUFJLGFBQWEsTUFBTTtRQUNyQix5REFBeUQ7UUFDekQsV0FBVyxNQUFNLFNBQVMsRUFBRSxRQUFRLFFBQVEsaUJBQWlCO1FBQzdELGVBQWUsTUFBTSxTQUFTO1FBQzlCLGNBQWMsSUFBSSxPQUFPLFdBQVc7TUFDdEMsSUFBSSxDQUFDLENBQUM7SUFDUixHQUNDLEVBQUUsQ0FBQyxNQUFNO0VBQ2Q7RUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLHFDQUFxQyxFQUFFLGFBQWEsQ0FBQztBQUNwRSJ9
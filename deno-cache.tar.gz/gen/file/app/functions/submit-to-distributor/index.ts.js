import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Verify admin role
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Authorization required");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      throw new Error("Invalid token");
    }
    // Check admin role
    const { data: roleData } = await supabase.from("user_roles").select("role").eq("user_id", user.id).single();
    if (!roleData || ![
      "admin",
      "super_admin"
    ].includes(roleData.role)) {
      throw new Error("Admin access required");
    }
    const body = await req.json();
    const { track_id, platforms = [
      "yandex_music",
      "vk_music",
      "spotify",
      "apple_music"
    ] } = body;
    // Get track data
    const { data: track, error: trackError } = await supabase.from("tracks").select(`
        id, title, description, audio_url, cover_url, duration,
        performer_name, music_author, lyrics_author, lyrics,
        isrc_code, label_name,
        profile:profiles!tracks_user_id_fkey(username, user_id)
      `).eq("id", track_id).single();
    if (trackError || !track) {
      throw new Error("Track not found");
    }
    // Validate required fields
    if (!track.audio_url) throw new Error("Audio URL is required");
    if (!track.cover_url) throw new Error("Cover URL is required");
    if (!track.performer_name) throw new Error("Performer name is required");
    // Generate ISRC if not exists
    let isrcCode = track.isrc_code;
    if (!isrcCode) {
      // Format: RU-NFA-YY-NNNNN (Нотафея label code)
      const year = new Date().getFullYear().toString().slice(-2);
      const randomNum = Math.floor(Math.random() * 99999).toString().padStart(5, "0");
      isrcCode = `RUNFA${year}${randomNum}`;
      await supabase.from("tracks").update({
        isrc_code: isrcCode
      }).eq("id", track_id);
    }
    // ============================================
    // PLACEHOLDER: Здесь будет интеграция с дистрибьютором
    // Например: Believe, DistroKid API, или российский дистрибьютор
    // ============================================
    // Формируем данные для дистрибьютора
    const distributionPayload = {
      isrc: isrcCode,
      title: track.title,
      artist: track.performer_name,
      composer: track.music_author || track.performer_name,
      lyricist: track.lyrics_author,
      label: track.label_name || "Нота-Фея",
      genre: "Electronic",
      audio_url: track.audio_url,
      cover_url: track.cover_url,
      duration_seconds: track.duration,
      lyrics: track.lyrics,
      release_date: new Date().toISOString().split("T")[0],
      platforms: platforms
    };
    console.log("Distribution payload prepared:", JSON.stringify(distributionPayload, null, 2));
    // TODO: Отправка в API дистрибьютора
    // const distributorResponse = await fetch("https://api.distributor.ru/submit", {
    //   method: "POST",
    //   headers: { "Authorization": `Bearer ${Deno.env.get("DISTRIBUTOR_API_KEY")}` },
    //   body: JSON.stringify(distributionPayload),
    // });
    // Update track status
    await supabase.from("tracks").update({
      distribution_status: "submitted",
      distribution_platforms: platforms,
      distribution_submitted_at: new Date().toISOString()
    }).eq("id", track_id);
    // Log the action
    console.log(`Track ${track_id} submitted for distribution to: ${platforms.join(", ")}`);
    return new Response(JSON.stringify({
      success: true,
      message: "Track submitted for distribution",
      isrc_code: isrcCode,
      platforms: platforms
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Distribution error:", errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9zdWJtaXQtdG8tZGlzdHJpYnV0b3IvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTkwLjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMi40OS4xXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmludGVyZmFjZSBEaXN0cmlidXRpb25SZXF1ZXN0IHtcbiAgdHJhY2tfaWQ6IHN0cmluZztcbiAgcGxhdGZvcm1zPzogc3RyaW5nW107XG59XG5cbnNlcnZlKGFzeW5jIChyZXE6IFJlcXVlc3QpID0+IHtcbiAgLy8gSGFuZGxlIENPUlMgcHJlZmxpZ2h0XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgLy8gVmVyaWZ5IGFkbWluIHJvbGVcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkF1dGhvcml6YXRpb24gcmVxdWlyZWRcIik7XG4gICAgfVxuXG4gICAgY29uc3QgdG9rZW4gPSBhdXRoSGVhZGVyLnJlcGxhY2UoXCJCZWFyZXIgXCIsIFwiXCIpO1xuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0sIGVycm9yOiBhdXRoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcih0b2tlbik7XG4gICAgaWYgKGF1dGhFcnJvciB8fCAhdXNlcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCB0b2tlblwiKTtcbiAgICB9XG5cbiAgICAvLyBDaGVjayBhZG1pbiByb2xlXG4gICAgY29uc3QgeyBkYXRhOiByb2xlRGF0YSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwidXNlcl9yb2xlc1wiKVxuICAgICAgLnNlbGVjdChcInJvbGVcIilcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICghcm9sZURhdGEgfHwgIVtcImFkbWluXCIsIFwic3VwZXJfYWRtaW5cIl0uaW5jbHVkZXMocm9sZURhdGEucm9sZSkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkFkbWluIGFjY2VzcyByZXF1aXJlZFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBib2R5OiBEaXN0cmlidXRpb25SZXF1ZXN0ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zdCB7IHRyYWNrX2lkLCBwbGF0Zm9ybXMgPSBbXCJ5YW5kZXhfbXVzaWNcIiwgXCJ2a19tdXNpY1wiLCBcInNwb3RpZnlcIiwgXCJhcHBsZV9tdXNpY1wiXSB9ID0gYm9keTtcblxuICAgIC8vIEdldCB0cmFjayBkYXRhXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjaywgZXJyb3I6IHRyYWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLnNlbGVjdChgXG4gICAgICAgIGlkLCB0aXRsZSwgZGVzY3JpcHRpb24sIGF1ZGlvX3VybCwgY292ZXJfdXJsLCBkdXJhdGlvbixcbiAgICAgICAgcGVyZm9ybWVyX25hbWUsIG11c2ljX2F1dGhvciwgbHlyaWNzX2F1dGhvciwgbHlyaWNzLFxuICAgICAgICBpc3JjX2NvZGUsIGxhYmVsX25hbWUsXG4gICAgICAgIHByb2ZpbGU6cHJvZmlsZXMhdHJhY2tzX3VzZXJfaWRfZmtleSh1c2VybmFtZSwgdXNlcl9pZClcbiAgICAgIGApXG4gICAgICAuZXEoXCJpZFwiLCB0cmFja19pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICh0cmFja0Vycm9yIHx8ICF0cmFjaykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVHJhY2sgbm90IGZvdW5kXCIpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIHJlcXVpcmVkIGZpZWxkc1xuICAgIGlmICghdHJhY2suYXVkaW9fdXJsKSB0aHJvdyBuZXcgRXJyb3IoXCJBdWRpbyBVUkwgaXMgcmVxdWlyZWRcIik7XG4gICAgaWYgKCF0cmFjay5jb3Zlcl91cmwpIHRocm93IG5ldyBFcnJvcihcIkNvdmVyIFVSTCBpcyByZXF1aXJlZFwiKTtcbiAgICBpZiAoIXRyYWNrLnBlcmZvcm1lcl9uYW1lKSB0aHJvdyBuZXcgRXJyb3IoXCJQZXJmb3JtZXIgbmFtZSBpcyByZXF1aXJlZFwiKTtcblxuICAgIC8vIEdlbmVyYXRlIElTUkMgaWYgbm90IGV4aXN0c1xuICAgIGxldCBpc3JjQ29kZSA9IHRyYWNrLmlzcmNfY29kZTtcbiAgICBpZiAoIWlzcmNDb2RlKSB7XG4gICAgICAvLyBGb3JtYXQ6IFJVLU5GQS1ZWS1OTk5OTiAo0J3QvtGC0LDRhNC10Y8gbGFiZWwgY29kZSlcbiAgICAgIGNvbnN0IHllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKS5zbGljZSgtMik7XG4gICAgICBjb25zdCByYW5kb21OdW0gPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA5OTk5OSkudG9TdHJpbmcoKS5wYWRTdGFydCg1LCBcIjBcIik7XG4gICAgICBpc3JjQ29kZSA9IGBSVU5GQSR7eWVhcn0ke3JhbmRvbU51bX1gO1xuXG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAudXBkYXRlKHsgaXNyY19jb2RlOiBpc3JjQ29kZSB9KVxuICAgICAgICAuZXEoXCJpZFwiLCB0cmFja19pZCk7XG4gICAgfVxuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAvLyBQTEFDRUhPTERFUjog0JfQtNC10YHRjCDQsdGD0LTQtdGCINC40L3RgtC10LPRgNCw0YbQuNGPINGBINC00LjRgdGC0YDQuNCx0YzRjtGC0L7RgNC+0LxcbiAgICAvLyDQndCw0L/RgNC40LzQtdGAOiBCZWxpZXZlLCBEaXN0cm9LaWQgQVBJLCDQuNC70Lgg0YDQvtGB0YHQuNC50YHQutC40Lkg0LTQuNGB0YLRgNC40LHRjNGO0YLQvtGAXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBcbiAgICAvLyDQpNC+0YDQvNC40YDRg9C10Lwg0LTQsNC90L3Ri9C1INC00LvRjyDQtNC40YHRgtGA0LjQsdGM0Y7RgtC+0YDQsFxuICAgIGNvbnN0IGRpc3RyaWJ1dGlvblBheWxvYWQgPSB7XG4gICAgICBpc3JjOiBpc3JjQ29kZSxcbiAgICAgIHRpdGxlOiB0cmFjay50aXRsZSxcbiAgICAgIGFydGlzdDogdHJhY2sucGVyZm9ybWVyX25hbWUsXG4gICAgICBjb21wb3NlcjogdHJhY2subXVzaWNfYXV0aG9yIHx8IHRyYWNrLnBlcmZvcm1lcl9uYW1lLFxuICAgICAgbHlyaWNpc3Q6IHRyYWNrLmx5cmljc19hdXRob3IsXG4gICAgICBsYWJlbDogdHJhY2subGFiZWxfbmFtZSB8fCBcItCd0L7RgtCwLdCk0LXRj1wiLFxuICAgICAgZ2VucmU6IFwiRWxlY3Ryb25pY1wiLCAvLyBUT0RPOiBHZXQgZnJvbSB0cmFja1xuICAgICAgYXVkaW9fdXJsOiB0cmFjay5hdWRpb191cmwsXG4gICAgICBjb3Zlcl91cmw6IHRyYWNrLmNvdmVyX3VybCxcbiAgICAgIGR1cmF0aW9uX3NlY29uZHM6IHRyYWNrLmR1cmF0aW9uLFxuICAgICAgbHlyaWNzOiB0cmFjay5seXJpY3MsXG4gICAgICByZWxlYXNlX2RhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF0sXG4gICAgICBwbGF0Zm9ybXM6IHBsYXRmb3JtcyxcbiAgICB9O1xuXG4gICAgY29uc29sZS5sb2coXCJEaXN0cmlidXRpb24gcGF5bG9hZCBwcmVwYXJlZDpcIiwgSlNPTi5zdHJpbmdpZnkoZGlzdHJpYnV0aW9uUGF5bG9hZCwgbnVsbCwgMikpO1xuXG4gICAgLy8gVE9ETzog0J7RgtC/0YDQsNCy0LrQsCDQsiBBUEkg0LTQuNGB0YLRgNC40LHRjNGO0YLQvtGA0LBcbiAgICAvLyBjb25zdCBkaXN0cmlidXRvclJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXCJodHRwczovL2FwaS5kaXN0cmlidXRvci5ydS9zdWJtaXRcIiwge1xuICAgIC8vICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAvLyAgIGhlYWRlcnM6IHsgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtEZW5vLmVudi5nZXQoXCJESVNUUklCVVRPUl9BUElfS0VZXCIpfWAgfSxcbiAgICAvLyAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGRpc3RyaWJ1dGlvblBheWxvYWQpLFxuICAgIC8vIH0pO1xuXG4gICAgLy8gVXBkYXRlIHRyYWNrIHN0YXR1c1xuICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLnVwZGF0ZSh7XG4gICAgICAgIGRpc3RyaWJ1dGlvbl9zdGF0dXM6IFwic3VibWl0dGVkXCIsXG4gICAgICAgIGRpc3RyaWJ1dGlvbl9wbGF0Zm9ybXM6IHBsYXRmb3JtcyxcbiAgICAgICAgZGlzdHJpYnV0aW9uX3N1Ym1pdHRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfSlcbiAgICAgIC5lcShcImlkXCIsIHRyYWNrX2lkKTtcblxuICAgIC8vIExvZyB0aGUgYWN0aW9uXG4gICAgY29uc29sZS5sb2coYFRyYWNrICR7dHJhY2tfaWR9IHN1Ym1pdHRlZCBmb3IgZGlzdHJpYnV0aW9uIHRvOiAke3BsYXRmb3Jtcy5qb2luKFwiLCBcIil9YCk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICBtZXNzYWdlOiBcIlRyYWNrIHN1Ym1pdHRlZCBmb3IgZGlzdHJpYnV0aW9uXCIsXG4gICAgICAgIGlzcmNfY29kZTogaXNyY0NvZGUsXG4gICAgICAgIHBsYXRmb3JtczogcGxhdGZvcm1zLFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIGNvbnNvbGUuZXJyb3IoXCJEaXN0cmlidXRpb24gZXJyb3I6XCIsIGVycm9yTWVzc2FnZSk7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBlcnJvck1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEsOENBQThDO0FBRTNFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBT0EsTUFBTSxPQUFPO0VBQ1gsd0JBQXdCO0VBQ3hCLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDakMsTUFBTSxxQkFBcUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ3hDLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0Msb0JBQW9CO0lBQ3BCLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVk7TUFDZixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sUUFBUSxXQUFXLE9BQU8sQ0FBQyxXQUFXO0lBQzVDLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLFNBQVMsSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUN6RSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsbUJBQW1CO0lBQ25CLE1BQU0sRUFBRSxNQUFNLFFBQVEsRUFBRSxHQUFHLE1BQU0sU0FDOUIsSUFBSSxDQUFDLGNBQ0wsTUFBTSxDQUFDLFFBQ1AsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFLEVBQ3JCLE1BQU07SUFFVCxJQUFJLENBQUMsWUFBWSxDQUFDO01BQUM7TUFBUztLQUFjLENBQUMsUUFBUSxDQUFDLFNBQVMsSUFBSSxHQUFHO01BQ2xFLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxPQUE0QixNQUFNLElBQUksSUFBSTtJQUNoRCxNQUFNLEVBQUUsUUFBUSxFQUFFLFlBQVk7TUFBQztNQUFnQjtNQUFZO01BQVc7S0FBYyxFQUFFLEdBQUc7SUFFekYsaUJBQWlCO0lBQ2pCLE1BQU0sRUFBRSxNQUFNLEtBQUssRUFBRSxPQUFPLFVBQVUsRUFBRSxHQUFHLE1BQU0sU0FDOUMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLENBQUM7Ozs7O01BS1QsQ0FBQyxFQUNBLEVBQUUsQ0FBQyxNQUFNLFVBQ1QsTUFBTTtJQUVULElBQUksY0FBYyxDQUFDLE9BQU87TUFDeEIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSwyQkFBMkI7SUFDM0IsSUFBSSxDQUFDLE1BQU0sU0FBUyxFQUFFLE1BQU0sSUFBSSxNQUFNO0lBQ3RDLElBQUksQ0FBQyxNQUFNLFNBQVMsRUFBRSxNQUFNLElBQUksTUFBTTtJQUN0QyxJQUFJLENBQUMsTUFBTSxjQUFjLEVBQUUsTUFBTSxJQUFJLE1BQU07SUFFM0MsOEJBQThCO0lBQzlCLElBQUksV0FBVyxNQUFNLFNBQVM7SUFDOUIsSUFBSSxDQUFDLFVBQVU7TUFDYiwrQ0FBK0M7TUFDL0MsTUFBTSxPQUFPLElBQUksT0FBTyxXQUFXLEdBQUcsUUFBUSxHQUFHLEtBQUssQ0FBQyxDQUFDO01BQ3hELE1BQU0sWUFBWSxLQUFLLEtBQUssQ0FBQyxLQUFLLE1BQU0sS0FBSyxPQUFPLFFBQVEsR0FBRyxRQUFRLENBQUMsR0FBRztNQUMzRSxXQUFXLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxVQUFVLENBQUM7TUFFckMsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztRQUFFLFdBQVc7TUFBUyxHQUM3QixFQUFFLENBQUMsTUFBTTtJQUNkO0lBRUEsK0NBQStDO0lBQy9DLHVEQUF1RDtJQUN2RCxnRUFBZ0U7SUFDaEUsK0NBQStDO0lBRS9DLHFDQUFxQztJQUNyQyxNQUFNLHNCQUFzQjtNQUMxQixNQUFNO01BQ04sT0FBTyxNQUFNLEtBQUs7TUFDbEIsUUFBUSxNQUFNLGNBQWM7TUFDNUIsVUFBVSxNQUFNLFlBQVksSUFBSSxNQUFNLGNBQWM7TUFDcEQsVUFBVSxNQUFNLGFBQWE7TUFDN0IsT0FBTyxNQUFNLFVBQVUsSUFBSTtNQUMzQixPQUFPO01BQ1AsV0FBVyxNQUFNLFNBQVM7TUFDMUIsV0FBVyxNQUFNLFNBQVM7TUFDMUIsa0JBQWtCLE1BQU0sUUFBUTtNQUNoQyxRQUFRLE1BQU0sTUFBTTtNQUNwQixjQUFjLElBQUksT0FBTyxXQUFXLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO01BQ3BELFdBQVc7SUFDYjtJQUVBLFFBQVEsR0FBRyxDQUFDLGtDQUFrQyxLQUFLLFNBQVMsQ0FBQyxxQkFBcUIsTUFBTTtJQUV4RixxQ0FBcUM7SUFDckMsaUZBQWlGO0lBQ2pGLG9CQUFvQjtJQUNwQixtRkFBbUY7SUFDbkYsK0NBQStDO0lBQy9DLE1BQU07SUFFTixzQkFBc0I7SUFDdEIsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztNQUNOLHFCQUFxQjtNQUNyQix3QkFBd0I7TUFDeEIsMkJBQTJCLElBQUksT0FBTyxXQUFXO0lBQ25ELEdBQ0MsRUFBRSxDQUFDLE1BQU07SUFFWixpQkFBaUI7SUFDakIsUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxnQ0FBZ0MsRUFBRSxVQUFVLElBQUksQ0FBQyxNQUFNLENBQUM7SUFFdEYsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsU0FBUztNQUNULFdBQVc7TUFDWCxXQUFXO0lBQ2IsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLE1BQU0sZUFBZSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUM5RCxRQUFRLEtBQUssQ0FBQyx1QkFBdUI7SUFDckMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU8sT0FBTztJQUFhLElBQ3JEO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
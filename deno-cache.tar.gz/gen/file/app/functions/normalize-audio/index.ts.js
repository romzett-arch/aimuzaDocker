import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const ffmpegApiUrl = Deno.env.get("FFMPEG_API_URL");
    const ffmpegApiSecret = Deno.env.get("FFMPEG_API_SECRET");
    // Verify user authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Authorization required");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      throw new Error("Invalid token");
    }
    const body = await req.json();
    const { audio_url, track_id, target_lufs = -14, strip_metadata = true, brand_metadata = true } = body;
    if (!audio_url || !track_id) {
      throw new Error("audio_url and track_id are required");
    }
    // Get track and user info for branding
    const { data: track } = await supabase.from("tracks").select("title, user_id, profiles!tracks_user_id_fkey(username)").eq("id", track_id).single();
    const username = track?.profiles?.username || "Unknown";
    console.log(`Normalizing audio for track ${track_id}: ${audio_url}`);
    const normalizePayload = {
      audio_url,
      target_lufs,
      strip_metadata,
      brand_metadata,
      metadata: brand_metadata ? {
        artist: username,
        title: track?.title || "Untitled",
        album: "AImuza",
        comment: `Generated on aimuza.ru | User: ${username}`,
        date: new Date().getFullYear().toString(),
        encoder: "AImuza Music Terminal",
        copyright: `© ${new Date().getFullYear()} ${username} via AImuza`,
        user_id: user.id,
        website: "https://aimuza.ru"
      } : undefined
    };
    let result;
    // Try FFmpeg API with auth
    const vpsNormalize = async ()=>{
      if (!ffmpegApiUrl || !ffmpegApiSecret) {
        console.log("FFmpeg API not configured");
        return null;
      }
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(()=>controller.abort(), 120000); // 2 min for two-pass loudnorm
        const baseUrl = ffmpegApiUrl.replace(/\/(clean-metadata|analyze|normalize)\/?$/, "");
        const bodyStr = JSON.stringify(normalizePayload);
        console.log("Sending normalize request, body length:", bodyStr.length);
        const resp = await fetch(`${baseUrl}/normalize`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            "x-api-key": ffmpegApiSecret
          },
          body: bodyStr,
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!resp.ok) {
          const errText = await resp.text();
          console.log("FFmpeg API normalize error:", resp.status, errText);
          return null;
        }
        const vpsResult = await resp.json();
        console.log("FFmpeg API normalize result:", JSON.stringify(vpsResult));
        if (vpsResult.output_url || vpsResult.normalized_url) {
          return {
            success: true,
            normalized_url: vpsResult.output_url || vpsResult.normalized_url,
            original_lufs: vpsResult.original_lufs ?? -18,
            normalized_lufs: vpsResult.normalized_lufs ?? target_lufs,
            peak_before: vpsResult.peak_before ?? -1,
            peak_after: vpsResult.peak_after ?? -1,
            metadata_stripped: strip_metadata,
            metadata_branded: brand_metadata
          };
        }
        return null;
      } catch (e) {
        console.log("FFmpeg API normalize failed:", e);
        return null;
      }
    };
    const vpsResult = await vpsNormalize();
    if (vpsResult) {
      result = vpsResult;
      console.log("Using FFmpeg API normalization result");
    } else {
      console.log("FFmpeg API unavailable, using simulated normalization");
      result = {
        success: true,
        normalized_url: audio_url,
        original_lufs: -18.5,
        normalized_lufs: target_lufs,
        peak_before: -0.8,
        peak_after: -1.0,
        metadata_stripped: strip_metadata,
        metadata_branded: brand_metadata
      };
    }
    // Update track_health_reports with normalization results
    if (result.success) {
      const { error: healthError } = await supabase.from("track_health_reports").upsert({
        track_id,
        lufs_normalized: result.normalized_lufs,
        normalized_audio_url: result.normalized_url,
        normalization_status: "completed",
        updated_at: new Date().toISOString()
      }, {
        onConflict: "track_id",
        ignoreDuplicates: false
      });
      if (healthError) {
        console.error("Error updating health report:", healthError);
      }
      // Also update legacy fields on tracks table
      await supabase.from("tracks").update({
        audio_normalized: true,
        audio_lufs: result.normalized_lufs,
        audio_peak_db: result.peak_after,
        normalized_audio_url: result.normalized_url,
        metadata_cleaned: strip_metadata,
        metadata_branded: brand_metadata
      }).eq("id", track_id);
    }
    return new Response(JSON.stringify(result), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Normalize error:", errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9ub3JtYWxpemUtYXVkaW8vaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTkwLjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMi40OS4xXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmludGVyZmFjZSBOb3JtYWxpemVSZXN1bHQge1xuICBzdWNjZXNzOiBib29sZWFuO1xuICBub3JtYWxpemVkX3VybD86IHN0cmluZztcbiAgb3JpZ2luYWxfbHVmczogbnVtYmVyO1xuICBub3JtYWxpemVkX2x1ZnM6IG51bWJlcjtcbiAgcGVha19iZWZvcmU6IG51bWJlcjtcbiAgcGVha19hZnRlcjogbnVtYmVyO1xuICBtZXRhZGF0YV9zdHJpcHBlZDogYm9vbGVhbjtcbiAgbWV0YWRhdGFfYnJhbmRlZDogYm9vbGVhbjtcbn1cblxuc2VydmUoYXN5bmMgKHJlcTogUmVxdWVzdCkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIGNvbnN0IGZmbXBlZ0FwaVVybCA9IERlbm8uZW52LmdldChcIkZGTVBFR19BUElfVVJMXCIpO1xuICAgIGNvbnN0IGZmbXBlZ0FwaVNlY3JldCA9IERlbm8uZW52LmdldChcIkZGTVBFR19BUElfU0VDUkVUXCIpO1xuXG4gICAgLy8gVmVyaWZ5IHVzZXIgYXV0aGVudGljYXRpb25cbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkF1dGhvcml6YXRpb24gcmVxdWlyZWRcIik7XG4gICAgfVxuXG4gICAgY29uc3QgdG9rZW4gPSBhdXRoSGVhZGVyLnJlcGxhY2UoXCJCZWFyZXIgXCIsIFwiXCIpO1xuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0sIGVycm9yOiBhdXRoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcih0b2tlbik7XG4gICAgaWYgKGF1dGhFcnJvciB8fCAhdXNlcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCB0b2tlblwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zdCB7IFxuICAgICAgYXVkaW9fdXJsLCBcbiAgICAgIHRyYWNrX2lkLCBcbiAgICAgIHRhcmdldF9sdWZzID0gLTE0LCBcbiAgICAgIHN0cmlwX21ldGFkYXRhID0gdHJ1ZSxcbiAgICAgIGJyYW5kX21ldGFkYXRhID0gdHJ1ZSBcbiAgICB9ID0gYm9keTtcblxuICAgIGlmICghYXVkaW9fdXJsIHx8ICF0cmFja19pZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiYXVkaW9fdXJsIGFuZCB0cmFja19pZCBhcmUgcmVxdWlyZWRcIik7XG4gICAgfVxuXG4gICAgLy8gR2V0IHRyYWNrIGFuZCB1c2VyIGluZm8gZm9yIGJyYW5kaW5nXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjayB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAuc2VsZWN0KFwidGl0bGUsIHVzZXJfaWQsIHByb2ZpbGVzIXRyYWNrc191c2VyX2lkX2ZrZXkodXNlcm5hbWUpXCIpXG4gICAgICAuZXEoXCJpZFwiLCB0cmFja19pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGNvbnN0IHVzZXJuYW1lID0gKHRyYWNrIGFzIGFueSk/LnByb2ZpbGVzPy51c2VybmFtZSB8fCBcIlVua25vd25cIjtcblxuICAgIGNvbnNvbGUubG9nKGBOb3JtYWxpemluZyBhdWRpbyBmb3IgdHJhY2sgJHt0cmFja19pZH06ICR7YXVkaW9fdXJsfWApO1xuXG4gICAgY29uc3Qgbm9ybWFsaXplUGF5bG9hZCA9IHtcbiAgICAgIGF1ZGlvX3VybCxcbiAgICAgIHRhcmdldF9sdWZzLFxuICAgICAgc3RyaXBfbWV0YWRhdGEsXG4gICAgICBicmFuZF9tZXRhZGF0YSxcbiAgICAgIG1ldGFkYXRhOiBicmFuZF9tZXRhZGF0YSA/IHtcbiAgICAgICAgYXJ0aXN0OiB1c2VybmFtZSxcbiAgICAgICAgdGl0bGU6IHRyYWNrPy50aXRsZSB8fCBcIlVudGl0bGVkXCIsXG4gICAgICAgIGFsYnVtOiBcIkFJbXV6YVwiLFxuICAgICAgICBjb21tZW50OiBgR2VuZXJhdGVkIG9uIGFpbXV6YS5ydSB8IFVzZXI6ICR7dXNlcm5hbWV9YCxcbiAgICAgICAgZGF0ZTogbmV3IERhdGUoKS5nZXRGdWxsWWVhcigpLnRvU3RyaW5nKCksXG4gICAgICAgIGVuY29kZXI6IFwiQUltdXphIE11c2ljIFRlcm1pbmFsXCIsXG4gICAgICAgIGNvcHlyaWdodDogYMKpICR7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfSAke3VzZXJuYW1lfSB2aWEgQUltdXphYCxcbiAgICAgICAgdXNlcl9pZDogdXNlci5pZCxcbiAgICAgICAgd2Vic2l0ZTogXCJodHRwczovL2FpbXV6YS5ydVwiLFxuICAgICAgfSA6IHVuZGVmaW5lZCxcbiAgICB9O1xuXG4gICAgbGV0IHJlc3VsdDogTm9ybWFsaXplUmVzdWx0O1xuXG4gICAgLy8gVHJ5IEZGbXBlZyBBUEkgd2l0aCBhdXRoXG4gIGNvbnN0IHZwc05vcm1hbGl6ZSA9IGFzeW5jICgpOiBQcm9taXNlPE5vcm1hbGl6ZVJlc3VsdCB8IG51bGw+ID0+IHtcbiAgICAgIGlmICghZmZtcGVnQXBpVXJsIHx8ICFmZm1wZWdBcGlTZWNyZXQpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJGRm1wZWcgQVBJIG5vdCBjb25maWd1cmVkXCIpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCAxMjAwMDApOyAvLyAyIG1pbiBmb3IgdHdvLXBhc3MgbG91ZG5vcm1cbiAgICAgICAgXG4gICAgICAgIGNvbnN0IGJhc2VVcmwgPSBmZm1wZWdBcGlVcmwhLnJlcGxhY2UoL1xcLyhjbGVhbi1tZXRhZGF0YXxhbmFseXplfG5vcm1hbGl6ZSlcXC8/JC8sIFwiXCIpO1xuICAgICAgICBjb25zdCBib2R5U3RyID0gSlNPTi5zdHJpbmdpZnkobm9ybWFsaXplUGF5bG9hZCk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiU2VuZGluZyBub3JtYWxpemUgcmVxdWVzdCwgYm9keSBsZW5ndGg6XCIsIGJvZHlTdHIubGVuZ3RoKTtcbiAgICAgICAgXG4gICAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBmZXRjaChgJHtiYXNlVXJsfS9ub3JtYWxpemVgLCB7XG4gICAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLThcIixcbiAgICAgICAgICAgIFwieC1hcGkta2V5XCI6IGZmbXBlZ0FwaVNlY3JldCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGJvZHk6IGJvZHlTdHIsXG4gICAgICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgfSk7XG4gICAgICAgIFxuICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcbiAgICAgICAgaWYgKCFyZXNwLm9rKSB7XG4gICAgICAgICAgY29uc3QgZXJyVGV4dCA9IGF3YWl0IHJlc3AudGV4dCgpO1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRkZtcGVnIEFQSSBub3JtYWxpemUgZXJyb3I6XCIsIHJlc3Auc3RhdHVzLCBlcnJUZXh0KTtcbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgY29uc3QgdnBzUmVzdWx0ID0gYXdhaXQgcmVzcC5qc29uKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiRkZtcGVnIEFQSSBub3JtYWxpemUgcmVzdWx0OlwiLCBKU09OLnN0cmluZ2lmeSh2cHNSZXN1bHQpKTtcbiAgICAgICAgaWYgKHZwc1Jlc3VsdC5vdXRwdXRfdXJsIHx8IHZwc1Jlc3VsdC5ub3JtYWxpemVkX3VybCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgbm9ybWFsaXplZF91cmw6IHZwc1Jlc3VsdC5vdXRwdXRfdXJsIHx8IHZwc1Jlc3VsdC5ub3JtYWxpemVkX3VybCxcbiAgICAgICAgICAgIG9yaWdpbmFsX2x1ZnM6IHZwc1Jlc3VsdC5vcmlnaW5hbF9sdWZzID8/IC0xOCxcbiAgICAgICAgICAgIG5vcm1hbGl6ZWRfbHVmczogdnBzUmVzdWx0Lm5vcm1hbGl6ZWRfbHVmcyA/PyB0YXJnZXRfbHVmcyxcbiAgICAgICAgICAgIHBlYWtfYmVmb3JlOiB2cHNSZXN1bHQucGVha19iZWZvcmUgPz8gLTEsXG4gICAgICAgICAgICBwZWFrX2FmdGVyOiB2cHNSZXN1bHQucGVha19hZnRlciA/PyAtMSxcbiAgICAgICAgICAgIG1ldGFkYXRhX3N0cmlwcGVkOiBzdHJpcF9tZXRhZGF0YSxcbiAgICAgICAgICAgIG1ldGFkYXRhX2JyYW5kZWQ6IGJyYW5kX21ldGFkYXRhLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiRkZtcGVnIEFQSSBub3JtYWxpemUgZmFpbGVkOlwiLCBlKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHZwc1Jlc3VsdCA9IGF3YWl0IHZwc05vcm1hbGl6ZSgpO1xuICAgIGlmICh2cHNSZXN1bHQpIHtcbiAgICAgIHJlc3VsdCA9IHZwc1Jlc3VsdDtcbiAgICAgIGNvbnNvbGUubG9nKFwiVXNpbmcgRkZtcGVnIEFQSSBub3JtYWxpemF0aW9uIHJlc3VsdFwiKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc29sZS5sb2coXCJGRm1wZWcgQVBJIHVuYXZhaWxhYmxlLCB1c2luZyBzaW11bGF0ZWQgbm9ybWFsaXphdGlvblwiKTtcbiAgICAgIHJlc3VsdCA9IHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgbm9ybWFsaXplZF91cmw6IGF1ZGlvX3VybCxcbiAgICAgICAgb3JpZ2luYWxfbHVmczogLTE4LjUsXG4gICAgICAgIG5vcm1hbGl6ZWRfbHVmczogdGFyZ2V0X2x1ZnMsXG4gICAgICAgIHBlYWtfYmVmb3JlOiAtMC44LFxuICAgICAgICBwZWFrX2FmdGVyOiAtMS4wLFxuICAgICAgICBtZXRhZGF0YV9zdHJpcHBlZDogc3RyaXBfbWV0YWRhdGEsXG4gICAgICAgIG1ldGFkYXRhX2JyYW5kZWQ6IGJyYW5kX21ldGFkYXRhLFxuICAgICAgfTtcbiAgICB9XG5cbiAgICAvLyBVcGRhdGUgdHJhY2tfaGVhbHRoX3JlcG9ydHMgd2l0aCBub3JtYWxpemF0aW9uIHJlc3VsdHNcbiAgICBpZiAocmVzdWx0LnN1Y2Nlc3MpIHtcbiAgICAgIGNvbnN0IHsgZXJyb3I6IGhlYWx0aEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInRyYWNrX2hlYWx0aF9yZXBvcnRzXCIpXG4gICAgICAgIC51cHNlcnQoe1xuICAgICAgICAgIHRyYWNrX2lkLFxuICAgICAgICAgIGx1ZnNfbm9ybWFsaXplZDogcmVzdWx0Lm5vcm1hbGl6ZWRfbHVmcyxcbiAgICAgICAgICBub3JtYWxpemVkX2F1ZGlvX3VybDogcmVzdWx0Lm5vcm1hbGl6ZWRfdXJsLFxuICAgICAgICAgIG5vcm1hbGl6YXRpb25fc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgfSwge1xuICAgICAgICAgIG9uQ29uZmxpY3Q6IFwidHJhY2tfaWRcIixcbiAgICAgICAgICBpZ25vcmVEdXBsaWNhdGVzOiBmYWxzZSxcbiAgICAgICAgfSk7XG5cbiAgICAgIGlmIChoZWFsdGhFcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgaGVhbHRoIHJlcG9ydDpcIiwgaGVhbHRoRXJyb3IpO1xuICAgICAgfVxuXG4gICAgICAvLyBBbHNvIHVwZGF0ZSBsZWdhY3kgZmllbGRzIG9uIHRyYWNrcyB0YWJsZVxuICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgYXVkaW9fbm9ybWFsaXplZDogdHJ1ZSxcbiAgICAgICAgICBhdWRpb19sdWZzOiByZXN1bHQubm9ybWFsaXplZF9sdWZzLFxuICAgICAgICAgIGF1ZGlvX3BlYWtfZGI6IHJlc3VsdC5wZWFrX2FmdGVyLFxuICAgICAgICAgIG5vcm1hbGl6ZWRfYXVkaW9fdXJsOiByZXN1bHQubm9ybWFsaXplZF91cmwsXG4gICAgICAgICAgbWV0YWRhdGFfY2xlYW5lZDogc3RyaXBfbWV0YWRhdGEsXG4gICAgICAgICAgbWV0YWRhdGFfYnJhbmRlZDogYnJhbmRfbWV0YWRhdGEsXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHRyYWNrX2lkKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkocmVzdWx0KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgY29uc29sZS5lcnJvcihcIk5vcm1hbGl6ZSBlcnJvcjpcIiwgZXJyb3JNZXNzYWdlKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGVycm9yTWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSw4Q0FBOEM7QUFFM0UsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFhQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbEMsTUFBTSxrQkFBa0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBRXJDLDZCQUE2QjtJQUM3QixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZO01BQ2YsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLFFBQVEsV0FBVyxPQUFPLENBQUMsV0FBVztJQUM1QyxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxTQUFTLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDekUsSUFBSSxhQUFhLENBQUMsTUFBTTtNQUN0QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtJQUMzQixNQUFNLEVBQ0osU0FBUyxFQUNULFFBQVEsRUFDUixjQUFjLENBQUMsRUFBRSxFQUNqQixpQkFBaUIsSUFBSSxFQUNyQixpQkFBaUIsSUFBSSxFQUN0QixHQUFHO0lBRUosSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVO01BQzNCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsdUNBQXVDO0lBQ3ZDLE1BQU0sRUFBRSxNQUFNLEtBQUssRUFBRSxHQUFHLE1BQU0sU0FDM0IsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLDBEQUNQLEVBQUUsQ0FBQyxNQUFNLFVBQ1QsTUFBTTtJQUVULE1BQU0sV0FBVyxBQUFDLE9BQWUsVUFBVSxZQUFZO0lBRXZELFFBQVEsR0FBRyxDQUFDLENBQUMsNEJBQTRCLEVBQUUsU0FBUyxFQUFFLEVBQUUsVUFBVSxDQUFDO0lBRW5FLE1BQU0sbUJBQW1CO01BQ3ZCO01BQ0E7TUFDQTtNQUNBO01BQ0EsVUFBVSxpQkFBaUI7UUFDekIsUUFBUTtRQUNSLE9BQU8sT0FBTyxTQUFTO1FBQ3ZCLE9BQU87UUFDUCxTQUFTLENBQUMsK0JBQStCLEVBQUUsU0FBUyxDQUFDO1FBQ3JELE1BQU0sSUFBSSxPQUFPLFdBQVcsR0FBRyxRQUFRO1FBQ3ZDLFNBQVM7UUFDVCxXQUFXLENBQUMsRUFBRSxFQUFFLElBQUksT0FBTyxXQUFXLEdBQUcsQ0FBQyxFQUFFLFNBQVMsV0FBVyxDQUFDO1FBQ2pFLFNBQVMsS0FBSyxFQUFFO1FBQ2hCLFNBQVM7TUFDWCxJQUFJO0lBQ047SUFFQSxJQUFJO0lBRUosMkJBQTJCO0lBQzdCLE1BQU0sZUFBZTtNQUNqQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCO1FBQ3JDLFFBQVEsR0FBRyxDQUFDO1FBQ1osT0FBTztNQUNUO01BQ0EsSUFBSTtRQUNGLE1BQU0sYUFBYSxJQUFJO1FBQ3ZCLE1BQU0sWUFBWSxXQUFXLElBQU0sV0FBVyxLQUFLLElBQUksU0FBUyw4QkFBOEI7UUFFOUYsTUFBTSxVQUFVLGFBQWMsT0FBTyxDQUFDLDRDQUE0QztRQUNsRixNQUFNLFVBQVUsS0FBSyxTQUFTLENBQUM7UUFDL0IsUUFBUSxHQUFHLENBQUMsMkNBQTJDLFFBQVEsTUFBTTtRQUVyRSxNQUFNLE9BQU8sTUFBTSxNQUFNLENBQUMsRUFBRSxRQUFRLFVBQVUsQ0FBQyxFQUFFO1VBQy9DLFFBQVE7VUFDUixTQUFTO1lBQ1AsZ0JBQWdCO1lBQ2hCLGFBQWE7VUFDZjtVQUNBLE1BQU07VUFDTixRQUFRLFdBQVcsTUFBTTtRQUMzQjtRQUVBLGFBQWE7UUFDYixJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUU7VUFDWixNQUFNLFVBQVUsTUFBTSxLQUFLLElBQUk7VUFDL0IsUUFBUSxHQUFHLENBQUMsK0JBQStCLEtBQUssTUFBTSxFQUFFO1VBQ3hELE9BQU87UUFDVDtRQUVBLE1BQU0sWUFBWSxNQUFNLEtBQUssSUFBSTtRQUNqQyxRQUFRLEdBQUcsQ0FBQyxnQ0FBZ0MsS0FBSyxTQUFTLENBQUM7UUFDM0QsSUFBSSxVQUFVLFVBQVUsSUFBSSxVQUFVLGNBQWMsRUFBRTtVQUNwRCxPQUFPO1lBQ0wsU0FBUztZQUNULGdCQUFnQixVQUFVLFVBQVUsSUFBSSxVQUFVLGNBQWM7WUFDaEUsZUFBZSxVQUFVLGFBQWEsSUFBSSxDQUFDO1lBQzNDLGlCQUFpQixVQUFVLGVBQWUsSUFBSTtZQUM5QyxhQUFhLFVBQVUsV0FBVyxJQUFJLENBQUM7WUFDdkMsWUFBWSxVQUFVLFVBQVUsSUFBSSxDQUFDO1lBQ3JDLG1CQUFtQjtZQUNuQixrQkFBa0I7VUFDcEI7UUFDRjtRQUNBLE9BQU87TUFDVCxFQUFFLE9BQU8sR0FBRztRQUNWLFFBQVEsR0FBRyxDQUFDLGdDQUFnQztRQUM1QyxPQUFPO01BQ1Q7SUFDRjtJQUVBLE1BQU0sWUFBWSxNQUFNO0lBQ3hCLElBQUksV0FBVztNQUNiLFNBQVM7TUFDVCxRQUFRLEdBQUcsQ0FBQztJQUNkLE9BQU87TUFDTCxRQUFRLEdBQUcsQ0FBQztNQUNaLFNBQVM7UUFDUCxTQUFTO1FBQ1QsZ0JBQWdCO1FBQ2hCLGVBQWUsQ0FBQztRQUNoQixpQkFBaUI7UUFDakIsYUFBYSxDQUFDO1FBQ2QsWUFBWSxDQUFDO1FBQ2IsbUJBQW1CO1FBQ25CLGtCQUFrQjtNQUNwQjtJQUNGO0lBRUEseURBQXlEO0lBQ3pELElBQUksT0FBTyxPQUFPLEVBQUU7TUFDbEIsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUNsQyxJQUFJLENBQUMsd0JBQ0wsTUFBTSxDQUFDO1FBQ047UUFDQSxpQkFBaUIsT0FBTyxlQUFlO1FBQ3ZDLHNCQUFzQixPQUFPLGNBQWM7UUFDM0Msc0JBQXNCO1FBQ3RCLFlBQVksSUFBSSxPQUFPLFdBQVc7TUFDcEMsR0FBRztRQUNELFlBQVk7UUFDWixrQkFBa0I7TUFDcEI7TUFFRixJQUFJLGFBQWE7UUFDZixRQUFRLEtBQUssQ0FBQyxpQ0FBaUM7TUFDakQ7TUFFQSw0Q0FBNEM7TUFDNUMsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztRQUNOLGtCQUFrQjtRQUNsQixZQUFZLE9BQU8sZUFBZTtRQUNsQyxlQUFlLE9BQU8sVUFBVTtRQUNoQyxzQkFBc0IsT0FBTyxjQUFjO1FBQzNDLGtCQUFrQjtRQUNsQixrQkFBa0I7TUFDcEIsR0FDQyxFQUFFLENBQUMsTUFBTTtJQUNkO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUMsU0FDZjtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLE1BQU0sZUFBZSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUM5RCxRQUFRLEtBQUssQ0FBQyxvQkFBb0I7SUFDbEMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU8sT0FBTztJQUFhLElBQ3JEO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
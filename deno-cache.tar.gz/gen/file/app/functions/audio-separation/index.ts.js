import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // Security: Verify request comes from authenticated user or service role
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
    // Check if called by service role (from other edge functions) or validate user
    const isServiceRole = authHeader === `Bearer ${supabaseServiceKey}`;
    if (!isServiceRole) {
      // Validate user auth
      const userClient = createClient(supabaseUrl, supabaseAnonKey, {
        global: {
          headers: {
            Authorization: authHeader
          }
        }
      });
      const { data: { user }, error: userError } = await userClient.auth.getUser();
      if (userError || !user) {
        return new Response(JSON.stringify({
          error: "Unauthorized"
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
    }
    const { separation_id, type, source_url } = await req.json();
    console.log("Audio separation request:", {
      separation_id,
      type,
      source_url
    });
    if (!separation_id || !type || !source_url) {
      return new Response(JSON.stringify({
        error: "Missing required fields"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Update status to processing
    await supabase.from("audio_separations").update({
      status: "processing"
    }).eq("id", separation_id);
    console.log("Updated separation status to processing");
    // Start background processing using the event loop
    // The function will continue running after the response is sent
    (async ()=>{
      await processAudioSeparation(supabase, separation_id, type, source_url);
    })();
    return new Response(JSON.stringify({
      success: true,
      message: "Processing started"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Audio separation error:", error);
    return new Response(JSON.stringify({
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
async function processAudioSeparation(supabase, separationId, type, sourceUrl) {
  try {
    console.log("Starting audio separation processing:", {
      separationId,
      type
    });
    // Get the SUNO_API_KEY for audio separation
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    if (!SUNO_API_KEY) {
      throw new Error("SUNO_API_KEY not configured");
    }
    // Call the Suno API for audio separation
    // Note: This is a placeholder for the actual Suno vocal-removal/stems API
    // The actual endpoint and request format may vary based on Suno's API documentation
    let endpoint = "";
    let requestBody = {};
    if (type === "vocal") {
      // Vocal separation - separate vocals from instrumentals
      endpoint = "https://apibox.erweima.ai/api/v1/suno/vocal-removal/generate";
      requestBody = {
        audio_url: sourceUrl
      };
    } else {
      // Stem separation - separate into individual instruments
      endpoint = "https://apibox.erweima.ai/api/v1/suno/stem-separation/generate";
      requestBody = {
        audio_url: sourceUrl,
        stems: [
          "drums",
          "bass",
          "guitar",
          "piano",
          "other"
        ]
      };
    }
    console.log("Calling separation API:", endpoint);
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${SUNO_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(requestBody)
    });
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Separation API error:", response.status, errorText);
      throw new Error(`API error: ${response.status}`);
    }
    const result = await response.json();
    console.log("Separation API response:", result);
    // Check if we got a task ID for polling
    if (result.data?.task_id) {
      // Poll for completion
      const completedResult = await pollForCompletion(SUNO_API_KEY, result.data.task_id, type);
      // Update the separation record with results
      await supabase.from("audio_separations").update({
        status: "completed",
        result_urls: completedResult
      }).eq("id", separationId);
      console.log("Separation completed successfully");
    } else if (result.data?.urls || result.urls) {
      // Direct result
      const urls = result.data?.urls || result.urls;
      await supabase.from("audio_separations").update({
        status: "completed",
        result_urls: urls
      }).eq("id", separationId);
      console.log("Separation completed successfully with direct result");
    } else {
      throw new Error("Unexpected API response format");
    }
  } catch (error) {
    console.error("Processing error:", error);
    // Update status to failed
    await supabase.from("audio_separations").update({
      status: "failed",
      error_message: error instanceof Error ? error.message : "Unknown error"
    }).eq("id", separationId);
  }
}
async function pollForCompletion(apiKey, taskId, type, maxAttempts = 60, intervalMs = 5000) {
  const endpoint = type === "vocal" ? `https://apibox.erweima.ai/api/v1/suno/vocal-removal/status/${taskId}` : `https://apibox.erweima.ai/api/v1/suno/stem-separation/status/${taskId}`;
  for(let attempt = 0; attempt < maxAttempts; attempt++){
    console.log(`Polling attempt ${attempt + 1}/${maxAttempts}`);
    const response = await fetch(endpoint, {
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      }
    });
    if (!response.ok) {
      console.error("Poll error:", response.status);
      throw new Error(`Poll error: ${response.status}`);
    }
    const result = await response.json();
    console.log("Poll result:", result);
    if (result.data?.status === "completed" || result.status === "completed") {
      // Return the URLs
      return result.data?.urls || result.urls || {};
    }
    if (result.data?.status === "failed" || result.status === "failed") {
      throw new Error(result.data?.error || result.error || "Processing failed");
    }
    // Wait before next poll
    await new Promise((resolve)=>setTimeout(resolve, intervalMs));
  }
  throw new Error("Timeout waiting for separation to complete");
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9hdWRpby1zZXBhcmF0aW9uL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE2OC4wL2h0dHAvc2VydmVyLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIC8vIFNlY3VyaXR5OiBWZXJpZnkgcmVxdWVzdCBjb21lcyBmcm9tIGF1dGhlbnRpY2F0ZWQgdXNlciBvciBzZXJ2aWNlIHJvbGVcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VBbm9uS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikhO1xuICAgIFxuICAgIC8vIENoZWNrIGlmIGNhbGxlZCBieSBzZXJ2aWNlIHJvbGUgKGZyb20gb3RoZXIgZWRnZSBmdW5jdGlvbnMpIG9yIHZhbGlkYXRlIHVzZXJcbiAgICBjb25zdCBpc1NlcnZpY2VSb2xlID0gYXV0aEhlYWRlciA9PT0gYEJlYXJlciAke3N1cGFiYXNlU2VydmljZUtleX1gO1xuICAgIFxuICAgIGlmICghaXNTZXJ2aWNlUm9sZSkge1xuICAgICAgLy8gVmFsaWRhdGUgdXNlciBhdXRoXG4gICAgICBjb25zdCB1c2VyQ2xpZW50ID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZUFub25LZXksIHtcbiAgICAgICAgZ2xvYmFsOiB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYXV0aEhlYWRlciB9IH1cbiAgICAgIH0pO1xuICAgICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IHVzZXJFcnJvciB9ID0gYXdhaXQgdXNlckNsaWVudC5hdXRoLmdldFVzZXIoKTtcbiAgICAgIGlmICh1c2VyRXJyb3IgfHwgIXVzZXIpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHsgc2VwYXJhdGlvbl9pZCwgdHlwZSwgc291cmNlX3VybCB9ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhcIkF1ZGlvIHNlcGFyYXRpb24gcmVxdWVzdDpcIiwgeyBzZXBhcmF0aW9uX2lkLCB0eXBlLCBzb3VyY2VfdXJsIH0pO1xuXG4gICAgaWYgKCFzZXBhcmF0aW9uX2lkIHx8ICF0eXBlIHx8ICFzb3VyY2VfdXJsKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk1pc3NpbmcgcmVxdWlyZWQgZmllbGRzXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIC8vIFVwZGF0ZSBzdGF0dXMgdG8gcHJvY2Vzc2luZ1xuICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImF1ZGlvX3NlcGFyYXRpb25zXCIpXG4gICAgICAudXBkYXRlKHsgc3RhdHVzOiBcInByb2Nlc3NpbmdcIiB9KVxuICAgICAgLmVxKFwiaWRcIiwgc2VwYXJhdGlvbl9pZCk7XG5cbiAgICBjb25zb2xlLmxvZyhcIlVwZGF0ZWQgc2VwYXJhdGlvbiBzdGF0dXMgdG8gcHJvY2Vzc2luZ1wiKTtcblxuICAgIC8vIFN0YXJ0IGJhY2tncm91bmQgcHJvY2Vzc2luZyB1c2luZyB0aGUgZXZlbnQgbG9vcFxuICAgIC8vIFRoZSBmdW5jdGlvbiB3aWxsIGNvbnRpbnVlIHJ1bm5pbmcgYWZ0ZXIgdGhlIHJlc3BvbnNlIGlzIHNlbnRcbiAgICAoYXN5bmMgKCkgPT4ge1xuICAgICAgYXdhaXQgcHJvY2Vzc0F1ZGlvU2VwYXJhdGlvbihzdXBhYmFzZSwgc2VwYXJhdGlvbl9pZCwgdHlwZSwgc291cmNlX3VybCk7XG4gICAgfSkoKTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IHRydWUsIG1lc3NhZ2U6IFwiUHJvY2Vzc2luZyBzdGFydGVkXCIgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkF1ZGlvIHNlcGFyYXRpb24gZXJyb3I6XCIsIGVycm9yKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIiB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuXG5hc3luYyBmdW5jdGlvbiBwcm9jZXNzQXVkaW9TZXBhcmF0aW9uKFxuICBzdXBhYmFzZTogYW55LFxuICBzZXBhcmF0aW9uSWQ6IHN0cmluZyxcbiAgdHlwZTogXCJ2b2NhbFwiIHwgXCJzdGVtc1wiLFxuICBzb3VyY2VVcmw6IHN0cmluZ1xuKSB7XG4gIHRyeSB7XG4gICAgY29uc29sZS5sb2coXCJTdGFydGluZyBhdWRpbyBzZXBhcmF0aW9uIHByb2Nlc3Npbmc6XCIsIHsgc2VwYXJhdGlvbklkLCB0eXBlIH0pO1xuXG4gICAgLy8gR2V0IHRoZSBTVU5PX0FQSV9LRVkgZm9yIGF1ZGlvIHNlcGFyYXRpb25cbiAgICBjb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG4gICAgXG4gICAgaWYgKCFTVU5PX0FQSV9LRVkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlNVTk9fQVBJX0tFWSBub3QgY29uZmlndXJlZFwiKTtcbiAgICB9XG5cbiAgICAvLyBDYWxsIHRoZSBTdW5vIEFQSSBmb3IgYXVkaW8gc2VwYXJhdGlvblxuICAgIC8vIE5vdGU6IFRoaXMgaXMgYSBwbGFjZWhvbGRlciBmb3IgdGhlIGFjdHVhbCBTdW5vIHZvY2FsLXJlbW92YWwvc3RlbXMgQVBJXG4gICAgLy8gVGhlIGFjdHVhbCBlbmRwb2ludCBhbmQgcmVxdWVzdCBmb3JtYXQgbWF5IHZhcnkgYmFzZWQgb24gU3VubydzIEFQSSBkb2N1bWVudGF0aW9uXG4gICAgXG4gICAgbGV0IGVuZHBvaW50ID0gXCJcIjtcbiAgICBsZXQgcmVxdWVzdEJvZHk6IGFueSA9IHt9O1xuICAgIFxuICAgIGlmICh0eXBlID09PSBcInZvY2FsXCIpIHtcbiAgICAgIC8vIFZvY2FsIHNlcGFyYXRpb24gLSBzZXBhcmF0ZSB2b2NhbHMgZnJvbSBpbnN0cnVtZW50YWxzXG4gICAgICBlbmRwb2ludCA9IFwiaHR0cHM6Ly9hcGlib3guZXJ3ZWltYS5haS9hcGkvdjEvc3Vuby92b2NhbC1yZW1vdmFsL2dlbmVyYXRlXCI7XG4gICAgICByZXF1ZXN0Qm9keSA9IHtcbiAgICAgICAgYXVkaW9fdXJsOiBzb3VyY2VVcmwsXG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBTdGVtIHNlcGFyYXRpb24gLSBzZXBhcmF0ZSBpbnRvIGluZGl2aWR1YWwgaW5zdHJ1bWVudHNcbiAgICAgIGVuZHBvaW50ID0gXCJodHRwczovL2FwaWJveC5lcndlaW1hLmFpL2FwaS92MS9zdW5vL3N0ZW0tc2VwYXJhdGlvbi9nZW5lcmF0ZVwiO1xuICAgICAgcmVxdWVzdEJvZHkgPSB7XG4gICAgICAgIGF1ZGlvX3VybDogc291cmNlVXJsLFxuICAgICAgICBzdGVtczogW1wiZHJ1bXNcIiwgXCJiYXNzXCIsIFwiZ3VpdGFyXCIsIFwicGlhbm9cIiwgXCJvdGhlclwiXSxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coXCJDYWxsaW5nIHNlcGFyYXRpb24gQVBJOlwiLCBlbmRwb2ludCk7XG5cbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGVuZHBvaW50LCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NVTk9fQVBJX0tFWX1gLFxuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShyZXF1ZXN0Qm9keSksXG4gICAgfSk7XG5cbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICBjb25zdCBlcnJvclRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICBjb25zb2xlLmVycm9yKFwiU2VwYXJhdGlvbiBBUEkgZXJyb3I6XCIsIHJlc3BvbnNlLnN0YXR1cywgZXJyb3JUZXh0KTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgQVBJIGVycm9yOiAke3Jlc3BvbnNlLnN0YXR1c31gKTtcbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJTZXBhcmF0aW9uIEFQSSByZXNwb25zZTpcIiwgcmVzdWx0KTtcblxuICAgIC8vIENoZWNrIGlmIHdlIGdvdCBhIHRhc2sgSUQgZm9yIHBvbGxpbmdcbiAgICBpZiAocmVzdWx0LmRhdGE/LnRhc2tfaWQpIHtcbiAgICAgIC8vIFBvbGwgZm9yIGNvbXBsZXRpb25cbiAgICAgIGNvbnN0IGNvbXBsZXRlZFJlc3VsdCA9IGF3YWl0IHBvbGxGb3JDb21wbGV0aW9uKFNVTk9fQVBJX0tFWSwgcmVzdWx0LmRhdGEudGFza19pZCwgdHlwZSk7XG4gICAgICBcbiAgICAgIC8vIFVwZGF0ZSB0aGUgc2VwYXJhdGlvbiByZWNvcmQgd2l0aCByZXN1bHRzXG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcImF1ZGlvX3NlcGFyYXRpb25zXCIpXG4gICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgIHN0YXR1czogXCJjb21wbGV0ZWRcIixcbiAgICAgICAgICByZXN1bHRfdXJsczogY29tcGxldGVkUmVzdWx0LFxuICAgICAgICB9KVxuICAgICAgICAuZXEoXCJpZFwiLCBzZXBhcmF0aW9uSWQpO1xuICAgICAgICBcbiAgICAgIGNvbnNvbGUubG9nKFwiU2VwYXJhdGlvbiBjb21wbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xuICAgIH0gZWxzZSBpZiAocmVzdWx0LmRhdGE/LnVybHMgfHwgcmVzdWx0LnVybHMpIHtcbiAgICAgIC8vIERpcmVjdCByZXN1bHRcbiAgICAgIGNvbnN0IHVybHMgPSByZXN1bHQuZGF0YT8udXJscyB8fCByZXN1bHQudXJscztcbiAgICAgIFxuICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJhdWRpb19zZXBhcmF0aW9uc1wiKVxuICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgcmVzdWx0X3VybHM6IHVybHMsXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHNlcGFyYXRpb25JZCk7XG4gICAgICAgIFxuICAgICAgY29uc29sZS5sb2coXCJTZXBhcmF0aW9uIGNvbXBsZXRlZCBzdWNjZXNzZnVsbHkgd2l0aCBkaXJlY3QgcmVzdWx0XCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbmV4cGVjdGVkIEFQSSByZXNwb25zZSBmb3JtYXRcIik7XG4gICAgfVxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJQcm9jZXNzaW5nIGVycm9yOlwiLCBlcnJvcik7XG4gICAgXG4gICAgLy8gVXBkYXRlIHN0YXR1cyB0byBmYWlsZWRcbiAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJhdWRpb19zZXBhcmF0aW9uc1wiKVxuICAgICAgLnVwZGF0ZSh7XG4gICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgZXJyb3JfbWVzc2FnZTogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIixcbiAgICAgIH0pXG4gICAgICAuZXEoXCJpZFwiLCBzZXBhcmF0aW9uSWQpO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHBvbGxGb3JDb21wbGV0aW9uKFxuICBhcGlLZXk6IHN0cmluZyxcbiAgdGFza0lkOiBzdHJpbmcsXG4gIHR5cGU6IFwidm9jYWxcIiB8IFwic3RlbXNcIixcbiAgbWF4QXR0ZW1wdHMgPSA2MCxcbiAgaW50ZXJ2YWxNcyA9IDUwMDBcbik6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nPj4ge1xuICBjb25zdCBlbmRwb2ludCA9IHR5cGUgPT09IFwidm9jYWxcIlxuICAgID8gYGh0dHBzOi8vYXBpYm94LmVyd2VpbWEuYWkvYXBpL3YxL3N1bm8vdm9jYWwtcmVtb3ZhbC9zdGF0dXMvJHt0YXNrSWR9YFxuICAgIDogYGh0dHBzOi8vYXBpYm94LmVyd2VpbWEuYWkvYXBpL3YxL3N1bm8vc3RlbS1zZXBhcmF0aW9uL3N0YXR1cy8ke3Rhc2tJZH1gO1xuXG4gIGZvciAobGV0IGF0dGVtcHQgPSAwOyBhdHRlbXB0IDwgbWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xuICAgIGNvbnNvbGUubG9nKGBQb2xsaW5nIGF0dGVtcHQgJHthdHRlbXB0ICsgMX0vJHttYXhBdHRlbXB0c31gKTtcbiAgICBcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGVuZHBvaW50LCB7XG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7YXBpS2V5fWAsXG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgfSxcbiAgICB9KTtcblxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJQb2xsIGVycm9yOlwiLCByZXNwb25zZS5zdGF0dXMpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBQb2xsIGVycm9yOiAke3Jlc3BvbnNlLnN0YXR1c31gKTtcbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJQb2xsIHJlc3VsdDpcIiwgcmVzdWx0KTtcblxuICAgIGlmIChyZXN1bHQuZGF0YT8uc3RhdHVzID09PSBcImNvbXBsZXRlZFwiIHx8IHJlc3VsdC5zdGF0dXMgPT09IFwiY29tcGxldGVkXCIpIHtcbiAgICAgIC8vIFJldHVybiB0aGUgVVJMc1xuICAgICAgcmV0dXJuIHJlc3VsdC5kYXRhPy51cmxzIHx8IHJlc3VsdC51cmxzIHx8IHt9O1xuICAgIH1cblxuICAgIGlmIChyZXN1bHQuZGF0YT8uc3RhdHVzID09PSBcImZhaWxlZFwiIHx8IHJlc3VsdC5zdGF0dXMgPT09IFwiZmFpbGVkXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihyZXN1bHQuZGF0YT8uZXJyb3IgfHwgcmVzdWx0LmVycm9yIHx8IFwiUHJvY2Vzc2luZyBmYWlsZWRcIik7XG4gICAgfVxuXG4gICAgLy8gV2FpdCBiZWZvcmUgbmV4dCBwb2xsXG4gICAgYXdhaXQgbmV3IFByb21pc2UocmVzb2x2ZSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIGludGVydmFsTXMpKTtcbiAgfVxuXG4gIHRocm93IG5ldyBFcnJvcihcIlRpbWVvdXQgd2FpdGluZyBmb3Igc2VwYXJhdGlvbiB0byBjb21wbGV0ZVwiKTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YseUVBQXlFO0lBQ3pFLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVk7TUFDZixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFFckMsK0VBQStFO0lBQy9FLE1BQU0sZ0JBQWdCLGVBQWUsQ0FBQyxPQUFPLEVBQUUsbUJBQW1CLENBQUM7SUFFbkUsSUFBSSxDQUFDLGVBQWU7TUFDbEIscUJBQXFCO01BQ3JCLE1BQU0sYUFBYSxhQUFhLGFBQWEsaUJBQWlCO1FBQzVELFFBQVE7VUFBRSxTQUFTO1lBQUUsZUFBZTtVQUFXO1FBQUU7TUFDbkQ7TUFDQSxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxXQUFXLElBQUksQ0FBQyxPQUFPO01BQzFFLElBQUksYUFBYSxDQUFDLE1BQU07UUFDdEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQWUsSUFDdkM7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO0lBQ0Y7SUFFQSxNQUFNLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUMxRCxRQUFRLEdBQUcsQ0FBQyw2QkFBNkI7TUFBRTtNQUFlO01BQU07SUFBVztJQUUzRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLFlBQVk7TUFDMUMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTBCLElBQ2xEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0MsOEJBQThCO0lBQzlCLE1BQU0sU0FDSCxJQUFJLENBQUMscUJBQ0wsTUFBTSxDQUFDO01BQUUsUUFBUTtJQUFhLEdBQzlCLEVBQUUsQ0FBQyxNQUFNO0lBRVosUUFBUSxHQUFHLENBQUM7SUFFWixtREFBbUQ7SUFDbkQsZ0VBQWdFO0lBQ2hFLENBQUM7TUFDQyxNQUFNLHVCQUF1QixVQUFVLGVBQWUsTUFBTTtJQUM5RCxDQUFDO0lBRUQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU0sU0FBUztJQUFxQixJQUM5RDtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUV0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLDJCQUEyQjtJQUN6QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU8saUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFBZ0IsSUFDakY7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0Y7QUFFQSxlQUFlLHVCQUNiLFFBQWEsRUFDYixZQUFvQixFQUNwQixJQUF1QixFQUN2QixTQUFpQjtFQUVqQixJQUFJO0lBQ0YsUUFBUSxHQUFHLENBQUMseUNBQXlDO01BQUU7TUFBYztJQUFLO0lBRTFFLDRDQUE0QztJQUM1QyxNQUFNLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBRWxDLElBQUksQ0FBQyxjQUFjO01BQ2pCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEseUNBQXlDO0lBQ3pDLDBFQUEwRTtJQUMxRSxvRkFBb0Y7SUFFcEYsSUFBSSxXQUFXO0lBQ2YsSUFBSSxjQUFtQixDQUFDO0lBRXhCLElBQUksU0FBUyxTQUFTO01BQ3BCLHdEQUF3RDtNQUN4RCxXQUFXO01BQ1gsY0FBYztRQUNaLFdBQVc7TUFDYjtJQUNGLE9BQU87TUFDTCx5REFBeUQ7TUFDekQsV0FBVztNQUNYLGNBQWM7UUFDWixXQUFXO1FBQ1gsT0FBTztVQUFDO1VBQVM7VUFBUTtVQUFVO1VBQVM7U0FBUTtNQUN0RDtJQUNGO0lBRUEsUUFBUSxHQUFHLENBQUMsMkJBQTJCO0lBRXZDLE1BQU0sV0FBVyxNQUFNLE1BQU0sVUFBVTtNQUNyQyxRQUFRO01BQ1IsU0FBUztRQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7UUFDekMsZ0JBQWdCO01BQ2xCO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztJQUN2QjtJQUVBLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRTtNQUNoQixNQUFNLFlBQVksTUFBTSxTQUFTLElBQUk7TUFDckMsUUFBUSxLQUFLLENBQUMseUJBQXlCLFNBQVMsTUFBTSxFQUFFO01BQ3hELE1BQU0sSUFBSSxNQUFNLENBQUMsV0FBVyxFQUFFLFNBQVMsTUFBTSxDQUFDLENBQUM7SUFDakQ7SUFFQSxNQUFNLFNBQVMsTUFBTSxTQUFTLElBQUk7SUFDbEMsUUFBUSxHQUFHLENBQUMsNEJBQTRCO0lBRXhDLHdDQUF3QztJQUN4QyxJQUFJLE9BQU8sSUFBSSxFQUFFLFNBQVM7TUFDeEIsc0JBQXNCO01BQ3RCLE1BQU0sa0JBQWtCLE1BQU0sa0JBQWtCLGNBQWMsT0FBTyxJQUFJLENBQUMsT0FBTyxFQUFFO01BRW5GLDRDQUE0QztNQUM1QyxNQUFNLFNBQ0gsSUFBSSxDQUFDLHFCQUNMLE1BQU0sQ0FBQztRQUNOLFFBQVE7UUFDUixhQUFhO01BQ2YsR0FDQyxFQUFFLENBQUMsTUFBTTtNQUVaLFFBQVEsR0FBRyxDQUFDO0lBQ2QsT0FBTyxJQUFJLE9BQU8sSUFBSSxFQUFFLFFBQVEsT0FBTyxJQUFJLEVBQUU7TUFDM0MsZ0JBQWdCO01BQ2hCLE1BQU0sT0FBTyxPQUFPLElBQUksRUFBRSxRQUFRLE9BQU8sSUFBSTtNQUU3QyxNQUFNLFNBQ0gsSUFBSSxDQUFDLHFCQUNMLE1BQU0sQ0FBQztRQUNOLFFBQVE7UUFDUixhQUFhO01BQ2YsR0FDQyxFQUFFLENBQUMsTUFBTTtNQUVaLFFBQVEsR0FBRyxDQUFDO0lBQ2QsT0FBTztNQUNMLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0VBQ0YsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyxxQkFBcUI7SUFFbkMsMEJBQTBCO0lBQzFCLE1BQU0sU0FDSCxJQUFJLENBQUMscUJBQ0wsTUFBTSxDQUFDO01BQ04sUUFBUTtNQUNSLGVBQWUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDMUQsR0FDQyxFQUFFLENBQUMsTUFBTTtFQUNkO0FBQ0Y7QUFFQSxlQUFlLGtCQUNiLE1BQWMsRUFDZCxNQUFjLEVBQ2QsSUFBdUIsRUFDdkIsY0FBYyxFQUFFLEVBQ2hCLGFBQWEsSUFBSTtFQUVqQixNQUFNLFdBQVcsU0FBUyxVQUN0QixDQUFDLDJEQUEyRCxFQUFFLE9BQU8sQ0FBQyxHQUN0RSxDQUFDLDZEQUE2RCxFQUFFLE9BQU8sQ0FBQztFQUU1RSxJQUFLLElBQUksVUFBVSxHQUFHLFVBQVUsYUFBYSxVQUFXO0lBQ3RELFFBQVEsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLENBQUMsRUFBRSxZQUFZLENBQUM7SUFFM0QsTUFBTSxXQUFXLE1BQU0sTUFBTSxVQUFVO01BQ3JDLFNBQVM7UUFDUCxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO1FBQ25DLGdCQUFnQjtNQUNsQjtJQUNGO0lBRUEsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLFFBQVEsS0FBSyxDQUFDLGVBQWUsU0FBUyxNQUFNO01BQzVDLE1BQU0sSUFBSSxNQUFNLENBQUMsWUFBWSxFQUFFLFNBQVMsTUFBTSxDQUFDLENBQUM7SUFDbEQ7SUFFQSxNQUFNLFNBQVMsTUFBTSxTQUFTLElBQUk7SUFDbEMsUUFBUSxHQUFHLENBQUMsZ0JBQWdCO0lBRTVCLElBQUksT0FBTyxJQUFJLEVBQUUsV0FBVyxlQUFlLE9BQU8sTUFBTSxLQUFLLGFBQWE7TUFDeEUsa0JBQWtCO01BQ2xCLE9BQU8sT0FBTyxJQUFJLEVBQUUsUUFBUSxPQUFPLElBQUksSUFBSSxDQUFDO0lBQzlDO0lBRUEsSUFBSSxPQUFPLElBQUksRUFBRSxXQUFXLFlBQVksT0FBTyxNQUFNLEtBQUssVUFBVTtNQUNsRSxNQUFNLElBQUksTUFBTSxPQUFPLElBQUksRUFBRSxTQUFTLE9BQU8sS0FBSyxJQUFJO0lBQ3hEO0lBRUEsd0JBQXdCO0lBQ3hCLE1BQU0sSUFBSSxRQUFRLENBQUEsVUFBVyxXQUFXLFNBQVM7RUFDbkQ7RUFFQSxNQUFNLElBQUksTUFBTTtBQUNsQiJ9
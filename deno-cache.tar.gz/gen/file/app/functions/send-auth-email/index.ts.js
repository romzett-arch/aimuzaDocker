import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import nodemailer from "npm:nodemailer@6.9.10";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const APP_NAME = "AI Planet Sound";
const APP_URL = "https://aiplanetsound.lovable.app";
function generateCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no O/0/1/I confusion
  let code = "";
  for(let i = 0; i < 6; i++){
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}
function getEmailHtml(type, data) {
  const baseStyle = `
    font-family: 'Segoe UI', Arial, sans-serif;
    max-width: 600px;
    margin: 0 auto;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    border-radius: 16px;
    overflow: hidden;
    color: #e0e0e0;
  `;
  const buttonStyle = `
    display: inline-block;
    padding: 14px 32px;
    background: linear-gradient(135deg, #8b5cf6, #6366f1);
    color: #ffffff;
    text-decoration: none;
    border-radius: 12px;
    font-weight: 600;
    font-size: 16px;
  `;
  const codeStyle = `
    display: inline-block;
    padding: 16px 32px;
    background: rgba(139, 92, 246, 0.2);
    border: 2px solid #8b5cf6;
    border-radius: 12px;
    font-size: 32px;
    font-weight: 700;
    letter-spacing: 8px;
    color: #a78bfa;
    font-family: monospace;
  `;
  const headerHtml = `
    <div style="padding: 32px 24px 16px; text-align: center;">
      <h1 style="color: #a78bfa; font-size: 24px; margin: 0;">🎵 ${APP_NAME}</h1>
    </div>
  `;
  const footerHtml = `
    <div style="padding: 16px 24px 24px; text-align: center; font-size: 12px; color: #666;">
      <p>Это автоматическое письмо от ${APP_NAME}.</p>
      <p>Если вы не совершали это действие, проигнорируйте это письмо.</p>
    </div>
  `;
  if (type === "confirm") {
    return {
      subject: `${data.code} — код подтверждения ${APP_NAME}`,
      html: `
        <div style="${baseStyle}">
          ${headerHtml}
          <div style="padding: 16px 24px 32px;">
            <h2 style="color: #e0e0e0; text-align: center;">Подтвердите регистрацию ✉️</h2>
            <p style="text-align: center; line-height: 1.6;">
              Привет, ${data.username || "музыкант"}! Введите код ниже на странице регистрации:
            </p>
            <div style="text-align: center; margin: 24px 0;">
              <span style="${codeStyle}">${data.code}</span>
            </div>
            <p style="text-align: center; font-size: 13px; color: #999;">
              Код действителен 15 минут. Если вы не регистрировались — проигнорируйте это письмо.
            </p>
          </div>
          ${footerHtml}
        </div>
      `
    };
  }
  if (type === "welcome") {
    return {
      subject: `Добро пожаловать в ${APP_NAME}! 🎵`,
      html: `
        <div style="${baseStyle}">
          ${headerHtml}
          <div style="padding: 16px 24px 32px;">
            <h2 style="color: #e0e0e0; text-align: center;">Привет, ${data.username || "музыкант"}! 👋</h2>
            <p style="text-align: center; line-height: 1.6;">
              Добро пожаловать на платформу AI Planet Sound — хаб AI музыкантов!
            </p>
            <div style="text-align: center; margin: 24px 0;">
              <a href="${APP_URL}" style="${buttonStyle}">Начать создавать 🚀</a>
            </div>
            <p style="text-align: center; font-size: 14px; color: #999;">
              Ваш аккаунт: <strong>${data.email}</strong>
            </p>
          </div>
          ${footerHtml}
        </div>
      `
    };
  }
  // reset
  return {
    subject: `Сброс пароля — ${APP_NAME}`,
    html: `
      <div style="${baseStyle}">
        ${headerHtml}
        <div style="padding: 16px 24px 32px;">
          <h2 style="color: #e0e0e0; text-align: center;">Сброс пароля 🔑</h2>
          <p style="text-align: center; line-height: 1.6;">
            Вы запросили сброс пароля для аккаунта <strong>${data.email}</strong>.
          </p>
          <div style="text-align: center; margin: 24px 0;">
            <a href="${data.link}" style="${buttonStyle}">Сбросить пароль</a>
          </div>
          <p style="text-align: center; font-size: 13px; color: #999;">
            Ссылка действительна 1 час.
          </p>
        </div>
        ${footerHtml}
      </div>
    `
  };
}
async function sendEmail(to, subject, html) {
  const transporter = nodemailer.createTransport({
    host: Deno.env.get("SMTP_HOST"),
    port: parseInt(Deno.env.get("SMTP_PORT") || "465"),
    secure: true,
    auth: {
      user: Deno.env.get("SMTP_USER"),
      pass: Deno.env.get("SMTP_PASS")
    }
  });
  await transporter.sendMail({
    from: `"${APP_NAME}" <${Deno.env.get("SMTP_USER")}>`,
    to,
    subject,
    html
  });
}
Deno.serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const { email, type, username } = await req.json();
    if (!email || !type) {
      return new Response(JSON.stringify({
        error: "email and type are required"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const adminClient = createClient(supabaseUrl, serviceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });
    let link;
    let code;
    if (type === "confirm") {
      // Generate 6-char code and store in DB
      code = generateCode();
      // Clean up old codes for this email
      await adminClient.from("email_verifications").delete().eq("email", email);
      // Insert new code
      const { error: insertError } = await adminClient.from("email_verifications").insert({
        email,
        code,
        username: username || null
      });
      if (insertError) {
        console.error("Insert verification code error:", insertError);
        return new Response(JSON.stringify({
          error: "Failed to create verification code"
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
    }
    if (type === "reset") {
      const { data, error } = await adminClient.auth.admin.generateLink({
        type: "recovery",
        email,
        options: {
          redirectTo: `${APP_URL}/auth?mode=reset`
        }
      });
      if (error) {
        console.error("Generate reset link error:", error);
        return new Response(JSON.stringify({
          error: "Failed to generate reset link"
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      link = data.properties?.action_link;
    }
    const template = getEmailHtml(type, {
      username,
      link,
      email,
      code
    });
    await sendEmail(email, template.subject, template.html);
    console.log(`[send-auth-email] Sent ${type} email to ${email}`);
    return new Response(JSON.stringify({
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("[send-auth-email] Error:", error);
    const message = error instanceof Error ? error.message : "Internal server error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9zZW5kLWF1dGgtZW1haWwvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDIuNDkuMVwiO1xuaW1wb3J0IG5vZGVtYWlsZXIgZnJvbSBcIm5wbTpub2RlbWFpbGVyQDYuOS4xMFwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOlxuICAgIFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmNvbnN0IEFQUF9OQU1FID0gXCJBSSBQbGFuZXQgU291bmRcIjtcbmNvbnN0IEFQUF9VUkwgPSBcImh0dHBzOi8vYWlwbGFuZXRzb3VuZC5sb3ZhYmxlLmFwcFwiO1xuXG5mdW5jdGlvbiBnZW5lcmF0ZUNvZGUoKTogc3RyaW5nIHtcbiAgY29uc3QgY2hhcnMgPSBcIkFCQ0RFRkdISktMTU5QUVJTVFVWV1hZWjIzNDU2Nzg5XCI7IC8vIG5vIE8vMC8xL0kgY29uZnVzaW9uXG4gIGxldCBjb2RlID0gXCJcIjtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCA2OyBpKyspIHtcbiAgICBjb2RlICs9IGNoYXJzW01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGNoYXJzLmxlbmd0aCldO1xuICB9XG4gIHJldHVybiBjb2RlO1xufVxuXG5mdW5jdGlvbiBnZXRFbWFpbEh0bWwodHlwZTogc3RyaW5nLCBkYXRhOiB7IGNvZGU/OiBzdHJpbmc7IGxpbms/OiBzdHJpbmc7IGVtYWlsOiBzdHJpbmc7IHVzZXJuYW1lPzogc3RyaW5nIH0pIHtcbiAgY29uc3QgYmFzZVN0eWxlID0gYFxuICAgIGZvbnQtZmFtaWx5OiAnU2Vnb2UgVUknLCBBcmlhbCwgc2Fucy1zZXJpZjtcbiAgICBtYXgtd2lkdGg6IDYwMHB4O1xuICAgIG1hcmdpbjogMCBhdXRvO1xuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICMxYTFhMmUgMCUsICMxNjIxM2UgNTAlLCAjMGYzNDYwIDEwMCUpO1xuICAgIGJvcmRlci1yYWRpdXM6IDE2cHg7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICBjb2xvcjogI2UwZTBlMDtcbiAgYDtcbiAgY29uc3QgYnV0dG9uU3R5bGUgPSBgXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIHBhZGRpbmc6IDE0cHggMzJweDtcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjOGI1Y2Y2LCAjNjM2NmYxKTtcbiAgICBjb2xvcjogI2ZmZmZmZjtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gICAgYm9yZGVyLXJhZGl1czogMTJweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgYDtcbiAgY29uc3QgY29kZVN0eWxlID0gYFxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICBwYWRkaW5nOiAxNnB4IDMycHg7XG4gICAgYmFja2dyb3VuZDogcmdiYSgxMzksIDkyLCAyNDYsIDAuMik7XG4gICAgYm9yZGVyOiAycHggc29saWQgIzhiNWNmNjtcbiAgICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICAgIGZvbnQtc2l6ZTogMzJweDtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICAgIGxldHRlci1zcGFjaW5nOiA4cHg7XG4gICAgY29sb3I6ICNhNzhiZmE7XG4gICAgZm9udC1mYW1pbHk6IG1vbm9zcGFjZTtcbiAgYDtcbiAgY29uc3QgaGVhZGVySHRtbCA9IGBcbiAgICA8ZGl2IHN0eWxlPVwicGFkZGluZzogMzJweCAyNHB4IDE2cHg7IHRleHQtYWxpZ246IGNlbnRlcjtcIj5cbiAgICAgIDxoMSBzdHlsZT1cImNvbG9yOiAjYTc4YmZhOyBmb250LXNpemU6IDI0cHg7IG1hcmdpbjogMDtcIj7wn461ICR7QVBQX05BTUV9PC9oMT5cbiAgICA8L2Rpdj5cbiAgYDtcbiAgY29uc3QgZm9vdGVySHRtbCA9IGBcbiAgICA8ZGl2IHN0eWxlPVwicGFkZGluZzogMTZweCAyNHB4IDI0cHg7IHRleHQtYWxpZ246IGNlbnRlcjsgZm9udC1zaXplOiAxMnB4OyBjb2xvcjogIzY2NjtcIj5cbiAgICAgIDxwPtCt0YLQviDQsNCy0YLQvtC80LDRgtC40YfQtdGB0LrQvtC1INC/0LjRgdGM0LzQviDQvtGCICR7QVBQX05BTUV9LjwvcD5cbiAgICAgIDxwPtCV0YHQu9C4INCy0Ysg0L3QtSDRgdC+0LLQtdGA0YjQsNC70Lgg0Y3RgtC+INC00LXQudGB0YLQstC40LUsINC/0YDQvtC40LPQvdC+0YDQuNGA0YPQudGC0LUg0Y3RgtC+INC/0LjRgdGM0LzQvi48L3A+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgaWYgKHR5cGUgPT09IFwiY29uZmlybVwiKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHN1YmplY3Q6IGAke2RhdGEuY29kZX0g4oCUINC60L7QtCDQv9C+0LTRgtCy0LXRgNC20LTQtdC90LjRjyAke0FQUF9OQU1FfWAsXG4gICAgICBodG1sOiBgXG4gICAgICAgIDxkaXYgc3R5bGU9XCIke2Jhc2VTdHlsZX1cIj5cbiAgICAgICAgICAke2hlYWRlckh0bWx9XG4gICAgICAgICAgPGRpdiBzdHlsZT1cInBhZGRpbmc6IDE2cHggMjRweCAzMnB4O1wiPlxuICAgICAgICAgICAgPGgyIHN0eWxlPVwiY29sb3I6ICNlMGUwZTA7IHRleHQtYWxpZ246IGNlbnRlcjtcIj7Qn9C+0LTRgtCy0LXRgNC00LjRgtC1INGA0LXQs9C40YHRgtGA0LDRhtC40Y4g4pyJ77iPPC9oMj5cbiAgICAgICAgICAgIDxwIHN0eWxlPVwidGV4dC1hbGlnbjogY2VudGVyOyBsaW5lLWhlaWdodDogMS42O1wiPlxuICAgICAgICAgICAgICDQn9GA0LjQstC10YIsICR7ZGF0YS51c2VybmFtZSB8fCBcItC80YPQt9GL0LrQsNC90YJcIn0hINCS0LLQtdC00LjRgtC1INC60L7QtCDQvdC40LbQtSDQvdCwINGB0YLRgNCw0L3QuNGG0LUg0YDQtdCz0LjRgdGC0YDQsNGG0LjQuDpcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJ0ZXh0LWFsaWduOiBjZW50ZXI7IG1hcmdpbjogMjRweCAwO1wiPlxuICAgICAgICAgICAgICA8c3BhbiBzdHlsZT1cIiR7Y29kZVN0eWxlfVwiPiR7ZGF0YS5jb2RlfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHAgc3R5bGU9XCJ0ZXh0LWFsaWduOiBjZW50ZXI7IGZvbnQtc2l6ZTogMTNweDsgY29sb3I6ICM5OTk7XCI+XG4gICAgICAgICAgICAgINCa0L7QtCDQtNC10LnRgdGC0LLQuNGC0LXQu9C10L0gMTUg0LzQuNC90YPRgi4g0JXRgdC70Lgg0LLRiyDQvdC1INGA0LXQs9C40YHRgtGA0LjRgNC+0LLQsNC70LjRgdGMIOKAlCDQv9GA0L7QuNCz0L3QvtGA0LjRgNGD0LnRgtC1INGN0YLQviDQv9C40YHRjNC80L4uXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgJHtmb290ZXJIdG1sfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIGAsXG4gICAgfTtcbiAgfVxuXG4gIGlmICh0eXBlID09PSBcIndlbGNvbWVcIikge1xuICAgIHJldHVybiB7XG4gICAgICBzdWJqZWN0OiBg0JTQvtCx0YDQviDQv9C+0LbQsNC70L7QstCw0YLRjCDQsiAke0FQUF9OQU1FfSEg8J+OtWAsXG4gICAgICBodG1sOiBgXG4gICAgICAgIDxkaXYgc3R5bGU9XCIke2Jhc2VTdHlsZX1cIj5cbiAgICAgICAgICAke2hlYWRlckh0bWx9XG4gICAgICAgICAgPGRpdiBzdHlsZT1cInBhZGRpbmc6IDE2cHggMjRweCAzMnB4O1wiPlxuICAgICAgICAgICAgPGgyIHN0eWxlPVwiY29sb3I6ICNlMGUwZTA7IHRleHQtYWxpZ246IGNlbnRlcjtcIj7Qn9GA0LjQstC10YIsICR7ZGF0YS51c2VybmFtZSB8fCBcItC80YPQt9GL0LrQsNC90YJcIn0hIPCfkYs8L2gyPlxuICAgICAgICAgICAgPHAgc3R5bGU9XCJ0ZXh0LWFsaWduOiBjZW50ZXI7IGxpbmUtaGVpZ2h0OiAxLjY7XCI+XG4gICAgICAgICAgICAgINCU0L7QsdGA0L4g0L/QvtC20LDQu9C+0LLQsNGC0Ywg0L3QsCDQv9C70LDRgtGE0L7RgNC80YMgQUkgUGxhbmV0IFNvdW5kIOKAlCDRhdCw0LEgQUkg0LzRg9C30YvQutCw0L3RgtC+0LIhXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPVwidGV4dC1hbGlnbjogY2VudGVyOyBtYXJnaW46IDI0cHggMDtcIj5cbiAgICAgICAgICAgICAgPGEgaHJlZj1cIiR7QVBQX1VSTH1cIiBzdHlsZT1cIiR7YnV0dG9uU3R5bGV9XCI+0J3QsNGH0LDRgtGMINGB0L7Qt9C00LDQstCw0YLRjCDwn5qAPC9hPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCBzdHlsZT1cInRleHQtYWxpZ246IGNlbnRlcjsgZm9udC1zaXplOiAxNHB4OyBjb2xvcjogIzk5OTtcIj5cbiAgICAgICAgICAgICAg0JLQsNGIINCw0LrQutCw0YPQvdGCOiA8c3Ryb25nPiR7ZGF0YS5lbWFpbH08L3N0cm9uZz5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAke2Zvb3Rlckh0bWx9XG4gICAgICAgIDwvZGl2PlxuICAgICAgYCxcbiAgICB9O1xuICB9XG5cbiAgLy8gcmVzZXRcbiAgcmV0dXJuIHtcbiAgICBzdWJqZWN0OiBg0KHQsdGA0L7RgSDQv9Cw0YDQvtC70Y8g4oCUICR7QVBQX05BTUV9YCxcbiAgICBodG1sOiBgXG4gICAgICA8ZGl2IHN0eWxlPVwiJHtiYXNlU3R5bGV9XCI+XG4gICAgICAgICR7aGVhZGVySHRtbH1cbiAgICAgICAgPGRpdiBzdHlsZT1cInBhZGRpbmc6IDE2cHggMjRweCAzMnB4O1wiPlxuICAgICAgICAgIDxoMiBzdHlsZT1cImNvbG9yOiAjZTBlMGUwOyB0ZXh0LWFsaWduOiBjZW50ZXI7XCI+0KHQsdGA0L7RgSDQv9Cw0YDQvtC70Y8g8J+UkTwvaDI+XG4gICAgICAgICAgPHAgc3R5bGU9XCJ0ZXh0LWFsaWduOiBjZW50ZXI7IGxpbmUtaGVpZ2h0OiAxLjY7XCI+XG4gICAgICAgICAgICDQktGLINC30LDQv9GA0L7RgdC40LvQuCDRgdCx0YDQvtGBINC/0LDRgNC+0LvRjyDQtNC70Y8g0LDQutC60LDRg9C90YLQsCA8c3Ryb25nPiR7ZGF0YS5lbWFpbH08L3N0cm9uZz4uXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxkaXYgc3R5bGU9XCJ0ZXh0LWFsaWduOiBjZW50ZXI7IG1hcmdpbjogMjRweCAwO1wiPlxuICAgICAgICAgICAgPGEgaHJlZj1cIiR7ZGF0YS5saW5rfVwiIHN0eWxlPVwiJHtidXR0b25TdHlsZX1cIj7QodCx0YDQvtGB0LjRgtGMINC/0LDRgNC+0LvRjDwvYT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBzdHlsZT1cInRleHQtYWxpZ246IGNlbnRlcjsgZm9udC1zaXplOiAxM3B4OyBjb2xvcjogIzk5OTtcIj5cbiAgICAgICAgICAgINCh0YHRi9C70LrQsCDQtNC10LnRgdGC0LLQuNGC0LXQu9GM0L3QsCAxINGH0LDRgS5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICAke2Zvb3Rlckh0bWx9XG4gICAgICA8L2Rpdj5cbiAgICBgLFxuICB9O1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZW5kRW1haWwodG86IHN0cmluZywgc3ViamVjdDogc3RyaW5nLCBodG1sOiBzdHJpbmcpIHtcbiAgY29uc3QgdHJhbnNwb3J0ZXIgPSBub2RlbWFpbGVyLmNyZWF0ZVRyYW5zcG9ydCh7XG4gICAgaG9zdDogRGVuby5lbnYuZ2V0KFwiU01UUF9IT1NUXCIpLFxuICAgIHBvcnQ6IHBhcnNlSW50KERlbm8uZW52LmdldChcIlNNVFBfUE9SVFwiKSB8fCBcIjQ2NVwiKSxcbiAgICBzZWN1cmU6IHRydWUsXG4gICAgYXV0aDoge1xuICAgICAgdXNlcjogRGVuby5lbnYuZ2V0KFwiU01UUF9VU0VSXCIpLFxuICAgICAgcGFzczogRGVuby5lbnYuZ2V0KFwiU01UUF9QQVNTXCIpLFxuICAgIH0sXG4gIH0pO1xuICBhd2FpdCB0cmFuc3BvcnRlci5zZW5kTWFpbCh7XG4gICAgZnJvbTogYFwiJHtBUFBfTkFNRX1cIiA8JHtEZW5vLmVudi5nZXQoXCJTTVRQX1VTRVJcIil9PmAsXG4gICAgdG8sXG4gICAgc3ViamVjdCxcbiAgICBodG1sLFxuICB9KTtcbn1cblxuRGVuby5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgeyBlbWFpbCwgdHlwZSwgdXNlcm5hbWUgfSA9IGF3YWl0IHJlcS5qc29uKCk7XG5cbiAgICBpZiAoIWVtYWlsIHx8ICF0eXBlKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcImVtYWlsIGFuZCB0eXBlIGFyZSByZXF1aXJlZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IHNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBjb25zdCBhZG1pbkNsaWVudCA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc2VydmljZUtleSwge1xuICAgICAgYXV0aDogeyBhdXRvUmVmcmVzaFRva2VuOiBmYWxzZSwgcGVyc2lzdFNlc3Npb246IGZhbHNlIH0sXG4gICAgfSk7XG5cbiAgICBsZXQgbGluazogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICAgIGxldCBjb2RlOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG5cbiAgICBpZiAodHlwZSA9PT0gXCJjb25maXJtXCIpIHtcbiAgICAgIC8vIEdlbmVyYXRlIDYtY2hhciBjb2RlIGFuZCBzdG9yZSBpbiBEQlxuICAgICAgY29kZSA9IGdlbmVyYXRlQ29kZSgpO1xuICAgICAgXG4gICAgICAvLyBDbGVhbiB1cCBvbGQgY29kZXMgZm9yIHRoaXMgZW1haWxcbiAgICAgIGF3YWl0IGFkbWluQ2xpZW50LmZyb20oXCJlbWFpbF92ZXJpZmljYXRpb25zXCIpLmRlbGV0ZSgpLmVxKFwiZW1haWxcIiwgZW1haWwpO1xuICAgICAgXG4gICAgICAvLyBJbnNlcnQgbmV3IGNvZGVcbiAgICAgIGNvbnN0IHsgZXJyb3I6IGluc2VydEVycm9yIH0gPSBhd2FpdCBhZG1pbkNsaWVudC5mcm9tKFwiZW1haWxfdmVyaWZpY2F0aW9uc1wiKS5pbnNlcnQoe1xuICAgICAgICBlbWFpbCxcbiAgICAgICAgY29kZSxcbiAgICAgICAgdXNlcm5hbWU6IHVzZXJuYW1lIHx8IG51bGwsXG4gICAgICB9KTtcbiAgICAgIFxuICAgICAgaWYgKGluc2VydEVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJJbnNlcnQgdmVyaWZpY2F0aW9uIGNvZGUgZXJyb3I6XCIsIGluc2VydEVycm9yKTtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkZhaWxlZCB0byBjcmVhdGUgdmVyaWZpY2F0aW9uIGNvZGVcIiB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAodHlwZSA9PT0gXCJyZXNldFwiKSB7XG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBhZG1pbkNsaWVudC5hdXRoLmFkbWluLmdlbmVyYXRlTGluayh7XG4gICAgICAgIHR5cGU6IFwicmVjb3ZlcnlcIixcbiAgICAgICAgZW1haWwsXG4gICAgICAgIG9wdGlvbnM6IHsgcmVkaXJlY3RUbzogYCR7QVBQX1VSTH0vYXV0aD9tb2RlPXJlc2V0YCB9LFxuICAgICAgfSk7XG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkdlbmVyYXRlIHJlc2V0IGxpbmsgZXJyb3I6XCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkZhaWxlZCB0byBnZW5lcmF0ZSByZXNldCBsaW5rXCIgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBsaW5rID0gZGF0YS5wcm9wZXJ0aWVzPy5hY3Rpb25fbGluaztcbiAgICB9XG5cbiAgICBjb25zdCB0ZW1wbGF0ZSA9IGdldEVtYWlsSHRtbCh0eXBlLCB7IHVzZXJuYW1lLCBsaW5rLCBlbWFpbCwgY29kZSB9KTtcbiAgICBhd2FpdCBzZW5kRW1haWwoZW1haWwsIHRlbXBsYXRlLnN1YmplY3QsIHRlbXBsYXRlLmh0bWwpO1xuXG4gICAgY29uc29sZS5sb2coYFtzZW5kLWF1dGgtZW1haWxdIFNlbnQgJHt0eXBlfSBlbWFpbCB0byAke2VtYWlsfWApO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICBjb25zb2xlLmVycm9yKFwiW3NlbmQtYXV0aC1lbWFpbF0gRXJyb3I6XCIsIGVycm9yKTtcbiAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIkludGVybmFsIHNlcnZlciBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBtZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxZQUFZLFFBQVEsOENBQThDO0FBQzNFLE9BQU8sZ0JBQWdCLHdCQUF3QjtBQUUvQyxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUNFO0FBQ0o7QUFFQSxNQUFNLFdBQVc7QUFDakIsTUFBTSxVQUFVO0FBRWhCLFNBQVM7RUFDUCxNQUFNLFFBQVEsb0NBQW9DLHVCQUF1QjtFQUN6RSxJQUFJLE9BQU87RUFDWCxJQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxJQUFLO0lBQzFCLFFBQVEsS0FBSyxDQUFDLEtBQUssS0FBSyxDQUFDLEtBQUssTUFBTSxLQUFLLE1BQU0sTUFBTSxFQUFFO0VBQ3pEO0VBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLElBQVksRUFBRSxJQUF3RTtFQUMxRyxNQUFNLFlBQVksQ0FBQzs7Ozs7Ozs7RUFRbkIsQ0FBQztFQUNELE1BQU0sY0FBYyxDQUFDOzs7Ozs7Ozs7RUFTckIsQ0FBQztFQUNELE1BQU0sWUFBWSxDQUFDOzs7Ozs7Ozs7OztFQVduQixDQUFDO0VBQ0QsTUFBTSxhQUFhLENBQUM7O2lFQUUyQyxFQUFFLFNBQVM7O0VBRTFFLENBQUM7RUFDRCxNQUFNLGFBQWEsQ0FBQzs7c0NBRWdCLEVBQUUsU0FBUzs7O0VBRy9DLENBQUM7RUFFRCxJQUFJLFNBQVMsV0FBVztJQUN0QixPQUFPO01BQ0wsU0FBUyxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMscUJBQXFCLEVBQUUsU0FBUyxDQUFDO01BQ3ZELE1BQU0sQ0FBQztvQkFDTyxFQUFFLFVBQVU7VUFDdEIsRUFBRSxXQUFXOzs7O3NCQUlELEVBQUUsS0FBSyxRQUFRLElBQUksV0FBVzs7OzJCQUd6QixFQUFFLFVBQVUsRUFBRSxFQUFFLEtBQUssSUFBSSxDQUFDOzs7Ozs7VUFNM0MsRUFBRSxXQUFXOztNQUVqQixDQUFDO0lBQ0g7RUFDRjtFQUVBLElBQUksU0FBUyxXQUFXO0lBQ3RCLE9BQU87TUFDTCxTQUFTLENBQUMsbUJBQW1CLEVBQUUsU0FBUyxJQUFJLENBQUM7TUFDN0MsTUFBTSxDQUFDO29CQUNPLEVBQUUsVUFBVTtVQUN0QixFQUFFLFdBQVc7O29FQUU2QyxFQUFFLEtBQUssUUFBUSxJQUFJLFdBQVc7Ozs7O3VCQUszRSxFQUFFLFFBQVEsU0FBUyxFQUFFLFlBQVk7OzttQ0FHckIsRUFBRSxLQUFLLEtBQUssQ0FBQzs7O1VBR3RDLEVBQUUsV0FBVzs7TUFFakIsQ0FBQztJQUNIO0VBQ0Y7RUFFQSxRQUFRO0VBQ1IsT0FBTztJQUNMLFNBQVMsQ0FBQyxlQUFlLEVBQUUsU0FBUyxDQUFDO0lBQ3JDLE1BQU0sQ0FBQztrQkFDTyxFQUFFLFVBQVU7UUFDdEIsRUFBRSxXQUFXOzs7OzJEQUlzQyxFQUFFLEtBQUssS0FBSyxDQUFDOzs7cUJBR25ELEVBQUUsS0FBSyxJQUFJLENBQUMsU0FBUyxFQUFFLFlBQVk7Ozs7OztRQU1oRCxFQUFFLFdBQVc7O0lBRWpCLENBQUM7RUFDSDtBQUNGO0FBRUEsZUFBZSxVQUFVLEVBQVUsRUFBRSxPQUFlLEVBQUUsSUFBWTtFQUNoRSxNQUFNLGNBQWMsV0FBVyxlQUFlLENBQUM7SUFDN0MsTUFBTSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbkIsTUFBTSxTQUFTLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0I7SUFDNUMsUUFBUTtJQUNSLE1BQU07TUFDSixNQUFNLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztNQUNuQixNQUFNLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNyQjtFQUNGO0VBQ0EsTUFBTSxZQUFZLFFBQVEsQ0FBQztJQUN6QixNQUFNLENBQUMsQ0FBQyxFQUFFLFNBQVMsR0FBRyxFQUFFLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNwRDtJQUNBO0lBQ0E7RUFDRjtBQUNGO0FBRUEsS0FBSyxLQUFLLENBQUMsT0FBTztFQUNoQixJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUVoRCxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU07TUFDbkIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQThCLElBQ3REO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDakMsTUFBTSxhQUFhLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNoQyxNQUFNLGNBQWMsYUFBYSxhQUFhLFlBQVk7TUFDeEQsTUFBTTtRQUFFLGtCQUFrQjtRQUFPLGdCQUFnQjtNQUFNO0lBQ3pEO0lBRUEsSUFBSTtJQUNKLElBQUk7SUFFSixJQUFJLFNBQVMsV0FBVztNQUN0Qix1Q0FBdUM7TUFDdkMsT0FBTztNQUVQLG9DQUFvQztNQUNwQyxNQUFNLFlBQVksSUFBSSxDQUFDLHVCQUF1QixNQUFNLEdBQUcsRUFBRSxDQUFDLFNBQVM7TUFFbkUsa0JBQWtCO01BQ2xCLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sWUFBWSxJQUFJLENBQUMsdUJBQXVCLE1BQU0sQ0FBQztRQUNsRjtRQUNBO1FBQ0EsVUFBVSxZQUFZO01BQ3hCO01BRUEsSUFBSSxhQUFhO1FBQ2YsUUFBUSxLQUFLLENBQUMsbUNBQW1DO1FBQ2pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUFxQyxJQUM3RDtVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7SUFDRjtJQUVBLElBQUksU0FBUyxTQUFTO01BQ3BCLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxZQUFZLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDO1FBQ2hFLE1BQU07UUFDTjtRQUNBLFNBQVM7VUFBRSxZQUFZLENBQUMsRUFBRSxRQUFRLGdCQUFnQixDQUFDO1FBQUM7TUFDdEQ7TUFDQSxJQUFJLE9BQU87UUFDVCxRQUFRLEtBQUssQ0FBQyw4QkFBOEI7UUFDNUMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQWdDLElBQ3hEO1VBQUUsUUFBUTtVQUFLLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUVuRjtNQUNBLE9BQU8sS0FBSyxVQUFVLEVBQUU7SUFDMUI7SUFFQSxNQUFNLFdBQVcsYUFBYSxNQUFNO01BQUU7TUFBVTtNQUFNO01BQU87SUFBSztJQUNsRSxNQUFNLFVBQVUsT0FBTyxTQUFTLE9BQU8sRUFBRSxTQUFTLElBQUk7SUFFdEQsUUFBUSxHQUFHLENBQUMsQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLFVBQVUsRUFBRSxNQUFNLENBQUM7SUFFOUQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO0lBQUssSUFDL0I7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEUsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDRCQUE0QjtJQUMxQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
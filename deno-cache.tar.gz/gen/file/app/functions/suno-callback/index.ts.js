import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
// Background task helper — fire-and-forget pattern
// (EdgeRuntime.waitUntil is NOT available in this Deno server)
function runInBackground(taskName, promise) {
  promise.catch((err)=>console.error(`[Background: ${taskName}] Error:`, err));
}
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Helper function to download file and upload to Supabase Storage
async function copyFileToStorage(supabaseAdmin, externalUrl, bucket, filePath) {
  try {
    console.log(`Downloading file from: ${externalUrl}`);
    const response = await fetch(externalUrl);
    if (!response.ok) {
      console.error(`Failed to download: ${response.status} ${response.statusText}`);
      return null;
    }
    const blob = await response.blob();
    const arrayBuffer = await blob.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);
    console.log(`Downloaded ${uint8Array.length} bytes, uploading to ${bucket}/${filePath}`);
    const { error: uploadError } = await supabaseAdmin.storage.from(bucket).upload(filePath, uint8Array, {
      contentType: blob.type || "application/octet-stream",
      upsert: true
    });
    if (uploadError) {
      console.error(`Upload error:`, uploadError);
      return null;
    }
    // Build public URL using BASE_URL (not internal SUPABASE_URL which is http://api:3000)
    const baseUrl = Deno.env.get("BASE_URL") || "https://aimuza.ru";
    const publicUrl = `${baseUrl}/storage/v1/object/public/${bucket}/${filePath}`;
    console.log(`File uploaded successfully: ${publicUrl}`);
    return publicUrl;
  } catch (err) {
    console.error(`Error copying file to storage:`, err);
    return null;
  }
}
// Timeweb Agent API configuration for AI classification
const TIMEWEB_AGENT_ACCESS_ID = '0846d064-4950-4d79-a54c-62ba315cdb34';
// AI Classification function - determines genre, vocal type, template, artist style
// Uses Timeweb Agent API (GPT-4)
async function classifyTrackWithAI(supabaseAdmin, trackId, style, lyrics) {
  try {
    console.log(`Starting AI classification for track ${trackId}`);
    const TIMEWEB_TOKEN = Deno.env.get("TIMEWEB_AGENT_TOKEN");
    if (!TIMEWEB_TOKEN) {
      console.error("TIMEWEB_AGENT_TOKEN not configured, skipping classification");
      return;
    }
    // Fetch all available options from database
    const [genresRes, vocalTypesRes, templatesRes, artistStylesRes] = await Promise.all([
      supabaseAdmin.from("genres").select("id, name, name_ru").order("sort_order"),
      supabaseAdmin.from("vocal_types").select("id, name, name_ru, description").eq("is_active", true).order("sort_order"),
      supabaseAdmin.from("templates").select("id, name, description").eq("is_active", true).order("sort_order"),
      supabaseAdmin.from("artist_styles").select("id, name, description").eq("is_active", true).order("sort_order")
    ]);
    const genres = genresRes.data || [];
    const vocalTypes = vocalTypesRes.data || [];
    const templates = templatesRes.data || [];
    const artistStyles = artistStylesRes.data || [];
    if (genres.length === 0) {
      console.log("No genres in database, skipping classification");
      return;
    }
    // Build the classification prompt
    const genresList = genres.map((g)=>`- id: "${g.id}", name: "${g.name}" (${g.name_ru})`).join("\n");
    const vocalTypesList = vocalTypes.map((v)=>`- id: "${v.id}", name: "${v.name}" (${v.name_ru})${v.description ? ` - ${v.description}` : ""}`).join("\n");
    const templatesList = templates.length > 0 ? templates.map((t)=>`- id: "${t.id}", name: "${t.name}"${t.description ? ` - ${t.description}` : ""}`).join("\n") : "Нет доступных шаблонов";
    const artistStylesList = artistStyles.length > 0 ? artistStyles.map((a)=>`- id: "${a.id}", name: "${a.name}"${a.description ? ` - ${a.description}` : ""}`).join("\n") : "Нет доступных стилей артистов";
    const prompt = `Ты — музыкальный классификатор. Проанализируй стиль и лирику трека.
Выбери ОДИН наиболее подходящий вариант из каждой категории.

ЖАНРЫ (обязательно выбери один):
${genresList}

ТИПЫ ВОКАЛА (обязательно выбери один):
${vocalTypesList}

ШАБЛОНЫ (опционально, выбери если подходит):
${templatesList}

СТИЛИ АРТИСТОВ (опционально, выбери если есть явное сходство):
${artistStylesList}

---
СТИЛЬ ТРЕКА: ${style || "Не указан"}
ЛИРИКА: ${lyrics ? lyrics.substring(0, 1000) : "Инструментал (без текста)"}
---

Правила:
1. genre_id - ОБЯЗАТЕЛЕН, выбери наиболее близкий жанр
2. vocal_type_id - ОБЯЗАТЕЛЕН. Если нет лирики, выбери "instrumental"
3. template_id - только если трек явно соответствует шаблону, иначе null
4. artist_style_id - только если стиль явно похож на конкретного артиста, иначе null

Верни ТОЛЬКО JSON без markdown:
{"genre_id": "...", "vocal_type_id": "...", "template_id": "..." или null, "artist_style_id": "..." или null}`;
    const apiUrl = `https://agent.timeweb.cloud/api/v1/cloud-ai/agents/${TIMEWEB_AGENT_ACCESS_ID}/v1/chat/completions`;
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${TIMEWEB_TOKEN}`,
        "Content-Type": "application/json",
        "x-proxy-source": "lovable-app"
      },
      body: JSON.stringify({
        model: "deepseek-v3",
        messages: [
          {
            role: "system",
            content: "Ты музыкальный классификатор. Отвечай только JSON."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.3
      })
    });
    if (!response.ok) {
      console.error(`AI classification failed: ${response.status}`);
      return;
    }
    const result = await response.json();
    const content = result.choices?.[0]?.message?.content;
    if (!content) {
      console.error("No content in AI response");
      return;
    }
    console.log(`AI classification response: ${content}`);
    // Parse JSON response (handle potential markdown wrapper)
    let classification;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        classification = JSON.parse(jsonMatch[0]);
      } else {
        classification = JSON.parse(content);
      }
    } catch (parseErr) {
      console.error("Failed to parse AI classification:", parseErr);
      return;
    }
    // Validate IDs exist in our data
    const validGenreId = genres.find((g)=>g.id === classification.genre_id)?.id || null;
    const validVocalTypeId = vocalTypes.find((v)=>v.id === classification.vocal_type_id)?.id || null;
    const validTemplateId = classification.template_id ? templates.find((t)=>t.id === classification.template_id)?.id || null : null;
    const validArtistStyleId = classification.artist_style_id ? artistStyles.find((a)=>a.id === classification.artist_style_id)?.id || null : null;
    // Update track with classification
    const updateData = {};
    if (validGenreId) updateData.genre_id = validGenreId;
    if (validVocalTypeId) updateData.vocal_type_id = validVocalTypeId;
    if (validTemplateId) updateData.template_id = validTemplateId;
    if (validArtistStyleId) updateData.artist_style_id = validArtistStyleId;
    if (Object.keys(updateData).length > 0) {
      const { error: updateErr } = await supabaseAdmin.from("tracks").update(updateData).eq("id", trackId);
      if (updateErr) {
        console.error("Failed to update track classification:", updateErr);
      } else {
        console.log(`Track ${trackId} classified: genre=${validGenreId}, vocal=${validVocalTypeId}, template=${validTemplateId}, artist=${validArtistStyleId}`);
      }
    }
  } catch (err) {
    console.error("Error in AI classification:", err);
  }
}
// Function to process addon services after track is completed
async function processTrackAddons(supabaseAdmin, trackId, trackTitle, coverUrl, audioUrl, sunoTaskId, sunoAudioId) {
  try {
    // Get pending addons for this track
    const { data: trackAddons, error: addonsError } = await supabaseAdmin.from("track_addons").select(`
        id,
        addon_service_id,
        status,
        addon_service:addon_services(name, name_ru)
      `).eq("track_id", trackId).eq("status", "pending");
    if (addonsError) {
      console.error("Error fetching track addons:", addonsError);
      return;
    }
    if (!trackAddons || trackAddons.length === 0) {
      console.log(`No pending addons for track ${trackId}`);
      return;
    }
    console.log(`Processing ${trackAddons.length} addons for track ${trackId}`);
    // Get track genre for better AI generation
    const { data: track } = await supabaseAdmin.from("tracks").select("genre_id, genres(name)").eq("id", trackId).single();
    const genreData = track?.genres;
    const genreName = genreData?.name || "electronic";
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    for (const addon of trackAddons){
      const addonServiceData = addon.addon_service;
      const addonName = addonServiceData?.name;
      console.log(`Processing addon: ${addonName} for track ${trackId}`);
      // Update status to processing
      await supabaseAdmin.from("track_addons").update({
        status: "processing",
        updated_at: new Date().toISOString()
      }).eq("id", addon.id);
      let functionName = null;
      let requestBody = {
        track_id: trackId,
        track_title: trackTitle,
        genre: genreName
      };
      if (addonName === "large_cover") {
        functionName = "generate-hd-cover";
        requestBody.original_cover_url = coverUrl;
      } else if (addonName === "short_video") {
        functionName = "generate-short-video";
        requestBody.cover_url = coverUrl;
        // For Suno music video generation, we need the task_id and audio_id
        if (sunoTaskId) {
          requestBody.suno_task_id = sunoTaskId;
        }
        if (sunoAudioId) {
          requestBody.suno_audio_id = sunoAudioId;
        }
      } else if (addonName === "ringtone") {
        functionName = "generate-ringtone";
        requestBody.audio_url = audioUrl;
      }
      if (functionName) {
        try {
          // Call the edge function directly using fetch
          const response = await fetch(`${SUPABASE_URL}/functions/v1/${functionName}`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${SUPABASE_SERVICE_KEY}`
            },
            body: JSON.stringify(requestBody)
          });
          const result = await response.json();
          console.log(`${functionName} result for track ${trackId}:`, result);
          if (!result.success) {
            // Mark as failed
            await supabaseAdmin.from("track_addons").update({
              status: "failed",
              updated_at: new Date().toISOString()
            }).eq("id", addon.id);
          }
        // Note: successful result_url update is handled by the edge function itself
        } catch (fnError) {
          console.error(`Error calling ${functionName}:`, fnError);
          await supabaseAdmin.from("track_addons").update({
            status: "failed",
            updated_at: new Date().toISOString()
          }).eq("id", addon.id);
        }
      } else {
        console.log(`Unknown addon type: ${addonName}, marking as failed`);
        await supabaseAdmin.from("track_addons").update({
          status: "failed",
          updated_at: new Date().toISOString()
        }).eq("id", addon.id);
      }
    }
  } catch (error) {
    console.error("Error processing track addons:", error);
  }
}
// ─── Trigger Suno Cover Generation ──────────────────────────────────
// After music is generated, request personalized cover art via Suno Cover API
// Docs: https://docs.sunoapi.org/suno-api/cover-suno
async function triggerCoverGeneration(supabaseAdmin, musicTaskId, matchedTrackIds) {
  try {
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    const SUNO_API_BASE = "https://apibox.erweima.ai";
    const callbackSecret = Deno.env.get("SUNO_CALLBACK_SECRET");
    const baseUrl = Deno.env.get("BASE_URL") || "https://aimuza.ru";
    if (!SUNO_API_KEY) {
      console.error("SUNO_API_KEY not set, skipping cover generation");
      return;
    }
    // Build cover callback URL
    const coverCallbackUrl = callbackSecret ? `${baseUrl}/functions/v1/suno-cover-callback?secret=${encodeURIComponent(callbackSecret)}` : `${baseUrl}/functions/v1/suno-cover-callback`;
    console.log(`Triggering Suno cover generation for music task ${musicTaskId}`);
    console.log(`Cover callback URL: ${coverCallbackUrl}`);
    // Call Suno Cover API
    // Try primary path first, then fallback
    const paths = [
      "/api/v1/suno/cover/generate",
      "/api/v1/cover/generate"
    ];
    let coverResponse = null;
    let coverData = null;
    for (const path of paths){
      try {
        const url = `${SUNO_API_BASE}${path}`;
        console.log(`Trying cover API: ${url}`);
        coverResponse = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${SUNO_API_KEY}`
          },
          body: JSON.stringify({
            taskId: musicTaskId,
            callBackUrl: coverCallbackUrl
          })
        });
        coverData = await coverResponse.json();
        console.log(`Cover API response (${path}):`, JSON.stringify(coverData));
        // If not a 404 (wrong path), we found the right endpoint
        if (coverResponse.status !== 404) break;
      } catch (fetchErr) {
        console.error(`Cover API fetch error (${path}):`, fetchErr);
      }
    }
    if (!coverData || coverData.code !== 200 && coverData.code !== 400) {
      console.error(`Cover API failed: ${JSON.stringify(coverData)}`);
      return;
    }
    // code 400 = cover already generated for this task (returns existing taskId)
    const coverTaskId = coverData.data?.taskId;
    if (!coverTaskId) {
      console.error("No coverTaskId in response");
      return;
    }
    console.log(`Cover generation started, cover_task_id: ${coverTaskId}`);
    // Store cover_task_id in matched tracks for callback matching
    for (const trackId of matchedTrackIds){
      const { data: track } = await supabaseAdmin.from("tracks").select("description").eq("id", trackId).single();
      if (track) {
        // Only add if not already present
        if (!track.description?.includes(`[cover_task_id: ${coverTaskId}]`)) {
          const newDesc = track.description ? `${track.description}\n\n[cover_task_id: ${coverTaskId}]` : `[cover_task_id: ${coverTaskId}]`;
          await supabaseAdmin.from("tracks").update({
            description: newDesc
          }).eq("id", trackId);
          console.log(`Stored cover_task_id ${coverTaskId} in track ${trackId}`);
        }
      }
    }
  } catch (err) {
    console.error("Error triggering cover generation:", err);
  }
}
// Human-readable error messages for Suno error codes
// Official Suno API error codes reference:
// 400 - Invalid Parameters
// 401 - Unauthorized
// 403 - Forbidden (moderation/copyright)
// 404 - Not Found
// 405 - Rate Limited (API frequency)
// 413 - Content Too Large (prompt/lyrics too long)
// 429 - Insufficient Credits
// 455 - Maintenance
// 500/503 - Server errors
function getSunoErrorMessage(code, originalMessage) {
  // First, check for specific error message patterns (more accurate than just code)
  if (originalMessage) {
    const lowerMsg = originalMessage.toLowerCase();
    // Copyright/content matching detection
    if (lowerMsg.includes("matches existing work") || lowerMsg.includes("existing work of art") || lowerMsg.includes("copyright") || lowerMsg.includes("protected content")) {
      return {
        short: "Контент защищён авторским правом",
        full: "Загруженный аудиофайл или текст распознан как существующее произведение. Система защиты авторских прав Suno заблокировала генерацию. Попробуйте использовать оригинальный контент."
      };
    }
    // Moderation/sensitive content
    if (lowerMsg.includes("moderation") || lowerMsg.includes("sensitive") || lowerMsg.includes("inappropriate") || lowerMsg.includes("prohibited")) {
      return {
        short: "Контент не прошёл модерацию",
        full: "Текст или описание содержит запрещённые слова или фразы. Измените содержимое и попробуйте снова."
      };
    }
    // Audio fetch issues
    if (lowerMsg.includes("fetch") && lowerMsg.includes("audio")) {
      return {
        short: "Не удалось получить аудиофайл",
        full: "Сервер не смог загрузить ваш аудиофайл. Проверьте, что файл доступен и попробуйте снова."
      };
    }
    // Content too long (can come in message too)
    if (lowerMsg.includes("too long") || lowerMsg.includes("too large") || lowerMsg.includes("exceeds")) {
      return {
        short: "Превышен лимит символов",
        full: "Описание, стиль или текст песни слишком длинные. Сократите текст и попробуйте снова."
      };
    }
    // Credits issues
    if (lowerMsg.includes("credit") || lowerMsg.includes("balance") || lowerMsg.includes("insufficient")) {
      return {
        short: "Недостаточно кредитов Suno",
        full: "На аккаунте Suno недостаточно кредитов для генерации. Обратитесь в поддержку."
      };
    }
  }
  // Fallback to code-based messages
  const errorMessages = {
    400: {
      short: "Неверные параметры запроса",
      full: "Параметры генерации некорректны. Проверьте введённые данные и попробуйте снова."
    },
    401: {
      short: "Ошибка авторизации",
      full: "Проблема с авторизацией в сервисе Suno. Обратитесь в поддержку."
    },
    403: {
      short: "Контент заблокирован модерацией",
      full: "Ваш запрос содержит запрещённый контент или нарушает правила использования Suno. Измените текст или описание."
    },
    404: {
      short: "Ресурс не найден",
      full: "Запрашиваемый ресурс не найден. Попробуйте ещё раз."
    },
    405: {
      short: "Превышена частота запросов",
      full: "Слишком много запросов к API. Подождите несколько минут и попробуйте снова."
    },
    413: {
      short: "Превышен лимит символов",
      full: "Описание, стиль или текст песни слишком длинные для обработки. Сократите текст (макс. ~3000 символов для lyrics, ~200 для style) и попробуйте снова."
    },
    429: {
      short: "Недостаточно кредитов",
      full: "На аккаунте Suno недостаточно кредитов для генерации. Обратитесь в поддержку."
    },
    455: {
      short: "Сервис на обслуживании",
      full: "Сервис Suno проходит техническое обслуживание. Попробуйте позже."
    },
    500: {
      short: "Внутренняя ошибка сервера",
      full: "Произошла внутренняя ошибка на сервере Suno. Попробуйте позже."
    },
    503: {
      short: "Сервис временно недоступен",
      full: "Сервис Suno временно перегружен или на обслуживании. Попробуйте позже."
    }
  };
  if (errorMessages[code]) {
    return errorMessages[code];
  }
  return {
    short: `Ошибка генерации (код ${code})`,
    full: originalMessage || `Произошла ошибка при генерации. Код ошибки: ${code}. Попробуйте позже или обратитесь в поддержку.`
  };
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // Verify callback authenticity using secret token
    const callbackSecret = Deno.env.get("SUNO_CALLBACK_SECRET");
    if (callbackSecret) {
      // Check for secret in header or query parameter
      const url = new URL(req.url);
      const headerToken = req.headers.get("x-callback-secret") || req.headers.get("authorization")?.replace("Bearer ", "");
      const queryToken = url.searchParams.get("secret");
      if (headerToken !== callbackSecret && queryToken !== callbackSecret) {
        console.error("Invalid callback secret provided");
        return new Response(JSON.stringify({
          error: "Unauthorized"
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      console.log("Callback secret verified successfully");
    } else {
      console.warn("SUNO_CALLBACK_SECRET not configured - callback verification skipped");
    }
    const supabaseAdmin = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
    const callbackData = await req.json();
    console.log("Received Suno callback:", JSON.stringify(callbackData));
    // Handle the nested data structure from Suno API
    // The structure is: { code: 200, data: { callbackType: "complete", data: [...tracks], task_id: "..." }, msg: "..." }
    const tracks = callbackData?.data?.data || callbackData?.data || [];
    const taskId = callbackData?.data?.task_id;
    const callbackType = callbackData?.data?.callbackType;
    const responseCode = callbackData?.code;
    const errorMessage = callbackData?.msg;
    console.log(`Callback type: ${callbackType}, Task ID: ${taskId}, Code: ${responseCode}, Tracks count: ${tracks.length}`);
    // Handle failed callbacks - check for error codes OR explicit failure types
    // Suno may return code 413 with callbackType "complete" when audio can't be fetched
    const isError = responseCode !== 200 || callbackType === "fail" || callbackType === "error" || callbackType === "failed";
    if (isError) {
      console.log(`Received error callback for task ${taskId} - code: ${responseCode}, type: ${callbackType}`);
      // Get human-readable error message
      const errorInfo = getSunoErrorMessage(responseCode || 500, errorMessage || callbackData?.data?.fail_reason);
      const failReason = errorInfo.short;
      // Find tracks that match this task_id first, then fall back to recent pending tracks
      let tracksToFail = [];
      // Try to find tracks by taskId in description metadata
      if (taskId) {
        const { data: taskTracks } = await supabaseAdmin.from("tracks").select("id, user_id, description").in("status", [
          "processing",
          "pending"
        ]).ilike("description", `%${taskId}%`).limit(2);
        if (taskTracks && taskTracks.length > 0) {
          tracksToFail = taskTracks;
          console.log(`Found ${taskTracks.length} tracks matching task_id ${taskId}`);
        }
      }
      // Fall back to recent pending tracks if no task match
      if (tracksToFail.length === 0) {
        const { data: pendingTracks } = await supabaseAdmin.from("tracks").select("id, user_id").in("status", [
          "processing",
          "pending"
        ]).order("created_at", {
          ascending: false
        }).limit(5);
        if (pendingTracks && pendingTracks.length > 0) {
          tracksToFail = pendingTracks;
        }
      }
      if (tracksToFail.length > 0) {
        for (const track of tracksToFail){
          await supabaseAdmin.from("tracks").update({
            status: "failed",
            error_message: failReason
          }).eq("id", track.id);
          // Get generation log to find cost
          const { data: genLog } = await supabaseAdmin.from("generation_logs").select("cost_rub").eq("track_id", track.id).single();
          // Refund ₽ to user
          if (genLog && genLog.cost_rub > 0) {
            const { data: profile } = await supabaseAdmin.from("profiles").select("balance").eq("user_id", track.user_id).single();
            if (profile) {
              const newBalance = (profile.balance || 0) + genLog.cost_rub;
              await supabaseAdmin.from("profiles").update({
                balance: newBalance
              }).eq("user_id", track.user_id);
              // Log refund transaction
              await supabaseAdmin.from("balance_transactions").insert({
                user_id: track.user_id,
                amount: genLog.cost_rub,
                balance_after: newBalance,
                type: "refund",
                description: `Возврат за генерацию: ${failReason}`,
                reference_id: track.id,
                reference_type: "track"
              });
              console.log(`Refunded ${genLog.cost_rub} ₽ to user ${track.user_id}`);
              // Create notification for refund with error explanation
              await supabaseAdmin.from("notifications").insert({
                user_id: track.user_id,
                type: "refund",
                title: `Ошибка: ${failReason}`,
                message: `${errorInfo.full}\n\nВам возвращено ${genLog.cost_rub} ₽`,
                target_type: "track",
                target_id: track.id
              });
            }
          }
          // Update generation log status to failed
          await supabaseAdmin.from("generation_logs").update({
            status: "failed"
          }).eq("track_id", track.id);
        }
        console.log(`Marked ${tracksToFail.length} tracks as failed with refunds`);
      }
      return new Response(JSON.stringify({
        received: true,
        message: "Failure callback processed with refunds"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (!Array.isArray(tracks) || tracks.length === 0) {
      console.log("No tracks in callback data");
      return new Response(JSON.stringify({
        received: true,
        message: "No tracks to process"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Process "complete" (all tracks ready) and "first" (first track ready) callbacks
    // Skip "text" callbacks (only lyrics generated, no audio yet)
    if (callbackType !== "complete" && callbackType !== "first") {
      console.log(`Skipping callback type: ${callbackType} (waiting for audio)`);
      return new Response(JSON.stringify({
        received: true,
        message: `Callback type ${callbackType} acknowledged`
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const isPartialCallback = callbackType === "first";
    if (isPartialCallback) {
      console.log(`Processing partial callback (first) — will only update tracks that have audio_url`);
    }
    // CRITICAL: First, find tracks that match this specific task_id
    // This prevents cross-user track mixing when multiple generations are pending
    let matchedTracks = [];
    if (taskId) {
      const { data: taskTracks, error: taskFindError } = await supabaseAdmin.from("tracks").select("id, title, description, lyrics, user_id, status").in("status", [
        "processing",
        "pending"
      ]).ilike("description", `%[task_id: ${taskId}]%`).order("created_at", {
        ascending: true
      }).limit(2);
      if (taskFindError) {
        console.error("Error finding tracks by task_id:", taskFindError);
      } else if (taskTracks && taskTracks.length > 0) {
        matchedTracks = taskTracks;
        console.log(`Found ${taskTracks.length} tracks matching task_id ${taskId}`);
      }
    }
    // If no task_id match, log a warning but DO NOT fall back to random pending tracks
    // This is critical to prevent cross-user track mixing
    if (matchedTracks.length === 0) {
      console.warn(`No tracks found matching task_id ${taskId}. Callback will be ignored to prevent cross-user mixing.`);
      console.warn(`Callback data had ${tracks.length} audio tracks, but no matching DB records.`);
      return new Response(JSON.stringify({
        received: true,
        warning: "No matching tracks found for task_id",
        task_id: taskId
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    let updatedCount = 0;
    // Create a copy of matched tracks for safe iteration (avoid mutation issues)
    const tracksToProcess = [
      ...matchedTracks
    ];
    // Track which indices have been processed
    const processedIndices = new Set();
    // Suno returns 2 versions per generation request
    // Match them to our v1/v2 track pairs by order (first Suno result -> v1, second -> v2)
    for(let i = 0; i < tracks.length; i++){
      const track = tracks[i];
      const { id: sunoAudioId, audio_url, source_audio_url, stream_audio_url, image_url, source_image_url, duration, title: sunoTitle } = track;
      const audioUrl = audio_url || source_audio_url || stream_audio_url;
      const coverUrl = image_url || source_image_url;
      if (!audioUrl) {
        console.log("Track has no audio URL, skipping");
        continue;
      }
      // Match by index: first Suno result -> first matched track (v1), second -> second (v2)
      // Use the original array copy, not the mutated one
      const trackToUpdate = tracksToProcess[i];
      // Safety check: ensure we're updating the right user's track
      if (!trackToUpdate) {
        console.log(`No matched track at index ${i} for Suno result: ${sunoTitle}`);
        continue;
      }
      // Skip if already processed (shouldn't happen, but be safe)
      if (processedIndices.has(i)) {
        console.log(`Track at index ${i} already processed, skipping`);
        continue;
      }
      processedIndices.add(i);
      console.log(`Updating track ${trackToUpdate.id} (${trackToUpdate.title}) with audio: ${audioUrl}`);
      // Copy files to Supabase Storage for permanent storage
      let finalAudioUrl = audioUrl;
      let finalCoverUrl = coverUrl;
      // Copy audio file to Storage
      try {
        const audioFileName = `${trackToUpdate.id}.mp3`;
        const storedAudioUrl = await copyFileToStorage(supabaseAdmin, audioUrl, "tracks", `audio/${audioFileName}`);
        if (storedAudioUrl) {
          finalAudioUrl = storedAudioUrl;
          console.log(`Audio copied to storage: ${finalAudioUrl}`);
        } else {
          console.log(`Failed to copy audio, using original URL`);
        }
      } catch (audioErr) {
        console.error(`Error copying audio:`, audioErr);
      }
      // Copy cover image to Storage
      if (coverUrl) {
        try {
          const coverFileName = `${trackToUpdate.id}.jpg`;
          const storedCoverUrl = await copyFileToStorage(supabaseAdmin, coverUrl, "tracks", `covers/${coverFileName}`);
          if (storedCoverUrl) {
            finalCoverUrl = storedCoverUrl;
            console.log(`Cover copied to storage: ${finalCoverUrl}`);
          } else {
            console.log(`Failed to copy cover, using original URL`);
          }
        } catch (coverErr) {
          console.error(`Error copying cover:`, coverErr);
        }
      }
      const { error: updateError } = await supabaseAdmin.from("tracks").update({
        audio_url: finalAudioUrl,
        cover_url: finalCoverUrl || null,
        duration: duration ? Math.round(duration) : null,
        status: "completed",
        // Store Suno audio ID for persona creation
        suno_audio_id: sunoAudioId || null,
        // Store suno_task_id in description for reference (append to existing)
        description: trackToUpdate.description ? `${trackToUpdate.description}\n\n[task_id: ${taskId}]` : `[task_id: ${taskId}]`
      }).eq("id", trackToUpdate.id);
      if (updateError) {
        console.error("Error updating track:", updateError);
      } else {
        console.log(`Track ${trackToUpdate.id} updated successfully with Storage URLs`);
        updatedCount++;
        // Update generation log status
        await supabaseAdmin.from("generation_logs").update({
          status: "completed"
        }).eq("track_id", trackToUpdate.id);
        // Process addon services for this track (pass taskId and audioId for Suno video generation)
        await processTrackAddons(supabaseAdmin, trackToUpdate.id, trackToUpdate.title || "Untitled", finalCoverUrl, finalAudioUrl, taskId, sunoAudioId);
        // AI Classification - run in background to not block response
        // Extract style from track description (before task_id was appended)
        const originalDescription = trackToUpdate.description?.replace(/\n\n\[task_id:.*\]$/, "") || null;
        const trackLyrics = trackToUpdate.lyrics || null;
        runInBackground(`classifyTrack-${trackToUpdate.id}`, classifyTrackWithAI(supabaseAdmin, trackToUpdate.id, originalDescription, trackLyrics));
      }
    }
    // ─── Trigger Suno Cover Generation (background) ────────────────
    // After all music tracks are updated, request personalized cover art
    // This runs in background so we don't delay the callback response
    // Only trigger on "complete" callback (not "first") to avoid premature cover generation
    if (updatedCount > 0 && taskId && !isPartialCallback) {
      const trackIdsForCover = tracksToProcess.filter((t)=>processedIndices.has(tracksToProcess.indexOf(t))).map((t)=>t.id);
      if (trackIdsForCover.length > 0) {
        runInBackground(`coverGeneration-${taskId}`, triggerCoverGeneration(supabaseAdmin, taskId, trackIdsForCover));
      }
    }
    return new Response(JSON.stringify({
      success: true,
      updated: updatedCount
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in suno-callback:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9zdW5vLWNhbGxiYWNrL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE2OC4wL2h0dHAvc2VydmVyLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQsIFN1cGFiYXNlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbi8vIEJhY2tncm91bmQgdGFzayBoZWxwZXIg4oCUIGZpcmUtYW5kLWZvcmdldCBwYXR0ZXJuXG4vLyAoRWRnZVJ1bnRpbWUud2FpdFVudGlsIGlzIE5PVCBhdmFpbGFibGUgaW4gdGhpcyBEZW5vIHNlcnZlcilcbmZ1bmN0aW9uIHJ1bkluQmFja2dyb3VuZCh0YXNrTmFtZTogc3RyaW5nLCBwcm9taXNlOiBQcm9taXNlPHVua25vd24+KTogdm9pZCB7XG4gIHByb21pc2UuY2F0Y2goZXJyID0+IGNvbnNvbGUuZXJyb3IoYFtCYWNrZ3JvdW5kOiAke3Rhc2tOYW1lfV0gRXJyb3I6YCwgZXJyKSk7XG59XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbi8vIEhlbHBlciBmdW5jdGlvbiB0byBkb3dubG9hZCBmaWxlIGFuZCB1cGxvYWQgdG8gU3VwYWJhc2UgU3RvcmFnZVxuYXN5bmMgZnVuY3Rpb24gY29weUZpbGVUb1N0b3JhZ2UoXG4gIHN1cGFiYXNlQWRtaW46IFN1cGFiYXNlQ2xpZW50LFxuICBleHRlcm5hbFVybDogc3RyaW5nLFxuICBidWNrZXQ6IHN0cmluZyxcbiAgZmlsZVBhdGg6IHN0cmluZ1xuKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gIHRyeSB7XG4gICAgY29uc29sZS5sb2coYERvd25sb2FkaW5nIGZpbGUgZnJvbTogJHtleHRlcm5hbFVybH1gKTtcbiAgICBcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGV4dGVybmFsVXJsKTtcbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBGYWlsZWQgdG8gZG93bmxvYWQ6ICR7cmVzcG9uc2Uuc3RhdHVzfSAke3Jlc3BvbnNlLnN0YXR1c1RleHR9YCk7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzcG9uc2UuYmxvYigpO1xuICAgIGNvbnN0IGFycmF5QnVmZmVyID0gYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpO1xuICAgIGNvbnN0IHVpbnQ4QXJyYXkgPSBuZXcgVWludDhBcnJheShhcnJheUJ1ZmZlcik7XG4gICAgXG4gICAgY29uc29sZS5sb2coYERvd25sb2FkZWQgJHt1aW50OEFycmF5Lmxlbmd0aH0gYnl0ZXMsIHVwbG9hZGluZyB0byAke2J1Y2tldH0vJHtmaWxlUGF0aH1gKTtcblxuICAgIGNvbnN0IHsgZXJyb3I6IHVwbG9hZEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluLnN0b3JhZ2VcbiAgICAgIC5mcm9tKGJ1Y2tldClcbiAgICAgIC51cGxvYWQoZmlsZVBhdGgsIHVpbnQ4QXJyYXksIHtcbiAgICAgICAgY29udGVudFR5cGU6IGJsb2IudHlwZSB8fCBcImFwcGxpY2F0aW9uL29jdGV0LXN0cmVhbVwiLFxuICAgICAgICB1cHNlcnQ6IHRydWUsXG4gICAgICB9KTtcblxuICAgIGlmICh1cGxvYWRFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihgVXBsb2FkIGVycm9yOmAsIHVwbG9hZEVycm9yKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIC8vIEJ1aWxkIHB1YmxpYyBVUkwgdXNpbmcgQkFTRV9VUkwgKG5vdCBpbnRlcm5hbCBTVVBBQkFTRV9VUkwgd2hpY2ggaXMgaHR0cDovL2FwaTozMDAwKVxuICAgIGNvbnN0IGJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJCQVNFX1VSTFwiKSB8fCBcImh0dHBzOi8vYWltdXphLnJ1XCI7XG4gICAgY29uc3QgcHVibGljVXJsID0gYCR7YmFzZVVybH0vc3RvcmFnZS92MS9vYmplY3QvcHVibGljLyR7YnVja2V0fS8ke2ZpbGVQYXRofWA7XG5cbiAgICBjb25zb2xlLmxvZyhgRmlsZSB1cGxvYWRlZCBzdWNjZXNzZnVsbHk6ICR7cHVibGljVXJsfWApO1xuICAgIHJldHVybiBwdWJsaWNVcmw7XG4gICAgXG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNvcHlpbmcgZmlsZSB0byBzdG9yYWdlOmAsIGVycik7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuLy8gVGltZXdlYiBBZ2VudCBBUEkgY29uZmlndXJhdGlvbiBmb3IgQUkgY2xhc3NpZmljYXRpb25cbmNvbnN0IFRJTUVXRUJfQUdFTlRfQUNDRVNTX0lEID0gJzA4NDZkMDY0LTQ5NTAtNGQ3OS1hNTRjLTYyYmEzMTVjZGIzNCc7XG5cbi8vIEFJIENsYXNzaWZpY2F0aW9uIGZ1bmN0aW9uIC0gZGV0ZXJtaW5lcyBnZW5yZSwgdm9jYWwgdHlwZSwgdGVtcGxhdGUsIGFydGlzdCBzdHlsZVxuLy8gVXNlcyBUaW1ld2ViIEFnZW50IEFQSSAoR1BULTQpXG5hc3luYyBmdW5jdGlvbiBjbGFzc2lmeVRyYWNrV2l0aEFJKFxuICBzdXBhYmFzZUFkbWluOiBTdXBhYmFzZUNsaWVudCxcbiAgdHJhY2tJZDogc3RyaW5nLFxuICBzdHlsZTogc3RyaW5nIHwgbnVsbCxcbiAgbHlyaWNzOiBzdHJpbmcgfCBudWxsXG4pIHtcbiAgdHJ5IHtcbiAgICBjb25zb2xlLmxvZyhgU3RhcnRpbmcgQUkgY2xhc3NpZmljYXRpb24gZm9yIHRyYWNrICR7dHJhY2tJZH1gKTtcbiAgICBcbiAgICBjb25zdCBUSU1FV0VCX1RPS0VOID0gRGVuby5lbnYuZ2V0KFwiVElNRVdFQl9BR0VOVF9UT0tFTlwiKTtcbiAgICBpZiAoIVRJTUVXRUJfVE9LRU4pIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJUSU1FV0VCX0FHRU5UX1RPS0VOIG5vdCBjb25maWd1cmVkLCBza2lwcGluZyBjbGFzc2lmaWNhdGlvblwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgXG4gICAgLy8gRmV0Y2ggYWxsIGF2YWlsYWJsZSBvcHRpb25zIGZyb20gZGF0YWJhc2VcbiAgICBjb25zdCBbZ2VucmVzUmVzLCB2b2NhbFR5cGVzUmVzLCB0ZW1wbGF0ZXNSZXMsIGFydGlzdFN0eWxlc1Jlc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICBzdXBhYmFzZUFkbWluLmZyb20oXCJnZW5yZXNcIikuc2VsZWN0KFwiaWQsIG5hbWUsIG5hbWVfcnVcIikub3JkZXIoXCJzb3J0X29yZGVyXCIpLFxuICAgICAgc3VwYWJhc2VBZG1pbi5mcm9tKFwidm9jYWxfdHlwZXNcIikuc2VsZWN0KFwiaWQsIG5hbWUsIG5hbWVfcnUsIGRlc2NyaXB0aW9uXCIpLmVxKFwiaXNfYWN0aXZlXCIsIHRydWUpLm9yZGVyKFwic29ydF9vcmRlclwiKSxcbiAgICAgIHN1cGFiYXNlQWRtaW4uZnJvbShcInRlbXBsYXRlc1wiKS5zZWxlY3QoXCJpZCwgbmFtZSwgZGVzY3JpcHRpb25cIikuZXEoXCJpc19hY3RpdmVcIiwgdHJ1ZSkub3JkZXIoXCJzb3J0X29yZGVyXCIpLFxuICAgICAgc3VwYWJhc2VBZG1pbi5mcm9tKFwiYXJ0aXN0X3N0eWxlc1wiKS5zZWxlY3QoXCJpZCwgbmFtZSwgZGVzY3JpcHRpb25cIikuZXEoXCJpc19hY3RpdmVcIiwgdHJ1ZSkub3JkZXIoXCJzb3J0X29yZGVyXCIpLFxuICAgIF0pO1xuICAgIFxuICAgIGNvbnN0IGdlbnJlcyA9IGdlbnJlc1Jlcy5kYXRhIHx8IFtdO1xuICAgIGNvbnN0IHZvY2FsVHlwZXMgPSB2b2NhbFR5cGVzUmVzLmRhdGEgfHwgW107XG4gICAgY29uc3QgdGVtcGxhdGVzID0gdGVtcGxhdGVzUmVzLmRhdGEgfHwgW107XG4gICAgY29uc3QgYXJ0aXN0U3R5bGVzID0gYXJ0aXN0U3R5bGVzUmVzLmRhdGEgfHwgW107XG4gICAgXG4gICAgaWYgKGdlbnJlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiTm8gZ2VucmVzIGluIGRhdGFiYXNlLCBza2lwcGluZyBjbGFzc2lmaWNhdGlvblwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgXG4gICAgLy8gQnVpbGQgdGhlIGNsYXNzaWZpY2F0aW9uIHByb21wdFxuICAgIGNvbnN0IGdlbnJlc0xpc3QgPSBnZW5yZXMubWFwKGcgPT4gYC0gaWQ6IFwiJHtnLmlkfVwiLCBuYW1lOiBcIiR7Zy5uYW1lfVwiICgke2cubmFtZV9ydX0pYCkuam9pbihcIlxcblwiKTtcbiAgICBjb25zdCB2b2NhbFR5cGVzTGlzdCA9IHZvY2FsVHlwZXMubWFwKHYgPT4gYC0gaWQ6IFwiJHt2LmlkfVwiLCBuYW1lOiBcIiR7di5uYW1lfVwiICgke3YubmFtZV9ydX0pJHt2LmRlc2NyaXB0aW9uID8gYCAtICR7di5kZXNjcmlwdGlvbn1gIDogXCJcIn1gKS5qb2luKFwiXFxuXCIpO1xuICAgIGNvbnN0IHRlbXBsYXRlc0xpc3QgPSB0ZW1wbGF0ZXMubGVuZ3RoID4gMCBcbiAgICAgID8gdGVtcGxhdGVzLm1hcCh0ID0+IGAtIGlkOiBcIiR7dC5pZH1cIiwgbmFtZTogXCIke3QubmFtZX1cIiR7dC5kZXNjcmlwdGlvbiA/IGAgLSAke3QuZGVzY3JpcHRpb259YCA6IFwiXCJ9YCkuam9pbihcIlxcblwiKVxuICAgICAgOiBcItCd0LXRgiDQtNC+0YHRgtGD0L/QvdGL0YUg0YjQsNCx0LvQvtC90L7QslwiO1xuICAgIGNvbnN0IGFydGlzdFN0eWxlc0xpc3QgPSBhcnRpc3RTdHlsZXMubGVuZ3RoID4gMFxuICAgICAgPyBhcnRpc3RTdHlsZXMubWFwKGEgPT4gYC0gaWQ6IFwiJHthLmlkfVwiLCBuYW1lOiBcIiR7YS5uYW1lfVwiJHthLmRlc2NyaXB0aW9uID8gYCAtICR7YS5kZXNjcmlwdGlvbn1gIDogXCJcIn1gKS5qb2luKFwiXFxuXCIpXG4gICAgICA6IFwi0J3QtdGCINC00L7RgdGC0YPQv9C90YvRhSDRgdGC0LjQu9C10Lkg0LDRgNGC0LjRgdGC0L7QslwiO1xuICAgIFxuICAgIGNvbnN0IHByb21wdCA9IGDQotGLIOKAlCDQvNGD0LfRi9C60LDQu9GM0L3Ri9C5INC60LvQsNGB0YHQuNGE0LjQutCw0YLQvtGALiDQn9GA0L7QsNC90LDQu9C40LfQuNGA0YPQuSDRgdGC0LjQu9GMINC4INC70LjRgNC40LrRgyDRgtGA0LXQutCwLlxu0JLRi9Cx0LXRgNC4INCe0JTQmNCdINC90LDQuNCx0L7Qu9C10LUg0L/QvtC00YXQvtC00Y/RidC40Lkg0LLQsNGA0LjQsNC90YIg0LjQtyDQutCw0LbQtNC+0Lkg0LrQsNGC0LXQs9C+0YDQuNC4LlxuXG7QltCQ0J3QoNCrICjQvtCx0Y/Qt9Cw0YLQtdC70YzQvdC+INCy0YvQsdC10YDQuCDQvtC00LjQvSk6XG4ke2dlbnJlc0xpc3R9XG5cbtCi0JjQn9CrINCS0J7QmtCQ0JvQkCAo0L7QsdGP0LfQsNGC0LXQu9GM0L3QviDQstGL0LHQtdGA0Lgg0L7QtNC40L0pOlxuJHt2b2NhbFR5cGVzTGlzdH1cblxu0KjQkNCR0JvQntCd0KsgKNC+0L/RhtC40L7QvdCw0LvRjNC90L4sINCy0YvQsdC10YDQuCDQtdGB0LvQuCDQv9C+0LTRhdC+0LTQuNGCKTpcbiR7dGVtcGxhdGVzTGlzdH1cblxu0KHQotCY0JvQmCDQkNCg0KLQmNCh0KLQntCSICjQvtC/0YbQuNC+0L3QsNC70YzQvdC+LCDQstGL0LHQtdGA0Lgg0LXRgdC70Lgg0LXRgdGC0Ywg0Y/QstC90L7QtSDRgdGF0L7QtNGB0YLQstC+KTpcbiR7YXJ0aXN0U3R5bGVzTGlzdH1cblxuLS0tXG7QodCi0JjQm9CsINCi0KDQldCa0JA6ICR7c3R5bGUgfHwgXCLQndC1INGD0LrQsNC30LDQvVwifVxu0JvQmNCg0JjQmtCQOiAke2x5cmljcyA/IGx5cmljcy5zdWJzdHJpbmcoMCwgMTAwMCkgOiBcItCY0L3RgdGC0YDRg9C80LXQvdGC0LDQuyAo0LHQtdC3INGC0LXQutGB0YLQsClcIn1cbi0tLVxuXG7Qn9GA0LDQstC40LvQsDpcbjEuIGdlbnJlX2lkIC0g0J7QkdCv0JfQkNCi0JXQm9CV0J0sINCy0YvQsdC10YDQuCDQvdCw0LjQsdC+0LvQtdC1INCx0LvQuNC30LrQuNC5INC20LDQvdGAXG4yLiB2b2NhbF90eXBlX2lkIC0g0J7QkdCv0JfQkNCi0JXQm9CV0J0uINCV0YHQu9C4INC90LXRgiDQu9C40YDQuNC60LgsINCy0YvQsdC10YDQuCBcImluc3RydW1lbnRhbFwiXG4zLiB0ZW1wbGF0ZV9pZCAtINGC0L7Qu9GM0LrQviDQtdGB0LvQuCDRgtGA0LXQuiDRj9Cy0L3QviDRgdC+0L7RgtCy0LXRgtGB0YLQstGD0LXRgiDRiNCw0LHQu9C+0L3Rgywg0LjQvdCw0YfQtSBudWxsXG40LiBhcnRpc3Rfc3R5bGVfaWQgLSDRgtC+0LvRjNC60L4g0LXRgdC70Lgg0YHRgtC40LvRjCDRj9Cy0L3QviDQv9C+0YXQvtC2INC90LAg0LrQvtC90LrRgNC10YLQvdC+0LPQviDQsNGA0YLQuNGB0YLQsCwg0LjQvdCw0YfQtSBudWxsXG5cbtCS0LXRgNC90Lgg0KLQntCb0KzQmtCeIEpTT04g0LHQtdC3IG1hcmtkb3duOlxue1wiZ2VucmVfaWRcIjogXCIuLi5cIiwgXCJ2b2NhbF90eXBlX2lkXCI6IFwiLi4uXCIsIFwidGVtcGxhdGVfaWRcIjogXCIuLi5cIiDQuNC70LggbnVsbCwgXCJhcnRpc3Rfc3R5bGVfaWRcIjogXCIuLi5cIiDQuNC70LggbnVsbH1gO1xuXG4gICAgY29uc3QgYXBpVXJsID0gYGh0dHBzOi8vYWdlbnQudGltZXdlYi5jbG91ZC9hcGkvdjEvY2xvdWQtYWkvYWdlbnRzLyR7VElNRVdFQl9BR0VOVF9BQ0NFU1NfSUR9L3YxL2NoYXQvY29tcGxldGlvbnNgO1xuICAgIFxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYXBpVXJsLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7VElNRVdFQl9UT0tFTn1gLFxuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJ4LXByb3h5LXNvdXJjZVwiOiBcImxvdmFibGUtYXBwXCIsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBtb2RlbDogXCJkZWVwc2Vlay12M1wiLFxuICAgICAgICBtZXNzYWdlczogW1xuICAgICAgICAgIHsgcm9sZTogXCJzeXN0ZW1cIiwgY29udGVudDogXCLQotGLINC80YPQt9GL0LrQsNC70YzQvdGL0Lkg0LrQu9Cw0YHRgdC40YTQuNC60LDRgtC+0YAuINCe0YLQstC10YfQsNC5INGC0L7Qu9GM0LrQviBKU09OLlwiIH0sXG4gICAgICAgICAgeyByb2xlOiBcInVzZXJcIiwgY29udGVudDogcHJvbXB0IH1cbiAgICAgICAgXSxcbiAgICAgICAgdGVtcGVyYXR1cmU6IDAuMyxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgY29uc29sZS5lcnJvcihgQUkgY2xhc3NpZmljYXRpb24gZmFpbGVkOiAke3Jlc3BvbnNlLnN0YXR1c31gKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgY29uc3QgY29udGVudCA9IHJlc3VsdC5jaG9pY2VzPy5bMF0/Lm1lc3NhZ2U/LmNvbnRlbnQ7XG4gICAgXG4gICAgaWYgKCFjb250ZW50KSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiTm8gY29udGVudCBpbiBBSSByZXNwb25zZVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgXG4gICAgY29uc29sZS5sb2coYEFJIGNsYXNzaWZpY2F0aW9uIHJlc3BvbnNlOiAke2NvbnRlbnR9YCk7XG4gICAgXG4gICAgLy8gUGFyc2UgSlNPTiByZXNwb25zZSAoaGFuZGxlIHBvdGVudGlhbCBtYXJrZG93biB3cmFwcGVyKVxuICAgIGxldCBjbGFzc2lmaWNhdGlvbjtcbiAgICB0cnkge1xuICAgICAgY29uc3QganNvbk1hdGNoID0gY29udGVudC5tYXRjaCgvXFx7W1xcc1xcU10qXFx9Lyk7XG4gICAgICBpZiAoanNvbk1hdGNoKSB7XG4gICAgICAgIGNsYXNzaWZpY2F0aW9uID0gSlNPTi5wYXJzZShqc29uTWF0Y2hbMF0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2xhc3NpZmljYXRpb24gPSBKU09OLnBhcnNlKGNvbnRlbnQpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKHBhcnNlRXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHBhcnNlIEFJIGNsYXNzaWZpY2F0aW9uOlwiLCBwYXJzZUVycik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIFxuICAgIC8vIFZhbGlkYXRlIElEcyBleGlzdCBpbiBvdXIgZGF0YVxuICAgIGNvbnN0IHZhbGlkR2VucmVJZCA9IGdlbnJlcy5maW5kKGcgPT4gZy5pZCA9PT0gY2xhc3NpZmljYXRpb24uZ2VucmVfaWQpPy5pZCB8fCBudWxsO1xuICAgIGNvbnN0IHZhbGlkVm9jYWxUeXBlSWQgPSB2b2NhbFR5cGVzLmZpbmQodiA9PiB2LmlkID09PSBjbGFzc2lmaWNhdGlvbi52b2NhbF90eXBlX2lkKT8uaWQgfHwgbnVsbDtcbiAgICBjb25zdCB2YWxpZFRlbXBsYXRlSWQgPSBjbGFzc2lmaWNhdGlvbi50ZW1wbGF0ZV9pZCBcbiAgICAgID8gdGVtcGxhdGVzLmZpbmQodCA9PiB0LmlkID09PSBjbGFzc2lmaWNhdGlvbi50ZW1wbGF0ZV9pZCk/LmlkIHx8IG51bGwgXG4gICAgICA6IG51bGw7XG4gICAgY29uc3QgdmFsaWRBcnRpc3RTdHlsZUlkID0gY2xhc3NpZmljYXRpb24uYXJ0aXN0X3N0eWxlX2lkIFxuICAgICAgPyBhcnRpc3RTdHlsZXMuZmluZChhID0+IGEuaWQgPT09IGNsYXNzaWZpY2F0aW9uLmFydGlzdF9zdHlsZV9pZCk/LmlkIHx8IG51bGwgXG4gICAgICA6IG51bGw7XG4gICAgXG4gICAgLy8gVXBkYXRlIHRyYWNrIHdpdGggY2xhc3NpZmljYXRpb25cbiAgICBjb25zdCB1cGRhdGVEYXRhOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgfCBudWxsPiA9IHt9O1xuICAgIGlmICh2YWxpZEdlbnJlSWQpIHVwZGF0ZURhdGEuZ2VucmVfaWQgPSB2YWxpZEdlbnJlSWQ7XG4gICAgaWYgKHZhbGlkVm9jYWxUeXBlSWQpIHVwZGF0ZURhdGEudm9jYWxfdHlwZV9pZCA9IHZhbGlkVm9jYWxUeXBlSWQ7XG4gICAgaWYgKHZhbGlkVGVtcGxhdGVJZCkgdXBkYXRlRGF0YS50ZW1wbGF0ZV9pZCA9IHZhbGlkVGVtcGxhdGVJZDtcbiAgICBpZiAodmFsaWRBcnRpc3RTdHlsZUlkKSB1cGRhdGVEYXRhLmFydGlzdF9zdHlsZV9pZCA9IHZhbGlkQXJ0aXN0U3R5bGVJZDtcbiAgICBcbiAgICBpZiAoT2JqZWN0LmtleXModXBkYXRlRGF0YSkubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgIC51cGRhdGUodXBkYXRlRGF0YSlcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZCk7XG4gICAgICBcbiAgICAgIGlmICh1cGRhdGVFcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgdHJhY2sgY2xhc3NpZmljYXRpb246XCIsIHVwZGF0ZUVycik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhgVHJhY2sgJHt0cmFja0lkfSBjbGFzc2lmaWVkOiBnZW5yZT0ke3ZhbGlkR2VucmVJZH0sIHZvY2FsPSR7dmFsaWRWb2NhbFR5cGVJZH0sIHRlbXBsYXRlPSR7dmFsaWRUZW1wbGF0ZUlkfSwgYXJ0aXN0PSR7dmFsaWRBcnRpc3RTdHlsZUlkfWApO1xuICAgICAgfVxuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIEFJIGNsYXNzaWZpY2F0aW9uOlwiLCBlcnIpO1xuICB9XG59XG5cbi8vIEZ1bmN0aW9uIHRvIHByb2Nlc3MgYWRkb24gc2VydmljZXMgYWZ0ZXIgdHJhY2sgaXMgY29tcGxldGVkXG5hc3luYyBmdW5jdGlvbiBwcm9jZXNzVHJhY2tBZGRvbnMoXG4gIHN1cGFiYXNlQWRtaW46IFN1cGFiYXNlQ2xpZW50LFxuICB0cmFja0lkOiBzdHJpbmcsXG4gIHRyYWNrVGl0bGU6IHN0cmluZyxcbiAgY292ZXJVcmw6IHN0cmluZyB8IG51bGwsXG4gIGF1ZGlvVXJsOiBzdHJpbmcgfCBudWxsLFxuICBzdW5vVGFza0lkPzogc3RyaW5nLFxuICBzdW5vQXVkaW9JZD86IHN0cmluZ1xuKSB7XG4gIHRyeSB7XG4gICAgLy8gR2V0IHBlbmRpbmcgYWRkb25zIGZvciB0aGlzIHRyYWNrXG4gICAgY29uc3QgeyBkYXRhOiB0cmFja0FkZG9ucywgZXJyb3I6IGFkZG9uc0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgLnNlbGVjdChgXG4gICAgICAgIGlkLFxuICAgICAgICBhZGRvbl9zZXJ2aWNlX2lkLFxuICAgICAgICBzdGF0dXMsXG4gICAgICAgIGFkZG9uX3NlcnZpY2U6YWRkb25fc2VydmljZXMobmFtZSwgbmFtZV9ydSlcbiAgICAgIGApXG4gICAgICAuZXEoXCJ0cmFja19pZFwiLCB0cmFja0lkKVxuICAgICAgLmVxKFwic3RhdHVzXCIsIFwicGVuZGluZ1wiKTtcblxuICAgIGlmIChhZGRvbnNFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHRyYWNrIGFkZG9uczpcIiwgYWRkb25zRXJyb3IpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICghdHJhY2tBZGRvbnMgfHwgdHJhY2tBZGRvbnMubGVuZ3RoID09PSAwKSB7XG4gICAgICBjb25zb2xlLmxvZyhgTm8gcGVuZGluZyBhZGRvbnMgZm9yIHRyYWNrICR7dHJhY2tJZH1gKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgUHJvY2Vzc2luZyAke3RyYWNrQWRkb25zLmxlbmd0aH0gYWRkb25zIGZvciB0cmFjayAke3RyYWNrSWR9YCk7XG5cbiAgICAvLyBHZXQgdHJhY2sgZ2VucmUgZm9yIGJldHRlciBBSSBnZW5lcmF0aW9uXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjayB9ID0gYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgIC5zZWxlY3QoXCJnZW5yZV9pZCwgZ2VucmVzKG5hbWUpXCIpXG4gICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgY29uc3QgZ2VucmVEYXRhID0gKHRyYWNrPy5nZW5yZXMgYXMgdW5rbm93bikgYXMgeyBuYW1lOiBzdHJpbmcgfSB8IG51bGw7XG4gICAgY29uc3QgZ2VucmVOYW1lID0gZ2VucmVEYXRhPy5uYW1lIHx8IFwiZWxlY3Ryb25pY1wiO1xuXG4gICAgY29uc3QgU1VQQUJBU0VfVVJMID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBTVVBBQkFTRV9TRVJWSUNFX0tFWSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhXG5cbiAgICBmb3IgKGNvbnN0IGFkZG9uIG9mIHRyYWNrQWRkb25zKSB7XG4gICAgICBjb25zdCBhZGRvblNlcnZpY2VEYXRhID0gKGFkZG9uLmFkZG9uX3NlcnZpY2UgYXMgdW5rbm93bikgYXMgeyBuYW1lOiBzdHJpbmc7IG5hbWVfcnU6IHN0cmluZyB9IHwgbnVsbDtcbiAgICAgIGNvbnN0IGFkZG9uTmFtZSA9IGFkZG9uU2VydmljZURhdGE/Lm5hbWU7XG4gICAgICBjb25zb2xlLmxvZyhgUHJvY2Vzc2luZyBhZGRvbjogJHthZGRvbk5hbWV9IGZvciB0cmFjayAke3RyYWNrSWR9YCk7XG5cbiAgICAgIC8vIFVwZGF0ZSBzdGF0dXMgdG8gcHJvY2Vzc2luZ1xuICAgICAgYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgICAudXBkYXRlKHsgc3RhdHVzOiBcInByb2Nlc3NpbmdcIiwgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0pXG4gICAgICAgIC5lcShcImlkXCIsIGFkZG9uLmlkKTtcblxuICAgICAgbGV0IGZ1bmN0aW9uTmFtZTogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gICAgICBsZXQgcmVxdWVzdEJvZHk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgICAgICB0cmFja19pZDogdHJhY2tJZCxcbiAgICAgICAgdHJhY2tfdGl0bGU6IHRyYWNrVGl0bGUsXG4gICAgICAgIGdlbnJlOiBnZW5yZU5hbWUsXG4gICAgICB9O1xuICAgICAgXG4gICAgICBpZiAoYWRkb25OYW1lID09PSBcImxhcmdlX2NvdmVyXCIpIHtcbiAgICAgICAgZnVuY3Rpb25OYW1lID0gXCJnZW5lcmF0ZS1oZC1jb3ZlclwiO1xuICAgICAgICByZXF1ZXN0Qm9keS5vcmlnaW5hbF9jb3Zlcl91cmwgPSBjb3ZlclVybDtcbiAgICAgIH0gZWxzZSBpZiAoYWRkb25OYW1lID09PSBcInNob3J0X3ZpZGVvXCIpIHtcbiAgICAgICAgZnVuY3Rpb25OYW1lID0gXCJnZW5lcmF0ZS1zaG9ydC12aWRlb1wiO1xuICAgICAgICByZXF1ZXN0Qm9keS5jb3Zlcl91cmwgPSBjb3ZlclVybDtcbiAgICAgICAgLy8gRm9yIFN1bm8gbXVzaWMgdmlkZW8gZ2VuZXJhdGlvbiwgd2UgbmVlZCB0aGUgdGFza19pZCBhbmQgYXVkaW9faWRcbiAgICAgICAgaWYgKHN1bm9UYXNrSWQpIHtcbiAgICAgICAgICByZXF1ZXN0Qm9keS5zdW5vX3Rhc2tfaWQgPSBzdW5vVGFza0lkO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzdW5vQXVkaW9JZCkge1xuICAgICAgICAgIHJlcXVlc3RCb2R5LnN1bm9fYXVkaW9faWQgPSBzdW5vQXVkaW9JZDtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChhZGRvbk5hbWUgPT09IFwicmluZ3RvbmVcIikge1xuICAgICAgICBmdW5jdGlvbk5hbWUgPSBcImdlbmVyYXRlLXJpbmd0b25lXCI7XG4gICAgICAgIHJlcXVlc3RCb2R5LmF1ZGlvX3VybCA9IGF1ZGlvVXJsO1xuICAgICAgfVxuXG4gICAgICBpZiAoZnVuY3Rpb25OYW1lKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgLy8gQ2FsbCB0aGUgZWRnZSBmdW5jdGlvbiBkaXJlY3RseSB1c2luZyBmZXRjaFxuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7U1VQQUJBU0VfVVJMfS9mdW5jdGlvbnMvdjEvJHtmdW5jdGlvbk5hbWV9YCwge1xuICAgICAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VQQUJBU0VfU0VSVklDRV9LRVl9YCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShyZXF1ZXN0Qm9keSksXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgICAgY29uc29sZS5sb2coYCR7ZnVuY3Rpb25OYW1lfSByZXN1bHQgZm9yIHRyYWNrICR7dHJhY2tJZH06YCwgcmVzdWx0KTtcblxuICAgICAgICAgIGlmICghcmVzdWx0LnN1Y2Nlc3MpIHtcbiAgICAgICAgICAgIC8vIE1hcmsgYXMgZmFpbGVkXG4gICAgICAgICAgICBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgICAgICAgIC51cGRhdGUoeyBcbiAgICAgICAgICAgICAgICBzdGF0dXM6IFwiZmFpbGVkXCIsIFxuICAgICAgICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSBcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLmVxKFwiaWRcIiwgYWRkb24uaWQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICAvLyBOb3RlOiBzdWNjZXNzZnVsIHJlc3VsdF91cmwgdXBkYXRlIGlzIGhhbmRsZWQgYnkgdGhlIGVkZ2UgZnVuY3Rpb24gaXRzZWxmXG4gICAgICAgIH0gY2F0Y2ggKGZuRXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjYWxsaW5nICR7ZnVuY3Rpb25OYW1lfTpgLCBmbkVycm9yKTtcbiAgICAgICAgICBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICAgICAgICBzdGF0dXM6IFwiZmFpbGVkXCIsIFxuICAgICAgICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmVxKFwiaWRcIiwgYWRkb24uaWQpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhgVW5rbm93biBhZGRvbiB0eXBlOiAke2FkZG9uTmFtZX0sIG1hcmtpbmcgYXMgZmFpbGVkYCk7XG4gICAgICAgIGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBcbiAgICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIiwgXG4gICAgICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgXG4gICAgICAgICAgfSlcbiAgICAgICAgICAuZXEoXCJpZFwiLCBhZGRvbi5pZCk7XG4gICAgICB9XG4gICAgfVxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBwcm9jZXNzaW5nIHRyYWNrIGFkZG9uczpcIiwgZXJyb3IpO1xuICB9XG59XG5cbi8vIOKUgOKUgOKUgCBUcmlnZ2VyIFN1bm8gQ292ZXIgR2VuZXJhdGlvbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIEFmdGVyIG11c2ljIGlzIGdlbmVyYXRlZCwgcmVxdWVzdCBwZXJzb25hbGl6ZWQgY292ZXIgYXJ0IHZpYSBTdW5vIENvdmVyIEFQSVxuLy8gRG9jczogaHR0cHM6Ly9kb2NzLnN1bm9hcGkub3JnL3N1bm8tYXBpL2NvdmVyLXN1bm9cbmFzeW5jIGZ1bmN0aW9uIHRyaWdnZXJDb3ZlckdlbmVyYXRpb24oXG4gIHN1cGFiYXNlQWRtaW46IFN1cGFiYXNlQ2xpZW50LFxuICBtdXNpY1Rhc2tJZDogc3RyaW5nLFxuICBtYXRjaGVkVHJhY2tJZHM6IHN0cmluZ1tdXG4pIHtcbiAgdHJ5IHtcbiAgICBjb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG4gICAgY29uc3QgU1VOT19BUElfQkFTRSA9IFwiaHR0cHM6Ly9hcGlib3guZXJ3ZWltYS5haVwiO1xuICAgIGNvbnN0IGNhbGxiYWNrU2VjcmV0ID0gRGVuby5lbnYuZ2V0KFwiU1VOT19DQUxMQkFDS19TRUNSRVRcIik7XG4gICAgY29uc3QgYmFzZVVybCA9IERlbm8uZW52LmdldChcIkJBU0VfVVJMXCIpIHx8IFwiaHR0cHM6Ly9haW11emEucnVcIjtcblxuICAgIGlmICghU1VOT19BUElfS0VZKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiU1VOT19BUElfS0VZIG5vdCBzZXQsIHNraXBwaW5nIGNvdmVyIGdlbmVyYXRpb25cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gQnVpbGQgY292ZXIgY2FsbGJhY2sgVVJMXG4gICAgY29uc3QgY292ZXJDYWxsYmFja1VybCA9IGNhbGxiYWNrU2VjcmV0XG4gICAgICA/IGAke2Jhc2VVcmx9L2Z1bmN0aW9ucy92MS9zdW5vLWNvdmVyLWNhbGxiYWNrP3NlY3JldD0ke2VuY29kZVVSSUNvbXBvbmVudChjYWxsYmFja1NlY3JldCl9YFxuICAgICAgOiBgJHtiYXNlVXJsfS9mdW5jdGlvbnMvdjEvc3Vuby1jb3Zlci1jYWxsYmFja2A7XG5cbiAgICBjb25zb2xlLmxvZyhgVHJpZ2dlcmluZyBTdW5vIGNvdmVyIGdlbmVyYXRpb24gZm9yIG11c2ljIHRhc2sgJHttdXNpY1Rhc2tJZH1gKTtcbiAgICBjb25zb2xlLmxvZyhgQ292ZXIgY2FsbGJhY2sgVVJMOiAke2NvdmVyQ2FsbGJhY2tVcmx9YCk7XG5cbiAgICAvLyBDYWxsIFN1bm8gQ292ZXIgQVBJXG4gICAgLy8gVHJ5IHByaW1hcnkgcGF0aCBmaXJzdCwgdGhlbiBmYWxsYmFja1xuICAgIGNvbnN0IHBhdGhzID0gW1xuICAgICAgXCIvYXBpL3YxL3N1bm8vY292ZXIvZ2VuZXJhdGVcIixcbiAgICAgIFwiL2FwaS92MS9jb3Zlci9nZW5lcmF0ZVwiLFxuICAgIF07XG5cbiAgICBsZXQgY292ZXJSZXNwb25zZSA9IG51bGw7XG4gICAgbGV0IGNvdmVyRGF0YSA9IG51bGw7XG5cbiAgICBmb3IgKGNvbnN0IHBhdGggb2YgcGF0aHMpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke1NVTk9fQVBJX0JBU0V9JHtwYXRofWA7XG4gICAgICAgIGNvbnNvbGUubG9nKGBUcnlpbmcgY292ZXIgQVBJOiAke3VybH1gKTtcblxuICAgICAgICBjb3ZlclJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICB0YXNrSWQ6IG11c2ljVGFza0lkLFxuICAgICAgICAgICAgY2FsbEJhY2tVcmw6IGNvdmVyQ2FsbGJhY2tVcmwsXG4gICAgICAgICAgfSksXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvdmVyRGF0YSA9IGF3YWl0IGNvdmVyUmVzcG9uc2UuanNvbigpO1xuICAgICAgICBjb25zb2xlLmxvZyhgQ292ZXIgQVBJIHJlc3BvbnNlICgke3BhdGh9KTpgLCBKU09OLnN0cmluZ2lmeShjb3ZlckRhdGEpKTtcblxuICAgICAgICAvLyBJZiBub3QgYSA0MDQgKHdyb25nIHBhdGgpLCB3ZSBmb3VuZCB0aGUgcmlnaHQgZW5kcG9pbnRcbiAgICAgICAgaWYgKGNvdmVyUmVzcG9uc2Uuc3RhdHVzICE9PSA0MDQpIGJyZWFrO1xuICAgICAgfSBjYXRjaCAoZmV0Y2hFcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgQ292ZXIgQVBJIGZldGNoIGVycm9yICgke3BhdGh9KTpgLCBmZXRjaEVycik7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKCFjb3ZlckRhdGEgfHwgKGNvdmVyRGF0YS5jb2RlICE9PSAyMDAgJiYgY292ZXJEYXRhLmNvZGUgIT09IDQwMCkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYENvdmVyIEFQSSBmYWlsZWQ6ICR7SlNPTi5zdHJpbmdpZnkoY292ZXJEYXRhKX1gKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBjb2RlIDQwMCA9IGNvdmVyIGFscmVhZHkgZ2VuZXJhdGVkIGZvciB0aGlzIHRhc2sgKHJldHVybnMgZXhpc3RpbmcgdGFza0lkKVxuICAgIGNvbnN0IGNvdmVyVGFza0lkID0gY292ZXJEYXRhLmRhdGE/LnRhc2tJZDtcbiAgICBpZiAoIWNvdmVyVGFza0lkKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiTm8gY292ZXJUYXNrSWQgaW4gcmVzcG9uc2VcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYENvdmVyIGdlbmVyYXRpb24gc3RhcnRlZCwgY292ZXJfdGFza19pZDogJHtjb3ZlclRhc2tJZH1gKTtcblxuICAgIC8vIFN0b3JlIGNvdmVyX3Rhc2tfaWQgaW4gbWF0Y2hlZCB0cmFja3MgZm9yIGNhbGxiYWNrIG1hdGNoaW5nXG4gICAgZm9yIChjb25zdCB0cmFja0lkIG9mIG1hdGNoZWRUcmFja0lkcykge1xuICAgICAgY29uc3QgeyBkYXRhOiB0cmFjayB9ID0gYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAuc2VsZWN0KFwiZGVzY3JpcHRpb25cIilcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZClcbiAgICAgICAgLnNpbmdsZSgpO1xuXG4gICAgICBpZiAodHJhY2spIHtcbiAgICAgICAgLy8gT25seSBhZGQgaWYgbm90IGFscmVhZHkgcHJlc2VudFxuICAgICAgICBpZiAoIXRyYWNrLmRlc2NyaXB0aW9uPy5pbmNsdWRlcyhgW2NvdmVyX3Rhc2tfaWQ6ICR7Y292ZXJUYXNrSWR9XWApKSB7XG4gICAgICAgICAgY29uc3QgbmV3RGVzYyA9IHRyYWNrLmRlc2NyaXB0aW9uXG4gICAgICAgICAgICA/IGAke3RyYWNrLmRlc2NyaXB0aW9ufVxcblxcbltjb3Zlcl90YXNrX2lkOiAke2NvdmVyVGFza0lkfV1gXG4gICAgICAgICAgICA6IGBbY292ZXJfdGFza19pZDogJHtjb3ZlclRhc2tJZH1dYDtcblxuICAgICAgICAgIGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgICAudXBkYXRlKHsgZGVzY3JpcHRpb246IG5ld0Rlc2MgfSlcbiAgICAgICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpO1xuXG4gICAgICAgICAgY29uc29sZS5sb2coYFN0b3JlZCBjb3Zlcl90YXNrX2lkICR7Y292ZXJUYXNrSWR9IGluIHRyYWNrICR7dHJhY2tJZH1gKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIHRyaWdnZXJpbmcgY292ZXIgZ2VuZXJhdGlvbjpcIiwgZXJyKTtcbiAgfVxufVxuXG4vLyBIdW1hbi1yZWFkYWJsZSBlcnJvciBtZXNzYWdlcyBmb3IgU3VubyBlcnJvciBjb2Rlc1xuLy8gT2ZmaWNpYWwgU3VubyBBUEkgZXJyb3IgY29kZXMgcmVmZXJlbmNlOlxuLy8gNDAwIC0gSW52YWxpZCBQYXJhbWV0ZXJzXG4vLyA0MDEgLSBVbmF1dGhvcml6ZWRcbi8vIDQwMyAtIEZvcmJpZGRlbiAobW9kZXJhdGlvbi9jb3B5cmlnaHQpXG4vLyA0MDQgLSBOb3QgRm91bmRcbi8vIDQwNSAtIFJhdGUgTGltaXRlZCAoQVBJIGZyZXF1ZW5jeSlcbi8vIDQxMyAtIENvbnRlbnQgVG9vIExhcmdlIChwcm9tcHQvbHlyaWNzIHRvbyBsb25nKVxuLy8gNDI5IC0gSW5zdWZmaWNpZW50IENyZWRpdHNcbi8vIDQ1NSAtIE1haW50ZW5hbmNlXG4vLyA1MDAvNTAzIC0gU2VydmVyIGVycm9yc1xuZnVuY3Rpb24gZ2V0U3Vub0Vycm9yTWVzc2FnZShjb2RlOiBudW1iZXIsIG9yaWdpbmFsTWVzc2FnZT86IHN0cmluZyk6IHsgc2hvcnQ6IHN0cmluZzsgZnVsbDogc3RyaW5nIH0ge1xuICAvLyBGaXJzdCwgY2hlY2sgZm9yIHNwZWNpZmljIGVycm9yIG1lc3NhZ2UgcGF0dGVybnMgKG1vcmUgYWNjdXJhdGUgdGhhbiBqdXN0IGNvZGUpXG4gIGlmIChvcmlnaW5hbE1lc3NhZ2UpIHtcbiAgICBjb25zdCBsb3dlck1zZyA9IG9yaWdpbmFsTWVzc2FnZS50b0xvd2VyQ2FzZSgpO1xuICAgIFxuICAgIC8vIENvcHlyaWdodC9jb250ZW50IG1hdGNoaW5nIGRldGVjdGlvblxuICAgIGlmIChsb3dlck1zZy5pbmNsdWRlcyhcIm1hdGNoZXMgZXhpc3Rpbmcgd29ya1wiKSB8fCBcbiAgICAgICAgbG93ZXJNc2cuaW5jbHVkZXMoXCJleGlzdGluZyB3b3JrIG9mIGFydFwiKSB8fFxuICAgICAgICBsb3dlck1zZy5pbmNsdWRlcyhcImNvcHlyaWdodFwiKSB8fFxuICAgICAgICBsb3dlck1zZy5pbmNsdWRlcyhcInByb3RlY3RlZCBjb250ZW50XCIpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzaG9ydDogXCLQmtC+0L3RgtC10L3RgiDQt9Cw0YnQuNGJ0ZHQvSDQsNCy0YLQvtGA0YHQutC40Lwg0L/RgNCw0LLQvtC8XCIsXG4gICAgICAgIGZ1bGw6IFwi0JfQsNCz0YDRg9C20LXQvdC90YvQuSDQsNGD0LTQuNC+0YTQsNC50Lsg0LjQu9C4INGC0LXQutGB0YIg0YDQsNGB0L/QvtC30L3QsNC9INC60LDQuiDRgdGD0YnQtdGB0YLQstGD0Y7RidC10LUg0L/RgNC+0LjQt9Cy0LXQtNC10L3QuNC1LiDQodC40YHRgtC10LzQsCDQt9Cw0YnQuNGC0Ysg0LDQstGC0L7RgNGB0LrQuNGFINC/0YDQsNCyIFN1bm8g0LfQsNCx0LvQvtC60LjRgNC+0LLQsNC70LAg0LPQtdC90LXRgNCw0YbQuNGOLiDQn9C+0L/RgNC+0LHRg9C50YLQtSDQuNGB0L/QvtC70YzQt9C+0LLQsNGC0Ywg0L7RgNC40LPQuNC90LDQu9GM0L3Ri9C5INC60L7QvdGC0LXQvdGCLlwiXG4gICAgICB9O1xuICAgIH1cbiAgICBcbiAgICAvLyBNb2RlcmF0aW9uL3NlbnNpdGl2ZSBjb250ZW50XG4gICAgaWYgKGxvd2VyTXNnLmluY2x1ZGVzKFwibW9kZXJhdGlvblwiKSB8fCBcbiAgICAgICAgbG93ZXJNc2cuaW5jbHVkZXMoXCJzZW5zaXRpdmVcIikgfHwgXG4gICAgICAgIGxvd2VyTXNnLmluY2x1ZGVzKFwiaW5hcHByb3ByaWF0ZVwiKSB8fFxuICAgICAgICBsb3dlck1zZy5pbmNsdWRlcyhcInByb2hpYml0ZWRcIikpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHNob3J0OiBcItCa0L7QvdGC0LXQvdGCINC90LUg0L/RgNC+0YjRkdC7INC80L7QtNC10YDQsNGG0LjRjlwiLFxuICAgICAgICBmdWxsOiBcItCi0LXQutGB0YIg0LjQu9C4INC+0L/QuNGB0LDQvdC40LUg0YHQvtC00LXRgNC20LjRgiDQt9Cw0L/RgNC10YnRkdC90L3Ri9C1INGB0LvQvtCy0LAg0LjQu9C4INGE0YDQsNC30YsuINCY0LfQvNC10L3QuNGC0LUg0YHQvtC00LXRgNC20LjQvNC+0LUg0Lgg0L/QvtC/0YDQvtCx0YPQudGC0LUg0YHQvdC+0LLQsC5cIlxuICAgICAgfTtcbiAgICB9XG4gICAgXG4gICAgLy8gQXVkaW8gZmV0Y2ggaXNzdWVzXG4gICAgaWYgKGxvd2VyTXNnLmluY2x1ZGVzKFwiZmV0Y2hcIikgJiYgbG93ZXJNc2cuaW5jbHVkZXMoXCJhdWRpb1wiKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2hvcnQ6IFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQv9C+0LvRg9GH0LjRgtGMINCw0YPQtNC40L7RhNCw0LnQu1wiLFxuICAgICAgICBmdWxsOiBcItCh0LXRgNCy0LXRgCDQvdC1INGB0LzQvtCzINC30LDQs9GA0YPQt9C40YLRjCDQstCw0Ygg0LDRg9C00LjQvtGE0LDQudC7LiDQn9GA0L7QstC10YDRjNGC0LUsINGH0YLQviDRhNCw0LnQuyDQtNC+0YHRgtGD0L/QtdC9INC4INC/0L7Qv9GA0L7QsdGD0LnRgtC1INGB0L3QvtCy0LAuXCJcbiAgICAgIH07XG4gICAgfVxuICAgIFxuICAgIC8vIENvbnRlbnQgdG9vIGxvbmcgKGNhbiBjb21lIGluIG1lc3NhZ2UgdG9vKVxuICAgIGlmIChsb3dlck1zZy5pbmNsdWRlcyhcInRvbyBsb25nXCIpIHx8IGxvd2VyTXNnLmluY2x1ZGVzKFwidG9vIGxhcmdlXCIpIHx8IGxvd2VyTXNnLmluY2x1ZGVzKFwiZXhjZWVkc1wiKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2hvcnQ6IFwi0J/RgNC10LLRi9GI0LXQvSDQu9C40LzQuNGCINGB0LjQvNCy0L7Qu9C+0LJcIixcbiAgICAgICAgZnVsbDogXCLQntC/0LjRgdCw0L3QuNC1LCDRgdGC0LjQu9GMINC40LvQuCDRgtC10LrRgdGCINC/0LXRgdC90Lgg0YHQu9C40YjQutC+0Lwg0LTQu9C40L3QvdGL0LUuINCh0L7QutGA0LDRgtC40YLQtSDRgtC10LrRgdGCINC4INC/0L7Qv9GA0L7QsdGD0LnRgtC1INGB0L3QvtCy0LAuXCJcbiAgICAgIH07XG4gICAgfVxuICAgIFxuICAgIC8vIENyZWRpdHMgaXNzdWVzXG4gICAgaWYgKGxvd2VyTXNnLmluY2x1ZGVzKFwiY3JlZGl0XCIpIHx8IGxvd2VyTXNnLmluY2x1ZGVzKFwiYmFsYW5jZVwiKSB8fCBsb3dlck1zZy5pbmNsdWRlcyhcImluc3VmZmljaWVudFwiKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2hvcnQ6IFwi0J3QtdC00L7RgdGC0LDRgtC+0YfQvdC+INC60YDQtdC00LjRgtC+0LIgU3Vub1wiLFxuICAgICAgICBmdWxsOiBcItCd0LAg0LDQutC60LDRg9C90YLQtSBTdW5vINC90LXQtNC+0YHRgtCw0YLQvtGH0L3QviDQutGA0LXQtNC40YLQvtCyINC00LvRjyDQs9C10L3QtdGA0LDRhtC40LguINCe0LHRgNCw0YLQuNGC0LXRgdGMINCyINC/0L7QtNC00LXRgNC20LrRgy5cIlxuICAgICAgfTtcbiAgICB9XG4gIH1cblxuICAvLyBGYWxsYmFjayB0byBjb2RlLWJhc2VkIG1lc3NhZ2VzXG4gIGNvbnN0IGVycm9yTWVzc2FnZXM6IFJlY29yZDxudW1iZXIsIHsgc2hvcnQ6IHN0cmluZzsgZnVsbDogc3RyaW5nIH0+ID0ge1xuICAgIDQwMDoge1xuICAgICAgc2hvcnQ6IFwi0J3QtdCy0LXRgNC90YvQtSDQv9Cw0YDQsNC80LXRgtGA0Ysg0LfQsNC/0YDQvtGB0LBcIixcbiAgICAgIGZ1bGw6IFwi0J/QsNGA0LDQvNC10YLRgNGLINCz0LXQvdC10YDQsNGG0LjQuCDQvdC10LrQvtGA0YDQtdC60YLQvdGLLiDQn9GA0L7QstC10YDRjNGC0LUg0LLQstC10LTRkdC90L3Ri9C1INC00LDQvdC90YvQtSDQuCDQv9C+0L/RgNC+0LHRg9C50YLQtSDRgdC90L7QstCwLlwiXG4gICAgfSxcbiAgICA0MDE6IHtcbiAgICAgIHNob3J0OiBcItCe0YjQuNCx0LrQsCDQsNCy0YLQvtGA0LjQt9Cw0YbQuNC4XCIsXG4gICAgICBmdWxsOiBcItCf0YDQvtCx0LvQtdC80LAg0YEg0LDQstGC0L7RgNC40LfQsNGG0LjQtdC5INCyINGB0LXRgNCy0LjRgdC1IFN1bm8uINCe0LHRgNCw0YLQuNGC0LXRgdGMINCyINC/0L7QtNC00LXRgNC20LrRgy5cIlxuICAgIH0sXG4gICAgNDAzOiB7XG4gICAgICBzaG9ydDogXCLQmtC+0L3RgtC10L3RgiDQt9Cw0LHQu9C+0LrQuNGA0L7QstCw0L0g0LzQvtC00LXRgNCw0YbQuNC10LlcIixcbiAgICAgIGZ1bGw6IFwi0JLQsNGIINC30LDQv9GA0L7RgSDRgdC+0LTQtdGA0LbQuNGCINC30LDQv9GA0LXRidGR0L3QvdGL0Lkg0LrQvtC90YLQtdC90YIg0LjQu9C4INC90LDRgNGD0YjQsNC10YIg0L/RgNCw0LLQuNC70LAg0LjRgdC/0L7Qu9GM0LfQvtCy0LDQvdC40Y8gU3Vuby4g0JjQt9C80LXQvdC40YLQtSDRgtC10LrRgdGCINC40LvQuCDQvtC/0LjRgdCw0L3QuNC1LlwiXG4gICAgfSxcbiAgICA0MDQ6IHtcbiAgICAgIHNob3J0OiBcItCg0LXRgdGD0YDRgSDQvdC1INC90LDQudC00LXQvVwiLFxuICAgICAgZnVsbDogXCLQl9Cw0L/RgNCw0YjQuNCy0LDQtdC80YvQuSDRgNC10YHRg9GA0YEg0L3QtSDQvdCw0LnQtNC10L0uINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC10YnRkSDRgNCw0LcuXCJcbiAgICB9LFxuICAgIDQwNToge1xuICAgICAgc2hvcnQ6IFwi0J/RgNC10LLRi9GI0LXQvdCwINGH0LDRgdGC0L7RgtCwINC30LDQv9GA0L7RgdC+0LJcIixcbiAgICAgIGZ1bGw6IFwi0KHQu9C40YjQutC+0Lwg0LzQvdC+0LPQviDQt9Cw0L/RgNC+0YHQvtCyINC6IEFQSS4g0J/QvtC00L7QttC00LjRgtC1INC90LXRgdC60L7Qu9GM0LrQviDQvNC40L3Rg9GCINC4INC/0L7Qv9GA0L7QsdGD0LnRgtC1INGB0L3QvtCy0LAuXCJcbiAgICB9LFxuICAgIDQxMzoge1xuICAgICAgc2hvcnQ6IFwi0J/RgNC10LLRi9GI0LXQvSDQu9C40LzQuNGCINGB0LjQvNCy0L7Qu9C+0LJcIixcbiAgICAgIGZ1bGw6IFwi0J7Qv9C40YHQsNC90LjQtSwg0YHRgtC40LvRjCDQuNC70Lgg0YLQtdC60YHRgiDQv9C10YHQvdC4INGB0LvQuNGI0LrQvtC8INC00LvQuNC90L3Ri9C1INC00LvRjyDQvtCx0YDQsNCx0L7RgtC60LguINCh0L7QutGA0LDRgtC40YLQtSDRgtC10LrRgdGCICjQvNCw0LrRgS4gfjMwMDAg0YHQuNC80LLQvtC70L7QsiDQtNC70Y8gbHlyaWNzLCB+MjAwINC00LvRjyBzdHlsZSkg0Lgg0L/QvtC/0YDQvtCx0YPQudGC0LUg0YHQvdC+0LLQsC5cIlxuICAgIH0sXG4gICAgNDI5OiB7XG4gICAgICBzaG9ydDogXCLQndC10LTQvtGB0YLQsNGC0L7Rh9C90L4g0LrRgNC10LTQuNGC0L7QslwiLFxuICAgICAgZnVsbDogXCLQndCwINCw0LrQutCw0YPQvdGC0LUgU3VubyDQvdC10LTQvtGB0YLQsNGC0L7Rh9C90L4g0LrRgNC10LTQuNGC0L7QsiDQtNC70Y8g0LPQtdC90LXRgNCw0YbQuNC4LiDQntCx0YDQsNGC0LjRgtC10YHRjCDQsiDQv9C+0LTQtNC10YDQttC60YMuXCJcbiAgICB9LFxuICAgIDQ1NToge1xuICAgICAgc2hvcnQ6IFwi0KHQtdGA0LLQuNGBINC90LAg0L7QsdGB0LvRg9C20LjQstCw0L3QuNC4XCIsXG4gICAgICBmdWxsOiBcItCh0LXRgNCy0LjRgSBTdW5vINC/0YDQvtGF0L7QtNC40YIg0YLQtdGF0L3QuNGH0LXRgdC60L7QtSDQvtCx0YHQu9GD0LbQuNCy0LDQvdC40LUuINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC/0L7Qt9C20LUuXCJcbiAgICB9LFxuICAgIDUwMDoge1xuICAgICAgc2hvcnQ6IFwi0JLQvdGD0YLRgNC10L3QvdGP0Y8g0L7RiNC40LHQutCwINGB0LXRgNCy0LXRgNCwXCIsXG4gICAgICBmdWxsOiBcItCf0YDQvtC40LfQvtGI0LvQsCDQstC90YPRgtGA0LXQvdC90Y/RjyDQvtGI0LjQsdC60LAg0L3QsCDRgdC10YDQstC10YDQtSBTdW5vLiDQn9C+0L/RgNC+0LHRg9C50YLQtSDQv9C+0LfQttC1LlwiXG4gICAgfSxcbiAgICA1MDM6IHtcbiAgICAgIHNob3J0OiBcItCh0LXRgNCy0LjRgSDQstGA0LXQvNC10L3QvdC+INC90LXQtNC+0YHRgtGD0L/QtdC9XCIsXG4gICAgICBmdWxsOiBcItCh0LXRgNCy0LjRgSBTdW5vINCy0YDQtdC80LXQvdC90L4g0L/QtdGA0LXQs9GA0YPQttC10L0g0LjQu9C4INC90LAg0L7QsdGB0LvRg9C20LjQstCw0L3QuNC4LiDQn9C+0L/RgNC+0LHRg9C50YLQtSDQv9C+0LfQttC1LlwiXG4gICAgfVxuICB9O1xuICBcbiAgaWYgKGVycm9yTWVzc2FnZXNbY29kZV0pIHtcbiAgICByZXR1cm4gZXJyb3JNZXNzYWdlc1tjb2RlXTtcbiAgfVxuICBcbiAgcmV0dXJuIHtcbiAgICBzaG9ydDogYNCe0YjQuNCx0LrQsCDQs9C10L3QtdGA0LDRhtC40LggKNC60L7QtCAke2NvZGV9KWAsXG4gICAgZnVsbDogb3JpZ2luYWxNZXNzYWdlIHx8IGDQn9GA0L7QuNC30L7RiNC70LAg0L7RiNC40LHQutCwINC/0YDQuCDQs9C10L3QtdGA0LDRhtC40LguINCa0L7QtCDQvtGI0LjQsdC60Lg6ICR7Y29kZX0uINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC/0L7Qt9C20LUg0LjQu9C4INC+0LHRgNCw0YLQuNGC0LXRgdGMINCyINC/0L7QtNC00LXRgNC20LrRgy5gXG4gIH07XG59XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICAvLyBWZXJpZnkgY2FsbGJhY2sgYXV0aGVudGljaXR5IHVzaW5nIHNlY3JldCB0b2tlblxuICAgIGNvbnN0IGNhbGxiYWNrU2VjcmV0ID0gRGVuby5lbnYuZ2V0KFwiU1VOT19DQUxMQkFDS19TRUNSRVRcIik7XG4gICAgaWYgKGNhbGxiYWNrU2VjcmV0KSB7XG4gICAgICAvLyBDaGVjayBmb3Igc2VjcmV0IGluIGhlYWRlciBvciBxdWVyeSBwYXJhbWV0ZXJcbiAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmVxLnVybCk7XG4gICAgICBjb25zdCBoZWFkZXJUb2tlbiA9IHJlcS5oZWFkZXJzLmdldChcIngtY2FsbGJhY2stc2VjcmV0XCIpIHx8IHJlcS5oZWFkZXJzLmdldChcImF1dGhvcml6YXRpb25cIik/LnJlcGxhY2UoXCJCZWFyZXIgXCIsIFwiXCIpO1xuICAgICAgY29uc3QgcXVlcnlUb2tlbiA9IHVybC5zZWFyY2hQYXJhbXMuZ2V0KFwic2VjcmV0XCIpO1xuICAgICAgXG4gICAgICBpZiAoaGVhZGVyVG9rZW4gIT09IGNhbGxiYWNrU2VjcmV0ICYmIHF1ZXJ5VG9rZW4gIT09IGNhbGxiYWNrU2VjcmV0KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJJbnZhbGlkIGNhbGxiYWNrIHNlY3JldCBwcm92aWRlZFwiKTtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgY29uc29sZS5sb2coXCJDYWxsYmFjayBzZWNyZXQgdmVyaWZpZWQgc3VjY2Vzc2Z1bGx5XCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLndhcm4oXCJTVU5PX0NBTExCQUNLX1NFQ1JFVCBub3QgY29uZmlndXJlZCAtIGNhbGxiYWNrIHZlcmlmaWNhdGlvbiBza2lwcGVkXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlQWRtaW4gPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgPz8gXCJcIixcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikgPz8gXCJcIlxuICAgICk7XG5cbiAgICBjb25zdCBjYWxsYmFja0RhdGEgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKFwiUmVjZWl2ZWQgU3VubyBjYWxsYmFjazpcIiwgSlNPTi5zdHJpbmdpZnkoY2FsbGJhY2tEYXRhKSk7XG5cbiAgICAvLyBIYW5kbGUgdGhlIG5lc3RlZCBkYXRhIHN0cnVjdHVyZSBmcm9tIFN1bm8gQVBJXG4gICAgLy8gVGhlIHN0cnVjdHVyZSBpczogeyBjb2RlOiAyMDAsIGRhdGE6IHsgY2FsbGJhY2tUeXBlOiBcImNvbXBsZXRlXCIsIGRhdGE6IFsuLi50cmFja3NdLCB0YXNrX2lkOiBcIi4uLlwiIH0sIG1zZzogXCIuLi5cIiB9XG4gICAgY29uc3QgdHJhY2tzID0gY2FsbGJhY2tEYXRhPy5kYXRhPy5kYXRhIHx8IGNhbGxiYWNrRGF0YT8uZGF0YSB8fCBbXTtcbiAgICBjb25zdCB0YXNrSWQgPSBjYWxsYmFja0RhdGE/LmRhdGE/LnRhc2tfaWQ7XG4gICAgY29uc3QgY2FsbGJhY2tUeXBlID0gY2FsbGJhY2tEYXRhPy5kYXRhPy5jYWxsYmFja1R5cGU7XG4gICAgY29uc3QgcmVzcG9uc2VDb2RlID0gY2FsbGJhY2tEYXRhPy5jb2RlO1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGNhbGxiYWNrRGF0YT8ubXNnO1xuICAgIFxuICAgIGNvbnNvbGUubG9nKGBDYWxsYmFjayB0eXBlOiAke2NhbGxiYWNrVHlwZX0sIFRhc2sgSUQ6ICR7dGFza0lkfSwgQ29kZTogJHtyZXNwb25zZUNvZGV9LCBUcmFja3MgY291bnQ6ICR7dHJhY2tzLmxlbmd0aH1gKTtcblxuICAgIC8vIEhhbmRsZSBmYWlsZWQgY2FsbGJhY2tzIC0gY2hlY2sgZm9yIGVycm9yIGNvZGVzIE9SIGV4cGxpY2l0IGZhaWx1cmUgdHlwZXNcbiAgICAvLyBTdW5vIG1heSByZXR1cm4gY29kZSA0MTMgd2l0aCBjYWxsYmFja1R5cGUgXCJjb21wbGV0ZVwiIHdoZW4gYXVkaW8gY2FuJ3QgYmUgZmV0Y2hlZFxuICAgIGNvbnN0IGlzRXJyb3IgPSByZXNwb25zZUNvZGUgIT09IDIwMCB8fCBcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2tUeXBlID09PSBcImZhaWxcIiB8fCBcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2tUeXBlID09PSBcImVycm9yXCIgfHwgXG4gICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrVHlwZSA9PT0gXCJmYWlsZWRcIjtcbiAgICBcbiAgICBpZiAoaXNFcnJvcikge1xuICAgICAgY29uc29sZS5sb2coYFJlY2VpdmVkIGVycm9yIGNhbGxiYWNrIGZvciB0YXNrICR7dGFza0lkfSAtIGNvZGU6ICR7cmVzcG9uc2VDb2RlfSwgdHlwZTogJHtjYWxsYmFja1R5cGV9YCk7XG4gICAgICBcbiAgICAgIC8vIEdldCBodW1hbi1yZWFkYWJsZSBlcnJvciBtZXNzYWdlXG4gICAgICBjb25zdCBlcnJvckluZm8gPSBnZXRTdW5vRXJyb3JNZXNzYWdlKHJlc3BvbnNlQ29kZSB8fCA1MDAsIGVycm9yTWVzc2FnZSB8fCBjYWxsYmFja0RhdGE/LmRhdGE/LmZhaWxfcmVhc29uKTtcbiAgICAgIGNvbnN0IGZhaWxSZWFzb24gPSBlcnJvckluZm8uc2hvcnQ7XG4gICAgICBcbiAgICAgIC8vIEZpbmQgdHJhY2tzIHRoYXQgbWF0Y2ggdGhpcyB0YXNrX2lkIGZpcnN0LCB0aGVuIGZhbGwgYmFjayB0byByZWNlbnQgcGVuZGluZyB0cmFja3NcbiAgICAgIGxldCB0cmFja3NUb0ZhaWw6IHsgaWQ6IHN0cmluZzsgdXNlcl9pZDogc3RyaW5nIH1bXSA9IFtdO1xuICAgICAgXG4gICAgICAvLyBUcnkgdG8gZmluZCB0cmFja3MgYnkgdGFza0lkIGluIGRlc2NyaXB0aW9uIG1ldGFkYXRhXG4gICAgICBpZiAodGFza0lkKSB7XG4gICAgICAgIGNvbnN0IHsgZGF0YTogdGFza1RyYWNrcyB9ID0gYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgLnNlbGVjdChcImlkLCB1c2VyX2lkLCBkZXNjcmlwdGlvblwiKVxuICAgICAgICAgIC5pbihcInN0YXR1c1wiLCBbXCJwcm9jZXNzaW5nXCIsIFwicGVuZGluZ1wiXSlcbiAgICAgICAgICAuaWxpa2UoXCJkZXNjcmlwdGlvblwiLCBgJSR7dGFza0lkfSVgKVxuICAgICAgICAgIC5saW1pdCgyKTtcbiAgICAgICAgXG4gICAgICAgIGlmICh0YXNrVHJhY2tzICYmIHRhc2tUcmFja3MubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHRyYWNrc1RvRmFpbCA9IHRhc2tUcmFja3M7XG4gICAgICAgICAgY29uc29sZS5sb2coYEZvdW5kICR7dGFza1RyYWNrcy5sZW5ndGh9IHRyYWNrcyBtYXRjaGluZyB0YXNrX2lkICR7dGFza0lkfWApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIEZhbGwgYmFjayB0byByZWNlbnQgcGVuZGluZyB0cmFja3MgaWYgbm8gdGFzayBtYXRjaFxuICAgICAgaWYgKHRyYWNrc1RvRmFpbC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc3QgeyBkYXRhOiBwZW5kaW5nVHJhY2tzIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAuc2VsZWN0KFwiaWQsIHVzZXJfaWRcIilcbiAgICAgICAgICAuaW4oXCJzdGF0dXNcIiwgW1wicHJvY2Vzc2luZ1wiLCBcInBlbmRpbmdcIl0pXG4gICAgICAgICAgLm9yZGVyKFwiY3JlYXRlZF9hdFwiLCB7IGFzY2VuZGluZzogZmFsc2UgfSlcbiAgICAgICAgICAubGltaXQoNSk7XG4gICAgICBcbiAgICAgICAgaWYgKHBlbmRpbmdUcmFja3MgJiYgcGVuZGluZ1RyYWNrcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgdHJhY2tzVG9GYWlsID0gcGVuZGluZ1RyYWNrcztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgXG4gICAgICBpZiAodHJhY2tzVG9GYWlsLmxlbmd0aCA+IDApIHtcbiAgICAgICAgZm9yIChjb25zdCB0cmFjayBvZiB0cmFja3NUb0ZhaWwpIHtcbiAgICAgICAgICBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgICAgICAgZXJyb3JfbWVzc2FnZTogZmFpbFJlYXNvbixcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuZXEoXCJpZFwiLCB0cmFjay5pZCk7XG4gICAgICAgICAgXG4gICAgICAgICAgLy8gR2V0IGdlbmVyYXRpb24gbG9nIHRvIGZpbmQgY29zdFxuICAgICAgICAgIGNvbnN0IHsgZGF0YTogZ2VuTG9nIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgICAuZnJvbShcImdlbmVyYXRpb25fbG9nc1wiKVxuICAgICAgICAgICAgLnNlbGVjdChcImNvc3RfcnViXCIpXG4gICAgICAgICAgICAuZXEoXCJ0cmFja19pZFwiLCB0cmFjay5pZClcbiAgICAgICAgICAgIC5zaW5nbGUoKTtcbiAgICAgICAgICBcbiAgICAgICAgICAvLyBSZWZ1bmQg4oK9IHRvIHVzZXJcbiAgICAgICAgICBpZiAoZ2VuTG9nICYmIGdlbkxvZy5jb3N0X3J1YiA+IDApIHtcbiAgICAgICAgICAgIGNvbnN0IHsgZGF0YTogcHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdHJhY2sudXNlcl9pZClcbiAgICAgICAgICAgICAgLnNpbmdsZSgpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBpZiAocHJvZmlsZSkge1xuICAgICAgICAgICAgICBjb25zdCBuZXdCYWxhbmNlID0gKHByb2ZpbGUuYmFsYW5jZSB8fCAwKSArIGdlbkxvZy5jb3N0X3J1YjtcbiAgICAgICAgICAgICAgYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogbmV3QmFsYW5jZSB9KVxuICAgICAgICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdHJhY2sudXNlcl9pZCk7XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAvLyBMb2cgcmVmdW5kIHRyYW5zYWN0aW9uXG4gICAgICAgICAgICAgIGF3YWl0IHN1cGFiYXNlQWRtaW4uZnJvbShcImJhbGFuY2VfdHJhbnNhY3Rpb25zXCIpLmluc2VydCh7XG4gICAgICAgICAgICAgICAgdXNlcl9pZDogdHJhY2sudXNlcl9pZCxcbiAgICAgICAgICAgICAgICBhbW91bnQ6IGdlbkxvZy5jb3N0X3J1YixcbiAgICAgICAgICAgICAgICBiYWxhbmNlX2FmdGVyOiBuZXdCYWxhbmNlLFxuICAgICAgICAgICAgICAgIHR5cGU6IFwicmVmdW5kXCIsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGDQktC+0LfQstGA0LDRgiDQt9CwINCz0LXQvdC10YDQsNGG0LjRjjogJHtmYWlsUmVhc29ufWAsXG4gICAgICAgICAgICAgICAgcmVmZXJlbmNlX2lkOiB0cmFjay5pZCxcbiAgICAgICAgICAgICAgICByZWZlcmVuY2VfdHlwZTogXCJ0cmFja1wiLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBSZWZ1bmRlZCAke2dlbkxvZy5jb3N0X3J1Yn0g4oK9IHRvIHVzZXIgJHt0cmFjay51c2VyX2lkfWApO1xuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgLy8gQ3JlYXRlIG5vdGlmaWNhdGlvbiBmb3IgcmVmdW5kIHdpdGggZXJyb3IgZXhwbGFuYXRpb25cbiAgICAgICAgICAgICAgYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAgICAgICAgIC5mcm9tKFwibm90aWZpY2F0aW9uc1wiKVxuICAgICAgICAgICAgICAgIC5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgdXNlcl9pZDogdHJhY2sudXNlcl9pZCxcbiAgICAgICAgICAgICAgICAgIHR5cGU6IFwicmVmdW5kXCIsXG4gICAgICAgICAgICAgICAgICB0aXRsZTogYNCe0YjQuNCx0LrQsDogJHtmYWlsUmVhc29ufWAsXG4gICAgICAgICAgICAgICAgICBtZXNzYWdlOiBgJHtlcnJvckluZm8uZnVsbH1cXG5cXG7QktCw0Lwg0LLQvtC30LLRgNCw0YnQtdC90L4gJHtnZW5Mb2cuY29zdF9ydWJ9IOKCvWAsXG4gICAgICAgICAgICAgICAgICB0YXJnZXRfdHlwZTogXCJ0cmFja1wiLFxuICAgICAgICAgICAgICAgICAgdGFyZ2V0X2lkOiB0cmFjay5pZCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgXG4gICAgICAgICAgLy8gVXBkYXRlIGdlbmVyYXRpb24gbG9nIHN0YXR1cyB0byBmYWlsZWRcbiAgICAgICAgICBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgICAuZnJvbShcImdlbmVyYXRpb25fbG9nc1wiKVxuICAgICAgICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJmYWlsZWRcIiB9KVxuICAgICAgICAgICAgLmVxKFwidHJhY2tfaWRcIiwgdHJhY2suaWQpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnNvbGUubG9nKGBNYXJrZWQgJHt0cmFja3NUb0ZhaWwubGVuZ3RofSB0cmFja3MgYXMgZmFpbGVkIHdpdGggcmVmdW5kc2ApO1xuICAgICAgfVxuICAgICAgXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHJlY2VpdmVkOiB0cnVlLCBtZXNzYWdlOiBcIkZhaWx1cmUgY2FsbGJhY2sgcHJvY2Vzc2VkIHdpdGggcmVmdW5kc1wiIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAoIUFycmF5LmlzQXJyYXkodHJhY2tzKSB8fCB0cmFja3MubGVuZ3RoID09PSAwKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIk5vIHRyYWNrcyBpbiBjYWxsYmFjayBkYXRhXCIpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyByZWNlaXZlZDogdHJ1ZSwgbWVzc2FnZTogXCJObyB0cmFja3MgdG8gcHJvY2Vzc1wiIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBQcm9jZXNzIFwiY29tcGxldGVcIiAoYWxsIHRyYWNrcyByZWFkeSkgYW5kIFwiZmlyc3RcIiAoZmlyc3QgdHJhY2sgcmVhZHkpIGNhbGxiYWNrc1xuICAgIC8vIFNraXAgXCJ0ZXh0XCIgY2FsbGJhY2tzIChvbmx5IGx5cmljcyBnZW5lcmF0ZWQsIG5vIGF1ZGlvIHlldClcbiAgICBpZiAoY2FsbGJhY2tUeXBlICE9PSBcImNvbXBsZXRlXCIgJiYgY2FsbGJhY2tUeXBlICE9PSBcImZpcnN0XCIpIHtcbiAgICAgIGNvbnNvbGUubG9nKGBTa2lwcGluZyBjYWxsYmFjayB0eXBlOiAke2NhbGxiYWNrVHlwZX0gKHdhaXRpbmcgZm9yIGF1ZGlvKWApO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyByZWNlaXZlZDogdHJ1ZSwgbWVzc2FnZTogYENhbGxiYWNrIHR5cGUgJHtjYWxsYmFja1R5cGV9IGFja25vd2xlZGdlZGAgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cbiAgICBcbiAgICBjb25zdCBpc1BhcnRpYWxDYWxsYmFjayA9IGNhbGxiYWNrVHlwZSA9PT0gXCJmaXJzdFwiO1xuICAgIGlmIChpc1BhcnRpYWxDYWxsYmFjaykge1xuICAgICAgY29uc29sZS5sb2coYFByb2Nlc3NpbmcgcGFydGlhbCBjYWxsYmFjayAoZmlyc3QpIOKAlCB3aWxsIG9ubHkgdXBkYXRlIHRyYWNrcyB0aGF0IGhhdmUgYXVkaW9fdXJsYCk7XG4gICAgfVxuXG4gICAgLy8gQ1JJVElDQUw6IEZpcnN0LCBmaW5kIHRyYWNrcyB0aGF0IG1hdGNoIHRoaXMgc3BlY2lmaWMgdGFza19pZFxuICAgIC8vIFRoaXMgcHJldmVudHMgY3Jvc3MtdXNlciB0cmFjayBtaXhpbmcgd2hlbiBtdWx0aXBsZSBnZW5lcmF0aW9ucyBhcmUgcGVuZGluZ1xuICAgIGxldCBtYXRjaGVkVHJhY2tzOiBBcnJheTx7XG4gICAgICBpZDogc3RyaW5nO1xuICAgICAgdGl0bGU6IHN0cmluZyB8IG51bGw7XG4gICAgICBkZXNjcmlwdGlvbjogc3RyaW5nIHwgbnVsbDtcbiAgICAgIGx5cmljczogc3RyaW5nIHwgbnVsbDtcbiAgICAgIHVzZXJfaWQ6IHN0cmluZztcbiAgICAgIHN0YXR1czogc3RyaW5nO1xuICAgIH0+ID0gW107XG5cbiAgICBpZiAodGFza0lkKSB7XG4gICAgICBjb25zdCB7IGRhdGE6IHRhc2tUcmFja3MsIGVycm9yOiB0YXNrRmluZEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgIC5zZWxlY3QoXCJpZCwgdGl0bGUsIGRlc2NyaXB0aW9uLCBseXJpY3MsIHVzZXJfaWQsIHN0YXR1c1wiKVxuICAgICAgICAuaW4oXCJzdGF0dXNcIiwgW1wicHJvY2Vzc2luZ1wiLCBcInBlbmRpbmdcIl0pXG4gICAgICAgIC5pbGlrZShcImRlc2NyaXB0aW9uXCIsIGAlW3Rhc2tfaWQ6ICR7dGFza0lkfV0lYClcbiAgICAgICAgLm9yZGVyKFwiY3JlYXRlZF9hdFwiLCB7IGFzY2VuZGluZzogdHJ1ZSB9KVxuICAgICAgICAubGltaXQoMik7XG5cbiAgICAgIGlmICh0YXNrRmluZEVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmaW5kaW5nIHRyYWNrcyBieSB0YXNrX2lkOlwiLCB0YXNrRmluZEVycm9yKTtcbiAgICAgIH0gZWxzZSBpZiAodGFza1RyYWNrcyAmJiB0YXNrVHJhY2tzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgbWF0Y2hlZFRyYWNrcyA9IHRhc2tUcmFja3M7XG4gICAgICAgIGNvbnNvbGUubG9nKGBGb3VuZCAke3Rhc2tUcmFja3MubGVuZ3RofSB0cmFja3MgbWF0Y2hpbmcgdGFza19pZCAke3Rhc2tJZH1gKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBJZiBubyB0YXNrX2lkIG1hdGNoLCBsb2cgYSB3YXJuaW5nIGJ1dCBETyBOT1QgZmFsbCBiYWNrIHRvIHJhbmRvbSBwZW5kaW5nIHRyYWNrc1xuICAgIC8vIFRoaXMgaXMgY3JpdGljYWwgdG8gcHJldmVudCBjcm9zcy11c2VyIHRyYWNrIG1peGluZ1xuICAgIGlmIChtYXRjaGVkVHJhY2tzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgY29uc29sZS53YXJuKGBObyB0cmFja3MgZm91bmQgbWF0Y2hpbmcgdGFza19pZCAke3Rhc2tJZH0uIENhbGxiYWNrIHdpbGwgYmUgaWdub3JlZCB0byBwcmV2ZW50IGNyb3NzLXVzZXIgbWl4aW5nLmApO1xuICAgICAgY29uc29sZS53YXJuKGBDYWxsYmFjayBkYXRhIGhhZCAke3RyYWNrcy5sZW5ndGh9IGF1ZGlvIHRyYWNrcywgYnV0IG5vIG1hdGNoaW5nIERCIHJlY29yZHMuYCk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHJlY2VpdmVkOiB0cnVlLCBcbiAgICAgICAgICB3YXJuaW5nOiBcIk5vIG1hdGNoaW5nIHRyYWNrcyBmb3VuZCBmb3IgdGFza19pZFwiLCBcbiAgICAgICAgICB0YXNrX2lkOiB0YXNrSWQgXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBsZXQgdXBkYXRlZENvdW50ID0gMDtcblxuICAgIC8vIENyZWF0ZSBhIGNvcHkgb2YgbWF0Y2hlZCB0cmFja3MgZm9yIHNhZmUgaXRlcmF0aW9uIChhdm9pZCBtdXRhdGlvbiBpc3N1ZXMpXG4gICAgY29uc3QgdHJhY2tzVG9Qcm9jZXNzID0gWy4uLm1hdGNoZWRUcmFja3NdO1xuICAgIC8vIFRyYWNrIHdoaWNoIGluZGljZXMgaGF2ZSBiZWVuIHByb2Nlc3NlZFxuICAgIGNvbnN0IHByb2Nlc3NlZEluZGljZXMgPSBuZXcgU2V0PG51bWJlcj4oKTtcblxuICAgIC8vIFN1bm8gcmV0dXJucyAyIHZlcnNpb25zIHBlciBnZW5lcmF0aW9uIHJlcXVlc3RcbiAgICAvLyBNYXRjaCB0aGVtIHRvIG91ciB2MS92MiB0cmFjayBwYWlycyBieSBvcmRlciAoZmlyc3QgU3VubyByZXN1bHQgLT4gdjEsIHNlY29uZCAtPiB2MilcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRyYWNrcy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgdHJhY2sgPSB0cmFja3NbaV07XG4gICAgICBjb25zdCB7IFxuICAgICAgICBpZDogc3Vub0F1ZGlvSWQsXG4gICAgICAgIGF1ZGlvX3VybCwgXG4gICAgICAgIHNvdXJjZV9hdWRpb191cmwsXG4gICAgICAgIHN0cmVhbV9hdWRpb191cmwsXG4gICAgICAgIGltYWdlX3VybCxcbiAgICAgICAgc291cmNlX2ltYWdlX3VybCxcbiAgICAgICAgZHVyYXRpb24sIFxuICAgICAgICB0aXRsZTogc3Vub1RpdGxlLFxuICAgICAgfSA9IHRyYWNrO1xuXG4gICAgICBjb25zdCBhdWRpb1VybCA9IGF1ZGlvX3VybCB8fCBzb3VyY2VfYXVkaW9fdXJsIHx8IHN0cmVhbV9hdWRpb191cmw7XG4gICAgICBjb25zdCBjb3ZlclVybCA9IGltYWdlX3VybCB8fCBzb3VyY2VfaW1hZ2VfdXJsO1xuICAgICAgXG4gICAgICBpZiAoIWF1ZGlvVXJsKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiVHJhY2sgaGFzIG5vIGF1ZGlvIFVSTCwgc2tpcHBpbmdcIik7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICAvLyBNYXRjaCBieSBpbmRleDogZmlyc3QgU3VubyByZXN1bHQgLT4gZmlyc3QgbWF0Y2hlZCB0cmFjayAodjEpLCBzZWNvbmQgLT4gc2Vjb25kICh2MilcbiAgICAgIC8vIFVzZSB0aGUgb3JpZ2luYWwgYXJyYXkgY29weSwgbm90IHRoZSBtdXRhdGVkIG9uZVxuICAgICAgY29uc3QgdHJhY2tUb1VwZGF0ZSA9IHRyYWNrc1RvUHJvY2Vzc1tpXTtcbiAgICAgIFxuICAgICAgLy8gU2FmZXR5IGNoZWNrOiBlbnN1cmUgd2UncmUgdXBkYXRpbmcgdGhlIHJpZ2h0IHVzZXIncyB0cmFja1xuICAgICAgaWYgKCF0cmFja1RvVXBkYXRlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBObyBtYXRjaGVkIHRyYWNrIGF0IGluZGV4ICR7aX0gZm9yIFN1bm8gcmVzdWx0OiAke3N1bm9UaXRsZX1gKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIFNraXAgaWYgYWxyZWFkeSBwcm9jZXNzZWQgKHNob3VsZG4ndCBoYXBwZW4sIGJ1dCBiZSBzYWZlKVxuICAgICAgaWYgKHByb2Nlc3NlZEluZGljZXMuaGFzKGkpKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBUcmFjayBhdCBpbmRleCAke2l9IGFscmVhZHkgcHJvY2Vzc2VkLCBza2lwcGluZ2ApO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgcHJvY2Vzc2VkSW5kaWNlcy5hZGQoaSk7XG4gICAgICBjb25zb2xlLmxvZyhgVXBkYXRpbmcgdHJhY2sgJHt0cmFja1RvVXBkYXRlLmlkfSAoJHt0cmFja1RvVXBkYXRlLnRpdGxlfSkgd2l0aCBhdWRpbzogJHthdWRpb1VybH1gKTtcbiAgICAgIFxuICAgICAgLy8gQ29weSBmaWxlcyB0byBTdXBhYmFzZSBTdG9yYWdlIGZvciBwZXJtYW5lbnQgc3RvcmFnZVxuICAgICAgbGV0IGZpbmFsQXVkaW9VcmwgPSBhdWRpb1VybDtcbiAgICAgIGxldCBmaW5hbENvdmVyVXJsID0gY292ZXJVcmw7XG4gICAgICBcbiAgICAgIC8vIENvcHkgYXVkaW8gZmlsZSB0byBTdG9yYWdlXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBhdWRpb0ZpbGVOYW1lID0gYCR7dHJhY2tUb1VwZGF0ZS5pZH0ubXAzYDtcbiAgICAgICAgY29uc3Qgc3RvcmVkQXVkaW9VcmwgPSBhd2FpdCBjb3B5RmlsZVRvU3RvcmFnZShcbiAgICAgICAgICBzdXBhYmFzZUFkbWluLFxuICAgICAgICAgIGF1ZGlvVXJsLFxuICAgICAgICAgIFwidHJhY2tzXCIsXG4gICAgICAgICAgYGF1ZGlvLyR7YXVkaW9GaWxlTmFtZX1gXG4gICAgICAgICk7XG4gICAgICAgIGlmIChzdG9yZWRBdWRpb1VybCkge1xuICAgICAgICAgIGZpbmFsQXVkaW9VcmwgPSBzdG9yZWRBdWRpb1VybDtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgQXVkaW8gY29waWVkIHRvIHN0b3JhZ2U6ICR7ZmluYWxBdWRpb1VybH1gKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgRmFpbGVkIHRvIGNvcHkgYXVkaW8sIHVzaW5nIG9yaWdpbmFsIFVSTGApO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChhdWRpb0Vycikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjb3B5aW5nIGF1ZGlvOmAsIGF1ZGlvRXJyKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgLy8gQ29weSBjb3ZlciBpbWFnZSB0byBTdG9yYWdlXG4gICAgICBpZiAoY292ZXJVcmwpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBjb3ZlckZpbGVOYW1lID0gYCR7dHJhY2tUb1VwZGF0ZS5pZH0uanBnYDtcbiAgICAgICAgICBjb25zdCBzdG9yZWRDb3ZlclVybCA9IGF3YWl0IGNvcHlGaWxlVG9TdG9yYWdlKFxuICAgICAgICAgICAgc3VwYWJhc2VBZG1pbixcbiAgICAgICAgICAgIGNvdmVyVXJsLFxuICAgICAgICAgICAgXCJ0cmFja3NcIixcbiAgICAgICAgICAgIGBjb3ZlcnMvJHtjb3ZlckZpbGVOYW1lfWBcbiAgICAgICAgICApO1xuICAgICAgICAgIGlmIChzdG9yZWRDb3ZlclVybCkge1xuICAgICAgICAgICAgZmluYWxDb3ZlclVybCA9IHN0b3JlZENvdmVyVXJsO1xuICAgICAgICAgICAgY29uc29sZS5sb2coYENvdmVyIGNvcGllZCB0byBzdG9yYWdlOiAke2ZpbmFsQ292ZXJVcmx9YCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBGYWlsZWQgdG8gY29weSBjb3ZlciwgdXNpbmcgb3JpZ2luYWwgVVJMYCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChjb3ZlckVycikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNvcHlpbmcgY292ZXI6YCwgY292ZXJFcnIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBcbiAgICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgIGF1ZGlvX3VybDogZmluYWxBdWRpb1VybCxcbiAgICAgICAgICBjb3Zlcl91cmw6IGZpbmFsQ292ZXJVcmwgfHwgbnVsbCxcbiAgICAgICAgICBkdXJhdGlvbjogZHVyYXRpb24gPyBNYXRoLnJvdW5kKGR1cmF0aW9uKSA6IG51bGwsXG4gICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgIC8vIFN0b3JlIFN1bm8gYXVkaW8gSUQgZm9yIHBlcnNvbmEgY3JlYXRpb25cbiAgICAgICAgICBzdW5vX2F1ZGlvX2lkOiBzdW5vQXVkaW9JZCB8fCBudWxsLFxuICAgICAgICAgIC8vIFN0b3JlIHN1bm9fdGFza19pZCBpbiBkZXNjcmlwdGlvbiBmb3IgcmVmZXJlbmNlIChhcHBlbmQgdG8gZXhpc3RpbmcpXG4gICAgICAgICAgZGVzY3JpcHRpb246IHRyYWNrVG9VcGRhdGUuZGVzY3JpcHRpb24gXG4gICAgICAgICAgICA/IGAke3RyYWNrVG9VcGRhdGUuZGVzY3JpcHRpb259XFxuXFxuW3Rhc2tfaWQ6ICR7dGFza0lkfV1gXG4gICAgICAgICAgICA6IGBbdGFza19pZDogJHt0YXNrSWR9XWAsXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHRyYWNrVG9VcGRhdGUuaWQpO1xuXG4gICAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHRyYWNrOlwiLCB1cGRhdGVFcnJvcik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhgVHJhY2sgJHt0cmFja1RvVXBkYXRlLmlkfSB1cGRhdGVkIHN1Y2Nlc3NmdWxseSB3aXRoIFN0b3JhZ2UgVVJMc2ApO1xuICAgICAgICB1cGRhdGVkQ291bnQrKztcblxuICAgICAgICAvLyBVcGRhdGUgZ2VuZXJhdGlvbiBsb2cgc3RhdHVzXG4gICAgICAgIGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgICAuZnJvbShcImdlbmVyYXRpb25fbG9nc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwiY29tcGxldGVkXCIgfSlcbiAgICAgICAgICAuZXEoXCJ0cmFja19pZFwiLCB0cmFja1RvVXBkYXRlLmlkKTtcblxuXG4gICAgICAgIC8vIFByb2Nlc3MgYWRkb24gc2VydmljZXMgZm9yIHRoaXMgdHJhY2sgKHBhc3MgdGFza0lkIGFuZCBhdWRpb0lkIGZvciBTdW5vIHZpZGVvIGdlbmVyYXRpb24pXG4gICAgICAgIGF3YWl0IHByb2Nlc3NUcmFja0FkZG9ucyhzdXBhYmFzZUFkbWluLCB0cmFja1RvVXBkYXRlLmlkLCB0cmFja1RvVXBkYXRlLnRpdGxlIHx8IFwiVW50aXRsZWRcIiwgZmluYWxDb3ZlclVybCwgZmluYWxBdWRpb1VybCwgdGFza0lkLCBzdW5vQXVkaW9JZCk7XG5cbiAgICAgICAgLy8gQUkgQ2xhc3NpZmljYXRpb24gLSBydW4gaW4gYmFja2dyb3VuZCB0byBub3QgYmxvY2sgcmVzcG9uc2VcbiAgICAgICAgLy8gRXh0cmFjdCBzdHlsZSBmcm9tIHRyYWNrIGRlc2NyaXB0aW9uIChiZWZvcmUgdGFza19pZCB3YXMgYXBwZW5kZWQpXG4gICAgICAgIGNvbnN0IG9yaWdpbmFsRGVzY3JpcHRpb24gPSB0cmFja1RvVXBkYXRlLmRlc2NyaXB0aW9uPy5yZXBsYWNlKC9cXG5cXG5cXFt0YXNrX2lkOi4qXFxdJC8sIFwiXCIpIHx8IG51bGw7XG4gICAgICAgIGNvbnN0IHRyYWNrTHlyaWNzID0gdHJhY2tUb1VwZGF0ZS5seXJpY3MgfHwgbnVsbDtcbiAgICAgICAgXG4gICAgICAgIHJ1bkluQmFja2dyb3VuZChcbiAgICAgICAgICBgY2xhc3NpZnlUcmFjay0ke3RyYWNrVG9VcGRhdGUuaWR9YCxcbiAgICAgICAgICBjbGFzc2lmeVRyYWNrV2l0aEFJKHN1cGFiYXNlQWRtaW4sIHRyYWNrVG9VcGRhdGUuaWQsIG9yaWdpbmFsRGVzY3JpcHRpb24sIHRyYWNrTHlyaWNzKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIOKUgOKUgOKUgCBUcmlnZ2VyIFN1bm8gQ292ZXIgR2VuZXJhdGlvbiAoYmFja2dyb3VuZCkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgLy8gQWZ0ZXIgYWxsIG11c2ljIHRyYWNrcyBhcmUgdXBkYXRlZCwgcmVxdWVzdCBwZXJzb25hbGl6ZWQgY292ZXIgYXJ0XG4gICAgLy8gVGhpcyBydW5zIGluIGJhY2tncm91bmQgc28gd2UgZG9uJ3QgZGVsYXkgdGhlIGNhbGxiYWNrIHJlc3BvbnNlXG4gICAgLy8gT25seSB0cmlnZ2VyIG9uIFwiY29tcGxldGVcIiBjYWxsYmFjayAobm90IFwiZmlyc3RcIikgdG8gYXZvaWQgcHJlbWF0dXJlIGNvdmVyIGdlbmVyYXRpb25cbiAgICBpZiAodXBkYXRlZENvdW50ID4gMCAmJiB0YXNrSWQgJiYgIWlzUGFydGlhbENhbGxiYWNrKSB7XG4gICAgICBjb25zdCB0cmFja0lkc0ZvckNvdmVyID0gdHJhY2tzVG9Qcm9jZXNzXG4gICAgICAgIC5maWx0ZXIodCA9PiBwcm9jZXNzZWRJbmRpY2VzLmhhcyh0cmFja3NUb1Byb2Nlc3MuaW5kZXhPZih0KSkpXG4gICAgICAgIC5tYXAodCA9PiB0LmlkKTtcblxuICAgICAgaWYgKHRyYWNrSWRzRm9yQ292ZXIubGVuZ3RoID4gMCkge1xuICAgICAgICBydW5JbkJhY2tncm91bmQoXG4gICAgICAgICAgYGNvdmVyR2VuZXJhdGlvbi0ke3Rhc2tJZH1gLFxuICAgICAgICAgIHRyaWdnZXJDb3ZlckdlbmVyYXRpb24oc3VwYWJhc2VBZG1pbiwgdGFza0lkLCB0cmFja0lkc0ZvckNvdmVyKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IHRydWUsIHVwZGF0ZWQ6IHVwZGF0ZWRDb3VudCB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBzdW5vLWNhbGxiYWNrOlwiLCBlcnJvcik7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogZXJyb3JNZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxLQUFLLFFBQVEsK0NBQStDO0FBQ3JFLFNBQVMsWUFBWSxRQUF3Qix5Q0FBeUM7QUFFdEYsbURBQW1EO0FBQ25ELCtEQUErRDtBQUMvRCxTQUFTLGdCQUFnQixRQUFnQixFQUFFLE9BQXlCO0VBQ2xFLFFBQVEsS0FBSyxDQUFDLENBQUEsTUFBTyxRQUFRLEtBQUssQ0FBQyxDQUFDLGFBQWEsRUFBRSxTQUFTLFFBQVEsQ0FBQyxFQUFFO0FBQ3pFO0FBRUEsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxrRUFBa0U7QUFDbEUsZUFBZSxrQkFDYixhQUE2QixFQUM3QixXQUFtQixFQUNuQixNQUFjLEVBQ2QsUUFBZ0I7RUFFaEIsSUFBSTtJQUNGLFFBQVEsR0FBRyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsWUFBWSxDQUFDO0lBRW5ELE1BQU0sV0FBVyxNQUFNLE1BQU07SUFDN0IsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLFFBQVEsS0FBSyxDQUFDLENBQUMsb0JBQW9CLEVBQUUsU0FBUyxNQUFNLENBQUMsQ0FBQyxFQUFFLFNBQVMsVUFBVSxDQUFDLENBQUM7TUFDN0UsT0FBTztJQUNUO0lBRUEsTUFBTSxPQUFPLE1BQU0sU0FBUyxJQUFJO0lBQ2hDLE1BQU0sY0FBYyxNQUFNLEtBQUssV0FBVztJQUMxQyxNQUFNLGFBQWEsSUFBSSxXQUFXO0lBRWxDLFFBQVEsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLFdBQVcsTUFBTSxDQUFDLHFCQUFxQixFQUFFLE9BQU8sQ0FBQyxFQUFFLFNBQVMsQ0FBQztJQUV2RixNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLGNBQWMsT0FBTyxDQUN2RCxJQUFJLENBQUMsUUFDTCxNQUFNLENBQUMsVUFBVSxZQUFZO01BQzVCLGFBQWEsS0FBSyxJQUFJLElBQUk7TUFDMUIsUUFBUTtJQUNWO0lBRUYsSUFBSSxhQUFhO01BQ2YsUUFBUSxLQUFLLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRTtNQUMvQixPQUFPO0lBQ1Q7SUFFQSx1RkFBdUY7SUFDdkYsTUFBTSxVQUFVLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxlQUFlO0lBQzVDLE1BQU0sWUFBWSxDQUFDLEVBQUUsUUFBUSwwQkFBMEIsRUFBRSxPQUFPLENBQUMsRUFBRSxTQUFTLENBQUM7SUFFN0UsUUFBUSxHQUFHLENBQUMsQ0FBQyw0QkFBNEIsRUFBRSxVQUFVLENBQUM7SUFDdEQsT0FBTztFQUVULEVBQUUsT0FBTyxLQUFLO0lBQ1osUUFBUSxLQUFLLENBQUMsQ0FBQyw4QkFBOEIsQ0FBQyxFQUFFO0lBQ2hELE9BQU87RUFDVDtBQUNGO0FBRUEsd0RBQXdEO0FBQ3hELE1BQU0sMEJBQTBCO0FBRWhDLG9GQUFvRjtBQUNwRixpQ0FBaUM7QUFDakMsZUFBZSxvQkFDYixhQUE2QixFQUM3QixPQUFlLEVBQ2YsS0FBb0IsRUFDcEIsTUFBcUI7RUFFckIsSUFBSTtJQUNGLFFBQVEsR0FBRyxDQUFDLENBQUMscUNBQXFDLEVBQUUsUUFBUSxDQUFDO0lBRTdELE1BQU0sZ0JBQWdCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsZUFBZTtNQUNsQixRQUFRLEtBQUssQ0FBQztNQUNkO0lBQ0Y7SUFFQSw0Q0FBNEM7SUFDNUMsTUFBTSxDQUFDLFdBQVcsZUFBZSxjQUFjLGdCQUFnQixHQUFHLE1BQU0sUUFBUSxHQUFHLENBQUM7TUFDbEYsY0FBYyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQUMscUJBQXFCLEtBQUssQ0FBQztNQUMvRCxjQUFjLElBQUksQ0FBQyxlQUFlLE1BQU0sQ0FBQyxrQ0FBa0MsRUFBRSxDQUFDLGFBQWEsTUFBTSxLQUFLLENBQUM7TUFDdkcsY0FBYyxJQUFJLENBQUMsYUFBYSxNQUFNLENBQUMseUJBQXlCLEVBQUUsQ0FBQyxhQUFhLE1BQU0sS0FBSyxDQUFDO01BQzVGLGNBQWMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUMseUJBQXlCLEVBQUUsQ0FBQyxhQUFhLE1BQU0sS0FBSyxDQUFDO0tBQ2pHO0lBRUQsTUFBTSxTQUFTLFVBQVUsSUFBSSxJQUFJLEVBQUU7SUFDbkMsTUFBTSxhQUFhLGNBQWMsSUFBSSxJQUFJLEVBQUU7SUFDM0MsTUFBTSxZQUFZLGFBQWEsSUFBSSxJQUFJLEVBQUU7SUFDekMsTUFBTSxlQUFlLGdCQUFnQixJQUFJLElBQUksRUFBRTtJQUUvQyxJQUFJLE9BQU8sTUFBTSxLQUFLLEdBQUc7TUFDdkIsUUFBUSxHQUFHLENBQUM7TUFDWjtJQUNGO0lBRUEsa0NBQWtDO0lBQ2xDLE1BQU0sYUFBYSxPQUFPLEdBQUcsQ0FBQyxDQUFBLElBQUssQ0FBQyxPQUFPLEVBQUUsRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUM7SUFDN0YsTUFBTSxpQkFBaUIsV0FBVyxHQUFHLENBQUMsQ0FBQSxJQUFLLENBQUMsT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLEVBQUUsV0FBVyxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUM7SUFDbEosTUFBTSxnQkFBZ0IsVUFBVSxNQUFNLEdBQUcsSUFDckMsVUFBVSxHQUFHLENBQUMsQ0FBQSxJQUFLLENBQUMsT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBRSxXQUFXLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUMzRztJQUNKLE1BQU0sbUJBQW1CLGFBQWEsTUFBTSxHQUFHLElBQzNDLGFBQWEsR0FBRyxDQUFDLENBQUEsSUFBSyxDQUFDLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUUsV0FBVyxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsUUFDOUc7SUFFSixNQUFNLFNBQVMsQ0FBQzs7OztBQUlwQixFQUFFLFdBQVc7OztBQUdiLEVBQUUsZUFBZTs7O0FBR2pCLEVBQUUsY0FBYzs7O0FBR2hCLEVBQUUsaUJBQWlCOzs7YUFHTixFQUFFLFNBQVMsWUFBWTtRQUM1QixFQUFFLFNBQVMsT0FBTyxTQUFTLENBQUMsR0FBRyxRQUFRLDRCQUE0Qjs7Ozs7Ozs7Ozs2R0FVa0MsQ0FBQztJQUUxRyxNQUFNLFNBQVMsQ0FBQyxtREFBbUQsRUFBRSx3QkFBd0Isb0JBQW9CLENBQUM7SUFFbEgsTUFBTSxXQUFXLE1BQU0sTUFBTSxRQUFRO01BQ25DLFFBQVE7TUFDUixTQUFTO1FBQ1AsZUFBZSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUM7UUFDeEMsZ0JBQWdCO1FBQ2hCLGtCQUFrQjtNQUNwQjtNQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7UUFDbkIsT0FBTztRQUNQLFVBQVU7VUFDUjtZQUFFLE1BQU07WUFBVSxTQUFTO1VBQXFEO1VBQ2hGO1lBQUUsTUFBTTtZQUFRLFNBQVM7VUFBTztTQUNqQztRQUNELGFBQWE7TUFDZjtJQUNGO0lBRUEsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLFFBQVEsS0FBSyxDQUFDLENBQUMsMEJBQTBCLEVBQUUsU0FBUyxNQUFNLENBQUMsQ0FBQztNQUM1RDtJQUNGO0lBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0lBQ2xDLE1BQU0sVUFBVSxPQUFPLE9BQU8sRUFBRSxDQUFDLEVBQUUsRUFBRSxTQUFTO0lBRTlDLElBQUksQ0FBQyxTQUFTO01BQ1osUUFBUSxLQUFLLENBQUM7TUFDZDtJQUNGO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyw0QkFBNEIsRUFBRSxRQUFRLENBQUM7SUFFcEQsMERBQTBEO0lBQzFELElBQUk7SUFDSixJQUFJO01BQ0YsTUFBTSxZQUFZLFFBQVEsS0FBSyxDQUFDO01BQ2hDLElBQUksV0FBVztRQUNiLGlCQUFpQixLQUFLLEtBQUssQ0FBQyxTQUFTLENBQUMsRUFBRTtNQUMxQyxPQUFPO1FBQ0wsaUJBQWlCLEtBQUssS0FBSyxDQUFDO01BQzlCO0lBQ0YsRUFBRSxPQUFPLFVBQVU7TUFDakIsUUFBUSxLQUFLLENBQUMsc0NBQXNDO01BQ3BEO0lBQ0Y7SUFFQSxpQ0FBaUM7SUFDakMsTUFBTSxlQUFlLE9BQU8sSUFBSSxDQUFDLENBQUEsSUFBSyxFQUFFLEVBQUUsS0FBSyxlQUFlLFFBQVEsR0FBRyxNQUFNO0lBQy9FLE1BQU0sbUJBQW1CLFdBQVcsSUFBSSxDQUFDLENBQUEsSUFBSyxFQUFFLEVBQUUsS0FBSyxlQUFlLGFBQWEsR0FBRyxNQUFNO0lBQzVGLE1BQU0sa0JBQWtCLGVBQWUsV0FBVyxHQUM5QyxVQUFVLElBQUksQ0FBQyxDQUFBLElBQUssRUFBRSxFQUFFLEtBQUssZUFBZSxXQUFXLEdBQUcsTUFBTSxPQUNoRTtJQUNKLE1BQU0scUJBQXFCLGVBQWUsZUFBZSxHQUNyRCxhQUFhLElBQUksQ0FBQyxDQUFBLElBQUssRUFBRSxFQUFFLEtBQUssZUFBZSxlQUFlLEdBQUcsTUFBTSxPQUN2RTtJQUVKLG1DQUFtQztJQUNuQyxNQUFNLGFBQTRDLENBQUM7SUFDbkQsSUFBSSxjQUFjLFdBQVcsUUFBUSxHQUFHO0lBQ3hDLElBQUksa0JBQWtCLFdBQVcsYUFBYSxHQUFHO0lBQ2pELElBQUksaUJBQWlCLFdBQVcsV0FBVyxHQUFHO0lBQzlDLElBQUksb0JBQW9CLFdBQVcsZUFBZSxHQUFHO0lBRXJELElBQUksT0FBTyxJQUFJLENBQUMsWUFBWSxNQUFNLEdBQUcsR0FBRztNQUN0QyxNQUFNLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLGNBQ2hDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxZQUNQLEVBQUUsQ0FBQyxNQUFNO01BRVosSUFBSSxXQUFXO1FBQ2IsUUFBUSxLQUFLLENBQUMsMENBQTBDO01BQzFELE9BQU87UUFDTCxRQUFRLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxRQUFRLG1CQUFtQixFQUFFLGFBQWEsUUFBUSxFQUFFLGlCQUFpQixXQUFXLEVBQUUsZ0JBQWdCLFNBQVMsRUFBRSxtQkFBbUIsQ0FBQztNQUN4SjtJQUNGO0VBQ0YsRUFBRSxPQUFPLEtBQUs7SUFDWixRQUFRLEtBQUssQ0FBQywrQkFBK0I7RUFDL0M7QUFDRjtBQUVBLDhEQUE4RDtBQUM5RCxlQUFlLG1CQUNiLGFBQTZCLEVBQzdCLE9BQWUsRUFDZixVQUFrQixFQUNsQixRQUF1QixFQUN2QixRQUF1QixFQUN2QixVQUFtQixFQUNuQixXQUFvQjtFQUVwQixJQUFJO0lBQ0Ysb0NBQW9DO0lBQ3BDLE1BQU0sRUFBRSxNQUFNLFdBQVcsRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sY0FDckQsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyxDQUFDOzs7OztNQUtULENBQUMsRUFDQSxFQUFFLENBQUMsWUFBWSxTQUNmLEVBQUUsQ0FBQyxVQUFVO0lBRWhCLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLGdDQUFnQztNQUM5QztJQUNGO0lBRUEsSUFBSSxDQUFDLGVBQWUsWUFBWSxNQUFNLEtBQUssR0FBRztNQUM1QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLDRCQUE0QixFQUFFLFFBQVEsQ0FBQztNQUNwRDtJQUNGO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsWUFBWSxNQUFNLENBQUMsa0JBQWtCLEVBQUUsUUFBUSxDQUFDO0lBRTFFLDJDQUEyQztJQUMzQyxNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsR0FBRyxNQUFNLGNBQzNCLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQywwQkFDUCxFQUFFLENBQUMsTUFBTSxTQUNULE1BQU07SUFFVCxNQUFNLFlBQWEsT0FBTztJQUMxQixNQUFNLFlBQVksV0FBVyxRQUFRO0lBRXJDLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbEMsTUFBTSx1QkFBdUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBRTFDLEtBQUssTUFBTSxTQUFTLFlBQWE7TUFDL0IsTUFBTSxtQkFBb0IsTUFBTSxhQUFhO01BQzdDLE1BQU0sWUFBWSxrQkFBa0I7TUFDcEMsUUFBUSxHQUFHLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxVQUFVLFdBQVcsRUFBRSxRQUFRLENBQUM7TUFFakUsOEJBQThCO01BQzlCLE1BQU0sY0FDSCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO1FBQUUsUUFBUTtRQUFjLFlBQVksSUFBSSxPQUFPLFdBQVc7TUFBRyxHQUNwRSxFQUFFLENBQUMsTUFBTSxNQUFNLEVBQUU7TUFFcEIsSUFBSSxlQUE4QjtNQUNsQyxJQUFJLGNBQXVDO1FBQ3pDLFVBQVU7UUFDVixhQUFhO1FBQ2IsT0FBTztNQUNUO01BRUEsSUFBSSxjQUFjLGVBQWU7UUFDL0IsZUFBZTtRQUNmLFlBQVksa0JBQWtCLEdBQUc7TUFDbkMsT0FBTyxJQUFJLGNBQWMsZUFBZTtRQUN0QyxlQUFlO1FBQ2YsWUFBWSxTQUFTLEdBQUc7UUFDeEIsb0VBQW9FO1FBQ3BFLElBQUksWUFBWTtVQUNkLFlBQVksWUFBWSxHQUFHO1FBQzdCO1FBQ0EsSUFBSSxhQUFhO1VBQ2YsWUFBWSxhQUFhLEdBQUc7UUFDOUI7TUFDRixPQUFPLElBQUksY0FBYyxZQUFZO1FBQ25DLGVBQWU7UUFDZixZQUFZLFNBQVMsR0FBRztNQUMxQjtNQUVBLElBQUksY0FBYztRQUNoQixJQUFJO1VBQ0YsOENBQThDO1VBQzlDLE1BQU0sV0FBVyxNQUFNLE1BQU0sQ0FBQyxFQUFFLGFBQWEsY0FBYyxFQUFFLGFBQWEsQ0FBQyxFQUFFO1lBQzNFLFFBQVE7WUFDUixTQUFTO2NBQ1AsZ0JBQWdCO2NBQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxxQkFBcUIsQ0FBQztZQUNuRDtZQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7VUFDdkI7VUFFQSxNQUFNLFNBQVMsTUFBTSxTQUFTLElBQUk7VUFDbEMsUUFBUSxHQUFHLENBQUMsQ0FBQyxFQUFFLGFBQWEsa0JBQWtCLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRTtVQUU1RCxJQUFJLENBQUMsT0FBTyxPQUFPLEVBQUU7WUFDbkIsaUJBQWlCO1lBQ2pCLE1BQU0sY0FDSCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDO2NBQ04sUUFBUTtjQUNSLFlBQVksSUFBSSxPQUFPLFdBQVc7WUFDcEMsR0FDQyxFQUFFLENBQUMsTUFBTSxNQUFNLEVBQUU7VUFDdEI7UUFDQSw0RUFBNEU7UUFDOUUsRUFBRSxPQUFPLFNBQVM7VUFDaEIsUUFBUSxLQUFLLENBQUMsQ0FBQyxjQUFjLEVBQUUsYUFBYSxDQUFDLENBQUMsRUFBRTtVQUNoRCxNQUFNLGNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztZQUNOLFFBQVE7WUFDUixZQUFZLElBQUksT0FBTyxXQUFXO1VBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sTUFBTSxFQUFFO1FBQ3RCO01BQ0YsT0FBTztRQUNMLFFBQVEsR0FBRyxDQUFDLENBQUMsb0JBQW9CLEVBQUUsVUFBVSxtQkFBbUIsQ0FBQztRQUNqRSxNQUFNLGNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztVQUNOLFFBQVE7VUFDUixZQUFZLElBQUksT0FBTyxXQUFXO1FBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sTUFBTSxFQUFFO01BQ3RCO0lBQ0Y7RUFDRixFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLGtDQUFrQztFQUNsRDtBQUNGO0FBRUEsdUVBQXVFO0FBQ3ZFLDhFQUE4RTtBQUM5RSxxREFBcUQ7QUFDckQsZUFBZSx1QkFDYixhQUE2QixFQUM3QixXQUFtQixFQUNuQixlQUF5QjtFQUV6QixJQUFJO0lBQ0YsTUFBTSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNsQyxNQUFNLGdCQUFnQjtJQUN0QixNQUFNLGlCQUFpQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDcEMsTUFBTSxVQUFVLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxlQUFlO0lBRTVDLElBQUksQ0FBQyxjQUFjO01BQ2pCLFFBQVEsS0FBSyxDQUFDO01BQ2Q7SUFDRjtJQUVBLDJCQUEyQjtJQUMzQixNQUFNLG1CQUFtQixpQkFDckIsQ0FBQyxFQUFFLFFBQVEseUNBQXlDLEVBQUUsbUJBQW1CLGdCQUFnQixDQUFDLEdBQzFGLENBQUMsRUFBRSxRQUFRLGlDQUFpQyxDQUFDO0lBRWpELFFBQVEsR0FBRyxDQUFDLENBQUMsZ0RBQWdELEVBQUUsWUFBWSxDQUFDO0lBQzVFLFFBQVEsR0FBRyxDQUFDLENBQUMsb0JBQW9CLEVBQUUsaUJBQWlCLENBQUM7SUFFckQsc0JBQXNCO0lBQ3RCLHdDQUF3QztJQUN4QyxNQUFNLFFBQVE7TUFDWjtNQUNBO0tBQ0Q7SUFFRCxJQUFJLGdCQUFnQjtJQUNwQixJQUFJLFlBQVk7SUFFaEIsS0FBSyxNQUFNLFFBQVEsTUFBTztNQUN4QixJQUFJO1FBQ0YsTUFBTSxNQUFNLENBQUMsRUFBRSxjQUFjLEVBQUUsS0FBSyxDQUFDO1FBQ3JDLFFBQVEsR0FBRyxDQUFDLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDO1FBRXRDLGdCQUFnQixNQUFNLE1BQU0sS0FBSztVQUMvQixRQUFRO1VBQ1IsU0FBUztZQUNQLGdCQUFnQjtZQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDO1VBQzNDO1VBQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztZQUNuQixRQUFRO1lBQ1IsYUFBYTtVQUNmO1FBQ0Y7UUFFQSxZQUFZLE1BQU0sY0FBYyxJQUFJO1FBQ3BDLFFBQVEsR0FBRyxDQUFDLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxLQUFLLFNBQVMsQ0FBQztRQUU1RCx5REFBeUQ7UUFDekQsSUFBSSxjQUFjLE1BQU0sS0FBSyxLQUFLO01BQ3BDLEVBQUUsT0FBTyxVQUFVO1FBQ2pCLFFBQVEsS0FBSyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRTtNQUNwRDtJQUNGO0lBRUEsSUFBSSxDQUFDLGFBQWMsVUFBVSxJQUFJLEtBQUssT0FBTyxVQUFVLElBQUksS0FBSyxLQUFNO01BQ3BFLFFBQVEsS0FBSyxDQUFDLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxTQUFTLENBQUMsV0FBVyxDQUFDO01BQzlEO0lBQ0Y7SUFFQSw2RUFBNkU7SUFDN0UsTUFBTSxjQUFjLFVBQVUsSUFBSSxFQUFFO0lBQ3BDLElBQUksQ0FBQyxhQUFhO01BQ2hCLFFBQVEsS0FBSyxDQUFDO01BQ2Q7SUFDRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMseUNBQXlDLEVBQUUsWUFBWSxDQUFDO0lBRXJFLDhEQUE4RDtJQUM5RCxLQUFLLE1BQU0sV0FBVyxnQkFBaUI7TUFDckMsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLEdBQUcsTUFBTSxjQUMzQixJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsZUFDUCxFQUFFLENBQUMsTUFBTSxTQUNULE1BQU07TUFFVCxJQUFJLE9BQU87UUFDVCxrQ0FBa0M7UUFDbEMsSUFBSSxDQUFDLE1BQU0sV0FBVyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0IsRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHO1VBQ25FLE1BQU0sVUFBVSxNQUFNLFdBQVcsR0FDN0IsQ0FBQyxFQUFFLE1BQU0sV0FBVyxDQUFDLG9CQUFvQixFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQ3pELENBQUMsZ0JBQWdCLEVBQUUsWUFBWSxDQUFDLENBQUM7VUFFckMsTUFBTSxjQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztZQUFFLGFBQWE7VUFBUSxHQUM5QixFQUFFLENBQUMsTUFBTTtVQUVaLFFBQVEsR0FBRyxDQUFDLENBQUMscUJBQXFCLEVBQUUsWUFBWSxVQUFVLEVBQUUsUUFBUSxDQUFDO1FBQ3ZFO01BQ0Y7SUFDRjtFQUNGLEVBQUUsT0FBTyxLQUFLO0lBQ1osUUFBUSxLQUFLLENBQUMsc0NBQXNDO0VBQ3REO0FBQ0Y7QUFFQSxxREFBcUQ7QUFDckQsMkNBQTJDO0FBQzNDLDJCQUEyQjtBQUMzQixxQkFBcUI7QUFDckIseUNBQXlDO0FBQ3pDLGtCQUFrQjtBQUNsQixxQ0FBcUM7QUFDckMsbURBQW1EO0FBQ25ELDZCQUE2QjtBQUM3QixvQkFBb0I7QUFDcEIsMEJBQTBCO0FBQzFCLFNBQVMsb0JBQW9CLElBQVksRUFBRSxlQUF3QjtFQUNqRSxrRkFBa0Y7RUFDbEYsSUFBSSxpQkFBaUI7SUFDbkIsTUFBTSxXQUFXLGdCQUFnQixXQUFXO0lBRTVDLHVDQUF1QztJQUN2QyxJQUFJLFNBQVMsUUFBUSxDQUFDLDRCQUNsQixTQUFTLFFBQVEsQ0FBQywyQkFDbEIsU0FBUyxRQUFRLENBQUMsZ0JBQ2xCLFNBQVMsUUFBUSxDQUFDLHNCQUFzQjtNQUMxQyxPQUFPO1FBQ0wsT0FBTztRQUNQLE1BQU07TUFDUjtJQUNGO0lBRUEsK0JBQStCO0lBQy9CLElBQUksU0FBUyxRQUFRLENBQUMsaUJBQ2xCLFNBQVMsUUFBUSxDQUFDLGdCQUNsQixTQUFTLFFBQVEsQ0FBQyxvQkFDbEIsU0FBUyxRQUFRLENBQUMsZUFBZTtNQUNuQyxPQUFPO1FBQ0wsT0FBTztRQUNQLE1BQU07TUFDUjtJQUNGO0lBRUEscUJBQXFCO0lBQ3JCLElBQUksU0FBUyxRQUFRLENBQUMsWUFBWSxTQUFTLFFBQVEsQ0FBQyxVQUFVO01BQzVELE9BQU87UUFDTCxPQUFPO1FBQ1AsTUFBTTtNQUNSO0lBQ0Y7SUFFQSw2Q0FBNkM7SUFDN0MsSUFBSSxTQUFTLFFBQVEsQ0FBQyxlQUFlLFNBQVMsUUFBUSxDQUFDLGdCQUFnQixTQUFTLFFBQVEsQ0FBQyxZQUFZO01BQ25HLE9BQU87UUFDTCxPQUFPO1FBQ1AsTUFBTTtNQUNSO0lBQ0Y7SUFFQSxpQkFBaUI7SUFDakIsSUFBSSxTQUFTLFFBQVEsQ0FBQyxhQUFhLFNBQVMsUUFBUSxDQUFDLGNBQWMsU0FBUyxRQUFRLENBQUMsaUJBQWlCO01BQ3BHLE9BQU87UUFDTCxPQUFPO1FBQ1AsTUFBTTtNQUNSO0lBQ0Y7RUFDRjtFQUVBLGtDQUFrQztFQUNsQyxNQUFNLGdCQUFpRTtJQUNyRSxLQUFLO01BQ0gsT0FBTztNQUNQLE1BQU07SUFDUjtJQUNBLEtBQUs7TUFDSCxPQUFPO01BQ1AsTUFBTTtJQUNSO0lBQ0EsS0FBSztNQUNILE9BQU87TUFDUCxNQUFNO0lBQ1I7SUFDQSxLQUFLO01BQ0gsT0FBTztNQUNQLE1BQU07SUFDUjtJQUNBLEtBQUs7TUFDSCxPQUFPO01BQ1AsTUFBTTtJQUNSO0lBQ0EsS0FBSztNQUNILE9BQU87TUFDUCxNQUFNO0lBQ1I7SUFDQSxLQUFLO01BQ0gsT0FBTztNQUNQLE1BQU07SUFDUjtJQUNBLEtBQUs7TUFDSCxPQUFPO01BQ1AsTUFBTTtJQUNSO0lBQ0EsS0FBSztNQUNILE9BQU87TUFDUCxNQUFNO0lBQ1I7SUFDQSxLQUFLO01BQ0gsT0FBTztNQUNQLE1BQU07SUFDUjtFQUNGO0VBRUEsSUFBSSxhQUFhLENBQUMsS0FBSyxFQUFFO0lBQ3ZCLE9BQU8sYUFBYSxDQUFDLEtBQUs7RUFDNUI7RUFFQSxPQUFPO0lBQ0wsT0FBTyxDQUFDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLE1BQU0sbUJBQW1CLENBQUMsNENBQTRDLEVBQUUsS0FBSyw4Q0FBOEMsQ0FBQztFQUM5SDtBQUNGO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0Ysa0RBQWtEO0lBQ2xELE1BQU0saUJBQWlCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNwQyxJQUFJLGdCQUFnQjtNQUNsQixnREFBZ0Q7TUFDaEQsTUFBTSxNQUFNLElBQUksSUFBSSxJQUFJLEdBQUc7TUFDM0IsTUFBTSxjQUFjLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixRQUFRLFdBQVc7TUFDakgsTUFBTSxhQUFhLElBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQztNQUV4QyxJQUFJLGdCQUFnQixrQkFBa0IsZUFBZSxnQkFBZ0I7UUFDbkUsUUFBUSxLQUFLLENBQUM7UUFDZCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBZSxJQUN2QztVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFDQSxRQUFRLEdBQUcsQ0FBQztJQUNkLE9BQU87TUFDTCxRQUFRLElBQUksQ0FBQztJQUNmO0lBRUEsTUFBTSxnQkFBZ0IsYUFDcEIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0lBRy9DLE1BQU0sZUFBZSxNQUFNLElBQUksSUFBSTtJQUNuQyxRQUFRLEdBQUcsQ0FBQywyQkFBMkIsS0FBSyxTQUFTLENBQUM7SUFFdEQsaURBQWlEO0lBQ2pELHFIQUFxSDtJQUNySCxNQUFNLFNBQVMsY0FBYyxNQUFNLFFBQVEsY0FBYyxRQUFRLEVBQUU7SUFDbkUsTUFBTSxTQUFTLGNBQWMsTUFBTTtJQUNuQyxNQUFNLGVBQWUsY0FBYyxNQUFNO0lBQ3pDLE1BQU0sZUFBZSxjQUFjO0lBQ25DLE1BQU0sZUFBZSxjQUFjO0lBRW5DLFFBQVEsR0FBRyxDQUFDLENBQUMsZUFBZSxFQUFFLGFBQWEsV0FBVyxFQUFFLE9BQU8sUUFBUSxFQUFFLGFBQWEsZ0JBQWdCLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQztJQUV2SCw0RUFBNEU7SUFDNUUsb0ZBQW9GO0lBQ3BGLE1BQU0sVUFBVSxpQkFBaUIsT0FDakIsaUJBQWlCLFVBQ2pCLGlCQUFpQixXQUNqQixpQkFBaUI7SUFFakMsSUFBSSxTQUFTO01BQ1gsUUFBUSxHQUFHLENBQUMsQ0FBQyxpQ0FBaUMsRUFBRSxPQUFPLFNBQVMsRUFBRSxhQUFhLFFBQVEsRUFBRSxhQUFhLENBQUM7TUFFdkcsbUNBQW1DO01BQ25DLE1BQU0sWUFBWSxvQkFBb0IsZ0JBQWdCLEtBQUssZ0JBQWdCLGNBQWMsTUFBTTtNQUMvRixNQUFNLGFBQWEsVUFBVSxLQUFLO01BRWxDLHFGQUFxRjtNQUNyRixJQUFJLGVBQWtELEVBQUU7TUFFeEQsdURBQXVEO01BQ3ZELElBQUksUUFBUTtRQUNWLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxHQUFHLE1BQU0sY0FDaEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLDRCQUNQLEVBQUUsQ0FBQyxVQUFVO1VBQUM7VUFBYztTQUFVLEVBQ3RDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEVBQ2xDLEtBQUssQ0FBQztRQUVULElBQUksY0FBYyxXQUFXLE1BQU0sR0FBRyxHQUFHO1VBQ3ZDLGVBQWU7VUFDZixRQUFRLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxXQUFXLE1BQU0sQ0FBQyx5QkFBeUIsRUFBRSxPQUFPLENBQUM7UUFDNUU7TUFDRjtNQUVBLHNEQUFzRDtNQUN0RCxJQUFJLGFBQWEsTUFBTSxLQUFLLEdBQUc7UUFDN0IsTUFBTSxFQUFFLE1BQU0sYUFBYSxFQUFFLEdBQUcsTUFBTSxjQUNuQyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsZUFDUCxFQUFFLENBQUMsVUFBVTtVQUFDO1VBQWM7U0FBVSxFQUN0QyxLQUFLLENBQUMsY0FBYztVQUFFLFdBQVc7UUFBTSxHQUN2QyxLQUFLLENBQUM7UUFFVCxJQUFJLGlCQUFpQixjQUFjLE1BQU0sR0FBRyxHQUFHO1VBQzdDLGVBQWU7UUFDakI7TUFDRjtNQUVBLElBQUksYUFBYSxNQUFNLEdBQUcsR0FBRztRQUMzQixLQUFLLE1BQU0sU0FBUyxhQUFjO1VBQ2hDLE1BQU0sY0FDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7WUFDTixRQUFRO1lBQ1IsZUFBZTtVQUNqQixHQUNDLEVBQUUsQ0FBQyxNQUFNLE1BQU0sRUFBRTtVQUVwQixrQ0FBa0M7VUFDbEMsTUFBTSxFQUFFLE1BQU0sTUFBTSxFQUFFLEdBQUcsTUFBTSxjQUM1QixJQUFJLENBQUMsbUJBQ0wsTUFBTSxDQUFDLFlBQ1AsRUFBRSxDQUFDLFlBQVksTUFBTSxFQUFFLEVBQ3ZCLE1BQU07VUFFVCxtQkFBbUI7VUFDbkIsSUFBSSxVQUFVLE9BQU8sUUFBUSxHQUFHLEdBQUc7WUFDakMsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxjQUM3QixJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxNQUFNLE9BQU8sRUFDM0IsTUFBTTtZQUVULElBQUksU0FBUztjQUNYLE1BQU0sYUFBYSxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSSxPQUFPLFFBQVE7Y0FDM0QsTUFBTSxjQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztnQkFBRSxTQUFTO2NBQVcsR0FDN0IsRUFBRSxDQUFDLFdBQVcsTUFBTSxPQUFPO2NBRTlCLHlCQUF5QjtjQUN6QixNQUFNLGNBQWMsSUFBSSxDQUFDLHdCQUF3QixNQUFNLENBQUM7Z0JBQ3RELFNBQVMsTUFBTSxPQUFPO2dCQUN0QixRQUFRLE9BQU8sUUFBUTtnQkFDdkIsZUFBZTtnQkFDZixNQUFNO2dCQUNOLGFBQWEsQ0FBQyxzQkFBc0IsRUFBRSxXQUFXLENBQUM7Z0JBQ2xELGNBQWMsTUFBTSxFQUFFO2dCQUN0QixnQkFBZ0I7Y0FDbEI7Y0FFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLFNBQVMsRUFBRSxPQUFPLFFBQVEsQ0FBQyxXQUFXLEVBQUUsTUFBTSxPQUFPLENBQUMsQ0FBQztjQUVwRSx3REFBd0Q7Y0FDeEQsTUFBTSxjQUNILElBQUksQ0FBQyxpQkFDTCxNQUFNLENBQUM7Z0JBQ04sU0FBUyxNQUFNLE9BQU87Z0JBQ3RCLE1BQU07Z0JBQ04sT0FBTyxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUM7Z0JBQzlCLFNBQVMsQ0FBQyxFQUFFLFVBQVUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLE9BQU8sUUFBUSxDQUFDLEVBQUUsQ0FBQztnQkFDbkUsYUFBYTtnQkFDYixXQUFXLE1BQU0sRUFBRTtjQUNyQjtZQUNKO1VBQ0Y7VUFFQSx5Q0FBeUM7VUFDekMsTUFBTSxjQUNILElBQUksQ0FBQyxtQkFDTCxNQUFNLENBQUM7WUFBRSxRQUFRO1VBQVMsR0FDMUIsRUFBRSxDQUFDLFlBQVksTUFBTSxFQUFFO1FBQzVCO1FBQ0EsUUFBUSxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsYUFBYSxNQUFNLENBQUMsOEJBQThCLENBQUM7TUFDM0U7TUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLFVBQVU7UUFBTSxTQUFTO01BQTBDLElBQ3BGO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsSUFBSSxDQUFDLE1BQU0sT0FBTyxDQUFDLFdBQVcsT0FBTyxNQUFNLEtBQUssR0FBRztNQUNqRCxRQUFRLEdBQUcsQ0FBQztNQUNaLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsVUFBVTtRQUFNLFNBQVM7TUFBdUIsSUFDakU7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxrRkFBa0Y7SUFDbEYsOERBQThEO0lBQzlELElBQUksaUJBQWlCLGNBQWMsaUJBQWlCLFNBQVM7TUFDM0QsUUFBUSxHQUFHLENBQUMsQ0FBQyx3QkFBd0IsRUFBRSxhQUFhLG9CQUFvQixDQUFDO01BQ3pFLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsVUFBVTtRQUFNLFNBQVMsQ0FBQyxjQUFjLEVBQUUsYUFBYSxhQUFhLENBQUM7TUFBQyxJQUN2RjtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLE1BQU0sb0JBQW9CLGlCQUFpQjtJQUMzQyxJQUFJLG1CQUFtQjtNQUNyQixRQUFRLEdBQUcsQ0FBQyxDQUFDLGlGQUFpRixDQUFDO0lBQ2pHO0lBRUEsZ0VBQWdFO0lBQ2hFLDhFQUE4RTtJQUM5RSxJQUFJLGdCQU9DLEVBQUU7SUFFUCxJQUFJLFFBQVE7TUFDVixNQUFNLEVBQUUsTUFBTSxVQUFVLEVBQUUsT0FBTyxhQUFhLEVBQUUsR0FBRyxNQUFNLGNBQ3RELElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxtREFDUCxFQUFFLENBQUMsVUFBVTtRQUFDO1FBQWM7T0FBVSxFQUN0QyxLQUFLLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUM3QyxLQUFLLENBQUMsY0FBYztRQUFFLFdBQVc7TUFBSyxHQUN0QyxLQUFLLENBQUM7TUFFVCxJQUFJLGVBQWU7UUFDakIsUUFBUSxLQUFLLENBQUMsb0NBQW9DO01BQ3BELE9BQU8sSUFBSSxjQUFjLFdBQVcsTUFBTSxHQUFHLEdBQUc7UUFDOUMsZ0JBQWdCO1FBQ2hCLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLFdBQVcsTUFBTSxDQUFDLHlCQUF5QixFQUFFLE9BQU8sQ0FBQztNQUM1RTtJQUNGO0lBRUEsbUZBQW1GO0lBQ25GLHNEQUFzRDtJQUN0RCxJQUFJLGNBQWMsTUFBTSxLQUFLLEdBQUc7TUFDOUIsUUFBUSxJQUFJLENBQUMsQ0FBQyxpQ0FBaUMsRUFBRSxPQUFPLHdEQUF3RCxDQUFDO01BQ2pILFFBQVEsSUFBSSxDQUFDLENBQUMsa0JBQWtCLEVBQUUsT0FBTyxNQUFNLENBQUMsMENBQTBDLENBQUM7TUFDM0YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixVQUFVO1FBQ1YsU0FBUztRQUNULFNBQVM7TUFDWCxJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsSUFBSSxlQUFlO0lBRW5CLDZFQUE2RTtJQUM3RSxNQUFNLGtCQUFrQjtTQUFJO0tBQWM7SUFDMUMsMENBQTBDO0lBQzFDLE1BQU0sbUJBQW1CLElBQUk7SUFFN0IsaURBQWlEO0lBQ2pELHVGQUF1RjtJQUN2RixJQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxNQUFNLEVBQUUsSUFBSztNQUN0QyxNQUFNLFFBQVEsTUFBTSxDQUFDLEVBQUU7TUFDdkIsTUFBTSxFQUNKLElBQUksV0FBVyxFQUNmLFNBQVMsRUFDVCxnQkFBZ0IsRUFDaEIsZ0JBQWdCLEVBQ2hCLFNBQVMsRUFDVCxnQkFBZ0IsRUFDaEIsUUFBUSxFQUNSLE9BQU8sU0FBUyxFQUNqQixHQUFHO01BRUosTUFBTSxXQUFXLGFBQWEsb0JBQW9CO01BQ2xELE1BQU0sV0FBVyxhQUFhO01BRTlCLElBQUksQ0FBQyxVQUFVO1FBQ2IsUUFBUSxHQUFHLENBQUM7UUFDWjtNQUNGO01BRUEsdUZBQXVGO01BQ3ZGLG1EQUFtRDtNQUNuRCxNQUFNLGdCQUFnQixlQUFlLENBQUMsRUFBRTtNQUV4Qyw2REFBNkQ7TUFDN0QsSUFBSSxDQUFDLGVBQWU7UUFDbEIsUUFBUSxHQUFHLENBQUMsQ0FBQywwQkFBMEIsRUFBRSxFQUFFLGtCQUFrQixFQUFFLFVBQVUsQ0FBQztRQUMxRTtNQUNGO01BRUEsNERBQTREO01BQzVELElBQUksaUJBQWlCLEdBQUcsQ0FBQyxJQUFJO1FBQzNCLFFBQVEsR0FBRyxDQUFDLENBQUMsZUFBZSxFQUFFLEVBQUUsNEJBQTRCLENBQUM7UUFDN0Q7TUFDRjtNQUVBLGlCQUFpQixHQUFHLENBQUM7TUFDckIsUUFBUSxHQUFHLENBQUMsQ0FBQyxlQUFlLEVBQUUsY0FBYyxFQUFFLENBQUMsRUFBRSxFQUFFLGNBQWMsS0FBSyxDQUFDLGNBQWMsRUFBRSxTQUFTLENBQUM7TUFFakcsdURBQXVEO01BQ3ZELElBQUksZ0JBQWdCO01BQ3BCLElBQUksZ0JBQWdCO01BRXBCLDZCQUE2QjtNQUM3QixJQUFJO1FBQ0YsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLGNBQWMsRUFBRSxDQUFDLElBQUksQ0FBQztRQUMvQyxNQUFNLGlCQUFpQixNQUFNLGtCQUMzQixlQUNBLFVBQ0EsVUFDQSxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUM7UUFFMUIsSUFBSSxnQkFBZ0I7VUFDbEIsZ0JBQWdCO1VBQ2hCLFFBQVEsR0FBRyxDQUFDLENBQUMseUJBQXlCLEVBQUUsY0FBYyxDQUFDO1FBQ3pELE9BQU87VUFDTCxRQUFRLEdBQUcsQ0FBQyxDQUFDLHdDQUF3QyxDQUFDO1FBQ3hEO01BQ0YsRUFBRSxPQUFPLFVBQVU7UUFDakIsUUFBUSxLQUFLLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFO01BQ3hDO01BRUEsOEJBQThCO01BQzlCLElBQUksVUFBVTtRQUNaLElBQUk7VUFDRixNQUFNLGdCQUFnQixDQUFDLEVBQUUsY0FBYyxFQUFFLENBQUMsSUFBSSxDQUFDO1VBQy9DLE1BQU0saUJBQWlCLE1BQU0sa0JBQzNCLGVBQ0EsVUFDQSxVQUNBLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQztVQUUzQixJQUFJLGdCQUFnQjtZQUNsQixnQkFBZ0I7WUFDaEIsUUFBUSxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBRSxjQUFjLENBQUM7VUFDekQsT0FBTztZQUNMLFFBQVEsR0FBRyxDQUFDLENBQUMsd0NBQXdDLENBQUM7VUFDeEQ7UUFDRixFQUFFLE9BQU8sVUFBVTtVQUNqQixRQUFRLEtBQUssQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEVBQUU7UUFDeEM7TUFDRjtNQUVBLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sY0FDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sV0FBVztRQUNYLFdBQVcsaUJBQWlCO1FBQzVCLFVBQVUsV0FBVyxLQUFLLEtBQUssQ0FBQyxZQUFZO1FBQzVDLFFBQVE7UUFDUiwyQ0FBMkM7UUFDM0MsZUFBZSxlQUFlO1FBQzlCLHVFQUF1RTtRQUN2RSxhQUFhLGNBQWMsV0FBVyxHQUNsQyxDQUFDLEVBQUUsY0FBYyxXQUFXLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEdBQ3RELENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO01BQzVCLEdBQ0MsRUFBRSxDQUFDLE1BQU0sY0FBYyxFQUFFO01BRTVCLElBQUksYUFBYTtRQUNmLFFBQVEsS0FBSyxDQUFDLHlCQUF5QjtNQUN6QyxPQUFPO1FBQ0wsUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsY0FBYyxFQUFFLENBQUMsdUNBQXVDLENBQUM7UUFDOUU7UUFFQSwrQkFBK0I7UUFDL0IsTUFBTSxjQUNILElBQUksQ0FBQyxtQkFDTCxNQUFNLENBQUM7VUFBRSxRQUFRO1FBQVksR0FDN0IsRUFBRSxDQUFDLFlBQVksY0FBYyxFQUFFO1FBR2xDLDRGQUE0RjtRQUM1RixNQUFNLG1CQUFtQixlQUFlLGNBQWMsRUFBRSxFQUFFLGNBQWMsS0FBSyxJQUFJLFlBQVksZUFBZSxlQUFlLFFBQVE7UUFFbkksOERBQThEO1FBQzlELHFFQUFxRTtRQUNyRSxNQUFNLHNCQUFzQixjQUFjLFdBQVcsRUFBRSxRQUFRLHVCQUF1QixPQUFPO1FBQzdGLE1BQU0sY0FBYyxjQUFjLE1BQU0sSUFBSTtRQUU1QyxnQkFDRSxDQUFDLGNBQWMsRUFBRSxjQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQ25DLG9CQUFvQixlQUFlLGNBQWMsRUFBRSxFQUFFLHFCQUFxQjtNQUU5RTtJQUNGO0lBRUEsa0VBQWtFO0lBQ2xFLHFFQUFxRTtJQUNyRSxrRUFBa0U7SUFDbEUsd0ZBQXdGO0lBQ3hGLElBQUksZUFBZSxLQUFLLFVBQVUsQ0FBQyxtQkFBbUI7TUFDcEQsTUFBTSxtQkFBbUIsZ0JBQ3RCLE1BQU0sQ0FBQyxDQUFBLElBQUssaUJBQWlCLEdBQUcsQ0FBQyxnQkFBZ0IsT0FBTyxDQUFDLEtBQ3pELEdBQUcsQ0FBQyxDQUFBLElBQUssRUFBRSxFQUFFO01BRWhCLElBQUksaUJBQWlCLE1BQU0sR0FBRyxHQUFHO1FBQy9CLGdCQUNFLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLEVBQzNCLHVCQUF1QixlQUFlLFFBQVE7TUFFbEQ7SUFDRjtJQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztNQUFNLFNBQVM7SUFBYSxJQUN0RDtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLDJCQUEyQjtJQUN6QyxNQUFNLGVBQWUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDOUQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQWEsSUFDckM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
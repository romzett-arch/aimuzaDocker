import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
const FILE_UPLOAD_BASE = "https://sunoapiorg.redpandaai.co";
// Map artist names to genre/style descriptions (Suno doesn't allow artist names)
const artistToStyleMap = {
  "Drake": "moody trap hip-hop with melodic hooks",
  "The Weeknd": "dark synth-pop R&B with falsetto vocals",
  "Taylor Swift": "catchy pop-country with storytelling lyrics",
  "Ed Sheeran": "acoustic pop folk with romantic themes",
  "Billie Eilish": "dark minimalist pop with whispered vocals",
  "Ariana Grande": "powerful pop R&B with high vocals",
  "Dua Lipa": "disco-influenced dance pop",
  "Bad Bunny": "reggaeton latin trap with urban beats",
  "Post Malone": "melodic hip-hop rock fusion",
  "Kendrick Lamar": "conscious lyrical hip-hop",
  "Beyoncé": "powerful R&B pop with soulful vocals",
  "Bruno Mars": "funk pop with retro grooves",
  "Adele": "powerful ballads with soulful vocals",
  "Coldplay": "anthemic alternative rock with atmospheric synths"
};
function convertArtistToStyle(artistName) {
  if (artistToStyleMap[artistName]) {
    return artistToStyleMap[artistName];
  }
  const lowerName = artistName.toLowerCase();
  for (const [artist, style] of Object.entries(artistToStyleMap)){
    if (artist.toLowerCase() === lowerName) {
      return style;
    }
  }
  return "contemporary pop with modern production";
}
function cleanStyleForSuno(style) {
  if (!style) return "";
  let cleanedStyle = style;
  for (const artistName of Object.keys(artistToStyleMap)){
    const regex = new RegExp(`${artistName}\\s*style`, "gi");
    if (regex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(regex, convertArtistToStyle(artistName));
    }
    const standaloneRegex = new RegExp(`\\b${artistName}\\b`, "gi");
    if (standaloneRegex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(standaloneRegex, convertArtistToStyle(artistName));
    }
  }
  cleanedStyle = cleanedStyle.replace(/,\s*,/g, ",").replace(/\s+/g, " ").trim();
  return cleanedStyle;
}
/**
 * Upload file to Suno API via URL method
 */ async function uploadFileToSuno(fileUrl) {
  console.log(`Uploading file to Suno from URL: ${fileUrl}`);
  // Send both parameter names for API compatibility
  const requestBody = {
    fileUrl: fileUrl,
    uploadPath: fileUrl,
    url: fileUrl
  };
  console.log("Upload request body:", JSON.stringify(requestBody));
  const response = await fetch(`${FILE_UPLOAD_BASE}/api/file-url-upload`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${SUNO_API_KEY}`
    },
    body: JSON.stringify(requestBody)
  });
  const data = await response.json();
  console.log("File upload response:", JSON.stringify(data));
  if (!response.ok || data.code && data.code !== 200) {
    throw new Error(data.msg || "Failed to upload file to Suno");
  }
  // Response contains downloadUrl for the uploaded file
  const uploadedUrl = data.data?.downloadUrl || data.data?.url || data.data || data.downloadUrl || data.url;
  console.log("Uploaded file URL:", uploadedUrl);
  return uploadedUrl;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { trackId, sourceAudioUrl, prompt, style, title } = await req.json();
    if (!trackId || !sourceAudioUrl) {
      return new Response(JSON.stringify({
        error: "Missing required fields: trackId, sourceAudioUrl"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (!prompt) {
      return new Response(JSON.stringify({
        error: "Missing required field: prompt (lyrics for vocals)"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Starting upload-add-vocal for track ${trackId} by user ${user.id}`);
    console.log(`Source audio: ${sourceAudioUrl}`);
    console.log(`Style: ${style}, Prompt length: ${prompt.length}`);
    // Clean the style to remove artist names
    const cleanedStyle = cleanStyleForSuno(style || "");
    console.log(`Cleaned style: ${cleanedStyle}`);
    // Update track status to processing
    const { error: updateError } = await supabaseClient.from("tracks").update({
      status: "processing",
      error_message: null
    }).eq("id", trackId).eq("user_id", user.id);
    if (updateError) {
      console.error("Failed to update track status:", updateError);
    }
    // Step 1: Upload the source audio to Suno's servers
    let sunoUploadUrl;
    try {
      sunoUploadUrl = await uploadFileToSuno(sourceAudioUrl);
      console.log(`File uploaded to Suno: ${sunoUploadUrl}`);
    } catch (uploadError) {
      console.error("Failed to upload file to Suno:", uploadError);
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: "Не удалось загрузить аудио для обработки"
      }).eq("id", trackId);
      return new Response(JSON.stringify({
        error: "Failed to upload audio file"
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Step 2: Call Suno upload-extend endpoint (for adding vocals to instrumental)
    // Using upload-extend API: POST /api/v1/generate/upload-extend
    // Required params: uploadUrl, defaultParamFlag, continueAt, instrumental, prompt, model, callBackUrl
    // NOTE: continueAt must be > 0 according to API docs, use 0.01 as minimum
    const sunoPayload = {
      uploadUrl: sunoUploadUrl,
      defaultParamFlag: true,
      continueAt: 0.01,
      instrumental: false,
      prompt: prompt,
      model: "V4",
      callBackUrl: `${Deno.env.get("SUPABASE_URL")}/functions/v1/suno-callback`
    };
    // Add style if provided (max 200 chars for V4)
    if (cleanedStyle) {
      sunoPayload.style = cleanedStyle.slice(0, 200);
    }
    console.log("Sending to Suno upload-extend API:", JSON.stringify(sunoPayload));
    const sunoResponse = await fetch(`${SUNO_API_BASE}/api/v1/generate/upload-extend`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify(sunoPayload)
    });
    const sunoData = await sunoResponse.json();
    console.log("Suno upload-extend response:", JSON.stringify(sunoData));
    if (!sunoResponse.ok || sunoData.code !== 200) {
      const errorMessage = sunoData.msg || "Failed to start vocal generation";
      console.error(`Suno API error: ${errorMessage}`);
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: errorMessage
      }).eq("id", trackId).eq("user_id", user.id);
      return new Response(JSON.stringify({
        error: errorMessage,
        details: sunoData
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const taskId = sunoData.data?.taskId;
    console.log(`Vocal generation started with task ID: ${taskId}`);
    return new Response(JSON.stringify({
      success: true,
      taskId,
      message: "Vocal generation started successfully"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in upload-add-vocal:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy91cGxvYWQtYWRkLXZvY2FsL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE2OC4wL2h0dHAvc2VydmVyLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuY29uc3QgU1VOT19BUElfS0VZID0gRGVuby5lbnYuZ2V0KFwiU1VOT19BUElfS0VZXCIpO1xuY29uc3QgU1VOT19BUElfQkFTRSA9IFwiaHR0cHM6Ly9hcGlib3guZXJ3ZWltYS5haVwiO1xuY29uc3QgRklMRV9VUExPQURfQkFTRSA9IFwiaHR0cHM6Ly9zdW5vYXBpb3JnLnJlZHBhbmRhYWkuY29cIjtcblxuLy8gTWFwIGFydGlzdCBuYW1lcyB0byBnZW5yZS9zdHlsZSBkZXNjcmlwdGlvbnMgKFN1bm8gZG9lc24ndCBhbGxvdyBhcnRpc3QgbmFtZXMpXG5jb25zdCBhcnRpc3RUb1N0eWxlTWFwOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICBcIkRyYWtlXCI6IFwibW9vZHkgdHJhcCBoaXAtaG9wIHdpdGggbWVsb2RpYyBob29rc1wiLFxuICBcIlRoZSBXZWVrbmRcIjogXCJkYXJrIHN5bnRoLXBvcCBSJkIgd2l0aCBmYWxzZXR0byB2b2NhbHNcIixcbiAgXCJUYXlsb3IgU3dpZnRcIjogXCJjYXRjaHkgcG9wLWNvdW50cnkgd2l0aCBzdG9yeXRlbGxpbmcgbHlyaWNzXCIsXG4gIFwiRWQgU2hlZXJhblwiOiBcImFjb3VzdGljIHBvcCBmb2xrIHdpdGggcm9tYW50aWMgdGhlbWVzXCIsXG4gIFwiQmlsbGllIEVpbGlzaFwiOiBcImRhcmsgbWluaW1hbGlzdCBwb3Agd2l0aCB3aGlzcGVyZWQgdm9jYWxzXCIsXG4gIFwiQXJpYW5hIEdyYW5kZVwiOiBcInBvd2VyZnVsIHBvcCBSJkIgd2l0aCBoaWdoIHZvY2Fsc1wiLFxuICBcIkR1YSBMaXBhXCI6IFwiZGlzY28taW5mbHVlbmNlZCBkYW5jZSBwb3BcIixcbiAgXCJCYWQgQnVubnlcIjogXCJyZWdnYWV0b24gbGF0aW4gdHJhcCB3aXRoIHVyYmFuIGJlYXRzXCIsXG4gIFwiUG9zdCBNYWxvbmVcIjogXCJtZWxvZGljIGhpcC1ob3Agcm9jayBmdXNpb25cIixcbiAgXCJLZW5kcmljayBMYW1hclwiOiBcImNvbnNjaW91cyBseXJpY2FsIGhpcC1ob3BcIixcbiAgXCJCZXlvbmPDqVwiOiBcInBvd2VyZnVsIFImQiBwb3Agd2l0aCBzb3VsZnVsIHZvY2Fsc1wiLFxuICBcIkJydW5vIE1hcnNcIjogXCJmdW5rIHBvcCB3aXRoIHJldHJvIGdyb292ZXNcIixcbiAgXCJBZGVsZVwiOiBcInBvd2VyZnVsIGJhbGxhZHMgd2l0aCBzb3VsZnVsIHZvY2Fsc1wiLFxuICBcIkNvbGRwbGF5XCI6IFwiYW50aGVtaWMgYWx0ZXJuYXRpdmUgcm9jayB3aXRoIGF0bW9zcGhlcmljIHN5bnRoc1wiLFxufTtcblxuZnVuY3Rpb24gY29udmVydEFydGlzdFRvU3R5bGUoYXJ0aXN0TmFtZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgaWYgKGFydGlzdFRvU3R5bGVNYXBbYXJ0aXN0TmFtZV0pIHtcbiAgICByZXR1cm4gYXJ0aXN0VG9TdHlsZU1hcFthcnRpc3ROYW1lXTtcbiAgfVxuICBjb25zdCBsb3dlck5hbWUgPSBhcnRpc3ROYW1lLnRvTG93ZXJDYXNlKCk7XG4gIGZvciAoY29uc3QgW2FydGlzdCwgc3R5bGVdIG9mIE9iamVjdC5lbnRyaWVzKGFydGlzdFRvU3R5bGVNYXApKSB7XG4gICAgaWYgKGFydGlzdC50b0xvd2VyQ2FzZSgpID09PSBsb3dlck5hbWUpIHtcbiAgICAgIHJldHVybiBzdHlsZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIFwiY29udGVtcG9yYXJ5IHBvcCB3aXRoIG1vZGVybiBwcm9kdWN0aW9uXCI7XG59XG5cbmZ1bmN0aW9uIGNsZWFuU3R5bGVGb3JTdW5vKHN0eWxlOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoIXN0eWxlKSByZXR1cm4gXCJcIjtcbiAgXG4gIGxldCBjbGVhbmVkU3R5bGUgPSBzdHlsZTtcbiAgZm9yIChjb25zdCBhcnRpc3ROYW1lIG9mIE9iamVjdC5rZXlzKGFydGlzdFRvU3R5bGVNYXApKSB7XG4gICAgY29uc3QgcmVnZXggPSBuZXcgUmVnRXhwKGAke2FydGlzdE5hbWV9XFxcXHMqc3R5bGVgLCBcImdpXCIpO1xuICAgIGlmIChyZWdleC50ZXN0KGNsZWFuZWRTdHlsZSkpIHtcbiAgICAgIGNsZWFuZWRTdHlsZSA9IGNsZWFuZWRTdHlsZS5yZXBsYWNlKHJlZ2V4LCBjb252ZXJ0QXJ0aXN0VG9TdHlsZShhcnRpc3ROYW1lKSk7XG4gICAgfVxuICAgIGNvbnN0IHN0YW5kYWxvbmVSZWdleCA9IG5ldyBSZWdFeHAoYFxcXFxiJHthcnRpc3ROYW1lfVxcXFxiYCwgXCJnaVwiKTtcbiAgICBpZiAoc3RhbmRhbG9uZVJlZ2V4LnRlc3QoY2xlYW5lZFN0eWxlKSkge1xuICAgICAgY2xlYW5lZFN0eWxlID0gY2xlYW5lZFN0eWxlLnJlcGxhY2Uoc3RhbmRhbG9uZVJlZ2V4LCBjb252ZXJ0QXJ0aXN0VG9TdHlsZShhcnRpc3ROYW1lKSk7XG4gICAgfVxuICB9XG4gIFxuICBjbGVhbmVkU3R5bGUgPSBjbGVhbmVkU3R5bGUucmVwbGFjZSgvLFxccyosL2csIFwiLFwiKS5yZXBsYWNlKC9cXHMrL2csIFwiIFwiKS50cmltKCk7XG4gIHJldHVybiBjbGVhbmVkU3R5bGU7XG59XG5cbi8qKlxuICogVXBsb2FkIGZpbGUgdG8gU3VubyBBUEkgdmlhIFVSTCBtZXRob2RcbiAqL1xuYXN5bmMgZnVuY3Rpb24gdXBsb2FkRmlsZVRvU3VubyhmaWxlVXJsOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zb2xlLmxvZyhgVXBsb2FkaW5nIGZpbGUgdG8gU3VubyBmcm9tIFVSTDogJHtmaWxlVXJsfWApO1xuICBcbiAgLy8gU2VuZCBib3RoIHBhcmFtZXRlciBuYW1lcyBmb3IgQVBJIGNvbXBhdGliaWxpdHlcbiAgY29uc3QgcmVxdWVzdEJvZHkgPSB7IFxuICAgIGZpbGVVcmw6IGZpbGVVcmwsXG4gICAgdXBsb2FkUGF0aDogZmlsZVVybCxcbiAgICB1cmw6IGZpbGVVcmwgXG4gIH07XG4gIGNvbnNvbGUubG9nKFwiVXBsb2FkIHJlcXVlc3QgYm9keTpcIiwgSlNPTi5zdHJpbmdpZnkocmVxdWVzdEJvZHkpKTtcbiAgXG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7RklMRV9VUExPQURfQkFTRX0vYXBpL2ZpbGUtdXJsLXVwbG9hZGAsIHtcbiAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgIGhlYWRlcnM6IHtcbiAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICB9LFxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlcXVlc3RCb2R5KSxcbiAgfSk7XG5cbiAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgY29uc29sZS5sb2coXCJGaWxlIHVwbG9hZCByZXNwb25zZTpcIiwgSlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xuICBcbiAgaWYgKCFyZXNwb25zZS5vayB8fCAoZGF0YS5jb2RlICYmIGRhdGEuY29kZSAhPT0gMjAwKSkge1xuICAgIHRocm93IG5ldyBFcnJvcihkYXRhLm1zZyB8fCBcIkZhaWxlZCB0byB1cGxvYWQgZmlsZSB0byBTdW5vXCIpO1xuICB9XG4gIFxuICAvLyBSZXNwb25zZSBjb250YWlucyBkb3dubG9hZFVybCBmb3IgdGhlIHVwbG9hZGVkIGZpbGVcbiAgY29uc3QgdXBsb2FkZWRVcmwgPSBkYXRhLmRhdGE/LmRvd25sb2FkVXJsIHx8IGRhdGEuZGF0YT8udXJsIHx8IGRhdGEuZGF0YSB8fCBkYXRhLmRvd25sb2FkVXJsIHx8IGRhdGEudXJsO1xuICBjb25zb2xlLmxvZyhcIlVwbG9hZGVkIGZpbGUgVVJMOlwiLCB1cGxvYWRlZFVybCk7XG4gIHJldHVybiB1cGxvYWRlZFVybDtcbn1cblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJObyBhdXRob3JpemF0aW9uIGhlYWRlclwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgc3VwYWJhc2VDbGllbnQgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgPz8gXCJcIixcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX0FOT05fS0VZXCIpID8/IFwiXCIsXG4gICAgICB7IGdsb2JhbDogeyBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGF1dGhIZWFkZXIgfSB9IH1cbiAgICApO1xuXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IHVzZXJFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnQuYXV0aC5nZXRVc2VyKCk7XG4gICAgaWYgKHVzZXJFcnJvciB8fCAhdXNlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHsgXG4gICAgICB0cmFja0lkLCBcbiAgICAgIHNvdXJjZUF1ZGlvVXJsLCAgLy8gVVJMIG9mIHVwbG9hZGVkIGluc3RydW1lbnRhbCBhdWRpbyBmaWxlXG4gICAgICBwcm9tcHQsICAgICAgICAgIC8vIEx5cmljcyB0ZXh0IGZvciB2b2NhbHNcbiAgICAgIHN0eWxlLCAgICAgICAgICAgLy8gTXVzaWMgc3R5bGVcbiAgICAgIHRpdGxlLCBcbiAgICB9ID0gYXdhaXQgcmVxLmpzb24oKTtcblxuICAgIGlmICghdHJhY2tJZCB8fCAhc291cmNlQXVkaW9VcmwpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiTWlzc2luZyByZXF1aXJlZCBmaWVsZHM6IHRyYWNrSWQsIHNvdXJjZUF1ZGlvVXJsXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAoIXByb21wdCkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJNaXNzaW5nIHJlcXVpcmVkIGZpZWxkOiBwcm9tcHQgKGx5cmljcyBmb3Igdm9jYWxzKVwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFN0YXJ0aW5nIHVwbG9hZC1hZGQtdm9jYWwgZm9yIHRyYWNrICR7dHJhY2tJZH0gYnkgdXNlciAke3VzZXIuaWR9YCk7XG4gICAgY29uc29sZS5sb2coYFNvdXJjZSBhdWRpbzogJHtzb3VyY2VBdWRpb1VybH1gKTtcbiAgICBjb25zb2xlLmxvZyhgU3R5bGU6ICR7c3R5bGV9LCBQcm9tcHQgbGVuZ3RoOiAke3Byb21wdC5sZW5ndGh9YCk7XG5cbiAgICAvLyBDbGVhbiB0aGUgc3R5bGUgdG8gcmVtb3ZlIGFydGlzdCBuYW1lc1xuICAgIGNvbnN0IGNsZWFuZWRTdHlsZSA9IGNsZWFuU3R5bGVGb3JTdW5vKHN0eWxlIHx8IFwiXCIpO1xuICAgIGNvbnNvbGUubG9nKGBDbGVhbmVkIHN0eWxlOiAke2NsZWFuZWRTdHlsZX1gKTtcblxuICAgIC8vIFVwZGF0ZSB0cmFjayBzdGF0dXMgdG8gcHJvY2Vzc2luZ1xuICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiLCBlcnJvcl9tZXNzYWdlOiBudWxsIH0pXG4gICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcblxuICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgdHJhY2sgc3RhdHVzOlwiLCB1cGRhdGVFcnJvcik7XG4gICAgfVxuXG4gICAgLy8gU3RlcCAxOiBVcGxvYWQgdGhlIHNvdXJjZSBhdWRpbyB0byBTdW5vJ3Mgc2VydmVyc1xuICAgIGxldCBzdW5vVXBsb2FkVXJsOiBzdHJpbmc7XG4gICAgdHJ5IHtcbiAgICAgIHN1bm9VcGxvYWRVcmwgPSBhd2FpdCB1cGxvYWRGaWxlVG9TdW5vKHNvdXJjZUF1ZGlvVXJsKTtcbiAgICAgIGNvbnNvbGUubG9nKGBGaWxlIHVwbG9hZGVkIHRvIFN1bm86ICR7c3Vub1VwbG9hZFVybH1gKTtcbiAgICB9IGNhdGNoICh1cGxvYWRFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGxvYWQgZmlsZSB0byBTdW5vOlwiLCB1cGxvYWRFcnJvcik7XG4gICAgICBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAudXBkYXRlKHsgXG4gICAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLFxuICAgICAgICAgIGVycm9yX21lc3NhZ2U6IFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQt9Cw0LPRgNGD0LfQuNGC0Ywg0LDRg9C00LjQviDQtNC70Y8g0L7QsdGA0LDQsdC+0YLQutC4XCJcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZCk7XG4gICAgICBcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiRmFpbGVkIHRvIHVwbG9hZCBhdWRpbyBmaWxlXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBTdGVwIDI6IENhbGwgU3VubyB1cGxvYWQtZXh0ZW5kIGVuZHBvaW50IChmb3IgYWRkaW5nIHZvY2FscyB0byBpbnN0cnVtZW50YWwpXG4gICAgLy8gVXNpbmcgdXBsb2FkLWV4dGVuZCBBUEk6IFBPU1QgL2FwaS92MS9nZW5lcmF0ZS91cGxvYWQtZXh0ZW5kXG4gICAgLy8gUmVxdWlyZWQgcGFyYW1zOiB1cGxvYWRVcmwsIGRlZmF1bHRQYXJhbUZsYWcsIGNvbnRpbnVlQXQsIGluc3RydW1lbnRhbCwgcHJvbXB0LCBtb2RlbCwgY2FsbEJhY2tVcmxcbiAgICAvLyBOT1RFOiBjb250aW51ZUF0IG11c3QgYmUgPiAwIGFjY29yZGluZyB0byBBUEkgZG9jcywgdXNlIDAuMDEgYXMgbWluaW11bVxuICAgIGNvbnN0IHN1bm9QYXlsb2FkOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHtcbiAgICAgIHVwbG9hZFVybDogc3Vub1VwbG9hZFVybCxcbiAgICAgIGRlZmF1bHRQYXJhbUZsYWc6IHRydWUsICAgLy8gUmVxdWlyZWQgLSB1c2UgY3VzdG9tIHBhcmFtcyAobXVzdCBiZSB0cnVlIHdoZW4gcHJvdmlkaW5nIHN0eWxlL3Byb21wdClcbiAgICAgIGNvbnRpbnVlQXQ6IDAuMDEsICAgICAgICAgLy8gUmVxdWlyZWQgLSBtdXN0IGJlID4gMCAoc2Vjb25kcylcbiAgICAgIGluc3RydW1lbnRhbDogZmFsc2UsICAgICAgLy8gV2Ugd2FudCB2b2NhbHMgYWRkZWRcbiAgICAgIHByb21wdDogcHJvbXB0LCAgICAgICAgICAgLy8gVGhlIGx5cmljc1xuICAgICAgbW9kZWw6IFwiVjRcIixcbiAgICAgIGNhbGxCYWNrVXJsOiBgJHtEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIil9L2Z1bmN0aW9ucy92MS9zdW5vLWNhbGxiYWNrYCxcbiAgICB9O1xuXG4gICAgLy8gQWRkIHN0eWxlIGlmIHByb3ZpZGVkIChtYXggMjAwIGNoYXJzIGZvciBWNClcbiAgICBpZiAoY2xlYW5lZFN0eWxlKSB7XG4gICAgICBzdW5vUGF5bG9hZC5zdHlsZSA9IGNsZWFuZWRTdHlsZS5zbGljZSgwLCAyMDApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKFwiU2VuZGluZyB0byBTdW5vIHVwbG9hZC1leHRlbmQgQVBJOlwiLCBKU09OLnN0cmluZ2lmeShzdW5vUGF5bG9hZCkpO1xuXG4gICAgY29uc3Qgc3Vub1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7U1VOT19BUElfQkFTRX0vYXBpL3YxL2dlbmVyYXRlL3VwbG9hZC1leHRlbmRgLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShzdW5vUGF5bG9hZCksXG4gICAgfSk7XG5cbiAgICBjb25zdCBzdW5vRGF0YSA9IGF3YWl0IHN1bm9SZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJTdW5vIHVwbG9hZC1leHRlbmQgcmVzcG9uc2U6XCIsIEpTT04uc3RyaW5naWZ5KHN1bm9EYXRhKSk7XG5cbiAgICBpZiAoIXN1bm9SZXNwb25zZS5vayB8fCBzdW5vRGF0YS5jb2RlICE9PSAyMDApIHtcbiAgICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IHN1bm9EYXRhLm1zZyB8fCBcIkZhaWxlZCB0byBzdGFydCB2b2NhbCBnZW5lcmF0aW9uXCI7XG4gICAgICBjb25zb2xlLmVycm9yKGBTdW5vIEFQSSBlcnJvcjogJHtlcnJvck1lc3NhZ2V9YCk7XG4gICAgICBcbiAgICAgIGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgIC51cGRhdGUoeyBcbiAgICAgICAgICBzdGF0dXM6IFwiZmFpbGVkXCIsXG4gICAgICAgICAgZXJyb3JfbWVzc2FnZTogZXJyb3JNZXNzYWdlXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZCk7XG5cbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgZXJyb3I6IGVycm9yTWVzc2FnZSxcbiAgICAgICAgICBkZXRhaWxzOiBzdW5vRGF0YSBcbiAgICAgICAgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB0YXNrSWQgPSBzdW5vRGF0YS5kYXRhPy50YXNrSWQ7XG4gICAgY29uc29sZS5sb2coYFZvY2FsIGdlbmVyYXRpb24gc3RhcnRlZCB3aXRoIHRhc2sgSUQ6ICR7dGFza0lkfWApO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICB0YXNrSWQsXG4gICAgICAgIG1lc3NhZ2U6IFwiVm9jYWwgZ2VuZXJhdGlvbiBzdGFydGVkIHN1Y2Nlc3NmdWxseVwiIFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gdXBsb2FkLWFkZC12b2NhbDpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGVycm9yTWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2xDLE1BQU0sZ0JBQWdCO0FBQ3RCLE1BQU0sbUJBQW1CO0FBRXpCLGlGQUFpRjtBQUNqRixNQUFNLG1CQUEyQztFQUMvQyxTQUFTO0VBQ1QsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGlCQUFpQjtFQUNqQixZQUFZO0VBQ1osYUFBYTtFQUNiLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLGNBQWM7RUFDZCxTQUFTO0VBQ1QsWUFBWTtBQUNkO0FBRUEsU0FBUyxxQkFBcUIsVUFBa0I7RUFDOUMsSUFBSSxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUU7SUFDaEMsT0FBTyxnQkFBZ0IsQ0FBQyxXQUFXO0VBQ3JDO0VBQ0EsTUFBTSxZQUFZLFdBQVcsV0FBVztFQUN4QyxLQUFLLE1BQU0sQ0FBQyxRQUFRLE1BQU0sSUFBSSxPQUFPLE9BQU8sQ0FBQyxrQkFBbUI7SUFDOUQsSUFBSSxPQUFPLFdBQVcsT0FBTyxXQUFXO01BQ3RDLE9BQU87SUFDVDtFQUNGO0VBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxrQkFBa0IsS0FBYTtFQUN0QyxJQUFJLENBQUMsT0FBTyxPQUFPO0VBRW5CLElBQUksZUFBZTtFQUNuQixLQUFLLE1BQU0sY0FBYyxPQUFPLElBQUksQ0FBQyxrQkFBbUI7SUFDdEQsTUFBTSxRQUFRLElBQUksT0FBTyxDQUFDLEVBQUUsV0FBVyxTQUFTLENBQUMsRUFBRTtJQUNuRCxJQUFJLE1BQU0sSUFBSSxDQUFDLGVBQWU7TUFDNUIsZUFBZSxhQUFhLE9BQU8sQ0FBQyxPQUFPLHFCQUFxQjtJQUNsRTtJQUNBLE1BQU0sa0JBQWtCLElBQUksT0FBTyxDQUFDLEdBQUcsRUFBRSxXQUFXLEdBQUcsQ0FBQyxFQUFFO0lBQzFELElBQUksZ0JBQWdCLElBQUksQ0FBQyxlQUFlO01BQ3RDLGVBQWUsYUFBYSxPQUFPLENBQUMsaUJBQWlCLHFCQUFxQjtJQUM1RTtFQUNGO0VBRUEsZUFBZSxhQUFhLE9BQU8sQ0FBQyxVQUFVLEtBQUssT0FBTyxDQUFDLFFBQVEsS0FBSyxJQUFJO0VBQzVFLE9BQU87QUFDVDtBQUVBOztDQUVDLEdBQ0QsZUFBZSxpQkFBaUIsT0FBZTtFQUM3QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLGlDQUFpQyxFQUFFLFFBQVEsQ0FBQztFQUV6RCxrREFBa0Q7RUFDbEQsTUFBTSxjQUFjO0lBQ2xCLFNBQVM7SUFDVCxZQUFZO0lBQ1osS0FBSztFQUNQO0VBQ0EsUUFBUSxHQUFHLENBQUMsd0JBQXdCLEtBQUssU0FBUyxDQUFDO0VBRW5ELE1BQU0sV0FBVyxNQUFNLE1BQU0sQ0FBQyxFQUFFLGlCQUFpQixvQkFBb0IsQ0FBQyxFQUFFO0lBQ3RFLFFBQVE7SUFDUixTQUFTO01BQ1AsZ0JBQWdCO01BQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7SUFDM0M7SUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO0VBQ3ZCO0VBRUEsTUFBTSxPQUFPLE1BQU0sU0FBUyxJQUFJO0VBQ2hDLFFBQVEsR0FBRyxDQUFDLHlCQUF5QixLQUFLLFNBQVMsQ0FBQztFQUVwRCxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUssS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssS0FBTTtJQUNwRCxNQUFNLElBQUksTUFBTSxLQUFLLEdBQUcsSUFBSTtFQUM5QjtFQUVBLHNEQUFzRDtFQUN0RCxNQUFNLGNBQWMsS0FBSyxJQUFJLEVBQUUsZUFBZSxLQUFLLElBQUksRUFBRSxPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUssV0FBVyxJQUFJLEtBQUssR0FBRztFQUN6RyxRQUFRLEdBQUcsQ0FBQyxzQkFBc0I7RUFDbEMsT0FBTztBQUNUO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEwQixJQUNsRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGlCQUFpQixhQUNyQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFDckM7TUFBRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQUU7SUFHdkQsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sZUFBZSxJQUFJLENBQUMsT0FBTztJQUM5RSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFlLElBQ3ZDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sRUFDSixPQUFPLEVBQ1AsY0FBYyxFQUNkLE1BQU0sRUFDTixLQUFLLEVBQ0wsS0FBSyxFQUNOLEdBQUcsTUFBTSxJQUFJLElBQUk7SUFFbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0I7TUFDL0IsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQW1ELElBQzNFO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLElBQUksQ0FBQyxRQUFRO01BQ1gsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQXFELElBQzdFO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsb0NBQW9DLEVBQUUsUUFBUSxTQUFTLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUMvRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGNBQWMsRUFBRSxlQUFlLENBQUM7SUFDN0MsUUFBUSxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0lBRTlELHlDQUF5QztJQUN6QyxNQUFNLGVBQWUsa0JBQWtCLFNBQVM7SUFDaEQsUUFBUSxHQUFHLENBQUMsQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDO0lBRTVDLG9DQUFvQztJQUNwQyxNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLGVBQ2xDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztNQUFFLFFBQVE7TUFBYyxlQUFlO0lBQUssR0FDbkQsRUFBRSxDQUFDLE1BQU0sU0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUU7SUFFeEIsSUFBSSxhQUFhO01BQ2YsUUFBUSxLQUFLLENBQUMsa0NBQWtDO0lBQ2xEO0lBRUEsb0RBQW9EO0lBQ3BELElBQUk7SUFDSixJQUFJO01BQ0YsZ0JBQWdCLE1BQU0saUJBQWlCO01BQ3ZDLFFBQVEsR0FBRyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsY0FBYyxDQUFDO0lBQ3ZELEVBQUUsT0FBTyxhQUFhO01BQ3BCLFFBQVEsS0FBSyxDQUFDLGtDQUFrQztNQUNoRCxNQUFNLGVBQ0gsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sUUFBUTtRQUNSLGVBQWU7TUFDakIsR0FDQyxFQUFFLENBQUMsTUFBTTtNQUVaLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE4QixJQUN0RDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSwrRUFBK0U7SUFDL0UsK0RBQStEO0lBQy9ELHFHQUFxRztJQUNyRywwRUFBMEU7SUFDMUUsTUFBTSxjQUF1QztNQUMzQyxXQUFXO01BQ1gsa0JBQWtCO01BQ2xCLFlBQVk7TUFDWixjQUFjO01BQ2QsUUFBUTtNQUNSLE9BQU87TUFDUCxhQUFhLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLDJCQUEyQixDQUFDO0lBQzNFO0lBRUEsK0NBQStDO0lBQy9DLElBQUksY0FBYztNQUNoQixZQUFZLEtBQUssR0FBRyxhQUFhLEtBQUssQ0FBQyxHQUFHO0lBQzVDO0lBRUEsUUFBUSxHQUFHLENBQUMsc0NBQXNDLEtBQUssU0FBUyxDQUFDO0lBRWpFLE1BQU0sZUFBZSxNQUFNLE1BQU0sQ0FBQyxFQUFFLGNBQWMsOEJBQThCLENBQUMsRUFBRTtNQUNqRixRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDO01BQzNDO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztJQUN2QjtJQUVBLE1BQU0sV0FBVyxNQUFNLGFBQWEsSUFBSTtJQUN4QyxRQUFRLEdBQUcsQ0FBQyxnQ0FBZ0MsS0FBSyxTQUFTLENBQUM7SUFFM0QsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLFNBQVMsSUFBSSxLQUFLLEtBQUs7TUFDN0MsTUFBTSxlQUFlLFNBQVMsR0FBRyxJQUFJO01BQ3JDLFFBQVEsS0FBSyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDO01BRS9DLE1BQU0sZUFDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7UUFDTixRQUFRO1FBQ1IsZUFBZTtNQUNqQixHQUNDLEVBQUUsQ0FBQyxNQUFNLFNBQ1QsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFO01BRXhCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQ2IsT0FBTztRQUNQLFNBQVM7TUFDWCxJQUNBO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sU0FBUyxTQUFTLElBQUksRUFBRTtJQUM5QixRQUFRLEdBQUcsQ0FBQyxDQUFDLHVDQUF1QyxFQUFFLE9BQU8sQ0FBQztJQUU5RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVDtNQUNBLFNBQVM7SUFDWCxJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsOEJBQThCO0lBQzVDLE1BQU0sZUFBZSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUM5RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBYSxJQUNyQztNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRiJ9
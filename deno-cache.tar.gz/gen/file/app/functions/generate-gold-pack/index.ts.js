import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
// Generate SILK-compatible XML metadata
function generateSilkXml(track) {
  const now = new Date().toISOString();
  const releaseDate = track.processing_completed_at || now;
  const genreName = track.genre?.[0]?.name || 'Electronic';
  const genreNameRu = track.genre?.[0]?.name_ru || 'Электронная';
  const uploaderName = track.profiles?.[0]?.username || 'Unknown';
  return `<?xml version="1.0" encoding="UTF-8"?>
<release xmlns="http://silk.ru/schema/release/v1">
  <metadata>
    <format_version>1.0</format_version>
    <generated_at>${now}</generated_at>
    <generator>Notafeya Distribution Platform</generator>
  </metadata>
  
  <release_info>
    <internal_id>${track.id}</internal_id>
    <isrc>${track.isrc_code || 'PENDING'}</isrc>
    <title><![CDATA[${track.title}]]></title>
    <artist><![CDATA[${track.performer_name}]]></artist>
    <label><![CDATA[${track.label_name || 'Notafeya Records'}]]></label>
    <release_date>${releaseDate.split('T')[0]}</release_date>
    <genre>${genreName}</genre>
    <genre_ru>${genreNameRu}</genre_ru>
    <duration_seconds>${Math.round(track.duration || 0)}</duration_seconds>
  </release_info>
  
  <credits>
    <music_author><![CDATA[${track.music_author || track.performer_name}]]></music_author>
    <lyrics_author><![CDATA[${track.lyrics_author || 'Instrumental'}]]></lyrics_author>
    <performer><![CDATA[${track.performer_name}]]></performer>
    <producer><![CDATA[${track.performer_name}]]></producer>
    <uploader><![CDATA[${uploaderName}]]></uploader>
  </credits>
  
  <technical>
    <audio_format>WAV</audio_format>
    <bit_depth>24</bit_depth>
    <sample_rate>44100</sample_rate>
    <loudness_standard>-14 LUFS</loudness_standard>
    <mastered>true</mastered>
    <metadata_cleaned>true</metadata_cleaned>
  </technical>
  
  <blockchain>
    <hash>${track.blockchain_hash || 'N/A'}</hash>
    <timestamp>${releaseDate}</timestamp>
    <network>OpenTimestamps</network>
    <verified>true</verified>
  </blockchain>
  
  <assets>
    <master_audio>${track.master_audio_url ? 'included' : 'pending'}</master_audio>
    <cover_art resolution="3000x3000">${track.cover_url ? 'included' : 'pending'}</cover_art>
    <promo_video>not_available</promo_video>
    <certificate>${track.certificate_url ? 'included' : 'pending'}</certificate>
  </assets>
  
  <distribution>
    <platforms>
      <platform name="Spotify" status="ready"/>
      <platform name="Apple Music" status="ready"/>
      <platform name="Yandex Music" status="ready"/>
      <platform name="VK Music" status="ready"/>
      <platform name="Deezer" status="ready"/>
      <platform name="SoundCloud" status="ready"/>
    </platforms>
    <territory>Worldwide</territory>
    <exclusive>false</exclusive>
  </distribution>
  
  <legal>
    <copyright>© ${new Date().getFullYear()} ${track.label_name || 'Notafeya Records'}. All rights reserved.</copyright>
    <license>Standard Distribution License</license>
    <content_rating>Unrated</content_rating>
  </legal>
</release>`;
}
// Generate PDF certificate HTML (would be converted to PDF in production)
function generateCertificateHtml(track) {
  const now = new Date();
  const formattedDate = now.toLocaleDateString('ru-RU', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  return `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Сертификат авторства - ${track.title}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=Montserrat:wght@300;400;600&display=swap');
    
    * { margin: 0; padding: 0; box-sizing: border-box; }
    
    body {
      font-family: 'Montserrat', sans-serif;
      background: linear-gradient(135deg, #0f0f23 0%, #1a1a3e 50%, #0f0f23 100%);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 40px;
    }
    
    .certificate {
      background: linear-gradient(180deg, #fefefe 0%, #f8f6f0 100%);
      border: 3px solid #c9a962;
      border-radius: 8px;
      padding: 60px 80px;
      max-width: 800px;
      width: 100%;
      position: relative;
      box-shadow: 0 20px 60px rgba(0,0,0,0.5);
    }
    
    .certificate::before {
      content: '';
      position: absolute;
      top: 15px;
      left: 15px;
      right: 15px;
      bottom: 15px;
      border: 1px solid #c9a962;
      border-radius: 4px;
      pointer-events: none;
    }
    
    .header {
      text-align: center;
      margin-bottom: 40px;
    }
    
    .logo {
      font-family: 'Cormorant Garamond', serif;
      font-size: 18px;
      color: #666;
      letter-spacing: 4px;
      text-transform: uppercase;
      margin-bottom: 20px;
    }
    
    .title {
      font-family: 'Cormorant Garamond', serif;
      font-size: 42px;
      font-weight: 700;
      color: #1a1a2e;
      margin-bottom: 10px;
    }
    
    .subtitle {
      font-size: 14px;
      color: #666;
      letter-spacing: 2px;
      text-transform: uppercase;
    }
    
    .divider {
      height: 2px;
      background: linear-gradient(90deg, transparent, #c9a962, transparent);
      margin: 30px 0;
    }
    
    .content {
      text-align: center;
    }
    
    .track-title {
      font-family: 'Cormorant Garamond', serif;
      font-size: 28px;
      font-weight: 600;
      color: #1a1a2e;
      margin-bottom: 15px;
    }
    
    .track-artist {
      font-size: 18px;
      color: #444;
      margin-bottom: 30px;
    }
    
    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin: 30px 0;
      text-align: left;
    }
    
    .info-item {
      padding: 15px;
      background: rgba(201, 169, 98, 0.1);
      border-radius: 4px;
    }
    
    .info-label {
      font-size: 11px;
      color: #888;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 5px;
    }
    
    .info-value {
      font-size: 14px;
      color: #1a1a2e;
      font-weight: 500;
    }
    
    .blockchain-section {
      margin: 40px 0;
      padding: 25px;
      background: #1a1a2e;
      border-radius: 6px;
      color: white;
    }
    
    .blockchain-title {
      font-size: 12px;
      color: #c9a962;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin-bottom: 15px;
    }
    
    .blockchain-hash {
      font-family: 'Courier New', monospace;
      font-size: 11px;
      word-break: break-all;
      color: #8be9fd;
      background: rgba(0,0,0,0.3);
      padding: 15px;
      border-radius: 4px;
    }
    
    .footer {
      margin-top: 40px;
      text-align: center;
    }
    
    .seal {
      width: 100px;
      height: 100px;
      margin: 0 auto 20px;
      border: 3px solid #c9a962;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Cormorant Garamond', serif;
      font-size: 12px;
      color: #c9a962;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    
    .date {
      font-size: 14px;
      color: #666;
    }
    
    .certificate-id {
      margin-top: 15px;
      font-size: 11px;
      color: #999;
      letter-spacing: 1px;
    }
  </style>
</head>
<body>
  <div class="certificate">
    <div class="header">
      <div class="logo">♪ Notafeya Records ♪</div>
      <h1 class="title">Сертификат Авторства</h1>
      <p class="subtitle">Certificate of Authorship</p>
    </div>
    
    <div class="divider"></div>
    
    <div class="content">
      <h2 class="track-title">"${track.title}"</h2>
      <p class="track-artist">Исполнитель: ${track.performer_name}</p>
      
      <div class="info-grid">
        <div class="info-item">
          <div class="info-label">Автор музыки</div>
          <div class="info-value">${track.music_author || track.performer_name}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Автор текста</div>
          <div class="info-value">${track.lyrics_author || 'Инструментал'}</div>
        </div>
        <div class="info-item">
          <div class="info-label">ISRC код</div>
          <div class="info-value">${track.isrc_code || 'В обработке'}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Лейбл</div>
          <div class="info-value">${track.label_name || 'Notafeya Records'}</div>
        </div>
      </div>
      
      <div class="blockchain-section">
        <div class="blockchain-title">⛓ Blockchain Verification</div>
        <div class="blockchain-hash">${track.blockchain_hash || 'Hash pending...'}</div>
      </div>
    </div>
    
    <div class="footer">
      <div class="seal">Verified<br/>✓</div>
      <p class="date">${formattedDate}</p>
      <p class="certificate-id">ID: ${track.id.substring(0, 8).toUpperCase()}</p>
    </div>
  </div>
</body>
</html>`;
}
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '');
    const { trackId } = await req.json();
    console.log(`[generate-gold-pack] Starting for track: ${trackId}`);
    if (!trackId) {
      throw new Error('trackId is required');
    }
    // Get track with all metadata
    const { data: track, error: trackError } = await supabase.from('tracks').select(`
        id, title, performer_name, music_author, lyrics_author, label_name,
        isrc_code, duration, blockchain_hash, cover_url, master_audio_url,
        certificate_url, created_at, processing_completed_at,
        profiles:user_id(username),
        genre:genres(name_ru, name)
      `).eq('id', trackId).single();
    if (trackError || !track) {
      throw new Error('Track not found');
    }
    console.log(`[generate-gold-pack] Generating assets for: ${track.title}`);
    // Generate SILK XML metadata
    const xmlContent = generateSilkXml(track);
    const xmlFileName = `gold-packs/${trackId}/metadata_silk.xml`;
    const { error: xmlUploadError } = await supabase.storage.from('tracks').upload(xmlFileName, new Blob([
      xmlContent
    ], {
      type: 'application/xml'
    }), {
      upsert: true,
      contentType: 'application/xml'
    });
    if (xmlUploadError) {
      console.error('[generate-gold-pack] XML upload error:', xmlUploadError);
    }
    // Generate certificate HTML (in production would convert to PDF)
    const certificateHtml = generateCertificateHtml(track);
    const certificateFileName = `gold-packs/${trackId}/certificate.html`;
    const { error: certUploadError } = await supabase.storage.from('tracks').upload(certificateFileName, new Blob([
      certificateHtml
    ], {
      type: 'text/html'
    }), {
      upsert: true,
      contentType: 'text/html'
    });
    if (certUploadError) {
      console.error('[generate-gold-pack] Certificate upload error:', certUploadError);
    }
    // Get public URLs
    const { data: xmlUrl } = supabase.storage.from('tracks').getPublicUrl(xmlFileName);
    const { data: certUrl } = supabase.storage.from('tracks').getPublicUrl(certificateFileName);
    // Generate pack manifest
    const manifest = {
      version: '1.0',
      generated_at: new Date().toISOString(),
      track_id: track.id,
      track_title: track.title,
      artist: track.performer_name,
      isrc: track.isrc_code,
      blockchain_hash: track.blockchain_hash,
      contents: {
        master_audio: {
          format: 'WAV 24-bit/44.1kHz',
          url: track.master_audio_url,
          status: track.master_audio_url ? 'included' : 'pending'
        },
        cover_art: {
          format: 'JPEG 3000x3000',
          url: track.cover_url,
          status: track.cover_url ? 'included' : 'pending'
        },
        metadata: {
          format: 'SILK XML v1.0',
          url: xmlUrl.publicUrl,
          status: 'included'
        },
        certificate: {
          format: 'HTML/PDF',
          url: certUrl.publicUrl,
          status: 'included'
        },
        promo_video: {
          format: 'MP4 1080p',
          url: null,
          status: 'not_available'
        }
      },
      distribution: {
        platforms: [
          'Spotify',
          'Apple Music',
          'Yandex Music',
          'VK Music',
          'Deezer',
          'SoundCloud'
        ],
        territory: 'Worldwide',
        release_ready: true
      }
    };
    const manifestFileName = `gold-packs/${trackId}/manifest.json`;
    await supabase.storage.from('tracks').upload(manifestFileName, new Blob([
      JSON.stringify(manifest, null, 2)
    ], {
      type: 'application/json'
    }), {
      upsert: true,
      contentType: 'application/json'
    });
    const { data: manifestUrl } = supabase.storage.from('tracks').getPublicUrl(manifestFileName);
    // Update track with gold pack URL (manifest as entry point)
    await supabase.from('tracks').update({
      gold_pack_url: manifestUrl.publicUrl,
      certificate_url: certUrl.publicUrl
    }).eq('id', trackId);
    // Log the gold pack generation
    const { data: userData } = await supabase.from('tracks').select('user_id').eq('id', trackId).single();
    if (userData) {
      await supabase.from('distribution_logs').insert({
        track_id: trackId,
        user_id: userData.user_id,
        action: 'gold_pack_generated',
        stage: 'level_pro',
        details: {
          manifest_url: manifestUrl.publicUrl,
          xml_url: xmlUrl.publicUrl,
          certificate_url: certUrl.publicUrl,
          has_master: !!track.master_audio_url,
          has_cover: !!track.cover_url,
          has_video: false
        }
      });
      // Notify user
      await supabase.from('notifications').insert({
        user_id: userData.user_id,
        type: 'system',
        title: '📦 Золотой пакет SILK готов!',
        message: `Ваш трек "${track.title}" готов к дистрибуции. WAV, XML-метаданные и сертификат доступны для скачивания.`,
        target_type: 'track',
        target_id: trackId
      });
    }
    return new Response(JSON.stringify({
      success: true,
      goldPack: {
        manifestUrl: manifestUrl.publicUrl,
        xmlUrl: xmlUrl.publicUrl,
        certificateUrl: certUrl.publicUrl,
        masterAudioUrl: track.master_audio_url,
        coverUrl: track.cover_url,
        promoVideoUrl: null
      }
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('[generate-gold-pack] Error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({
      success: false,
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9nZW5lcmF0ZS1nb2xkLXBhY2svaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTY4LjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcbiAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnMnOiAnYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUnLFxufTtcblxuaW50ZXJmYWNlIEdvbGRQYWNrUmVxdWVzdCB7XG4gIHRyYWNrSWQ6IHN0cmluZztcbn1cblxuaW50ZXJmYWNlIFRyYWNrTWV0YWRhdGEge1xuICBpZDogc3RyaW5nO1xuICB0aXRsZTogc3RyaW5nO1xuICBwZXJmb3JtZXJfbmFtZTogc3RyaW5nO1xuICBtdXNpY19hdXRob3I6IHN0cmluZyB8IG51bGw7XG4gIGx5cmljc19hdXRob3I6IHN0cmluZyB8IG51bGw7XG4gIGxhYmVsX25hbWU6IHN0cmluZyB8IG51bGw7XG4gIGlzcmNfY29kZTogc3RyaW5nIHwgbnVsbDtcbiAgZHVyYXRpb246IG51bWJlcjtcbiAgZ2VucmU6IHsgbmFtZV9ydTogc3RyaW5nOyBuYW1lOiBzdHJpbmcgfVtdIHwgbnVsbDtcbiAgYmxvY2tjaGFpbl9oYXNoOiBzdHJpbmcgfCBudWxsO1xuICBjb3Zlcl91cmw6IHN0cmluZyB8IG51bGw7XG4gIG1hc3Rlcl9hdWRpb191cmw6IHN0cmluZyB8IG51bGw7XG4gIGNlcnRpZmljYXRlX3VybDogc3RyaW5nIHwgbnVsbDtcbiAgY3JlYXRlZF9hdDogc3RyaW5nO1xuICBwcm9jZXNzaW5nX2NvbXBsZXRlZF9hdDogc3RyaW5nIHwgbnVsbDtcbiAgcHJvZmlsZXM6IHsgdXNlcm5hbWU6IHN0cmluZyB8IG51bGwgfVtdIHwgbnVsbDtcbn1cblxuLy8gR2VuZXJhdGUgU0lMSy1jb21wYXRpYmxlIFhNTCBtZXRhZGF0YVxuZnVuY3Rpb24gZ2VuZXJhdGVTaWxrWG1sKHRyYWNrOiBUcmFja01ldGFkYXRhKTogc3RyaW5nIHtcbiAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICBjb25zdCByZWxlYXNlRGF0ZSA9IHRyYWNrLnByb2Nlc3NpbmdfY29tcGxldGVkX2F0IHx8IG5vdztcbiAgY29uc3QgZ2VucmVOYW1lID0gdHJhY2suZ2VucmU/LlswXT8ubmFtZSB8fCAnRWxlY3Ryb25pYyc7XG4gIGNvbnN0IGdlbnJlTmFtZVJ1ID0gdHJhY2suZ2VucmU/LlswXT8ubmFtZV9ydSB8fCAn0K3Qu9C10LrRgtGA0L7QvdC90LDRjyc7XG4gIGNvbnN0IHVwbG9hZGVyTmFtZSA9IHRyYWNrLnByb2ZpbGVzPy5bMF0/LnVzZXJuYW1lIHx8ICdVbmtub3duJztcbiAgXG4gIHJldHVybiBgPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+XG48cmVsZWFzZSB4bWxucz1cImh0dHA6Ly9zaWxrLnJ1L3NjaGVtYS9yZWxlYXNlL3YxXCI+XG4gIDxtZXRhZGF0YT5cbiAgICA8Zm9ybWF0X3ZlcnNpb24+MS4wPC9mb3JtYXRfdmVyc2lvbj5cbiAgICA8Z2VuZXJhdGVkX2F0PiR7bm93fTwvZ2VuZXJhdGVkX2F0PlxuICAgIDxnZW5lcmF0b3I+Tm90YWZleWEgRGlzdHJpYnV0aW9uIFBsYXRmb3JtPC9nZW5lcmF0b3I+XG4gIDwvbWV0YWRhdGE+XG4gIFxuICA8cmVsZWFzZV9pbmZvPlxuICAgIDxpbnRlcm5hbF9pZD4ke3RyYWNrLmlkfTwvaW50ZXJuYWxfaWQ+XG4gICAgPGlzcmM+JHt0cmFjay5pc3JjX2NvZGUgfHwgJ1BFTkRJTkcnfTwvaXNyYz5cbiAgICA8dGl0bGU+PCFbQ0RBVEFbJHt0cmFjay50aXRsZX1dXT48L3RpdGxlPlxuICAgIDxhcnRpc3Q+PCFbQ0RBVEFbJHt0cmFjay5wZXJmb3JtZXJfbmFtZX1dXT48L2FydGlzdD5cbiAgICA8bGFiZWw+PCFbQ0RBVEFbJHt0cmFjay5sYWJlbF9uYW1lIHx8ICdOb3RhZmV5YSBSZWNvcmRzJ31dXT48L2xhYmVsPlxuICAgIDxyZWxlYXNlX2RhdGU+JHtyZWxlYXNlRGF0ZS5zcGxpdCgnVCcpWzBdfTwvcmVsZWFzZV9kYXRlPlxuICAgIDxnZW5yZT4ke2dlbnJlTmFtZX08L2dlbnJlPlxuICAgIDxnZW5yZV9ydT4ke2dlbnJlTmFtZVJ1fTwvZ2VucmVfcnU+XG4gICAgPGR1cmF0aW9uX3NlY29uZHM+JHtNYXRoLnJvdW5kKHRyYWNrLmR1cmF0aW9uIHx8IDApfTwvZHVyYXRpb25fc2Vjb25kcz5cbiAgPC9yZWxlYXNlX2luZm8+XG4gIFxuICA8Y3JlZGl0cz5cbiAgICA8bXVzaWNfYXV0aG9yPjwhW0NEQVRBWyR7dHJhY2subXVzaWNfYXV0aG9yIHx8IHRyYWNrLnBlcmZvcm1lcl9uYW1lfV1dPjwvbXVzaWNfYXV0aG9yPlxuICAgIDxseXJpY3NfYXV0aG9yPjwhW0NEQVRBWyR7dHJhY2subHlyaWNzX2F1dGhvciB8fCAnSW5zdHJ1bWVudGFsJ31dXT48L2x5cmljc19hdXRob3I+XG4gICAgPHBlcmZvcm1lcj48IVtDREFUQVske3RyYWNrLnBlcmZvcm1lcl9uYW1lfV1dPjwvcGVyZm9ybWVyPlxuICAgIDxwcm9kdWNlcj48IVtDREFUQVske3RyYWNrLnBlcmZvcm1lcl9uYW1lfV1dPjwvcHJvZHVjZXI+XG4gICAgPHVwbG9hZGVyPjwhW0NEQVRBWyR7dXBsb2FkZXJOYW1lfV1dPjwvdXBsb2FkZXI+XG4gIDwvY3JlZGl0cz5cbiAgXG4gIDx0ZWNobmljYWw+XG4gICAgPGF1ZGlvX2Zvcm1hdD5XQVY8L2F1ZGlvX2Zvcm1hdD5cbiAgICA8Yml0X2RlcHRoPjI0PC9iaXRfZGVwdGg+XG4gICAgPHNhbXBsZV9yYXRlPjQ0MTAwPC9zYW1wbGVfcmF0ZT5cbiAgICA8bG91ZG5lc3Nfc3RhbmRhcmQ+LTE0IExVRlM8L2xvdWRuZXNzX3N0YW5kYXJkPlxuICAgIDxtYXN0ZXJlZD50cnVlPC9tYXN0ZXJlZD5cbiAgICA8bWV0YWRhdGFfY2xlYW5lZD50cnVlPC9tZXRhZGF0YV9jbGVhbmVkPlxuICA8L3RlY2huaWNhbD5cbiAgXG4gIDxibG9ja2NoYWluPlxuICAgIDxoYXNoPiR7dHJhY2suYmxvY2tjaGFpbl9oYXNoIHx8ICdOL0EnfTwvaGFzaD5cbiAgICA8dGltZXN0YW1wPiR7cmVsZWFzZURhdGV9PC90aW1lc3RhbXA+XG4gICAgPG5ldHdvcms+T3BlblRpbWVzdGFtcHM8L25ldHdvcms+XG4gICAgPHZlcmlmaWVkPnRydWU8L3ZlcmlmaWVkPlxuICA8L2Jsb2NrY2hhaW4+XG4gIFxuICA8YXNzZXRzPlxuICAgIDxtYXN0ZXJfYXVkaW8+JHt0cmFjay5tYXN0ZXJfYXVkaW9fdXJsID8gJ2luY2x1ZGVkJyA6ICdwZW5kaW5nJ308L21hc3Rlcl9hdWRpbz5cbiAgICA8Y292ZXJfYXJ0IHJlc29sdXRpb249XCIzMDAweDMwMDBcIj4ke3RyYWNrLmNvdmVyX3VybCA/ICdpbmNsdWRlZCcgOiAncGVuZGluZyd9PC9jb3Zlcl9hcnQ+XG4gICAgPHByb21vX3ZpZGVvPm5vdF9hdmFpbGFibGU8L3Byb21vX3ZpZGVvPlxuICAgIDxjZXJ0aWZpY2F0ZT4ke3RyYWNrLmNlcnRpZmljYXRlX3VybCA/ICdpbmNsdWRlZCcgOiAncGVuZGluZyd9PC9jZXJ0aWZpY2F0ZT5cbiAgPC9hc3NldHM+XG4gIFxuICA8ZGlzdHJpYnV0aW9uPlxuICAgIDxwbGF0Zm9ybXM+XG4gICAgICA8cGxhdGZvcm0gbmFtZT1cIlNwb3RpZnlcIiBzdGF0dXM9XCJyZWFkeVwiLz5cbiAgICAgIDxwbGF0Zm9ybSBuYW1lPVwiQXBwbGUgTXVzaWNcIiBzdGF0dXM9XCJyZWFkeVwiLz5cbiAgICAgIDxwbGF0Zm9ybSBuYW1lPVwiWWFuZGV4IE11c2ljXCIgc3RhdHVzPVwicmVhZHlcIi8+XG4gICAgICA8cGxhdGZvcm0gbmFtZT1cIlZLIE11c2ljXCIgc3RhdHVzPVwicmVhZHlcIi8+XG4gICAgICA8cGxhdGZvcm0gbmFtZT1cIkRlZXplclwiIHN0YXR1cz1cInJlYWR5XCIvPlxuICAgICAgPHBsYXRmb3JtIG5hbWU9XCJTb3VuZENsb3VkXCIgc3RhdHVzPVwicmVhZHlcIi8+XG4gICAgPC9wbGF0Zm9ybXM+XG4gICAgPHRlcnJpdG9yeT5Xb3JsZHdpZGU8L3RlcnJpdG9yeT5cbiAgICA8ZXhjbHVzaXZlPmZhbHNlPC9leGNsdXNpdmU+XG4gIDwvZGlzdHJpYnV0aW9uPlxuICBcbiAgPGxlZ2FsPlxuICAgIDxjb3B5cmlnaHQ+wqkgJHtuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCl9ICR7dHJhY2subGFiZWxfbmFtZSB8fCAnTm90YWZleWEgUmVjb3Jkcyd9LiBBbGwgcmlnaHRzIHJlc2VydmVkLjwvY29weXJpZ2h0PlxuICAgIDxsaWNlbnNlPlN0YW5kYXJkIERpc3RyaWJ1dGlvbiBMaWNlbnNlPC9saWNlbnNlPlxuICAgIDxjb250ZW50X3JhdGluZz5VbnJhdGVkPC9jb250ZW50X3JhdGluZz5cbiAgPC9sZWdhbD5cbjwvcmVsZWFzZT5gO1xufVxuXG4vLyBHZW5lcmF0ZSBQREYgY2VydGlmaWNhdGUgSFRNTCAod291bGQgYmUgY29udmVydGVkIHRvIFBERiBpbiBwcm9kdWN0aW9uKVxuZnVuY3Rpb24gZ2VuZXJhdGVDZXJ0aWZpY2F0ZUh0bWwodHJhY2s6IFRyYWNrTWV0YWRhdGEpOiBzdHJpbmcge1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xuICBjb25zdCBmb3JtYXR0ZWREYXRlID0gbm93LnRvTG9jYWxlRGF0ZVN0cmluZygncnUtUlUnLCB7XG4gICAgeWVhcjogJ251bWVyaWMnLFxuICAgIG1vbnRoOiAnbG9uZycsXG4gICAgZGF5OiAnbnVtZXJpYydcbiAgfSk7XG4gIFxuICByZXR1cm4gYDwhRE9DVFlQRSBodG1sPlxuPGh0bWwgbGFuZz1cInJ1XCI+XG48aGVhZD5cbiAgPG1ldGEgY2hhcnNldD1cIlVURi04XCI+XG4gIDx0aXRsZT7QodC10YDRgtC40YTQuNC60LDRgiDQsNCy0YLQvtGA0YHRgtCy0LAgLSAke3RyYWNrLnRpdGxlfTwvdGl0bGU+XG4gIDxzdHlsZT5cbiAgICBAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1Db3Jtb3JhbnQrR2FyYW1vbmQ6d2dodEA0MDA7NjAwOzcwMCZmYW1pbHk9TW9udHNlcnJhdDp3Z2h0QDMwMDs0MDA7NjAwJmRpc3BsYXk9c3dhcCcpO1xuICAgIFxuICAgICogeyBtYXJnaW46IDA7IHBhZGRpbmc6IDA7IGJveC1zaXppbmc6IGJvcmRlci1ib3g7IH1cbiAgICBcbiAgICBib2R5IHtcbiAgICAgIGZvbnQtZmFtaWx5OiAnTW9udHNlcnJhdCcsIHNhbnMtc2VyaWY7XG4gICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjMGYwZjIzIDAlLCAjMWExYTNlIDUwJSwgIzBmMGYyMyAxMDAlKTtcbiAgICAgIG1pbi1oZWlnaHQ6IDEwMHZoO1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgIHBhZGRpbmc6IDQwcHg7XG4gICAgfVxuICAgIFxuICAgIC5jZXJ0aWZpY2F0ZSB7XG4gICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTgwZGVnLCAjZmVmZWZlIDAlLCAjZjhmNmYwIDEwMCUpO1xuICAgICAgYm9yZGVyOiAzcHggc29saWQgI2M5YTk2MjtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICAgIHBhZGRpbmc6IDYwcHggODBweDtcbiAgICAgIG1heC13aWR0aDogODAwcHg7XG4gICAgICB3aWR0aDogMTAwJTtcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMjBweCA2MHB4IHJnYmEoMCwwLDAsMC41KTtcbiAgICB9XG4gICAgXG4gICAgLmNlcnRpZmljYXRlOjpiZWZvcmUge1xuICAgICAgY29udGVudDogJyc7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICB0b3A6IDE1cHg7XG4gICAgICBsZWZ0OiAxNXB4O1xuICAgICAgcmlnaHQ6IDE1cHg7XG4gICAgICBib3R0b206IDE1cHg7XG4gICAgICBib3JkZXI6IDFweCBzb2xpZCAjYzlhOTYyO1xuICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAgICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XG4gICAgfVxuICAgIFxuICAgIC5oZWFkZXIge1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgbWFyZ2luLWJvdHRvbTogNDBweDtcbiAgICB9XG4gICAgXG4gICAgLmxvZ28ge1xuICAgICAgZm9udC1mYW1pbHk6ICdDb3Jtb3JhbnQgR2FyYW1vbmQnLCBzZXJpZjtcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgIGNvbG9yOiAjNjY2O1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDRweDtcbiAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAgIH1cbiAgICBcbiAgICAudGl0bGUge1xuICAgICAgZm9udC1mYW1pbHk6ICdDb3Jtb3JhbnQgR2FyYW1vbmQnLCBzZXJpZjtcbiAgICAgIGZvbnQtc2l6ZTogNDJweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgICBjb2xvcjogIzFhMWEyZTtcbiAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgfVxuICAgIFxuICAgIC5zdWJ0aXRsZSB7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBjb2xvcjogIzY2NjtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAycHg7XG4gICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgIH1cbiAgICBcbiAgICAuZGl2aWRlciB7XG4gICAgICBoZWlnaHQ6IDJweDtcbiAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgdHJhbnNwYXJlbnQsICNjOWE5NjIsIHRyYW5zcGFyZW50KTtcbiAgICAgIG1hcmdpbjogMzBweCAwO1xuICAgIH1cbiAgICBcbiAgICAuY29udGVudCB7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgfVxuICAgIFxuICAgIC50cmFjay10aXRsZSB7XG4gICAgICBmb250LWZhbWlseTogJ0Nvcm1vcmFudCBHYXJhbW9uZCcsIHNlcmlmO1xuICAgICAgZm9udC1zaXplOiAyOHB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgIGNvbG9yOiAjMWExYTJlO1xuICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgICB9XG4gICAgXG4gICAgLnRyYWNrLWFydGlzdCB7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICBjb2xvcjogIzQ0NDtcbiAgICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gICAgfVxuICAgIFxuICAgIC5pbmZvLWdyaWQge1xuICAgICAgZGlzcGxheTogZ3JpZDtcbiAgICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogMWZyIDFmcjtcbiAgICAgIGdhcDogMjBweDtcbiAgICAgIG1hcmdpbjogMzBweCAwO1xuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICB9XG4gICAgXG4gICAgLmluZm8taXRlbSB7XG4gICAgICBwYWRkaW5nOiAxNXB4O1xuICAgICAgYmFja2dyb3VuZDogcmdiYSgyMDEsIDE2OSwgOTgsIDAuMSk7XG4gICAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgfVxuICAgIFxuICAgIC5pbmZvLWxhYmVsIHtcbiAgICAgIGZvbnQtc2l6ZTogMTFweDtcbiAgICAgIGNvbG9yOiAjODg4O1xuICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgfVxuICAgIFxuICAgIC5pbmZvLXZhbHVlIHtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGNvbG9yOiAjMWExYTJlO1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICB9XG4gICAgXG4gICAgLmJsb2NrY2hhaW4tc2VjdGlvbiB7XG4gICAgICBtYXJnaW46IDQwcHggMDtcbiAgICAgIHBhZGRpbmc6IDI1cHg7XG4gICAgICBiYWNrZ3JvdW5kOiAjMWExYTJlO1xuICAgICAgYm9yZGVyLXJhZGl1czogNnB4O1xuICAgICAgY29sb3I6IHdoaXRlO1xuICAgIH1cbiAgICBcbiAgICAuYmxvY2tjaGFpbi10aXRsZSB7XG4gICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICBjb2xvcjogI2M5YTk2MjtcbiAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICBsZXR0ZXItc3BhY2luZzogMnB4O1xuICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgICB9XG4gICAgXG4gICAgLmJsb2NrY2hhaW4taGFzaCB7XG4gICAgICBmb250LWZhbWlseTogJ0NvdXJpZXIgTmV3JywgbW9ub3NwYWNlO1xuICAgICAgZm9udC1zaXplOiAxMXB4O1xuICAgICAgd29yZC1icmVhazogYnJlYWstYWxsO1xuICAgICAgY29sb3I6ICM4YmU5ZmQ7XG4gICAgICBiYWNrZ3JvdW5kOiByZ2JhKDAsMCwwLDAuMyk7XG4gICAgICBwYWRkaW5nOiAxNXB4O1xuICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAgIH1cbiAgICBcbiAgICAuZm9vdGVyIHtcbiAgICAgIG1hcmdpbi10b3A6IDQwcHg7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgfVxuICAgIFxuICAgIC5zZWFsIHtcbiAgICAgIHdpZHRoOiAxMDBweDtcbiAgICAgIGhlaWdodDogMTAwcHg7XG4gICAgICBtYXJnaW46IDAgYXV0byAyMHB4O1xuICAgICAgYm9yZGVyOiAzcHggc29saWQgI2M5YTk2MjtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICBmb250LWZhbWlseTogJ0Nvcm1vcmFudCBHYXJhbW9uZCcsIHNlcmlmO1xuICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgY29sb3I6ICNjOWE5NjI7XG4gICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgICB9XG4gICAgXG4gICAgLmRhdGUge1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgY29sb3I6ICM2NjY7XG4gICAgfVxuICAgIFxuICAgIC5jZXJ0aWZpY2F0ZS1pZCB7XG4gICAgICBtYXJnaW4tdG9wOiAxNXB4O1xuICAgICAgZm9udC1zaXplOiAxMXB4O1xuICAgICAgY29sb3I6ICM5OTk7XG4gICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xuICAgIH1cbiAgPC9zdHlsZT5cbjwvaGVhZD5cbjxib2R5PlxuICA8ZGl2IGNsYXNzPVwiY2VydGlmaWNhdGVcIj5cbiAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibG9nb1wiPuKZqiBOb3RhZmV5YSBSZWNvcmRzIOKZqjwvZGl2PlxuICAgICAgPGgxIGNsYXNzPVwidGl0bGVcIj7QodC10YDRgtC40YTQuNC60LDRgiDQkNCy0YLQvtGA0YHRgtCy0LA8L2gxPlxuICAgICAgPHAgY2xhc3M9XCJzdWJ0aXRsZVwiPkNlcnRpZmljYXRlIG9mIEF1dGhvcnNoaXA8L3A+XG4gICAgPC9kaXY+XG4gICAgXG4gICAgPGRpdiBjbGFzcz1cImRpdmlkZXJcIj48L2Rpdj5cbiAgICBcbiAgICA8ZGl2IGNsYXNzPVwiY29udGVudFwiPlxuICAgICAgPGgyIGNsYXNzPVwidHJhY2stdGl0bGVcIj5cIiR7dHJhY2sudGl0bGV9XCI8L2gyPlxuICAgICAgPHAgY2xhc3M9XCJ0cmFjay1hcnRpc3RcIj7QmNGB0L/QvtC70L3QuNGC0LXQu9GMOiAke3RyYWNrLnBlcmZvcm1lcl9uYW1lfTwvcD5cbiAgICAgIFxuICAgICAgPGRpdiBjbGFzcz1cImluZm8tZ3JpZFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1pdGVtXCI+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tbGFiZWxcIj7QkNCy0YLQvtGAINC80YPQt9GL0LrQuDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLXZhbHVlXCI+JHt0cmFjay5tdXNpY19hdXRob3IgfHwgdHJhY2sucGVyZm9ybWVyX25hbWV9PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1pdGVtXCI+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tbGFiZWxcIj7QkNCy0YLQvtGAINGC0LXQutGB0YLQsDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLXZhbHVlXCI+JHt0cmFjay5seXJpY3NfYXV0aG9yIHx8ICfQmNC90YHRgtGA0YPQvNC10L3RgtCw0LsnfTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImluZm8taXRlbVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLWxhYmVsXCI+SVNSQyDQutC+0LQ8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby12YWx1ZVwiPiR7dHJhY2suaXNyY19jb2RlIHx8ICfQkiDQvtCx0YDQsNCx0L7RgtC60LUnfTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImluZm8taXRlbVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLWxhYmVsXCI+0JvQtdC50LHQuzwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLXZhbHVlXCI+JHt0cmFjay5sYWJlbF9uYW1lIHx8ICdOb3RhZmV5YSBSZWNvcmRzJ308L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIFxuICAgICAgPGRpdiBjbGFzcz1cImJsb2NrY2hhaW4tc2VjdGlvblwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiYmxvY2tjaGFpbi10aXRsZVwiPuKbkyBCbG9ja2NoYWluIFZlcmlmaWNhdGlvbjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiYmxvY2tjaGFpbi1oYXNoXCI+JHt0cmFjay5ibG9ja2NoYWluX2hhc2ggfHwgJ0hhc2ggcGVuZGluZy4uLid9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICBcbiAgICA8ZGl2IGNsYXNzPVwiZm9vdGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwic2VhbFwiPlZlcmlmaWVkPGJyLz7inJM8L2Rpdj5cbiAgICAgIDxwIGNsYXNzPVwiZGF0ZVwiPiR7Zm9ybWF0dGVkRGF0ZX08L3A+XG4gICAgICA8cCBjbGFzcz1cImNlcnRpZmljYXRlLWlkXCI+SUQ6ICR7dHJhY2suaWQuc3Vic3RyaW5nKDAsIDgpLnRvVXBwZXJDYXNlKCl9PC9wPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvYm9keT5cbjwvaHRtbD5gO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSAnT1BUSU9OUycpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKCdvaycsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9VUkwnKSA/PyAnJyxcbiAgICAgIERlbm8uZW52LmdldCgnU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWScpID8/ICcnXG4gICAgKTtcblxuICAgIGNvbnN0IHsgdHJhY2tJZCB9OiBHb2xkUGFja1JlcXVlc3QgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKGBbZ2VuZXJhdGUtZ29sZC1wYWNrXSBTdGFydGluZyBmb3IgdHJhY2s6ICR7dHJhY2tJZH1gKTtcblxuICAgIGlmICghdHJhY2tJZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCd0cmFja0lkIGlzIHJlcXVpcmVkJyk7XG4gICAgfVxuXG4gICAgLy8gR2V0IHRyYWNrIHdpdGggYWxsIG1ldGFkYXRhXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjaywgZXJyb3I6IHRyYWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgndHJhY2tzJylcbiAgICAgIC5zZWxlY3QoYFxuICAgICAgICBpZCwgdGl0bGUsIHBlcmZvcm1lcl9uYW1lLCBtdXNpY19hdXRob3IsIGx5cmljc19hdXRob3IsIGxhYmVsX25hbWUsXG4gICAgICAgIGlzcmNfY29kZSwgZHVyYXRpb24sIGJsb2NrY2hhaW5faGFzaCwgY292ZXJfdXJsLCBtYXN0ZXJfYXVkaW9fdXJsLFxuICAgICAgICBjZXJ0aWZpY2F0ZV91cmwsIGNyZWF0ZWRfYXQsIHByb2Nlc3NpbmdfY29tcGxldGVkX2F0LFxuICAgICAgICBwcm9maWxlczp1c2VyX2lkKHVzZXJuYW1lKSxcbiAgICAgICAgZ2VucmU6Z2VucmVzKG5hbWVfcnUsIG5hbWUpXG4gICAgICBgKVxuICAgICAgLmVxKCdpZCcsIHRyYWNrSWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAodHJhY2tFcnJvciB8fCAhdHJhY2spIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignVHJhY2sgbm90IGZvdW5kJyk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFtnZW5lcmF0ZS1nb2xkLXBhY2tdIEdlbmVyYXRpbmcgYXNzZXRzIGZvcjogJHt0cmFjay50aXRsZX1gKTtcblxuICAgIC8vIEdlbmVyYXRlIFNJTEsgWE1MIG1ldGFkYXRhXG4gICAgY29uc3QgeG1sQ29udGVudCA9IGdlbmVyYXRlU2lsa1htbCh0cmFjayBhcyBUcmFja01ldGFkYXRhKTtcbiAgICBjb25zdCB4bWxGaWxlTmFtZSA9IGBnb2xkLXBhY2tzLyR7dHJhY2tJZH0vbWV0YWRhdGFfc2lsay54bWxgO1xuICAgIFxuICAgIGNvbnN0IHsgZXJyb3I6IHhtbFVwbG9hZEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5zdG9yYWdlXG4gICAgICAuZnJvbSgndHJhY2tzJylcbiAgICAgIC51cGxvYWQoeG1sRmlsZU5hbWUsIG5ldyBCbG9iKFt4bWxDb250ZW50XSwgeyB0eXBlOiAnYXBwbGljYXRpb24veG1sJyB9KSwge1xuICAgICAgICB1cHNlcnQ6IHRydWUsXG4gICAgICAgIGNvbnRlbnRUeXBlOiAnYXBwbGljYXRpb24veG1sJ1xuICAgICAgfSk7XG5cbiAgICBpZiAoeG1sVXBsb2FkRXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1tnZW5lcmF0ZS1nb2xkLXBhY2tdIFhNTCB1cGxvYWQgZXJyb3I6JywgeG1sVXBsb2FkRXJyb3IpO1xuICAgIH1cblxuICAgIC8vIEdlbmVyYXRlIGNlcnRpZmljYXRlIEhUTUwgKGluIHByb2R1Y3Rpb24gd291bGQgY29udmVydCB0byBQREYpXG4gICAgY29uc3QgY2VydGlmaWNhdGVIdG1sID0gZ2VuZXJhdGVDZXJ0aWZpY2F0ZUh0bWwodHJhY2sgYXMgVHJhY2tNZXRhZGF0YSk7XG4gICAgY29uc3QgY2VydGlmaWNhdGVGaWxlTmFtZSA9IGBnb2xkLXBhY2tzLyR7dHJhY2tJZH0vY2VydGlmaWNhdGUuaHRtbGA7XG4gICAgXG4gICAgY29uc3QgeyBlcnJvcjogY2VydFVwbG9hZEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5zdG9yYWdlXG4gICAgICAuZnJvbSgndHJhY2tzJylcbiAgICAgIC51cGxvYWQoY2VydGlmaWNhdGVGaWxlTmFtZSwgbmV3IEJsb2IoW2NlcnRpZmljYXRlSHRtbF0sIHsgdHlwZTogJ3RleHQvaHRtbCcgfSksIHtcbiAgICAgICAgdXBzZXJ0OiB0cnVlLFxuICAgICAgICBjb250ZW50VHlwZTogJ3RleHQvaHRtbCdcbiAgICAgIH0pO1xuXG4gICAgaWYgKGNlcnRVcGxvYWRFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignW2dlbmVyYXRlLWdvbGQtcGFja10gQ2VydGlmaWNhdGUgdXBsb2FkIGVycm9yOicsIGNlcnRVcGxvYWRFcnJvcik7XG4gICAgfVxuXG4gICAgLy8gR2V0IHB1YmxpYyBVUkxzXG4gICAgY29uc3QgeyBkYXRhOiB4bWxVcmwgfSA9IHN1cGFiYXNlLnN0b3JhZ2UuZnJvbSgndHJhY2tzJykuZ2V0UHVibGljVXJsKHhtbEZpbGVOYW1lKTtcbiAgICBjb25zdCB7IGRhdGE6IGNlcnRVcmwgfSA9IHN1cGFiYXNlLnN0b3JhZ2UuZnJvbSgndHJhY2tzJykuZ2V0UHVibGljVXJsKGNlcnRpZmljYXRlRmlsZU5hbWUpO1xuXG4gICAgLy8gR2VuZXJhdGUgcGFjayBtYW5pZmVzdFxuICAgIGNvbnN0IG1hbmlmZXN0ID0ge1xuICAgICAgdmVyc2lvbjogJzEuMCcsXG4gICAgICBnZW5lcmF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIHRyYWNrX2lkOiB0cmFjay5pZCxcbiAgICAgIHRyYWNrX3RpdGxlOiB0cmFjay50aXRsZSxcbiAgICAgIGFydGlzdDogdHJhY2sucGVyZm9ybWVyX25hbWUsXG4gICAgICBpc3JjOiB0cmFjay5pc3JjX2NvZGUsXG4gICAgICBibG9ja2NoYWluX2hhc2g6IHRyYWNrLmJsb2NrY2hhaW5faGFzaCxcbiAgICAgIGNvbnRlbnRzOiB7XG4gICAgICAgIG1hc3Rlcl9hdWRpbzoge1xuICAgICAgICAgIGZvcm1hdDogJ1dBViAyNC1iaXQvNDQuMWtIeicsXG4gICAgICAgICAgdXJsOiB0cmFjay5tYXN0ZXJfYXVkaW9fdXJsLFxuICAgICAgICAgIHN0YXR1czogdHJhY2subWFzdGVyX2F1ZGlvX3VybCA/ICdpbmNsdWRlZCcgOiAncGVuZGluZydcbiAgICAgICAgfSxcbiAgICAgICAgY292ZXJfYXJ0OiB7XG4gICAgICAgICAgZm9ybWF0OiAnSlBFRyAzMDAweDMwMDAnLFxuICAgICAgICAgIHVybDogdHJhY2suY292ZXJfdXJsLFxuICAgICAgICAgIHN0YXR1czogdHJhY2suY292ZXJfdXJsID8gJ2luY2x1ZGVkJyA6ICdwZW5kaW5nJ1xuICAgICAgICB9LFxuICAgICAgICBtZXRhZGF0YToge1xuICAgICAgICAgIGZvcm1hdDogJ1NJTEsgWE1MIHYxLjAnLFxuICAgICAgICAgIHVybDogeG1sVXJsLnB1YmxpY1VybCxcbiAgICAgICAgICBzdGF0dXM6ICdpbmNsdWRlZCdcbiAgICAgICAgfSxcbiAgICAgICAgY2VydGlmaWNhdGU6IHtcbiAgICAgICAgICBmb3JtYXQ6ICdIVE1ML1BERicsXG4gICAgICAgICAgdXJsOiBjZXJ0VXJsLnB1YmxpY1VybCxcbiAgICAgICAgICBzdGF0dXM6ICdpbmNsdWRlZCdcbiAgICAgICAgfSxcbiAgICAgICAgcHJvbW9fdmlkZW86IHtcbiAgICAgICAgICBmb3JtYXQ6ICdNUDQgMTA4MHAnLFxuICAgICAgICAgIHVybDogbnVsbCxcbiAgICAgICAgICBzdGF0dXM6ICdub3RfYXZhaWxhYmxlJ1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgZGlzdHJpYnV0aW9uOiB7XG4gICAgICAgIHBsYXRmb3JtczogWydTcG90aWZ5JywgJ0FwcGxlIE11c2ljJywgJ1lhbmRleCBNdXNpYycsICdWSyBNdXNpYycsICdEZWV6ZXInLCAnU291bmRDbG91ZCddLFxuICAgICAgICB0ZXJyaXRvcnk6ICdXb3JsZHdpZGUnLFxuICAgICAgICByZWxlYXNlX3JlYWR5OiB0cnVlXG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IG1hbmlmZXN0RmlsZU5hbWUgPSBgZ29sZC1wYWNrcy8ke3RyYWNrSWR9L21hbmlmZXN0Lmpzb25gO1xuICAgIGF3YWl0IHN1cGFiYXNlLnN0b3JhZ2VcbiAgICAgIC5mcm9tKCd0cmFja3MnKVxuICAgICAgLnVwbG9hZChtYW5pZmVzdEZpbGVOYW1lLCBuZXcgQmxvYihbSlNPTi5zdHJpbmdpZnkobWFuaWZlc3QsIG51bGwsIDIpXSwgeyB0eXBlOiAnYXBwbGljYXRpb24vanNvbicgfSksIHtcbiAgICAgICAgdXBzZXJ0OiB0cnVlLFxuICAgICAgICBjb250ZW50VHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nXG4gICAgICB9KTtcblxuICAgIGNvbnN0IHsgZGF0YTogbWFuaWZlc3RVcmwgfSA9IHN1cGFiYXNlLnN0b3JhZ2UuZnJvbSgndHJhY2tzJykuZ2V0UHVibGljVXJsKG1hbmlmZXN0RmlsZU5hbWUpO1xuXG4gICAgLy8gVXBkYXRlIHRyYWNrIHdpdGggZ29sZCBwYWNrIFVSTCAobWFuaWZlc3QgYXMgZW50cnkgcG9pbnQpXG4gICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKCd0cmFja3MnKVxuICAgICAgLnVwZGF0ZSh7XG4gICAgICAgIGdvbGRfcGFja191cmw6IG1hbmlmZXN0VXJsLnB1YmxpY1VybCxcbiAgICAgICAgY2VydGlmaWNhdGVfdXJsOiBjZXJ0VXJsLnB1YmxpY1VybFxuICAgICAgfSlcbiAgICAgIC5lcSgnaWQnLCB0cmFja0lkKTtcblxuICAgIC8vIExvZyB0aGUgZ29sZCBwYWNrIGdlbmVyYXRpb25cbiAgICBjb25zdCB7IGRhdGE6IHVzZXJEYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oJ3RyYWNrcycpXG4gICAgICAuc2VsZWN0KCd1c2VyX2lkJylcbiAgICAgIC5lcSgnaWQnLCB0cmFja0lkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKHVzZXJEYXRhKSB7XG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdkaXN0cmlidXRpb25fbG9ncycpLmluc2VydCh7XG4gICAgICAgIHRyYWNrX2lkOiB0cmFja0lkLFxuICAgICAgICB1c2VyX2lkOiB1c2VyRGF0YS51c2VyX2lkLFxuICAgICAgICBhY3Rpb246ICdnb2xkX3BhY2tfZ2VuZXJhdGVkJyxcbiAgICAgICAgc3RhZ2U6ICdsZXZlbF9wcm8nLFxuICAgICAgICBkZXRhaWxzOiB7XG4gICAgICAgICAgbWFuaWZlc3RfdXJsOiBtYW5pZmVzdFVybC5wdWJsaWNVcmwsXG4gICAgICAgICAgeG1sX3VybDogeG1sVXJsLnB1YmxpY1VybCxcbiAgICAgICAgICBjZXJ0aWZpY2F0ZV91cmw6IGNlcnRVcmwucHVibGljVXJsLFxuICAgICAgICAgIGhhc19tYXN0ZXI6ICEhdHJhY2subWFzdGVyX2F1ZGlvX3VybCxcbiAgICAgICAgICBoYXNfY292ZXI6ICEhdHJhY2suY292ZXJfdXJsLFxuICAgICAgICAgIGhhc192aWRlbzogZmFsc2VcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIC8vIE5vdGlmeSB1c2VyXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdub3RpZmljYXRpb25zJykuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogdXNlckRhdGEudXNlcl9pZCxcbiAgICAgICAgdHlwZTogJ3N5c3RlbScsXG4gICAgICAgIHRpdGxlOiAn8J+TpiDQl9C+0LvQvtGC0L7QuSDQv9Cw0LrQtdGCIFNJTEsg0LPQvtGC0L7QsiEnLFxuICAgICAgICBtZXNzYWdlOiBg0JLQsNGIINGC0YDQtdC6IFwiJHt0cmFjay50aXRsZX1cIiDQs9C+0YLQvtCyINC6INC00LjRgdGC0YDQuNCx0YPRhtC40LguIFdBViwgWE1MLdC80LXRgtCw0LTQsNC90L3Ri9C1INC4INGB0LXRgNGC0LjRhNC40LrQsNGCINC00L7RgdGC0YPQv9C90Ysg0LTQu9GPINGB0LrQsNGH0LjQstCw0L3QuNGPLmAsXG4gICAgICAgIHRhcmdldF90eXBlOiAndHJhY2snLFxuICAgICAgICB0YXJnZXRfaWQ6IHRyYWNrSWRcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgIGdvbGRQYWNrOiB7XG4gICAgICAgICAgbWFuaWZlc3RVcmw6IG1hbmlmZXN0VXJsLnB1YmxpY1VybCxcbiAgICAgICAgICB4bWxVcmw6IHhtbFVybC5wdWJsaWNVcmwsXG4gICAgICAgICAgY2VydGlmaWNhdGVVcmw6IGNlcnRVcmwucHVibGljVXJsLFxuICAgICAgICAgIG1hc3RlckF1ZGlvVXJsOiB0cmFjay5tYXN0ZXJfYXVkaW9fdXJsLFxuICAgICAgICAgIGNvdmVyVXJsOiB0cmFjay5jb3Zlcl91cmwsXG4gICAgICAgICAgcHJvbW9WaWRlb1VybDogbnVsbFxuICAgICAgICB9XG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignW2dlbmVyYXRlLWdvbGQtcGFja10gRXJyb3I6JywgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJztcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IG1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUF5QkEsd0NBQXdDO0FBQ3hDLFNBQVMsZ0JBQWdCLEtBQW9CO0VBQzNDLE1BQU0sTUFBTSxJQUFJLE9BQU8sV0FBVztFQUNsQyxNQUFNLGNBQWMsTUFBTSx1QkFBdUIsSUFBSTtFQUNyRCxNQUFNLFlBQVksTUFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUUsUUFBUTtFQUM1QyxNQUFNLGNBQWMsTUFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUUsV0FBVztFQUNqRCxNQUFNLGVBQWUsTUFBTSxRQUFRLEVBQUUsQ0FBQyxFQUFFLEVBQUUsWUFBWTtFQUV0RCxPQUFPLENBQUM7Ozs7a0JBSVEsRUFBRSxJQUFJOzs7OztpQkFLUCxFQUFFLE1BQU0sRUFBRSxDQUFDO1VBQ2xCLEVBQUUsTUFBTSxTQUFTLElBQUksVUFBVTtvQkFDckIsRUFBRSxNQUFNLEtBQUssQ0FBQztxQkFDYixFQUFFLE1BQU0sY0FBYyxDQUFDO29CQUN4QixFQUFFLE1BQU0sVUFBVSxJQUFJLG1CQUFtQjtrQkFDM0MsRUFBRSxZQUFZLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO1dBQ25DLEVBQUUsVUFBVTtjQUNULEVBQUUsWUFBWTtzQkFDTixFQUFFLEtBQUssS0FBSyxDQUFDLE1BQU0sUUFBUSxJQUFJLEdBQUc7Ozs7MkJBSTdCLEVBQUUsTUFBTSxZQUFZLElBQUksTUFBTSxjQUFjLENBQUM7NEJBQzVDLEVBQUUsTUFBTSxhQUFhLElBQUksZUFBZTt3QkFDNUMsRUFBRSxNQUFNLGNBQWMsQ0FBQzt1QkFDeEIsRUFBRSxNQUFNLGNBQWMsQ0FBQzt1QkFDdkIsRUFBRSxhQUFhOzs7Ozs7Ozs7Ozs7O1VBYTVCLEVBQUUsTUFBTSxlQUFlLElBQUksTUFBTTtlQUM1QixFQUFFLFlBQVk7Ozs7OztrQkFNWCxFQUFFLE1BQU0sZ0JBQWdCLEdBQUcsYUFBYSxVQUFVO3NDQUM5QixFQUFFLE1BQU0sU0FBUyxHQUFHLGFBQWEsVUFBVTs7aUJBRWhFLEVBQUUsTUFBTSxlQUFlLEdBQUcsYUFBYSxVQUFVOzs7Ozs7Ozs7Ozs7Ozs7OztpQkFpQmpELEVBQUUsSUFBSSxPQUFPLFdBQVcsR0FBRyxDQUFDLEVBQUUsTUFBTSxVQUFVLElBQUksbUJBQW1COzs7O1VBSTVFLENBQUM7QUFDWDtBQUVBLDBFQUEwRTtBQUMxRSxTQUFTLHdCQUF3QixLQUFvQjtFQUNuRCxNQUFNLE1BQU0sSUFBSTtFQUNoQixNQUFNLGdCQUFnQixJQUFJLGtCQUFrQixDQUFDLFNBQVM7SUFDcEQsTUFBTTtJQUNOLE9BQU87SUFDUCxLQUFLO0VBQ1A7RUFFQSxPQUFPLENBQUM7Ozs7Z0NBSXNCLEVBQUUsTUFBTSxLQUFLLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OytCQStMZixFQUFFLE1BQU0sS0FBSyxDQUFDOzJDQUNGLEVBQUUsTUFBTSxjQUFjLENBQUM7Ozs7O2tDQUtoQyxFQUFFLE1BQU0sWUFBWSxJQUFJLE1BQU0sY0FBYyxDQUFDOzs7O2tDQUk3QyxFQUFFLE1BQU0sYUFBYSxJQUFJLGVBQWU7Ozs7a0NBSXhDLEVBQUUsTUFBTSxTQUFTLElBQUksY0FBYzs7OztrQ0FJbkMsRUFBRSxNQUFNLFVBQVUsSUFBSSxtQkFBbUI7Ozs7OztxQ0FNdEMsRUFBRSxNQUFNLGVBQWUsSUFBSSxrQkFBa0I7Ozs7OztzQkFNNUQsRUFBRSxjQUFjO29DQUNGLEVBQUUsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxXQUFXLEdBQUc7Ozs7T0FJdEUsQ0FBQztBQUNSO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxXQUFXLGFBQ2YsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0lBRy9DLE1BQU0sRUFBRSxPQUFPLEVBQUUsR0FBb0IsTUFBTSxJQUFJLElBQUk7SUFDbkQsUUFBUSxHQUFHLENBQUMsQ0FBQyx5Q0FBeUMsRUFBRSxRQUFRLENBQUM7SUFFakUsSUFBSSxDQUFDLFNBQVM7TUFDWixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLDhCQUE4QjtJQUM5QixNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxVQUFVLEVBQUUsR0FBRyxNQUFNLFNBQzlDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxDQUFDOzs7Ozs7TUFNVCxDQUFDLEVBQ0EsRUFBRSxDQUFDLE1BQU0sU0FDVCxNQUFNO0lBRVQsSUFBSSxjQUFjLENBQUMsT0FBTztNQUN4QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsNENBQTRDLEVBQUUsTUFBTSxLQUFLLENBQUMsQ0FBQztJQUV4RSw2QkFBNkI7SUFDN0IsTUFBTSxhQUFhLGdCQUFnQjtJQUNuQyxNQUFNLGNBQWMsQ0FBQyxXQUFXLEVBQUUsUUFBUSxrQkFBa0IsQ0FBQztJQUU3RCxNQUFNLEVBQUUsT0FBTyxjQUFjLEVBQUUsR0FBRyxNQUFNLFNBQVMsT0FBTyxDQUNyRCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsYUFBYSxJQUFJLEtBQUs7TUFBQztLQUFXLEVBQUU7TUFBRSxNQUFNO0lBQWtCLElBQUk7TUFDeEUsUUFBUTtNQUNSLGFBQWE7SUFDZjtJQUVGLElBQUksZ0JBQWdCO01BQ2xCLFFBQVEsS0FBSyxDQUFDLDBDQUEwQztJQUMxRDtJQUVBLGlFQUFpRTtJQUNqRSxNQUFNLGtCQUFrQix3QkFBd0I7SUFDaEQsTUFBTSxzQkFBc0IsQ0FBQyxXQUFXLEVBQUUsUUFBUSxpQkFBaUIsQ0FBQztJQUVwRSxNQUFNLEVBQUUsT0FBTyxlQUFlLEVBQUUsR0FBRyxNQUFNLFNBQVMsT0FBTyxDQUN0RCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMscUJBQXFCLElBQUksS0FBSztNQUFDO0tBQWdCLEVBQUU7TUFBRSxNQUFNO0lBQVksSUFBSTtNQUMvRSxRQUFRO01BQ1IsYUFBYTtJQUNmO0lBRUYsSUFBSSxpQkFBaUI7TUFDbkIsUUFBUSxLQUFLLENBQUMsa0RBQWtEO0lBQ2xFO0lBRUEsa0JBQWtCO0lBQ2xCLE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxHQUFHLFNBQVMsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLFlBQVksQ0FBQztJQUN0RSxNQUFNLEVBQUUsTUFBTSxPQUFPLEVBQUUsR0FBRyxTQUFTLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxZQUFZLENBQUM7SUFFdkUseUJBQXlCO0lBQ3pCLE1BQU0sV0FBVztNQUNmLFNBQVM7TUFDVCxjQUFjLElBQUksT0FBTyxXQUFXO01BQ3BDLFVBQVUsTUFBTSxFQUFFO01BQ2xCLGFBQWEsTUFBTSxLQUFLO01BQ3hCLFFBQVEsTUFBTSxjQUFjO01BQzVCLE1BQU0sTUFBTSxTQUFTO01BQ3JCLGlCQUFpQixNQUFNLGVBQWU7TUFDdEMsVUFBVTtRQUNSLGNBQWM7VUFDWixRQUFRO1VBQ1IsS0FBSyxNQUFNLGdCQUFnQjtVQUMzQixRQUFRLE1BQU0sZ0JBQWdCLEdBQUcsYUFBYTtRQUNoRDtRQUNBLFdBQVc7VUFDVCxRQUFRO1VBQ1IsS0FBSyxNQUFNLFNBQVM7VUFDcEIsUUFBUSxNQUFNLFNBQVMsR0FBRyxhQUFhO1FBQ3pDO1FBQ0EsVUFBVTtVQUNSLFFBQVE7VUFDUixLQUFLLE9BQU8sU0FBUztVQUNyQixRQUFRO1FBQ1Y7UUFDQSxhQUFhO1VBQ1gsUUFBUTtVQUNSLEtBQUssUUFBUSxTQUFTO1VBQ3RCLFFBQVE7UUFDVjtRQUNBLGFBQWE7VUFDWCxRQUFRO1VBQ1IsS0FBSztVQUNMLFFBQVE7UUFDVjtNQUNGO01BQ0EsY0FBYztRQUNaLFdBQVc7VUFBQztVQUFXO1VBQWU7VUFBZ0I7VUFBWTtVQUFVO1NBQWE7UUFDekYsV0FBVztRQUNYLGVBQWU7TUFDakI7SUFDRjtJQUVBLE1BQU0sbUJBQW1CLENBQUMsV0FBVyxFQUFFLFFBQVEsY0FBYyxDQUFDO0lBQzlELE1BQU0sU0FBUyxPQUFPLENBQ25CLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxrQkFBa0IsSUFBSSxLQUFLO01BQUMsS0FBSyxTQUFTLENBQUMsVUFBVSxNQUFNO0tBQUcsRUFBRTtNQUFFLE1BQU07SUFBbUIsSUFBSTtNQUNyRyxRQUFRO01BQ1IsYUFBYTtJQUNmO0lBRUYsTUFBTSxFQUFFLE1BQU0sV0FBVyxFQUFFLEdBQUcsU0FBUyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsWUFBWSxDQUFDO0lBRTNFLDREQUE0RDtJQUM1RCxNQUFNLFNBQ0gsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO01BQ04sZUFBZSxZQUFZLFNBQVM7TUFDcEMsaUJBQWlCLFFBQVEsU0FBUztJQUNwQyxHQUNDLEVBQUUsQ0FBQyxNQUFNO0lBRVosK0JBQStCO0lBQy9CLE1BQU0sRUFBRSxNQUFNLFFBQVEsRUFBRSxHQUFHLE1BQU0sU0FDOUIsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLE1BQU0sU0FDVCxNQUFNO0lBRVQsSUFBSSxVQUFVO01BQ1osTUFBTSxTQUFTLElBQUksQ0FBQyxxQkFBcUIsTUFBTSxDQUFDO1FBQzlDLFVBQVU7UUFDVixTQUFTLFNBQVMsT0FBTztRQUN6QixRQUFRO1FBQ1IsT0FBTztRQUNQLFNBQVM7VUFDUCxjQUFjLFlBQVksU0FBUztVQUNuQyxTQUFTLE9BQU8sU0FBUztVQUN6QixpQkFBaUIsUUFBUSxTQUFTO1VBQ2xDLFlBQVksQ0FBQyxDQUFDLE1BQU0sZ0JBQWdCO1VBQ3BDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sU0FBUztVQUM1QixXQUFXO1FBQ2I7TUFDRjtNQUVBLGNBQWM7TUFDZCxNQUFNLFNBQVMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7UUFDMUMsU0FBUyxTQUFTLE9BQU87UUFDekIsTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTLENBQUMsVUFBVSxFQUFFLE1BQU0sS0FBSyxDQUFDLGdGQUFnRixDQUFDO1FBQ25ILGFBQWE7UUFDYixXQUFXO01BQ2I7SUFDRjtJQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULFVBQVU7UUFDUixhQUFhLFlBQVksU0FBUztRQUNsQyxRQUFRLE9BQU8sU0FBUztRQUN4QixnQkFBZ0IsUUFBUSxTQUFTO1FBQ2pDLGdCQUFnQixNQUFNLGdCQUFnQjtRQUN0QyxVQUFVLE1BQU0sU0FBUztRQUN6QixlQUFlO01BQ2pCO0lBQ0YsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLCtCQUErQjtJQUM3QyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU8sT0FBTztJQUFRLElBQ2hEO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
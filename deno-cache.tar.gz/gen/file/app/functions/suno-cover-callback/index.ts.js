import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const BASE_URL = Deno.env.get("BASE_URL") || "https://aimuza.ru";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "http://api:3000";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
// Download external image and upload to local storage
async function downloadCoverToStorage(externalUrl, trackId, index) {
  try {
    console.log(`Downloading cover from: ${externalUrl}`);
    const resp = await fetch(externalUrl);
    if (!resp.ok) {
      console.log(`Download failed: ${resp.status}`);
      return null;
    }
    const blob = await resp.blob();
    const buffer = new Uint8Array(await blob.arrayBuffer());
    // Determine extension from content type
    const contentType = blob.type || "image/png";
    const ext = contentType.includes("jpeg") || contentType.includes("jpg") ? "jpg" : "png";
    const filePath = `covers/${trackId}-suno-${index}.${ext}`;
    // Upload to local storage API
    const uploadResp = await fetch(`${SUPABASE_URL}/storage/v1/object/tracks/${filePath}`, {
      method: "PUT",
      headers: {
        "Content-Type": contentType,
        "Authorization": `Bearer ${SERVICE_ROLE_KEY}`
      },
      body: buffer
    });
    if (!uploadResp.ok) {
      const errText = await uploadResp.text();
      console.log(`Upload to storage failed: ${uploadResp.status} ${errText}`);
      return null;
    }
    const localUrl = `${BASE_URL}/storage/v1/object/public/tracks/${filePath}`;
    console.log(`Cover saved to storage: ${localUrl}`);
    return localUrl;
  } catch (err) {
    console.error(`Error downloading cover:`, err);
    return null;
  }
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // Verify callback secret
    const callbackSecret = Deno.env.get("SUNO_CALLBACK_SECRET");
    if (callbackSecret) {
      const url = new URL(req.url);
      const headerToken = req.headers.get("x-callback-secret") || req.headers.get("authorization")?.replace("Bearer ", "");
      const queryToken = url.searchParams.get("secret");
      if (headerToken !== callbackSecret && queryToken !== callbackSecret) {
        console.error("Invalid callback secret provided");
        return new Response(JSON.stringify({
          error: "Unauthorized"
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      console.log("Cover callback secret verified");
    }
    const supabaseAdmin = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
    const callbackData = await req.json();
    console.log("Suno cover callback received:", JSON.stringify(callbackData));
    const code = callbackData?.code;
    const msg = callbackData?.msg;
    const coverTaskId = callbackData?.data?.taskId;
    const images = callbackData?.data?.images || [];
    console.log(`Cover callback: code=${code}, taskId=${coverTaskId}, images=${images.length}`);
    // Handle errors
    if (code !== 200) {
      console.error(`Cover generation failed: code=${code}, msg=${msg}`);
      // Remove cover_task_id marker from tracks (so it's clear it failed)
      if (coverTaskId) {
        const { data: failedTracks } = await supabaseAdmin.from("tracks").select("id, description").ilike("description", `%[cover_task_id: ${coverTaskId}]%`);
        for (const track of failedTracks || []){
          const cleanDesc = (track.description || "").replace(`\n\n[cover_task_id: ${coverTaskId}]`, "").replace(`[cover_task_id: ${coverTaskId}]`, "").trim();
          await supabaseAdmin.from("tracks").update({
            description: cleanDesc || null
          }).eq("id", track.id);
        }
      }
      return new Response(JSON.stringify({
        received: true,
        message: "Cover generation failed"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (images.length === 0) {
      console.log("No cover images in callback");
      return new Response(JSON.stringify({
        received: true,
        message: "No images"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Find tracks matching this cover_task_id
    let matchedTracks = [];
    if (coverTaskId) {
      const { data: tracks, error } = await supabaseAdmin.from("tracks").select("id, title, description, cover_url").ilike("description", `%[cover_task_id: ${coverTaskId}]%`).order("created_at", {
        ascending: true
      });
      if (error) {
        console.error("Error finding tracks by cover_task_id:", error);
      } else if (tracks && tracks.length > 0) {
        matchedTracks = tracks;
        console.log(`Found ${tracks.length} tracks for cover_task_id ${coverTaskId}`);
      }
    }
    if (matchedTracks.length === 0) {
      console.warn(`No tracks found for cover_task_id ${coverTaskId}`);
      return new Response(JSON.stringify({
        received: true,
        warning: "No matching tracks"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Assign images to tracks: image[0] → track[0], image[1] → track[1]
    // Suno usually generates 2 cover variants
    let updatedCount = 0;
    for(let i = 0; i < matchedTracks.length; i++){
      const track = matchedTracks[i];
      const imageUrl = images[i] || images[0]; // fallback to first image if fewer images than tracks
      if (!imageUrl) continue;
      // Download cover to local storage
      const localCoverUrl = await downloadCoverToStorage(imageUrl, track.id, i);
      const finalCoverUrl = localCoverUrl || imageUrl;
      // Clean description: remove cover_task_id marker
      const cleanDesc = (track.description || "").replace(`\n\n[cover_task_id: ${coverTaskId}]`, "").replace(`[cover_task_id: ${coverTaskId}]`, "").trim();
      const { error: updateError } = await supabaseAdmin.from("tracks").update({
        cover_url: finalCoverUrl,
        description: cleanDesc || null
      }).eq("id", track.id);
      if (updateError) {
        console.error(`Error updating track ${track.id} cover:`, updateError);
      } else {
        console.log(`Track ${track.id} (${track.title}) cover updated: ${finalCoverUrl}`);
        updatedCount++;
      }
    }
    console.log(`Cover callback processed: ${updatedCount} tracks updated`);
    return new Response(JSON.stringify({
      received: true,
      success: true,
      updated: updatedCount
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("suno-cover-callback error:", error);
    return new Response(JSON.stringify({
      received: true,
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9zdW5vLWNvdmVyLWNhbGxiYWNrL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE2OC4wL2h0dHAvc2VydmVyLnRzXCI7XHJcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xyXG5cclxuY29uc3QgY29yc0hlYWRlcnMgPSB7XHJcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXHJcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcclxufTtcclxuXHJcbmNvbnN0IEJBU0VfVVJMID0gRGVuby5lbnYuZ2V0KFwiQkFTRV9VUkxcIikgfHwgXCJodHRwczovL2FpbXV6YS5ydVwiO1xyXG5jb25zdCBTVVBBQkFTRV9VUkwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgfHwgXCJodHRwOi8vYXBpOjMwMDBcIjtcclxuY29uc3QgU0VSVklDRV9ST0xFX0tFWSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikgfHwgXCJcIjtcclxuXHJcbi8vIERvd25sb2FkIGV4dGVybmFsIGltYWdlIGFuZCB1cGxvYWQgdG8gbG9jYWwgc3RvcmFnZVxyXG5hc3luYyBmdW5jdGlvbiBkb3dubG9hZENvdmVyVG9TdG9yYWdlKFxyXG4gIGV4dGVybmFsVXJsOiBzdHJpbmcsXHJcbiAgdHJhY2tJZDogc3RyaW5nLFxyXG4gIGluZGV4OiBudW1iZXJcclxuKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnNvbGUubG9nKGBEb3dubG9hZGluZyBjb3ZlciBmcm9tOiAke2V4dGVybmFsVXJsfWApO1xyXG4gICAgY29uc3QgcmVzcCA9IGF3YWl0IGZldGNoKGV4dGVybmFsVXJsKTtcclxuICAgIGlmICghcmVzcC5vaykge1xyXG4gICAgICBjb25zb2xlLmxvZyhgRG93bmxvYWQgZmFpbGVkOiAke3Jlc3Auc3RhdHVzfWApO1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwLmJsb2IoKTtcclxuICAgIGNvbnN0IGJ1ZmZlciA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSk7XHJcblxyXG4gICAgLy8gRGV0ZXJtaW5lIGV4dGVuc2lvbiBmcm9tIGNvbnRlbnQgdHlwZVxyXG4gICAgY29uc3QgY29udGVudFR5cGUgPSBibG9iLnR5cGUgfHwgXCJpbWFnZS9wbmdcIjtcclxuICAgIGNvbnN0IGV4dCA9IGNvbnRlbnRUeXBlLmluY2x1ZGVzKFwianBlZ1wiKSB8fCBjb250ZW50VHlwZS5pbmNsdWRlcyhcImpwZ1wiKSA/IFwianBnXCIgOiBcInBuZ1wiO1xyXG4gICAgY29uc3QgZmlsZVBhdGggPSBgY292ZXJzLyR7dHJhY2tJZH0tc3Vuby0ke2luZGV4fS4ke2V4dH1gO1xyXG5cclxuICAgIC8vIFVwbG9hZCB0byBsb2NhbCBzdG9yYWdlIEFQSVxyXG4gICAgY29uc3QgdXBsb2FkUmVzcCA9IGF3YWl0IGZldGNoKFxyXG4gICAgICBgJHtTVVBBQkFTRV9VUkx9L3N0b3JhZ2UvdjEvb2JqZWN0L3RyYWNrcy8ke2ZpbGVQYXRofWAsXHJcbiAgICAgIHtcclxuICAgICAgICBtZXRob2Q6IFwiUFVUXCIsXHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogY29udGVudFR5cGUsXHJcbiAgICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NFUlZJQ0VfUk9MRV9LRVl9YCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJvZHk6IGJ1ZmZlcixcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAoIXVwbG9hZFJlc3Aub2spIHtcclxuICAgICAgY29uc3QgZXJyVGV4dCA9IGF3YWl0IHVwbG9hZFJlc3AudGV4dCgpO1xyXG4gICAgICBjb25zb2xlLmxvZyhgVXBsb2FkIHRvIHN0b3JhZ2UgZmFpbGVkOiAke3VwbG9hZFJlc3Auc3RhdHVzfSAke2VyclRleHR9YCk7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGxvY2FsVXJsID0gYCR7QkFTRV9VUkx9L3N0b3JhZ2UvdjEvb2JqZWN0L3B1YmxpYy90cmFja3MvJHtmaWxlUGF0aH1gO1xyXG4gICAgY29uc29sZS5sb2coYENvdmVyIHNhdmVkIHRvIHN0b3JhZ2U6ICR7bG9jYWxVcmx9YCk7XHJcbiAgICByZXR1cm4gbG9jYWxVcmw7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGBFcnJvciBkb3dubG9hZGluZyBjb3ZlcjpgLCBlcnIpO1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XHJcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XHJcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XHJcbiAgfVxyXG5cclxuICB0cnkge1xyXG4gICAgLy8gVmVyaWZ5IGNhbGxiYWNrIHNlY3JldFxyXG4gICAgY29uc3QgY2FsbGJhY2tTZWNyZXQgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0NBTExCQUNLX1NFQ1JFVFwiKTtcclxuICAgIGlmIChjYWxsYmFja1NlY3JldCkge1xyXG4gICAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHJlcS51cmwpO1xyXG4gICAgICBjb25zdCBoZWFkZXJUb2tlbiA9IHJlcS5oZWFkZXJzLmdldChcIngtY2FsbGJhY2stc2VjcmV0XCIpIHx8IHJlcS5oZWFkZXJzLmdldChcImF1dGhvcml6YXRpb25cIik/LnJlcGxhY2UoXCJCZWFyZXIgXCIsIFwiXCIpO1xyXG4gICAgICBjb25zdCBxdWVyeVRva2VuID0gdXJsLnNlYXJjaFBhcmFtcy5nZXQoXCJzZWNyZXRcIik7XHJcblxyXG4gICAgICBpZiAoaGVhZGVyVG9rZW4gIT09IGNhbGxiYWNrU2VjcmV0ICYmIHF1ZXJ5VG9rZW4gIT09IGNhbGxiYWNrU2VjcmV0KSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkludmFsaWQgY2FsbGJhY2sgc2VjcmV0IHByb3ZpZGVkXCIpO1xyXG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXHJcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxyXG4gICAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgICBjb25zb2xlLmxvZyhcIkNvdmVyIGNhbGxiYWNrIHNlY3JldCB2ZXJpZmllZFwiKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBzdXBhYmFzZUFkbWluID0gY3JlYXRlQ2xpZW50KFxyXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgPz8gXCJcIixcclxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSA/PyBcIlwiXHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IGNhbGxiYWNrRGF0YSA9IGF3YWl0IHJlcS5qc29uKCk7XHJcbiAgICBjb25zb2xlLmxvZyhcIlN1bm8gY292ZXIgY2FsbGJhY2sgcmVjZWl2ZWQ6XCIsIEpTT04uc3RyaW5naWZ5KGNhbGxiYWNrRGF0YSkpO1xyXG5cclxuICAgIGNvbnN0IGNvZGUgPSBjYWxsYmFja0RhdGE/LmNvZGU7XHJcbiAgICBjb25zdCBtc2cgPSBjYWxsYmFja0RhdGE/Lm1zZztcclxuICAgIGNvbnN0IGNvdmVyVGFza0lkID0gY2FsbGJhY2tEYXRhPy5kYXRhPy50YXNrSWQ7XHJcbiAgICBjb25zdCBpbWFnZXMgPSBjYWxsYmFja0RhdGE/LmRhdGE/LmltYWdlcyB8fCBbXTtcclxuXHJcbiAgICBjb25zb2xlLmxvZyhgQ292ZXIgY2FsbGJhY2s6IGNvZGU9JHtjb2RlfSwgdGFza0lkPSR7Y292ZXJUYXNrSWR9LCBpbWFnZXM9JHtpbWFnZXMubGVuZ3RofWApO1xyXG5cclxuICAgIC8vIEhhbmRsZSBlcnJvcnNcclxuICAgIGlmIChjb2RlICE9PSAyMDApIHtcclxuICAgICAgY29uc29sZS5lcnJvcihgQ292ZXIgZ2VuZXJhdGlvbiBmYWlsZWQ6IGNvZGU9JHtjb2RlfSwgbXNnPSR7bXNnfWApO1xyXG4gICAgICAvLyBSZW1vdmUgY292ZXJfdGFza19pZCBtYXJrZXIgZnJvbSB0cmFja3MgKHNvIGl0J3MgY2xlYXIgaXQgZmFpbGVkKVxyXG4gICAgICBpZiAoY292ZXJUYXNrSWQpIHtcclxuICAgICAgICBjb25zdCB7IGRhdGE6IGZhaWxlZFRyYWNrcyB9ID0gYXdhaXQgc3VwYWJhc2VBZG1pblxyXG4gICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcclxuICAgICAgICAgIC5zZWxlY3QoXCJpZCwgZGVzY3JpcHRpb25cIilcclxuICAgICAgICAgIC5pbGlrZShcImRlc2NyaXB0aW9uXCIsIGAlW2NvdmVyX3Rhc2tfaWQ6ICR7Y292ZXJUYXNrSWR9XSVgKTtcclxuXHJcbiAgICAgICAgZm9yIChjb25zdCB0cmFjayBvZiBmYWlsZWRUcmFja3MgfHwgW10pIHtcclxuICAgICAgICAgIGNvbnN0IGNsZWFuRGVzYyA9ICh0cmFjay5kZXNjcmlwdGlvbiB8fCBcIlwiKVxyXG4gICAgICAgICAgICAucmVwbGFjZShgXFxuXFxuW2NvdmVyX3Rhc2tfaWQ6ICR7Y292ZXJUYXNrSWR9XWAsIFwiXCIpXHJcbiAgICAgICAgICAgIC5yZXBsYWNlKGBbY292ZXJfdGFza19pZDogJHtjb3ZlclRhc2tJZH1dYCwgXCJcIilcclxuICAgICAgICAgICAgLnRyaW0oKTtcclxuICAgICAgICAgIGF3YWl0IHN1cGFiYXNlQWRtaW5cclxuICAgICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcclxuICAgICAgICAgICAgLnVwZGF0ZSh7IGRlc2NyaXB0aW9uOiBjbGVhbkRlc2MgfHwgbnVsbCB9KVxyXG4gICAgICAgICAgICAuZXEoXCJpZFwiLCB0cmFjay5pZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXHJcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyByZWNlaXZlZDogdHJ1ZSwgbWVzc2FnZTogXCJDb3ZlciBnZW5lcmF0aW9uIGZhaWxlZFwiIH0pLFxyXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGltYWdlcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgY29uc29sZS5sb2coXCJObyBjb3ZlciBpbWFnZXMgaW4gY2FsbGJhY2tcIik7XHJcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXHJcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyByZWNlaXZlZDogdHJ1ZSwgbWVzc2FnZTogXCJObyBpbWFnZXNcIiB9KSxcclxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEZpbmQgdHJhY2tzIG1hdGNoaW5nIHRoaXMgY292ZXJfdGFza19pZFxyXG4gICAgbGV0IG1hdGNoZWRUcmFja3M6IEFycmF5PHsgaWQ6IHN0cmluZzsgdGl0bGU6IHN0cmluZyB8IG51bGw7IGRlc2NyaXB0aW9uOiBzdHJpbmcgfCBudWxsOyBjb3Zlcl91cmw6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcclxuXHJcbiAgICBpZiAoY292ZXJUYXNrSWQpIHtcclxuICAgICAgY29uc3QgeyBkYXRhOiB0cmFja3MsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluXHJcbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcclxuICAgICAgICAuc2VsZWN0KFwiaWQsIHRpdGxlLCBkZXNjcmlwdGlvbiwgY292ZXJfdXJsXCIpXHJcbiAgICAgICAgLmlsaWtlKFwiZGVzY3JpcHRpb25cIiwgYCVbY292ZXJfdGFza19pZDogJHtjb3ZlclRhc2tJZH1dJWApXHJcbiAgICAgICAgLm9yZGVyKFwiY3JlYXRlZF9hdFwiLCB7IGFzY2VuZGluZzogdHJ1ZSB9KTtcclxuXHJcbiAgICAgIGlmIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmaW5kaW5nIHRyYWNrcyBieSBjb3Zlcl90YXNrX2lkOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZWxzZSBpZiAodHJhY2tzICYmIHRyYWNrcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgbWF0Y2hlZFRyYWNrcyA9IHRyYWNrcztcclxuICAgICAgICBjb25zb2xlLmxvZyhgRm91bmQgJHt0cmFja3MubGVuZ3RofSB0cmFja3MgZm9yIGNvdmVyX3Rhc2tfaWQgJHtjb3ZlclRhc2tJZH1gKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGlmIChtYXRjaGVkVHJhY2tzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBjb25zb2xlLndhcm4oYE5vIHRyYWNrcyBmb3VuZCBmb3IgY292ZXJfdGFza19pZCAke2NvdmVyVGFza0lkfWApO1xyXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxyXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgcmVjZWl2ZWQ6IHRydWUsIHdhcm5pbmc6IFwiTm8gbWF0Y2hpbmcgdHJhY2tzXCIgfSksXHJcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBBc3NpZ24gaW1hZ2VzIHRvIHRyYWNrczogaW1hZ2VbMF0g4oaSIHRyYWNrWzBdLCBpbWFnZVsxXSDihpIgdHJhY2tbMV1cclxuICAgIC8vIFN1bm8gdXN1YWxseSBnZW5lcmF0ZXMgMiBjb3ZlciB2YXJpYW50c1xyXG4gICAgbGV0IHVwZGF0ZWRDb3VudCA9IDA7XHJcblxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXRjaGVkVHJhY2tzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIGNvbnN0IHRyYWNrID0gbWF0Y2hlZFRyYWNrc1tpXTtcclxuICAgICAgY29uc3QgaW1hZ2VVcmwgPSBpbWFnZXNbaV0gfHwgaW1hZ2VzWzBdOyAvLyBmYWxsYmFjayB0byBmaXJzdCBpbWFnZSBpZiBmZXdlciBpbWFnZXMgdGhhbiB0cmFja3NcclxuXHJcbiAgICAgIGlmICghaW1hZ2VVcmwpIGNvbnRpbnVlO1xyXG5cclxuICAgICAgLy8gRG93bmxvYWQgY292ZXIgdG8gbG9jYWwgc3RvcmFnZVxyXG4gICAgICBjb25zdCBsb2NhbENvdmVyVXJsID0gYXdhaXQgZG93bmxvYWRDb3ZlclRvU3RvcmFnZShpbWFnZVVybCwgdHJhY2suaWQsIGkpO1xyXG4gICAgICBjb25zdCBmaW5hbENvdmVyVXJsID0gbG9jYWxDb3ZlclVybCB8fCBpbWFnZVVybDtcclxuXHJcbiAgICAgIC8vIENsZWFuIGRlc2NyaXB0aW9uOiByZW1vdmUgY292ZXJfdGFza19pZCBtYXJrZXJcclxuICAgICAgY29uc3QgY2xlYW5EZXNjID0gKHRyYWNrLmRlc2NyaXB0aW9uIHx8IFwiXCIpXHJcbiAgICAgICAgLnJlcGxhY2UoYFxcblxcbltjb3Zlcl90YXNrX2lkOiAke2NvdmVyVGFza0lkfV1gLCBcIlwiKVxyXG4gICAgICAgIC5yZXBsYWNlKGBbY292ZXJfdGFza19pZDogJHtjb3ZlclRhc2tJZH1dYCwgXCJcIilcclxuICAgICAgICAudHJpbSgpO1xyXG5cclxuICAgICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW5cclxuICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxyXG4gICAgICAgIC51cGRhdGUoe1xyXG4gICAgICAgICAgY292ZXJfdXJsOiBmaW5hbENvdmVyVXJsLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IGNsZWFuRGVzYyB8fCBudWxsLFxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2suaWQpO1xyXG5cclxuICAgICAgaWYgKHVwZGF0ZUVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgdXBkYXRpbmcgdHJhY2sgJHt0cmFjay5pZH0gY292ZXI6YCwgdXBkYXRlRXJyb3IpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGBUcmFjayAke3RyYWNrLmlkfSAoJHt0cmFjay50aXRsZX0pIGNvdmVyIHVwZGF0ZWQ6ICR7ZmluYWxDb3ZlclVybH1gKTtcclxuICAgICAgICB1cGRhdGVkQ291bnQrKztcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnNvbGUubG9nKGBDb3ZlciBjYWxsYmFjayBwcm9jZXNzZWQ6ICR7dXBkYXRlZENvdW50fSB0cmFja3MgdXBkYXRlZGApO1xyXG5cclxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXHJcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgcmVjZWl2ZWQ6IHRydWUsIHN1Y2Nlc3M6IHRydWUsIHVwZGF0ZWQ6IHVwZGF0ZWRDb3VudCB9KSxcclxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cclxuICAgICk7XHJcblxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwic3Vuby1jb3Zlci1jYWxsYmFjayBlcnJvcjpcIiwgZXJyb3IpO1xyXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcclxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHJlY2VpdmVkOiB0cnVlLFxyXG4gICAgICAgIGVycm9yOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiLFxyXG4gICAgICB9KSxcclxuICAgICAge1xyXG4gICAgICAgIHN0YXR1czogNTAwLFxyXG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXHJcbiAgICAgIH1cclxuICAgICk7XHJcbiAgfVxyXG59KTtcclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLFdBQVcsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGVBQWU7QUFDN0MsTUFBTSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUI7QUFDckQsTUFBTSxtQkFBbUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdDQUFnQztBQUV0RSxzREFBc0Q7QUFDdEQsZUFBZSx1QkFDYixXQUFtQixFQUNuQixPQUFlLEVBQ2YsS0FBYTtFQUViLElBQUk7SUFDRixRQUFRLEdBQUcsQ0FBQyxDQUFDLHdCQUF3QixFQUFFLFlBQVksQ0FBQztJQUNwRCxNQUFNLE9BQU8sTUFBTSxNQUFNO0lBQ3pCLElBQUksQ0FBQyxLQUFLLEVBQUUsRUFBRTtNQUNaLFFBQVEsR0FBRyxDQUFDLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxNQUFNLENBQUMsQ0FBQztNQUM3QyxPQUFPO0lBQ1Q7SUFDQSxNQUFNLE9BQU8sTUFBTSxLQUFLLElBQUk7SUFDNUIsTUFBTSxTQUFTLElBQUksV0FBVyxNQUFNLEtBQUssV0FBVztJQUVwRCx3Q0FBd0M7SUFDeEMsTUFBTSxjQUFjLEtBQUssSUFBSSxJQUFJO0lBQ2pDLE1BQU0sTUFBTSxZQUFZLFFBQVEsQ0FBQyxXQUFXLFlBQVksUUFBUSxDQUFDLFNBQVMsUUFBUTtJQUNsRixNQUFNLFdBQVcsQ0FBQyxPQUFPLEVBQUUsUUFBUSxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDO0lBRXpELDhCQUE4QjtJQUM5QixNQUFNLGFBQWEsTUFBTSxNQUN2QixDQUFDLEVBQUUsYUFBYSwwQkFBMEIsRUFBRSxTQUFTLENBQUMsRUFDdEQ7TUFDRSxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLENBQUM7TUFDL0M7TUFDQSxNQUFNO0lBQ1I7SUFHRixJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUU7TUFDbEIsTUFBTSxVQUFVLE1BQU0sV0FBVyxJQUFJO01BQ3JDLFFBQVEsR0FBRyxDQUFDLENBQUMsMEJBQTBCLEVBQUUsV0FBVyxNQUFNLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQztNQUN2RSxPQUFPO0lBQ1Q7SUFFQSxNQUFNLFdBQVcsQ0FBQyxFQUFFLFNBQVMsaUNBQWlDLEVBQUUsU0FBUyxDQUFDO0lBQzFFLFFBQVEsR0FBRyxDQUFDLENBQUMsd0JBQXdCLEVBQUUsU0FBUyxDQUFDO0lBQ2pELE9BQU87RUFDVCxFQUFFLE9BQU8sS0FBSztJQUNaLFFBQVEsS0FBSyxDQUFDLENBQUMsd0JBQXdCLENBQUMsRUFBRTtJQUMxQyxPQUFPO0VBQ1Q7QUFDRjtBQUVBLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLHlCQUF5QjtJQUN6QixNQUFNLGlCQUFpQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDcEMsSUFBSSxnQkFBZ0I7TUFDbEIsTUFBTSxNQUFNLElBQUksSUFBSSxJQUFJLEdBQUc7TUFDM0IsTUFBTSxjQUFjLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixRQUFRLFdBQVc7TUFDakgsTUFBTSxhQUFhLElBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQztNQUV4QyxJQUFJLGdCQUFnQixrQkFBa0IsZUFBZSxnQkFBZ0I7UUFDbkUsUUFBUSxLQUFLLENBQUM7UUFDZCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBZSxJQUN2QztVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFDQSxRQUFRLEdBQUcsQ0FBQztJQUNkO0lBRUEsTUFBTSxnQkFBZ0IsYUFDcEIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0lBRy9DLE1BQU0sZUFBZSxNQUFNLElBQUksSUFBSTtJQUNuQyxRQUFRLEdBQUcsQ0FBQyxpQ0FBaUMsS0FBSyxTQUFTLENBQUM7SUFFNUQsTUFBTSxPQUFPLGNBQWM7SUFDM0IsTUFBTSxNQUFNLGNBQWM7SUFDMUIsTUFBTSxjQUFjLGNBQWMsTUFBTTtJQUN4QyxNQUFNLFNBQVMsY0FBYyxNQUFNLFVBQVUsRUFBRTtJQUUvQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLEtBQUssU0FBUyxFQUFFLFlBQVksU0FBUyxFQUFFLE9BQU8sTUFBTSxDQUFDLENBQUM7SUFFMUYsZ0JBQWdCO0lBQ2hCLElBQUksU0FBUyxLQUFLO01BQ2hCLFFBQVEsS0FBSyxDQUFDLENBQUMsOEJBQThCLEVBQUUsS0FBSyxNQUFNLEVBQUUsSUFBSSxDQUFDO01BQ2pFLG9FQUFvRTtNQUNwRSxJQUFJLGFBQWE7UUFDZixNQUFNLEVBQUUsTUFBTSxZQUFZLEVBQUUsR0FBRyxNQUFNLGNBQ2xDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxtQkFDUCxLQUFLLENBQUMsZUFBZSxDQUFDLGlCQUFpQixFQUFFLFlBQVksRUFBRSxDQUFDO1FBRTNELEtBQUssTUFBTSxTQUFTLGdCQUFnQixFQUFFLENBQUU7VUFDdEMsTUFBTSxZQUFZLENBQUMsTUFBTSxXQUFXLElBQUksRUFBRSxFQUN2QyxPQUFPLENBQUMsQ0FBQyxvQkFBb0IsRUFBRSxZQUFZLENBQUMsQ0FBQyxFQUFFLElBQy9DLE9BQU8sQ0FBQyxDQUFDLGdCQUFnQixFQUFFLFlBQVksQ0FBQyxDQUFDLEVBQUUsSUFDM0MsSUFBSTtVQUNQLE1BQU0sY0FDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7WUFBRSxhQUFhLGFBQWE7VUFBSyxHQUN4QyxFQUFFLENBQUMsTUFBTSxNQUFNLEVBQUU7UUFDdEI7TUFDRjtNQUNBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsVUFBVTtRQUFNLFNBQVM7TUFBMEIsSUFDcEU7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxJQUFJLE9BQU8sTUFBTSxLQUFLLEdBQUc7TUFDdkIsUUFBUSxHQUFHLENBQUM7TUFDWixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLFVBQVU7UUFBTSxTQUFTO01BQVksSUFDdEQ7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSwwQ0FBMEM7SUFDMUMsSUFBSSxnQkFBbUgsRUFBRTtJQUV6SCxJQUFJLGFBQWE7TUFDZixNQUFNLEVBQUUsTUFBTSxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxjQUNuQyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMscUNBQ1AsS0FBSyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsRUFBRSxZQUFZLEVBQUUsQ0FBQyxFQUN4RCxLQUFLLENBQUMsY0FBYztRQUFFLFdBQVc7TUFBSztNQUV6QyxJQUFJLE9BQU87UUFDVCxRQUFRLEtBQUssQ0FBQywwQ0FBMEM7TUFDMUQsT0FBTyxJQUFJLFVBQVUsT0FBTyxNQUFNLEdBQUcsR0FBRztRQUN0QyxnQkFBZ0I7UUFDaEIsUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxNQUFNLENBQUMsMEJBQTBCLEVBQUUsWUFBWSxDQUFDO01BQzlFO0lBQ0Y7SUFFQSxJQUFJLGNBQWMsTUFBTSxLQUFLLEdBQUc7TUFDOUIsUUFBUSxJQUFJLENBQUMsQ0FBQyxrQ0FBa0MsRUFBRSxZQUFZLENBQUM7TUFDL0QsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxVQUFVO1FBQU0sU0FBUztNQUFxQixJQUMvRDtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLG9FQUFvRTtJQUNwRSwwQ0FBMEM7SUFDMUMsSUFBSSxlQUFlO0lBRW5CLElBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxjQUFjLE1BQU0sRUFBRSxJQUFLO01BQzdDLE1BQU0sUUFBUSxhQUFhLENBQUMsRUFBRTtNQUM5QixNQUFNLFdBQVcsTUFBTSxDQUFDLEVBQUUsSUFBSSxNQUFNLENBQUMsRUFBRSxFQUFFLHNEQUFzRDtNQUUvRixJQUFJLENBQUMsVUFBVTtNQUVmLGtDQUFrQztNQUNsQyxNQUFNLGdCQUFnQixNQUFNLHVCQUF1QixVQUFVLE1BQU0sRUFBRSxFQUFFO01BQ3ZFLE1BQU0sZ0JBQWdCLGlCQUFpQjtNQUV2QyxpREFBaUQ7TUFDakQsTUFBTSxZQUFZLENBQUMsTUFBTSxXQUFXLElBQUksRUFBRSxFQUN2QyxPQUFPLENBQUMsQ0FBQyxvQkFBb0IsRUFBRSxZQUFZLENBQUMsQ0FBQyxFQUFFLElBQy9DLE9BQU8sQ0FBQyxDQUFDLGdCQUFnQixFQUFFLFlBQVksQ0FBQyxDQUFDLEVBQUUsSUFDM0MsSUFBSTtNQUVQLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sY0FDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sV0FBVztRQUNYLGFBQWEsYUFBYTtNQUM1QixHQUNDLEVBQUUsQ0FBQyxNQUFNLE1BQU0sRUFBRTtNQUVwQixJQUFJLGFBQWE7UUFDZixRQUFRLEtBQUssQ0FBQyxDQUFDLHFCQUFxQixFQUFFLE1BQU0sRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQzNELE9BQU87UUFDTCxRQUFRLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsTUFBTSxLQUFLLENBQUMsaUJBQWlCLEVBQUUsY0FBYyxDQUFDO1FBQ2hGO01BQ0Y7SUFDRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsMEJBQTBCLEVBQUUsYUFBYSxlQUFlLENBQUM7SUFFdEUsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxVQUFVO01BQU0sU0FBUztNQUFNLFNBQVM7SUFBYSxJQUN0RTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLDhCQUE4QjtJQUM1QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFVBQVU7TUFDVixPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ2xELElBQ0E7TUFDRSxRQUFRO01BQ1IsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUNoRTtFQUVKO0FBQ0YifQ==
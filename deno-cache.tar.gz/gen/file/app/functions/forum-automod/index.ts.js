import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
/** Map technical flag names to human-readable descriptions */ function humanizeFlag(flag) {
  const map = {
    stopwords: "Обнаружена ненормативная лексика",
    too_many_links: "Слишком много ссылок",
    blacklisted_link: "Запрещённая ссылка",
    regex_match: "Обнаружено запрещённое выражение",
    newbie_premod: "Премодерация нового пользователя",
    ad_too_many_links: "Подозрение на рекламу: много ссылок",
    ad_external_links: "Подозрение на рекламу: внешние ссылки",
    ai_toxic: "Обнаружен токсичный контент",
    ai_insult: "Обнаружены оскорбления",
    ai_hate: "Обнаружен язык ненависти",
    ai_threat: "Обнаружены угрозы",
    ai_spam: "Обнаружен спам",
    ai_low_quality: "Низкое качество контента"
  };
  // Handle dynamic flags like "ad_ai_promo"
  if (flag.startsWith("ad_ai_")) return "Обнаружена реклама";
  if (flag.startsWith("ai_")) return map[flag] || "Нарушение правил (AI-проверка)";
  return map[flag] || "Нарушение правил форума";
}
Deno.serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        allowed: false,
        reason: "unauthorized",
        message: "Необходимо войти в систему"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
    const userClient = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_ANON_KEY"), {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: authError } = await userClient.auth.getUser();
    if (authError || !user) {
      console.error("Auth error:", authError);
      return new Response(JSON.stringify({
        allowed: false,
        reason: "unauthorized",
        message: "Не авторизован"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const body = await req.json();
    const { content, title, type } = body;
    const textToCheck = title ? `${title} ${content}` : content;
    const flags = [];
    let autoHidden = false;
    console.log(`[forum-automod] Checking ${type} from user ${user.id}, length: ${textToCheck.length}`);
    // Fetch all settings at once
    const { data: settings } = await supabase.from("forum_automod_settings").select("key, value");
    const settingsMap = {};
    (settings || []).forEach((s)=>{
      settingsMap[s.key] = s.value;
    });
    // ── 0. Get user trust level ───────────────────────────────
    const { data: userStats } = await supabase.from("forum_user_stats").select("trust_level").eq("user_id", user.id).maybeSingle();
    const userTrustLevel = userStats?.trust_level ?? 0;
    // ── 1. Rate Limit Check ────────────────────────────────────
    const result1 = await checkRateLimit(supabase, user.id);
    if (result1) return jsonResponse(result1);
    // ── 2. Stopwords Check ─────────────────────────────────────
    checkStopwords(settingsMap, textToCheck, flags, (v)=>{
      autoHidden = autoHidden || v;
    });
    // ── 3. Link Filter ─────────────────────────────────────────
    checkLinks(settingsMap, textToCheck, flags, (v)=>{
      autoHidden = autoHidden || v;
    });
    // ── 4. Regex Filters ───────────────────────────────────────
    checkRegex(settingsMap, textToCheck, flags, (v)=>{
      autoHidden = autoHidden || v;
    });
    // ── 5. Newbie Premoderation ─────────────────────────────────
    await checkNewbie(supabase, settingsMap, user.id, userTrustLevel, flags, (v)=>{
      autoHidden = autoHidden || v;
    });
    // ── 6. Duplicate Content Check ─────────────────────────────
    const dupResult = await checkDuplicate(supabase, user.id, textToCheck);
    if (dupResult) return jsonResponse(dupResult);
    // ── 6.5. Advertising / Promo Policy ─────────────────────────
    const adResult = await checkAdPolicy(supabase, settingsMap, user.id, userTrustLevel, textToCheck, flags, (v)=>{
      autoHidden = autoHidden || v;
    });
    if (adResult) return jsonResponse(adResult);
    // ── 7–9. AI Checks (skip for trusted users: trust_level ≥ 2) ──
    const aiTrustThreshold = settingsMap["ai_moderation"]?.skip_trust_level ?? 2;
    if (userTrustLevel < aiTrustThreshold) {
      console.log(`[forum-automod] Running AI checks for user trust_level=${userTrustLevel} (threshold=${aiTrustThreshold})`);
      await checkAIToxicity(settingsMap, textToCheck, flags, (v)=>{
        autoHidden = autoHidden || v;
      });
      await checkAISpam(settingsMap, textToCheck, flags, (v)=>{
        autoHidden = autoHidden || v;
      });
      await checkAIQuality(settingsMap, textToCheck, flags, (v)=>{
        autoHidden = autoHidden || v;
      });
    } else {
      console.log(`[forum-automod] Skipping AI checks for trusted user trust_level=${userTrustLevel}`);
    }
    // ── Result ──────────────────────────────────────────────────
    const humanFlags = flags.map((f)=>humanizeFlag(f));
    const result = {
      allowed: true,
      flags: flags.length > 0 ? flags : undefined,
      human_flags: humanFlags.length > 0 ? humanFlags : undefined,
      auto_hidden: autoHidden || undefined
    };
    if (autoHidden) {
      result.message = "Контент будет проверен модератором";
      result.hidden_reason = humanFlags.length > 0 ? `Сообщение скрыто: ${humanFlags.join(", ").toLowerCase()}` : "Сообщение скрыто автоматической модерацией";
      console.log(`[forum-automod] Content flagged for auto-hide: ${flags.join(", ")}`);
    }
    console.log(`[forum-automod] Result: allowed=${result.allowed}, flags=${flags.join(",")}, auto_hidden=${autoHidden}`);
    return jsonResponse(result);
  } catch (error) {
    console.error("[forum-automod] Error:", error);
    return jsonResponse({
      allowed: true,
      error: "Automod check failed, allowing by default"
    });
  }
});
// ── Helper: JSON Response ──────────────────────────────────
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json"
    }
  });
}
// ── Check: Rate Limit ──────────────────────────────────────
async function checkRateLimit(supabase, userId) {
  const { data: rateLimitResult } = await supabase.rpc("forum_check_rate_limit", {
    p_user_id: userId
  });
  if (rateLimitResult && !rateLimitResult.allowed) {
    console.log(`[forum-automod] Rate limit hit: ${rateLimitResult.message}`);
    return {
      allowed: false,
      reason: rateLimitResult.reason,
      message: rateLimitResult.message
    };
  }
  return null;
}
// ── Check: Stopwords (with word-boundary regex) ───────────
function checkStopwords(settingsMap, text, flags, setHidden) {
  const config = settingsMap["stopwords"];
  if (!config?.enabled || !config?.words?.length) return;
  const lowerText = text.toLowerCase();
  const matched = [];
  for (const word of config.words){
    const lowerWord = word.toLowerCase();
    // Use word-boundary regex for accurate matching
    // \b doesn't work well with Cyrillic, so use lookaround for non-word chars or string edges
    try {
      const escaped = lowerWord.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const regex = new RegExp(`(?:^|[\\s.,!?;:()\\[\\]{}\"'\\-–—/])${escaped}(?:$|[\\s.,!?;:()\\[\\]{}\"'\\-–—/])`, "i");
      if (regex.test(` ${lowerText} `)) {
        matched.push(word);
      }
    } catch  {
      // Fallback to includes for invalid patterns
      if (lowerText.includes(lowerWord)) {
        matched.push(word);
      }
    }
  }
  if (matched.length > 0) {
    console.log(`[forum-automod] Stopwords matched: ${matched.join(", ")}`);
    flags.push("stopwords");
    setHidden(true);
  }
}
// ── Check: Links ───────────────────────────────────────────
function checkLinks(settingsMap, text, flags, setHidden) {
  const config = settingsMap["link_filter"];
  if (!config?.enabled) return;
  const urlRegex = /https?:\/\/[^\s<>"']+/gi;
  const urls = text.match(urlRegex) || [];
  const maxLinks = config.max_links || 5;
  if (urls.length > maxLinks) {
    console.log(`[forum-automod] Too many links: ${urls.length} > ${maxLinks}`);
    flags.push("too_many_links");
    setHidden(true);
  }
  const blacklist = config.blacklist_domains || [];
  if (blacklist.length > 0) {
    for (const url of urls){
      try {
        const domain = new URL(url).hostname.toLowerCase();
        if (blacklist.some((bl)=>domain.includes(bl.toLowerCase()))) {
          console.log(`[forum-automod] Blacklisted domain: ${domain}`);
          flags.push("blacklisted_link");
          setHidden(true);
          break;
        }
      } catch  {}
    }
  }
}
// ── Check: Regex Filters ───────────────────────────────────
function checkRegex(settingsMap, text, flags, setHidden) {
  const config = settingsMap["regex_filters"];
  if (!config?.enabled || !config?.patterns?.length) return;
  for (const pattern of config.patterns){
    try {
      const regex = new RegExp(pattern, "gi");
      if (regex.test(text)) {
        console.log(`[forum-automod] Regex matched: ${pattern}`);
        flags.push("regex_match");
        setHidden(true);
        break;
      }
    } catch  {
      console.warn(`[forum-automod] Invalid regex pattern: ${pattern}`);
    }
  }
}
// ── Check: Newbie Premod ───────────────────────────────────
async function checkNewbie(supabase, settingsMap, userId, userTrustLevel, flags, setHidden) {
  const config = settingsMap["newbie_premod"];
  if (!config?.enabled) return;
  const maxTrustLevel = config.max_trust_level ?? 0;
  if (userTrustLevel <= maxTrustLevel) {
    console.log(`[forum-automod] Newbie premod: trust_level=${userTrustLevel}`);
    flags.push("newbie_premod");
    setHidden(true);
  }
}
// ── Check: Duplicate Content ───────────────────────────────
async function checkDuplicate(supabase, userId, text) {
  const contentHash = text.substring(0, 200).trim().toLowerCase();
  if (contentHash.length <= 20) return null;
  const { data: recentPosts } = await supabase.from("forum_posts").select("id, content").eq("user_id", userId).gte("created_at", new Date(Date.now() - 60 * 60 * 1000).toISOString()).limit(10);
  const isDuplicate = (recentPosts || []).some((p)=>p.content.substring(0, 200).trim().toLowerCase() === contentHash);
  if (isDuplicate) {
    console.log(`[forum-automod] Duplicate content detected`);
    return {
      allowed: false,
      reason: "duplicate",
      message: "Такое сообщение уже было отправлено. Пожалуйста, не дублируйте контент."
    };
  }
  return null;
}
// ── Check: Advertising / Promo Policy ──────────────────────
async function checkAdPolicy(supabase, settingsMap, userId, userTrustLevel, text, flags, setHidden) {
  const policy = settingsMap["ad_policy"];
  if (!policy?.enabled) return null;
  const urlRegex = /https?:\/\/[^\s<>"']+/gi;
  const urls = text.match(urlRegex) || [];
  const whitelist = policy.whitelist_domains || [];
  const blacklist = policy.blacklist_domains || [];
  const maxLinks = policy.max_links_per_post || 5;
  const minTrustLinks = policy.min_trust_level_links ?? 1;
  const minTrustPromo = policy.min_trust_level_promo ?? 2;
  const action = policy.action || "auto_hide";
  // ── 1. Check trust level for links ──
  if (urls.length > 0 && userTrustLevel < minTrustLinks) {
    console.log(`[forum-automod] Ad policy: user trust_level=${userTrustLevel} < ${minTrustLinks}, links blocked`);
    return {
      allowed: false,
      reason: "ad_policy_trust",
      message: `Для размещения ссылок нужен уровень доверия ${minTrustLinks} (у вас: ${userTrustLevel}). Продолжайте активно общаться!`
    };
  }
  // ── 2. Check max links ──
  if (urls.length > maxLinks) {
    console.log(`[forum-automod] Ad policy: too many links ${urls.length} > ${maxLinks}`);
    flags.push("ad_too_many_links");
    if (action === "auto_hide") setHidden(true);
    if (action === "block") {
      return {
        allowed: false,
        reason: "ad_too_many_links",
        message: `Максимум ${maxLinks} ссылок в одном сообщении.`
      };
    }
  }
  // ── 3. Check blacklisted domains ──
  for (const url of urls){
    try {
      const domain = new URL(url).hostname.toLowerCase();
      if (blacklist.some((bl)=>domain.includes(bl.toLowerCase()))) {
        console.log(`[forum-automod] Ad policy: blacklisted domain ${domain}`);
        return {
          allowed: false,
          reason: "ad_blacklisted_domain",
          message: "Ссылки на этот ресурс запрещены на форуме."
        };
      }
    } catch  {}
  }
  // ── 4. Check non-whitelisted external links (promo detection) ──
  const externalUrls = urls.filter((url)=>{
    try {
      const domain = new URL(url).hostname.toLowerCase();
      return !whitelist.some((wl)=>domain.includes(wl.toLowerCase()));
    } catch  {
      return false;
    }
  });
  if (externalUrls.length > 0 && userTrustLevel < minTrustPromo) {
    console.log(`[forum-automod] Ad policy: external links from low-trust user, trust=${userTrustLevel}`);
    flags.push("ad_external_links");
    if (action === "auto_hide") setHidden(true);
    if (action === "block") {
      return {
        allowed: false,
        reason: "ad_external_links",
        message: `Размещение внешних ссылок доступно с уровня доверия ${minTrustPromo}.`
      };
    }
  }
  // ── 5. Daily promo limit ──
  if (externalUrls.length > 0) {
    const maxPromo = policy.max_promo_per_day || 3;
    const { data: todayPosts } = await supabase.from("forum_posts").select("id, content").eq("user_id", userId).gte("created_at", new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()).limit(50);
    const promoCount = (todayPosts || []).filter((p)=>{
      const postUrls = p.content.match(urlRegex) || [];
      return postUrls.some((u)=>{
        try {
          const d = new URL(u).hostname.toLowerCase();
          return !whitelist.some((wl)=>d.includes(wl.toLowerCase()));
        } catch  {
          return false;
        }
      });
    }).length;
    if (promoCount >= maxPromo) {
      console.log(`[forum-automod] Ad policy: daily promo limit reached ${promoCount} >= ${maxPromo}`);
      return {
        allowed: false,
        reason: "ad_daily_limit",
        message: `Лимит промо-постов в сутки: ${maxPromo}. Попробуйте завтра.`
      };
    }
  }
  // ── 6. AI hidden ad detection ──
  if (policy.ai_ad_detection && text.length >= 50) {
    try {
      const systemPrompt = `Ты — AI-модератор музыкального форума. Определи, содержит ли текст СКРЫТУЮ рекламу.
Скрытая реклама = завуалированные промо-посты, нативная реклама, "случайные" рекомендации коммерческих сервисов, партнёрские ссылки, рекрутинг.
НЕ реклама = обсуждение музыки, рекомендации бесплатных инструментов, обмен опытом, помощь другим, шеринг своих треков.
Отвечай ТОЛЬКО JSON: {"is_ad": true/false, "confidence": 0.0-1.0, "ad_type": "none|native_ad|affiliate|recruitment|promo|spam", "reason": "краткое пояснение"}`;
      const result = await callDeepSeek(systemPrompt, text.substring(0, 1000));
      if (result) {
        const jsonMatch = result.match(/\{[^}]*\}/s);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          if (parsed.is_ad === true && (parsed.confidence || 0) >= 0.75) {
            console.log(`[forum-automod] Ad policy AI: type=${parsed.ad_type}, confidence=${parsed.confidence}, reason=${parsed.reason}`);
            flags.push(`ad_ai_${parsed.ad_type || "detected"}`);
            if (action === "auto_hide") setHidden(true);
            if (action === "block") {
              return {
                allowed: false,
                reason: "ad_detected",
                message: "Контент распознан как реклама и заблокирован."
              };
            }
          }
        }
      }
    } catch (error) {
      console.warn("[forum-automod] Ad policy AI check error:", error);
    }
  }
  return null;
}
// ── DeepSeek AI via Timeweb Agent API ──────────────────────
const TIMEWEB_AGENT_ACCESS_ID = '0846d064-4950-4d79-a54c-62ba315cdb34';
async function callDeepSeek(systemPrompt, userMessage) {
  const TIMEWEB_TOKEN = Deno.env.get("TIMEWEB_AGENT_TOKEN");
  if (!TIMEWEB_TOKEN) {
    console.warn("[forum-automod] TIMEWEB_AGENT_TOKEN not configured");
    return null;
  }
  const apiUrl = `https://agent.timeweb.cloud/api/v1/cloud-ai/agents/${TIMEWEB_AGENT_ACCESS_ID}/v1/chat/completions`;
  const response = await fetch(apiUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${TIMEWEB_TOKEN}`
    },
    body: JSON.stringify({
      model: "deepseek-v3",
      messages: [
        {
          role: "system",
          content: systemPrompt
        },
        {
          role: "user",
          content: userMessage
        }
      ],
      temperature: 0.1,
      max_tokens: 500
    })
  });
  if (!response.ok) {
    console.warn(`[forum-automod] DeepSeek API error: ${response.status}`);
    return null;
  }
  const data = await response.json();
  return data.choices?.[0]?.message?.content || null;
}
// ── Check: AI Toxicity (via DeepSeek / Timeweb) ────────────
async function checkAIToxicity(settingsMap, text, flags, setHidden) {
  const aiConfig = settingsMap["ai_moderation"];
  if (!aiConfig?.enabled) return;
  const minLength = aiConfig.min_text_length || 20;
  if (text.length < minLength) return;
  try {
    const systemPrompt = `Ты — AI-модератор музыкального форума. Анализируй текст на:
1. Токсичность, оскорбления, hate speech
2. Спам, рекламу, фишинг
3. Угрозы, буллинг, домогательства
4. Откровенный NSFW-контент
5. Мошенничество, фейки

НЕ считай нарушением: критику музыки, дискуссии, сленг, мнения, юмор.

Отвечай ТОЛЬКО JSON: {"toxic": true/false, "confidence": 0.0-1.0, "category": "none|toxicity|spam|threats|nsfw|fraud", "reason": "краткое пояснение на русском"}`;
    const result = await callDeepSeek(systemPrompt, text.substring(0, 1000));
    if (!result) return;
    const jsonMatch = result.match(/\{[^}]*\}/s);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      const threshold = aiConfig.confidence_threshold || 0.7;
      if (parsed.toxic === true && (parsed.confidence || 0) >= threshold) {
        console.log(`[forum-automod] DeepSeek toxicity: category=${parsed.category}, confidence=${parsed.confidence}, reason=${parsed.reason}`);
        flags.push(`ai_${parsed.category || "toxic"}`);
        setHidden(true);
      }
    }
  } catch (error) {
    console.warn("[forum-automod] DeepSeek toxicity check error:", error);
  // Fail open — don't block on AI errors
  }
}
// ── AI: Spam detection (ads, scam links, crypto spam) ──────
async function checkAISpam(settingsMap, text, flags, setHidden) {
  const aiConfig = settingsMap["ai_moderation"];
  if (!aiConfig?.enabled || !aiConfig?.spam_detection) return;
  if (text.length < 30) return;
  try {
    const systemPrompt = `Определи, является ли текст спамом на музыкальном форуме.
Спам = реклама, крипто-схемы, казино, сомнительные ссылки, бессмысленный набор символов, SEO-спам.
НЕ спам = обсуждение музыки, просьбы о фидбеке, шеринг своих треков, вопросы.

Отвечай ТОЛЬКО JSON: {"spam": true/false, "confidence": 0.0-1.0, "reason": "краткое пояснение"}`;
    const result = await callDeepSeek(systemPrompt, text.substring(0, 800));
    if (!result) return;
    const jsonMatch = result.match(/\{[^}]*\}/s);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (parsed.spam === true && (parsed.confidence || 0) >= 0.75) {
        console.log(`[forum-automod] DeepSeek spam detected: ${parsed.reason}`);
        flags.push("ai_spam");
        setHidden(true);
      }
    }
  } catch (error) {
    console.warn("[forum-automod] DeepSeek spam check error:", error);
  }
}
// ── AI: Language quality check (gibberish, all-caps flood) ──
async function checkAIQuality(settingsMap, text, flags, setHidden) {
  const aiConfig = settingsMap["ai_moderation"];
  if (!aiConfig?.enabled || !aiConfig?.quality_check) return;
  if (text.length < 10) return;
  try {
    const systemPrompt = `Оцени качество текста для музыкального форума.
Низкое качество = полная бессмыслица, случайные символы, весь текст КАПСОМ (>80%), бот-генерация.
Допустимо = разговорный стиль, сленг, короткие ответы, эмодзи, музыкальные термины.

Отвечай ТОЛЬКО JSON: {"low_quality": true/false, "reason": "краткое пояснение"}`;
    const result = await callDeepSeek(systemPrompt, text.substring(0, 500));
    if (!result) return;
    const jsonMatch = result.match(/\{[^}]*\}/s);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (parsed.low_quality === true) {
        console.log(`[forum-automod] DeepSeek low quality: ${parsed.reason}`);
        flags.push("ai_low_quality");
      // Don't auto-hide, just flag for review
      }
    }
  } catch (error) {
    console.warn("[forum-automod] DeepSeek quality check error:", error);
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9mb3J1bS1hdXRvbW9kL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOlxuICAgIFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmludGVyZmFjZSBBdXRvbW9kUmVxdWVzdCB7XG4gIGNvbnRlbnQ6IHN0cmluZztcbiAgdGl0bGU/OiBzdHJpbmc7XG4gIHR5cGU6IFwicG9zdFwiIHwgXCJ0b3BpY1wiO1xufVxuXG5pbnRlcmZhY2UgQXV0b21vZFJlc3VsdCB7XG4gIGFsbG93ZWQ6IGJvb2xlYW47XG4gIHJlYXNvbj86IHN0cmluZztcbiAgbWVzc2FnZT86IHN0cmluZztcbiAgZmxhZ3M/OiBzdHJpbmdbXTtcbiAgaHVtYW5fZmxhZ3M/OiBzdHJpbmdbXTtcbiAgYXV0b19oaWRkZW4/OiBib29sZWFuO1xuICBoaWRkZW5fcmVhc29uPzogc3RyaW5nO1xufVxuXG4vKiogTWFwIHRlY2huaWNhbCBmbGFnIG5hbWVzIHRvIGh1bWFuLXJlYWRhYmxlIGRlc2NyaXB0aW9ucyAqL1xuZnVuY3Rpb24gaHVtYW5pemVGbGFnKGZsYWc6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IG1hcDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgICBzdG9wd29yZHM6IFwi0J7QsdC90LDRgNGD0LbQtdC90LAg0L3QtdC90L7RgNC80LDRgtC40LLQvdCw0Y8g0LvQtdC60YHQuNC60LBcIixcbiAgICB0b29fbWFueV9saW5rczogXCLQodC70LjRiNC60L7QvCDQvNC90L7Qs9C+INGB0YHRi9C70L7QulwiLFxuICAgIGJsYWNrbGlzdGVkX2xpbms6IFwi0JfQsNC/0YDQtdGJ0ZHQvdC90LDRjyDRgdGB0YvQu9C60LBcIixcbiAgICByZWdleF9tYXRjaDogXCLQntCx0L3QsNGA0YPQttC10L3QviDQt9Cw0L/RgNC10YnRkdC90L3QvtC1INCy0YvRgNCw0LbQtdC90LjQtVwiLFxuICAgIG5ld2JpZV9wcmVtb2Q6IFwi0J/RgNC10LzQvtC00LXRgNCw0YbQuNGPINC90L7QstC+0LPQviDQv9C+0LvRjNC30L7QstCw0YLQtdC70Y9cIixcbiAgICBhZF90b29fbWFueV9saW5rczogXCLQn9C+0LTQvtC30YDQtdC90LjQtSDQvdCwINGA0LXQutC70LDQvNGDOiDQvNC90L7Qs9C+INGB0YHRi9C70L7QulwiLFxuICAgIGFkX2V4dGVybmFsX2xpbmtzOiBcItCf0L7QtNC+0LfRgNC10L3QuNC1INC90LAg0YDQtdC60LvQsNC80YM6INCy0L3QtdGI0L3QuNC1INGB0YHRi9C70LrQuFwiLFxuICAgIGFpX3RveGljOiBcItCe0LHQvdCw0YDRg9C20LXQvSDRgtC+0LrRgdC40YfQvdGL0Lkg0LrQvtC90YLQtdC90YJcIixcbiAgICBhaV9pbnN1bHQ6IFwi0J7QsdC90LDRgNGD0LbQtdC90Ysg0L7RgdC60L7RgNCx0LvQtdC90LjRj1wiLFxuICAgIGFpX2hhdGU6IFwi0J7QsdC90LDRgNGD0LbQtdC9INGP0LfRi9C6INC90LXQvdCw0LLQuNGB0YLQuFwiLFxuICAgIGFpX3RocmVhdDogXCLQntCx0L3QsNGA0YPQttC10L3RiyDRg9Cz0YDQvtC30YtcIixcbiAgICBhaV9zcGFtOiBcItCe0LHQvdCw0YDRg9C20LXQvSDRgdC/0LDQvFwiLFxuICAgIGFpX2xvd19xdWFsaXR5OiBcItCd0LjQt9C60L7QtSDQutCw0YfQtdGB0YLQstC+INC60L7QvdGC0LXQvdGC0LBcIixcbiAgfTtcbiAgLy8gSGFuZGxlIGR5bmFtaWMgZmxhZ3MgbGlrZSBcImFkX2FpX3Byb21vXCJcbiAgaWYgKGZsYWcuc3RhcnRzV2l0aChcImFkX2FpX1wiKSkgcmV0dXJuIFwi0J7QsdC90LDRgNGD0LbQtdC90LAg0YDQtdC60LvQsNC80LBcIjtcbiAgaWYgKGZsYWcuc3RhcnRzV2l0aChcImFpX1wiKSkgcmV0dXJuIG1hcFtmbGFnXSB8fCBcItCd0LDRgNGD0YjQtdC90LjQtSDQv9GA0LDQstC40LsgKEFJLdC/0YDQvtCy0LXRgNC60LApXCI7XG4gIHJldHVybiBtYXBbZmxhZ10gfHwgXCLQndCw0YDRg9GI0LXQvdC40LUg0L/RgNCw0LLQuNC7INGE0L7RgNGD0LzQsFwiO1xufVxuXG5EZW5vLnNlcnZlKGFzeW5jIChyZXE6IFJlcXVlc3QpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcIm9rXCIsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBhbGxvd2VkOiBmYWxzZSwgcmVhc29uOiBcInVuYXV0aG9yaXplZFwiLCBtZXNzYWdlOiBcItCd0LXQvtCx0YXQvtC00LjQvNC+INCy0L7QudGC0Lgg0LIg0YHQuNGB0YLQtdC80YNcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpISxcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhXG4gICAgKTtcblxuICAgIGNvbnN0IHVzZXJDbGllbnQgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikhLFxuICAgICAgeyBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfSB9XG4gICAgKTtcblxuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0sIGVycm9yOiBhdXRoRXJyb3IgfSA9IGF3YWl0IHVzZXJDbGllbnQuYXV0aC5nZXRVc2VyKCk7XG4gICAgaWYgKGF1dGhFcnJvciB8fCAhdXNlcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkF1dGggZXJyb3I6XCIsIGF1dGhFcnJvcik7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGFsbG93ZWQ6IGZhbHNlLCByZWFzb246IFwidW5hdXRob3JpemVkXCIsIG1lc3NhZ2U6IFwi0J3QtSDQsNCy0YLQvtGA0LjQt9C+0LLQsNC9XCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBib2R5OiBBdXRvbW9kUmVxdWVzdCA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc3QgeyBjb250ZW50LCB0aXRsZSwgdHlwZSB9ID0gYm9keTtcbiAgICBjb25zdCB0ZXh0VG9DaGVjayA9IHRpdGxlID8gYCR7dGl0bGV9ICR7Y29udGVudH1gIDogY29udGVudDtcbiAgICBjb25zdCBmbGFnczogc3RyaW5nW10gPSBbXTtcbiAgICBsZXQgYXV0b0hpZGRlbiA9IGZhbHNlO1xuXG4gICAgY29uc29sZS5sb2coYFtmb3J1bS1hdXRvbW9kXSBDaGVja2luZyAke3R5cGV9IGZyb20gdXNlciAke3VzZXIuaWR9LCBsZW5ndGg6ICR7dGV4dFRvQ2hlY2subGVuZ3RofWApO1xuXG4gICAgLy8gRmV0Y2ggYWxsIHNldHRpbmdzIGF0IG9uY2VcbiAgICBjb25zdCB7IGRhdGE6IHNldHRpbmdzIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJmb3J1bV9hdXRvbW9kX3NldHRpbmdzXCIpXG4gICAgICAuc2VsZWN0KFwia2V5LCB2YWx1ZVwiKTtcblxuICAgIGNvbnN0IHNldHRpbmdzTWFwOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge307XG4gICAgKHNldHRpbmdzIHx8IFtdKS5mb3JFYWNoKChzOiBhbnkpID0+IHsgc2V0dGluZ3NNYXBbcy5rZXldID0gcy52YWx1ZTsgfSk7XG5cbiAgICAvLyDilIDilIAgMC4gR2V0IHVzZXIgdHJ1c3QgbGV2ZWwg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgY29uc3QgeyBkYXRhOiB1c2VyU3RhdHMgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImZvcnVtX3VzZXJfc3RhdHNcIilcbiAgICAgIC5zZWxlY3QoXCJ0cnVzdF9sZXZlbFwiKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG4gICAgY29uc3QgdXNlclRydXN0TGV2ZWwgPSB1c2VyU3RhdHM/LnRydXN0X2xldmVsID8/IDA7XG5cbiAgICAvLyDilIDilIAgMS4gUmF0ZSBMaW1pdCBDaGVjayDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBjb25zdCByZXN1bHQxID0gYXdhaXQgY2hlY2tSYXRlTGltaXQoc3VwYWJhc2UsIHVzZXIuaWQpO1xuICAgIGlmIChyZXN1bHQxKSByZXR1cm4ganNvblJlc3BvbnNlKHJlc3VsdDEpO1xuXG4gICAgLy8g4pSA4pSAIDIuIFN0b3B3b3JkcyBDaGVjayDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBjaGVja1N0b3B3b3JkcyhzZXR0aW5nc01hcCwgdGV4dFRvQ2hlY2ssIGZsYWdzLCAodjogYm9vbGVhbikgPT4geyBhdXRvSGlkZGVuID0gYXV0b0hpZGRlbiB8fCB2OyB9KTtcblxuICAgIC8vIOKUgOKUgCAzLiBMaW5rIEZpbHRlciDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBjaGVja0xpbmtzKHNldHRpbmdzTWFwLCB0ZXh0VG9DaGVjaywgZmxhZ3MsICh2OiBib29sZWFuKSA9PiB7IGF1dG9IaWRkZW4gPSBhdXRvSGlkZGVuIHx8IHY7IH0pO1xuXG4gICAgLy8g4pSA4pSAIDQuIFJlZ2V4IEZpbHRlcnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgY2hlY2tSZWdleChzZXR0aW5nc01hcCwgdGV4dFRvQ2hlY2ssIGZsYWdzLCAodjogYm9vbGVhbikgPT4geyBhdXRvSGlkZGVuID0gYXV0b0hpZGRlbiB8fCB2OyB9KTtcblxuICAgIC8vIOKUgOKUgCA1LiBOZXdiaWUgUHJlbW9kZXJhdGlvbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBhd2FpdCBjaGVja05ld2JpZShzdXBhYmFzZSwgc2V0dGluZ3NNYXAsIHVzZXIuaWQsIHVzZXJUcnVzdExldmVsLCBmbGFncywgKHY6IGJvb2xlYW4pID0+IHsgYXV0b0hpZGRlbiA9IGF1dG9IaWRkZW4gfHwgdjsgfSk7XG5cbiAgICAvLyDilIDilIAgNi4gRHVwbGljYXRlIENvbnRlbnQgQ2hlY2sg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgY29uc3QgZHVwUmVzdWx0ID0gYXdhaXQgY2hlY2tEdXBsaWNhdGUoc3VwYWJhc2UsIHVzZXIuaWQsIHRleHRUb0NoZWNrKTtcbiAgICBpZiAoZHVwUmVzdWx0KSByZXR1cm4ganNvblJlc3BvbnNlKGR1cFJlc3VsdCk7XG5cbiAgICAvLyDilIDilIAgNi41LiBBZHZlcnRpc2luZyAvIFByb21vIFBvbGljeSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBjb25zdCBhZFJlc3VsdCA9IGF3YWl0IGNoZWNrQWRQb2xpY3koc3VwYWJhc2UsIHNldHRpbmdzTWFwLCB1c2VyLmlkLCB1c2VyVHJ1c3RMZXZlbCwgdGV4dFRvQ2hlY2ssIGZsYWdzLCAodjogYm9vbGVhbikgPT4geyBhdXRvSGlkZGVuID0gYXV0b0hpZGRlbiB8fCB2OyB9KTtcbiAgICBpZiAoYWRSZXN1bHQpIHJldHVybiBqc29uUmVzcG9uc2UoYWRSZXN1bHQpO1xuXG4gICAgLy8g4pSA4pSAIDfigJM5LiBBSSBDaGVja3MgKHNraXAgZm9yIHRydXN0ZWQgdXNlcnM6IHRydXN0X2xldmVsIOKJpSAyKSDilIDilIBcbiAgICBjb25zdCBhaVRydXN0VGhyZXNob2xkID0gc2V0dGluZ3NNYXBbXCJhaV9tb2RlcmF0aW9uXCJdPy5za2lwX3RydXN0X2xldmVsID8/IDI7XG4gICAgaWYgKHVzZXJUcnVzdExldmVsIDwgYWlUcnVzdFRocmVzaG9sZCkge1xuICAgICAgY29uc29sZS5sb2coYFtmb3J1bS1hdXRvbW9kXSBSdW5uaW5nIEFJIGNoZWNrcyBmb3IgdXNlciB0cnVzdF9sZXZlbD0ke3VzZXJUcnVzdExldmVsfSAodGhyZXNob2xkPSR7YWlUcnVzdFRocmVzaG9sZH0pYCk7XG4gICAgICBhd2FpdCBjaGVja0FJVG94aWNpdHkoc2V0dGluZ3NNYXAsIHRleHRUb0NoZWNrLCBmbGFncywgKHY6IGJvb2xlYW4pID0+IHsgYXV0b0hpZGRlbiA9IGF1dG9IaWRkZW4gfHwgdjsgfSk7XG4gICAgICBhd2FpdCBjaGVja0FJU3BhbShzZXR0aW5nc01hcCwgdGV4dFRvQ2hlY2ssIGZsYWdzLCAodjogYm9vbGVhbikgPT4geyBhdXRvSGlkZGVuID0gYXV0b0hpZGRlbiB8fCB2OyB9KTtcbiAgICAgIGF3YWl0IGNoZWNrQUlRdWFsaXR5KHNldHRpbmdzTWFwLCB0ZXh0VG9DaGVjaywgZmxhZ3MsICh2OiBib29sZWFuKSA9PiB7IGF1dG9IaWRkZW4gPSBhdXRvSGlkZGVuIHx8IHY7IH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIFNraXBwaW5nIEFJIGNoZWNrcyBmb3IgdHJ1c3RlZCB1c2VyIHRydXN0X2xldmVsPSR7dXNlclRydXN0TGV2ZWx9YCk7XG4gICAgfVxuXG4gICAgLy8g4pSA4pSAIFJlc3VsdCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICBjb25zdCBodW1hbkZsYWdzID0gZmxhZ3MubWFwKGYgPT4gaHVtYW5pemVGbGFnKGYpKTtcbiAgICBjb25zdCByZXN1bHQ6IEF1dG9tb2RSZXN1bHQgPSB7XG4gICAgICBhbGxvd2VkOiB0cnVlLFxuICAgICAgZmxhZ3M6IGZsYWdzLmxlbmd0aCA+IDAgPyBmbGFncyA6IHVuZGVmaW5lZCxcbiAgICAgIGh1bWFuX2ZsYWdzOiBodW1hbkZsYWdzLmxlbmd0aCA+IDAgPyBodW1hbkZsYWdzIDogdW5kZWZpbmVkLFxuICAgICAgYXV0b19oaWRkZW46IGF1dG9IaWRkZW4gfHwgdW5kZWZpbmVkLFxuICAgIH07XG5cbiAgICBpZiAoYXV0b0hpZGRlbikge1xuICAgICAgcmVzdWx0Lm1lc3NhZ2UgPSBcItCa0L7QvdGC0LXQvdGCINCx0YPQtNC10YIg0L/RgNC+0LLQtdGA0LXQvSDQvNC+0LTQtdGA0LDRgtC+0YDQvtC8XCI7XG4gICAgICByZXN1bHQuaGlkZGVuX3JlYXNvbiA9IGh1bWFuRmxhZ3MubGVuZ3RoID4gMFxuICAgICAgICA/IGDQodC+0L7QsdGJ0LXQvdC40LUg0YHQutGA0YvRgtC+OiAke2h1bWFuRmxhZ3Muam9pbihcIiwgXCIpLnRvTG93ZXJDYXNlKCl9YFxuICAgICAgICA6IFwi0KHQvtC+0LHRidC10L3QuNC1INGB0LrRgNGL0YLQviDQsNCy0YLQvtC80LDRgtC40YfQtdGB0LrQvtC5INC80L7QtNC10YDQsNGG0LjQtdC5XCI7XG4gICAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIENvbnRlbnQgZmxhZ2dlZCBmb3IgYXV0by1oaWRlOiAke2ZsYWdzLmpvaW4oXCIsIFwiKX1gKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIFJlc3VsdDogYWxsb3dlZD0ke3Jlc3VsdC5hbGxvd2VkfSwgZmxhZ3M9JHtmbGFncy5qb2luKFwiLFwiKX0sIGF1dG9faGlkZGVuPSR7YXV0b0hpZGRlbn1gKTtcbiAgICByZXR1cm4ganNvblJlc3BvbnNlKHJlc3VsdCk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiW2ZvcnVtLWF1dG9tb2RdIEVycm9yOlwiLCBlcnJvcik7XG4gICAgcmV0dXJuIGpzb25SZXNwb25zZSh7IGFsbG93ZWQ6IHRydWUsIGVycm9yOiBcIkF1dG9tb2QgY2hlY2sgZmFpbGVkLCBhbGxvd2luZyBieSBkZWZhdWx0XCIgfSk7XG4gIH1cbn0pO1xuXG4vLyDilIDilIAgSGVscGVyOiBKU09OIFJlc3BvbnNlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZnVuY3Rpb24ganNvblJlc3BvbnNlKGRhdGE6IGFueSwgc3RhdHVzID0gMjAwKSB7XG4gIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoZGF0YSksIHtcbiAgICBzdGF0dXMsXG4gICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgfSk7XG59XG5cbi8vIOKUgOKUgCBDaGVjazogUmF0ZSBMaW1pdCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmFzeW5jIGZ1bmN0aW9uIGNoZWNrUmF0ZUxpbWl0KHN1cGFiYXNlOiBhbnksIHVzZXJJZDogc3RyaW5nKTogUHJvbWlzZTxBdXRvbW9kUmVzdWx0IHwgbnVsbD4ge1xuICBjb25zdCB7IGRhdGE6IHJhdGVMaW1pdFJlc3VsdCB9ID0gYXdhaXQgc3VwYWJhc2UucnBjKFwiZm9ydW1fY2hlY2tfcmF0ZV9saW1pdFwiLCB7XG4gICAgcF91c2VyX2lkOiB1c2VySWQsXG4gIH0pO1xuXG4gIGlmIChyYXRlTGltaXRSZXN1bHQgJiYgIXJhdGVMaW1pdFJlc3VsdC5hbGxvd2VkKSB7XG4gICAgY29uc29sZS5sb2coYFtmb3J1bS1hdXRvbW9kXSBSYXRlIGxpbWl0IGhpdDogJHtyYXRlTGltaXRSZXN1bHQubWVzc2FnZX1gKTtcbiAgICByZXR1cm4ge1xuICAgICAgYWxsb3dlZDogZmFsc2UsXG4gICAgICByZWFzb246IHJhdGVMaW1pdFJlc3VsdC5yZWFzb24sXG4gICAgICBtZXNzYWdlOiByYXRlTGltaXRSZXN1bHQubWVzc2FnZSxcbiAgICB9O1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vLyDilIDilIAgQ2hlY2s6IFN0b3B3b3JkcyAod2l0aCB3b3JkLWJvdW5kYXJ5IHJlZ2V4KSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmZ1bmN0aW9uIGNoZWNrU3RvcHdvcmRzKFxuICBzZXR0aW5nc01hcDogUmVjb3JkPHN0cmluZywgYW55PixcbiAgdGV4dDogc3RyaW5nLFxuICBmbGFnczogc3RyaW5nW10sXG4gIHNldEhpZGRlbjogKHY6IGJvb2xlYW4pID0+IHZvaWRcbikge1xuICBjb25zdCBjb25maWcgPSBzZXR0aW5nc01hcFtcInN0b3B3b3Jkc1wiXTtcbiAgaWYgKCFjb25maWc/LmVuYWJsZWQgfHwgIWNvbmZpZz8ud29yZHM/Lmxlbmd0aCkgcmV0dXJuO1xuXG4gIGNvbnN0IGxvd2VyVGV4dCA9IHRleHQudG9Mb3dlckNhc2UoKTtcbiAgY29uc3QgbWF0Y2hlZDogc3RyaW5nW10gPSBbXTtcblxuICBmb3IgKGNvbnN0IHdvcmQgb2YgY29uZmlnLndvcmRzKSB7XG4gICAgY29uc3QgbG93ZXJXb3JkID0gd29yZC50b0xvd2VyQ2FzZSgpO1xuICAgIC8vIFVzZSB3b3JkLWJvdW5kYXJ5IHJlZ2V4IGZvciBhY2N1cmF0ZSBtYXRjaGluZ1xuICAgIC8vIFxcYiBkb2Vzbid0IHdvcmsgd2VsbCB3aXRoIEN5cmlsbGljLCBzbyB1c2UgbG9va2Fyb3VuZCBmb3Igbm9uLXdvcmQgY2hhcnMgb3Igc3RyaW5nIGVkZ2VzXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGVzY2FwZWQgPSBsb3dlcldvcmQucmVwbGFjZSgvWy4qKz9eJHt9KCl8W1xcXVxcXFxdL2csIFwiXFxcXCQmXCIpO1xuICAgICAgY29uc3QgcmVnZXggPSBuZXcgUmVnRXhwKGAoPzpefFtcXFxccy4sIT87OigpXFxcXFtcXFxcXXt9XFxcIidcXFxcLeKAk+KAlC9dKSR7ZXNjYXBlZH0oPzokfFtcXFxccy4sIT87OigpXFxcXFtcXFxcXXt9XFxcIidcXFxcLeKAk+KAlC9dKWAsIFwiaVwiKTtcbiAgICAgIGlmIChyZWdleC50ZXN0KGAgJHtsb3dlclRleHR9IGApKSB7XG4gICAgICAgIG1hdGNoZWQucHVzaCh3b3JkKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIEZhbGxiYWNrIHRvIGluY2x1ZGVzIGZvciBpbnZhbGlkIHBhdHRlcm5zXG4gICAgICBpZiAobG93ZXJUZXh0LmluY2x1ZGVzKGxvd2VyV29yZCkpIHtcbiAgICAgICAgbWF0Y2hlZC5wdXNoKHdvcmQpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGlmIChtYXRjaGVkLmxlbmd0aCA+IDApIHtcbiAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIFN0b3B3b3JkcyBtYXRjaGVkOiAke21hdGNoZWQuam9pbihcIiwgXCIpfWApO1xuICAgIGZsYWdzLnB1c2goXCJzdG9wd29yZHNcIik7XG4gICAgc2V0SGlkZGVuKHRydWUpO1xuICB9XG59XG5cbi8vIOKUgOKUgCBDaGVjazogTGlua3Mg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5mdW5jdGlvbiBjaGVja0xpbmtzKFxuICBzZXR0aW5nc01hcDogUmVjb3JkPHN0cmluZywgYW55PixcbiAgdGV4dDogc3RyaW5nLFxuICBmbGFnczogc3RyaW5nW10sXG4gIHNldEhpZGRlbjogKHY6IGJvb2xlYW4pID0+IHZvaWRcbikge1xuICBjb25zdCBjb25maWcgPSBzZXR0aW5nc01hcFtcImxpbmtfZmlsdGVyXCJdO1xuICBpZiAoIWNvbmZpZz8uZW5hYmxlZCkgcmV0dXJuO1xuXG4gIGNvbnN0IHVybFJlZ2V4ID0gL2h0dHBzPzpcXC9cXC9bXlxcczw+XCInXSsvZ2k7XG4gIGNvbnN0IHVybHMgPSB0ZXh0Lm1hdGNoKHVybFJlZ2V4KSB8fCBbXTtcbiAgY29uc3QgbWF4TGlua3MgPSBjb25maWcubWF4X2xpbmtzIHx8IDU7XG5cbiAgaWYgKHVybHMubGVuZ3RoID4gbWF4TGlua3MpIHtcbiAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIFRvbyBtYW55IGxpbmtzOiAke3VybHMubGVuZ3RofSA+ICR7bWF4TGlua3N9YCk7XG4gICAgZmxhZ3MucHVzaChcInRvb19tYW55X2xpbmtzXCIpO1xuICAgIHNldEhpZGRlbih0cnVlKTtcbiAgfVxuXG4gIGNvbnN0IGJsYWNrbGlzdDogc3RyaW5nW10gPSBjb25maWcuYmxhY2tsaXN0X2RvbWFpbnMgfHwgW107XG4gIGlmIChibGFja2xpc3QubGVuZ3RoID4gMCkge1xuICAgIGZvciAoY29uc3QgdXJsIG9mIHVybHMpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGRvbWFpbiA9IG5ldyBVUkwodXJsKS5ob3N0bmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBpZiAoYmxhY2tsaXN0LnNvbWUoKGJsOiBzdHJpbmcpID0+IGRvbWFpbi5pbmNsdWRlcyhibC50b0xvd2VyQ2FzZSgpKSkpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIEJsYWNrbGlzdGVkIGRvbWFpbjogJHtkb21haW59YCk7XG4gICAgICAgICAgZmxhZ3MucHVzaChcImJsYWNrbGlzdGVkX2xpbmtcIik7XG4gICAgICAgICAgc2V0SGlkZGVuKHRydWUpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIHsgLyogSW52YWxpZCBVUkwgKi8gfVxuICAgIH1cbiAgfVxufVxuXG4vLyDilIDilIAgQ2hlY2s6IFJlZ2V4IEZpbHRlcnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5mdW5jdGlvbiBjaGVja1JlZ2V4KFxuICBzZXR0aW5nc01hcDogUmVjb3JkPHN0cmluZywgYW55PixcbiAgdGV4dDogc3RyaW5nLFxuICBmbGFnczogc3RyaW5nW10sXG4gIHNldEhpZGRlbjogKHY6IGJvb2xlYW4pID0+IHZvaWRcbikge1xuICBjb25zdCBjb25maWcgPSBzZXR0aW5nc01hcFtcInJlZ2V4X2ZpbHRlcnNcIl07XG4gIGlmICghY29uZmlnPy5lbmFibGVkIHx8ICFjb25maWc/LnBhdHRlcm5zPy5sZW5ndGgpIHJldHVybjtcblxuICBmb3IgKGNvbnN0IHBhdHRlcm4gb2YgY29uZmlnLnBhdHRlcm5zKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlZ2V4ID0gbmV3IFJlZ0V4cChwYXR0ZXJuLCBcImdpXCIpO1xuICAgICAgaWYgKHJlZ2V4LnRlc3QodGV4dCkpIHtcbiAgICAgICAgY29uc29sZS5sb2coYFtmb3J1bS1hdXRvbW9kXSBSZWdleCBtYXRjaGVkOiAke3BhdHRlcm59YCk7XG4gICAgICAgIGZsYWdzLnB1c2goXCJyZWdleF9tYXRjaFwiKTtcbiAgICAgICAgc2V0SGlkZGVuKHRydWUpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9IGNhdGNoIHtcbiAgICAgIGNvbnNvbGUud2FybihgW2ZvcnVtLWF1dG9tb2RdIEludmFsaWQgcmVnZXggcGF0dGVybjogJHtwYXR0ZXJufWApO1xuICAgIH1cbiAgfVxufVxuXG4vLyDilIDilIAgQ2hlY2s6IE5ld2JpZSBQcmVtb2Qg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5hc3luYyBmdW5jdGlvbiBjaGVja05ld2JpZShcbiAgc3VwYWJhc2U6IGFueSxcbiAgc2V0dGluZ3NNYXA6IFJlY29yZDxzdHJpbmcsIGFueT4sXG4gIHVzZXJJZDogc3RyaW5nLFxuICB1c2VyVHJ1c3RMZXZlbDogbnVtYmVyLFxuICBmbGFnczogc3RyaW5nW10sXG4gIHNldEhpZGRlbjogKHY6IGJvb2xlYW4pID0+IHZvaWRcbikge1xuICBjb25zdCBjb25maWcgPSBzZXR0aW5nc01hcFtcIm5ld2JpZV9wcmVtb2RcIl07XG4gIGlmICghY29uZmlnPy5lbmFibGVkKSByZXR1cm47XG5cbiAgY29uc3QgbWF4VHJ1c3RMZXZlbCA9IGNvbmZpZy5tYXhfdHJ1c3RfbGV2ZWwgPz8gMDtcbiAgaWYgKHVzZXJUcnVzdExldmVsIDw9IG1heFRydXN0TGV2ZWwpIHtcbiAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIE5ld2JpZSBwcmVtb2Q6IHRydXN0X2xldmVsPSR7dXNlclRydXN0TGV2ZWx9YCk7XG4gICAgZmxhZ3MucHVzaChcIm5ld2JpZV9wcmVtb2RcIik7XG4gICAgc2V0SGlkZGVuKHRydWUpO1xuICB9XG59XG5cbi8vIOKUgOKUgCBDaGVjazogRHVwbGljYXRlIENvbnRlbnQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5hc3luYyBmdW5jdGlvbiBjaGVja0R1cGxpY2F0ZShzdXBhYmFzZTogYW55LCB1c2VySWQ6IHN0cmluZywgdGV4dDogc3RyaW5nKTogUHJvbWlzZTxBdXRvbW9kUmVzdWx0IHwgbnVsbD4ge1xuICBjb25zdCBjb250ZW50SGFzaCA9IHRleHQuc3Vic3RyaW5nKDAsIDIwMCkudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gIGlmIChjb250ZW50SGFzaC5sZW5ndGggPD0gMjApIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHsgZGF0YTogcmVjZW50UG9zdHMgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJmb3J1bV9wb3N0c1wiKVxuICAgIC5zZWxlY3QoXCJpZCwgY29udGVudFwiKVxuICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKVxuICAgIC5ndGUoXCJjcmVhdGVkX2F0XCIsIG5ldyBEYXRlKERhdGUubm93KCkgLSA2MCAqIDYwICogMTAwMCkudG9JU09TdHJpbmcoKSlcbiAgICAubGltaXQoMTApO1xuXG4gIGNvbnN0IGlzRHVwbGljYXRlID0gKHJlY2VudFBvc3RzIHx8IFtdKS5zb21lKChwOiBhbnkpID0+XG4gICAgcC5jb250ZW50LnN1YnN0cmluZygwLCAyMDApLnRyaW0oKS50b0xvd2VyQ2FzZSgpID09PSBjb250ZW50SGFzaFxuICApO1xuXG4gIGlmIChpc0R1cGxpY2F0ZSkge1xuICAgIGNvbnNvbGUubG9nKGBbZm9ydW0tYXV0b21vZF0gRHVwbGljYXRlIGNvbnRlbnQgZGV0ZWN0ZWRgKTtcbiAgICByZXR1cm4ge1xuICAgICAgYWxsb3dlZDogZmFsc2UsXG4gICAgICByZWFzb246IFwiZHVwbGljYXRlXCIsXG4gICAgICBtZXNzYWdlOiBcItCi0LDQutC+0LUg0YHQvtC+0LHRidC10L3QuNC1INGD0LbQtSDQsdGL0LvQviDQvtGC0L/RgNCw0LLQu9C10L3Qvi4g0J/QvtC20LDQu9GD0LnRgdGC0LAsINC90LUg0LTRg9Cx0LvQuNGA0YPQudGC0LUg0LrQvtC90YLQtdC90YIuXCIsXG4gICAgfTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLy8g4pSA4pSAIENoZWNrOiBBZHZlcnRpc2luZyAvIFByb21vIFBvbGljeSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmFzeW5jIGZ1bmN0aW9uIGNoZWNrQWRQb2xpY3koXG4gIHN1cGFiYXNlOiBhbnksXG4gIHNldHRpbmdzTWFwOiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuICB1c2VySWQ6IHN0cmluZyxcbiAgdXNlclRydXN0TGV2ZWw6IG51bWJlcixcbiAgdGV4dDogc3RyaW5nLFxuICBmbGFnczogc3RyaW5nW10sXG4gIHNldEhpZGRlbjogKHY6IGJvb2xlYW4pID0+IHZvaWRcbik6IFByb21pc2U8QXV0b21vZFJlc3VsdCB8IG51bGw+IHtcbiAgY29uc3QgcG9saWN5ID0gc2V0dGluZ3NNYXBbXCJhZF9wb2xpY3lcIl07XG4gIGlmICghcG9saWN5Py5lbmFibGVkKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCB1cmxSZWdleCA9IC9odHRwcz86XFwvXFwvW15cXHM8PlwiJ10rL2dpO1xuICBjb25zdCB1cmxzID0gdGV4dC5tYXRjaCh1cmxSZWdleCkgfHwgW107XG4gIGNvbnN0IHdoaXRlbGlzdDogc3RyaW5nW10gPSBwb2xpY3kud2hpdGVsaXN0X2RvbWFpbnMgfHwgW107XG4gIGNvbnN0IGJsYWNrbGlzdDogc3RyaW5nW10gPSBwb2xpY3kuYmxhY2tsaXN0X2RvbWFpbnMgfHwgW107XG4gIGNvbnN0IG1heExpbmtzID0gcG9saWN5Lm1heF9saW5rc19wZXJfcG9zdCB8fCA1O1xuICBjb25zdCBtaW5UcnVzdExpbmtzID0gcG9saWN5Lm1pbl90cnVzdF9sZXZlbF9saW5rcyA/PyAxO1xuICBjb25zdCBtaW5UcnVzdFByb21vID0gcG9saWN5Lm1pbl90cnVzdF9sZXZlbF9wcm9tbyA/PyAyO1xuICBjb25zdCBhY3Rpb24gPSBwb2xpY3kuYWN0aW9uIHx8IFwiYXV0b19oaWRlXCI7XG5cbiAgLy8g4pSA4pSAIDEuIENoZWNrIHRydXN0IGxldmVsIGZvciBsaW5rcyDilIDilIBcbiAgaWYgKHVybHMubGVuZ3RoID4gMCAmJiB1c2VyVHJ1c3RMZXZlbCA8IG1pblRydXN0TGlua3MpIHtcbiAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIEFkIHBvbGljeTogdXNlciB0cnVzdF9sZXZlbD0ke3VzZXJUcnVzdExldmVsfSA8ICR7bWluVHJ1c3RMaW5rc30sIGxpbmtzIGJsb2NrZWRgKTtcbiAgICByZXR1cm4ge1xuICAgICAgYWxsb3dlZDogZmFsc2UsXG4gICAgICByZWFzb246IFwiYWRfcG9saWN5X3RydXN0XCIsXG4gICAgICBtZXNzYWdlOiBg0JTQu9GPINGA0LDQt9C80LXRidC10L3QuNGPINGB0YHRi9C70L7QuiDQvdGD0LbQtdC9INGD0YDQvtCy0LXQvdGMINC00L7QstC10YDQuNGPICR7bWluVHJ1c3RMaW5rc30gKNGDINCy0LDRgTogJHt1c2VyVHJ1c3RMZXZlbH0pLiDQn9GA0L7QtNC+0LvQttCw0LnRgtC1INCw0LrRgtC40LLQvdC+INC+0LHRidCw0YLRjNGB0Y8hYCxcbiAgICB9O1xuICB9XG5cbiAgLy8g4pSA4pSAIDIuIENoZWNrIG1heCBsaW5rcyDilIDilIBcbiAgaWYgKHVybHMubGVuZ3RoID4gbWF4TGlua3MpIHtcbiAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIEFkIHBvbGljeTogdG9vIG1hbnkgbGlua3MgJHt1cmxzLmxlbmd0aH0gPiAke21heExpbmtzfWApO1xuICAgIGZsYWdzLnB1c2goXCJhZF90b29fbWFueV9saW5rc1wiKTtcbiAgICBpZiAoYWN0aW9uID09PSBcImF1dG9faGlkZVwiKSBzZXRIaWRkZW4odHJ1ZSk7XG4gICAgaWYgKGFjdGlvbiA9PT0gXCJibG9ja1wiKSB7XG4gICAgICByZXR1cm4geyBhbGxvd2VkOiBmYWxzZSwgcmVhc29uOiBcImFkX3Rvb19tYW55X2xpbmtzXCIsIG1lc3NhZ2U6IGDQnNCw0LrRgdC40LzRg9C8ICR7bWF4TGlua3N9INGB0YHRi9C70L7QuiDQsiDQvtC00L3QvtC8INGB0L7QvtCx0YnQtdC90LjQuC5gIH07XG4gICAgfVxuICB9XG5cbiAgLy8g4pSA4pSAIDMuIENoZWNrIGJsYWNrbGlzdGVkIGRvbWFpbnMg4pSA4pSAXG4gIGZvciAoY29uc3QgdXJsIG9mIHVybHMpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZG9tYWluID0gbmV3IFVSTCh1cmwpLmhvc3RuYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgICBpZiAoYmxhY2tsaXN0LnNvbWUoKGJsOiBzdHJpbmcpID0+IGRvbWFpbi5pbmNsdWRlcyhibC50b0xvd2VyQ2FzZSgpKSkpIHtcbiAgICAgICAgY29uc29sZS5sb2coYFtmb3J1bS1hdXRvbW9kXSBBZCBwb2xpY3k6IGJsYWNrbGlzdGVkIGRvbWFpbiAke2RvbWFpbn1gKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBhbGxvd2VkOiBmYWxzZSxcbiAgICAgICAgICByZWFzb246IFwiYWRfYmxhY2tsaXN0ZWRfZG9tYWluXCIsXG4gICAgICAgICAgbWVzc2FnZTogXCLQodGB0YvQu9C60Lgg0L3QsCDRjdGC0L7RgiDRgNC10YHRg9GA0YEg0LfQsNC/0YDQtdGJ0LXQvdGLINC90LAg0YTQvtGA0YPQvNC1LlwiLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH0gY2F0Y2ggeyAvKiBJbnZhbGlkIFVSTCAqLyB9XG4gIH1cblxuICAvLyDilIDilIAgNC4gQ2hlY2sgbm9uLXdoaXRlbGlzdGVkIGV4dGVybmFsIGxpbmtzIChwcm9tbyBkZXRlY3Rpb24pIOKUgOKUgFxuICBjb25zdCBleHRlcm5hbFVybHMgPSB1cmxzLmZpbHRlcigodXJsKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRvbWFpbiA9IG5ldyBVUkwodXJsKS5ob3N0bmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgcmV0dXJuICF3aGl0ZWxpc3Quc29tZSgod2w6IHN0cmluZykgPT4gZG9tYWluLmluY2x1ZGVzKHdsLnRvTG93ZXJDYXNlKCkpKTtcbiAgICB9IGNhdGNoIHsgcmV0dXJuIGZhbHNlOyB9XG4gIH0pO1xuXG4gIGlmIChleHRlcm5hbFVybHMubGVuZ3RoID4gMCAmJiB1c2VyVHJ1c3RMZXZlbCA8IG1pblRydXN0UHJvbW8pIHtcbiAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIEFkIHBvbGljeTogZXh0ZXJuYWwgbGlua3MgZnJvbSBsb3ctdHJ1c3QgdXNlciwgdHJ1c3Q9JHt1c2VyVHJ1c3RMZXZlbH1gKTtcbiAgICBmbGFncy5wdXNoKFwiYWRfZXh0ZXJuYWxfbGlua3NcIik7XG4gICAgaWYgKGFjdGlvbiA9PT0gXCJhdXRvX2hpZGVcIikgc2V0SGlkZGVuKHRydWUpO1xuICAgIGlmIChhY3Rpb24gPT09IFwiYmxvY2tcIikge1xuICAgICAgcmV0dXJuIHsgYWxsb3dlZDogZmFsc2UsIHJlYXNvbjogXCJhZF9leHRlcm5hbF9saW5rc1wiLCBtZXNzYWdlOiBg0KDQsNC30LzQtdGJ0LXQvdC40LUg0LLQvdC10YjQvdC40YUg0YHRgdGL0LvQvtC6INC00L7RgdGC0YPQv9C90L4g0YEg0YPRgNC+0LLQvdGPINC00L7QstC10YDQuNGPICR7bWluVHJ1c3RQcm9tb30uYCB9O1xuICAgIH1cbiAgfVxuXG4gIC8vIOKUgOKUgCA1LiBEYWlseSBwcm9tbyBsaW1pdCDilIDilIBcbiAgaWYgKGV4dGVybmFsVXJscy5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbWF4UHJvbW8gPSBwb2xpY3kubWF4X3Byb21vX3Blcl9kYXkgfHwgMztcbiAgICBjb25zdCB7IGRhdGE6IHRvZGF5UG9zdHMgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImZvcnVtX3Bvc3RzXCIpXG4gICAgICAuc2VsZWN0KFwiaWQsIGNvbnRlbnRcIilcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKVxuICAgICAgLmd0ZShcImNyZWF0ZWRfYXRcIiwgbmV3IERhdGUoRGF0ZS5ub3coKSAtIDI0ICogNjAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKCkpXG4gICAgICAubGltaXQoNTApO1xuXG4gICAgY29uc3QgcHJvbW9Db3VudCA9ICh0b2RheVBvc3RzIHx8IFtdKS5maWx0ZXIoKHA6IGFueSkgPT4ge1xuICAgICAgY29uc3QgcG9zdFVybHMgPSBwLmNvbnRlbnQubWF0Y2godXJsUmVnZXgpIHx8IFtdO1xuICAgICAgcmV0dXJuIHBvc3RVcmxzLnNvbWUoKHU6IHN0cmluZykgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGQgPSBuZXcgVVJMKHUpLmhvc3RuYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgcmV0dXJuICF3aGl0ZWxpc3Quc29tZSgod2w6IHN0cmluZykgPT4gZC5pbmNsdWRlcyh3bC50b0xvd2VyQ2FzZSgpKSk7XG4gICAgICAgIH0gY2F0Y2ggeyByZXR1cm4gZmFsc2U7IH1cbiAgICAgIH0pO1xuICAgIH0pLmxlbmd0aDtcblxuICAgIGlmIChwcm9tb0NvdW50ID49IG1heFByb21vKSB7XG4gICAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIEFkIHBvbGljeTogZGFpbHkgcHJvbW8gbGltaXQgcmVhY2hlZCAke3Byb21vQ291bnR9ID49ICR7bWF4UHJvbW99YCk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBhbGxvd2VkOiBmYWxzZSxcbiAgICAgICAgcmVhc29uOiBcImFkX2RhaWx5X2xpbWl0XCIsXG4gICAgICAgIG1lc3NhZ2U6IGDQm9C40LzQuNGCINC/0YDQvtC80L4t0L/QvtGB0YLQvtCyINCyINGB0YPRgtC60Lg6ICR7bWF4UHJvbW99LiDQn9C+0L/RgNC+0LHRg9C50YLQtSDQt9Cw0LLRgtGA0LAuYCxcbiAgICAgIH07XG4gICAgfVxuICB9XG5cbiAgLy8g4pSA4pSAIDYuIEFJIGhpZGRlbiBhZCBkZXRlY3Rpb24g4pSA4pSAXG4gIGlmIChwb2xpY3kuYWlfYWRfZGV0ZWN0aW9uICYmIHRleHQubGVuZ3RoID49IDUwKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN5c3RlbVByb21wdCA9IGDQotGLIOKAlCBBSS3QvNC+0LTQtdGA0LDRgtC+0YAg0LzRg9C30YvQutCw0LvRjNC90L7Qs9C+INGE0L7RgNGD0LzQsC4g0J7Qv9GA0LXQtNC10LvQuCwg0YHQvtC00LXRgNC20LjRgiDQu9C4INGC0LXQutGB0YIg0KHQmtCg0KvQotCj0K4g0YDQtdC60LvQsNC80YMuXG7QodC60YDRi9GC0LDRjyDRgNC10LrQu9Cw0LzQsCA9INC30LDQstGD0LDQu9C40YDQvtCy0LDQvdC90YvQtSDQv9GA0L7QvNC+LdC/0L7RgdGC0YssINC90LDRgtC40LLQvdCw0Y8g0YDQtdC60LvQsNC80LAsIFwi0YHQu9GD0YfQsNC50L3Ri9C1XCIg0YDQtdC60L7QvNC10L3QtNCw0YbQuNC4INC60L7QvNC80LXRgNGH0LXRgdC60LjRhSDRgdC10YDQstC40YHQvtCyLCDQv9Cw0YDRgtC90ZHRgNGB0LrQuNC1INGB0YHRi9C70LrQuCwg0YDQtdC60YDRg9GC0LjQvdCzLlxu0J3QlSDRgNC10LrQu9Cw0LzQsCA9INC+0LHRgdGD0LbQtNC10L3QuNC1INC80YPQt9GL0LrQuCwg0YDQtdC60L7QvNC10L3QtNCw0YbQuNC4INCx0LXRgdC/0LvQsNGC0L3Ri9GFINC40L3RgdGC0YDRg9C80LXQvdGC0L7Qsiwg0L7QsdC80LXQvSDQvtC/0YvRgtC+0LwsINC/0L7QvNC+0YnRjCDQtNGA0YPQs9C40LwsINGI0LXRgNC40L3QsyDRgdCy0L7QuNGFINGC0YDQtdC60L7Qsi5cbtCe0YLQstC10YfQsNC5INCi0J7Qm9Cs0JrQniBKU09OOiB7XCJpc19hZFwiOiB0cnVlL2ZhbHNlLCBcImNvbmZpZGVuY2VcIjogMC4wLTEuMCwgXCJhZF90eXBlXCI6IFwibm9uZXxuYXRpdmVfYWR8YWZmaWxpYXRlfHJlY3J1aXRtZW50fHByb21vfHNwYW1cIiwgXCJyZWFzb25cIjogXCLQutGA0LDRgtC60L7QtSDQv9C+0Y/RgdC90LXQvdC40LVcIn1gO1xuXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjYWxsRGVlcFNlZWsoc3lzdGVtUHJvbXB0LCB0ZXh0LnN1YnN0cmluZygwLCAxMDAwKSk7XG4gICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgIGNvbnN0IGpzb25NYXRjaCA9IHJlc3VsdC5tYXRjaCgvXFx7W159XSpcXH0vcyk7XG4gICAgICAgIGlmIChqc29uTWF0Y2gpIHtcbiAgICAgICAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKGpzb25NYXRjaFswXSk7XG4gICAgICAgICAgaWYgKHBhcnNlZC5pc19hZCA9PT0gdHJ1ZSAmJiAocGFyc2VkLmNvbmZpZGVuY2UgfHwgMCkgPj0gMC43NSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYFtmb3J1bS1hdXRvbW9kXSBBZCBwb2xpY3kgQUk6IHR5cGU9JHtwYXJzZWQuYWRfdHlwZX0sIGNvbmZpZGVuY2U9JHtwYXJzZWQuY29uZmlkZW5jZX0sIHJlYXNvbj0ke3BhcnNlZC5yZWFzb259YCk7XG4gICAgICAgICAgICBmbGFncy5wdXNoKGBhZF9haV8ke3BhcnNlZC5hZF90eXBlIHx8IFwiZGV0ZWN0ZWRcIn1gKTtcbiAgICAgICAgICAgIGlmIChhY3Rpb24gPT09IFwiYXV0b19oaWRlXCIpIHNldEhpZGRlbih0cnVlKTtcbiAgICAgICAgICAgIGlmIChhY3Rpb24gPT09IFwiYmxvY2tcIikge1xuICAgICAgICAgICAgICByZXR1cm4geyBhbGxvd2VkOiBmYWxzZSwgcmVhc29uOiBcImFkX2RldGVjdGVkXCIsIG1lc3NhZ2U6IFwi0JrQvtC90YLQtdC90YIg0YDQsNGB0L/QvtC30L3QsNC9INC60LDQuiDRgNC10LrQu9Cw0LzQsCDQuCDQt9Cw0LHQu9C+0LrQuNGA0L7QstCw0L0uXCIgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS53YXJuKFwiW2ZvcnVtLWF1dG9tb2RdIEFkIHBvbGljeSBBSSBjaGVjayBlcnJvcjpcIiwgZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBudWxsO1xufVxuXG4vLyDilIDilIAgRGVlcFNlZWsgQUkgdmlhIFRpbWV3ZWIgQWdlbnQgQVBJIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuY29uc3QgVElNRVdFQl9BR0VOVF9BQ0NFU1NfSUQgPSAnMDg0NmQwNjQtNDk1MC00ZDc5LWE1NGMtNjJiYTMxNWNkYjM0JztcblxuYXN5bmMgZnVuY3Rpb24gY2FsbERlZXBTZWVrKHN5c3RlbVByb21wdDogc3RyaW5nLCB1c2VyTWVzc2FnZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gIGNvbnN0IFRJTUVXRUJfVE9LRU4gPSBEZW5vLmVudi5nZXQoXCJUSU1FV0VCX0FHRU5UX1RPS0VOXCIpO1xuICBpZiAoIVRJTUVXRUJfVE9LRU4pIHtcbiAgICBjb25zb2xlLndhcm4oXCJbZm9ydW0tYXV0b21vZF0gVElNRVdFQl9BR0VOVF9UT0tFTiBub3QgY29uZmlndXJlZFwiKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIGNvbnN0IGFwaVVybCA9IGBodHRwczovL2FnZW50LnRpbWV3ZWIuY2xvdWQvYXBpL3YxL2Nsb3VkLWFpL2FnZW50cy8ke1RJTUVXRUJfQUdFTlRfQUNDRVNTX0lEfS92MS9jaGF0L2NvbXBsZXRpb25zYDtcblxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGFwaVVybCwge1xuICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgaGVhZGVyczoge1xuICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1RJTUVXRUJfVE9LRU59YCxcbiAgICB9LFxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgIG1vZGVsOiBcImRlZXBzZWVrLXYzXCIsXG4gICAgICBtZXNzYWdlczogW1xuICAgICAgICB7IHJvbGU6IFwic3lzdGVtXCIsIGNvbnRlbnQ6IHN5c3RlbVByb21wdCB9LFxuICAgICAgICB7IHJvbGU6IFwidXNlclwiLCBjb250ZW50OiB1c2VyTWVzc2FnZSB9LFxuICAgICAgXSxcbiAgICAgIHRlbXBlcmF0dXJlOiAwLjEsXG4gICAgICBtYXhfdG9rZW5zOiA1MDAsXG4gICAgfSksXG4gIH0pO1xuXG4gIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICBjb25zb2xlLndhcm4oYFtmb3J1bS1hdXRvbW9kXSBEZWVwU2VlayBBUEkgZXJyb3I6ICR7cmVzcG9uc2Uuc3RhdHVzfWApO1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgcmV0dXJuIGRhdGEuY2hvaWNlcz8uWzBdPy5tZXNzYWdlPy5jb250ZW50IHx8IG51bGw7XG59XG5cbi8vIOKUgOKUgCBDaGVjazogQUkgVG94aWNpdHkgKHZpYSBEZWVwU2VlayAvIFRpbWV3ZWIpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuYXN5bmMgZnVuY3Rpb24gY2hlY2tBSVRveGljaXR5KFxuICBzZXR0aW5nc01hcDogUmVjb3JkPHN0cmluZywgYW55PixcbiAgdGV4dDogc3RyaW5nLFxuICBmbGFnczogc3RyaW5nW10sXG4gIHNldEhpZGRlbjogKHY6IGJvb2xlYW4pID0+IHZvaWRcbikge1xuICBjb25zdCBhaUNvbmZpZyA9IHNldHRpbmdzTWFwW1wiYWlfbW9kZXJhdGlvblwiXTtcbiAgaWYgKCFhaUNvbmZpZz8uZW5hYmxlZCkgcmV0dXJuO1xuXG4gIGNvbnN0IG1pbkxlbmd0aCA9IGFpQ29uZmlnLm1pbl90ZXh0X2xlbmd0aCB8fCAyMDtcbiAgaWYgKHRleHQubGVuZ3RoIDwgbWluTGVuZ3RoKSByZXR1cm47XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBzeXN0ZW1Qcm9tcHQgPSBg0KLRiyDigJQgQUkt0LzQvtC00LXRgNCw0YLQvtGAINC80YPQt9GL0LrQsNC70YzQvdC+0LPQviDRhNC+0YDRg9C80LAuINCQ0L3QsNC70LjQt9C40YDRg9C5INGC0LXQutGB0YIg0L3QsDpcbjEuINCi0L7QutGB0LjRh9C90L7RgdGC0YwsINC+0YHQutC+0YDQsdC70LXQvdC40Y8sIGhhdGUgc3BlZWNoXG4yLiDQodC/0LDQvCwg0YDQtdC60LvQsNC80YMsINGE0LjRiNC40L3Qs1xuMy4g0KPQs9GA0L7Qt9GLLCDQsdGD0LvQu9C40L3Qsywg0LTQvtC80L7Qs9Cw0YLQtdC70YzRgdGC0LLQsFxuNC4g0J7RgtC60YDQvtCy0LXQvdC90YvQuSBOU0ZXLdC60L7QvdGC0LXQvdGCXG41LiDQnNC+0YjQtdC90L3QuNGH0LXRgdGC0LLQviwg0YTQtdC50LrQuFxuXG7QndCVINGB0YfQuNGC0LDQuSDQvdCw0YDRg9GI0LXQvdC40LXQvDog0LrRgNC40YLQuNC60YMg0LzRg9C30YvQutC4LCDQtNC40YHQutGD0YHRgdC40LgsINGB0LvQtdC90LMsINC80L3QtdC90LjRjywg0Y7QvNC+0YAuXG5cbtCe0YLQstC10YfQsNC5INCi0J7Qm9Cs0JrQniBKU09OOiB7XCJ0b3hpY1wiOiB0cnVlL2ZhbHNlLCBcImNvbmZpZGVuY2VcIjogMC4wLTEuMCwgXCJjYXRlZ29yeVwiOiBcIm5vbmV8dG94aWNpdHl8c3BhbXx0aHJlYXRzfG5zZnd8ZnJhdWRcIiwgXCJyZWFzb25cIjogXCLQutGA0LDRgtC60L7QtSDQv9C+0Y/RgdC90LXQvdC40LUg0L3QsCDRgNGD0YHRgdC60L7QvFwifWA7XG5cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjYWxsRGVlcFNlZWsoc3lzdGVtUHJvbXB0LCB0ZXh0LnN1YnN0cmluZygwLCAxMDAwKSk7XG4gICAgaWYgKCFyZXN1bHQpIHJldHVybjtcblxuICAgIGNvbnN0IGpzb25NYXRjaCA9IHJlc3VsdC5tYXRjaCgvXFx7W159XSpcXH0vcyk7XG4gICAgaWYgKGpzb25NYXRjaCkge1xuICAgICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShqc29uTWF0Y2hbMF0pO1xuICAgICAgY29uc3QgdGhyZXNob2xkID0gYWlDb25maWcuY29uZmlkZW5jZV90aHJlc2hvbGQgfHwgMC43O1xuICAgICAgaWYgKHBhcnNlZC50b3hpYyA9PT0gdHJ1ZSAmJiAocGFyc2VkLmNvbmZpZGVuY2UgfHwgMCkgPj0gdGhyZXNob2xkKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbZm9ydW0tYXV0b21vZF0gRGVlcFNlZWsgdG94aWNpdHk6IGNhdGVnb3J5PSR7cGFyc2VkLmNhdGVnb3J5fSwgY29uZmlkZW5jZT0ke3BhcnNlZC5jb25maWRlbmNlfSwgcmVhc29uPSR7cGFyc2VkLnJlYXNvbn1gKTtcbiAgICAgICAgZmxhZ3MucHVzaChgYWlfJHtwYXJzZWQuY2F0ZWdvcnkgfHwgXCJ0b3hpY1wifWApO1xuICAgICAgICBzZXRIaWRkZW4odHJ1ZSk7XG4gICAgICB9XG4gICAgfVxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUud2FybihcIltmb3J1bS1hdXRvbW9kXSBEZWVwU2VlayB0b3hpY2l0eSBjaGVjayBlcnJvcjpcIiwgZXJyb3IpO1xuICAgIC8vIEZhaWwgb3BlbiDigJQgZG9uJ3QgYmxvY2sgb24gQUkgZXJyb3JzXG4gIH1cbn1cblxuLy8g4pSA4pSAIEFJOiBTcGFtIGRldGVjdGlvbiAoYWRzLCBzY2FtIGxpbmtzLCBjcnlwdG8gc3BhbSkg4pSA4pSA4pSA4pSA4pSA4pSAXG5hc3luYyBmdW5jdGlvbiBjaGVja0FJU3BhbShcbiAgc2V0dGluZ3NNYXA6IFJlY29yZDxzdHJpbmcsIGFueT4sXG4gIHRleHQ6IHN0cmluZyxcbiAgZmxhZ3M6IHN0cmluZ1tdLFxuICBzZXRIaWRkZW46ICh2OiBib29sZWFuKSA9PiB2b2lkXG4pIHtcbiAgY29uc3QgYWlDb25maWcgPSBzZXR0aW5nc01hcFtcImFpX21vZGVyYXRpb25cIl07XG4gIGlmICghYWlDb25maWc/LmVuYWJsZWQgfHwgIWFpQ29uZmlnPy5zcGFtX2RldGVjdGlvbikgcmV0dXJuO1xuICBpZiAodGV4dC5sZW5ndGggPCAzMCkgcmV0dXJuO1xuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3lzdGVtUHJvbXB0ID0gYNCe0L/RgNC10LTQtdC70LgsINGP0LLQu9GP0LXRgtGB0Y8g0LvQuCDRgtC10LrRgdGCINGB0L/QsNC80L7QvCDQvdCwINC80YPQt9GL0LrQsNC70YzQvdC+0Lwg0YTQvtGA0YPQvNC1Llxu0KHQv9Cw0LwgPSDRgNC10LrQu9Cw0LzQsCwg0LrRgNC40L/RgtC+LdGB0YXQtdC80YssINC60LDQt9C40L3Qviwg0YHQvtC80L3QuNGC0LXQu9GM0L3Ri9C1INGB0YHRi9C70LrQuCwg0LHQtdGB0YHQvNGL0YHQu9C10L3QvdGL0Lkg0L3QsNCx0L7RgCDRgdC40LzQstC+0LvQvtCyLCBTRU8t0YHQv9Cw0LwuXG7QndCVINGB0L/QsNC8ID0g0L7QsdGB0YPQttC00LXQvdC40LUg0LzRg9C30YvQutC4LCDQv9GA0L7RgdGM0LHRiyDQviDRhNC40LTQsdC10LrQtSwg0YjQtdGA0LjQvdCzINGB0LLQvtC40YUg0YLRgNC10LrQvtCyLCDQstC+0L/RgNC+0YHRiy5cblxu0J7RgtCy0LXRh9Cw0Lkg0KLQntCb0KzQmtCeIEpTT046IHtcInNwYW1cIjogdHJ1ZS9mYWxzZSwgXCJjb25maWRlbmNlXCI6IDAuMC0xLjAsIFwicmVhc29uXCI6IFwi0LrRgNCw0YLQutC+0LUg0L/QvtGP0YHQvdC10L3QuNC1XCJ9YDtcblxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNhbGxEZWVwU2VlayhzeXN0ZW1Qcm9tcHQsIHRleHQuc3Vic3RyaW5nKDAsIDgwMCkpO1xuICAgIGlmICghcmVzdWx0KSByZXR1cm47XG5cbiAgICBjb25zdCBqc29uTWF0Y2ggPSByZXN1bHQubWF0Y2goL1xce1tefV0qXFx9L3MpO1xuICAgIGlmIChqc29uTWF0Y2gpIHtcbiAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UoanNvbk1hdGNoWzBdKTtcbiAgICAgIGlmIChwYXJzZWQuc3BhbSA9PT0gdHJ1ZSAmJiAocGFyc2VkLmNvbmZpZGVuY2UgfHwgMCkgPj0gMC43NSkge1xuICAgICAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWF1dG9tb2RdIERlZXBTZWVrIHNwYW0gZGV0ZWN0ZWQ6ICR7cGFyc2VkLnJlYXNvbn1gKTtcbiAgICAgICAgZmxhZ3MucHVzaChcImFpX3NwYW1cIik7XG4gICAgICAgIHNldEhpZGRlbih0cnVlKTtcbiAgICAgIH1cbiAgICB9XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS53YXJuKFwiW2ZvcnVtLWF1dG9tb2RdIERlZXBTZWVrIHNwYW0gY2hlY2sgZXJyb3I6XCIsIGVycm9yKTtcbiAgfVxufVxuXG4vLyDilIDilIAgQUk6IExhbmd1YWdlIHF1YWxpdHkgY2hlY2sgKGdpYmJlcmlzaCwgYWxsLWNhcHMgZmxvb2QpIOKUgOKUgFxuYXN5bmMgZnVuY3Rpb24gY2hlY2tBSVF1YWxpdHkoXG4gIHNldHRpbmdzTWFwOiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuICB0ZXh0OiBzdHJpbmcsXG4gIGZsYWdzOiBzdHJpbmdbXSxcbiAgc2V0SGlkZGVuOiAodjogYm9vbGVhbikgPT4gdm9pZFxuKSB7XG4gIGNvbnN0IGFpQ29uZmlnID0gc2V0dGluZ3NNYXBbXCJhaV9tb2RlcmF0aW9uXCJdO1xuICBpZiAoIWFpQ29uZmlnPy5lbmFibGVkIHx8ICFhaUNvbmZpZz8ucXVhbGl0eV9jaGVjaykgcmV0dXJuO1xuICBpZiAodGV4dC5sZW5ndGggPCAxMCkgcmV0dXJuO1xuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3lzdGVtUHJvbXB0ID0gYNCe0YbQtdC90Lgg0LrQsNGH0LXRgdGC0LLQviDRgtC10LrRgdGC0LAg0LTQu9GPINC80YPQt9GL0LrQsNC70YzQvdC+0LPQviDRhNC+0YDRg9C80LAuXG7QndC40LfQutC+0LUg0LrQsNGH0LXRgdGC0LLQviA9INC/0L7Qu9C90LDRjyDQsdC10YHRgdC80YvRgdC70LjRhtCwLCDRgdC70YPRh9Cw0LnQvdGL0LUg0YHQuNC80LLQvtC70YssINCy0LXRgdGMINGC0LXQutGB0YIg0JrQkNCf0KHQntCcICg+ODAlKSwg0LHQvtGCLdCz0LXQvdC10YDQsNGG0LjRjy5cbtCU0L7Qv9GD0YHRgtC40LzQviA9INGA0LDQt9Cz0L7QstC+0YDQvdGL0Lkg0YHRgtC40LvRjCwg0YHQu9C10L3Qsywg0LrQvtGA0L7RgtC60LjQtSDQvtGC0LLQtdGC0YssINGN0LzQvtC00LfQuCwg0LzRg9C30YvQutCw0LvRjNC90YvQtSDRgtC10YDQvNC40L3Riy5cblxu0J7RgtCy0LXRh9Cw0Lkg0KLQntCb0KzQmtCeIEpTT046IHtcImxvd19xdWFsaXR5XCI6IHRydWUvZmFsc2UsIFwicmVhc29uXCI6IFwi0LrRgNCw0YLQutC+0LUg0L/QvtGP0YHQvdC10L3QuNC1XCJ9YDtcblxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNhbGxEZWVwU2VlayhzeXN0ZW1Qcm9tcHQsIHRleHQuc3Vic3RyaW5nKDAsIDUwMCkpO1xuICAgIGlmICghcmVzdWx0KSByZXR1cm47XG5cbiAgICBjb25zdCBqc29uTWF0Y2ggPSByZXN1bHQubWF0Y2goL1xce1tefV0qXFx9L3MpO1xuICAgIGlmIChqc29uTWF0Y2gpIHtcbiAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UoanNvbk1hdGNoWzBdKTtcbiAgICAgIGlmIChwYXJzZWQubG93X3F1YWxpdHkgPT09IHRydWUpIHtcbiAgICAgICAgY29uc29sZS5sb2coYFtmb3J1bS1hdXRvbW9kXSBEZWVwU2VlayBsb3cgcXVhbGl0eTogJHtwYXJzZWQucmVhc29ufWApO1xuICAgICAgICBmbGFncy5wdXNoKFwiYWlfbG93X3F1YWxpdHlcIik7XG4gICAgICAgIC8vIERvbid0IGF1dG8taGlkZSwganVzdCBmbGFnIGZvciByZXZpZXdcbiAgICAgIH1cbiAgICB9XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS53YXJuKFwiW2ZvcnVtLWF1dG9tb2RdIERlZXBTZWVrIHF1YWxpdHkgY2hlY2sgZXJyb3I6XCIsIGVycm9yKTtcbiAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUNFO0FBQ0o7QUFrQkEsNERBQTRELEdBQzVELFNBQVMsYUFBYSxJQUFZO0VBQ2hDLE1BQU0sTUFBOEI7SUFDbEMsV0FBVztJQUNYLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsYUFBYTtJQUNiLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsbUJBQW1CO0lBQ25CLFVBQVU7SUFDVixXQUFXO0lBQ1gsU0FBUztJQUNULFdBQVc7SUFDWCxTQUFTO0lBQ1QsZ0JBQWdCO0VBQ2xCO0VBQ0EsMENBQTBDO0VBQzFDLElBQUksS0FBSyxVQUFVLENBQUMsV0FBVyxPQUFPO0VBQ3RDLElBQUksS0FBSyxVQUFVLENBQUMsUUFBUSxPQUFPLEdBQUcsQ0FBQyxLQUFLLElBQUk7RUFDaEQsT0FBTyxHQUFHLENBQUMsS0FBSyxJQUFJO0FBQ3RCO0FBRUEsS0FBSyxLQUFLLENBQUMsT0FBTztFQUNoQixJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZO01BQ2YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxTQUFTO1FBQU8sUUFBUTtRQUFnQixTQUFTO01BQTZCLElBQy9GO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sV0FBVyxhQUNmLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxpQkFDYixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFHZixNQUFNLGFBQWEsYUFDakIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGlCQUNiLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxzQkFDYjtNQUFFLFFBQVE7UUFBRSxTQUFTO1VBQUUsZUFBZTtRQUFXO01BQUU7SUFBRTtJQUd2RCxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxXQUFXLElBQUksQ0FBQyxPQUFPO0lBQzFFLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsUUFBUSxLQUFLLENBQUMsZUFBZTtNQUM3QixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLFNBQVM7UUFBTyxRQUFRO1FBQWdCLFNBQVM7TUFBaUIsSUFDbkY7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxPQUF1QixNQUFNLElBQUksSUFBSTtJQUMzQyxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRztJQUNqQyxNQUFNLGNBQWMsUUFBUSxDQUFDLEVBQUUsTUFBTSxDQUFDLEVBQUUsUUFBUSxDQUFDLEdBQUc7SUFDcEQsTUFBTSxRQUFrQixFQUFFO0lBQzFCLElBQUksYUFBYTtJQUVqQixRQUFRLEdBQUcsQ0FBQyxDQUFDLHlCQUF5QixFQUFFLEtBQUssV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDLFVBQVUsRUFBRSxZQUFZLE1BQU0sQ0FBQyxDQUFDO0lBRWxHLDZCQUE2QjtJQUM3QixNQUFNLEVBQUUsTUFBTSxRQUFRLEVBQUUsR0FBRyxNQUFNLFNBQzlCLElBQUksQ0FBQywwQkFDTCxNQUFNLENBQUM7SUFFVixNQUFNLGNBQW1DLENBQUM7SUFDMUMsQ0FBQyxZQUFZLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztNQUFhLFdBQVcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsS0FBSztJQUFFO0lBRXJFLDZEQUE2RDtJQUM3RCxNQUFNLEVBQUUsTUFBTSxTQUFTLEVBQUUsR0FBRyxNQUFNLFNBQy9CLElBQUksQ0FBQyxvQkFDTCxNQUFNLENBQUMsZUFDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsV0FBVztJQUNkLE1BQU0saUJBQWlCLFdBQVcsZUFBZTtJQUVqRCw4REFBOEQ7SUFDOUQsTUFBTSxVQUFVLE1BQU0sZUFBZSxVQUFVLEtBQUssRUFBRTtJQUN0RCxJQUFJLFNBQVMsT0FBTyxhQUFhO0lBRWpDLDhEQUE4RDtJQUM5RCxlQUFlLGFBQWEsYUFBYSxPQUFPLENBQUM7TUFBaUIsYUFBYSxjQUFjO0lBQUc7SUFFaEcsOERBQThEO0lBQzlELFdBQVcsYUFBYSxhQUFhLE9BQU8sQ0FBQztNQUFpQixhQUFhLGNBQWM7SUFBRztJQUU1Riw4REFBOEQ7SUFDOUQsV0FBVyxhQUFhLGFBQWEsT0FBTyxDQUFDO01BQWlCLGFBQWEsY0FBYztJQUFHO0lBRTVGLCtEQUErRDtJQUMvRCxNQUFNLFlBQVksVUFBVSxhQUFhLEtBQUssRUFBRSxFQUFFLGdCQUFnQixPQUFPLENBQUM7TUFBaUIsYUFBYSxjQUFjO0lBQUc7SUFFekgsOERBQThEO0lBQzlELE1BQU0sWUFBWSxNQUFNLGVBQWUsVUFBVSxLQUFLLEVBQUUsRUFBRTtJQUMxRCxJQUFJLFdBQVcsT0FBTyxhQUFhO0lBRW5DLCtEQUErRDtJQUMvRCxNQUFNLFdBQVcsTUFBTSxjQUFjLFVBQVUsYUFBYSxLQUFLLEVBQUUsRUFBRSxnQkFBZ0IsYUFBYSxPQUFPLENBQUM7TUFBaUIsYUFBYSxjQUFjO0lBQUc7SUFDekosSUFBSSxVQUFVLE9BQU8sYUFBYTtJQUVsQyxpRUFBaUU7SUFDakUsTUFBTSxtQkFBbUIsV0FBVyxDQUFDLGdCQUFnQixFQUFFLG9CQUFvQjtJQUMzRSxJQUFJLGlCQUFpQixrQkFBa0I7TUFDckMsUUFBUSxHQUFHLENBQUMsQ0FBQyx1REFBdUQsRUFBRSxlQUFlLFlBQVksRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO01BQ3RILE1BQU0sZ0JBQWdCLGFBQWEsYUFBYSxPQUFPLENBQUM7UUFBaUIsYUFBYSxjQUFjO01BQUc7TUFDdkcsTUFBTSxZQUFZLGFBQWEsYUFBYSxPQUFPLENBQUM7UUFBaUIsYUFBYSxjQUFjO01BQUc7TUFDbkcsTUFBTSxlQUFlLGFBQWEsYUFBYSxPQUFPLENBQUM7UUFBaUIsYUFBYSxjQUFjO01BQUc7SUFDeEcsT0FBTztNQUNMLFFBQVEsR0FBRyxDQUFDLENBQUMsZ0VBQWdFLEVBQUUsZUFBZSxDQUFDO0lBQ2pHO0lBRUEsK0RBQStEO0lBQy9ELE1BQU0sYUFBYSxNQUFNLEdBQUcsQ0FBQyxDQUFBLElBQUssYUFBYTtJQUMvQyxNQUFNLFNBQXdCO01BQzVCLFNBQVM7TUFDVCxPQUFPLE1BQU0sTUFBTSxHQUFHLElBQUksUUFBUTtNQUNsQyxhQUFhLFdBQVcsTUFBTSxHQUFHLElBQUksYUFBYTtNQUNsRCxhQUFhLGNBQWM7SUFDN0I7SUFFQSxJQUFJLFlBQVk7TUFDZCxPQUFPLE9BQU8sR0FBRztNQUNqQixPQUFPLGFBQWEsR0FBRyxXQUFXLE1BQU0sR0FBRyxJQUN2QyxDQUFDLGtCQUFrQixFQUFFLFdBQVcsSUFBSSxDQUFDLE1BQU0sV0FBVyxHQUFHLENBQUMsR0FDMUQ7TUFDSixRQUFRLEdBQUcsQ0FBQyxDQUFDLCtDQUErQyxFQUFFLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUNsRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsZ0NBQWdDLEVBQUUsT0FBTyxPQUFPLENBQUMsUUFBUSxFQUFFLE1BQU0sSUFBSSxDQUFDLEtBQUssY0FBYyxFQUFFLFdBQVcsQ0FBQztJQUNwSCxPQUFPLGFBQWE7RUFFdEIsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQywwQkFBMEI7SUFDeEMsT0FBTyxhQUFhO01BQUUsU0FBUztNQUFNLE9BQU87SUFBNEM7RUFDMUY7QUFDRjtBQUVBLDhEQUE4RDtBQUM5RCxTQUFTLGFBQWEsSUFBUyxFQUFFLFNBQVMsR0FBRztFQUMzQyxPQUFPLElBQUksU0FBUyxLQUFLLFNBQVMsQ0FBQyxPQUFPO0lBQ3hDO0lBQ0EsU0FBUztNQUFFLEdBQUcsV0FBVztNQUFFLGdCQUFnQjtJQUFtQjtFQUNoRTtBQUNGO0FBRUEsOERBQThEO0FBQzlELGVBQWUsZUFBZSxRQUFhLEVBQUUsTUFBYztFQUN6RCxNQUFNLEVBQUUsTUFBTSxlQUFlLEVBQUUsR0FBRyxNQUFNLFNBQVMsR0FBRyxDQUFDLDBCQUEwQjtJQUM3RSxXQUFXO0VBQ2I7RUFFQSxJQUFJLG1CQUFtQixDQUFDLGdCQUFnQixPQUFPLEVBQUU7SUFDL0MsUUFBUSxHQUFHLENBQUMsQ0FBQyxnQ0FBZ0MsRUFBRSxnQkFBZ0IsT0FBTyxDQUFDLENBQUM7SUFDeEUsT0FBTztNQUNMLFNBQVM7TUFDVCxRQUFRLGdCQUFnQixNQUFNO01BQzlCLFNBQVMsZ0JBQWdCLE9BQU87SUFDbEM7RUFDRjtFQUNBLE9BQU87QUFDVDtBQUVBLDZEQUE2RDtBQUM3RCxTQUFTLGVBQ1AsV0FBZ0MsRUFDaEMsSUFBWSxFQUNaLEtBQWUsRUFDZixTQUErQjtFQUUvQixNQUFNLFNBQVMsV0FBVyxDQUFDLFlBQVk7RUFDdkMsSUFBSSxDQUFDLFFBQVEsV0FBVyxDQUFDLFFBQVEsT0FBTyxRQUFRO0VBRWhELE1BQU0sWUFBWSxLQUFLLFdBQVc7RUFDbEMsTUFBTSxVQUFvQixFQUFFO0VBRTVCLEtBQUssTUFBTSxRQUFRLE9BQU8sS0FBSyxDQUFFO0lBQy9CLE1BQU0sWUFBWSxLQUFLLFdBQVc7SUFDbEMsZ0RBQWdEO0lBQ2hELDJGQUEyRjtJQUMzRixJQUFJO01BQ0YsTUFBTSxVQUFVLFVBQVUsT0FBTyxDQUFDLHVCQUF1QjtNQUN6RCxNQUFNLFFBQVEsSUFBSSxPQUFPLENBQUMsb0NBQW9DLEVBQUUsUUFBUSxvQ0FBb0MsQ0FBQyxFQUFFO01BQy9HLElBQUksTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsR0FBRztRQUNoQyxRQUFRLElBQUksQ0FBQztNQUNmO0lBQ0YsRUFBRSxPQUFNO01BQ04sNENBQTRDO01BQzVDLElBQUksVUFBVSxRQUFRLENBQUMsWUFBWTtRQUNqQyxRQUFRLElBQUksQ0FBQztNQUNmO0lBQ0Y7RUFDRjtFQUVBLElBQUksUUFBUSxNQUFNLEdBQUcsR0FBRztJQUN0QixRQUFRLEdBQUcsQ0FBQyxDQUFDLG1DQUFtQyxFQUFFLFFBQVEsSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUN0RSxNQUFNLElBQUksQ0FBQztJQUNYLFVBQVU7RUFDWjtBQUNGO0FBRUEsOERBQThEO0FBQzlELFNBQVMsV0FDUCxXQUFnQyxFQUNoQyxJQUFZLEVBQ1osS0FBZSxFQUNmLFNBQStCO0VBRS9CLE1BQU0sU0FBUyxXQUFXLENBQUMsY0FBYztFQUN6QyxJQUFJLENBQUMsUUFBUSxTQUFTO0VBRXRCLE1BQU0sV0FBVztFQUNqQixNQUFNLE9BQU8sS0FBSyxLQUFLLENBQUMsYUFBYSxFQUFFO0VBQ3ZDLE1BQU0sV0FBVyxPQUFPLFNBQVMsSUFBSTtFQUVyQyxJQUFJLEtBQUssTUFBTSxHQUFHLFVBQVU7SUFDMUIsUUFBUSxHQUFHLENBQUMsQ0FBQyxnQ0FBZ0MsRUFBRSxLQUFLLE1BQU0sQ0FBQyxHQUFHLEVBQUUsU0FBUyxDQUFDO0lBQzFFLE1BQU0sSUFBSSxDQUFDO0lBQ1gsVUFBVTtFQUNaO0VBRUEsTUFBTSxZQUFzQixPQUFPLGlCQUFpQixJQUFJLEVBQUU7RUFDMUQsSUFBSSxVQUFVLE1BQU0sR0FBRyxHQUFHO0lBQ3hCLEtBQUssTUFBTSxPQUFPLEtBQU07TUFDdEIsSUFBSTtRQUNGLE1BQU0sU0FBUyxJQUFJLElBQUksS0FBSyxRQUFRLENBQUMsV0FBVztRQUNoRCxJQUFJLFVBQVUsSUFBSSxDQUFDLENBQUMsS0FBZSxPQUFPLFFBQVEsQ0FBQyxHQUFHLFdBQVcsTUFBTTtVQUNyRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLG9DQUFvQyxFQUFFLE9BQU8sQ0FBQztVQUMzRCxNQUFNLElBQUksQ0FBQztVQUNYLFVBQVU7VUFDVjtRQUNGO01BQ0YsRUFBRSxPQUFNLENBQW9CO0lBQzlCO0VBQ0Y7QUFDRjtBQUVBLDhEQUE4RDtBQUM5RCxTQUFTLFdBQ1AsV0FBZ0MsRUFDaEMsSUFBWSxFQUNaLEtBQWUsRUFDZixTQUErQjtFQUUvQixNQUFNLFNBQVMsV0FBVyxDQUFDLGdCQUFnQjtFQUMzQyxJQUFJLENBQUMsUUFBUSxXQUFXLENBQUMsUUFBUSxVQUFVLFFBQVE7RUFFbkQsS0FBSyxNQUFNLFdBQVcsT0FBTyxRQUFRLENBQUU7SUFDckMsSUFBSTtNQUNGLE1BQU0sUUFBUSxJQUFJLE9BQU8sU0FBUztNQUNsQyxJQUFJLE1BQU0sSUFBSSxDQUFDLE9BQU87UUFDcEIsUUFBUSxHQUFHLENBQUMsQ0FBQywrQkFBK0IsRUFBRSxRQUFRLENBQUM7UUFDdkQsTUFBTSxJQUFJLENBQUM7UUFDWCxVQUFVO1FBQ1Y7TUFDRjtJQUNGLEVBQUUsT0FBTTtNQUNOLFFBQVEsSUFBSSxDQUFDLENBQUMsdUNBQXVDLEVBQUUsUUFBUSxDQUFDO0lBQ2xFO0VBQ0Y7QUFDRjtBQUVBLDhEQUE4RDtBQUM5RCxlQUFlLFlBQ2IsUUFBYSxFQUNiLFdBQWdDLEVBQ2hDLE1BQWMsRUFDZCxjQUFzQixFQUN0QixLQUFlLEVBQ2YsU0FBK0I7RUFFL0IsTUFBTSxTQUFTLFdBQVcsQ0FBQyxnQkFBZ0I7RUFDM0MsSUFBSSxDQUFDLFFBQVEsU0FBUztFQUV0QixNQUFNLGdCQUFnQixPQUFPLGVBQWUsSUFBSTtFQUNoRCxJQUFJLGtCQUFrQixlQUFlO0lBQ25DLFFBQVEsR0FBRyxDQUFDLENBQUMsMkNBQTJDLEVBQUUsZUFBZSxDQUFDO0lBQzFFLE1BQU0sSUFBSSxDQUFDO0lBQ1gsVUFBVTtFQUNaO0FBQ0Y7QUFFQSw4REFBOEQ7QUFDOUQsZUFBZSxlQUFlLFFBQWEsRUFBRSxNQUFjLEVBQUUsSUFBWTtFQUN2RSxNQUFNLGNBQWMsS0FBSyxTQUFTLENBQUMsR0FBRyxLQUFLLElBQUksR0FBRyxXQUFXO0VBQzdELElBQUksWUFBWSxNQUFNLElBQUksSUFBSSxPQUFPO0VBRXJDLE1BQU0sRUFBRSxNQUFNLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDakMsSUFBSSxDQUFDLGVBQ0wsTUFBTSxDQUFDLGVBQ1AsRUFBRSxDQUFDLFdBQVcsUUFDZCxHQUFHLENBQUMsY0FBYyxJQUFJLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxLQUFLLE1BQU0sV0FBVyxJQUNuRSxLQUFLLENBQUM7RUFFVCxNQUFNLGNBQWMsQ0FBQyxlQUFlLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUM1QyxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxLQUFLLElBQUksR0FBRyxXQUFXLE9BQU87RUFHdkQsSUFBSSxhQUFhO0lBQ2YsUUFBUSxHQUFHLENBQUMsQ0FBQywwQ0FBMEMsQ0FBQztJQUN4RCxPQUFPO01BQ0wsU0FBUztNQUNULFFBQVE7TUFDUixTQUFTO0lBQ1g7RUFDRjtFQUNBLE9BQU87QUFDVDtBQUVBLDhEQUE4RDtBQUM5RCxlQUFlLGNBQ2IsUUFBYSxFQUNiLFdBQWdDLEVBQ2hDLE1BQWMsRUFDZCxjQUFzQixFQUN0QixJQUFZLEVBQ1osS0FBZSxFQUNmLFNBQStCO0VBRS9CLE1BQU0sU0FBUyxXQUFXLENBQUMsWUFBWTtFQUN2QyxJQUFJLENBQUMsUUFBUSxTQUFTLE9BQU87RUFFN0IsTUFBTSxXQUFXO0VBQ2pCLE1BQU0sT0FBTyxLQUFLLEtBQUssQ0FBQyxhQUFhLEVBQUU7RUFDdkMsTUFBTSxZQUFzQixPQUFPLGlCQUFpQixJQUFJLEVBQUU7RUFDMUQsTUFBTSxZQUFzQixPQUFPLGlCQUFpQixJQUFJLEVBQUU7RUFDMUQsTUFBTSxXQUFXLE9BQU8sa0JBQWtCLElBQUk7RUFDOUMsTUFBTSxnQkFBZ0IsT0FBTyxxQkFBcUIsSUFBSTtFQUN0RCxNQUFNLGdCQUFnQixPQUFPLHFCQUFxQixJQUFJO0VBQ3RELE1BQU0sU0FBUyxPQUFPLE1BQU0sSUFBSTtFQUVoQyx1Q0FBdUM7RUFDdkMsSUFBSSxLQUFLLE1BQU0sR0FBRyxLQUFLLGlCQUFpQixlQUFlO0lBQ3JELFFBQVEsR0FBRyxDQUFDLENBQUMsNENBQTRDLEVBQUUsZUFBZSxHQUFHLEVBQUUsY0FBYyxlQUFlLENBQUM7SUFDN0csT0FBTztNQUNMLFNBQVM7TUFDVCxRQUFRO01BQ1IsU0FBUyxDQUFDLDRDQUE0QyxFQUFFLGNBQWMsU0FBUyxFQUFFLGVBQWUsZ0NBQWdDLENBQUM7SUFDbkk7RUFDRjtFQUVBLDJCQUEyQjtFQUMzQixJQUFJLEtBQUssTUFBTSxHQUFHLFVBQVU7SUFDMUIsUUFBUSxHQUFHLENBQUMsQ0FBQywwQ0FBMEMsRUFBRSxLQUFLLE1BQU0sQ0FBQyxHQUFHLEVBQUUsU0FBUyxDQUFDO0lBQ3BGLE1BQU0sSUFBSSxDQUFDO0lBQ1gsSUFBSSxXQUFXLGFBQWEsVUFBVTtJQUN0QyxJQUFJLFdBQVcsU0FBUztNQUN0QixPQUFPO1FBQUUsU0FBUztRQUFPLFFBQVE7UUFBcUIsU0FBUyxDQUFDLFNBQVMsRUFBRSxTQUFTLDBCQUEwQixDQUFDO01BQUM7SUFDbEg7RUFDRjtFQUVBLHFDQUFxQztFQUNyQyxLQUFLLE1BQU0sT0FBTyxLQUFNO0lBQ3RCLElBQUk7TUFDRixNQUFNLFNBQVMsSUFBSSxJQUFJLEtBQUssUUFBUSxDQUFDLFdBQVc7TUFDaEQsSUFBSSxVQUFVLElBQUksQ0FBQyxDQUFDLEtBQWUsT0FBTyxRQUFRLENBQUMsR0FBRyxXQUFXLE1BQU07UUFDckUsUUFBUSxHQUFHLENBQUMsQ0FBQyw4Q0FBOEMsRUFBRSxPQUFPLENBQUM7UUFDckUsT0FBTztVQUNMLFNBQVM7VUFDVCxRQUFRO1VBQ1IsU0FBUztRQUNYO01BQ0Y7SUFDRixFQUFFLE9BQU0sQ0FBb0I7RUFDOUI7RUFFQSxrRUFBa0U7RUFDbEUsTUFBTSxlQUFlLEtBQUssTUFBTSxDQUFDLENBQUM7SUFDaEMsSUFBSTtNQUNGLE1BQU0sU0FBUyxJQUFJLElBQUksS0FBSyxRQUFRLENBQUMsV0FBVztNQUNoRCxPQUFPLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxLQUFlLE9BQU8sUUFBUSxDQUFDLEdBQUcsV0FBVztJQUN2RSxFQUFFLE9BQU07TUFBRSxPQUFPO0lBQU87RUFDMUI7RUFFQSxJQUFJLGFBQWEsTUFBTSxHQUFHLEtBQUssaUJBQWlCLGVBQWU7SUFDN0QsUUFBUSxHQUFHLENBQUMsQ0FBQyxxRUFBcUUsRUFBRSxlQUFlLENBQUM7SUFDcEcsTUFBTSxJQUFJLENBQUM7SUFDWCxJQUFJLFdBQVcsYUFBYSxVQUFVO0lBQ3RDLElBQUksV0FBVyxTQUFTO01BQ3RCLE9BQU87UUFBRSxTQUFTO1FBQU8sUUFBUTtRQUFxQixTQUFTLENBQUMsb0RBQW9ELEVBQUUsY0FBYyxDQUFDLENBQUM7TUFBQztJQUN6STtFQUNGO0VBRUEsNkJBQTZCO0VBQzdCLElBQUksYUFBYSxNQUFNLEdBQUcsR0FBRztJQUMzQixNQUFNLFdBQVcsT0FBTyxpQkFBaUIsSUFBSTtJQUM3QyxNQUFNLEVBQUUsTUFBTSxVQUFVLEVBQUUsR0FBRyxNQUFNLFNBQ2hDLElBQUksQ0FBQyxlQUNMLE1BQU0sQ0FBQyxlQUNQLEVBQUUsQ0FBQyxXQUFXLFFBQ2QsR0FBRyxDQUFDLGNBQWMsSUFBSSxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssS0FBSyxLQUFLLE1BQU0sV0FBVyxJQUN4RSxLQUFLLENBQUM7SUFFVCxNQUFNLGFBQWEsQ0FBQyxjQUFjLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztNQUM1QyxNQUFNLFdBQVcsRUFBRSxPQUFPLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRTtNQUNoRCxPQUFPLFNBQVMsSUFBSSxDQUFDLENBQUM7UUFDcEIsSUFBSTtVQUNGLE1BQU0sSUFBSSxJQUFJLElBQUksR0FBRyxRQUFRLENBQUMsV0FBVztVQUN6QyxPQUFPLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxLQUFlLEVBQUUsUUFBUSxDQUFDLEdBQUcsV0FBVztRQUNsRSxFQUFFLE9BQU07VUFBRSxPQUFPO1FBQU87TUFDMUI7SUFDRixHQUFHLE1BQU07SUFFVCxJQUFJLGNBQWMsVUFBVTtNQUMxQixRQUFRLEdBQUcsQ0FBQyxDQUFDLHFEQUFxRCxFQUFFLFdBQVcsSUFBSSxFQUFFLFNBQVMsQ0FBQztNQUMvRixPQUFPO1FBQ0wsU0FBUztRQUNULFFBQVE7UUFDUixTQUFTLENBQUMsNEJBQTRCLEVBQUUsU0FBUyxvQkFBb0IsQ0FBQztNQUN4RTtJQUNGO0VBQ0Y7RUFFQSxrQ0FBa0M7RUFDbEMsSUFBSSxPQUFPLGVBQWUsSUFBSSxLQUFLLE1BQU0sSUFBSSxJQUFJO0lBQy9DLElBQUk7TUFDRixNQUFNLGVBQWUsQ0FBQzs7OzhKQUdrSSxDQUFDO01BRXpKLE1BQU0sU0FBUyxNQUFNLGFBQWEsY0FBYyxLQUFLLFNBQVMsQ0FBQyxHQUFHO01BQ2xFLElBQUksUUFBUTtRQUNWLE1BQU0sWUFBWSxPQUFPLEtBQUssQ0FBQztRQUMvQixJQUFJLFdBQVc7VUFDYixNQUFNLFNBQVMsS0FBSyxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUU7VUFDdEMsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLENBQUMsT0FBTyxVQUFVLElBQUksQ0FBQyxLQUFLLE1BQU07WUFDN0QsUUFBUSxHQUFHLENBQUMsQ0FBQyxtQ0FBbUMsRUFBRSxPQUFPLE9BQU8sQ0FBQyxhQUFhLEVBQUUsT0FBTyxVQUFVLENBQUMsU0FBUyxFQUFFLE9BQU8sTUFBTSxDQUFDLENBQUM7WUFDNUgsTUFBTSxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLElBQUksV0FBVyxDQUFDO1lBQ2xELElBQUksV0FBVyxhQUFhLFVBQVU7WUFDdEMsSUFBSSxXQUFXLFNBQVM7Y0FDdEIsT0FBTztnQkFBRSxTQUFTO2dCQUFPLFFBQVE7Z0JBQWUsU0FBUztjQUFnRDtZQUMzRztVQUNGO1FBQ0Y7TUFDRjtJQUNGLEVBQUUsT0FBTyxPQUFPO01BQ2QsUUFBUSxJQUFJLENBQUMsNkNBQTZDO0lBQzVEO0VBQ0Y7RUFFQSxPQUFPO0FBQ1Q7QUFFQSw4REFBOEQ7QUFDOUQsTUFBTSwwQkFBMEI7QUFFaEMsZUFBZSxhQUFhLFlBQW9CLEVBQUUsV0FBbUI7RUFDbkUsTUFBTSxnQkFBZ0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0VBQ25DLElBQUksQ0FBQyxlQUFlO0lBQ2xCLFFBQVEsSUFBSSxDQUFDO0lBQ2IsT0FBTztFQUNUO0VBRUEsTUFBTSxTQUFTLENBQUMsbURBQW1ELEVBQUUsd0JBQXdCLG9CQUFvQixDQUFDO0VBRWxILE1BQU0sV0FBVyxNQUFNLE1BQU0sUUFBUTtJQUNuQyxRQUFRO0lBQ1IsU0FBUztNQUNQLGdCQUFnQjtNQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO0lBQzVDO0lBQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztNQUNuQixPQUFPO01BQ1AsVUFBVTtRQUNSO1VBQUUsTUFBTTtVQUFVLFNBQVM7UUFBYTtRQUN4QztVQUFFLE1BQU07VUFBUSxTQUFTO1FBQVk7T0FDdEM7TUFDRCxhQUFhO01BQ2IsWUFBWTtJQUNkO0VBQ0Y7RUFFQSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7SUFDaEIsUUFBUSxJQUFJLENBQUMsQ0FBQyxvQ0FBb0MsRUFBRSxTQUFTLE1BQU0sQ0FBQyxDQUFDO0lBQ3JFLE9BQU87RUFDVDtFQUVBLE1BQU0sT0FBTyxNQUFNLFNBQVMsSUFBSTtFQUNoQyxPQUFPLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRSxFQUFFLFNBQVMsV0FBVztBQUNoRDtBQUVBLDhEQUE4RDtBQUM5RCxlQUFlLGdCQUNiLFdBQWdDLEVBQ2hDLElBQVksRUFDWixLQUFlLEVBQ2YsU0FBK0I7RUFFL0IsTUFBTSxXQUFXLFdBQVcsQ0FBQyxnQkFBZ0I7RUFDN0MsSUFBSSxDQUFDLFVBQVUsU0FBUztFQUV4QixNQUFNLFlBQVksU0FBUyxlQUFlLElBQUk7RUFDOUMsSUFBSSxLQUFLLE1BQU0sR0FBRyxXQUFXO0VBRTdCLElBQUk7SUFDRixNQUFNLGVBQWUsQ0FBQzs7Ozs7Ozs7O2dLQVNzSSxDQUFDO0lBRTdKLE1BQU0sU0FBUyxNQUFNLGFBQWEsY0FBYyxLQUFLLFNBQVMsQ0FBQyxHQUFHO0lBQ2xFLElBQUksQ0FBQyxRQUFRO0lBRWIsTUFBTSxZQUFZLE9BQU8sS0FBSyxDQUFDO0lBQy9CLElBQUksV0FBVztNQUNiLE1BQU0sU0FBUyxLQUFLLEtBQUssQ0FBQyxTQUFTLENBQUMsRUFBRTtNQUN0QyxNQUFNLFlBQVksU0FBUyxvQkFBb0IsSUFBSTtNQUNuRCxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsQ0FBQyxPQUFPLFVBQVUsSUFBSSxDQUFDLEtBQUssV0FBVztRQUNsRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDRDQUE0QyxFQUFFLE9BQU8sUUFBUSxDQUFDLGFBQWEsRUFBRSxPQUFPLFVBQVUsQ0FBQyxTQUFTLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQztRQUN0SSxNQUFNLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxPQUFPLFFBQVEsSUFBSSxRQUFRLENBQUM7UUFDN0MsVUFBVTtNQUNaO0lBQ0Y7RUFDRixFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsSUFBSSxDQUFDLGtEQUFrRDtFQUMvRCx1Q0FBdUM7RUFDekM7QUFDRjtBQUVBLDhEQUE4RDtBQUM5RCxlQUFlLFlBQ2IsV0FBZ0MsRUFDaEMsSUFBWSxFQUNaLEtBQWUsRUFDZixTQUErQjtFQUUvQixNQUFNLFdBQVcsV0FBVyxDQUFDLGdCQUFnQjtFQUM3QyxJQUFJLENBQUMsVUFBVSxXQUFXLENBQUMsVUFBVSxnQkFBZ0I7RUFDckQsSUFBSSxLQUFLLE1BQU0sR0FBRyxJQUFJO0VBRXRCLElBQUk7SUFDRixNQUFNLGVBQWUsQ0FBQzs7OzsrRkFJcUUsQ0FBQztJQUU1RixNQUFNLFNBQVMsTUFBTSxhQUFhLGNBQWMsS0FBSyxTQUFTLENBQUMsR0FBRztJQUNsRSxJQUFJLENBQUMsUUFBUTtJQUViLE1BQU0sWUFBWSxPQUFPLEtBQUssQ0FBQztJQUMvQixJQUFJLFdBQVc7TUFDYixNQUFNLFNBQVMsS0FBSyxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUU7TUFDdEMsSUFBSSxPQUFPLElBQUksS0FBSyxRQUFRLENBQUMsT0FBTyxVQUFVLElBQUksQ0FBQyxLQUFLLE1BQU07UUFDNUQsUUFBUSxHQUFHLENBQUMsQ0FBQyx3Q0FBd0MsRUFBRSxPQUFPLE1BQU0sQ0FBQyxDQUFDO1FBQ3RFLE1BQU0sSUFBSSxDQUFDO1FBQ1gsVUFBVTtNQUNaO0lBQ0Y7RUFDRixFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsSUFBSSxDQUFDLDhDQUE4QztFQUM3RDtBQUNGO0FBRUEsK0RBQStEO0FBQy9ELGVBQWUsZUFDYixXQUFnQyxFQUNoQyxJQUFZLEVBQ1osS0FBZSxFQUNmLFNBQStCO0VBRS9CLE1BQU0sV0FBVyxXQUFXLENBQUMsZ0JBQWdCO0VBQzdDLElBQUksQ0FBQyxVQUFVLFdBQVcsQ0FBQyxVQUFVLGVBQWU7RUFDcEQsSUFBSSxLQUFLLE1BQU0sR0FBRyxJQUFJO0VBRXRCLElBQUk7SUFDRixNQUFNLGVBQWUsQ0FBQzs7OzsrRUFJcUQsQ0FBQztJQUU1RSxNQUFNLFNBQVMsTUFBTSxhQUFhLGNBQWMsS0FBSyxTQUFTLENBQUMsR0FBRztJQUNsRSxJQUFJLENBQUMsUUFBUTtJQUViLE1BQU0sWUFBWSxPQUFPLEtBQUssQ0FBQztJQUMvQixJQUFJLFdBQVc7TUFDYixNQUFNLFNBQVMsS0FBSyxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUU7TUFDdEMsSUFBSSxPQUFPLFdBQVcsS0FBSyxNQUFNO1FBQy9CLFFBQVEsR0FBRyxDQUFDLENBQUMsc0NBQXNDLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQztRQUNwRSxNQUFNLElBQUksQ0FBQztNQUNYLHdDQUF3QztNQUMxQztJQUNGO0VBQ0YsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLElBQUksQ0FBQyxpREFBaUQ7RUFDaEU7QUFDRiJ9
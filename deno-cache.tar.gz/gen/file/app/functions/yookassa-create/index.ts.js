import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// YooKassa configuration - ADD YOUR KEYS HERE
const YOOKASSA_SHOP_ID = Deno.env.get("YOOKASSA_SHOP_ID") || "";
const YOOKASSA_SECRET_KEY = Deno.env.get("YOOKASSA_SECRET_KEY") || "";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Необходима авторизация");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      throw new Error("Неверный токен авторизации");
    }
    const { amount, description, return_url } = await req.json();
    if (!amount || amount < 1) {
      throw new Error("Сумма должна быть больше 0");
    }
    // Create payment record
    const { data: payment, error: paymentError } = await supabase.from("payments").insert({
      user_id: user.id,
      amount: amount,
      currency: "RUB",
      status: "pending",
      payment_system: "yookassa",
      description: description || `Пополнение баланса на ${amount} ₽`
    }).select().single();
    if (paymentError) {
      throw new Error("Ошибка создания платежа: " + paymentError.message);
    }
    // Create YooKassa payment
    const idempotenceKey = crypto.randomUUID();
    const yooKassaPayment = {
      amount: {
        value: amount.toFixed(2),
        currency: "RUB"
      },
      capture: true,
      confirmation: {
        type: "redirect",
        return_url: return_url || `${req.headers.get("origin")}/profile?payment=success`
      },
      description: description || `Пополнение баланса на ${amount} ₽`,
      metadata: {
        payment_id: payment.id,
        user_id: user.id
      }
    };
    const response = await fetch("https://api.yookassa.ru/v3/payments", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Idempotence-Key": idempotenceKey,
        "Authorization": `Basic ${btoa(`${YOOKASSA_SHOP_ID}:${YOOKASSA_SECRET_KEY}`)}`
      },
      body: JSON.stringify(yooKassaPayment)
    });
    if (!response.ok) {
      const error = await response.text();
      console.error("YooKassa API error:", error);
      throw new Error("Ошибка создания платежа в YooKassa");
    }
    const yooKassaResponse = await response.json();
    // Update payment with external ID
    await supabase.from("payments").update({
      external_id: yooKassaResponse.id,
      metadata: yooKassaResponse
    }).eq("id", payment.id);
    return new Response(JSON.stringify({
      success: true,
      payment_id: payment.id,
      payment_url: yooKassaResponse.confirmation.confirmation_url
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 200
    });
  } catch (error) {
    console.error("YooKassa create error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 400
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy95b29rYXNzYS1jcmVhdGUvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTY4LjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG4vLyBZb29LYXNzYSBjb25maWd1cmF0aW9uIC0gQUREIFlPVVIgS0VZUyBIRVJFXG5jb25zdCBZT09LQVNTQV9TSE9QX0lEID0gRGVuby5lbnYuZ2V0KFwiWU9PS0FTU0FfU0hPUF9JRFwiKSB8fCBcIlwiO1xuY29uc3QgWU9PS0FTU0FfU0VDUkVUX0tFWSA9IERlbm8uZW52LmdldChcIllPT0tBU1NBX1NFQ1JFVF9LRVlcIikgfHwgXCJcIjtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtdC+0LHRhdC+0LTQuNC80LAg0LDQstGC0L7RgNC40LfQsNGG0LjRj1wiKTtcbiAgICB9XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IGF1dGhFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKHRva2VuKTtcbiAgICBcbiAgICBpZiAoYXV0aEVycm9yIHx8ICF1c2VyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC10LLQtdGA0L3Ri9C5INGC0L7QutC10L0g0LDQstGC0L7RgNC40LfQsNGG0LjQuFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCB7IGFtb3VudCwgZGVzY3JpcHRpb24sIHJldHVybl91cmwgfSA9IGF3YWl0IHJlcS5qc29uKCk7XG5cbiAgICBpZiAoIWFtb3VudCB8fCBhbW91bnQgPCAxKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCLQodGD0LzQvNCwINC00L7Qu9C20L3QsCDQsdGL0YLRjCDQsdC+0LvRjNGI0LUgMFwiKTtcbiAgICB9XG5cbiAgICAvLyBDcmVhdGUgcGF5bWVudCByZWNvcmRcbiAgICBjb25zdCB7IGRhdGE6IHBheW1lbnQsIGVycm9yOiBwYXltZW50RXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInBheW1lbnRzXCIpXG4gICAgICAuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogdXNlci5pZCxcbiAgICAgICAgYW1vdW50OiBhbW91bnQsXG4gICAgICAgIGN1cnJlbmN5OiBcIlJVQlwiLFxuICAgICAgICBzdGF0dXM6IFwicGVuZGluZ1wiLFxuICAgICAgICBwYXltZW50X3N5c3RlbTogXCJ5b29rYXNzYVwiLFxuICAgICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24gfHwgYNCf0L7Qv9C+0LvQvdC10L3QuNC1INCx0LDQu9Cw0L3RgdCwINC90LAgJHthbW91bnR9IOKCvWAsXG4gICAgICB9KVxuICAgICAgLnNlbGVjdCgpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAocGF5bWVudEVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCLQntGI0LjQsdC60LAg0YHQvtC30LTQsNC90LjRjyDQv9C70LDRgtC10LbQsDogXCIgKyBwYXltZW50RXJyb3IubWVzc2FnZSk7XG4gICAgfVxuXG4gICAgLy8gQ3JlYXRlIFlvb0thc3NhIHBheW1lbnRcbiAgICBjb25zdCBpZGVtcG90ZW5jZUtleSA9IGNyeXB0by5yYW5kb21VVUlEKCk7XG4gICAgXG4gICAgY29uc3QgeW9vS2Fzc2FQYXltZW50ID0ge1xuICAgICAgYW1vdW50OiB7XG4gICAgICAgIHZhbHVlOiBhbW91bnQudG9GaXhlZCgyKSxcbiAgICAgICAgY3VycmVuY3k6IFwiUlVCXCIsXG4gICAgICB9LFxuICAgICAgY2FwdHVyZTogdHJ1ZSxcbiAgICAgIGNvbmZpcm1hdGlvbjoge1xuICAgICAgICB0eXBlOiBcInJlZGlyZWN0XCIsXG4gICAgICAgIHJldHVybl91cmw6IHJldHVybl91cmwgfHwgYCR7cmVxLmhlYWRlcnMuZ2V0KFwib3JpZ2luXCIpfS9wcm9maWxlP3BheW1lbnQ9c3VjY2Vzc2AsXG4gICAgICB9LFxuICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uIHx8IGDQn9C+0L/QvtC70L3QtdC90LjQtSDQsdCw0LvQsNC90YHQsCDQvdCwICR7YW1vdW50fSDigr1gLFxuICAgICAgbWV0YWRhdGE6IHtcbiAgICAgICAgcGF5bWVudF9pZDogcGF5bWVudC5pZCxcbiAgICAgICAgdXNlcl9pZDogdXNlci5pZCxcbiAgICAgIH0sXG4gICAgfTtcblxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXCJodHRwczovL2FwaS55b29rYXNzYS5ydS92My9wYXltZW50c1wiLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJJZGVtcG90ZW5jZS1LZXlcIjogaWRlbXBvdGVuY2VLZXksXG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmFzaWMgJHtidG9hKGAke1lPT0tBU1NBX1NIT1BfSUR9OiR7WU9PS0FTU0FfU0VDUkVUX0tFWX1gKX1gLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHlvb0thc3NhUGF5bWVudCksXG4gICAgfSk7XG5cbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICBjb25zdCBlcnJvciA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJZb29LYXNzYSBBUEkgZXJyb3I6XCIsIGVycm9yKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCe0YjQuNCx0LrQsCDRgdC+0LfQtNCw0L3QuNGPINC/0LvQsNGC0LXQttCwINCyIFlvb0thc3NhXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHlvb0thc3NhUmVzcG9uc2UgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG5cbiAgICAvLyBVcGRhdGUgcGF5bWVudCB3aXRoIGV4dGVybmFsIElEXG4gICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicGF5bWVudHNcIilcbiAgICAgIC51cGRhdGUoeyBcbiAgICAgICAgZXh0ZXJuYWxfaWQ6IHlvb0thc3NhUmVzcG9uc2UuaWQsXG4gICAgICAgIG1ldGFkYXRhOiB5b29LYXNzYVJlc3BvbnNlLFxuICAgICAgfSlcbiAgICAgIC5lcShcImlkXCIsIHBheW1lbnQuaWQpO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgcGF5bWVudF9pZDogcGF5bWVudC5pZCxcbiAgICAgICAgcGF5bWVudF91cmw6IHlvb0thc3NhUmVzcG9uc2UuY29uZmlybWF0aW9uLmNvbmZpcm1hdGlvbl91cmwsXG4gICAgICB9KSxcbiAgICAgIHtcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgICAgc3RhdHVzOiAyMDAsXG4gICAgICB9XG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICBjb25zb2xlLmVycm9yKFwiWW9vS2Fzc2EgY3JlYXRlIGVycm9yOlwiLCBlcnJvcik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IG1lc3NhZ2UgfSksXG4gICAgICB7XG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICAgIHN0YXR1czogNDAwLFxuICAgICAgfVxuICAgICk7XG4gIH1cbn0pOyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsOENBQThDO0FBQzlDLE1BQU0sbUJBQW1CLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUI7QUFDN0QsTUFBTSxzQkFBc0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLDBCQUEwQjtBQUVuRSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVk7TUFDZixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sUUFBUSxXQUFXLE9BQU8sQ0FBQyxXQUFXO0lBQzVDLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLFNBQVMsSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUV6RSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLEdBQUcsTUFBTSxJQUFJLElBQUk7SUFFMUQsSUFBSSxDQUFDLFVBQVUsU0FBUyxHQUFHO01BQ3pCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsd0JBQXdCO0lBQ3hCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbEQsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO01BQ04sU0FBUyxLQUFLLEVBQUU7TUFDaEIsUUFBUTtNQUNSLFVBQVU7TUFDVixRQUFRO01BQ1IsZ0JBQWdCO01BQ2hCLGFBQWEsZUFBZSxDQUFDLHNCQUFzQixFQUFFLE9BQU8sRUFBRSxDQUFDO0lBQ2pFLEdBQ0MsTUFBTSxHQUNOLE1BQU07SUFFVCxJQUFJLGNBQWM7TUFDaEIsTUFBTSxJQUFJLE1BQU0sOEJBQThCLGFBQWEsT0FBTztJQUNwRTtJQUVBLDBCQUEwQjtJQUMxQixNQUFNLGlCQUFpQixPQUFPLFVBQVU7SUFFeEMsTUFBTSxrQkFBa0I7TUFDdEIsUUFBUTtRQUNOLE9BQU8sT0FBTyxPQUFPLENBQUM7UUFDdEIsVUFBVTtNQUNaO01BQ0EsU0FBUztNQUNULGNBQWM7UUFDWixNQUFNO1FBQ04sWUFBWSxjQUFjLENBQUMsRUFBRSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSx3QkFBd0IsQ0FBQztNQUNsRjtNQUNBLGFBQWEsZUFBZSxDQUFDLHNCQUFzQixFQUFFLE9BQU8sRUFBRSxDQUFDO01BQy9ELFVBQVU7UUFDUixZQUFZLFFBQVEsRUFBRTtRQUN0QixTQUFTLEtBQUssRUFBRTtNQUNsQjtJQUNGO0lBRUEsTUFBTSxXQUFXLE1BQU0sTUFBTSx1Q0FBdUM7TUFDbEUsUUFBUTtNQUNSLFNBQVM7UUFDUCxnQkFBZ0I7UUFDaEIsbUJBQW1CO1FBQ25CLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRSxpQkFBaUIsQ0FBQyxFQUFFLG9CQUFvQixDQUFDLEVBQUUsQ0FBQztNQUNoRjtNQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7SUFDdkI7SUFFQSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7TUFDaEIsTUFBTSxRQUFRLE1BQU0sU0FBUyxJQUFJO01BQ2pDLFFBQVEsS0FBSyxDQUFDLHVCQUF1QjtNQUNyQyxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxJQUFJO0lBRTVDLGtDQUFrQztJQUNsQyxNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO01BQ04sYUFBYSxpQkFBaUIsRUFBRTtNQUNoQyxVQUFVO0lBQ1osR0FDQyxFQUFFLENBQUMsTUFBTSxRQUFRLEVBQUU7SUFFdEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsWUFBWSxRQUFRLEVBQUU7TUFDdEIsYUFBYSxpQkFBaUIsWUFBWSxDQUFDLGdCQUFnQjtJQUM3RCxJQUNBO01BQ0UsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtNQUM5RCxRQUFRO0lBQ1Y7RUFFSixFQUFFLE9BQU8sT0FBZ0I7SUFDdkIsUUFBUSxLQUFLLENBQUMsMEJBQTBCO0lBQ3hDLE1BQU0sVUFBVSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUN6RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBUSxJQUNoQztNQUNFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7TUFDOUQsUUFBUTtJQUNWO0VBRUo7QUFDRiJ9
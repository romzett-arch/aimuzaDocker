import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Poll for lyrics result
async function pollLyricsResult(taskId, apiKey, maxAttempts = 30) {
  for(let i = 0; i < maxAttempts; i++){
    await new Promise((resolve)=>setTimeout(resolve, 2000)); // Wait 2 seconds between polls
    try {
      const response = await fetch(`https://api.sunoapi.org/api/v1/lyrics/record-info?taskId=${taskId}`, {
        headers: {
          "Authorization": `Bearer ${apiKey}`
        }
      });
      const result = await response.json();
      console.log(`Poll attempt ${i + 1}:`, result);
      if (result.code === 200 && result.data?.status === "SUCCESS") {
        // API returns an array of results in result.data.response.data
        const lyricsData = result.data.response?.data;
        if (lyricsData && lyricsData.length > 0) {
          return {
            text: lyricsData[0].text || "",
            title: lyricsData[0].title || ""
          };
        }
        // Fallback to direct fields if available
        return {
          text: result.data.text || "",
          title: result.data.title || ""
        };
      }
      if (result.data?.status === "FAILED") {
        throw new Error("Lyrics generation failed");
      }
    } catch (error) {
      console.error("Poll error:", error);
    }
  }
  return null;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    // CRITICAL: Authenticate user from token
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "Необходима авторизация"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
    // Verify JWT and get authenticated user using getUser (works with modern Supabase)
    const token = authHeader.replace("Bearer ", "");
    const { data: { user: authUser }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !authUser?.id) {
      console.error("Auth error:", authError);
      return new Response(JSON.stringify({
        error: "Неверный токен авторизации"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Use authenticated user ID, NOT from request body
    const user_id = authUser.id;
    const { prompt } = await req.json();
    console.log("Generate lyrics request:", {
      prompt,
      user_id
    });
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    if (!SUNO_API_KEY) {
      throw new Error("SUNO_API_KEY not configured");
    }
    // Get service price
    const { data: service } = await supabase.from("addon_services").select("price_rub").eq("name", "generate_lyrics").maybeSingle();
    const price = service?.price_rub || 4;
    // Check user balance
    const { data: profile } = await supabase.from("profiles").select("balance").eq("user_id", user_id).maybeSingle();
    if (!profile || (profile.balance || 0) < price) {
      throw new Error("Недостаточно средств на балансе");
    }
    // Deduct balance
    const newBalance = (profile.balance || 0) - price;
    await supabase.from("profiles").update({
      balance: newBalance
    }).eq("user_id", user_id);
    // Log transaction
    await supabase.from("balance_transactions").insert({
      user_id: user_id,
      amount: -price,
      balance_after: newBalance,
      type: "lyrics_gen",
      description: "Генерация текста (Suno)"
    });
    // Call Suno API to generate lyrics
    // Note: callBackUrl is required by API, but we'll poll for results
    const callbackUrl = `${Deno.env.get("SUPABASE_URL")}/functions/v1/lyrics-callback`;
    const response = await fetch("https://api.sunoapi.org/api/v1/lyrics", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify({
        prompt,
        callBackUrl: callbackUrl
      })
    });
    const result = await response.json();
    console.log("Suno Lyrics API response:", result);
    if (result.code !== 200) {
      // Refund on failure
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user_id);
      throw new Error(result.msg || "Failed to generate lyrics");
    }
    const taskId = result.data?.taskId;
    if (!taskId) {
      // Refund on failure
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user_id);
      throw new Error("No taskId returned from API");
    }
    // Poll for result
    const lyricsResult = await pollLyricsResult(taskId, SUNO_API_KEY);
    if (!lyricsResult) {
      // Refund on timeout
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user_id);
      throw new Error("Timeout waiting for lyrics generation");
    }
    // Save to history
    await supabase.from("generated_lyrics").insert({
      user_id: user_id,
      prompt: prompt,
      lyrics: lyricsResult.text,
      title: lyricsResult.title || null
    });
    return new Response(JSON.stringify({
      success: true,
      lyrics: lyricsResult.text,
      title: lyricsResult.title,
      message: "Текст успешно сгенерирован"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in generate-lyrics:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9nZW5lcmF0ZS1seXJpY3MvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTY4LjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG4vLyBQb2xsIGZvciBseXJpY3MgcmVzdWx0XG5hc3luYyBmdW5jdGlvbiBwb2xsTHlyaWNzUmVzdWx0KHRhc2tJZDogc3RyaW5nLCBhcGlLZXk6IHN0cmluZywgbWF4QXR0ZW1wdHMgPSAzMCk6IFByb21pc2U8eyB0ZXh0OiBzdHJpbmc7IHRpdGxlOiBzdHJpbmcgfSB8IG51bGw+IHtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXhBdHRlbXB0czsgaSsrKSB7XG4gICAgYXdhaXQgbmV3IFByb21pc2UocmVzb2x2ZSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIDIwMDApKTsgLy8gV2FpdCAyIHNlY29uZHMgYmV0d2VlbiBwb2xsc1xuICAgIFxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGBodHRwczovL2FwaS5zdW5vYXBpLm9yZy9hcGkvdjEvbHlyaWNzL3JlY29yZC1pbmZvP3Rhc2tJZD0ke3Rhc2tJZH1gLCB7XG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke2FwaUtleX1gLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgICBcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgIGNvbnNvbGUubG9nKGBQb2xsIGF0dGVtcHQgJHtpICsgMX06YCwgcmVzdWx0KTtcbiAgICAgIFxuICAgICAgaWYgKHJlc3VsdC5jb2RlID09PSAyMDAgJiYgcmVzdWx0LmRhdGE/LnN0YXR1cyA9PT0gXCJTVUNDRVNTXCIpIHtcbiAgICAgICAgLy8gQVBJIHJldHVybnMgYW4gYXJyYXkgb2YgcmVzdWx0cyBpbiByZXN1bHQuZGF0YS5yZXNwb25zZS5kYXRhXG4gICAgICAgIGNvbnN0IGx5cmljc0RhdGEgPSByZXN1bHQuZGF0YS5yZXNwb25zZT8uZGF0YTtcbiAgICAgICAgaWYgKGx5cmljc0RhdGEgJiYgbHlyaWNzRGF0YS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHRleHQ6IGx5cmljc0RhdGFbMF0udGV4dCB8fCBcIlwiLFxuICAgICAgICAgICAgdGl0bGU6IGx5cmljc0RhdGFbMF0udGl0bGUgfHwgXCJcIixcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIC8vIEZhbGxiYWNrIHRvIGRpcmVjdCBmaWVsZHMgaWYgYXZhaWxhYmxlXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdGV4dDogcmVzdWx0LmRhdGEudGV4dCB8fCBcIlwiLFxuICAgICAgICAgIHRpdGxlOiByZXN1bHQuZGF0YS50aXRsZSB8fCBcIlwiLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgXG4gICAgICBpZiAocmVzdWx0LmRhdGE/LnN0YXR1cyA9PT0gXCJGQUlMRURcIikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJMeXJpY3MgZ2VuZXJhdGlvbiBmYWlsZWRcIik7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJQb2xsIGVycm9yOlwiLCBlcnJvcik7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgLy8gQ1JJVElDQUw6IEF1dGhlbnRpY2F0ZSB1c2VyIGZyb20gdG9rZW5cbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXI/LnN0YXJ0c1dpdGgoXCJCZWFyZXIgXCIpKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LXQvtCx0YXQvtC00LjQvNCwINCw0LLRgtC+0YDQuNC30LDRhtC40Y9cIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpISxcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhXG4gICAgKTtcblxuICAgIC8vIFZlcmlmeSBKV1QgYW5kIGdldCBhdXRoZW50aWNhdGVkIHVzZXIgdXNpbmcgZ2V0VXNlciAod29ya3Mgd2l0aCBtb2Rlcm4gU3VwYWJhc2UpXG4gICAgY29uc3QgdG9rZW4gPSBhdXRoSGVhZGVyLnJlcGxhY2UoXCJCZWFyZXIgXCIsIFwiXCIpO1xuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyOiBhdXRoVXNlciB9LCBlcnJvcjogYXV0aEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIodG9rZW4pO1xuICAgIFxuICAgIGlmIChhdXRoRXJyb3IgfHwgIWF1dGhVc2VyPy5pZCkge1xuICAgICAgY29uc29sZS5lcnJvcihcIkF1dGggZXJyb3I6XCIsIGF1dGhFcnJvcik7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LXQstC10YDQvdGL0Lkg0YLQvtC60LXQvSDQsNCy0YLQvtGA0LjQt9Cw0YbQuNC4XCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBVc2UgYXV0aGVudGljYXRlZCB1c2VyIElELCBOT1QgZnJvbSByZXF1ZXN0IGJvZHlcbiAgICBjb25zdCB1c2VyX2lkID0gYXV0aFVzZXIuaWQ7XG4gICAgXG4gICAgY29uc3QgeyBwcm9tcHQgfSA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgXG4gICAgY29uc29sZS5sb2coXCJHZW5lcmF0ZSBseXJpY3MgcmVxdWVzdDpcIiwgeyBwcm9tcHQsIHVzZXJfaWQgfSk7XG5cbiAgICBjb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG4gICAgaWYgKCFTVU5PX0FQSV9LRVkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlNVTk9fQVBJX0tFWSBub3QgY29uZmlndXJlZFwiKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgc2VydmljZSBwcmljZVxuICAgIGNvbnN0IHsgZGF0YTogc2VydmljZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiYWRkb25fc2VydmljZXNcIilcbiAgICAgIC5zZWxlY3QoXCJwcmljZV9ydWJcIilcbiAgICAgIC5lcShcIm5hbWVcIiwgXCJnZW5lcmF0ZV9seXJpY3NcIilcbiAgICAgIC5tYXliZVNpbmdsZSgpO1xuXG4gICAgY29uc3QgcHJpY2UgPSBzZXJ2aWNlPy5wcmljZV9ydWIgfHwgNDtcblxuICAgIC8vIENoZWNrIHVzZXIgYmFsYW5jZVxuICAgIGNvbnN0IHsgZGF0YTogcHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJfaWQpXG4gICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgIGlmICghcHJvZmlsZSB8fCAocHJvZmlsZS5iYWxhbmNlIHx8IDApIDwgcHJpY2UpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCd0LXQtNC+0YHRgtCw0YLQvtGH0L3QviDRgdGA0LXQtNGB0YLQsiDQvdCwINCx0LDQu9Cw0L3RgdC1XCIpO1xuICAgIH1cblxuICAgIC8vIERlZHVjdCBiYWxhbmNlXG4gICAgY29uc3QgbmV3QmFsYW5jZSA9IChwcm9maWxlLmJhbGFuY2UgfHwgMCkgLSBwcmljZTtcbiAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IG5ld0JhbGFuY2UgfSlcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcl9pZCk7XG5cbiAgICAvLyBMb2cgdHJhbnNhY3Rpb25cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwiYmFsYW5jZV90cmFuc2FjdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgIHVzZXJfaWQ6IHVzZXJfaWQsXG4gICAgICBhbW91bnQ6IC1wcmljZSxcbiAgICAgIGJhbGFuY2VfYWZ0ZXI6IG5ld0JhbGFuY2UsXG4gICAgICB0eXBlOiBcImx5cmljc19nZW5cIixcbiAgICAgIGRlc2NyaXB0aW9uOiBcItCT0LXQvdC10YDQsNGG0LjRjyDRgtC10LrRgdGC0LAgKFN1bm8pXCIsXG4gICAgfSk7XG5cbiAgICAvLyBDYWxsIFN1bm8gQVBJIHRvIGdlbmVyYXRlIGx5cmljc1xuICAgIC8vIE5vdGU6IGNhbGxCYWNrVXJsIGlzIHJlcXVpcmVkIGJ5IEFQSSwgYnV0IHdlJ2xsIHBvbGwgZm9yIHJlc3VsdHNcbiAgICBjb25zdCBjYWxsYmFja1VybCA9IGAke0Rlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKX0vZnVuY3Rpb25zL3YxL2x5cmljcy1jYWxsYmFja2A7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcImh0dHBzOi8vYXBpLnN1bm9hcGkub3JnL2FwaS92MS9seXJpY3NcIiwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBwcm9tcHQsXG4gICAgICAgIGNhbGxCYWNrVXJsOiBjYWxsYmFja1VybCxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKFwiU3VubyBMeXJpY3MgQVBJIHJlc3BvbnNlOlwiLCByZXN1bHQpO1xuXG4gICAgaWYgKHJlc3VsdC5jb2RlICE9PSAyMDApIHtcbiAgICAgIC8vIFJlZnVuZCBvbiBmYWlsdXJlXG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBwcm9maWxlLmJhbGFuY2UgfSlcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyX2lkKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihyZXN1bHQubXNnIHx8IFwiRmFpbGVkIHRvIGdlbmVyYXRlIGx5cmljc1wiKTtcbiAgICB9XG5cbiAgICBjb25zdCB0YXNrSWQgPSByZXN1bHQuZGF0YT8udGFza0lkO1xuICAgIGlmICghdGFza0lkKSB7XG4gICAgICAvLyBSZWZ1bmQgb24gZmFpbHVyZVxuICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogcHJvZmlsZS5iYWxhbmNlIH0pXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcl9pZCk7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyB0YXNrSWQgcmV0dXJuZWQgZnJvbSBBUElcIik7XG4gICAgfVxuXG4gICAgLy8gUG9sbCBmb3IgcmVzdWx0XG4gICAgY29uc3QgbHlyaWNzUmVzdWx0ID0gYXdhaXQgcG9sbEx5cmljc1Jlc3VsdCh0YXNrSWQsIFNVTk9fQVBJX0tFWSk7XG4gICAgXG4gICAgaWYgKCFseXJpY3NSZXN1bHQpIHtcbiAgICAgIC8vIFJlZnVuZCBvbiB0aW1lb3V0XG4gICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBwcm9maWxlLmJhbGFuY2UgfSlcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyX2lkKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRpbWVvdXQgd2FpdGluZyBmb3IgbHlyaWNzIGdlbmVyYXRpb25cIik7XG4gICAgfVxuXG4gICAgLy8gU2F2ZSB0byBoaXN0b3J5XG4gICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiZ2VuZXJhdGVkX2x5cmljc1wiKVxuICAgICAgLmluc2VydCh7XG4gICAgICAgIHVzZXJfaWQ6IHVzZXJfaWQsXG4gICAgICAgIHByb21wdDogcHJvbXB0LFxuICAgICAgICBseXJpY3M6IGx5cmljc1Jlc3VsdC50ZXh0LFxuICAgICAgICB0aXRsZTogbHlyaWNzUmVzdWx0LnRpdGxlIHx8IG51bGwsXG4gICAgICB9KTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgbHlyaWNzOiBseXJpY3NSZXN1bHQudGV4dCxcbiAgICAgICAgdGl0bGU6IGx5cmljc1Jlc3VsdC50aXRsZSxcbiAgICAgICAgbWVzc2FnZTogXCLQotC10LrRgdGCINGD0YHQv9C10YjQvdC+INGB0LPQtdC90LXRgNC40YDQvtCy0LDQvVwiIFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIGdlbmVyYXRlLWx5cmljczpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiVW5rbm93biBlcnJvclwiO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBtZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSx5QkFBeUI7QUFDekIsZUFBZSxpQkFBaUIsTUFBYyxFQUFFLE1BQWMsRUFBRSxjQUFjLEVBQUU7RUFDOUUsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsSUFBSztJQUNwQyxNQUFNLElBQUksUUFBUSxDQUFBLFVBQVcsV0FBVyxTQUFTLFFBQVEsK0JBQStCO0lBRXhGLElBQUk7TUFDRixNQUFNLFdBQVcsTUFBTSxNQUFNLENBQUMseURBQXlELEVBQUUsT0FBTyxDQUFDLEVBQUU7UUFDakcsU0FBUztVQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUM7UUFDckM7TUFDRjtNQUVBLE1BQU0sU0FBUyxNQUFNLFNBQVMsSUFBSTtNQUNsQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUU7TUFFdEMsSUFBSSxPQUFPLElBQUksS0FBSyxPQUFPLE9BQU8sSUFBSSxFQUFFLFdBQVcsV0FBVztRQUM1RCwrREFBK0Q7UUFDL0QsTUFBTSxhQUFhLE9BQU8sSUFBSSxDQUFDLFFBQVEsRUFBRTtRQUN6QyxJQUFJLGNBQWMsV0FBVyxNQUFNLEdBQUcsR0FBRztVQUN2QyxPQUFPO1lBQ0wsTUFBTSxVQUFVLENBQUMsRUFBRSxDQUFDLElBQUksSUFBSTtZQUM1QixPQUFPLFVBQVUsQ0FBQyxFQUFFLENBQUMsS0FBSyxJQUFJO1VBQ2hDO1FBQ0Y7UUFDQSx5Q0FBeUM7UUFDekMsT0FBTztVQUNMLE1BQU0sT0FBTyxJQUFJLENBQUMsSUFBSSxJQUFJO1VBQzFCLE9BQU8sT0FBTyxJQUFJLENBQUMsS0FBSyxJQUFJO1FBQzlCO01BQ0Y7TUFFQSxJQUFJLE9BQU8sSUFBSSxFQUFFLFdBQVcsVUFBVTtRQUNwQyxNQUFNLElBQUksTUFBTTtNQUNsQjtJQUNGLEVBQUUsT0FBTyxPQUFPO01BQ2QsUUFBUSxLQUFLLENBQUMsZUFBZTtJQUMvQjtFQUNGO0VBQ0EsT0FBTztBQUNUO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YseUNBQXlDO0lBQ3pDLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVksV0FBVyxZQUFZO01BQ3RDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF5QixJQUNqRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFdBQVcsYUFDZixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsaUJBQ2IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBR2YsbUZBQW1GO0lBQ25GLE1BQU0sUUFBUSxXQUFXLE9BQU8sQ0FBQyxXQUFXO0lBQzVDLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxRQUFRLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBRW5GLElBQUksYUFBYSxDQUFDLFVBQVUsSUFBSTtNQUM5QixRQUFRLEtBQUssQ0FBQyxlQUFlO01BQzdCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE2QixJQUNyRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxtREFBbUQ7SUFDbkQsTUFBTSxVQUFVLFNBQVMsRUFBRTtJQUUzQixNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFJLElBQUk7SUFFakMsUUFBUSxHQUFHLENBQUMsNEJBQTRCO01BQUU7TUFBUTtJQUFRO0lBRTFELE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbEMsSUFBSSxDQUFDLGNBQWM7TUFDakIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxvQkFBb0I7SUFDcEIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxTQUM3QixJQUFJLENBQUMsa0JBQ0wsTUFBTSxDQUFDLGFBQ1AsRUFBRSxDQUFDLFFBQVEsbUJBQ1gsV0FBVztJQUVkLE1BQU0sUUFBUSxTQUFTLGFBQWE7SUFFcEMscUJBQXFCO0lBQ3JCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxHQUFHLE1BQU0sU0FDN0IsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsU0FDZCxXQUFXO0lBRWQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLE9BQU8sSUFBSSxDQUFDLElBQUksT0FBTztNQUM5QyxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLGlCQUFpQjtJQUNqQixNQUFNLGFBQWEsQ0FBQyxRQUFRLE9BQU8sSUFBSSxDQUFDLElBQUk7SUFDNUMsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztNQUFFLFNBQVM7SUFBVyxHQUM3QixFQUFFLENBQUMsV0FBVztJQUVqQixrQkFBa0I7SUFDbEIsTUFBTSxTQUFTLElBQUksQ0FBQyx3QkFBd0IsTUFBTSxDQUFDO01BQ2pELFNBQVM7TUFDVCxRQUFRLENBQUM7TUFDVCxlQUFlO01BQ2YsTUFBTTtNQUNOLGFBQWE7SUFDZjtJQUVBLG1DQUFtQztJQUNuQyxtRUFBbUU7SUFDbkUsTUFBTSxjQUFjLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLDZCQUE2QixDQUFDO0lBQ2xGLE1BQU0sV0FBVyxNQUFNLE1BQU0seUNBQXlDO01BQ3BFLFFBQVE7TUFDUixTQUFTO1FBQ1AsZ0JBQWdCO1FBQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQ25CO1FBQ0EsYUFBYTtNQUNmO0lBQ0Y7SUFFQSxNQUFNLFNBQVMsTUFBTSxTQUFTLElBQUk7SUFDbEMsUUFBUSxHQUFHLENBQUMsNkJBQTZCO0lBRXpDLElBQUksT0FBTyxJQUFJLEtBQUssS0FBSztNQUN2QixvQkFBb0I7TUFDcEIsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztRQUFFLFNBQVMsUUFBUSxPQUFPO01BQUMsR0FDbEMsRUFBRSxDQUFDLFdBQVc7TUFDakIsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHLElBQUk7SUFDaEM7SUFFQSxNQUFNLFNBQVMsT0FBTyxJQUFJLEVBQUU7SUFDNUIsSUFBSSxDQUFDLFFBQVE7TUFDWCxvQkFBb0I7TUFDcEIsTUFBTSxTQUNILElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztRQUFFLFNBQVMsUUFBUSxPQUFPO01BQUMsR0FDbEMsRUFBRSxDQUFDLFdBQVc7TUFDakIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxrQkFBa0I7SUFDbEIsTUFBTSxlQUFlLE1BQU0saUJBQWlCLFFBQVE7SUFFcEQsSUFBSSxDQUFDLGNBQWM7TUFDakIsb0JBQW9CO01BQ3BCLE1BQU0sU0FDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7UUFBRSxTQUFTLFFBQVEsT0FBTztNQUFDLEdBQ2xDLEVBQUUsQ0FBQyxXQUFXO01BQ2pCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsa0JBQWtCO0lBQ2xCLE1BQU0sU0FDSCxJQUFJLENBQUMsb0JBQ0wsTUFBTSxDQUFDO01BQ04sU0FBUztNQUNULFFBQVE7TUFDUixRQUFRLGFBQWEsSUFBSTtNQUN6QixPQUFPLGFBQWEsS0FBSyxJQUFJO0lBQy9CO0lBRUYsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsUUFBUSxhQUFhLElBQUk7TUFDekIsT0FBTyxhQUFhLEtBQUs7TUFDekIsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEUsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDZCQUE2QjtJQUMzQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
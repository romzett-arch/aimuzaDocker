import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const ROBOKASSA_PASSWORD2 = Deno.env.get("ROBOKASSA_PASSWORD2") || "";
async function createMD5(str) {
  const encoder = new TextEncoder();
  const data = encoder.encode(str);
  // Use crypto.subtle for MD5 - fail securely if not available
  const hashBuffer = await crypto.subtle.digest('MD5', data).catch((error)=>{
    console.error("MD5 digest failed:", error);
    return null;
  });
  if (!hashBuffer) {
    // Fail securely - do not use weak fallback
    throw new Error("MD5 hashing is not supported in this environment. Cannot verify payment signature.");
  }
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b)=>b.toString(16).padStart(2, '0')).join('');
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Parse form data or query params
    let outSum, invId, signatureValue;
    if (req.method === "POST") {
      const formData = await req.formData().catch(()=>null);
      if (formData) {
        outSum = formData.get("OutSum")?.toString() || "";
        invId = formData.get("InvId")?.toString() || "";
        signatureValue = formData.get("SignatureValue")?.toString() || "";
      } else {
        const body = await req.json();
        outSum = body.OutSum;
        invId = body.InvId;
        signatureValue = body.SignatureValue;
      }
    } else {
      const url = new URL(req.url);
      outSum = url.searchParams.get("OutSum") || "";
      invId = url.searchParams.get("InvId") || "";
      signatureValue = url.searchParams.get("SignatureValue") || "";
    }
    console.log("Robokassa callback:", {
      outSum,
      invId,
      signatureValue
    });
    // Verify signature: OutSum:InvId:Password2
    const expectedSignature = await createMD5(`${outSum}:${invId}:${ROBOKASSA_PASSWORD2}`);
    if (signatureValue.toLowerCase() !== expectedSignature.toLowerCase()) {
      console.error("Invalid signature", {
        expected: expectedSignature,
        received: signatureValue
      });
      return new Response("bad sign", {
        status: 400
      });
    }
    // Find payment by external_id
    const { data: payment, error: findError } = await supabase.from("payments").select("*").eq("external_id", invId).eq("payment_system", "robokassa").single();
    if (findError || !payment) {
      console.error("Payment not found:", invId);
      return new Response("bad", {
        status: 404
      });
    }
    // Update payment status
    const { error: updateError } = await supabase.from("payments").update({
      status: "completed",
      updated_at: new Date().toISOString()
    }).eq("id", payment.id);
    if (updateError) {
      console.error("Error updating payment:", updateError);
      return new Response("bad", {
        status: 500
      });
    }
    // Add balance to user profile
    const { data: profile, error: profileError } = await supabase.from("profiles").select("balance").eq("user_id", payment.user_id).single();
    if (!profileError && profile) {
      const newBalance = (profile.balance || 0) + payment.amount;
      await supabase.from("profiles").update({
        balance: newBalance
      }).eq("user_id", payment.user_id);
      // Log topup transaction
      await supabase.from("balance_transactions").insert({
        user_id: payment.user_id,
        amount: payment.amount,
        balance_after: newBalance,
        type: "topup",
        description: `Пополнение баланса (Робокасса)`,
        reference_id: payment.id,
        reference_type: "payment"
      });
    }
    console.log("Payment completed:", payment.id);
    // Return OK for Robokassa
    return new Response(`OK${invId}`, {
      headers: {
        "Content-Type": "text/plain"
      },
      status: 200
    });
  } catch (error) {
    console.error("Robokassa callback error:", error);
    return new Response("bad", {
      status: 500
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9yb2Jva2Fzc2EtY2FsbGJhY2svaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTY4LjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5jb25zdCBST0JPS0FTU0FfUEFTU1dPUkQyID0gRGVuby5lbnYuZ2V0KFwiUk9CT0tBU1NBX1BBU1NXT1JEMlwiKSB8fCBcIlwiO1xuXG5hc3luYyBmdW5jdGlvbiBjcmVhdGVNRDUoc3RyOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG4gIGNvbnN0IGRhdGEgPSBlbmNvZGVyLmVuY29kZShzdHIpO1xuICBcbiAgLy8gVXNlIGNyeXB0by5zdWJ0bGUgZm9yIE1ENSAtIGZhaWwgc2VjdXJlbHkgaWYgbm90IGF2YWlsYWJsZVxuICBjb25zdCBoYXNoQnVmZmVyID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ01ENScsIGRhdGEpLmNhdGNoKChlcnJvcikgPT4ge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJNRDUgZGlnZXN0IGZhaWxlZDpcIiwgZXJyb3IpO1xuICAgIHJldHVybiBudWxsO1xuICB9KTtcbiAgXG4gIGlmICghaGFzaEJ1ZmZlcikge1xuICAgIC8vIEZhaWwgc2VjdXJlbHkgLSBkbyBub3QgdXNlIHdlYWsgZmFsbGJhY2tcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJNRDUgaGFzaGluZyBpcyBub3Qgc3VwcG9ydGVkIGluIHRoaXMgZW52aXJvbm1lbnQuIENhbm5vdCB2ZXJpZnkgcGF5bWVudCBzaWduYXR1cmUuXCIpO1xuICB9XG4gIFxuICBjb25zdCBoYXNoQXJyYXkgPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGhhc2hCdWZmZXIpKTtcbiAgcmV0dXJuIGhhc2hBcnJheS5tYXAoYiA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKS5qb2luKCcnKTtcbn1cblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIC8vIFBhcnNlIGZvcm0gZGF0YSBvciBxdWVyeSBwYXJhbXNcbiAgICBsZXQgb3V0U3VtOiBzdHJpbmcsIGludklkOiBzdHJpbmcsIHNpZ25hdHVyZVZhbHVlOiBzdHJpbmc7XG5cbiAgICBpZiAocmVxLm1ldGhvZCA9PT0gXCJQT1NUXCIpIHtcbiAgICAgIGNvbnN0IGZvcm1EYXRhID0gYXdhaXQgcmVxLmZvcm1EYXRhKCkuY2F0Y2goKCkgPT4gbnVsbCk7XG4gICAgICBpZiAoZm9ybURhdGEpIHtcbiAgICAgICAgb3V0U3VtID0gZm9ybURhdGEuZ2V0KFwiT3V0U3VtXCIpPy50b1N0cmluZygpIHx8IFwiXCI7XG4gICAgICAgIGludklkID0gZm9ybURhdGEuZ2V0KFwiSW52SWRcIik/LnRvU3RyaW5nKCkgfHwgXCJcIjtcbiAgICAgICAgc2lnbmF0dXJlVmFsdWUgPSBmb3JtRGF0YS5nZXQoXCJTaWduYXR1cmVWYWx1ZVwiKT8udG9TdHJpbmcoKSB8fCBcIlwiO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgYm9keSA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgICAgIG91dFN1bSA9IGJvZHkuT3V0U3VtO1xuICAgICAgICBpbnZJZCA9IGJvZHkuSW52SWQ7XG4gICAgICAgIHNpZ25hdHVyZVZhbHVlID0gYm9keS5TaWduYXR1cmVWYWx1ZTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgdXJsID0gbmV3IFVSTChyZXEudXJsKTtcbiAgICAgIG91dFN1bSA9IHVybC5zZWFyY2hQYXJhbXMuZ2V0KFwiT3V0U3VtXCIpIHx8IFwiXCI7XG4gICAgICBpbnZJZCA9IHVybC5zZWFyY2hQYXJhbXMuZ2V0KFwiSW52SWRcIikgfHwgXCJcIjtcbiAgICAgIHNpZ25hdHVyZVZhbHVlID0gdXJsLnNlYXJjaFBhcmFtcy5nZXQoXCJTaWduYXR1cmVWYWx1ZVwiKSB8fCBcIlwiO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKFwiUm9ib2thc3NhIGNhbGxiYWNrOlwiLCB7IG91dFN1bSwgaW52SWQsIHNpZ25hdHVyZVZhbHVlIH0pO1xuXG4gICAgLy8gVmVyaWZ5IHNpZ25hdHVyZTogT3V0U3VtOkludklkOlBhc3N3b3JkMlxuICAgIGNvbnN0IGV4cGVjdGVkU2lnbmF0dXJlID0gYXdhaXQgY3JlYXRlTUQ1KGAke291dFN1bX06JHtpbnZJZH06JHtST0JPS0FTU0FfUEFTU1dPUkQyfWApO1xuICAgIFxuICAgIGlmIChzaWduYXR1cmVWYWx1ZS50b0xvd2VyQ2FzZSgpICE9PSBleHBlY3RlZFNpZ25hdHVyZS50b0xvd2VyQ2FzZSgpKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiSW52YWxpZCBzaWduYXR1cmVcIiwgeyBleHBlY3RlZDogZXhwZWN0ZWRTaWduYXR1cmUsIHJlY2VpdmVkOiBzaWduYXR1cmVWYWx1ZSB9KTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXCJiYWQgc2lnblwiLCB7IHN0YXR1czogNDAwIH0pO1xuICAgIH1cblxuICAgIC8vIEZpbmQgcGF5bWVudCBieSBleHRlcm5hbF9pZFxuICAgIGNvbnN0IHsgZGF0YTogcGF5bWVudCwgZXJyb3I6IGZpbmRFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicGF5bWVudHNcIilcbiAgICAgIC5zZWxlY3QoXCIqXCIpXG4gICAgICAuZXEoXCJleHRlcm5hbF9pZFwiLCBpbnZJZClcbiAgICAgIC5lcShcInBheW1lbnRfc3lzdGVtXCIsIFwicm9ib2thc3NhXCIpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoZmluZEVycm9yIHx8ICFwYXltZW50KSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiUGF5bWVudCBub3QgZm91bmQ6XCIsIGludklkKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXCJiYWRcIiwgeyBzdGF0dXM6IDQwNCB9KTtcbiAgICB9XG5cbiAgICAvLyBVcGRhdGUgcGF5bWVudCBzdGF0dXNcbiAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicGF5bWVudHNcIilcbiAgICAgIC51cGRhdGUoeyBcbiAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgIH0pXG4gICAgICAuZXEoXCJpZFwiLCBwYXltZW50LmlkKTtcblxuICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHBheW1lbnQ6XCIsIHVwZGF0ZUVycm9yKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXCJiYWRcIiwgeyBzdGF0dXM6IDUwMCB9KTtcbiAgICB9XG5cbiAgICAvLyBBZGQgYmFsYW5jZSB0byB1c2VyIHByb2ZpbGVcbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUsIGVycm9yOiBwcm9maWxlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAuc2VsZWN0KFwiYmFsYW5jZVwiKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCBwYXltZW50LnVzZXJfaWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoIXByb2ZpbGVFcnJvciAmJiBwcm9maWxlKSB7XG4gICAgICBjb25zdCBuZXdCYWxhbmNlID0gKHByb2ZpbGUuYmFsYW5jZSB8fCAwKSArIHBheW1lbnQuYW1vdW50O1xuICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogbmV3QmFsYW5jZSB9KVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHBheW1lbnQudXNlcl9pZCk7XG5cbiAgICAgIC8vIExvZyB0b3B1cCB0cmFuc2FjdGlvblxuICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcImJhbGFuY2VfdHJhbnNhY3Rpb25zXCIpLmluc2VydCh7XG4gICAgICAgIHVzZXJfaWQ6IHBheW1lbnQudXNlcl9pZCxcbiAgICAgICAgYW1vdW50OiBwYXltZW50LmFtb3VudCxcbiAgICAgICAgYmFsYW5jZV9hZnRlcjogbmV3QmFsYW5jZSxcbiAgICAgICAgdHlwZTogXCJ0b3B1cFwiLFxuICAgICAgICBkZXNjcmlwdGlvbjogYNCf0L7Qv9C+0LvQvdC10L3QuNC1INCx0LDQu9Cw0L3RgdCwICjQoNC+0LHQvtC60LDRgdGB0LApYCxcbiAgICAgICAgcmVmZXJlbmNlX2lkOiBwYXltZW50LmlkLFxuICAgICAgICByZWZlcmVuY2VfdHlwZTogXCJwYXltZW50XCIsXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhcIlBheW1lbnQgY29tcGxldGVkOlwiLCBwYXltZW50LmlkKTtcblxuICAgIC8vIFJldHVybiBPSyBmb3IgUm9ib2thc3NhXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShgT0ske2ludklkfWAsIHtcbiAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJ0ZXh0L3BsYWluXCIgfSxcbiAgICAgIHN0YXR1czogMjAwLFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJSb2Jva2Fzc2EgY2FsbGJhY2sgZXJyb3I6XCIsIGVycm9yKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFwiYmFkXCIsIHsgc3RhdHVzOiA1MDAgfSk7XG4gIH1cbn0pOyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxzQkFBc0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLDBCQUEwQjtBQUVuRSxlQUFlLFVBQVUsR0FBVztFQUNsQyxNQUFNLFVBQVUsSUFBSTtFQUNwQixNQUFNLE9BQU8sUUFBUSxNQUFNLENBQUM7RUFFNUIsNkRBQTZEO0VBQzdELE1BQU0sYUFBYSxNQUFNLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLE1BQU0sS0FBSyxDQUFDLENBQUM7SUFDaEUsUUFBUSxLQUFLLENBQUMsc0JBQXNCO0lBQ3BDLE9BQU87RUFDVDtFQUVBLElBQUksQ0FBQyxZQUFZO0lBQ2YsMkNBQTJDO0lBQzNDLE1BQU0sSUFBSSxNQUFNO0VBQ2xCO0VBRUEsTUFBTSxZQUFZLE1BQU0sSUFBSSxDQUFDLElBQUksV0FBVztFQUM1QyxPQUFPLFVBQVUsR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBQ2xFO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDeEMsTUFBTSxXQUFXLGFBQWEsYUFBYTtJQUUzQyxrQ0FBa0M7SUFDbEMsSUFBSSxRQUFnQixPQUFlO0lBRW5DLElBQUksSUFBSSxNQUFNLEtBQUssUUFBUTtNQUN6QixNQUFNLFdBQVcsTUFBTSxJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBTTtNQUNsRCxJQUFJLFVBQVU7UUFDWixTQUFTLFNBQVMsR0FBRyxDQUFDLFdBQVcsY0FBYztRQUMvQyxRQUFRLFNBQVMsR0FBRyxDQUFDLFVBQVUsY0FBYztRQUM3QyxpQkFBaUIsU0FBUyxHQUFHLENBQUMsbUJBQW1CLGNBQWM7TUFDakUsT0FBTztRQUNMLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtRQUMzQixTQUFTLEtBQUssTUFBTTtRQUNwQixRQUFRLEtBQUssS0FBSztRQUNsQixpQkFBaUIsS0FBSyxjQUFjO01BQ3RDO0lBQ0YsT0FBTztNQUNMLE1BQU0sTUFBTSxJQUFJLElBQUksSUFBSSxHQUFHO01BQzNCLFNBQVMsSUFBSSxZQUFZLENBQUMsR0FBRyxDQUFDLGFBQWE7TUFDM0MsUUFBUSxJQUFJLFlBQVksQ0FBQyxHQUFHLENBQUMsWUFBWTtNQUN6QyxpQkFBaUIsSUFBSSxZQUFZLENBQUMsR0FBRyxDQUFDLHFCQUFxQjtJQUM3RDtJQUVBLFFBQVEsR0FBRyxDQUFDLHVCQUF1QjtNQUFFO01BQVE7TUFBTztJQUFlO0lBRW5FLDJDQUEyQztJQUMzQyxNQUFNLG9CQUFvQixNQUFNLFVBQVUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFLG9CQUFvQixDQUFDO0lBRXJGLElBQUksZUFBZSxXQUFXLE9BQU8sa0JBQWtCLFdBQVcsSUFBSTtNQUNwRSxRQUFRLEtBQUssQ0FBQyxxQkFBcUI7UUFBRSxVQUFVO1FBQW1CLFVBQVU7TUFBZTtNQUMzRixPQUFPLElBQUksU0FBUyxZQUFZO1FBQUUsUUFBUTtNQUFJO0lBQ2hEO0lBRUEsOEJBQThCO0lBQzlCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FDL0MsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLEtBQ1AsRUFBRSxDQUFDLGVBQWUsT0FDbEIsRUFBRSxDQUFDLGtCQUFrQixhQUNyQixNQUFNO0lBRVQsSUFBSSxhQUFhLENBQUMsU0FBUztNQUN6QixRQUFRLEtBQUssQ0FBQyxzQkFBc0I7TUFDcEMsT0FBTyxJQUFJLFNBQVMsT0FBTztRQUFFLFFBQVE7TUFBSTtJQUMzQztJQUVBLHdCQUF3QjtJQUN4QixNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLFNBQ2xDLElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztNQUNOLFFBQVE7TUFDUixZQUFZLElBQUksT0FBTyxXQUFXO0lBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sUUFBUSxFQUFFO0lBRXRCLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLDJCQUEyQjtNQUN6QyxPQUFPLElBQUksU0FBUyxPQUFPO1FBQUUsUUFBUTtNQUFJO0lBQzNDO0lBRUEsOEJBQThCO0lBQzlCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbEQsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFdBQVcsUUFBUSxPQUFPLEVBQzdCLE1BQU07SUFFVCxJQUFJLENBQUMsZ0JBQWdCLFNBQVM7TUFDNUIsTUFBTSxhQUFhLENBQUMsUUFBUSxPQUFPLElBQUksQ0FBQyxJQUFJLFFBQVEsTUFBTTtNQUMxRCxNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1FBQUUsU0FBUztNQUFXLEdBQzdCLEVBQUUsQ0FBQyxXQUFXLFFBQVEsT0FBTztNQUVoQyx3QkFBd0I7TUFDeEIsTUFBTSxTQUFTLElBQUksQ0FBQyx3QkFBd0IsTUFBTSxDQUFDO1FBQ2pELFNBQVMsUUFBUSxPQUFPO1FBQ3hCLFFBQVEsUUFBUSxNQUFNO1FBQ3RCLGVBQWU7UUFDZixNQUFNO1FBQ04sYUFBYSxDQUFDLDhCQUE4QixDQUFDO1FBQzdDLGNBQWMsUUFBUSxFQUFFO1FBQ3hCLGdCQUFnQjtNQUNsQjtJQUNGO0lBRUEsUUFBUSxHQUFHLENBQUMsc0JBQXNCLFFBQVEsRUFBRTtJQUU1QywwQkFBMEI7SUFDMUIsT0FBTyxJQUFJLFNBQVMsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUU7TUFDaEMsU0FBUztRQUFFLGdCQUFnQjtNQUFhO01BQ3hDLFFBQVE7SUFDVjtFQUNGLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsNkJBQTZCO0lBQzNDLE9BQU8sSUFBSSxTQUFTLE9BQU87TUFBRSxRQUFRO0lBQUk7RUFDM0M7QUFDRiJ9
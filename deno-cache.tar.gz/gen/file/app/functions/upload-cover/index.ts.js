import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
const FILE_UPLOAD_BASE = "https://sunoapiorg.redpandaai.co";
// Map artist names to genre/style descriptions (Suno doesn't allow artist names)
const artistToStyleMap = {
  "Drake": "moody trap hip-hop with melodic hooks",
  "The Weeknd": "dark synth-pop R&B with falsetto vocals",
  "Taylor Swift": "catchy pop-country with storytelling lyrics",
  "Ed Sheeran": "acoustic pop folk with romantic themes",
  "Billie Eilish": "dark minimalist pop with whispered vocals",
  "Ariana Grande": "powerful pop R&B with high vocals",
  "Dua Lipa": "disco-influenced dance pop",
  "Bad Bunny": "reggaeton latin trap with urban beats",
  "Post Malone": "melodic hip-hop rock fusion",
  "Kendrick Lamar": "conscious lyrical hip-hop",
  "Beyoncé": "powerful R&B pop with soulful vocals",
  "Bruno Mars": "funk pop with retro grooves",
  "Adele": "powerful ballads with soulful vocals",
  "Coldplay": "anthemic alternative rock with atmospheric synths"
};
function convertArtistToStyle(artistName) {
  if (artistToStyleMap[artistName]) {
    return artistToStyleMap[artistName];
  }
  const lowerName = artistName.toLowerCase();
  for (const [artist, style] of Object.entries(artistToStyleMap)){
    if (artist.toLowerCase() === lowerName) {
      return style;
    }
  }
  return "contemporary pop with modern production";
}
function cleanStyleForSuno(style) {
  if (!style) return "";
  let cleanedStyle = style;
  for (const artistName of Object.keys(artistToStyleMap)){
    const regex = new RegExp(`${artistName}\\s*style`, "gi");
    if (regex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(regex, convertArtistToStyle(artistName));
    }
    const standaloneRegex = new RegExp(`\\b${artistName}\\b`, "gi");
    if (standaloneRegex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(standaloneRegex, convertArtistToStyle(artistName));
    }
  }
  cleanedStyle = cleanedStyle.replace(/,\s*,/g, ",").replace(/\s+/g, " ").trim();
  return cleanedStyle;
}
/**
 * Upload file to Suno API via URL method
 */ async function uploadFileToSuno(fileUrl) {
  console.log(`Uploading file to Suno from URL: ${fileUrl}`);
  // Send both parameter names for API compatibility
  const requestBody = {
    fileUrl: fileUrl,
    uploadPath: fileUrl,
    url: fileUrl
  };
  console.log("Upload request body:", JSON.stringify(requestBody));
  const response = await fetch(`${FILE_UPLOAD_BASE}/api/file-url-upload`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${SUNO_API_KEY}`
    },
    body: JSON.stringify(requestBody)
  });
  const data = await response.json();
  console.log("File upload response:", JSON.stringify(data));
  if (!response.ok || data.code && data.code !== 200) {
    throw new Error(data.msg || "Failed to upload file to Suno");
  }
  // Response contains downloadUrl for the uploaded file
  const uploadedUrl = data.data?.downloadUrl || data.data?.url || data.data || data.downloadUrl || data.url;
  console.log("Uploaded file URL:", uploadedUrl);
  return uploadedUrl;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { trackId, sourceAudioUrl, prompt, style, title, instrumental, customMode = true } = await req.json();
    if (!trackId || !sourceAudioUrl) {
      return new Response(JSON.stringify({
        error: "Missing required fields: trackId, sourceAudioUrl"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Starting upload-cover for track ${trackId} by user ${user.id}`);
    console.log(`Source audio: ${sourceAudioUrl}`);
    console.log(`Style: ${style}, Instrumental: ${instrumental}`);
    // Clean the style to remove artist names
    const cleanedStyle = cleanStyleForSuno(style || "");
    console.log(`Cleaned style: ${cleanedStyle}`);
    // Update track status to processing
    const { error: updateError } = await supabaseClient.from("tracks").update({
      status: "processing",
      error_message: null
    }).eq("id", trackId).eq("user_id", user.id);
    if (updateError) {
      console.error("Failed to update track status:", updateError);
    }
    // Step 1: Upload the source audio to Suno's servers
    let sunoUploadUrl;
    try {
      sunoUploadUrl = await uploadFileToSuno(sourceAudioUrl);
      console.log(`File uploaded to Suno: ${sunoUploadUrl}`);
    } catch (uploadError) {
      console.error("Failed to upload file to Suno:", uploadError);
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: "Не удалось загрузить аудио для обработки"
      }).eq("id", trackId);
      return new Response(JSON.stringify({
        error: "Failed to upload audio file"
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Step 2: Call Suno upload-cover endpoint
    const sunoPayload = {
      uploadUrl: sunoUploadUrl,
      customMode: customMode,
      instrumental: instrumental || false,
      model: "V4",
      callBackUrl: `${Deno.env.get("SUPABASE_URL")}/functions/v1/suno-callback`
    };
    if (customMode) {
      if (prompt) sunoPayload.prompt = prompt;
      if (cleanedStyle) sunoPayload.style = cleanedStyle;
      if (title) sunoPayload.title = title;
    }
    console.log("Sending to Suno upload-cover API:", JSON.stringify(sunoPayload));
    const sunoResponse = await fetch(`${SUNO_API_BASE}/api/v1/generate/upload-cover`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify(sunoPayload)
    });
    const sunoData = await sunoResponse.json();
    console.log("Suno upload-cover response:", JSON.stringify(sunoData));
    if (!sunoResponse.ok || sunoData.code !== 200) {
      const errorMessage = sunoData.msg || "Failed to start cover generation";
      console.error(`Suno API error: ${errorMessage}`);
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: errorMessage
      }).eq("id", trackId).eq("user_id", user.id);
      return new Response(JSON.stringify({
        error: errorMessage,
        details: sunoData
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const taskId = sunoData.data?.taskId;
    console.log(`Cover generation started with task ID: ${taskId}`);
    return new Response(JSON.stringify({
      success: true,
      taskId,
      message: "Cover generation started successfully"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in upload-cover:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy91cGxvYWQtY292ZXIvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTY4LjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5jb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG5jb25zdCBTVU5PX0FQSV9CQVNFID0gXCJodHRwczovL2FwaWJveC5lcndlaW1hLmFpXCI7XG5jb25zdCBGSUxFX1VQTE9BRF9CQVNFID0gXCJodHRwczovL3N1bm9hcGlvcmcucmVkcGFuZGFhaS5jb1wiO1xuXG4vLyBNYXAgYXJ0aXN0IG5hbWVzIHRvIGdlbnJlL3N0eWxlIGRlc2NyaXB0aW9ucyAoU3VubyBkb2Vzbid0IGFsbG93IGFydGlzdCBuYW1lcylcbmNvbnN0IGFydGlzdFRvU3R5bGVNYXA6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIFwiRHJha2VcIjogXCJtb29keSB0cmFwIGhpcC1ob3Agd2l0aCBtZWxvZGljIGhvb2tzXCIsXG4gIFwiVGhlIFdlZWtuZFwiOiBcImRhcmsgc3ludGgtcG9wIFImQiB3aXRoIGZhbHNldHRvIHZvY2Fsc1wiLFxuICBcIlRheWxvciBTd2lmdFwiOiBcImNhdGNoeSBwb3AtY291bnRyeSB3aXRoIHN0b3J5dGVsbGluZyBseXJpY3NcIixcbiAgXCJFZCBTaGVlcmFuXCI6IFwiYWNvdXN0aWMgcG9wIGZvbGsgd2l0aCByb21hbnRpYyB0aGVtZXNcIixcbiAgXCJCaWxsaWUgRWlsaXNoXCI6IFwiZGFyayBtaW5pbWFsaXN0IHBvcCB3aXRoIHdoaXNwZXJlZCB2b2NhbHNcIixcbiAgXCJBcmlhbmEgR3JhbmRlXCI6IFwicG93ZXJmdWwgcG9wIFImQiB3aXRoIGhpZ2ggdm9jYWxzXCIsXG4gIFwiRHVhIExpcGFcIjogXCJkaXNjby1pbmZsdWVuY2VkIGRhbmNlIHBvcFwiLFxuICBcIkJhZCBCdW5ueVwiOiBcInJlZ2dhZXRvbiBsYXRpbiB0cmFwIHdpdGggdXJiYW4gYmVhdHNcIixcbiAgXCJQb3N0IE1hbG9uZVwiOiBcIm1lbG9kaWMgaGlwLWhvcCByb2NrIGZ1c2lvblwiLFxuICBcIktlbmRyaWNrIExhbWFyXCI6IFwiY29uc2Npb3VzIGx5cmljYWwgaGlwLWhvcFwiLFxuICBcIkJleW9uY8OpXCI6IFwicG93ZXJmdWwgUiZCIHBvcCB3aXRoIHNvdWxmdWwgdm9jYWxzXCIsXG4gIFwiQnJ1bm8gTWFyc1wiOiBcImZ1bmsgcG9wIHdpdGggcmV0cm8gZ3Jvb3Zlc1wiLFxuICBcIkFkZWxlXCI6IFwicG93ZXJmdWwgYmFsbGFkcyB3aXRoIHNvdWxmdWwgdm9jYWxzXCIsXG4gIFwiQ29sZHBsYXlcIjogXCJhbnRoZW1pYyBhbHRlcm5hdGl2ZSByb2NrIHdpdGggYXRtb3NwaGVyaWMgc3ludGhzXCIsXG59O1xuXG5mdW5jdGlvbiBjb252ZXJ0QXJ0aXN0VG9TdHlsZShhcnRpc3ROYW1lOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoYXJ0aXN0VG9TdHlsZU1hcFthcnRpc3ROYW1lXSkge1xuICAgIHJldHVybiBhcnRpc3RUb1N0eWxlTWFwW2FydGlzdE5hbWVdO1xuICB9XG4gIGNvbnN0IGxvd2VyTmFtZSA9IGFydGlzdE5hbWUudG9Mb3dlckNhc2UoKTtcbiAgZm9yIChjb25zdCBbYXJ0aXN0LCBzdHlsZV0gb2YgT2JqZWN0LmVudHJpZXMoYXJ0aXN0VG9TdHlsZU1hcCkpIHtcbiAgICBpZiAoYXJ0aXN0LnRvTG93ZXJDYXNlKCkgPT09IGxvd2VyTmFtZSkge1xuICAgICAgcmV0dXJuIHN0eWxlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gXCJjb250ZW1wb3JhcnkgcG9wIHdpdGggbW9kZXJuIHByb2R1Y3Rpb25cIjtcbn1cblxuZnVuY3Rpb24gY2xlYW5TdHlsZUZvclN1bm8oc3R5bGU6IHN0cmluZyk6IHN0cmluZyB7XG4gIGlmICghc3R5bGUpIHJldHVybiBcIlwiO1xuICBcbiAgbGV0IGNsZWFuZWRTdHlsZSA9IHN0eWxlO1xuICBmb3IgKGNvbnN0IGFydGlzdE5hbWUgb2YgT2JqZWN0LmtleXMoYXJ0aXN0VG9TdHlsZU1hcCkpIHtcbiAgICBjb25zdCByZWdleCA9IG5ldyBSZWdFeHAoYCR7YXJ0aXN0TmFtZX1cXFxccypzdHlsZWAsIFwiZ2lcIik7XG4gICAgaWYgKHJlZ2V4LnRlc3QoY2xlYW5lZFN0eWxlKSkge1xuICAgICAgY2xlYW5lZFN0eWxlID0gY2xlYW5lZFN0eWxlLnJlcGxhY2UocmVnZXgsIGNvbnZlcnRBcnRpc3RUb1N0eWxlKGFydGlzdE5hbWUpKTtcbiAgICB9XG4gICAgY29uc3Qgc3RhbmRhbG9uZVJlZ2V4ID0gbmV3IFJlZ0V4cChgXFxcXGIke2FydGlzdE5hbWV9XFxcXGJgLCBcImdpXCIpO1xuICAgIGlmIChzdGFuZGFsb25lUmVnZXgudGVzdChjbGVhbmVkU3R5bGUpKSB7XG4gICAgICBjbGVhbmVkU3R5bGUgPSBjbGVhbmVkU3R5bGUucmVwbGFjZShzdGFuZGFsb25lUmVnZXgsIGNvbnZlcnRBcnRpc3RUb1N0eWxlKGFydGlzdE5hbWUpKTtcbiAgICB9XG4gIH1cbiAgXG4gIGNsZWFuZWRTdHlsZSA9IGNsZWFuZWRTdHlsZS5yZXBsYWNlKC8sXFxzKiwvZywgXCIsXCIpLnJlcGxhY2UoL1xccysvZywgXCIgXCIpLnRyaW0oKTtcbiAgcmV0dXJuIGNsZWFuZWRTdHlsZTtcbn1cblxuLyoqXG4gKiBVcGxvYWQgZmlsZSB0byBTdW5vIEFQSSB2aWEgVVJMIG1ldGhvZFxuICovXG5hc3luYyBmdW5jdGlvbiB1cGxvYWRGaWxlVG9TdW5vKGZpbGVVcmw6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnNvbGUubG9nKGBVcGxvYWRpbmcgZmlsZSB0byBTdW5vIGZyb20gVVJMOiAke2ZpbGVVcmx9YCk7XG4gIFxuICAvLyBTZW5kIGJvdGggcGFyYW1ldGVyIG5hbWVzIGZvciBBUEkgY29tcGF0aWJpbGl0eVxuICBjb25zdCByZXF1ZXN0Qm9keSA9IHsgXG4gICAgZmlsZVVybDogZmlsZVVybCxcbiAgICB1cGxvYWRQYXRoOiBmaWxlVXJsLFxuICAgIHVybDogZmlsZVVybCBcbiAgfTtcbiAgY29uc29sZS5sb2coXCJVcGxvYWQgcmVxdWVzdCBib2R5OlwiLCBKU09OLnN0cmluZ2lmeShyZXF1ZXN0Qm9keSkpO1xuICBcbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtGSUxFX1VQTE9BRF9CQVNFfS9hcGkvZmlsZS11cmwtdXBsb2FkYCwge1xuICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgaGVhZGVyczoge1xuICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NVTk9fQVBJX0tFWX1gLFxuICAgIH0sXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkocmVxdWVzdEJvZHkpLFxuICB9KTtcblxuICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICBjb25zb2xlLmxvZyhcIkZpbGUgdXBsb2FkIHJlc3BvbnNlOlwiLCBKU09OLnN0cmluZ2lmeShkYXRhKSk7XG4gIFxuICBpZiAoIXJlc3BvbnNlLm9rIHx8IChkYXRhLmNvZGUgJiYgZGF0YS5jb2RlICE9PSAyMDApKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGRhdGEubXNnIHx8IFwiRmFpbGVkIHRvIHVwbG9hZCBmaWxlIHRvIFN1bm9cIik7XG4gIH1cbiAgXG4gIC8vIFJlc3BvbnNlIGNvbnRhaW5zIGRvd25sb2FkVXJsIGZvciB0aGUgdXBsb2FkZWQgZmlsZVxuICBjb25zdCB1cGxvYWRlZFVybCA9IGRhdGEuZGF0YT8uZG93bmxvYWRVcmwgfHwgZGF0YS5kYXRhPy51cmwgfHwgZGF0YS5kYXRhIHx8IGRhdGEuZG93bmxvYWRVcmwgfHwgZGF0YS51cmw7XG4gIGNvbnNvbGUubG9nKFwiVXBsb2FkZWQgZmlsZSBVUkw6XCIsIHVwbG9hZGVkVXJsKTtcbiAgcmV0dXJuIHVwbG9hZGVkVXJsO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk5vIGF1dGhvcml6YXRpb24gaGVhZGVyXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZUNsaWVudCA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikgPz8gXCJcIixcbiAgICAgIHsgZ2xvYmFsOiB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYXV0aEhlYWRlciB9IH0gfVxuICAgICk7XG5cbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9LCBlcnJvcjogdXNlckVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudC5hdXRoLmdldFVzZXIoKTtcbiAgICBpZiAodXNlckVycm9yIHx8ICF1c2VyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgeyBcbiAgICAgIHRyYWNrSWQsIFxuICAgICAgc291cmNlQXVkaW9VcmwsICAvLyBVUkwgb2YgdXBsb2FkZWQgYXVkaW8gZmlsZSAoZnJvbSBTdXBhYmFzZSBzdG9yYWdlIG9yIGV4dGVybmFsKVxuICAgICAgcHJvbXB0LCAgICAgICAgICAvLyBMeXJpY3Mgb3IgZGVzY3JpcHRpb25cbiAgICAgIHN0eWxlLCAgICAgICAgICAgLy8gTXVzaWMgc3R5bGVcbiAgICAgIHRpdGxlLCBcbiAgICAgIGluc3RydW1lbnRhbCxcbiAgICAgIGN1c3RvbU1vZGUgPSB0cnVlLFxuICAgIH0gPSBhd2FpdCByZXEuanNvbigpO1xuXG4gICAgaWYgKCF0cmFja0lkIHx8ICFzb3VyY2VBdWRpb1VybCkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJNaXNzaW5nIHJlcXVpcmVkIGZpZWxkczogdHJhY2tJZCwgc291cmNlQXVkaW9VcmxcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBTdGFydGluZyB1cGxvYWQtY292ZXIgZm9yIHRyYWNrICR7dHJhY2tJZH0gYnkgdXNlciAke3VzZXIuaWR9YCk7XG4gICAgY29uc29sZS5sb2coYFNvdXJjZSBhdWRpbzogJHtzb3VyY2VBdWRpb1VybH1gKTtcbiAgICBjb25zb2xlLmxvZyhgU3R5bGU6ICR7c3R5bGV9LCBJbnN0cnVtZW50YWw6ICR7aW5zdHJ1bWVudGFsfWApO1xuXG4gICAgLy8gQ2xlYW4gdGhlIHN0eWxlIHRvIHJlbW92ZSBhcnRpc3QgbmFtZXNcbiAgICBjb25zdCBjbGVhbmVkU3R5bGUgPSBjbGVhblN0eWxlRm9yU3VubyhzdHlsZSB8fCBcIlwiKTtcbiAgICBjb25zb2xlLmxvZyhgQ2xlYW5lZCBzdHlsZTogJHtjbGVhbmVkU3R5bGV9YCk7XG5cbiAgICAvLyBVcGRhdGUgdHJhY2sgc3RhdHVzIHRvIHByb2Nlc3NpbmdcbiAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAudXBkYXRlKHsgc3RhdHVzOiBcInByb2Nlc3NpbmdcIiwgZXJyb3JfbWVzc2FnZTogbnVsbCB9KVxuICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZClcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZCk7XG5cbiAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIHRyYWNrIHN0YXR1czpcIiwgdXBkYXRlRXJyb3IpO1xuICAgIH1cblxuICAgIC8vIFN0ZXAgMTogVXBsb2FkIHRoZSBzb3VyY2UgYXVkaW8gdG8gU3VubydzIHNlcnZlcnNcbiAgICBsZXQgc3Vub1VwbG9hZFVybDogc3RyaW5nO1xuICAgIHRyeSB7XG4gICAgICBzdW5vVXBsb2FkVXJsID0gYXdhaXQgdXBsb2FkRmlsZVRvU3Vubyhzb3VyY2VBdWRpb1VybCk7XG4gICAgICBjb25zb2xlLmxvZyhgRmlsZSB1cGxvYWRlZCB0byBTdW5vOiAke3N1bm9VcGxvYWRVcmx9YCk7XG4gICAgfSBjYXRjaCAodXBsb2FkRXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gdXBsb2FkIGZpbGUgdG8gU3VubzpcIiwgdXBsb2FkRXJyb3IpO1xuICAgICAgYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgICBlcnJvcl9tZXNzYWdlOiBcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINCw0YPQtNC40L4g0LTQu9GPINC+0LHRgNCw0LHQvtGC0LrQuFwiXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpO1xuICAgICAgXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkZhaWxlZCB0byB1cGxvYWQgYXVkaW8gZmlsZVwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gU3RlcCAyOiBDYWxsIFN1bm8gdXBsb2FkLWNvdmVyIGVuZHBvaW50XG4gICAgY29uc3Qgc3Vub1BheWxvYWQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgICAgdXBsb2FkVXJsOiBzdW5vVXBsb2FkVXJsLFxuICAgICAgY3VzdG9tTW9kZTogY3VzdG9tTW9kZSxcbiAgICAgIGluc3RydW1lbnRhbDogaW5zdHJ1bWVudGFsIHx8IGZhbHNlLFxuICAgICAgbW9kZWw6IFwiVjRcIixcbiAgICAgIGNhbGxCYWNrVXJsOiBgJHtEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIil9L2Z1bmN0aW9ucy92MS9zdW5vLWNhbGxiYWNrYCxcbiAgICB9O1xuXG4gICAgaWYgKGN1c3RvbU1vZGUpIHtcbiAgICAgIGlmIChwcm9tcHQpIHN1bm9QYXlsb2FkLnByb21wdCA9IHByb21wdDtcbiAgICAgIGlmIChjbGVhbmVkU3R5bGUpIHN1bm9QYXlsb2FkLnN0eWxlID0gY2xlYW5lZFN0eWxlO1xuICAgICAgaWYgKHRpdGxlKSBzdW5vUGF5bG9hZC50aXRsZSA9IHRpdGxlO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKFwiU2VuZGluZyB0byBTdW5vIHVwbG9hZC1jb3ZlciBBUEk6XCIsIEpTT04uc3RyaW5naWZ5KHN1bm9QYXlsb2FkKSk7XG5cbiAgICBjb25zdCBzdW5vUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtTVU5PX0FQSV9CQVNFfS9hcGkvdjEvZ2VuZXJhdGUvdXBsb2FkLWNvdmVyYCwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoc3Vub1BheWxvYWQpLFxuICAgIH0pO1xuXG4gICAgY29uc3Qgc3Vub0RhdGEgPSBhd2FpdCBzdW5vUmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKFwiU3VubyB1cGxvYWQtY292ZXIgcmVzcG9uc2U6XCIsIEpTT04uc3RyaW5naWZ5KHN1bm9EYXRhKSk7XG5cbiAgICBpZiAoIXN1bm9SZXNwb25zZS5vayB8fCBzdW5vRGF0YS5jb2RlICE9PSAyMDApIHtcbiAgICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IHN1bm9EYXRhLm1zZyB8fCBcIkZhaWxlZCB0byBzdGFydCBjb3ZlciBnZW5lcmF0aW9uXCI7XG4gICAgICBjb25zb2xlLmVycm9yKGBTdW5vIEFQSSBlcnJvcjogJHtlcnJvck1lc3NhZ2V9YCk7XG4gICAgICBcbiAgICAgIGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgIC51cGRhdGUoeyBcbiAgICAgICAgICBzdGF0dXM6IFwiZmFpbGVkXCIsXG4gICAgICAgICAgZXJyb3JfbWVzc2FnZTogZXJyb3JNZXNzYWdlXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZCk7XG5cbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgZXJyb3I6IGVycm9yTWVzc2FnZSxcbiAgICAgICAgICBkZXRhaWxzOiBzdW5vRGF0YSBcbiAgICAgICAgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB0YXNrSWQgPSBzdW5vRGF0YS5kYXRhPy50YXNrSWQ7XG4gICAgY29uc29sZS5sb2coYENvdmVyIGdlbmVyYXRpb24gc3RhcnRlZCB3aXRoIHRhc2sgSUQ6ICR7dGFza0lkfWApO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICB0YXNrSWQsXG4gICAgICAgIG1lc3NhZ2U6IFwiQ292ZXIgZ2VuZXJhdGlvbiBzdGFydGVkIHN1Y2Nlc3NmdWxseVwiIFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gdXBsb2FkLWNvdmVyOlwiLCBlcnJvcik7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogZXJyb3JNZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxLQUFLLFFBQVEsK0NBQStDO0FBQ3JFLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDbEMsTUFBTSxnQkFBZ0I7QUFDdEIsTUFBTSxtQkFBbUI7QUFFekIsaUZBQWlGO0FBQ2pGLE1BQU0sbUJBQTJDO0VBQy9DLFNBQVM7RUFDVCxjQUFjO0VBQ2QsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCxpQkFBaUI7RUFDakIsaUJBQWlCO0VBQ2pCLFlBQVk7RUFDWixhQUFhO0VBQ2IsZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsY0FBYztFQUNkLFNBQVM7RUFDVCxZQUFZO0FBQ2Q7QUFFQSxTQUFTLHFCQUFxQixVQUFrQjtFQUM5QyxJQUFJLGdCQUFnQixDQUFDLFdBQVcsRUFBRTtJQUNoQyxPQUFPLGdCQUFnQixDQUFDLFdBQVc7RUFDckM7RUFDQSxNQUFNLFlBQVksV0FBVyxXQUFXO0VBQ3hDLEtBQUssTUFBTSxDQUFDLFFBQVEsTUFBTSxJQUFJLE9BQU8sT0FBTyxDQUFDLGtCQUFtQjtJQUM5RCxJQUFJLE9BQU8sV0FBVyxPQUFPLFdBQVc7TUFDdEMsT0FBTztJQUNUO0VBQ0Y7RUFDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTLGtCQUFrQixLQUFhO0VBQ3RDLElBQUksQ0FBQyxPQUFPLE9BQU87RUFFbkIsSUFBSSxlQUFlO0VBQ25CLEtBQUssTUFBTSxjQUFjLE9BQU8sSUFBSSxDQUFDLGtCQUFtQjtJQUN0RCxNQUFNLFFBQVEsSUFBSSxPQUFPLENBQUMsRUFBRSxXQUFXLFNBQVMsQ0FBQyxFQUFFO0lBQ25ELElBQUksTUFBTSxJQUFJLENBQUMsZUFBZTtNQUM1QixlQUFlLGFBQWEsT0FBTyxDQUFDLE9BQU8scUJBQXFCO0lBQ2xFO0lBQ0EsTUFBTSxrQkFBa0IsSUFBSSxPQUFPLENBQUMsR0FBRyxFQUFFLFdBQVcsR0FBRyxDQUFDLEVBQUU7SUFDMUQsSUFBSSxnQkFBZ0IsSUFBSSxDQUFDLGVBQWU7TUFDdEMsZUFBZSxhQUFhLE9BQU8sQ0FBQyxpQkFBaUIscUJBQXFCO0lBQzVFO0VBQ0Y7RUFFQSxlQUFlLGFBQWEsT0FBTyxDQUFDLFVBQVUsS0FBSyxPQUFPLENBQUMsUUFBUSxLQUFLLElBQUk7RUFDNUUsT0FBTztBQUNUO0FBRUE7O0NBRUMsR0FDRCxlQUFlLGlCQUFpQixPQUFlO0VBQzdDLFFBQVEsR0FBRyxDQUFDLENBQUMsaUNBQWlDLEVBQUUsUUFBUSxDQUFDO0VBRXpELGtEQUFrRDtFQUNsRCxNQUFNLGNBQWM7SUFDbEIsU0FBUztJQUNULFlBQVk7SUFDWixLQUFLO0VBQ1A7RUFDQSxRQUFRLEdBQUcsQ0FBQyx3QkFBd0IsS0FBSyxTQUFTLENBQUM7RUFFbkQsTUFBTSxXQUFXLE1BQU0sTUFBTSxDQUFDLEVBQUUsaUJBQWlCLG9CQUFvQixDQUFDLEVBQUU7SUFDdEUsUUFBUTtJQUNSLFNBQVM7TUFDUCxnQkFBZ0I7TUFDaEIsaUJBQWlCLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQztJQUMzQztJQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7RUFDdkI7RUFFQSxNQUFNLE9BQU8sTUFBTSxTQUFTLElBQUk7RUFDaEMsUUFBUSxHQUFHLENBQUMseUJBQXlCLEtBQUssU0FBUyxDQUFDO0VBRXBELElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSyxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksS0FBSyxLQUFNO0lBQ3BELE1BQU0sSUFBSSxNQUFNLEtBQUssR0FBRyxJQUFJO0VBQzlCO0VBRUEsc0RBQXNEO0VBQ3RELE1BQU0sY0FBYyxLQUFLLElBQUksRUFBRSxlQUFlLEtBQUssSUFBSSxFQUFFLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksS0FBSyxHQUFHO0VBQ3pHLFFBQVEsR0FBRyxDQUFDLHNCQUFzQjtFQUNsQyxPQUFPO0FBQ1Q7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZO01BQ2YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTBCLElBQ2xEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0saUJBQWlCLGFBQ3JCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFDaEMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLHdCQUF3QixJQUNyQztNQUFFLFFBQVE7UUFBRSxTQUFTO1VBQUUsZUFBZTtRQUFXO01BQUU7SUFBRTtJQUd2RCxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxPQUFPO0lBQzlFLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWUsSUFDdkM7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxFQUNKLE9BQU8sRUFDUCxjQUFjLEVBQ2QsTUFBTSxFQUNOLEtBQUssRUFDTCxLQUFLLEVBQ0wsWUFBWSxFQUNaLGFBQWEsSUFBSSxFQUNsQixHQUFHLE1BQU0sSUFBSSxJQUFJO0lBRWxCLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCO01BQy9CLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFtRCxJQUMzRTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGdDQUFnQyxFQUFFLFFBQVEsU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7SUFDM0UsUUFBUSxHQUFHLENBQUMsQ0FBQyxjQUFjLEVBQUUsZUFBZSxDQUFDO0lBQzdDLFFBQVEsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sZ0JBQWdCLEVBQUUsYUFBYSxDQUFDO0lBRTVELHlDQUF5QztJQUN6QyxNQUFNLGVBQWUsa0JBQWtCLFNBQVM7SUFDaEQsUUFBUSxHQUFHLENBQUMsQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDO0lBRTVDLG9DQUFvQztJQUNwQyxNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLGVBQ2xDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztNQUFFLFFBQVE7TUFBYyxlQUFlO0lBQUssR0FDbkQsRUFBRSxDQUFDLE1BQU0sU0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUU7SUFFeEIsSUFBSSxhQUFhO01BQ2YsUUFBUSxLQUFLLENBQUMsa0NBQWtDO0lBQ2xEO0lBRUEsb0RBQW9EO0lBQ3BELElBQUk7SUFDSixJQUFJO01BQ0YsZ0JBQWdCLE1BQU0saUJBQWlCO01BQ3ZDLFFBQVEsR0FBRyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsY0FBYyxDQUFDO0lBQ3ZELEVBQUUsT0FBTyxhQUFhO01BQ3BCLFFBQVEsS0FBSyxDQUFDLGtDQUFrQztNQUNoRCxNQUFNLGVBQ0gsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sUUFBUTtRQUNSLGVBQWU7TUFDakIsR0FDQyxFQUFFLENBQUMsTUFBTTtNQUVaLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE4QixJQUN0RDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSwwQ0FBMEM7SUFDMUMsTUFBTSxjQUF1QztNQUMzQyxXQUFXO01BQ1gsWUFBWTtNQUNaLGNBQWMsZ0JBQWdCO01BQzlCLE9BQU87TUFDUCxhQUFhLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLDJCQUEyQixDQUFDO0lBQzNFO0lBRUEsSUFBSSxZQUFZO01BQ2QsSUFBSSxRQUFRLFlBQVksTUFBTSxHQUFHO01BQ2pDLElBQUksY0FBYyxZQUFZLEtBQUssR0FBRztNQUN0QyxJQUFJLE9BQU8sWUFBWSxLQUFLLEdBQUc7SUFDakM7SUFFQSxRQUFRLEdBQUcsQ0FBQyxxQ0FBcUMsS0FBSyxTQUFTLENBQUM7SUFFaEUsTUFBTSxlQUFlLE1BQU0sTUFBTSxDQUFDLEVBQUUsY0FBYyw2QkFBNkIsQ0FBQyxFQUFFO01BQ2hGLFFBQVE7TUFDUixTQUFTO1FBQ1AsZ0JBQWdCO1FBQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO0lBQ3ZCO0lBRUEsTUFBTSxXQUFXLE1BQU0sYUFBYSxJQUFJO0lBQ3hDLFFBQVEsR0FBRyxDQUFDLCtCQUErQixLQUFLLFNBQVMsQ0FBQztJQUUxRCxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksU0FBUyxJQUFJLEtBQUssS0FBSztNQUM3QyxNQUFNLGVBQWUsU0FBUyxHQUFHLElBQUk7TUFDckMsUUFBUSxLQUFLLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLENBQUM7TUFFL0MsTUFBTSxlQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztRQUNOLFFBQVE7UUFDUixlQUFlO01BQ2pCLEdBQ0MsRUFBRSxDQUFDLE1BQU0sU0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUU7TUFFeEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixPQUFPO1FBQ1AsU0FBUztNQUNYLElBQ0E7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxTQUFTLFNBQVMsSUFBSSxFQUFFO0lBQzlCLFFBQVEsR0FBRyxDQUFDLENBQUMsdUNBQXVDLEVBQUUsT0FBTyxDQUFDO0lBRTlELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNUO01BQ0EsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQywwQkFBMEI7SUFDeEMsTUFBTSxlQUFlLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQzlELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFhLElBQ3JDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const AGENT_ACCESS_ID = "0846d064-4950-4d79-a54c-62ba315cdb34";
const SERVICE_NAMES = {
  spell_check: "forum_spell_check",
  expand_topic: "forum_expand_topic",
  expand_to_topic: "forum_expand_topic",
  expand_reply: "forum_expand_reply",
  improve_text: "forum_improve_text",
  summarize_thread: "forum_summarize_thread",
  suggest_arguments: "forum_suggest_arguments",
  auto_tags: "forum_auto_tags"
};
const DEFAULT_PRICES = {
  spell_check: 3,
  expand_topic: 5,
  expand_to_topic: 5,
  expand_reply: 5,
  improve_text: 4,
  summarize_thread: 3,
  suggest_arguments: 4,
  auto_tags: 0
};
const MESSAGES = {
  spell_check: "Текст проверен!",
  expand_topic: "Тезисы развёрнуты!",
  expand_to_topic: "Тема сгенерирована!",
  expand_reply: "Ответ развёрнут!",
  improve_text: "Текст улучшен!",
  summarize_thread: "Резюме готово!",
  suggest_arguments: "Аргументы готовы!",
  auto_tags: "Теги сгенерированы!"
};
const TAG_COLORS = [
  "#6366f1",
  "#10b981",
  "#f59e0b",
  "#ec4899",
  "#ef4444",
  "#8b5cf6",
  "#06b6d4",
  "#a855f7",
  "#14b8a6",
  "#f97316",
  "#84cc16",
  "#0ea5e9",
  "#d946ef",
  "#22c55e",
  "#e11d48",
  "#7c3aed",
  "#0891b2",
  "#c026d3",
  "#16a34a",
  "#ea580c"
];
function buildPrompts(mode, text, topicTitle, topicContent, threadPosts) {
  const topicContext = topicTitle ? `Тема обсуждения: "${topicTitle}"` : "";
  const contentContext = topicContent ? `\nКонтекст темы: ${topicContent.replace(/<[^>]*>/g, "").slice(0, 500)}` : "";
  switch(mode){
    case "spell_check":
      return {
        systemPrompt: `Ты профессиональный корректор текста. Твоя задача — исправить орфографические, грамматические и пунктуационные ошибки в тексте.

Правила:
- Исправь все орфографические ошибки
- Исправь грамматические ошибки
- Расставь правильную пунктуацию
- Сохрани оригинальное форматирование (переносы строк, абзацы)
- Сохрани стиль и тон автора
- НЕ меняй смысл текста
- НЕ переписывай предложения, если они грамматически верны
- НЕ добавляй и НЕ удаляй контент
- Если текст написан без ошибок — верни его как есть
- Отвечай ТОЛЬКО исправленным текстом, без пояснений и комментариев`,
        userPrompt: `Проверь и исправь ошибки в этом тексте:\n\n${text}`
      };
    case "expand_to_topic":
      return {
        systemPrompt: `Ты опытный участник музыкального форума. Пользователь даёт тебе набор тезисов — ты должен:
1. Придумать короткий, цепляющий заголовок для темы (до 100 символов)
2. Развернуть тезисы в полноценный структурированный пост
3. Подобрать до 3 наиболее подходящих тегов из списка

Доступные теги (выбирай ТОЛЬКО из этого списка, используй точные значения name):
discussion, tutorial, question, showcase, bug-report, feature-request, tip, ai-generation, mixing, lyrics, beats, collab

Формат ответа — строго JSON:
{"title": "заголовок темы", "content": "текст поста", "tags": ["tag1", "tag2"]}

Правила для контента:
- Развей каждый тезис в полноценный абзац
- Используй разговорный, но грамотный стиль общения на форуме
- Сохрани все идеи и мысли автора
- Добавь уместные вопросы к сообществу
- НЕ используй канцелярит и шаблонные фразы
- Пиши живо и естественно
- Длина: 3-6 абзацев
- Разделяй абзацы двойным переносом строки

Правила для заголовка:
- Краткий, интригующий, без кликбейта
- На русском языке

Правила для тегов:
- Выбирай от 1 до 3 тегов, максимально релевантных содержанию
- Используй ТОЛЬКО имена из предоставленного списка

Отвечай ТОЛЬКО валидным JSON, без markdown-обёрток.`,
        userPrompt: `Развей эти тезисы в полноценную тему для форума:\n\n${text}`
      };
    case "expand_reply":
      return {
        systemPrompt: `Ты опытный участник музыкального форума. Развей краткие тезисы в полноценный ответ на тему.

Правила:
- Развей каждый тезис в полноценный абзац
- Добавь логические связки между идеями
- Используй разговорный, но грамотный стиль общения на форуме
- Сохрани все идеи и мысли автора
- Добавь уместные вопросы и реакции на тему обсуждения
- НЕ используй канцелярит и шаблонные фразы
- НЕ добавляй заголовки — только текст ответа
- Пиши живо и естественно, как реальный человек
- Длина: 2-5 абзацев
- Отвечай ТОЛЬКО текстом ответа, без пояснений`,
        userPrompt: `${topicContext}${contentContext}\n\nРазвей эти тезисы в полноценный ответ:\n\n${text}`
      };
    case "improve_text":
      return {
        systemPrompt: `Ты литературный редактор. Улучши текст поста на форуме.

Правила:
- Улучши стиль и читаемость
- Исправь орфографию и пунктуацию
- Сделай текст более структурированным
- Сохрани ВСЕ оригинальные мысли и смысл
- НЕ добавляй новые идеи от себя
- НЕ сокращай текст существенно
- Сохрани тон автора (если неформальный — оставь неформальным)
- НЕ используй канцелярит
- Отвечай ТОЛЬКО улучшенным текстом, без пояснений`,
        userPrompt: `Улучши этот текст:\n\n${text}`
      };
    case "summarize_thread":
      return {
        systemPrompt: `Ты аналитик форумных дискуссий. Создай краткое, информативное резюме обсуждения в теме.

Правила:
- Выдели основные точки зрения и аргументы
- Укажи ключевые идеи каждой стороны дискуссии
- Если есть консенсус — отметь это
- Если есть разногласия — обозначь позиции
- Формат: 3-5 пунктов, коротко и по делу
- Используй маркированный список
- Добавь одно предложение в конце: «Что ещё не обсудили / какие вопросы остались»
- Отвечай ТОЛЬКО резюме, без вступлений и пояснений`,
        userPrompt: `${topicContext}${contentContext}\n\nПосты в дискуссии:\n${threadPosts || "(постов пока нет)"}`
      };
    case "suggest_arguments":
      return {
        systemPrompt: `Ты помощник для написания ответов на музыкальном форуме. Проанализируй тему и предложи аргументы/идеи для ответа.

Правила:
- Предложи 3-5 чётких тезисов для ответа
- Учитывай контекст темы и уже написанные ответы
- Каждый тезис — 1-2 предложения
- Предлагай разные углы зрения
- Учитывай специфику музыкального сообщества
- Формат: нумерованный список
- Отвечай ТОЛЬКО списком тезисов, без вступлений`,
        userPrompt: `${topicContext}${contentContext}\n\nУже написанные ответы:\n${threadPosts || "(ответов пока нет)"}\n\nПредложи идеи для ответа.`
      };
    case "auto_tags":
      return {
        systemPrompt: `Ты SEO-специалист музыкального форума. Твоя задача — извлечь из заголовка и текста темы КОНКРЕТНЫЕ ключевые слова, которые точно описывают содержание ИМЕННО ЭТОЙ темы.

КРИТИЧЕСКИ ВАЖНО — РЕЛЕВАНТНОСТЬ:
- Каждый тег ОБЯЗАН напрямую соответствовать тому, о чём написано в заголовке и тексте
- Если тема про горячие клавиши — теги должны быть про горячие клавиши, советы, лайфхаки
- Если тема про сведение вокала — теги должны быть про сведение, вокал, микширование  
- НИКОГДА не добавляй теги про сведение, биты, тексты, коллаб, если тема НЕ об этом
- НЕ генерируй шаблонные музыкальные теги, которые не связаны с конкретным текстом
- Перечитай заголовок ещё раз перед ответом и убедись, что КАЖДЫЙ тег описывает содержание

Правила:
- Сгенерируй от 2 до 4 тегов (лучше меньше, но точнее)
- Каждый тег: 1-3 слова на русском
- Slug: латиницей, через дефис, lowercase, транслитерация русского названия
- Не используй слишком общие теги: "музыка", "форум", "обсуждение", "вопрос"
- Теги должны быть полезны для SEO-кластеризации: пользователь, ищущий эту тему в Google, мог бы найти её по этим тегам

Формат ответа — строго JSON массив:
[{"slug": "goryachie-klavishi", "name_ru": "Горячие клавиши"}, {"slug": "sovety-novichkam", "name_ru": "Советы новичкам"}]

Отвечай ТОЛЬКО валидным JSON массивом, без markdown-обёрток и пояснений.`,
        userPrompt: `Заголовок темы: "${topicTitle || ""}"\n\nТекст темы:\n${text || topicContent || "(текст отсутствует)"}`
      };
    default:
      // expand_topic (legacy)
      return {
        systemPrompt: `Ты опытный участник музыкального форума. Развей краткие тезисы в полноценный пост.

Правила:
- Развей каждый тезис в полноценный абзац
- Добавь логические связки
- Используй разговорный, но грамотный стиль
- Сохрани все идеи автора
- НЕ добавляй заголовки и разметку — только текст
- Длина: 3-6 абзацев
- Отвечай ТОЛЬКО текстом поста, без пояснений`,
        userPrompt: `${topicContext}${contentContext}\n\nРазвей эти тезисы в полноценный пост:\n\n${text}`
      };
  }
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "Необходима авторизация"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
    const token = authHeader.replace("Bearer ", "");
    const { data, error: authError } = await supabase.auth.getClaims(token);
    if (authError || !data?.claims?.sub) {
      console.error("Auth error:", authError);
      return new Response(JSON.stringify({
        error: "Неверный токен авторизации"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const user_id = data.claims.sub;
    const { mode, text, topicTitle, topicContent, threadPosts, topicId } = await req.json();
    console.log(`[forum-ai-helper] mode=${mode}, user=${user_id}, textLen=${text?.length || 0}`);
    const TIMEWEB_TOKEN = Deno.env.get("TIMEWEB_AGENT_TOKEN");
    if (!TIMEWEB_TOKEN) {
      throw new Error("TIMEWEB_AGENT_TOKEN not configured");
    }
    // Get service price from addon_services
    const serviceName = SERVICE_NAMES[mode];
    if (!serviceName) {
      return new Response(JSON.stringify({
        error: `Неизвестный режим: ${mode}`
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { data: service } = await supabase.from("addon_services").select("price_rub, is_active").eq("name", serviceName).maybeSingle();
    if (service && !service.is_active) {
      return new Response(JSON.stringify({
        error: "Эта функция временно отключена"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const price = service?.price_rub ?? DEFAULT_PRICES[mode];
    const isFreeMode = price === 0;
    let profile = null;
    let newBalance = 0;
    if (!isFreeMode) {
      // Check balance
      const { data: profileData } = await supabase.from("profiles").select("balance").eq("user_id", user_id).maybeSingle();
      profile = profileData;
      if (!profile || (profile.balance || 0) < price) {
        return new Response(JSON.stringify({
          error: "Недостаточно средств на балансе",
          required: price,
          balance: profile?.balance || 0
        }), {
          status: 402,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Deduct balance
      newBalance = (profile.balance || 0) - price;
      const { error: balanceError } = await supabase.from("profiles").update({
        balance: newBalance
      }).eq("user_id", user_id);
      if (balanceError) {
        throw new Error("Ошибка списания баланса");
      }
      // Log transaction
      await supabase.from("balance_transactions").insert({
        user_id: user_id,
        amount: -price,
        balance_after: newBalance,
        type: "forum_ai",
        description: `Форум AI: ${MESSAGES[mode] || mode}`,
        metadata: {
          mode,
          topicTitle
        }
      });
    }
    const { systemPrompt, userPrompt } = buildPrompts(mode, text, topicTitle, topicContent, threadPosts);
    // Call Timeweb Agent API
    const apiUrl = `https://agent.timeweb.cloud/api/v1/cloud-ai/agents/${AGENT_ACCESS_ID}/v1/chat/completions`;
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${TIMEWEB_TOKEN}`,
        "x-proxy-source": "lovable-app"
      },
      body: JSON.stringify({
        model: "deepseek-v3",
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: userPrompt
          }
        ],
        temperature: mode === "spell_check" || mode === "auto_tags" ? 0.1 : 0.7
      })
    });
    console.log(`[forum-ai-helper] Timeweb response status: ${response.status}`);
    if (!response.ok) {
      // Refund on API error (only if paid)
      if (!isFreeMode && profile) {
        await supabase.from("profiles").update({
          balance: profile.balance
        }).eq("user_id", user_id);
      }
      const errorText = await response.text();
      console.error("[forum-ai-helper] Timeweb API error:", response.status, errorText);
      throw new Error("Ошибка API — попробуйте позже");
    }
    const result = await response.json();
    const generatedContent = result.choices?.[0]?.message?.content;
    if (!generatedContent) {
      if (!isFreeMode && profile) {
        await supabase.from("profiles").update({
          balance: profile.balance
        }).eq("user_id", user_id);
      }
      throw new Error("Не удалось обработать текст");
    }
    // ── auto_tags: parse, create tags, link to topic ──
    if (mode === "auto_tags") {
      try {
        let cleanJson = generatedContent.trim();
        // Remove markdown fences
        cleanJson = cleanJson.replace(/```json\s*/gi, "").replace(/```\s*/g, "").trim();
        // Find JSON array boundaries
        const arrStart = cleanJson.indexOf("[");
        const arrEnd = cleanJson.lastIndexOf("]");
        if (arrStart !== -1 && arrEnd !== -1) {
          cleanJson = cleanJson.substring(arrStart, arrEnd + 1);
        }
        // Fix common issues
        cleanJson = cleanJson.replace(/,\s*]/g, "]").replace(/[\x00-\x1F\x7F]/g, "");
        const tags = JSON.parse(cleanJson);
        console.log(`[forum-ai-helper] auto_tags parsed ${tags.length} tags:`, tags);
        if (!Array.isArray(tags) || tags.length === 0) {
          return new Response(JSON.stringify({
            success: true,
            tags: [],
            mode,
            message: "Нет подходящих тегов"
          }), {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json"
            }
          });
        }
        const createdTagIds = [];
        const createdTags = [];
        for (const tag of tags.slice(0, 5)){
          if (!tag.slug || !tag.name_ru) continue;
          const slug = tag.slug.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 50);
          const nameRu = tag.name_ru.trim().slice(0, 50);
          if (!slug || !nameRu) continue;
          // Check if tag exists by slug
          const { data: existing } = await supabase.from("forum_tags").select("id, name, name_ru, color").eq("name", slug).maybeSingle();
          if (existing) {
            createdTagIds.push(existing.id);
            createdTags.push(existing);
            // Increment usage_count
            await supabase.from("forum_tags").update({
              usage_count: existing.usage_count ? existing.usage_count + 1 : 1
            }).eq("id", existing.id);
          } else {
            const color = TAG_COLORS[Math.floor(Math.random() * TAG_COLORS.length)];
            const { data: newTag, error: tagError } = await supabase.from("forum_tags").insert({
              name: slug,
              name_ru: nameRu,
              color,
              usage_count: 1
            }).select("id, name, name_ru, color").single();
            if (tagError) {
              console.error(`[forum-ai-helper] Error creating tag "${slug}":`, tagError);
              continue;
            }
            createdTagIds.push(newTag.id);
            createdTags.push(newTag);
          }
        }
        // Link tags to topic
        if (topicId && createdTagIds.length > 0) {
          // Get existing tags for this topic
          const { data: existingLinks } = await supabase.from("forum_topic_tags").select("tag_id").eq("topic_id", topicId);
          const existingTagIds = new Set((existingLinks || []).map((l)=>l.tag_id));
          const newLinks = createdTagIds.filter((id)=>!existingTagIds.has(id)).slice(0, 5 - existingTagIds.size) // max 5 total tags per topic
          .map((tag_id)=>({
              topic_id: topicId,
              tag_id
            }));
          if (newLinks.length > 0) {
            const { error: linkError } = await supabase.from("forum_topic_tags").insert(newLinks);
            if (linkError) {
              console.error("[forum-ai-helper] Error linking tags:", linkError);
            }
          }
          console.log(`[forum-ai-helper] Linked ${newLinks.length} auto-tags to topic ${topicId}`);
        }
        return new Response(JSON.stringify({
          success: true,
          tags: createdTags,
          mode,
          message: MESSAGES[mode]
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      } catch (parseErr) {
        console.error("[forum-ai-helper] auto_tags parse error:", parseErr, "raw:", generatedContent);
        return new Response(JSON.stringify({
          success: true,
          tags: [],
          mode,
          message: "Не удалось распознать теги"
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
    }
    // For expand_to_topic, parse JSON to extract title + content
    if (mode === "expand_to_topic") {
      try {
        let cleanJson = generatedContent.trim();
        cleanJson = cleanJson.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
        const parsed = JSON.parse(cleanJson);
        return new Response(JSON.stringify({
          success: true,
          title: (parsed.title || "").trim(),
          content: (parsed.content || "").trim(),
          suggestedTags: Array.isArray(parsed.tags) ? parsed.tags : [],
          mode,
          price,
          message: MESSAGES[mode]
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      } catch  {
        const lines = generatedContent.trim().split("\n");
        const fallbackTitle = lines[0].replace(/^["#*]+|["#*]+$/g, "").trim();
        const fallbackContent = lines.slice(1).join("\n").trim();
        return new Response(JSON.stringify({
          success: true,
          title: fallbackTitle,
          content: fallbackContent || generatedContent.trim(),
          suggestedTags: [],
          mode,
          price,
          message: MESSAGES[mode]
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
    }
    return new Response(JSON.stringify({
      success: true,
      result: generatedContent.trim(),
      mode,
      price,
      message: MESSAGES[mode]
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("[forum-ai-helper] Error:", error);
    const message = error instanceof Error ? error.message : "Неизвестная ошибка";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9mb3J1bS1haS1oZWxwZXIvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTY4LjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOlxuICAgIFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbnR5cGUgTW9kZSA9XG4gIHwgXCJzcGVsbF9jaGVja1wiXG4gIHwgXCJleHBhbmRfdG9waWNcIlxuICB8IFwiZXhwYW5kX3RvX3RvcGljXCJcbiAgfCBcImV4cGFuZF9yZXBseVwiXG4gIHwgXCJpbXByb3ZlX3RleHRcIlxuICB8IFwic3VtbWFyaXplX3RocmVhZFwiXG4gIHwgXCJzdWdnZXN0X2FyZ3VtZW50c1wiXG4gIHwgXCJhdXRvX3RhZ3NcIjtcblxuY29uc3QgQUdFTlRfQUNDRVNTX0lEID0gXCIwODQ2ZDA2NC00OTUwLTRkNzktYTU0Yy02MmJhMzE1Y2RiMzRcIjtcblxuY29uc3QgU0VSVklDRV9OQU1FUzogUmVjb3JkPE1vZGUsIHN0cmluZz4gPSB7XG4gIHNwZWxsX2NoZWNrOiBcImZvcnVtX3NwZWxsX2NoZWNrXCIsXG4gIGV4cGFuZF90b3BpYzogXCJmb3J1bV9leHBhbmRfdG9waWNcIixcbiAgZXhwYW5kX3RvX3RvcGljOiBcImZvcnVtX2V4cGFuZF90b3BpY1wiLFxuICBleHBhbmRfcmVwbHk6IFwiZm9ydW1fZXhwYW5kX3JlcGx5XCIsXG4gIGltcHJvdmVfdGV4dDogXCJmb3J1bV9pbXByb3ZlX3RleHRcIixcbiAgc3VtbWFyaXplX3RocmVhZDogXCJmb3J1bV9zdW1tYXJpemVfdGhyZWFkXCIsXG4gIHN1Z2dlc3RfYXJndW1lbnRzOiBcImZvcnVtX3N1Z2dlc3RfYXJndW1lbnRzXCIsXG4gIGF1dG9fdGFnczogXCJmb3J1bV9hdXRvX3RhZ3NcIixcbn07XG5cbmNvbnN0IERFRkFVTFRfUFJJQ0VTOiBSZWNvcmQ8TW9kZSwgbnVtYmVyPiA9IHtcbiAgc3BlbGxfY2hlY2s6IDMsXG4gIGV4cGFuZF90b3BpYzogNSxcbiAgZXhwYW5kX3RvX3RvcGljOiA1LFxuICBleHBhbmRfcmVwbHk6IDUsXG4gIGltcHJvdmVfdGV4dDogNCxcbiAgc3VtbWFyaXplX3RocmVhZDogMyxcbiAgc3VnZ2VzdF9hcmd1bWVudHM6IDQsXG4gIGF1dG9fdGFnczogMCwgLy8gRnJlZSBmb3IgU0VPXG59O1xuXG5jb25zdCBNRVNTQUdFUzogUmVjb3JkPE1vZGUsIHN0cmluZz4gPSB7XG4gIHNwZWxsX2NoZWNrOiBcItCi0LXQutGB0YIg0L/RgNC+0LLQtdGA0LXQvSFcIixcbiAgZXhwYW5kX3RvcGljOiBcItCi0LXQt9C40YHRiyDRgNCw0LfQstGR0YDQvdGD0YLRiyFcIixcbiAgZXhwYW5kX3RvX3RvcGljOiBcItCi0LXQvNCwINGB0LPQtdC90LXRgNC40YDQvtCy0LDQvdCwIVwiLFxuICBleHBhbmRfcmVwbHk6IFwi0J7RgtCy0LXRgiDRgNCw0LfQstGR0YDQvdGD0YIhXCIsXG4gIGltcHJvdmVfdGV4dDogXCLQotC10LrRgdGCINGD0LvRg9GH0YjQtdC9IVwiLFxuICBzdW1tYXJpemVfdGhyZWFkOiBcItCg0LXQt9GO0LzQtSDQs9C+0YLQvtCy0L4hXCIsXG4gIHN1Z2dlc3RfYXJndW1lbnRzOiBcItCQ0YDQs9GD0LzQtdC90YLRiyDQs9C+0YLQvtCy0YshXCIsXG4gIGF1dG9fdGFnczogXCLQotC10LPQuCDRgdCz0LXQvdC10YDQuNGA0L7QstCw0L3RiyFcIixcbn07XG5cbmNvbnN0IFRBR19DT0xPUlMgPSBbXG4gIFwiIzYzNjZmMVwiLCBcIiMxMGI5ODFcIiwgXCIjZjU5ZTBiXCIsIFwiI2VjNDg5OVwiLCBcIiNlZjQ0NDRcIixcbiAgXCIjOGI1Y2Y2XCIsIFwiIzA2YjZkNFwiLCBcIiNhODU1ZjdcIiwgXCIjMTRiOGE2XCIsIFwiI2Y5NzMxNlwiLFxuICBcIiM4NGNjMTZcIiwgXCIjMGVhNWU5XCIsIFwiI2Q5NDZlZlwiLCBcIiMyMmM1NWVcIiwgXCIjZTExZDQ4XCIsXG4gIFwiIzdjM2FlZFwiLCBcIiMwODkxYjJcIiwgXCIjYzAyNmQzXCIsIFwiIzE2YTM0YVwiLCBcIiNlYTU4MGNcIixcbl07XG5cbmZ1bmN0aW9uIGJ1aWxkUHJvbXB0cyhcbiAgbW9kZTogTW9kZSxcbiAgdGV4dDogc3RyaW5nIHwgdW5kZWZpbmVkLFxuICB0b3BpY1RpdGxlOiBzdHJpbmcgfCB1bmRlZmluZWQsXG4gIHRvcGljQ29udGVudDogc3RyaW5nIHwgdW5kZWZpbmVkLFxuICB0aHJlYWRQb3N0czogc3RyaW5nIHwgdW5kZWZpbmVkLFxuKTogeyBzeXN0ZW1Qcm9tcHQ6IHN0cmluZzsgdXNlclByb21wdDogc3RyaW5nIH0ge1xuICBjb25zdCB0b3BpY0NvbnRleHQgPSB0b3BpY1RpdGxlID8gYNCi0LXQvNCwINC+0LHRgdGD0LbQtNC10L3QuNGPOiBcIiR7dG9waWNUaXRsZX1cImAgOiBcIlwiO1xuICBjb25zdCBjb250ZW50Q29udGV4dCA9IHRvcGljQ29udGVudFxuICAgID8gYFxcbtCa0L7QvdGC0LXQutGB0YIg0YLQtdC80Ys6ICR7dG9waWNDb250ZW50LnJlcGxhY2UoLzxbXj5dKj4vZywgXCJcIikuc2xpY2UoMCwgNTAwKX1gXG4gICAgOiBcIlwiO1xuXG4gIHN3aXRjaCAobW9kZSkge1xuICAgIGNhc2UgXCJzcGVsbF9jaGVja1wiOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3lzdGVtUHJvbXB0OiBg0KLRiyDQv9GA0L7RhNC10YHRgdC40L7QvdCw0LvRjNC90YvQuSDQutC+0YDRgNC10LrRgtC+0YAg0YLQtdC60YHRgtCwLiDQotCy0L7RjyDQt9Cw0LTQsNGH0LAg4oCUINC40YHQv9GA0LDQstC40YLRjCDQvtGA0YTQvtCz0YDQsNGE0LjRh9C10YHQutC40LUsINCz0YDQsNC80LzQsNGC0LjRh9C10YHQutC40LUg0Lgg0L/Rg9C90LrRgtGD0LDRhtC40L7QvdC90YvQtSDQvtGI0LjQsdC60Lgg0LIg0YLQtdC60YHRgtC1LlxuXG7Qn9GA0LDQstC40LvQsDpcbi0g0JjRgdC/0YDQsNCy0Ywg0LLRgdC1INC+0YDRhNC+0LPRgNCw0YTQuNGH0LXRgdC60LjQtSDQvtGI0LjQsdC60Lhcbi0g0JjRgdC/0YDQsNCy0Ywg0LPRgNCw0LzQvNCw0YLQuNGH0LXRgdC60LjQtSDQvtGI0LjQsdC60Lhcbi0g0KDQsNGB0YHRgtCw0LLRjCDQv9GA0LDQstC40LvRjNC90YPRjiDQv9GD0L3QutGC0YPQsNGG0LjRjlxuLSDQodC+0YXRgNCw0L3QuCDQvtGA0LjQs9C40L3QsNC70YzQvdC+0LUg0YTQvtGA0LzQsNGC0LjRgNC+0LLQsNC90LjQtSAo0L/QtdGA0LXQvdC+0YHRiyDRgdGC0YDQvtC6LCDQsNCx0LfQsNGG0YspXG4tINCh0L7RhdGA0LDQvdC4INGB0YLQuNC70Ywg0Lgg0YLQvtC9INCw0LLRgtC+0YDQsFxuLSDQndCVINC80LXQvdGP0Lkg0YHQvNGL0YHQuyDRgtC10LrRgdGC0LBcbi0g0J3QlSDQv9C10YDQtdC/0LjRgdGL0LLQsNC5INC/0YDQtdC00LvQvtC20LXQvdC40Y8sINC10YHQu9C4INC+0L3QuCDQs9GA0LDQvNC80LDRgtC40YfQtdGB0LrQuCDQstC10YDQvdGLXG4tINCd0JUg0LTQvtCx0LDQstC70Y/QuSDQuCDQndCVINGD0LTQsNC70Y/QuSDQutC+0L3RgtC10L3RglxuLSDQldGB0LvQuCDRgtC10LrRgdGCINC90LDQv9C40YHQsNC9INCx0LXQtyDQvtGI0LjQsdC+0Log4oCUINCy0LXRgNC90Lgg0LXQs9C+INC60LDQuiDQtdGB0YLRjFxuLSDQntGC0LLQtdGH0LDQuSDQotCe0JvQrNCa0J4g0LjRgdC/0YDQsNCy0LvQtdC90L3Ri9C8INGC0LXQutGB0YLQvtC8LCDQsdC10Lcg0L/QvtGP0YHQvdC10L3QuNC5INC4INC60L7QvNC80LXQvdGC0LDRgNC40LXQsmAsXG4gICAgICAgIHVzZXJQcm9tcHQ6IGDQn9GA0L7QstC10YDRjCDQuCDQuNGB0L/RgNCw0LLRjCDQvtGI0LjQsdC60Lgg0LIg0Y3RgtC+0Lwg0YLQtdC60YHRgtC1OlxcblxcbiR7dGV4dH1gLFxuICAgICAgfTtcblxuICAgIGNhc2UgXCJleHBhbmRfdG9fdG9waWNcIjpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN5c3RlbVByb21wdDogYNCi0Ysg0L7Qv9GL0YLQvdGL0Lkg0YPRh9Cw0YHRgtC90LjQuiDQvNGD0LfRi9C60LDQu9GM0L3QvtCz0L4g0YTQvtGA0YPQvNCwLiDQn9C+0LvRjNC30L7QstCw0YLQtdC70Ywg0LTQsNGR0YIg0YLQtdCx0LUg0L3QsNCx0L7RgCDRgtC10LfQuNGB0L7QsiDigJQg0YLRiyDQtNC+0LvQttC10L06XG4xLiDQn9GA0LjQtNGD0LzQsNGC0Ywg0LrQvtGA0L7RgtC60LjQuSwg0YbQtdC/0LvRj9GO0YnQuNC5INC30LDQs9C+0LvQvtCy0L7QuiDQtNC70Y8g0YLQtdC80YsgKNC00L4gMTAwINGB0LjQvNCy0L7Qu9C+0LIpXG4yLiDQoNCw0LfQstC10YDQvdGD0YLRjCDRgtC10LfQuNGB0Ysg0LIg0L/QvtC70L3QvtGG0LXQvdC90YvQuSDRgdGC0YDRg9C60YLRg9GA0LjRgNC+0LLQsNC90L3Ri9C5INC/0L7RgdGCXG4zLiDQn9C+0LTQvtCx0YDQsNGC0Ywg0LTQviAzINC90LDQuNCx0L7Qu9C10LUg0L/QvtC00YXQvtC00Y/RidC40YUg0YLQtdCz0L7QsiDQuNC3INGB0L/QuNGB0LrQsFxuXG7QlNC+0YHRgtGD0L/QvdGL0LUg0YLQtdCz0LggKNCy0YvQsdC40YDQsNC5INCi0J7Qm9Cs0JrQniDQuNC3INGN0YLQvtCz0L4g0YHQv9C40YHQutCwLCDQuNGB0L/QvtC70YzQt9GD0Lkg0YLQvtGH0L3Ri9C1INC30L3QsNGH0LXQvdC40Y8gbmFtZSk6XG5kaXNjdXNzaW9uLCB0dXRvcmlhbCwgcXVlc3Rpb24sIHNob3djYXNlLCBidWctcmVwb3J0LCBmZWF0dXJlLXJlcXVlc3QsIHRpcCwgYWktZ2VuZXJhdGlvbiwgbWl4aW5nLCBseXJpY3MsIGJlYXRzLCBjb2xsYWJcblxu0KTQvtGA0LzQsNGCINC+0YLQstC10YLQsCDigJQg0YHRgtGA0L7Qs9C+IEpTT046XG57XCJ0aXRsZVwiOiBcItC30LDQs9C+0LvQvtCy0L7QuiDRgtC10LzRi1wiLCBcImNvbnRlbnRcIjogXCLRgtC10LrRgdGCINC/0L7RgdGC0LBcIiwgXCJ0YWdzXCI6IFtcInRhZzFcIiwgXCJ0YWcyXCJdfVxuXG7Qn9GA0LDQstC40LvQsCDQtNC70Y8g0LrQvtC90YLQtdC90YLQsDpcbi0g0KDQsNC30LLQtdC5INC60LDQttC00YvQuSDRgtC10LfQuNGBINCyINC/0L7Qu9C90L7RhtC10L3QvdGL0Lkg0LDQsdC30LDRhlxuLSDQmNGB0L/QvtC70YzQt9GD0Lkg0YDQsNC30LPQvtCy0L7RgNC90YvQuSwg0L3QviDQs9GA0LDQvNC+0YLQvdGL0Lkg0YHRgtC40LvRjCDQvtCx0YnQtdC90LjRjyDQvdCwINGE0L7RgNGD0LzQtVxuLSDQodC+0YXRgNCw0L3QuCDQstGB0LUg0LjQtNC10Lgg0Lgg0LzRi9GB0LvQuCDQsNCy0YLQvtGA0LBcbi0g0JTQvtCx0LDQstGMINGD0LzQtdGB0YLQvdGL0LUg0LLQvtC/0YDQvtGB0Ysg0Log0YHQvtC+0LHRidC10YHRgtCy0YNcbi0g0J3QlSDQuNGB0L/QvtC70YzQt9GD0Lkg0LrQsNC90YbQtdC70Y/RgNC40YIg0Lgg0YjQsNCx0LvQvtC90L3Ri9C1INGE0YDQsNC30Ytcbi0g0J/QuNGI0Lgg0LbQuNCy0L4g0Lgg0LXRgdGC0LXRgdGC0LLQtdC90L3QvlxuLSDQlNC70LjQvdCwOiAzLTYg0LDQsdC30LDRhtC10LJcbi0g0KDQsNC30LTQtdC70Y/QuSDQsNCx0LfQsNGG0Ysg0LTQstC+0LnQvdGL0Lwg0L/QtdGA0LXQvdC+0YHQvtC8INGB0YLRgNC+0LrQuFxuXG7Qn9GA0LDQstC40LvQsCDQtNC70Y8g0LfQsNCz0L7Qu9C+0LLQutCwOlxuLSDQmtGA0LDRgtC60LjQuSwg0LjQvdGC0YDQuNCz0YPRjtGJ0LjQuSwg0LHQtdC3INC60LvQuNC60LHQtdC50YLQsFxuLSDQndCwINGA0YPRgdGB0LrQvtC8INGP0LfRi9C60LVcblxu0J/RgNCw0LLQuNC70LAg0LTQu9GPINGC0LXQs9C+0LI6XG4tINCS0YvQsdC40YDQsNC5INC+0YIgMSDQtNC+IDMg0YLQtdCz0L7Qsiwg0LzQsNC60YHQuNC80LDQu9GM0L3QviDRgNC10LvQtdCy0LDQvdGC0L3Ri9GFINGB0L7QtNC10YDQttCw0L3QuNGOXG4tINCY0YHQv9C+0LvRjNC30YPQuSDQotCe0JvQrNCa0J4g0LjQvNC10L3QsCDQuNC3INC/0YDQtdC00L7RgdGC0LDQstC70LXQvdC90L7Qs9C+INGB0L/QuNGB0LrQsFxuXG7QntGC0LLQtdGH0LDQuSDQotCe0JvQrNCa0J4g0LLQsNC70LjQtNC90YvQvCBKU09OLCDQsdC10LcgbWFya2Rvd24t0L7QsdGR0YDRgtC+0LouYCxcbiAgICAgICAgdXNlclByb21wdDogYNCg0LDQt9Cy0LXQuSDRjdGC0Lgg0YLQtdC30LjRgdGLINCyINC/0L7Qu9C90L7RhtC10L3QvdGD0Y4g0YLQtdC80YMg0LTQu9GPINGE0L7RgNGD0LzQsDpcXG5cXG4ke3RleHR9YCxcbiAgICAgIH07XG5cbiAgICBjYXNlIFwiZXhwYW5kX3JlcGx5XCI6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzeXN0ZW1Qcm9tcHQ6IGDQotGLINC+0L/Ri9GC0L3Ri9C5INGD0YfQsNGB0YLQvdC40Log0LzRg9C30YvQutCw0LvRjNC90L7Qs9C+INGE0L7RgNGD0LzQsC4g0KDQsNC30LLQtdC5INC60YDQsNGC0LrQuNC1INGC0LXQt9C40YHRiyDQsiDQv9C+0LvQvdC+0YbQtdC90L3Ri9C5INC+0YLQstC10YIg0L3QsCDRgtC10LzRgy5cblxu0J/RgNCw0LLQuNC70LA6XG4tINCg0LDQt9Cy0LXQuSDQutCw0LbQtNGL0Lkg0YLQtdC30LjRgSDQsiDQv9C+0LvQvdC+0YbQtdC90L3Ri9C5INCw0LHQt9Cw0YZcbi0g0JTQvtCx0LDQstGMINC70L7Qs9C40YfQtdGB0LrQuNC1INGB0LLRj9C30LrQuCDQvNC10LbQtNGDINC40LTQtdGP0LzQuFxuLSDQmNGB0L/QvtC70YzQt9GD0Lkg0YDQsNC30LPQvtCy0L7RgNC90YvQuSwg0L3QviDQs9GA0LDQvNC+0YLQvdGL0Lkg0YHRgtC40LvRjCDQvtCx0YnQtdC90LjRjyDQvdCwINGE0L7RgNGD0LzQtVxuLSDQodC+0YXRgNCw0L3QuCDQstGB0LUg0LjQtNC10Lgg0Lgg0LzRi9GB0LvQuCDQsNCy0YLQvtGA0LBcbi0g0JTQvtCx0LDQstGMINGD0LzQtdGB0YLQvdGL0LUg0LLQvtC/0YDQvtGB0Ysg0Lgg0YDQtdCw0LrRhtC40Lgg0L3QsCDRgtC10LzRgyDQvtCx0YHRg9C20LTQtdC90LjRj1xuLSDQndCVINC40YHQv9C+0LvRjNC30YPQuSDQutCw0L3RhtC10LvRj9GA0LjRgiDQuCDRiNCw0LHQu9C+0L3QvdGL0LUg0YTRgNCw0LfRi1xuLSDQndCVINC00L7QsdCw0LLQu9GP0Lkg0LfQsNCz0L7Qu9C+0LLQutC4IOKAlCDRgtC+0LvRjNC60L4g0YLQtdC60YHRgiDQvtGC0LLQtdGC0LBcbi0g0J/QuNGI0Lgg0LbQuNCy0L4g0Lgg0LXRgdGC0LXRgdGC0LLQtdC90L3Qviwg0LrQsNC6INGA0LXQsNC70YzQvdGL0Lkg0YfQtdC70L7QstC10Lpcbi0g0JTQu9C40L3QsDogMi01INCw0LHQt9Cw0YbQtdCyXG4tINCe0YLQstC10YfQsNC5INCi0J7Qm9Cs0JrQniDRgtC10LrRgdGC0L7QvCDQvtGC0LLQtdGC0LAsINCx0LXQtyDQv9C+0Y/RgdC90LXQvdC40LlgLFxuICAgICAgICB1c2VyUHJvbXB0OiBgJHt0b3BpY0NvbnRleHR9JHtjb250ZW50Q29udGV4dH1cXG5cXG7QoNCw0LfQstC10Lkg0Y3RgtC4INGC0LXQt9C40YHRiyDQsiDQv9C+0LvQvdC+0YbQtdC90L3Ri9C5INC+0YLQstC10YI6XFxuXFxuJHt0ZXh0fWAsXG4gICAgICB9O1xuXG4gICAgY2FzZSBcImltcHJvdmVfdGV4dFwiOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3lzdGVtUHJvbXB0OiBg0KLRiyDQu9C40YLQtdGA0LDRgtGD0YDQvdGL0Lkg0YDQtdC00LDQutGC0L7RgC4g0KPQu9GD0YfRiNC4INGC0LXQutGB0YIg0L/QvtGB0YLQsCDQvdCwINGE0L7RgNGD0LzQtS5cblxu0J/RgNCw0LLQuNC70LA6XG4tINCj0LvRg9GH0YjQuCDRgdGC0LjQu9GMINC4INGH0LjRgtCw0LXQvNC+0YHRgtGMXG4tINCY0YHQv9GA0LDQstGMINC+0YDRhNC+0LPRgNCw0YTQuNGOINC4INC/0YPQvdC60YLRg9Cw0YbQuNGOXG4tINCh0LTQtdC70LDQuSDRgtC10LrRgdGCINCx0L7Qu9C10LUg0YHRgtGA0YPQutGC0YPRgNC40YDQvtCy0LDQvdC90YvQvFxuLSDQodC+0YXRgNCw0L3QuCDQktCh0JUg0L7RgNC40LPQuNC90LDQu9GM0L3Ri9C1INC80YvRgdC70Lgg0Lgg0YHQvNGL0YHQu1xuLSDQndCVINC00L7QsdCw0LLQu9GP0Lkg0L3QvtCy0YvQtSDQuNC00LXQuCDQvtGCINGB0LXQsdGPXG4tINCd0JUg0YHQvtC60YDQsNGJ0LDQuSDRgtC10LrRgdGCINGB0YPRidC10YHRgtCy0LXQvdC90L5cbi0g0KHQvtGF0YDQsNC90Lgg0YLQvtC9INCw0LLRgtC+0YDQsCAo0LXRgdC70Lgg0L3QtdGE0L7RgNC80LDQu9GM0L3Ri9C5IOKAlCDQvtGB0YLQsNCy0Ywg0L3QtdGE0L7RgNC80LDQu9GM0L3Ri9C8KVxuLSDQndCVINC40YHQv9C+0LvRjNC30YPQuSDQutCw0L3RhtC10LvRj9GA0LjRglxuLSDQntGC0LLQtdGH0LDQuSDQotCe0JvQrNCa0J4g0YPQu9GD0YfRiNC10L3QvdGL0Lwg0YLQtdC60YHRgtC+0LwsINCx0LXQtyDQv9C+0Y/RgdC90LXQvdC40LlgLFxuICAgICAgICB1c2VyUHJvbXB0OiBg0KPQu9GD0YfRiNC4INGN0YLQvtGCINGC0LXQutGB0YI6XFxuXFxuJHt0ZXh0fWAsXG4gICAgICB9O1xuXG4gICAgY2FzZSBcInN1bW1hcml6ZV90aHJlYWRcIjpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN5c3RlbVByb21wdDogYNCi0Ysg0LDQvdCw0LvQuNGC0LjQuiDRhNC+0YDRg9C80L3Ri9GFINC00LjRgdC60YPRgdGB0LjQuS4g0KHQvtC30LTQsNC5INC60YDQsNGC0LrQvtC1LCDQuNC90YTQvtGA0LzQsNGC0LjQstC90L7QtSDRgNC10LfRjtC80LUg0L7QsdGB0YPQttC00LXQvdC40Y8g0LIg0YLQtdC80LUuXG5cbtCf0YDQsNCy0LjQu9CwOlxuLSDQktGL0LTQtdC70Lgg0L7RgdC90L7QstC90YvQtSDRgtC+0YfQutC4INC30YDQtdC90LjRjyDQuCDQsNGA0LPRg9C80LXQvdGC0Ytcbi0g0KPQutCw0LbQuCDQutC70Y7Rh9C10LLRi9C1INC40LTQtdC4INC60LDQttC00L7QuSDRgdGC0L7RgNC+0L3RiyDQtNC40YHQutGD0YHRgdC40Lhcbi0g0JXRgdC70Lgg0LXRgdGC0Ywg0LrQvtC90YHQtdC90YHRg9GBIOKAlCDQvtGC0LzQtdGC0Ywg0Y3RgtC+XG4tINCV0YHQu9C4INC10YHRgtGMINGA0LDQt9C90L7Qs9C70LDRgdC40Y8g4oCUINC+0LHQvtC30L3QsNGH0Ywg0L/QvtC30LjRhtC40Lhcbi0g0KTQvtGA0LzQsNGCOiAzLTUg0L/Rg9C90LrRgtC+0LIsINC60L7RgNC+0YLQutC+INC4INC/0L4g0LTQtdC70YNcbi0g0JjRgdC/0L7Qu9GM0LfRg9C5INC80LDRgNC60LjRgNC+0LLQsNC90L3Ri9C5INGB0L/QuNGB0L7QulxuLSDQlNC+0LHQsNCy0Ywg0L7QtNC90L4g0L/RgNC10LTQu9C+0LbQtdC90LjQtSDQsiDQutC+0L3RhtC1OiDCq9Cn0YLQviDQtdGJ0ZEg0L3QtSDQvtCx0YHRg9C00LjQu9C4IC8g0LrQsNC60LjQtSDQstC+0L/RgNC+0YHRiyDQvtGB0YLQsNC70LjRgdGMwrtcbi0g0J7RgtCy0LXRh9Cw0Lkg0KLQntCb0KzQmtCeINGA0LXQt9GO0LzQtSwg0LHQtdC3INCy0YHRgtGD0L/Qu9C10L3QuNC5INC4INC/0L7Rj9GB0L3QtdC90LjQuWAsXG4gICAgICAgIHVzZXJQcm9tcHQ6IGAke3RvcGljQ29udGV4dH0ke2NvbnRlbnRDb250ZXh0fVxcblxcbtCf0L7RgdGC0Ysg0LIg0LTQuNGB0LrRg9GB0YHQuNC4OlxcbiR7dGhyZWFkUG9zdHMgfHwgXCIo0L/QvtGB0YLQvtCyINC/0L7QutCwINC90LXRgilcIn1gLFxuICAgICAgfTtcblxuICAgIGNhc2UgXCJzdWdnZXN0X2FyZ3VtZW50c1wiOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3lzdGVtUHJvbXB0OiBg0KLRiyDQv9C+0LzQvtGJ0L3QuNC6INC00LvRjyDQvdCw0L/QuNGB0LDQvdC40Y8g0L7RgtCy0LXRgtC+0LIg0L3QsCDQvNGD0LfRi9C60LDQu9GM0L3QvtC8INGE0L7RgNGD0LzQtS4g0J/RgNC+0LDQvdCw0LvQuNC30LjRgNGD0Lkg0YLQtdC80YMg0Lgg0L/RgNC10LTQu9C+0LbQuCDQsNGA0LPRg9C80LXQvdGC0Ysv0LjQtNC10Lgg0LTQu9GPINC+0YLQstC10YLQsC5cblxu0J/RgNCw0LLQuNC70LA6XG4tINCf0YDQtdC00LvQvtC20LggMy01INGH0ZHRgtC60LjRhSDRgtC10LfQuNGB0L7QsiDQtNC70Y8g0L7RgtCy0LXRgtCwXG4tINCj0YfQuNGC0YvQstCw0Lkg0LrQvtC90YLQtdC60YHRgiDRgtC10LzRiyDQuCDRg9C20LUg0L3QsNC/0LjRgdCw0L3QvdGL0LUg0L7RgtCy0LXRgtGLXG4tINCa0LDQttC00YvQuSDRgtC10LfQuNGBIOKAlCAxLTIg0L/RgNC10LTQu9C+0LbQtdC90LjRj1xuLSDQn9GA0LXQtNC70LDQs9Cw0Lkg0YDQsNC30L3Ri9C1INGD0LPQu9GLINC30YDQtdC90LjRj1xuLSDQo9GH0LjRgtGL0LLQsNC5INGB0L/QtdGG0LjRhNC40LrRgyDQvNGD0LfRi9C60LDQu9GM0L3QvtCz0L4g0YHQvtC+0LHRidC10YHRgtCy0LBcbi0g0KTQvtGA0LzQsNGCOiDQvdGD0LzQtdGA0L7QstCw0L3QvdGL0Lkg0YHQv9C40YHQvtC6XG4tINCe0YLQstC10YfQsNC5INCi0J7Qm9Cs0JrQniDRgdC/0LjRgdC60L7QvCDRgtC10LfQuNGB0L7Qsiwg0LHQtdC3INCy0YHRgtGD0L/Qu9C10L3QuNC5YCxcbiAgICAgICAgdXNlclByb21wdDogYCR7dG9waWNDb250ZXh0fSR7Y29udGVudENvbnRleHR9XFxuXFxu0KPQttC1INC90LDQv9C40YHQsNC90L3Ri9C1INC+0YLQstC10YLRizpcXG4ke3RocmVhZFBvc3RzIHx8IFwiKNC+0YLQstC10YLQvtCyINC/0L7QutCwINC90LXRgilcIn1cXG5cXG7Qn9GA0LXQtNC70L7QttC4INC40LTQtdC4INC00LvRjyDQvtGC0LLQtdGC0LAuYCxcbiAgICAgIH07XG5cbiAgICBjYXNlIFwiYXV0b190YWdzXCI6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzeXN0ZW1Qcm9tcHQ6IGDQotGLIFNFTy3RgdC/0LXRhtC40LDQu9C40YHRgiDQvNGD0LfRi9C60LDQu9GM0L3QvtCz0L4g0YTQvtGA0YPQvNCwLiDQotCy0L7RjyDQt9Cw0LTQsNGH0LAg4oCUINC40LfQstC70LXRh9GMINC40Lcg0LfQsNCz0L7Qu9C+0LLQutCwINC4INGC0LXQutGB0YLQsCDRgtC10LzRiyDQmtCe0J3QmtCg0JXQotCd0KvQlSDQutC70Y7Rh9C10LLRi9C1INGB0LvQvtCy0LAsINC60L7RgtC+0YDRi9C1INGC0L7Rh9C90L4g0L7Qv9C40YHRi9Cy0LDRjtGCINGB0L7QtNC10YDQttCw0L3QuNC1INCY0JzQldCd0J3QniDQrdCi0J7QmSDRgtC10LzRiy5cblxu0JrQoNCY0KLQmNCn0JXQodCa0Jgg0JLQkNCW0J3QniDigJQg0KDQldCb0JXQktCQ0J3QotCd0J7QodCi0Kw6XG4tINCa0LDQttC00YvQuSDRgtC10LMg0J7QkdCv0JfQkNCdINC90LDQv9GA0Y/QvNGD0Y4g0YHQvtC+0YLQstC10YLRgdGC0LLQvtCy0LDRgtGMINGC0L7QvNGDLCDQviDRh9GR0Lwg0L3QsNC/0LjRgdCw0L3QviDQsiDQt9Cw0LPQvtC70L7QstC60LUg0Lgg0YLQtdC60YHRgtC1XG4tINCV0YHQu9C4INGC0LXQvNCwINC/0YDQviDQs9C+0YDRj9GH0LjQtSDQutC70LDQstC40YjQuCDigJQg0YLQtdCz0Lgg0LTQvtC70LbQvdGLINCx0YvRgtGMINC/0YDQviDQs9C+0YDRj9GH0LjQtSDQutC70LDQstC40YjQuCwg0YHQvtCy0LXRgtGLLCDQu9Cw0LnRhNGF0LDQutC4XG4tINCV0YHQu9C4INGC0LXQvNCwINC/0YDQviDRgdCy0LXQtNC10L3QuNC1INCy0L7QutCw0LvQsCDigJQg0YLQtdCz0Lgg0LTQvtC70LbQvdGLINCx0YvRgtGMINC/0YDQviDRgdCy0LXQtNC10L3QuNC1LCDQstC+0LrQsNC7LCDQvNC40LrRiNC40YDQvtCy0LDQvdC40LUgIFxuLSDQndCY0JrQntCT0JTQkCDQvdC1INC00L7QsdCw0LLQu9GP0Lkg0YLQtdCz0Lgg0L/RgNC+INGB0LLQtdC00LXQvdC40LUsINCx0LjRgtGLLCDRgtC10LrRgdGC0YssINC60L7Qu9C70LDQsSwg0LXRgdC70Lgg0YLQtdC80LAg0J3QlSDQvtCxINGN0YLQvtC8XG4tINCd0JUg0LPQtdC90LXRgNC40YDRg9C5INGI0LDQsdC70L7QvdC90YvQtSDQvNGD0LfRi9C60LDQu9GM0L3Ri9C1INGC0LXQs9C4LCDQutC+0YLQvtGA0YvQtSDQvdC1INGB0LLRj9C30LDQvdGLINGBINC60L7QvdC60YDQtdGC0L3Ri9C8INGC0LXQutGB0YLQvtC8XG4tINCf0LXRgNC10YfQuNGC0LDQuSDQt9Cw0LPQvtC70L7QstC+0Log0LXRidGRINGA0LDQtyDQv9C10YDQtdC0INC+0YLQstC10YLQvtC8INC4INGD0LHQtdC00LjRgdGMLCDRh9GC0L4g0JrQkNCW0JTQq9CZINGC0LXQsyDQvtC/0LjRgdGL0LLQsNC10YIg0YHQvtC00LXRgNC20LDQvdC40LVcblxu0J/RgNCw0LLQuNC70LA6XG4tINCh0LPQtdC90LXRgNC40YDRg9C5INC+0YIgMiDQtNC+IDQg0YLQtdCz0L7QsiAo0LvRg9GH0YjQtSDQvNC10L3RjNGI0LUsINC90L4g0YLQvtGH0L3QtdC1KVxuLSDQmtCw0LbQtNGL0Lkg0YLQtdCzOiAxLTMg0YHQu9C+0LLQsCDQvdCwINGA0YPRgdGB0LrQvtC8XG4tIFNsdWc6INC70LDRgtC40L3QuNGG0LXQuSwg0YfQtdGA0LXQtyDQtNC10YTQuNGBLCBsb3dlcmNhc2UsINGC0YDQsNC90YHQu9C40YLQtdGA0LDRhtC40Y8g0YDRg9GB0YHQutC+0LPQviDQvdCw0LfQstCw0L3QuNGPXG4tINCd0LUg0LjRgdC/0L7Qu9GM0LfRg9C5INGB0LvQuNGI0LrQvtC8INC+0LHRidC40LUg0YLQtdCz0Lg6IFwi0LzRg9C30YvQutCwXCIsIFwi0YTQvtGA0YPQvFwiLCBcItC+0LHRgdGD0LbQtNC10L3QuNC1XCIsIFwi0LLQvtC/0YDQvtGBXCJcbi0g0KLQtdCz0Lgg0LTQvtC70LbQvdGLINCx0YvRgtGMINC/0L7Qu9C10LfQvdGLINC00LvRjyBTRU8t0LrQu9Cw0YHRgtC10YDQuNC30LDRhtC40Lg6INC/0L7Qu9GM0LfQvtCy0LDRgtC10LvRjCwg0LjRidGD0YnQuNC5INGN0YLRgyDRgtC10LzRgyDQsiBHb29nbGUsINC80L7QsyDQsdGLINC90LDQudGC0Lgg0LXRkSDQv9C+INGN0YLQuNC8INGC0LXQs9Cw0Lxcblxu0KTQvtGA0LzQsNGCINC+0YLQstC10YLQsCDigJQg0YHRgtGA0L7Qs9C+IEpTT04g0LzQsNGB0YHQuNCyOlxuW3tcInNsdWdcIjogXCJnb3J5YWNoaWUta2xhdmlzaGlcIiwgXCJuYW1lX3J1XCI6IFwi0JPQvtGA0Y/Rh9C40LUg0LrQu9Cw0LLQuNGI0LhcIn0sIHtcInNsdWdcIjogXCJzb3ZldHktbm92aWNoa2FtXCIsIFwibmFtZV9ydVwiOiBcItCh0L7QstC10YLRiyDQvdC+0LLQuNGH0LrQsNC8XCJ9XVxuXG7QntGC0LLQtdGH0LDQuSDQotCe0JvQrNCa0J4g0LLQsNC70LjQtNC90YvQvCBKU09OINC80LDRgdGB0LjQstC+0LwsINCx0LXQtyBtYXJrZG93bi3QvtCx0ZHRgNGC0L7QuiDQuCDQv9C+0Y/RgdC90LXQvdC40LkuYCxcbiAgICAgICAgdXNlclByb21wdDogYNCX0LDQs9C+0LvQvtCy0L7QuiDRgtC10LzRizogXCIke3RvcGljVGl0bGUgfHwgXCJcIn1cIlxcblxcbtCi0LXQutGB0YIg0YLQtdC80Ys6XFxuJHt0ZXh0IHx8IHRvcGljQ29udGVudCB8fCBcIijRgtC10LrRgdGCINC+0YLRgdGD0YLRgdGC0LLRg9C10YIpXCJ9YCxcbiAgICAgIH07XG5cbiAgICBkZWZhdWx0OlxuICAgICAgLy8gZXhwYW5kX3RvcGljIChsZWdhY3kpXG4gICAgICByZXR1cm4ge1xuICAgICAgICBzeXN0ZW1Qcm9tcHQ6IGDQotGLINC+0L/Ri9GC0L3Ri9C5INGD0YfQsNGB0YLQvdC40Log0LzRg9C30YvQutCw0LvRjNC90L7Qs9C+INGE0L7RgNGD0LzQsC4g0KDQsNC30LLQtdC5INC60YDQsNGC0LrQuNC1INGC0LXQt9C40YHRiyDQsiDQv9C+0LvQvdC+0YbQtdC90L3Ri9C5INC/0L7RgdGCLlxuXG7Qn9GA0LDQstC40LvQsDpcbi0g0KDQsNC30LLQtdC5INC60LDQttC00YvQuSDRgtC10LfQuNGBINCyINC/0L7Qu9C90L7RhtC10L3QvdGL0Lkg0LDQsdC30LDRhlxuLSDQlNC+0LHQsNCy0Ywg0LvQvtCz0LjRh9C10YHQutC40LUg0YHQstGP0LfQutC4XG4tINCY0YHQv9C+0LvRjNC30YPQuSDRgNCw0LfQs9C+0LLQvtGA0L3Ri9C5LCDQvdC+INCz0YDQsNC80L7RgtC90YvQuSDRgdGC0LjQu9GMXG4tINCh0L7RhdGA0LDQvdC4INCy0YHQtSDQuNC00LXQuCDQsNCy0YLQvtGA0LBcbi0g0J3QlSDQtNC+0LHQsNCy0LvRj9C5INC30LDQs9C+0LvQvtCy0LrQuCDQuCDRgNCw0LfQvNC10YLQutGDIOKAlCDRgtC+0LvRjNC60L4g0YLQtdC60YHRglxuLSDQlNC70LjQvdCwOiAzLTYg0LDQsdC30LDRhtC10LJcbi0g0J7RgtCy0LXRh9Cw0Lkg0KLQntCb0KzQmtCeINGC0LXQutGB0YLQvtC8INC/0L7RgdGC0LAsINCx0LXQtyDQv9C+0Y/RgdC90LXQvdC40LlgLFxuICAgICAgICB1c2VyUHJvbXB0OiBgJHt0b3BpY0NvbnRleHR9JHtjb250ZW50Q29udGV4dH1cXG5cXG7QoNCw0LfQstC10Lkg0Y3RgtC4INGC0LXQt9C40YHRiyDQsiDQv9C+0LvQvdC+0YbQtdC90L3Ri9C5INC/0L7RgdGCOlxcblxcbiR7dGV4dH1gLFxuICAgICAgfTtcbiAgfVxufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyPy5zdGFydHNXaXRoKFwiQmVhcmVyIFwiKSkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQndC10L7QsdGF0L7QtNC40LzQsCDQsNCy0YLQvtGA0LjQt9Cw0YbQuNGPXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSEsXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpIVxuICAgICk7XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgY29uc3QgeyBkYXRhLCBlcnJvcjogYXV0aEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldENsYWltcyh0b2tlbik7XG5cbiAgICBpZiAoYXV0aEVycm9yIHx8ICFkYXRhPy5jbGFpbXM/LnN1Yikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkF1dGggZXJyb3I6XCIsIGF1dGhFcnJvcik7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LXQstC10YDQvdGL0Lkg0YLQvtC60LXQvSDQsNCy0YLQvtGA0LjQt9Cw0YbQuNC4XCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB1c2VyX2lkID0gZGF0YS5jbGFpbXMuc3ViIGFzIHN0cmluZztcbiAgICBjb25zdCB7IG1vZGUsIHRleHQsIHRvcGljVGl0bGUsIHRvcGljQ29udGVudCwgdGhyZWFkUG9zdHMsIHRvcGljSWQgfSA9IGF3YWl0IHJlcS5qc29uKCkgYXMge1xuICAgICAgbW9kZTogTW9kZTtcbiAgICAgIHRleHQ/OiBzdHJpbmc7XG4gICAgICB0b3BpY1RpdGxlPzogc3RyaW5nO1xuICAgICAgdG9waWNDb250ZW50Pzogc3RyaW5nO1xuICAgICAgdGhyZWFkUG9zdHM/OiBzdHJpbmc7XG4gICAgICB0b3BpY0lkPzogc3RyaW5nO1xuICAgIH07XG5cbiAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWFpLWhlbHBlcl0gbW9kZT0ke21vZGV9LCB1c2VyPSR7dXNlcl9pZH0sIHRleHRMZW49JHt0ZXh0Py5sZW5ndGggfHwgMH1gKTtcblxuICAgIGNvbnN0IFRJTUVXRUJfVE9LRU4gPSBEZW5vLmVudi5nZXQoXCJUSU1FV0VCX0FHRU5UX1RPS0VOXCIpO1xuICAgIGlmICghVElNRVdFQl9UT0tFTikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVElNRVdFQl9BR0VOVF9UT0tFTiBub3QgY29uZmlndXJlZFwiKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgc2VydmljZSBwcmljZSBmcm9tIGFkZG9uX3NlcnZpY2VzXG4gICAgY29uc3Qgc2VydmljZU5hbWUgPSBTRVJWSUNFX05BTUVTW21vZGVdO1xuICAgIGlmICghc2VydmljZU5hbWUpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGDQndC10LjQt9Cy0LXRgdGC0L3Ri9C5INGA0LXQttC40Lw6ICR7bW9kZX1gIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgeyBkYXRhOiBzZXJ2aWNlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJhZGRvbl9zZXJ2aWNlc1wiKVxuICAgICAgLnNlbGVjdChcInByaWNlX3J1YiwgaXNfYWN0aXZlXCIpXG4gICAgICAuZXEoXCJuYW1lXCIsIHNlcnZpY2VOYW1lKVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICBpZiAoc2VydmljZSAmJiAhc2VydmljZS5pc19hY3RpdmUpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0K3RgtCwINGE0YPQvdC60YbQuNGPINCy0YDQtdC80LXQvdC90L4g0L7RgtC60LvRjtGH0LXQvdCwXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDMsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBwcmljZSA9IHNlcnZpY2U/LnByaWNlX3J1YiA/PyBERUZBVUxUX1BSSUNFU1ttb2RlXTtcbiAgICBjb25zdCBpc0ZyZWVNb2RlID0gcHJpY2UgPT09IDA7XG5cbiAgICBsZXQgcHJvZmlsZTogeyBiYWxhbmNlOiBudW1iZXIgfSB8IG51bGwgPSBudWxsO1xuICAgIGxldCBuZXdCYWxhbmNlID0gMDtcblxuICAgIGlmICghaXNGcmVlTW9kZSkge1xuICAgICAgLy8gQ2hlY2sgYmFsYW5jZVxuICAgICAgY29uc3QgeyBkYXRhOiBwcm9maWxlRGF0YSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAuc2VsZWN0KFwiYmFsYW5jZVwiKVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJfaWQpXG4gICAgICAgIC5tYXliZVNpbmdsZSgpO1xuICAgICAgcHJvZmlsZSA9IHByb2ZpbGVEYXRhO1xuXG4gICAgICBpZiAoIXByb2ZpbGUgfHwgKHByb2ZpbGUuYmFsYW5jZSB8fCAwKSA8IHByaWNlKSB7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQndC10LTQvtGB0YLQsNGC0L7Rh9C90L4g0YHRgNC10LTRgdGC0LIg0L3QsCDQsdCw0LvQsNC90YHQtVwiLCByZXF1aXJlZDogcHJpY2UsIGJhbGFuY2U6IHByb2ZpbGU/LmJhbGFuY2UgfHwgMCB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNDAyLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgLy8gRGVkdWN0IGJhbGFuY2VcbiAgICAgIG5ld0JhbGFuY2UgPSAocHJvZmlsZS5iYWxhbmNlIHx8IDApIC0gcHJpY2U7XG4gICAgICBjb25zdCB7IGVycm9yOiBiYWxhbmNlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IG5ld0JhbGFuY2UgfSlcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyX2lkKTtcblxuICAgICAgaWYgKGJhbGFuY2VFcnJvcikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCLQntGI0LjQsdC60LAg0YHQv9C40YHQsNC90LjRjyDQsdCw0LvQsNC90YHQsFwiKTtcbiAgICAgIH1cblxuICAgICAgLy8gTG9nIHRyYW5zYWN0aW9uXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwiYmFsYW5jZV90cmFuc2FjdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogdXNlcl9pZCxcbiAgICAgICAgYW1vdW50OiAtcHJpY2UsXG4gICAgICAgIGJhbGFuY2VfYWZ0ZXI6IG5ld0JhbGFuY2UsXG4gICAgICAgIHR5cGU6IFwiZm9ydW1fYWlcIixcbiAgICAgICAgZGVzY3JpcHRpb246IGDQpNC+0YDRg9C8IEFJOiAke01FU1NBR0VTW21vZGVdIHx8IG1vZGV9YCxcbiAgICAgICAgbWV0YWRhdGE6IHsgbW9kZSwgdG9waWNUaXRsZSB9LFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgY29uc3QgeyBzeXN0ZW1Qcm9tcHQsIHVzZXJQcm9tcHQgfSA9IGJ1aWxkUHJvbXB0cyhtb2RlLCB0ZXh0LCB0b3BpY1RpdGxlLCB0b3BpY0NvbnRlbnQsIHRocmVhZFBvc3RzKTtcblxuICAgIC8vIENhbGwgVGltZXdlYiBBZ2VudCBBUElcbiAgICBjb25zdCBhcGlVcmwgPSBgaHR0cHM6Ly9hZ2VudC50aW1ld2ViLmNsb3VkL2FwaS92MS9jbG91ZC1haS9hZ2VudHMvJHtBR0VOVF9BQ0NFU1NfSUR9L3YxL2NoYXQvY29tcGxldGlvbnNgO1xuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7VElNRVdFQl9UT0tFTn1gLFxuICAgICAgICBcIngtcHJveHktc291cmNlXCI6IFwibG92YWJsZS1hcHBcIixcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIG1vZGVsOiBcImRlZXBzZWVrLXYzXCIsXG4gICAgICAgIG1lc3NhZ2VzOiBbXG4gICAgICAgICAgeyByb2xlOiBcInN5c3RlbVwiLCBjb250ZW50OiBzeXN0ZW1Qcm9tcHQgfSxcbiAgICAgICAgICB7IHJvbGU6IFwidXNlclwiLCBjb250ZW50OiB1c2VyUHJvbXB0IH0sXG4gICAgICAgIF0sXG4gICAgICAgIHRlbXBlcmF0dXJlOiBtb2RlID09PSBcInNwZWxsX2NoZWNrXCIgfHwgbW9kZSA9PT0gXCJhdXRvX3RhZ3NcIiA/IDAuMSA6IDAuNyxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgY29uc29sZS5sb2coYFtmb3J1bS1haS1oZWxwZXJdIFRpbWV3ZWIgcmVzcG9uc2Ugc3RhdHVzOiAke3Jlc3BvbnNlLnN0YXR1c31gKTtcblxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIC8vIFJlZnVuZCBvbiBBUEkgZXJyb3IgKG9ubHkgaWYgcGFpZClcbiAgICAgIGlmICghaXNGcmVlTW9kZSAmJiBwcm9maWxlKSB7XG4gICAgICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBwcm9maWxlLmJhbGFuY2UgfSlcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJfaWQpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBlcnJvclRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICBjb25zb2xlLmVycm9yKFwiW2ZvcnVtLWFpLWhlbHBlcl0gVGltZXdlYiBBUEkgZXJyb3I6XCIsIHJlc3BvbnNlLnN0YXR1cywgZXJyb3JUZXh0KTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCe0YjQuNCx0LrQsCBBUEkg4oCUINC/0L7Qv9GA0L7QsdGD0LnRgtC1INC/0L7Qt9C20LVcIik7XG4gICAgfVxuXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnN0IGdlbmVyYXRlZENvbnRlbnQgPSByZXN1bHQuY2hvaWNlcz8uWzBdPy5tZXNzYWdlPy5jb250ZW50O1xuXG4gICAgaWYgKCFnZW5lcmF0ZWRDb250ZW50KSB7XG4gICAgICBpZiAoIWlzRnJlZU1vZGUgJiYgcHJvZmlsZSkge1xuICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogcHJvZmlsZS5iYWxhbmNlIH0pXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyX2lkKTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L7QsdGA0LDQsdC+0YLQsNGC0Ywg0YLQtdC60YHRglwiKTtcbiAgICB9XG5cbiAgICAvLyDilIDilIAgYXV0b190YWdzOiBwYXJzZSwgY3JlYXRlIHRhZ3MsIGxpbmsgdG8gdG9waWMg4pSA4pSAXG4gICAgaWYgKG1vZGUgPT09IFwiYXV0b190YWdzXCIpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGxldCBjbGVhbkpzb24gPSBnZW5lcmF0ZWRDb250ZW50LnRyaW0oKTtcbiAgICAgICAgLy8gUmVtb3ZlIG1hcmtkb3duIGZlbmNlc1xuICAgICAgICBjbGVhbkpzb24gPSBjbGVhbkpzb24ucmVwbGFjZSgvYGBganNvblxccyovZ2ksIFwiXCIpLnJlcGxhY2UoL2BgYFxccyovZywgXCJcIikudHJpbSgpO1xuICAgICAgICAvLyBGaW5kIEpTT04gYXJyYXkgYm91bmRhcmllc1xuICAgICAgICBjb25zdCBhcnJTdGFydCA9IGNsZWFuSnNvbi5pbmRleE9mKFwiW1wiKTtcbiAgICAgICAgY29uc3QgYXJyRW5kID0gY2xlYW5Kc29uLmxhc3RJbmRleE9mKFwiXVwiKTtcbiAgICAgICAgaWYgKGFyclN0YXJ0ICE9PSAtMSAmJiBhcnJFbmQgIT09IC0xKSB7XG4gICAgICAgICAgY2xlYW5Kc29uID0gY2xlYW5Kc29uLnN1YnN0cmluZyhhcnJTdGFydCwgYXJyRW5kICsgMSk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gRml4IGNvbW1vbiBpc3N1ZXNcbiAgICAgICAgY2xlYW5Kc29uID0gY2xlYW5Kc29uXG4gICAgICAgICAgLnJlcGxhY2UoLyxcXHMqXS9nLCBcIl1cIilcbiAgICAgICAgICAucmVwbGFjZSgvW1xceDAwLVxceDFGXFx4N0ZdL2csIFwiXCIpO1xuXG4gICAgICAgIGNvbnN0IHRhZ3M6IHsgc2x1Zzogc3RyaW5nOyBuYW1lX3J1OiBzdHJpbmcgfVtdID0gSlNPTi5wYXJzZShjbGVhbkpzb24pO1xuICAgICAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWFpLWhlbHBlcl0gYXV0b190YWdzIHBhcnNlZCAke3RhZ3MubGVuZ3RofSB0YWdzOmAsIHRhZ3MpO1xuXG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheSh0YWdzKSB8fCB0YWdzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IHRydWUsIHRhZ3M6IFtdLCBtb2RlLCBtZXNzYWdlOiBcItCd0LXRgiDQv9C+0LTRhdC+0LTRj9GJ0LjRhSDRgtC10LPQvtCyXCIgfSksXG4gICAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBjcmVhdGVkVGFnSWRzOiBzdHJpbmdbXSA9IFtdO1xuICAgICAgICBjb25zdCBjcmVhdGVkVGFnczogeyBpZDogc3RyaW5nOyBuYW1lOiBzdHJpbmc7IG5hbWVfcnU6IHN0cmluZzsgY29sb3I6IHN0cmluZyB9W10gPSBbXTtcblxuICAgICAgICBmb3IgKGNvbnN0IHRhZyBvZiB0YWdzLnNsaWNlKDAsIDUpKSB7XG4gICAgICAgICAgaWYgKCF0YWcuc2x1ZyB8fCAhdGFnLm5hbWVfcnUpIGNvbnRpbnVlO1xuXG4gICAgICAgICAgY29uc3Qgc2x1ZyA9IHRhZy5zbHVnLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvW15hLXowLTktXS9nLCBcIlwiKS5zbGljZSgwLCA1MCk7XG4gICAgICAgICAgY29uc3QgbmFtZVJ1ID0gdGFnLm5hbWVfcnUudHJpbSgpLnNsaWNlKDAsIDUwKTtcbiAgICAgICAgICBpZiAoIXNsdWcgfHwgIW5hbWVSdSkgY29udGludWU7XG5cbiAgICAgICAgICAvLyBDaGVjayBpZiB0YWcgZXhpc3RzIGJ5IHNsdWdcbiAgICAgICAgICBjb25zdCB7IGRhdGE6IGV4aXN0aW5nIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgICAgLmZyb20oXCJmb3J1bV90YWdzXCIpXG4gICAgICAgICAgICAuc2VsZWN0KFwiaWQsIG5hbWUsIG5hbWVfcnUsIGNvbG9yXCIpXG4gICAgICAgICAgICAuZXEoXCJuYW1lXCIsIHNsdWcpXG4gICAgICAgICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgICAgICAgIGlmIChleGlzdGluZykge1xuICAgICAgICAgICAgY3JlYXRlZFRhZ0lkcy5wdXNoKGV4aXN0aW5nLmlkKTtcbiAgICAgICAgICAgIGNyZWF0ZWRUYWdzLnB1c2goZXhpc3RpbmcpO1xuICAgICAgICAgICAgLy8gSW5jcmVtZW50IHVzYWdlX2NvdW50XG4gICAgICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgICAgICAuZnJvbShcImZvcnVtX3RhZ3NcIilcbiAgICAgICAgICAgICAgLnVwZGF0ZSh7IHVzYWdlX2NvdW50OiAoZXhpc3RpbmcgYXMgYW55KS51c2FnZV9jb3VudCA/IChleGlzdGluZyBhcyBhbnkpLnVzYWdlX2NvdW50ICsgMSA6IDEgfSlcbiAgICAgICAgICAgICAgLmVxKFwiaWRcIiwgZXhpc3RpbmcuaWQpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBjb2xvciA9IFRBR19DT0xPUlNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogVEFHX0NPTE9SUy5sZW5ndGgpXTtcbiAgICAgICAgICAgIGNvbnN0IHsgZGF0YTogbmV3VGFnLCBlcnJvcjogdGFnRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgICAgIC5mcm9tKFwiZm9ydW1fdGFnc1wiKVxuICAgICAgICAgICAgICAuaW5zZXJ0KHsgbmFtZTogc2x1ZywgbmFtZV9ydTogbmFtZVJ1LCBjb2xvciwgdXNhZ2VfY291bnQ6IDEgfSlcbiAgICAgICAgICAgICAgLnNlbGVjdChcImlkLCBuYW1lLCBuYW1lX3J1LCBjb2xvclwiKVxuICAgICAgICAgICAgICAuc2luZ2xlKCk7XG5cbiAgICAgICAgICAgIGlmICh0YWdFcnJvcikge1xuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBbZm9ydW0tYWktaGVscGVyXSBFcnJvciBjcmVhdGluZyB0YWcgXCIke3NsdWd9XCI6YCwgdGFnRXJyb3IpO1xuICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNyZWF0ZWRUYWdJZHMucHVzaChuZXdUYWcuaWQpO1xuICAgICAgICAgICAgY3JlYXRlZFRhZ3MucHVzaChuZXdUYWcpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIExpbmsgdGFncyB0byB0b3BpY1xuICAgICAgICBpZiAodG9waWNJZCAmJiBjcmVhdGVkVGFnSWRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAvLyBHZXQgZXhpc3RpbmcgdGFncyBmb3IgdGhpcyB0b3BpY1xuICAgICAgICAgIGNvbnN0IHsgZGF0YTogZXhpc3RpbmdMaW5rcyB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAgIC5mcm9tKFwiZm9ydW1fdG9waWNfdGFnc1wiKVxuICAgICAgICAgICAgLnNlbGVjdChcInRhZ19pZFwiKVxuICAgICAgICAgICAgLmVxKFwidG9waWNfaWRcIiwgdG9waWNJZCk7XG5cbiAgICAgICAgICBjb25zdCBleGlzdGluZ1RhZ0lkcyA9IG5ldyBTZXQoKGV4aXN0aW5nTGlua3MgfHwgW10pLm1hcCgobDogYW55KSA9PiBsLnRhZ19pZCkpO1xuICAgICAgICAgIGNvbnN0IG5ld0xpbmtzID0gY3JlYXRlZFRhZ0lkc1xuICAgICAgICAgICAgLmZpbHRlcihpZCA9PiAhZXhpc3RpbmdUYWdJZHMuaGFzKGlkKSlcbiAgICAgICAgICAgIC5zbGljZSgwLCA1IC0gZXhpc3RpbmdUYWdJZHMuc2l6ZSkgLy8gbWF4IDUgdG90YWwgdGFncyBwZXIgdG9waWNcbiAgICAgICAgICAgIC5tYXAodGFnX2lkID0+ICh7IHRvcGljX2lkOiB0b3BpY0lkLCB0YWdfaWQgfSkpO1xuXG4gICAgICAgICAgaWYgKG5ld0xpbmtzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGNvbnN0IHsgZXJyb3I6IGxpbmtFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAgICAgLmZyb20oXCJmb3J1bV90b3BpY190YWdzXCIpXG4gICAgICAgICAgICAgIC5pbnNlcnQobmV3TGlua3MpO1xuICAgICAgICAgICAgaWYgKGxpbmtFcnJvcikge1xuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiW2ZvcnVtLWFpLWhlbHBlcl0gRXJyb3IgbGlua2luZyB0YWdzOlwiLCBsaW5rRXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zb2xlLmxvZyhgW2ZvcnVtLWFpLWhlbHBlcl0gTGlua2VkICR7bmV3TGlua3MubGVuZ3RofSBhdXRvLXRhZ3MgdG8gdG9waWMgJHt0b3BpY0lkfWApO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgdGFnczogY3JlYXRlZFRhZ3MsXG4gICAgICAgICAgICBtb2RlLFxuICAgICAgICAgICAgbWVzc2FnZTogTUVTU0FHRVNbbW9kZV0sXG4gICAgICAgICAgfSksXG4gICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH0gY2F0Y2ggKHBhcnNlRXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJbZm9ydW0tYWktaGVscGVyXSBhdXRvX3RhZ3MgcGFyc2UgZXJyb3I6XCIsIHBhcnNlRXJyLCBcInJhdzpcIiwgZ2VuZXJhdGVkQ29udGVudCk7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiB0cnVlLCB0YWdzOiBbXSwgbW9kZSwgbWVzc2FnZTogXCLQndC1INGD0LTQsNC70L7RgdGMINGA0LDRgdC/0L7Qt9C90LDRgtGMINGC0LXQs9C4XCIgfSksXG4gICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBGb3IgZXhwYW5kX3RvX3RvcGljLCBwYXJzZSBKU09OIHRvIGV4dHJhY3QgdGl0bGUgKyBjb250ZW50XG4gICAgaWYgKG1vZGUgPT09IFwiZXhwYW5kX3RvX3RvcGljXCIpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGxldCBjbGVhbkpzb24gPSBnZW5lcmF0ZWRDb250ZW50LnRyaW0oKTtcbiAgICAgICAgY2xlYW5Kc29uID0gY2xlYW5Kc29uLnJlcGxhY2UoL15gYGAoPzpqc29uKT9cXHMqL2ksIFwiXCIpLnJlcGxhY2UoL1xccypgYGAkLywgXCJcIik7XG4gICAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UoY2xlYW5Kc29uKTtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgdGl0bGU6IChwYXJzZWQudGl0bGUgfHwgXCJcIikudHJpbSgpLFxuICAgICAgICAgICAgY29udGVudDogKHBhcnNlZC5jb250ZW50IHx8IFwiXCIpLnRyaW0oKSxcbiAgICAgICAgICAgIHN1Z2dlc3RlZFRhZ3M6IEFycmF5LmlzQXJyYXkocGFyc2VkLnRhZ3MpID8gcGFyc2VkLnRhZ3MgOiBbXSxcbiAgICAgICAgICAgIG1vZGUsXG4gICAgICAgICAgICBwcmljZSxcbiAgICAgICAgICAgIG1lc3NhZ2U6IE1FU1NBR0VTW21vZGVdLFxuICAgICAgICAgIH0pLFxuICAgICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgY29uc3QgbGluZXMgPSBnZW5lcmF0ZWRDb250ZW50LnRyaW0oKS5zcGxpdChcIlxcblwiKTtcbiAgICAgICAgY29uc3QgZmFsbGJhY2tUaXRsZSA9IGxpbmVzWzBdLnJlcGxhY2UoL15bXCIjKl0rfFtcIiMqXSskL2csIFwiXCIpLnRyaW0oKTtcbiAgICAgICAgY29uc3QgZmFsbGJhY2tDb250ZW50ID0gbGluZXMuc2xpY2UoMSkuam9pbihcIlxcblwiKS50cmltKCk7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgIHRpdGxlOiBmYWxsYmFja1RpdGxlLFxuICAgICAgICAgICAgY29udGVudDogZmFsbGJhY2tDb250ZW50IHx8IGdlbmVyYXRlZENvbnRlbnQudHJpbSgpLFxuICAgICAgICAgICAgc3VnZ2VzdGVkVGFnczogW10sXG4gICAgICAgICAgICBtb2RlLFxuICAgICAgICAgICAgcHJpY2UsXG4gICAgICAgICAgICBtZXNzYWdlOiBNRVNTQUdFU1ttb2RlXSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgIHJlc3VsdDogZ2VuZXJhdGVkQ29udGVudC50cmltKCksXG4gICAgICAgIG1vZGUsXG4gICAgICAgIHByaWNlLFxuICAgICAgICBtZXNzYWdlOiBNRVNTQUdFU1ttb2RlXSxcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJbZm9ydW0tYWktaGVscGVyXSBFcnJvcjpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwi0J3QtdC40LfQstC10YHRgtC90LDRjyDQvtGI0LjQsdC60LBcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FDRTtBQUNKO0FBWUEsTUFBTSxrQkFBa0I7QUFFeEIsTUFBTSxnQkFBc0M7RUFDMUMsYUFBYTtFQUNiLGNBQWM7RUFDZCxpQkFBaUI7RUFDakIsY0FBYztFQUNkLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLFdBQVc7QUFDYjtBQUVBLE1BQU0saUJBQXVDO0VBQzNDLGFBQWE7RUFDYixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGNBQWM7RUFDZCxjQUFjO0VBQ2Qsa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQixXQUFXO0FBQ2I7QUFFQSxNQUFNLFdBQWlDO0VBQ3JDLGFBQWE7RUFDYixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGNBQWM7RUFDZCxjQUFjO0VBQ2Qsa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQixXQUFXO0FBQ2I7QUFFQSxNQUFNLGFBQWE7RUFDakI7RUFBVztFQUFXO0VBQVc7RUFBVztFQUM1QztFQUFXO0VBQVc7RUFBVztFQUFXO0VBQzVDO0VBQVc7RUFBVztFQUFXO0VBQVc7RUFDNUM7RUFBVztFQUFXO0VBQVc7RUFBVztDQUM3QztBQUVELFNBQVMsYUFDUCxJQUFVLEVBQ1YsSUFBd0IsRUFDeEIsVUFBOEIsRUFDOUIsWUFBZ0MsRUFDaEMsV0FBK0I7RUFFL0IsTUFBTSxlQUFlLGFBQWEsQ0FBQyxrQkFBa0IsRUFBRSxXQUFXLENBQUMsQ0FBQyxHQUFHO0VBQ3ZFLE1BQU0saUJBQWlCLGVBQ25CLENBQUMsaUJBQWlCLEVBQUUsYUFBYSxPQUFPLENBQUMsWUFBWSxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUN4RTtFQUVKLE9BQVE7SUFDTixLQUFLO01BQ0gsT0FBTztRQUNMLGNBQWMsQ0FBQzs7Ozs7Ozs7Ozs7O21FQVk0QyxDQUFDO1FBQzVELFlBQVksQ0FBQywyQ0FBMkMsRUFBRSxLQUFLLENBQUM7TUFDbEU7SUFFRixLQUFLO01BQ0gsT0FBTztRQUNMLGNBQWMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7bURBNkI0QixDQUFDO1FBQzVDLFlBQVksQ0FBQyxvREFBb0QsRUFBRSxLQUFLLENBQUM7TUFDM0U7SUFFRixLQUFLO01BQ0gsT0FBTztRQUNMLGNBQWMsQ0FBQzs7Ozs7Ozs7Ozs7OzhDQVl1QixDQUFDO1FBQ3ZDLFlBQVksQ0FBQyxFQUFFLGFBQWEsRUFBRSxlQUFlLDhDQUE4QyxFQUFFLEtBQUssQ0FBQztNQUNyRztJQUVGLEtBQUs7TUFDSCxPQUFPO1FBQ0wsY0FBYyxDQUFDOzs7Ozs7Ozs7OztrREFXMkIsQ0FBQztRQUMzQyxZQUFZLENBQUMsc0JBQXNCLEVBQUUsS0FBSyxDQUFDO01BQzdDO0lBRUYsS0FBSztNQUNILE9BQU87UUFDTCxjQUFjLENBQUM7Ozs7Ozs7Ozs7bURBVTRCLENBQUM7UUFDNUMsWUFBWSxDQUFDLEVBQUUsYUFBYSxFQUFFLGVBQWUsd0JBQXdCLEVBQUUsZUFBZSxvQkFBb0IsQ0FBQztNQUM3RztJQUVGLEtBQUs7TUFDSCxPQUFPO1FBQ0wsY0FBYyxDQUFDOzs7Ozs7Ozs7Z0RBU3lCLENBQUM7UUFDekMsWUFBWSxDQUFDLEVBQUUsYUFBYSxFQUFFLGVBQWUsNEJBQTRCLEVBQUUsZUFBZSxxQkFBcUIsNkJBQTZCLENBQUM7TUFDL0k7SUFFRixLQUFLO01BQ0gsT0FBTztRQUNMLGNBQWMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7d0VBb0JpRCxDQUFDO1FBQ2pFLFlBQVksQ0FBQyxpQkFBaUIsRUFBRSxjQUFjLEdBQUcsa0JBQWtCLEVBQUUsUUFBUSxnQkFBZ0Isc0JBQXNCLENBQUM7TUFDdEg7SUFFRjtNQUNFLHdCQUF3QjtNQUN4QixPQUFPO1FBQ0wsY0FBYyxDQUFDOzs7Ozs7Ozs7NkNBU3NCLENBQUM7UUFDdEMsWUFBWSxDQUFDLEVBQUUsYUFBYSxFQUFFLGVBQWUsNkNBQTZDLEVBQUUsS0FBSyxDQUFDO01BQ3BHO0VBQ0o7QUFDRjtBQUVBLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVksV0FBVyxZQUFZO01BQ3RDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF5QixJQUNqRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFdBQVcsYUFDZixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsaUJBQ2IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBR2YsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBRWpFLElBQUksYUFBYSxDQUFDLE1BQU0sUUFBUSxLQUFLO01BQ25DLFFBQVEsS0FBSyxDQUFDLGVBQWU7TUFDN0IsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTZCLElBQ3JEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sVUFBVSxLQUFLLE1BQU0sQ0FBQyxHQUFHO0lBQy9CLE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxZQUFZLEVBQUUsV0FBVyxFQUFFLE9BQU8sRUFBRSxHQUFHLE1BQU0sSUFBSSxJQUFJO0lBU3JGLFFBQVEsR0FBRyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxPQUFPLEVBQUUsUUFBUSxVQUFVLEVBQUUsTUFBTSxVQUFVLEVBQUUsQ0FBQztJQUUzRixNQUFNLGdCQUFnQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLGVBQWU7TUFDbEIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSx3Q0FBd0M7SUFDeEMsTUFBTSxjQUFjLGFBQWEsQ0FBQyxLQUFLO0lBQ3ZDLElBQUksQ0FBQyxhQUFhO01BQ2hCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTyxDQUFDLG1CQUFtQixFQUFFLEtBQUssQ0FBQztNQUFDLElBQ3JEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxHQUFHLE1BQU0sU0FDN0IsSUFBSSxDQUFDLGtCQUNMLE1BQU0sQ0FBQyx3QkFDUCxFQUFFLENBQUMsUUFBUSxhQUNYLFdBQVc7SUFFZCxJQUFJLFdBQVcsQ0FBQyxRQUFRLFNBQVMsRUFBRTtNQUNqQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBaUMsSUFDekQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxRQUFRLFNBQVMsYUFBYSxjQUFjLENBQUMsS0FBSztJQUN4RCxNQUFNLGFBQWEsVUFBVTtJQUU3QixJQUFJLFVBQXNDO0lBQzFDLElBQUksYUFBYTtJQUVqQixJQUFJLENBQUMsWUFBWTtNQUNmLGdCQUFnQjtNQUNoQixNQUFNLEVBQUUsTUFBTSxXQUFXLEVBQUUsR0FBRyxNQUFNLFNBQ2pDLElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQyxXQUNQLEVBQUUsQ0FBQyxXQUFXLFNBQ2QsV0FBVztNQUNkLFVBQVU7TUFFVixJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSSxPQUFPO1FBQzlDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztVQUFtQyxVQUFVO1VBQU8sU0FBUyxTQUFTLFdBQVc7UUFBRSxJQUMzRztVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSxpQkFBaUI7TUFDakIsYUFBYSxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSTtNQUN0QyxNQUFNLEVBQUUsT0FBTyxZQUFZLEVBQUUsR0FBRyxNQUFNLFNBQ25DLElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQztRQUFFLFNBQVM7TUFBVyxHQUM3QixFQUFFLENBQUMsV0FBVztNQUVqQixJQUFJLGNBQWM7UUFDaEIsTUFBTSxJQUFJLE1BQU07TUFDbEI7TUFFQSxrQkFBa0I7TUFDbEIsTUFBTSxTQUFTLElBQUksQ0FBQyx3QkFBd0IsTUFBTSxDQUFDO1FBQ2pELFNBQVM7UUFDVCxRQUFRLENBQUM7UUFDVCxlQUFlO1FBQ2YsTUFBTTtRQUNOLGFBQWEsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUM7UUFDbEQsVUFBVTtVQUFFO1VBQU07UUFBVztNQUMvQjtJQUNGO0lBRUEsTUFBTSxFQUFFLFlBQVksRUFBRSxVQUFVLEVBQUUsR0FBRyxhQUFhLE1BQU0sTUFBTSxZQUFZLGNBQWM7SUFFeEYseUJBQXlCO0lBQ3pCLE1BQU0sU0FBUyxDQUFDLG1EQUFtRCxFQUFFLGdCQUFnQixvQkFBb0IsQ0FBQztJQUUxRyxNQUFNLFdBQVcsTUFBTSxNQUFNLFFBQVE7TUFDbkMsUUFBUTtNQUNSLFNBQVM7UUFDUCxnQkFBZ0I7UUFDaEIsZUFBZSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUM7UUFDeEMsa0JBQWtCO01BQ3BCO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztRQUNuQixPQUFPO1FBQ1AsVUFBVTtVQUNSO1lBQUUsTUFBTTtZQUFVLFNBQVM7VUFBYTtVQUN4QztZQUFFLE1BQU07WUFBUSxTQUFTO1VBQVc7U0FDckM7UUFDRCxhQUFhLFNBQVMsaUJBQWlCLFNBQVMsY0FBYyxNQUFNO01BQ3RFO0lBQ0Y7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDJDQUEyQyxFQUFFLFNBQVMsTUFBTSxDQUFDLENBQUM7SUFFM0UsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLHFDQUFxQztNQUNyQyxJQUFJLENBQUMsY0FBYyxTQUFTO1FBQzFCLE1BQU0sU0FDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7VUFBRSxTQUFTLFFBQVEsT0FBTztRQUFDLEdBQ2xDLEVBQUUsQ0FBQyxXQUFXO01BQ25CO01BRUEsTUFBTSxZQUFZLE1BQU0sU0FBUyxJQUFJO01BQ3JDLFFBQVEsS0FBSyxDQUFDLHdDQUF3QyxTQUFTLE1BQU0sRUFBRTtNQUN2RSxNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sU0FBUyxNQUFNLFNBQVMsSUFBSTtJQUNsQyxNQUFNLG1CQUFtQixPQUFPLE9BQU8sRUFBRSxDQUFDLEVBQUUsRUFBRSxTQUFTO0lBRXZELElBQUksQ0FBQyxrQkFBa0I7TUFDckIsSUFBSSxDQUFDLGNBQWMsU0FBUztRQUMxQixNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1VBQUUsU0FBUyxRQUFRLE9BQU87UUFBQyxHQUNsQyxFQUFFLENBQUMsV0FBVztNQUNuQjtNQUNBLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEscURBQXFEO0lBQ3JELElBQUksU0FBUyxhQUFhO01BQ3hCLElBQUk7UUFDRixJQUFJLFlBQVksaUJBQWlCLElBQUk7UUFDckMseUJBQXlCO1FBQ3pCLFlBQVksVUFBVSxPQUFPLENBQUMsZ0JBQWdCLElBQUksT0FBTyxDQUFDLFdBQVcsSUFBSSxJQUFJO1FBQzdFLDZCQUE2QjtRQUM3QixNQUFNLFdBQVcsVUFBVSxPQUFPLENBQUM7UUFDbkMsTUFBTSxTQUFTLFVBQVUsV0FBVyxDQUFDO1FBQ3JDLElBQUksYUFBYSxDQUFDLEtBQUssV0FBVyxDQUFDLEdBQUc7VUFDcEMsWUFBWSxVQUFVLFNBQVMsQ0FBQyxVQUFVLFNBQVM7UUFDckQ7UUFDQSxvQkFBb0I7UUFDcEIsWUFBWSxVQUNULE9BQU8sQ0FBQyxVQUFVLEtBQ2xCLE9BQU8sQ0FBQyxvQkFBb0I7UUFFL0IsTUFBTSxPQUE0QyxLQUFLLEtBQUssQ0FBQztRQUM3RCxRQUFRLEdBQUcsQ0FBQyxDQUFDLG1DQUFtQyxFQUFFLEtBQUssTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBRXZFLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxTQUFTLEtBQUssTUFBTSxLQUFLLEdBQUc7VUFDN0MsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7WUFBRSxTQUFTO1lBQU0sTUFBTSxFQUFFO1lBQUU7WUFBTSxTQUFTO1VBQXVCLElBQ2hGO1lBQUUsU0FBUztjQUFFLEdBQUcsV0FBVztjQUFFLGdCQUFnQjtZQUFtQjtVQUFFO1FBRXRFO1FBRUEsTUFBTSxnQkFBMEIsRUFBRTtRQUNsQyxNQUFNLGNBQThFLEVBQUU7UUFFdEYsS0FBSyxNQUFNLE9BQU8sS0FBSyxLQUFLLENBQUMsR0FBRyxHQUFJO1VBQ2xDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksT0FBTyxFQUFFO1VBRS9CLE1BQU0sT0FBTyxJQUFJLElBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsSUFBSSxLQUFLLENBQUMsR0FBRztVQUN4RSxNQUFNLFNBQVMsSUFBSSxPQUFPLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxHQUFHO1VBQzNDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUTtVQUV0Qiw4QkFBOEI7VUFDOUIsTUFBTSxFQUFFLE1BQU0sUUFBUSxFQUFFLEdBQUcsTUFBTSxTQUM5QixJQUFJLENBQUMsY0FDTCxNQUFNLENBQUMsNEJBQ1AsRUFBRSxDQUFDLFFBQVEsTUFDWCxXQUFXO1VBRWQsSUFBSSxVQUFVO1lBQ1osY0FBYyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQzlCLFlBQVksSUFBSSxDQUFDO1lBQ2pCLHdCQUF3QjtZQUN4QixNQUFNLFNBQ0gsSUFBSSxDQUFDLGNBQ0wsTUFBTSxDQUFDO2NBQUUsYUFBYSxBQUFDLFNBQWlCLFdBQVcsR0FBRyxBQUFDLFNBQWlCLFdBQVcsR0FBRyxJQUFJO1lBQUUsR0FDNUYsRUFBRSxDQUFDLE1BQU0sU0FBUyxFQUFFO1VBQ3pCLE9BQU87WUFDTCxNQUFNLFFBQVEsVUFBVSxDQUFDLEtBQUssS0FBSyxDQUFDLEtBQUssTUFBTSxLQUFLLFdBQVcsTUFBTSxFQUFFO1lBQ3ZFLE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLFFBQVEsRUFBRSxHQUFHLE1BQU0sU0FDN0MsSUFBSSxDQUFDLGNBQ0wsTUFBTSxDQUFDO2NBQUUsTUFBTTtjQUFNLFNBQVM7Y0FBUTtjQUFPLGFBQWE7WUFBRSxHQUM1RCxNQUFNLENBQUMsNEJBQ1AsTUFBTTtZQUVULElBQUksVUFBVTtjQUNaLFFBQVEsS0FBSyxDQUFDLENBQUMsc0NBQXNDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRTtjQUNqRTtZQUNGO1lBQ0EsY0FBYyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQzVCLFlBQVksSUFBSSxDQUFDO1VBQ25CO1FBQ0Y7UUFFQSxxQkFBcUI7UUFDckIsSUFBSSxXQUFXLGNBQWMsTUFBTSxHQUFHLEdBQUc7VUFDdkMsbUNBQW1DO1VBQ25DLE1BQU0sRUFBRSxNQUFNLGFBQWEsRUFBRSxHQUFHLE1BQU0sU0FDbkMsSUFBSSxDQUFDLG9CQUNMLE1BQU0sQ0FBQyxVQUNQLEVBQUUsQ0FBQyxZQUFZO1VBRWxCLE1BQU0saUJBQWlCLElBQUksSUFBSSxDQUFDLGlCQUFpQixFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsSUFBVyxFQUFFLE1BQU07VUFDN0UsTUFBTSxXQUFXLGNBQ2QsTUFBTSxDQUFDLENBQUEsS0FBTSxDQUFDLGVBQWUsR0FBRyxDQUFDLEtBQ2pDLEtBQUssQ0FBQyxHQUFHLElBQUksZUFBZSxJQUFJLEVBQUUsNkJBQTZCO1dBQy9ELEdBQUcsQ0FBQyxDQUFBLFNBQVUsQ0FBQztjQUFFLFVBQVU7Y0FBUztZQUFPLENBQUM7VUFFL0MsSUFBSSxTQUFTLE1BQU0sR0FBRyxHQUFHO1lBQ3ZCLE1BQU0sRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FDaEMsSUFBSSxDQUFDLG9CQUNMLE1BQU0sQ0FBQztZQUNWLElBQUksV0FBVztjQUNiLFFBQVEsS0FBSyxDQUFDLHlDQUF5QztZQUN6RDtVQUNGO1VBQ0EsUUFBUSxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBRSxTQUFTLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxRQUFRLENBQUM7UUFDekY7UUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUNiLFNBQVM7VUFDVCxNQUFNO1VBQ047VUFDQSxTQUFTLFFBQVEsQ0FBQyxLQUFLO1FBQ3pCLElBQ0E7VUFBRSxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFdEUsRUFBRSxPQUFPLFVBQVU7UUFDakIsUUFBUSxLQUFLLENBQUMsNENBQTRDLFVBQVUsUUFBUTtRQUM1RSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLFNBQVM7VUFBTSxNQUFNLEVBQUU7VUFBRTtVQUFNLFNBQVM7UUFBNkIsSUFDdEY7VUFBRSxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFdEU7SUFDRjtJQUVBLDZEQUE2RDtJQUM3RCxJQUFJLFNBQVMsbUJBQW1CO01BQzlCLElBQUk7UUFDRixJQUFJLFlBQVksaUJBQWlCLElBQUk7UUFDckMsWUFBWSxVQUFVLE9BQU8sQ0FBQyxxQkFBcUIsSUFBSSxPQUFPLENBQUMsV0FBVztRQUMxRSxNQUFNLFNBQVMsS0FBSyxLQUFLLENBQUM7UUFDMUIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsT0FBTyxDQUFDLE9BQU8sS0FBSyxJQUFJLEVBQUUsRUFBRSxJQUFJO1VBQ2hDLFNBQVMsQ0FBQyxPQUFPLE9BQU8sSUFBSSxFQUFFLEVBQUUsSUFBSTtVQUNwQyxlQUFlLE1BQU0sT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJLE9BQU8sSUFBSSxHQUFHLEVBQUU7VUFDNUQ7VUFDQTtVQUNBLFNBQVMsUUFBUSxDQUFDLEtBQUs7UUFDekIsSUFDQTtVQUFFLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUV0RSxFQUFFLE9BQU07UUFDTixNQUFNLFFBQVEsaUJBQWlCLElBQUksR0FBRyxLQUFLLENBQUM7UUFDNUMsTUFBTSxnQkFBZ0IsS0FBSyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsb0JBQW9CLElBQUksSUFBSTtRQUNuRSxNQUFNLGtCQUFrQixNQUFNLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLElBQUk7UUFDdEQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsT0FBTztVQUNQLFNBQVMsbUJBQW1CLGlCQUFpQixJQUFJO1VBQ2pELGVBQWUsRUFBRTtVQUNqQjtVQUNBO1VBQ0EsU0FBUyxRQUFRLENBQUMsS0FBSztRQUN6QixJQUNBO1VBQUUsU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRXRFO0lBQ0Y7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxRQUFRLGlCQUFpQixJQUFJO01BQzdCO01BQ0E7TUFDQSxTQUFTLFFBQVEsQ0FBQyxLQUFLO0lBQ3pCLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEUsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDRCQUE0QjtJQUMxQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
// Основные таблицы для экспорта
const TABLES_TO_EXPORT = [
  'profiles',
  'tracks',
  'genres',
  'genre_categories',
  'ai_models',
  'vocal_types',
  'templates',
  'artist_styles',
  'addon_services',
  'user_prompts',
  'generated_lyrics',
  'lyrics_items',
  'playlists',
  'playlist_tracks',
  'track_likes',
  'track_comments',
  'user_follows',
  'payments',
  'subscriptions',
  'subscription_plans',
  'user_roles',
  'settings',
  'notifications',
  'contests',
  'contest_entries',
  'achievements',
  'user_achievements',
  'referral_codes',
  'referrals',
  'store_items',
  'item_purchases'
];
// SHA-256 hash function
async function sha256(message) {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map((b)=>b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}
Deno.serve(async (req)=>{
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({
        error: 'Unauthorized'
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    // Get PIN from request body
    const body = await req.json().catch(()=>({}));
    const pin = body.pin;
    if (!pin || typeof pin !== 'string' || pin.length !== 6) {
      return new Response(JSON.stringify({
        error: 'Требуется 6-значный PIN-код'
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY');
    // Verify user is super_admin
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const token = authHeader.replace('Bearer ', '');
    const { data: claims, error: claimsError } = await userClient.auth.getClaims(token);
    if (claimsError || !claims?.claims) {
      return new Response(JSON.stringify({
        error: 'Invalid token'
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const userId = claims.claims.sub;
    // Use service role for checking role and PIN
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);
    // Check if user is SUPER_ADMIN only
    const { data: userRole } = await adminClient.from('user_roles').select('role').eq('user_id', userId).single();
    if (!userRole || userRole.role !== 'super_admin') {
      console.log('Access denied for user:', userId, 'Role:', userRole?.role);
      return new Response(JSON.stringify({
        error: 'Доступ запрещён. Только для super_admin.'
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    // Verify PIN
    const { data: pinSetting } = await adminClient.from('settings').select('value').eq('key', 'backup_pin_hash').single();
    if (!pinSetting?.value) {
      return new Response(JSON.stringify({
        error: 'PIN-код не настроен'
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const pinHash = await sha256(pin);
    if (pinHash !== pinSetting.value) {
      console.log('Invalid PIN attempt by super_admin:', userId);
      return new Response(JSON.stringify({
        error: 'Неверный PIN-код'
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    console.log('Starting database export for super_admin:', userId);
    const exportData = {
      exported_at: new Date().toISOString(),
      exported_by: userId,
      tables: {}
    };
    const errors = [];
    // Export each table
    for (const tableName of TABLES_TO_EXPORT){
      try {
        const { data, error } = await adminClient.from(tableName).select('*').limit(10000);
        if (error) {
          console.error(`Error exporting ${tableName}:`, error.message);
          errors.push(`${tableName}: ${error.message}`);
          exportData.tables[tableName] = {
            error: error.message,
            count: 0
          };
        } else {
          exportData.tables[tableName] = {
            count: data?.length || 0,
            data: data || []
          };
          console.log(`Exported ${tableName}: ${data?.length || 0} rows`);
        }
      } catch (e) {
        const errorMessage = e instanceof Error ? e.message : String(e);
        console.error(`Exception exporting ${tableName}:`, errorMessage);
        errors.push(`${tableName}: ${errorMessage}`);
        exportData.tables[tableName] = {
          error: errorMessage,
          count: 0
        };
      }
    }
    exportData.errors = errors;
    exportData.tables_count = Object.keys(exportData.tables).length;
    console.log('Export completed. Tables:', exportData.tables_count, 'Errors:', errors.length);
    return new Response(JSON.stringify(exportData, null, 2), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="database-backup-${new Date().toISOString().split('T')[0]}.json"`
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error('Export error:', errorMessage);
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9leHBvcnQtZGF0YWJhc2UvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6ICdhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZScsXG59O1xuXG4vLyDQntGB0L3QvtCy0L3Ri9C1INGC0LDQsdC70LjRhtGLINC00LvRjyDRjdC60YHQv9C+0YDRgtCwXG5jb25zdCBUQUJMRVNfVE9fRVhQT1JUID0gW1xuICAncHJvZmlsZXMnLFxuICAndHJhY2tzJyxcbiAgJ2dlbnJlcycsXG4gICdnZW5yZV9jYXRlZ29yaWVzJyxcbiAgJ2FpX21vZGVscycsXG4gICd2b2NhbF90eXBlcycsXG4gICd0ZW1wbGF0ZXMnLFxuICAnYXJ0aXN0X3N0eWxlcycsXG4gICdhZGRvbl9zZXJ2aWNlcycsXG4gICd1c2VyX3Byb21wdHMnLFxuICAnZ2VuZXJhdGVkX2x5cmljcycsXG4gICdseXJpY3NfaXRlbXMnLFxuICAncGxheWxpc3RzJyxcbiAgJ3BsYXlsaXN0X3RyYWNrcycsXG4gICd0cmFja19saWtlcycsXG4gICd0cmFja19jb21tZW50cycsXG4gICd1c2VyX2ZvbGxvd3MnLFxuICAncGF5bWVudHMnLFxuICAnc3Vic2NyaXB0aW9ucycsXG4gICdzdWJzY3JpcHRpb25fcGxhbnMnLFxuICAndXNlcl9yb2xlcycsXG4gICdzZXR0aW5ncycsXG4gICdub3RpZmljYXRpb25zJyxcbiAgJ2NvbnRlc3RzJyxcbiAgJ2NvbnRlc3RfZW50cmllcycsXG4gICdhY2hpZXZlbWVudHMnLFxuICAndXNlcl9hY2hpZXZlbWVudHMnLFxuICAncmVmZXJyYWxfY29kZXMnLFxuICAncmVmZXJyYWxzJyxcbiAgJ3N0b3JlX2l0ZW1zJyxcbiAgJ2l0ZW1fcHVyY2hhc2VzJyxcbl07XG5cbi8vIFNIQS0yNTYgaGFzaCBmdW5jdGlvblxuYXN5bmMgZnVuY3Rpb24gc2hhMjU2KG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IG1zZ0J1ZmZlciA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShtZXNzYWdlKTtcbiAgY29uc3QgaGFzaEJ1ZmZlciA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgbXNnQnVmZmVyKTtcbiAgY29uc3QgaGFzaEFycmF5ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShoYXNoQnVmZmVyKSk7XG4gIGNvbnN0IGhhc2hIZXggPSBoYXNoQXJyYXkubWFwKGIgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSkuam9pbignJyk7XG4gIHJldHVybiBoYXNoSGV4O1xufVxuXG5EZW5vLnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgLy8gSGFuZGxlIENPUlMgcHJlZmxpZ2h0XG4gIGlmIChyZXEubWV0aG9kID09PSAnT1BUSU9OUycpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKCdvaycsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoJ0F1dGhvcml6YXRpb24nKTtcbiAgICBpZiAoIWF1dGhIZWFkZXI/LnN0YXJ0c1dpdGgoJ0JlYXJlciAnKSkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ1VuYXV0aG9yaXplZCcgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIEdldCBQSU4gZnJvbSByZXF1ZXN0IGJvZHlcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVxLmpzb24oKS5jYXRjaCgoKSA9PiAoe30pKTtcbiAgICBjb25zdCBwaW4gPSBib2R5LnBpbjtcblxuICAgIGlmICghcGluIHx8IHR5cGVvZiBwaW4gIT09ICdzdHJpbmcnIHx8IHBpbi5sZW5ndGggIT09IDYpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICfQotGA0LXQsdGD0LXRgtGB0Y8gNi3Qt9C90LDRh9C90YvQuSBQSU4t0LrQvtC0JyB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoJ1NVUEFCQVNFX1VSTCcpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoJ1NVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVknKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VBbm9uS2V5ID0gRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9BTk9OX0tFWScpITtcblxuICAgIC8vIFZlcmlmeSB1c2VyIGlzIHN1cGVyX2FkbWluXG4gICAgY29uc3QgdXNlckNsaWVudCA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VBbm9uS2V5LCB7XG4gICAgICBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfVxuICAgIH0pO1xuXG4gICAgY29uc3QgdG9rZW4gPSBhdXRoSGVhZGVyLnJlcGxhY2UoJ0JlYXJlciAnLCAnJyk7XG4gICAgY29uc3QgeyBkYXRhOiBjbGFpbXMsIGVycm9yOiBjbGFpbXNFcnJvciB9ID0gYXdhaXQgdXNlckNsaWVudC5hdXRoLmdldENsYWltcyh0b2tlbik7XG4gICAgXG4gICAgaWYgKGNsYWltc0Vycm9yIHx8ICFjbGFpbXM/LmNsYWltcykge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ0ludmFsaWQgdG9rZW4nIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB1c2VySWQgPSBjbGFpbXMuY2xhaW1zLnN1YjtcblxuICAgIC8vIFVzZSBzZXJ2aWNlIHJvbGUgZm9yIGNoZWNraW5nIHJvbGUgYW5kIFBJTlxuICAgIGNvbnN0IGFkbWluQ2xpZW50ID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgLy8gQ2hlY2sgaWYgdXNlciBpcyBTVVBFUl9BRE1JTiBvbmx5XG4gICAgY29uc3QgeyBkYXRhOiB1c2VyUm9sZSB9ID0gYXdhaXQgYWRtaW5DbGllbnRcbiAgICAgIC5mcm9tKCd1c2VyX3JvbGVzJylcbiAgICAgIC5zZWxlY3QoJ3JvbGUnKVxuICAgICAgLmVxKCd1c2VyX2lkJywgdXNlcklkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKCF1c2VyUm9sZSB8fCB1c2VyUm9sZS5yb2xlICE9PSAnc3VwZXJfYWRtaW4nKSB7XG4gICAgICBjb25zb2xlLmxvZygnQWNjZXNzIGRlbmllZCBmb3IgdXNlcjonLCB1c2VySWQsICdSb2xlOicsIHVzZXJSb2xlPy5yb2xlKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICfQlNC+0YHRgtGD0L8g0LfQsNC/0YDQtdGJ0ZHQvS4g0KLQvtC70YzQutC+INC00LvRjyBzdXBlcl9hZG1pbi4nIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBWZXJpZnkgUElOXG4gICAgY29uc3QgeyBkYXRhOiBwaW5TZXR0aW5nIH0gPSBhd2FpdCBhZG1pbkNsaWVudFxuICAgICAgLmZyb20oJ3NldHRpbmdzJylcbiAgICAgIC5zZWxlY3QoJ3ZhbHVlJylcbiAgICAgIC5lcSgna2V5JywgJ2JhY2t1cF9waW5faGFzaCcpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoIXBpblNldHRpbmc/LnZhbHVlKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAnUElOLdC60L7QtCDQvdC1INC90LDRgdGC0YDQvtC10L0nIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBwaW5IYXNoID0gYXdhaXQgc2hhMjU2KHBpbik7XG4gICAgXG4gICAgaWYgKHBpbkhhc2ggIT09IHBpblNldHRpbmcudmFsdWUpIHtcbiAgICAgIGNvbnNvbGUubG9nKCdJbnZhbGlkIFBJTiBhdHRlbXB0IGJ5IHN1cGVyX2FkbWluOicsIHVzZXJJZCk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAn0J3QtdCy0LXRgNC90YvQuSBQSU4t0LrQvtC0JyB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMywgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coJ1N0YXJ0aW5nIGRhdGFiYXNlIGV4cG9ydCBmb3Igc3VwZXJfYWRtaW46JywgdXNlcklkKTtcblxuICAgIGNvbnN0IGV4cG9ydERhdGE6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgICAgZXhwb3J0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGV4cG9ydGVkX2J5OiB1c2VySWQsXG4gICAgICB0YWJsZXM6IHt9XG4gICAgfTtcblxuICAgIGNvbnN0IGVycm9yczogc3RyaW5nW10gPSBbXTtcblxuICAgIC8vIEV4cG9ydCBlYWNoIHRhYmxlXG4gICAgZm9yIChjb25zdCB0YWJsZU5hbWUgb2YgVEFCTEVTX1RPX0VYUE9SVCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgYWRtaW5DbGllbnRcbiAgICAgICAgICAuZnJvbSh0YWJsZU5hbWUpXG4gICAgICAgICAgLnNlbGVjdCgnKicpXG4gICAgICAgICAgLmxpbWl0KDEwMDAwKTtcblxuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBleHBvcnRpbmcgJHt0YWJsZU5hbWV9OmAsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICAgIGVycm9ycy5wdXNoKGAke3RhYmxlTmFtZX06ICR7ZXJyb3IubWVzc2FnZX1gKTtcbiAgICAgICAgICAoZXhwb3J0RGF0YS50YWJsZXMgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW3RhYmxlTmFtZV0gPSB7IGVycm9yOiBlcnJvci5tZXNzYWdlLCBjb3VudDogMCB9O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIChleHBvcnREYXRhLnRhYmxlcyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilbdGFibGVOYW1lXSA9IHtcbiAgICAgICAgICAgIGNvdW50OiBkYXRhPy5sZW5ndGggfHwgMCxcbiAgICAgICAgICAgIGRhdGE6IGRhdGEgfHwgW11cbiAgICAgICAgICB9O1xuICAgICAgICAgIGNvbnNvbGUubG9nKGBFeHBvcnRlZCAke3RhYmxlTmFtZX06ICR7ZGF0YT8ubGVuZ3RoIHx8IDB9IHJvd3NgKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZTogdW5rbm93bikge1xuICAgICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBTdHJpbmcoZSk7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEV4Y2VwdGlvbiBleHBvcnRpbmcgJHt0YWJsZU5hbWV9OmAsIGVycm9yTWVzc2FnZSk7XG4gICAgICAgIGVycm9ycy5wdXNoKGAke3RhYmxlTmFtZX06ICR7ZXJyb3JNZXNzYWdlfWApO1xuICAgICAgICAoZXhwb3J0RGF0YS50YWJsZXMgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW3RhYmxlTmFtZV0gPSB7IGVycm9yOiBlcnJvck1lc3NhZ2UsIGNvdW50OiAwIH07XG4gICAgICB9XG4gICAgfVxuXG4gICAgZXhwb3J0RGF0YS5lcnJvcnMgPSBlcnJvcnM7XG4gICAgZXhwb3J0RGF0YS50YWJsZXNfY291bnQgPSBPYmplY3Qua2V5cyhleHBvcnREYXRhLnRhYmxlcyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikubGVuZ3RoO1xuXG4gICAgY29uc29sZS5sb2coJ0V4cG9ydCBjb21wbGV0ZWQuIFRhYmxlczonLCBleHBvcnREYXRhLnRhYmxlc19jb3VudCwgJ0Vycm9yczonLCBlcnJvcnMubGVuZ3RoKTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeShleHBvcnREYXRhLCBudWxsLCAyKSxcbiAgICAgIHsgXG4gICAgICAgIGhlYWRlcnM6IHsgXG4gICAgICAgICAgLi4uY29yc0hlYWRlcnMsIFxuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgJ0NvbnRlbnQtRGlzcG9zaXRpb24nOiBgYXR0YWNobWVudDsgZmlsZW5hbWU9XCJkYXRhYmFzZS1iYWNrdXAtJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXX0uanNvblwiYFxuICAgICAgICB9IFxuICAgICAgfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFN0cmluZyhlcnJvcik7XG4gICAgY29uc29sZS5lcnJvcignRXhwb3J0IGVycm9yOicsIGVycm9yTWVzc2FnZSk7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGVycm9yTWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsZ0NBQWdDO0FBQ2hDLE1BQU0sbUJBQW1CO0VBQ3ZCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Q7QUFFRCx3QkFBd0I7QUFDeEIsZUFBZSxPQUFPLE9BQWU7RUFDbkMsTUFBTSxZQUFZLElBQUksY0FBYyxNQUFNLENBQUM7RUFDM0MsTUFBTSxhQUFhLE1BQU0sT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVc7RUFDekQsTUFBTSxZQUFZLE1BQU0sSUFBSSxDQUFDLElBQUksV0FBVztFQUM1QyxNQUFNLFVBQVUsVUFBVSxHQUFHLENBQUMsQ0FBQSxJQUFLLEVBQUUsUUFBUSxDQUFDLElBQUksUUFBUSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUM7RUFDekUsT0FBTztBQUNUO0FBRUEsS0FBSyxLQUFLLENBQUMsT0FBTztFQUNoQix3QkFBd0I7RUFDeEIsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWSxXQUFXLFlBQVk7TUFDdEMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWUsSUFDdkM7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsNEJBQTRCO0lBQzVCLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFNLENBQUMsQ0FBQyxDQUFDO0lBQzdDLE1BQU0sTUFBTSxLQUFLLEdBQUc7SUFFcEIsSUFBSSxDQUFDLE9BQU8sT0FBTyxRQUFRLFlBQVksSUFBSSxNQUFNLEtBQUssR0FBRztNQUN2RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBOEIsSUFDdEQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDeEMsTUFBTSxrQkFBa0IsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBRXJDLDZCQUE2QjtJQUM3QixNQUFNLGFBQWEsYUFBYSxhQUFhLGlCQUFpQjtNQUM1RCxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQ25EO0lBRUEsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxXQUFXLElBQUksQ0FBQyxTQUFTLENBQUM7SUFFN0UsSUFBSSxlQUFlLENBQUMsUUFBUSxRQUFRO01BQ2xDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFnQixJQUN4QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFNBQVMsT0FBTyxNQUFNLENBQUMsR0FBRztJQUVoQyw2Q0FBNkM7SUFDN0MsTUFBTSxjQUFjLGFBQWEsYUFBYTtJQUU5QyxvQ0FBb0M7SUFDcEMsTUFBTSxFQUFFLE1BQU0sUUFBUSxFQUFFLEdBQUcsTUFBTSxZQUM5QixJQUFJLENBQUMsY0FDTCxNQUFNLENBQUMsUUFDUCxFQUFFLENBQUMsV0FBVyxRQUNkLE1BQU07SUFFVCxJQUFJLENBQUMsWUFBWSxTQUFTLElBQUksS0FBSyxlQUFlO01BQ2hELFFBQVEsR0FBRyxDQUFDLDJCQUEyQixRQUFRLFNBQVMsVUFBVTtNQUNsRSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBMkMsSUFDbkU7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsYUFBYTtJQUNiLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxHQUFHLE1BQU0sWUFDaEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFNBQ1AsRUFBRSxDQUFDLE9BQU8sbUJBQ1YsTUFBTTtJQUVULElBQUksQ0FBQyxZQUFZLE9BQU87TUFDdEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQXNCLElBQzlDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sVUFBVSxNQUFNLE9BQU87SUFFN0IsSUFBSSxZQUFZLFdBQVcsS0FBSyxFQUFFO01BQ2hDLFFBQVEsR0FBRyxDQUFDLHVDQUF1QztNQUNuRCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBbUIsSUFDM0M7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsUUFBUSxHQUFHLENBQUMsNkNBQTZDO0lBRXpELE1BQU0sYUFBc0M7TUFDMUMsYUFBYSxJQUFJLE9BQU8sV0FBVztNQUNuQyxhQUFhO01BQ2IsUUFBUSxDQUFDO0lBQ1g7SUFFQSxNQUFNLFNBQW1CLEVBQUU7SUFFM0Isb0JBQW9CO0lBQ3BCLEtBQUssTUFBTSxhQUFhLGlCQUFrQjtNQUN4QyxJQUFJO1FBQ0YsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFlBQzNCLElBQUksQ0FBQyxXQUNMLE1BQU0sQ0FBQyxLQUNQLEtBQUssQ0FBQztRQUVULElBQUksT0FBTztVQUNULFFBQVEsS0FBSyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsVUFBVSxDQUFDLENBQUMsRUFBRSxNQUFNLE9BQU87VUFDNUQsT0FBTyxJQUFJLENBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBRSxFQUFFLE1BQU0sT0FBTyxDQUFDLENBQUM7VUFDM0MsV0FBVyxNQUFNLEFBQTRCLENBQUMsVUFBVSxHQUFHO1lBQUUsT0FBTyxNQUFNLE9BQU87WUFBRSxPQUFPO1VBQUU7UUFDL0YsT0FBTztVQUNKLFdBQVcsTUFBTSxBQUE0QixDQUFDLFVBQVUsR0FBRztZQUMxRCxPQUFPLE1BQU0sVUFBVTtZQUN2QixNQUFNLFFBQVEsRUFBRTtVQUNsQjtVQUNBLFFBQVEsR0FBRyxDQUFDLENBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxFQUFFLE1BQU0sVUFBVSxFQUFFLEtBQUssQ0FBQztRQUNoRTtNQUNGLEVBQUUsT0FBTyxHQUFZO1FBQ25CLE1BQU0sZUFBZSxhQUFhLFFBQVEsRUFBRSxPQUFPLEdBQUcsT0FBTztRQUM3RCxRQUFRLEtBQUssQ0FBQyxDQUFDLG9CQUFvQixFQUFFLFVBQVUsQ0FBQyxDQUFDLEVBQUU7UUFDbkQsT0FBTyxJQUFJLENBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBRSxFQUFFLGFBQWEsQ0FBQztRQUMxQyxXQUFXLE1BQU0sQUFBNEIsQ0FBQyxVQUFVLEdBQUc7VUFBRSxPQUFPO1VBQWMsT0FBTztRQUFFO01BQzlGO0lBQ0Y7SUFFQSxXQUFXLE1BQU0sR0FBRztJQUNwQixXQUFXLFlBQVksR0FBRyxPQUFPLElBQUksQ0FBQyxXQUFXLE1BQU0sRUFBNkIsTUFBTTtJQUUxRixRQUFRLEdBQUcsQ0FBQyw2QkFBNkIsV0FBVyxZQUFZLEVBQUUsV0FBVyxPQUFPLE1BQU07SUFFMUYsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUMsWUFBWSxNQUFNLElBQ2pDO01BQ0UsU0FBUztRQUNQLEdBQUcsV0FBVztRQUNkLGdCQUFnQjtRQUNoQix1QkFBdUIsQ0FBQyxzQ0FBc0MsRUFBRSxJQUFJLE9BQU8sV0FBVyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztNQUNoSDtJQUNGO0VBR0osRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLE1BQU0sZUFBZSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRyxPQUFPO0lBQ3JFLFFBQVEsS0FBSyxDQUFDLGlCQUFpQjtJQUMvQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBYSxJQUNyQztNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRiJ9
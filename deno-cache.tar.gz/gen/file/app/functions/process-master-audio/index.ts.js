import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
const PROCESSING_STAGES = [
  {
    id: 'validating',
    name: 'Проверка формата WAV 24-bit'
  },
  {
    id: 'upscale_detection',
    name: 'Детектор апскейла (спектральный анализ)'
  },
  {
    id: 'loudness_analysis',
    name: 'Анализ громкости (LUFS)'
  },
  {
    id: 'normalization',
    name: 'Нормализация до -14 LUFS'
  },
  {
    id: 'metadata_cleaning',
    name: 'Очистка и запись метаданных'
  },
  {
    id: 'blockchain_hash',
    name: 'Запись хеша в Blockchain (OpenTimestamps)'
  },
  {
    id: 'certificate_generation',
    name: 'Генерация сертификата'
  },
  {
    id: 'gold_pack_assembly',
    name: 'Сборка Золотого пакета'
  }
];
// =============================================
// VPS COMMUNICATION HELPERS
// =============================================
async function callVps(url, endpoint, payload, timeoutMs = 30000, headers) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(()=>controller.abort(), timeoutMs);
    const reqHeaders = {
      'Content-Type': 'application/json',
      ...headers
    };
    const resp = await fetch(`${url}${endpoint}`, {
      method: 'POST',
      headers: reqHeaders,
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (!resp.ok) {
      const errText = await resp.text();
      console.error(`[VPS] ${endpoint} error ${resp.status}: ${errText}`);
      return null;
    }
    return await resp.json();
  } catch (e) {
    console.error(`[VPS] ${endpoint} failed:`, e);
    return null;
  }
}
// Parse VPS /analyze response into structured data
function parseAnalysis(raw) {
  const audioStream = raw.streams?.find((s)=>s.codec_type === 'audio') || {};
  const highFreqCutoff = raw.spectrum?.high_freq_cutoff || 20000;
  const upscaleDetected = highFreqCutoff < 16000;
  const originalLufs = raw.lufs?.integrated ?? -16;
  const peakDb = raw.lufs?.true_peak ?? -1;
  const dynamicRange = raw.lufs?.range ?? 8;
  const sampleRate = parseInt(audioStream.sample_rate) || 44100;
  const bitDepth = audioStream.bits_per_sample || 24;
  const channels = audioStream.channels || 2;
  const duration = parseFloat(raw.format?.duration) || 0;
  const format = raw.format?.format_name || 'unknown';
  let qualityScore = 10;
  if (upscaleDetected) qualityScore -= 3;
  if (sampleRate < 44100) qualityScore -= 2;
  if (bitDepth < 16) qualityScore -= 2;
  if (originalLufs > -8) qualityScore -= 1;
  qualityScore = Math.max(1, Math.min(10, qualityScore));
  return {
    highFreqCutoff,
    upscaleDetected,
    originalLufs,
    peakDb,
    dynamicRange,
    sampleRate,
    bitDepth,
    channels,
    duration,
    format,
    qualityScore,
    masterQuality: bitDepth >= 24 && [
      'wav',
      'flac',
      'aiff'
    ].includes(format)
  };
}
// Compute SHA-256 hash from a URL (downloads and hashes)
async function computeFileHash(fileUrl) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(()=>controller.abort(), 120000); // 2 min for large files
    const resp = await fetch(fileUrl, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (!resp.ok) {
      console.error(`[SHA-256] Download failed: ${resp.status}`);
      return null;
    }
    const buffer = await resp.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashHex = Array.from(new Uint8Array(hashBuffer)).map((b)=>b.toString(16).padStart(2, '0')).join('');
    console.log(`[SHA-256] Computed: ${hashHex} (${(buffer.byteLength / 1024 / 1024).toFixed(1)}MB)`);
    return hashHex;
  } catch (e) {
    console.error(`[SHA-256] Failed:`, e);
    return null;
  }
}
// Submit hash to OpenTimestamps calendar servers
async function submitToOpenTimestamps(hashHex) {
  const hashBytes = new Uint8Array(hashHex.match(/.{2}/g).map((byte)=>parseInt(byte, 16)));
  const calendars = [
    'https://a.pool.opentimestamps.org/digest',
    'https://b.pool.opentimestamps.org/digest',
    'https://finney.calendar.eternitywall.com/digest'
  ];
  for (const calendar of calendars){
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(()=>controller.abort(), 15000);
      const resp = await fetch(calendar, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/octet-stream',
          'Accept': 'application/vnd.opentimestamps.v1'
        },
        body: hashBytes,
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (resp.ok) {
        const proofBytes = new Uint8Array(await resp.arrayBuffer());
        console.log(`[OTS] Proof received from ${calendar} (${proofBytes.length} bytes)`);
        return proofBytes;
      } else {
        const errText = await resp.text();
        console.log(`[OTS] ${calendar} returned ${resp.status}: ${errText}`);
      }
    } catch (e) {
      console.log(`[OTS] ${calendar} failed:`, e);
    }
  }
  console.error('[OTS] All calendar servers failed');
  return null;
}
// =============================================
// MAIN HANDLER
// =============================================
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '');
    const { trackId, masterAudioUrl } = await req.json();
    console.log(`[process-master-audio] ▶ Starting REAL processing for track: ${trackId}`);
    if (!trackId || !masterAudioUrl) {
      throw new Error('trackId and masterAudioUrl are required');
    }
    // Get track info (avoid joins for resilience)
    const { data: track, error: trackError } = await supabase.from('tracks').select('*').eq('id', trackId).maybeSingle();
    if (trackError) {
      console.error('[process-master-audio] DB error:', trackError);
      throw new Error(`Database error: ${trackError.message}`);
    }
    if (!track) {
      throw new Error(`Track not found: ${trackId}`);
    }
    console.log(`[process-master-audio] Track: "${track.title}", user: ${track.user_id}`);
    const VPS_URL = Deno.env.get("VPS_FFMPEG_URL") || "http://217.199.254.170:3001";
    const FFMPEG_API_URL = Deno.env.get("FFMPEG_API_URL");
    const FFMPEG_API_SECRET = Deno.env.get("FFMPEG_API_SECRET");
    const ffmpegHeaders = FFMPEG_API_SECRET ? {
      'x-api-key': FFMPEG_API_SECRET
    } : undefined;
    // Helper: update progress in DB
    let stageIdx = 0;
    const updateStage = async (stageId)=>{
      stageIdx++;
      const progress = Math.round(stageIdx / PROCESSING_STAGES.length * 100);
      console.log(`[process-master-audio] ── Stage ${stageIdx}/${PROCESSING_STAGES.length}: ${stageId} (${progress}%)`);
      await supabase.from('tracks').update({
        processing_stage: stageId,
        processing_progress: progress
      }).eq('id', trackId);
      await supabase.from('distribution_logs').insert({
        track_id: trackId,
        user_id: track.user_id,
        action: `stage_${stageId}`,
        stage: 'level_pro',
        details: {
          stage_name: PROCESSING_STAGES.find((s)=>s.id === stageId)?.name
        }
      });
    };
    // Mark as processing
    await supabase.from('tracks').update({
      distribution_status: 'processing',
      processing_started_at: new Date().toISOString(),
      processing_progress: 0
    }).eq('id', trackId);
    // ========================================
    // STAGE 1-2-3: ANALYZE (validate + upscale + loudness)
    // Single VPS call covers all three stages
    // ========================================
    await updateStage('validating');
    const rawAnalysis = await callVps(VPS_URL, '/analyze', {
      audio_url: masterAudioUrl
    }, 30000, ffmpegHeaders);
    if (!rawAnalysis) {
      console.error('[process-master-audio] ✗ VPS analysis unavailable — aborting');
      await supabase.from('tracks').update({
        distribution_status: 'pending_master',
        processing_stage: null,
        processing_progress: 0
      }).eq('id', trackId);
      await supabase.from('notifications').insert({
        user_id: track.user_id,
        type: 'system',
        title: '❌ Ошибка анализа',
        message: `Не удалось проанализировать мастер-файл для трека "${track.title}". Попробуйте позже или загрузите файл повторно.`,
        target_type: 'track',
        target_id: trackId
      });
      return new Response(JSON.stringify({
        success: false,
        error: 'vps_unavailable',
        message: 'Сервер обработки аудио недоступен'
      }), {
        status: 503,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const analysis = parseAnalysis(rawAnalysis);
    console.log(`[process-master-audio] ✓ Analysis: format=${analysis.format}, ${analysis.bitDepth}bit/${analysis.sampleRate}Hz, LUFS=${analysis.originalLufs}, quality=${analysis.qualityScore}/10`);
    // Save analysis to track_health_reports
    await supabase.from('track_health_reports').upsert({
      track_id: trackId,
      quality_score: analysis.qualityScore,
      lufs_original: analysis.originalLufs,
      peak_db: analysis.peakDb,
      dynamic_range: analysis.dynamicRange,
      spectrum_ok: !analysis.upscaleDetected,
      high_freq_cutoff: analysis.highFreqCutoff,
      upscale_detected: analysis.upscaleDetected,
      sample_rate: analysis.sampleRate,
      bit_depth: analysis.bitDepth,
      channels: analysis.channels,
      duration: analysis.duration,
      format: analysis.format,
      master_quality: analysis.masterQuality,
      analysis_status: 'completed',
      updated_at: new Date().toISOString()
    }, {
      onConflict: 'track_id'
    });
    // STAGE 2: Upscale detection
    await updateStage('upscale_detection');
    if (analysis.upscaleDetected) {
      console.log(`[process-master-audio] ✗ UPSCALE DETECTED: cutoff=${analysis.highFreqCutoff}Hz (threshold 16000Hz)`);
      await supabase.from('tracks').update({
        distribution_status: 'pending_master',
        upscale_detected: true,
        processing_stage: null,
        processing_progress: 0
      }).eq('id', trackId);
      await supabase.from('notifications').insert({
        user_id: track.user_id,
        type: 'system',
        title: '⚠️ Обнаружен апскейл',
        message: `Трек "${track.title}" содержит апскейленный аудиофайл (срез частот на ${analysis.highFreqCutoff}Гц, порог 16000Гц). Пожалуйста, загрузите оригинальный WAV-файл.`,
        target_type: 'track',
        target_id: trackId
      });
      return new Response(JSON.stringify({
        success: false,
        error: 'upscale_detected',
        message: `Обнаружен апскейл (срез на ${analysis.highFreqCutoff}Гц). Загрузите оригинал WAV 24-bit`,
        high_freq_cutoff: analysis.highFreqCutoff
      }), {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    // STAGE 3: Loudness analysis
    await updateStage('loudness_analysis');
    await supabase.from('tracks').update({
      audio_quality_score: analysis.qualityScore,
      audio_sample_rate: analysis.sampleRate,
      audio_bit_depth: analysis.bitDepth,
      audio_lufs: analysis.originalLufs,
      audio_peak_db: analysis.peakDb,
      upscale_detected: false
    }).eq('id', trackId);
    // ========================================
    // STAGE 4: NORMALIZATION (-14 LUFS)
    // ========================================
    await updateStage('normalization');
    let processedUrl = masterAudioUrl;
    let normalizedLufs = analysis.originalLufs;
    const needsNorm = Math.abs(analysis.originalLufs - -14) > 1;
    if (needsNorm) {
      console.log(`[process-master-audio] Normalizing: ${analysis.originalLufs} → -14 LUFS`);
      const normResult = await callVps(VPS_URL, '/normalize', {
        audio_url: masterAudioUrl,
        target_lufs: -14,
        strip_metadata: false,
        brand_metadata: false
      }, 90000, ffmpegHeaders); // 90s for large files
      if (normResult?.normalized_url) {
        processedUrl = normResult.normalized_url;
        normalizedLufs = normResult.normalized_lufs ?? -14;
        console.log(`[process-master-audio] ✓ Normalized: ${analysis.originalLufs} → ${normalizedLufs} LUFS`);
      } else {
        console.log(`[process-master-audio] ⚠ Normalization failed, keeping original`);
      }
    } else {
      console.log(`[process-master-audio] ✓ LUFS within tolerance (${analysis.originalLufs}), no normalization needed`);
    }
    await supabase.from('tracks').update({
      lufs_normalized: true,
      audio_lufs: normalizedLufs,
      normalized_audio_url: processedUrl
    }).eq('id', trackId);
    await supabase.from('track_health_reports').update({
      lufs_normalized: normalizedLufs,
      normalized_audio_url: processedUrl,
      normalization_status: 'completed'
    }).eq('track_id', trackId);
    // ========================================
    // STAGE 5: METADATA CLEANING & BRANDING
    // ========================================
    await updateStage('metadata_cleaning');
    const { data: profile } = await supabase.from('profiles').select('username').eq('user_id', track.user_id).maybeSingle();
    const username = profile?.username || 'Unknown';
    // Use FFMPEG_API_URL (with auth) if available, else VPS_URL
    if (FFMPEG_API_URL && FFMPEG_API_SECRET) {
      console.log(`[process-master-audio] Metadata cleaning via FFMPEG_API_URL`);
      const metaResult = await callVps(FFMPEG_API_URL, '/clean-metadata', {
        audio_url: processedUrl,
        metadata: {
          title: track.title,
          artist: username,
          album: 'AImuza',
          publisher: 'AImuza',
          comment: `Generated on aimuza.ru | User: ${username}`,
          copyright: `© ${new Date().getFullYear()} ${username} via AImuza`,
          custom: {
            TXXX_USER_ID: track.user_id,
            TXXX_USERNAME: username,
            TXXX_WEBSITE: 'aimuza.ru',
            TXXX_DATE: new Date().toISOString().split('T')[0],
            TXXX_TRACK_ID: trackId
          }
        }
      }, 60000, {
        'x-api-key': FFMPEG_API_SECRET
      });
      if (metaResult?.cleaned_url) {
        processedUrl = metaResult.cleaned_url;
        console.log(`[process-master-audio] ✓ Metadata cleaned via FFMPEG API`);
      }
    } else {
      console.log(`[process-master-audio] Metadata cleaning via VPS /normalize`);
      const metaResult = await callVps(VPS_URL, '/normalize', {
        audio_url: processedUrl,
        target_lufs: -14,
        strip_metadata: true,
        brand_metadata: true,
        metadata: {
          artist: username,
          title: track.title,
          album: 'AImuza',
          comment: `Generated on aimuza.ru | User: ${username}`,
          date: new Date().getFullYear().toString(),
          encoder: 'AImuza Music Terminal',
          copyright: `© ${new Date().getFullYear()} ${username} via AImuza`,
          user_id: track.user_id,
          website: 'https://aimuza.ru'
        }
      }, 60000, ffmpegHeaders);
      if (metaResult?.normalized_url) {
        processedUrl = metaResult.normalized_url;
        console.log(`[process-master-audio] ✓ Metadata cleaned via VPS normalize`);
      }
    }
    await supabase.from('tracks').update({
      metadata_cleaned: true,
      metadata_branded: true
    }).eq('id', trackId);
    // ========================================
    // STAGE 6: BLOCKCHAIN HASH (SHA-256 + OpenTimestamps)
    // ========================================
    await updateStage('blockchain_hash');
    // Step 1: Compute real SHA-256 of the final processed file
    const fileHash = await computeFileHash(processedUrl);
    let blockchainHash;
    let otsProofUploaded = false;
    if (fileHash) {
      blockchainHash = `0x${fileHash}`;
      console.log(`[process-master-audio] ✓ Real SHA-256: ${blockchainHash}`);
      // Step 2: Submit to OpenTimestamps (async - don't block)
      const otsProof = await submitToOpenTimestamps(fileHash);
      if (otsProof) {
        // Upload OTS proof to storage
        try {
          const proofFileName = `gold-packs/${trackId}/proof.ots`;
          await supabase.storage.from('tracks').upload(proofFileName, otsProof, {
            upsert: true,
            contentType: 'application/vnd.opentimestamps.v1'
          });
          otsProofUploaded = true;
          console.log(`[process-master-audio] ✓ OTS proof uploaded to storage`);
        } catch (e) {
          console.error(`[process-master-audio] OTS proof upload failed:`, e);
        }
      }
    } else {
      // Fallback: still generate a hash but mark it as local-only
      const fallbackBytes = new TextEncoder().encode(processedUrl + Date.now().toString());
      const fallbackBuffer = await crypto.subtle.digest('SHA-256', fallbackBytes);
      const fallbackHex = Array.from(new Uint8Array(fallbackBuffer)).map((b)=>b.toString(16).padStart(2, '0')).join('');
      blockchainHash = `0xLOCAL_${fallbackHex}`;
      console.log(`[process-master-audio] ⚠ Using fallback hash (file download failed)`);
    }
    await supabase.from('tracks').update({
      blockchain_hash: blockchainHash
    }).eq('id', trackId);
    // ========================================
    // STAGE 7: CERTIFICATE GENERATION
    // (delegated to generate-gold-pack function)
    // ========================================
    await updateStage('certificate_generation');
    const certificateUrl = `${Deno.env.get('SUPABASE_URL')}/storage/v1/object/public/tracks/gold-packs/${trackId}/certificate.html`;
    await supabase.from('tracks').update({
      certificate_url: certificateUrl
    }).eq('id', trackId);
    // ========================================
    // STAGE 8: GOLD PACK ASSEMBLY
    // ========================================
    await updateStage('gold_pack_assembly');
    try {
      const supabaseUrl = Deno.env.get('SUPABASE_URL');
      const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
      const goldPackResponse = await fetch(`${supabaseUrl}/functions/v1/generate-gold-pack`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${serviceKey}`
        },
        body: JSON.stringify({
          trackId
        })
      });
      const goldPackResult = await goldPackResponse.json();
      console.log(`[process-master-audio] ✓ Gold pack:`, goldPackResult);
    } catch (gpError) {
      console.error('[process-master-audio] Gold pack error:', gpError);
    }
    // ========================================
    // FINAL UPDATE
    // ========================================
    await supabase.from('tracks').update({
      distribution_status: 'completed',
      processing_stage: 'completed',
      processing_progress: 100,
      processing_completed_at: new Date().toISOString(),
      master_audio_url: processedUrl
    }).eq('id', trackId);
    const completionDetails = {
      real_processing: true,
      vps_url: VPS_URL,
      analysis: {
        quality_score: analysis.qualityScore,
        lufs_original: analysis.originalLufs,
        lufs_normalized: normalizedLufs,
        normalization_applied: needsNorm,
        upscale_detected: false,
        high_freq_cutoff: analysis.highFreqCutoff,
        format: analysis.format,
        bit_depth: analysis.bitDepth,
        sample_rate: analysis.sampleRate,
        duration: analysis.duration
      },
      blockchain: {
        hash: blockchainHash,
        real_sha256: !!fileHash,
        ots_proof_uploaded: otsProofUploaded
      },
      metadata: {
        cleaned: true,
        branded: true,
        artist: username
      },
      gold_pack_ready: true
    };
    await supabase.from('distribution_logs').insert({
      track_id: trackId,
      user_id: track.user_id,
      action: 'processing_completed',
      stage: 'level_pro',
      details: completionDetails
    });
    await supabase.from('notifications').insert({
      user_id: track.user_id,
      type: 'system',
      title: '🎉 Золотой пакет готов!',
      message: `Трек "${track.title}" полностью обработан. WAV (-14 LUFS), XML-метаданные, сертификат и OTS-доказательство доступны для скачивания.`,
      target_type: 'track',
      target_id: trackId
    });
    console.log(`[process-master-audio] ✅ COMPLETED. All stages passed with real processing.`);
    return new Response(JSON.stringify({
      success: true,
      message: 'Gold pack assembled with real audio processing',
      stages_completed: PROCESSING_STAGES.length,
      real_processing: true,
      details: completionDetails
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('[process-master-audio] FATAL:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({
      success: false,
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9wcm9jZXNzLW1hc3Rlci1hdWRpby9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6ICdhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZScsXG59O1xuXG5pbnRlcmZhY2UgUHJvY2Vzc01hc3RlclJlcXVlc3Qge1xuICB0cmFja0lkOiBzdHJpbmc7XG4gIG1hc3RlckF1ZGlvVXJsOiBzdHJpbmc7XG59XG5cbmNvbnN0IFBST0NFU1NJTkdfU1RBR0VTID0gW1xuICB7IGlkOiAndmFsaWRhdGluZycsIG5hbWU6ICfQn9GA0L7QstC10YDQutCwINGE0L7RgNC80LDRgtCwIFdBViAyNC1iaXQnIH0sXG4gIHsgaWQ6ICd1cHNjYWxlX2RldGVjdGlvbicsIG5hbWU6ICfQlNC10YLQtdC60YLQvtGAINCw0L/RgdC60LXQudC70LAgKNGB0L/QtdC60YLRgNCw0LvRjNC90YvQuSDQsNC90LDQu9C40LcpJyB9LFxuICB7IGlkOiAnbG91ZG5lc3NfYW5hbHlzaXMnLCBuYW1lOiAn0JDQvdCw0LvQuNC3INCz0YDQvtC80LrQvtGB0YLQuCAoTFVGUyknIH0sXG4gIHsgaWQ6ICdub3JtYWxpemF0aW9uJywgbmFtZTogJ9Cd0L7RgNC80LDQu9C40LfQsNGG0LjRjyDQtNC+IC0xNCBMVUZTJyB9LFxuICB7IGlkOiAnbWV0YWRhdGFfY2xlYW5pbmcnLCBuYW1lOiAn0J7Rh9C40YHRgtC60LAg0Lgg0LfQsNC/0LjRgdGMINC80LXRgtCw0LTQsNC90L3Ri9GFJyB9LFxuICB7IGlkOiAnYmxvY2tjaGFpbl9oYXNoJywgbmFtZTogJ9CX0LDQv9C40YHRjCDRhdC10YjQsCDQsiBCbG9ja2NoYWluIChPcGVuVGltZXN0YW1wcyknIH0sXG4gIHsgaWQ6ICdjZXJ0aWZpY2F0ZV9nZW5lcmF0aW9uJywgbmFtZTogJ9CT0LXQvdC10YDQsNGG0LjRjyDRgdC10YDRgtC40YTQuNC60LDRgtCwJyB9LFxuICB7IGlkOiAnZ29sZF9wYWNrX2Fzc2VtYmx5JywgbmFtZTogJ9Ch0LHQvtGA0LrQsCDQl9C+0LvQvtGC0L7Qs9C+INC/0LDQutC10YLQsCcgfSxcbl07XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gVlBTIENPTU1VTklDQVRJT04gSEVMUEVSU1xuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbGxWcHMoXG4gIHVybDogc3RyaW5nLFxuICBlbmRwb2ludDogc3RyaW5nLFxuICBwYXlsb2FkOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAgdGltZW91dE1zID0gMzAwMDAsXG4gIGhlYWRlcnM/OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+LFxuKTogUHJvbWlzZTxhbnkgfCBudWxsPiB7XG4gIHRyeSB7XG4gICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBjb25zdCB0aW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSwgdGltZW91dE1zKTtcbiAgICBjb25zdCByZXFIZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0geyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLCAuLi5oZWFkZXJzIH07XG5cbiAgICBjb25zdCByZXNwID0gYXdhaXQgZmV0Y2goYCR7dXJsfSR7ZW5kcG9pbnR9YCwge1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBoZWFkZXJzOiByZXFIZWFkZXJzLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocGF5bG9hZCksXG4gICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgIH0pO1xuICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuXG4gICAgaWYgKCFyZXNwLm9rKSB7XG4gICAgICBjb25zdCBlcnJUZXh0ID0gYXdhaXQgcmVzcC50ZXh0KCk7XG4gICAgICBjb25zb2xlLmVycm9yKGBbVlBTXSAke2VuZHBvaW50fSBlcnJvciAke3Jlc3Auc3RhdHVzfTogJHtlcnJUZXh0fWApO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHJldHVybiBhd2FpdCByZXNwLmpzb24oKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIGNvbnNvbGUuZXJyb3IoYFtWUFNdICR7ZW5kcG9pbnR9IGZhaWxlZDpgLCBlKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG4vLyBQYXJzZSBWUFMgL2FuYWx5emUgcmVzcG9uc2UgaW50byBzdHJ1Y3R1cmVkIGRhdGFcbmZ1bmN0aW9uIHBhcnNlQW5hbHlzaXMocmF3OiBhbnkpIHtcbiAgY29uc3QgYXVkaW9TdHJlYW0gPSByYXcuc3RyZWFtcz8uZmluZCgoczogYW55KSA9PiBzLmNvZGVjX3R5cGUgPT09ICdhdWRpbycpIHx8IHt9O1xuICBjb25zdCBoaWdoRnJlcUN1dG9mZiA9IHJhdy5zcGVjdHJ1bT8uaGlnaF9mcmVxX2N1dG9mZiB8fCAyMDAwMDtcbiAgY29uc3QgdXBzY2FsZURldGVjdGVkID0gaGlnaEZyZXFDdXRvZmYgPCAxNjAwMDtcbiAgY29uc3Qgb3JpZ2luYWxMdWZzID0gcmF3Lmx1ZnM/LmludGVncmF0ZWQgPz8gLTE2O1xuICBjb25zdCBwZWFrRGIgPSByYXcubHVmcz8udHJ1ZV9wZWFrID8/IC0xO1xuICBjb25zdCBkeW5hbWljUmFuZ2UgPSByYXcubHVmcz8ucmFuZ2UgPz8gODtcbiAgY29uc3Qgc2FtcGxlUmF0ZSA9IHBhcnNlSW50KGF1ZGlvU3RyZWFtLnNhbXBsZV9yYXRlKSB8fCA0NDEwMDtcbiAgY29uc3QgYml0RGVwdGggPSBhdWRpb1N0cmVhbS5iaXRzX3Blcl9zYW1wbGUgfHwgMjQ7XG4gIGNvbnN0IGNoYW5uZWxzID0gYXVkaW9TdHJlYW0uY2hhbm5lbHMgfHwgMjtcbiAgY29uc3QgZHVyYXRpb24gPSBwYXJzZUZsb2F0KHJhdy5mb3JtYXQ/LmR1cmF0aW9uKSB8fCAwO1xuICBjb25zdCBmb3JtYXQgPSByYXcuZm9ybWF0Py5mb3JtYXRfbmFtZSB8fCAndW5rbm93bic7XG5cbiAgbGV0IHF1YWxpdHlTY29yZSA9IDEwO1xuICBpZiAodXBzY2FsZURldGVjdGVkKSBxdWFsaXR5U2NvcmUgLT0gMztcbiAgaWYgKHNhbXBsZVJhdGUgPCA0NDEwMCkgcXVhbGl0eVNjb3JlIC09IDI7XG4gIGlmIChiaXREZXB0aCA8IDE2KSBxdWFsaXR5U2NvcmUgLT0gMjtcbiAgaWYgKG9yaWdpbmFsTHVmcyA+IC04KSBxdWFsaXR5U2NvcmUgLT0gMTtcbiAgcXVhbGl0eVNjb3JlID0gTWF0aC5tYXgoMSwgTWF0aC5taW4oMTAsIHF1YWxpdHlTY29yZSkpO1xuXG4gIHJldHVybiB7XG4gICAgaGlnaEZyZXFDdXRvZmYsIHVwc2NhbGVEZXRlY3RlZCwgb3JpZ2luYWxMdWZzLCBwZWFrRGIsIGR5bmFtaWNSYW5nZSxcbiAgICBzYW1wbGVSYXRlLCBiaXREZXB0aCwgY2hhbm5lbHMsIGR1cmF0aW9uLCBmb3JtYXQsIHF1YWxpdHlTY29yZSxcbiAgICBtYXN0ZXJRdWFsaXR5OiBiaXREZXB0aCA+PSAyNCAmJiBbJ3dhdicsICdmbGFjJywgJ2FpZmYnXS5pbmNsdWRlcyhmb3JtYXQpLFxuICB9O1xufVxuXG4vLyBDb21wdXRlIFNIQS0yNTYgaGFzaCBmcm9tIGEgVVJMIChkb3dubG9hZHMgYW5kIGhhc2hlcylcbmFzeW5jIGZ1bmN0aW9uIGNvbXB1dGVGaWxlSGFzaChmaWxlVXJsOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCAxMjAwMDApOyAvLyAyIG1pbiBmb3IgbGFyZ2UgZmlsZXNcbiAgICBjb25zdCByZXNwID0gYXdhaXQgZmV0Y2goZmlsZVVybCwgeyBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsIH0pO1xuICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuXG4gICAgaWYgKCFyZXNwLm9rKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBbU0hBLTI1Nl0gRG93bmxvYWQgZmFpbGVkOiAke3Jlc3Auc3RhdHVzfWApO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgY29uc3QgYnVmZmVyID0gYXdhaXQgcmVzcC5hcnJheUJ1ZmZlcigpO1xuICAgIGNvbnN0IGhhc2hCdWZmZXIgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGJ1ZmZlcik7XG4gICAgY29uc3QgaGFzaEhleCA9IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoaGFzaEJ1ZmZlcikpXG4gICAgICAubWFwKGIgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcbiAgICAgIC5qb2luKCcnKTtcblxuICAgIGNvbnNvbGUubG9nKGBbU0hBLTI1Nl0gQ29tcHV0ZWQ6ICR7aGFzaEhleH0gKCR7KGJ1ZmZlci5ieXRlTGVuZ3RoIC8gMTAyNCAvIDEwMjQpLnRvRml4ZWQoMSl9TUIpYCk7XG4gICAgcmV0dXJuIGhhc2hIZXg7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBjb25zb2xlLmVycm9yKGBbU0hBLTI1Nl0gRmFpbGVkOmAsIGUpO1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbi8vIFN1Ym1pdCBoYXNoIHRvIE9wZW5UaW1lc3RhbXBzIGNhbGVuZGFyIHNlcnZlcnNcbmFzeW5jIGZ1bmN0aW9uIHN1Ym1pdFRvT3BlblRpbWVzdGFtcHMoaGFzaEhleDogc3RyaW5nKTogUHJvbWlzZTxVaW50OEFycmF5IHwgbnVsbD4ge1xuICBjb25zdCBoYXNoQnl0ZXMgPSBuZXcgVWludDhBcnJheShcbiAgICBoYXNoSGV4Lm1hdGNoKC8uezJ9L2cpIS5tYXAoYnl0ZSA9PiBwYXJzZUludChieXRlLCAxNikpXG4gICk7XG5cbiAgY29uc3QgY2FsZW5kYXJzID0gW1xuICAgICdodHRwczovL2EucG9vbC5vcGVudGltZXN0YW1wcy5vcmcvZGlnZXN0JyxcbiAgICAnaHR0cHM6Ly9iLnBvb2wub3BlbnRpbWVzdGFtcHMub3JnL2RpZ2VzdCcsXG4gICAgJ2h0dHBzOi8vZmlubmV5LmNhbGVuZGFyLmV0ZXJuaXR5d2FsbC5jb20vZGlnZXN0JyxcbiAgXTtcblxuICBmb3IgKGNvbnN0IGNhbGVuZGFyIG9mIGNhbGVuZGFycykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIDE1MDAwKTtcblxuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGZldGNoKGNhbGVuZGFyLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nLFxuICAgICAgICAgICdBY2NlcHQnOiAnYXBwbGljYXRpb24vdm5kLm9wZW50aW1lc3RhbXBzLnYxJyxcbiAgICAgICAgfSxcbiAgICAgICAgYm9keTogaGFzaEJ5dGVzLFxuICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgfSk7XG4gICAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcblxuICAgICAgaWYgKHJlc3Aub2spIHtcbiAgICAgICAgY29uc3QgcHJvb2ZCeXRlcyA9IG5ldyBVaW50OEFycmF5KGF3YWl0IHJlc3AuYXJyYXlCdWZmZXIoKSk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbT1RTXSBQcm9vZiByZWNlaXZlZCBmcm9tICR7Y2FsZW5kYXJ9ICgke3Byb29mQnl0ZXMubGVuZ3RofSBieXRlcylgKTtcbiAgICAgICAgcmV0dXJuIHByb29mQnl0ZXM7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBlcnJUZXh0ID0gYXdhaXQgcmVzcC50ZXh0KCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbT1RTXSAke2NhbGVuZGFyfSByZXR1cm5lZCAke3Jlc3Auc3RhdHVzfTogJHtlcnJUZXh0fWApO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUubG9nKGBbT1RTXSAke2NhbGVuZGFyfSBmYWlsZWQ6YCwgZSk7XG4gICAgfVxuICB9XG5cbiAgY29uc29sZS5lcnJvcignW09UU10gQWxsIGNhbGVuZGFyIHNlcnZlcnMgZmFpbGVkJyk7XG4gIHJldHVybiBudWxsO1xufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIE1BSU4gSEFORExFUlxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09ICdPUFRJT05TJykge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoJ29rJywgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoJ1NVUEFCQVNFX1VSTCcpID8/ICcnLFxuICAgICAgRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZJykgPz8gJydcbiAgICApO1xuXG4gICAgY29uc3QgeyB0cmFja0lkLCBtYXN0ZXJBdWRpb1VybCB9OiBQcm9jZXNzTWFzdGVyUmVxdWVzdCA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10g4pa2IFN0YXJ0aW5nIFJFQUwgcHJvY2Vzc2luZyBmb3IgdHJhY2s6ICR7dHJhY2tJZH1gKTtcblxuICAgIGlmICghdHJhY2tJZCB8fCAhbWFzdGVyQXVkaW9VcmwpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcigndHJhY2tJZCBhbmQgbWFzdGVyQXVkaW9VcmwgYXJlIHJlcXVpcmVkJyk7XG4gICAgfVxuXG4gICAgLy8gR2V0IHRyYWNrIGluZm8gKGF2b2lkIGpvaW5zIGZvciByZXNpbGllbmNlKVxuICAgIGNvbnN0IHsgZGF0YTogdHJhY2ssIGVycm9yOiB0cmFja0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oJ3RyYWNrcycpXG4gICAgICAuc2VsZWN0KCcqJylcbiAgICAgIC5lcSgnaWQnLCB0cmFja0lkKVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICBpZiAodHJhY2tFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSBEQiBlcnJvcjonLCB0cmFja0Vycm9yKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgRGF0YWJhc2UgZXJyb3I6ICR7dHJhY2tFcnJvci5tZXNzYWdlfWApO1xuICAgIH1cbiAgICBpZiAoIXRyYWNrKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFRyYWNrIG5vdCBmb3VuZDogJHt0cmFja0lkfWApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIFRyYWNrOiBcIiR7dHJhY2sudGl0bGV9XCIsIHVzZXI6ICR7dHJhY2sudXNlcl9pZH1gKTtcblxuICAgIGNvbnN0IFZQU19VUkwgPSBEZW5vLmVudi5nZXQoXCJWUFNfRkZNUEVHX1VSTFwiKSB8fCBcImh0dHA6Ly8yMTcuMTk5LjI1NC4xNzA6MzAwMVwiO1xuICAgIGNvbnN0IEZGTVBFR19BUElfVVJMID0gRGVuby5lbnYuZ2V0KFwiRkZNUEVHX0FQSV9VUkxcIik7XG4gICAgY29uc3QgRkZNUEVHX0FQSV9TRUNSRVQgPSBEZW5vLmVudi5nZXQoXCJGRk1QRUdfQVBJX1NFQ1JFVFwiKTtcbiAgICBjb25zdCBmZm1wZWdIZWFkZXJzID0gRkZNUEVHX0FQSV9TRUNSRVQgPyB7ICd4LWFwaS1rZXknOiBGRk1QRUdfQVBJX1NFQ1JFVCB9IDogdW5kZWZpbmVkO1xuXG4gICAgLy8gSGVscGVyOiB1cGRhdGUgcHJvZ3Jlc3MgaW4gREJcbiAgICBsZXQgc3RhZ2VJZHggPSAwO1xuICAgIGNvbnN0IHVwZGF0ZVN0YWdlID0gYXN5bmMgKHN0YWdlSWQ6IHN0cmluZykgPT4ge1xuICAgICAgc3RhZ2VJZHgrKztcbiAgICAgIGNvbnN0IHByb2dyZXNzID0gTWF0aC5yb3VuZCgoc3RhZ2VJZHggLyBQUk9DRVNTSU5HX1NUQUdFUy5sZW5ndGgpICogMTAwKTtcbiAgICAgIGNvbnNvbGUubG9nKGBbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIOKUgOKUgCBTdGFnZSAke3N0YWdlSWR4fS8ke1BST0NFU1NJTkdfU1RBR0VTLmxlbmd0aH06ICR7c3RhZ2VJZH0gKCR7cHJvZ3Jlc3N9JSlgKTtcblxuICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgndHJhY2tzJykudXBkYXRlKHtcbiAgICAgICAgcHJvY2Vzc2luZ19zdGFnZTogc3RhZ2VJZCxcbiAgICAgICAgcHJvY2Vzc2luZ19wcm9ncmVzczogcHJvZ3Jlc3MsXG4gICAgICB9KS5lcSgnaWQnLCB0cmFja0lkKTtcblxuICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgnZGlzdHJpYnV0aW9uX2xvZ3MnKS5pbnNlcnQoe1xuICAgICAgICB0cmFja19pZDogdHJhY2tJZCxcbiAgICAgICAgdXNlcl9pZDogdHJhY2sudXNlcl9pZCxcbiAgICAgICAgYWN0aW9uOiBgc3RhZ2VfJHtzdGFnZUlkfWAsXG4gICAgICAgIHN0YWdlOiAnbGV2ZWxfcHJvJyxcbiAgICAgICAgZGV0YWlsczogeyBzdGFnZV9uYW1lOiBQUk9DRVNTSU5HX1NUQUdFUy5maW5kKHMgPT4gcy5pZCA9PT0gc3RhZ2VJZCk/Lm5hbWUgfSxcbiAgICAgIH0pO1xuICAgIH07XG5cbiAgICAvLyBNYXJrIGFzIHByb2Nlc3NpbmdcbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCd0cmFja3MnKS51cGRhdGUoe1xuICAgICAgZGlzdHJpYnV0aW9uX3N0YXR1czogJ3Byb2Nlc3NpbmcnLFxuICAgICAgcHJvY2Vzc2luZ19zdGFydGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBwcm9jZXNzaW5nX3Byb2dyZXNzOiAwLFxuICAgIH0pLmVxKCdpZCcsIHRyYWNrSWQpO1xuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIC8vIFNUQUdFIDEtMi0zOiBBTkFMWVpFICh2YWxpZGF0ZSArIHVwc2NhbGUgKyBsb3VkbmVzcylcbiAgICAvLyBTaW5nbGUgVlBTIGNhbGwgY292ZXJzIGFsbCB0aHJlZSBzdGFnZXNcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgYXdhaXQgdXBkYXRlU3RhZ2UoJ3ZhbGlkYXRpbmcnKTtcblxuICAgIGNvbnN0IHJhd0FuYWx5c2lzID0gYXdhaXQgY2FsbFZwcyhWUFNfVVJMLCAnL2FuYWx5emUnLCB7IGF1ZGlvX3VybDogbWFzdGVyQXVkaW9VcmwgfSwgMzAwMDAsIGZmbXBlZ0hlYWRlcnMpO1xuXG4gICAgaWYgKCFyYXdBbmFseXNpcykge1xuICAgICAgY29uc29sZS5lcnJvcignW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDinJcgVlBTIGFuYWx5c2lzIHVuYXZhaWxhYmxlIOKAlCBhYm9ydGluZycpO1xuICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgndHJhY2tzJykudXBkYXRlKHtcbiAgICAgICAgZGlzdHJpYnV0aW9uX3N0YXR1czogJ3BlbmRpbmdfbWFzdGVyJyxcbiAgICAgICAgcHJvY2Vzc2luZ19zdGFnZTogbnVsbCxcbiAgICAgICAgcHJvY2Vzc2luZ19wcm9ncmVzczogMCxcbiAgICAgIH0pLmVxKCdpZCcsIHRyYWNrSWQpO1xuXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdub3RpZmljYXRpb25zJykuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogdHJhY2sudXNlcl9pZCxcbiAgICAgICAgdHlwZTogJ3N5c3RlbScsXG4gICAgICAgIHRpdGxlOiAn4p2MINCe0YjQuNCx0LrQsCDQsNC90LDQu9C40LfQsCcsXG4gICAgICAgIG1lc3NhZ2U6IGDQndC1INGD0LTQsNC70L7RgdGMINC/0YDQvtCw0L3QsNC70LjQt9C40YDQvtCy0LDRgtGMINC80LDRgdGC0LXRgC3RhNCw0LnQuyDQtNC70Y8g0YLRgNC10LrQsCBcIiR7dHJhY2sudGl0bGV9XCIuINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC/0L7Qt9C20LUg0LjQu9C4INC30LDQs9GA0YPQt9C40YLQtSDRhNCw0LnQuyDQv9C+0LLRgtC+0YDQvdC+LmAsXG4gICAgICAgIHRhcmdldF90eXBlOiAndHJhY2snLFxuICAgICAgICB0YXJnZXRfaWQ6IHRyYWNrSWQsXG4gICAgICB9KTtcblxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICd2cHNfdW5hdmFpbGFibGUnLCBtZXNzYWdlOiAn0KHQtdGA0LLQtdGAINC+0LHRgNCw0LHQvtGC0LrQuCDQsNGD0LTQuNC+INC90LXQtNC+0YHRgtGD0L/QtdC9JyB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDUwMywgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgYW5hbHlzaXMgPSBwYXJzZUFuYWx5c2lzKHJhd0FuYWx5c2lzKTtcbiAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDinJMgQW5hbHlzaXM6IGZvcm1hdD0ke2FuYWx5c2lzLmZvcm1hdH0sICR7YW5hbHlzaXMuYml0RGVwdGh9Yml0LyR7YW5hbHlzaXMuc2FtcGxlUmF0ZX1IeiwgTFVGUz0ke2FuYWx5c2lzLm9yaWdpbmFsTHVmc30sIHF1YWxpdHk9JHthbmFseXNpcy5xdWFsaXR5U2NvcmV9LzEwYCk7XG5cbiAgICAvLyBTYXZlIGFuYWx5c2lzIHRvIHRyYWNrX2hlYWx0aF9yZXBvcnRzXG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgndHJhY2tfaGVhbHRoX3JlcG9ydHMnKS51cHNlcnQoe1xuICAgICAgdHJhY2tfaWQ6IHRyYWNrSWQsXG4gICAgICBxdWFsaXR5X3Njb3JlOiBhbmFseXNpcy5xdWFsaXR5U2NvcmUsXG4gICAgICBsdWZzX29yaWdpbmFsOiBhbmFseXNpcy5vcmlnaW5hbEx1ZnMsXG4gICAgICBwZWFrX2RiOiBhbmFseXNpcy5wZWFrRGIsXG4gICAgICBkeW5hbWljX3JhbmdlOiBhbmFseXNpcy5keW5hbWljUmFuZ2UsXG4gICAgICBzcGVjdHJ1bV9vazogIWFuYWx5c2lzLnVwc2NhbGVEZXRlY3RlZCxcbiAgICAgIGhpZ2hfZnJlcV9jdXRvZmY6IGFuYWx5c2lzLmhpZ2hGcmVxQ3V0b2ZmLFxuICAgICAgdXBzY2FsZV9kZXRlY3RlZDogYW5hbHlzaXMudXBzY2FsZURldGVjdGVkLFxuICAgICAgc2FtcGxlX3JhdGU6IGFuYWx5c2lzLnNhbXBsZVJhdGUsXG4gICAgICBiaXRfZGVwdGg6IGFuYWx5c2lzLmJpdERlcHRoLFxuICAgICAgY2hhbm5lbHM6IGFuYWx5c2lzLmNoYW5uZWxzLFxuICAgICAgZHVyYXRpb246IGFuYWx5c2lzLmR1cmF0aW9uLFxuICAgICAgZm9ybWF0OiBhbmFseXNpcy5mb3JtYXQsXG4gICAgICBtYXN0ZXJfcXVhbGl0eTogYW5hbHlzaXMubWFzdGVyUXVhbGl0eSxcbiAgICAgIGFuYWx5c2lzX3N0YXR1czogJ2NvbXBsZXRlZCcsXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfSwgeyBvbkNvbmZsaWN0OiAndHJhY2tfaWQnIH0pO1xuXG4gICAgLy8gU1RBR0UgMjogVXBzY2FsZSBkZXRlY3Rpb25cbiAgICBhd2FpdCB1cGRhdGVTdGFnZSgndXBzY2FsZV9kZXRlY3Rpb24nKTtcblxuICAgIGlmIChhbmFseXNpcy51cHNjYWxlRGV0ZWN0ZWQpIHtcbiAgICAgIGNvbnNvbGUubG9nKGBbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIOKclyBVUFNDQUxFIERFVEVDVEVEOiBjdXRvZmY9JHthbmFseXNpcy5oaWdoRnJlcUN1dG9mZn1IeiAodGhyZXNob2xkIDE2MDAwSHopYCk7XG5cbiAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ3RyYWNrcycpLnVwZGF0ZSh7XG4gICAgICAgIGRpc3RyaWJ1dGlvbl9zdGF0dXM6ICdwZW5kaW5nX21hc3RlcicsXG4gICAgICAgIHVwc2NhbGVfZGV0ZWN0ZWQ6IHRydWUsXG4gICAgICAgIHByb2Nlc3Npbmdfc3RhZ2U6IG51bGwsXG4gICAgICAgIHByb2Nlc3NpbmdfcHJvZ3Jlc3M6IDAsXG4gICAgICB9KS5lcSgnaWQnLCB0cmFja0lkKTtcblxuICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgnbm90aWZpY2F0aW9ucycpLmluc2VydCh7XG4gICAgICAgIHVzZXJfaWQ6IHRyYWNrLnVzZXJfaWQsXG4gICAgICAgIHR5cGU6ICdzeXN0ZW0nLFxuICAgICAgICB0aXRsZTogJ+KaoO+4jyDQntCx0L3QsNGA0YPQttC10L0g0LDQv9GB0LrQtdC50LsnLFxuICAgICAgICBtZXNzYWdlOiBg0KLRgNC10LogXCIke3RyYWNrLnRpdGxlfVwiINGB0L7QtNC10YDQttC40YIg0LDQv9GB0LrQtdC50LvQtdC90L3Ri9C5INCw0YPQtNC40L7RhNCw0LnQuyAo0YHRgNC10Lcg0YfQsNGB0YLQvtGCINC90LAgJHthbmFseXNpcy5oaWdoRnJlcUN1dG9mZn3Qk9GGLCDQv9C+0YDQvtCzIDE2MDAw0JPRhikuINCf0L7QttCw0LvRg9C50YHRgtCwLCDQt9Cw0LPRgNGD0LfQuNGC0LUg0L7RgNC40LPQuNC90LDQu9GM0L3Ri9C5IFdBVi3RhNCw0LnQuy5gLFxuICAgICAgICB0YXJnZXRfdHlwZTogJ3RyYWNrJyxcbiAgICAgICAgdGFyZ2V0X2lkOiB0cmFja0lkLFxuICAgICAgfSk7XG5cbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICBlcnJvcjogJ3Vwc2NhbGVfZGV0ZWN0ZWQnLFxuICAgICAgICAgIG1lc3NhZ2U6IGDQntCx0L3QsNGA0YPQttC10L0g0LDQv9GB0LrQtdC50LsgKNGB0YDQtdC3INC90LAgJHthbmFseXNpcy5oaWdoRnJlcUN1dG9mZn3Qk9GGKS4g0JfQsNCz0YDRg9C30LjRgtC1INC+0YDQuNCz0LjQvdCw0LsgV0FWIDI0LWJpdGAsXG4gICAgICAgICAgaGlnaF9mcmVxX2N1dG9mZjogYW5hbHlzaXMuaGlnaEZyZXFDdXRvZmYsXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIFNUQUdFIDM6IExvdWRuZXNzIGFuYWx5c2lzXG4gICAgYXdhaXQgdXBkYXRlU3RhZ2UoJ2xvdWRuZXNzX2FuYWx5c2lzJyk7XG5cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCd0cmFja3MnKS51cGRhdGUoe1xuICAgICAgYXVkaW9fcXVhbGl0eV9zY29yZTogYW5hbHlzaXMucXVhbGl0eVNjb3JlLFxuICAgICAgYXVkaW9fc2FtcGxlX3JhdGU6IGFuYWx5c2lzLnNhbXBsZVJhdGUsXG4gICAgICBhdWRpb19iaXRfZGVwdGg6IGFuYWx5c2lzLmJpdERlcHRoLFxuICAgICAgYXVkaW9fbHVmczogYW5hbHlzaXMub3JpZ2luYWxMdWZzLFxuICAgICAgYXVkaW9fcGVha19kYjogYW5hbHlzaXMucGVha0RiLFxuICAgICAgdXBzY2FsZV9kZXRlY3RlZDogZmFsc2UsXG4gICAgfSkuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLy8gU1RBR0UgNDogTk9STUFMSVpBVElPTiAoLTE0IExVRlMpXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGF3YWl0IHVwZGF0ZVN0YWdlKCdub3JtYWxpemF0aW9uJyk7XG5cbiAgICBsZXQgcHJvY2Vzc2VkVXJsID0gbWFzdGVyQXVkaW9Vcmw7XG4gICAgbGV0IG5vcm1hbGl6ZWRMdWZzID0gYW5hbHlzaXMub3JpZ2luYWxMdWZzO1xuICAgIGNvbnN0IG5lZWRzTm9ybSA9IE1hdGguYWJzKGFuYWx5c2lzLm9yaWdpbmFsTHVmcyAtICgtMTQpKSA+IDE7XG5cbiAgICBpZiAobmVlZHNOb3JtKSB7XG4gICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSBOb3JtYWxpemluZzogJHthbmFseXNpcy5vcmlnaW5hbEx1ZnN9IOKGkiAtMTQgTFVGU2ApO1xuXG4gICAgICBjb25zdCBub3JtUmVzdWx0ID0gYXdhaXQgY2FsbFZwcyhWUFNfVVJMLCAnL25vcm1hbGl6ZScsIHtcbiAgICAgICAgYXVkaW9fdXJsOiBtYXN0ZXJBdWRpb1VybCxcbiAgICAgICAgdGFyZ2V0X2x1ZnM6IC0xNCxcbiAgICAgICAgc3RyaXBfbWV0YWRhdGE6IGZhbHNlLFxuICAgICAgICBicmFuZF9tZXRhZGF0YTogZmFsc2UsXG4gICAgICB9LCA5MDAwMCwgZmZtcGVnSGVhZGVycyk7IC8vIDkwcyBmb3IgbGFyZ2UgZmlsZXNcblxuICAgICAgaWYgKG5vcm1SZXN1bHQ/Lm5vcm1hbGl6ZWRfdXJsKSB7XG4gICAgICAgIHByb2Nlc3NlZFVybCA9IG5vcm1SZXN1bHQubm9ybWFsaXplZF91cmw7XG4gICAgICAgIG5vcm1hbGl6ZWRMdWZzID0gbm9ybVJlc3VsdC5ub3JtYWxpemVkX2x1ZnMgPz8gLTE0O1xuICAgICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDinJMgTm9ybWFsaXplZDogJHthbmFseXNpcy5vcmlnaW5hbEx1ZnN9IOKGkiAke25vcm1hbGl6ZWRMdWZzfSBMVUZTYCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhgW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSDimqAgTm9ybWFsaXphdGlvbiBmYWlsZWQsIGtlZXBpbmcgb3JpZ2luYWxgKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10g4pyTIExVRlMgd2l0aGluIHRvbGVyYW5jZSAoJHthbmFseXNpcy5vcmlnaW5hbEx1ZnN9KSwgbm8gbm9ybWFsaXphdGlvbiBuZWVkZWRgKTtcbiAgICB9XG5cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCd0cmFja3MnKS51cGRhdGUoe1xuICAgICAgbHVmc19ub3JtYWxpemVkOiB0cnVlLFxuICAgICAgYXVkaW9fbHVmczogbm9ybWFsaXplZEx1ZnMsXG4gICAgICBub3JtYWxpemVkX2F1ZGlvX3VybDogcHJvY2Vzc2VkVXJsLFxuICAgIH0pLmVxKCdpZCcsIHRyYWNrSWQpO1xuXG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgndHJhY2tfaGVhbHRoX3JlcG9ydHMnKS51cGRhdGUoe1xuICAgICAgbHVmc19ub3JtYWxpemVkOiBub3JtYWxpemVkTHVmcyxcbiAgICAgIG5vcm1hbGl6ZWRfYXVkaW9fdXJsOiBwcm9jZXNzZWRVcmwsXG4gICAgICBub3JtYWxpemF0aW9uX3N0YXR1czogJ2NvbXBsZXRlZCcsXG4gICAgfSkuZXEoJ3RyYWNrX2lkJywgdHJhY2tJZCk7XG5cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLy8gU1RBR0UgNTogTUVUQURBVEEgQ0xFQU5JTkcgJiBCUkFORElOR1xuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBhd2FpdCB1cGRhdGVTdGFnZSgnbWV0YWRhdGFfY2xlYW5pbmcnKTtcblxuICAgIGNvbnN0IHsgZGF0YTogcHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKCdwcm9maWxlcycpXG4gICAgICAuc2VsZWN0KCd1c2VybmFtZScpXG4gICAgICAuZXEoJ3VzZXJfaWQnLCB0cmFjay51c2VyX2lkKVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICBjb25zdCB1c2VybmFtZSA9IHByb2ZpbGU/LnVzZXJuYW1lIHx8ICdVbmtub3duJztcblxuICAgIC8vIFVzZSBGRk1QRUdfQVBJX1VSTCAod2l0aCBhdXRoKSBpZiBhdmFpbGFibGUsIGVsc2UgVlBTX1VSTFxuICAgIGlmIChGRk1QRUdfQVBJX1VSTCAmJiBGRk1QRUdfQVBJX1NFQ1JFVCkge1xuICAgICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10gTWV0YWRhdGEgY2xlYW5pbmcgdmlhIEZGTVBFR19BUElfVVJMYCk7XG5cbiAgICAgIGNvbnN0IG1ldGFSZXN1bHQgPSBhd2FpdCBjYWxsVnBzKEZGTVBFR19BUElfVVJMLCAnL2NsZWFuLW1ldGFkYXRhJywge1xuICAgICAgICBhdWRpb191cmw6IHByb2Nlc3NlZFVybCxcbiAgICAgICAgbWV0YWRhdGE6IHtcbiAgICAgICAgICB0aXRsZTogdHJhY2sudGl0bGUsXG4gICAgICAgICAgYXJ0aXN0OiB1c2VybmFtZSxcbiAgICAgICAgICBhbGJ1bTogJ0FJbXV6YScsXG4gICAgICAgICAgcHVibGlzaGVyOiAnQUltdXphJyxcbiAgICAgICAgICBjb21tZW50OiBgR2VuZXJhdGVkIG9uIGFpbXV6YS5ydSB8IFVzZXI6ICR7dXNlcm5hbWV9YCxcbiAgICAgICAgICBjb3B5cmlnaHQ6IGDCqSAke25ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKX0gJHt1c2VybmFtZX0gdmlhIEFJbXV6YWAsXG4gICAgICAgICAgY3VzdG9tOiB7XG4gICAgICAgICAgICBUWFhYX1VTRVJfSUQ6IHRyYWNrLnVzZXJfaWQsXG4gICAgICAgICAgICBUWFhYX1VTRVJOQU1FOiB1c2VybmFtZSxcbiAgICAgICAgICAgIFRYWFhfV0VCU0lURTogJ2FpbXV6YS5ydScsXG4gICAgICAgICAgICBUWFhYX0RBVEU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICAgICAgICAgICAgVFhYWF9UUkFDS19JRDogdHJhY2tJZCxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSwgNjAwMDAsIHsgJ3gtYXBpLWtleSc6IEZGTVBFR19BUElfU0VDUkVUIH0pO1xuXG4gICAgICBpZiAobWV0YVJlc3VsdD8uY2xlYW5lZF91cmwpIHtcbiAgICAgICAgcHJvY2Vzc2VkVXJsID0gbWV0YVJlc3VsdC5jbGVhbmVkX3VybDtcbiAgICAgICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10g4pyTIE1ldGFkYXRhIGNsZWFuZWQgdmlhIEZGTVBFRyBBUElgKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10gTWV0YWRhdGEgY2xlYW5pbmcgdmlhIFZQUyAvbm9ybWFsaXplYCk7XG5cbiAgICAgIGNvbnN0IG1ldGFSZXN1bHQgPSBhd2FpdCBjYWxsVnBzKFZQU19VUkwsICcvbm9ybWFsaXplJywge1xuICAgICAgICBhdWRpb191cmw6IHByb2Nlc3NlZFVybCxcbiAgICAgICAgdGFyZ2V0X2x1ZnM6IC0xNCxcbiAgICAgICAgc3RyaXBfbWV0YWRhdGE6IHRydWUsXG4gICAgICAgIGJyYW5kX21ldGFkYXRhOiB0cnVlLFxuICAgICAgICBtZXRhZGF0YToge1xuICAgICAgICAgIGFydGlzdDogdXNlcm5hbWUsXG4gICAgICAgICAgdGl0bGU6IHRyYWNrLnRpdGxlLFxuICAgICAgICAgIGFsYnVtOiAnQUltdXphJyxcbiAgICAgICAgICBjb21tZW50OiBgR2VuZXJhdGVkIG9uIGFpbXV6YS5ydSB8IFVzZXI6ICR7dXNlcm5hbWV9YCxcbiAgICAgICAgICBkYXRlOiBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKSxcbiAgICAgICAgICBlbmNvZGVyOiAnQUltdXphIE11c2ljIFRlcm1pbmFsJyxcbiAgICAgICAgICBjb3B5cmlnaHQ6IGDCqSAke25ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKX0gJHt1c2VybmFtZX0gdmlhIEFJbXV6YWAsXG4gICAgICAgICAgdXNlcl9pZDogdHJhY2sudXNlcl9pZCxcbiAgICAgICAgICB3ZWJzaXRlOiAnaHR0cHM6Ly9haW11emEucnUnLFxuICAgICAgICB9LFxuICAgICAgfSwgNjAwMDAsIGZmbXBlZ0hlYWRlcnMpO1xuXG4gICAgICBpZiAobWV0YVJlc3VsdD8ubm9ybWFsaXplZF91cmwpIHtcbiAgICAgICAgcHJvY2Vzc2VkVXJsID0gbWV0YVJlc3VsdC5ub3JtYWxpemVkX3VybDtcbiAgICAgICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10g4pyTIE1ldGFkYXRhIGNsZWFuZWQgdmlhIFZQUyBub3JtYWxpemVgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCd0cmFja3MnKS51cGRhdGUoe1xuICAgICAgbWV0YWRhdGFfY2xlYW5lZDogdHJ1ZSxcbiAgICAgIG1ldGFkYXRhX2JyYW5kZWQ6IHRydWUsXG4gICAgfSkuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLy8gU1RBR0UgNjogQkxPQ0tDSEFJTiBIQVNIIChTSEEtMjU2ICsgT3BlblRpbWVzdGFtcHMpXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGF3YWl0IHVwZGF0ZVN0YWdlKCdibG9ja2NoYWluX2hhc2gnKTtcblxuICAgIC8vIFN0ZXAgMTogQ29tcHV0ZSByZWFsIFNIQS0yNTYgb2YgdGhlIGZpbmFsIHByb2Nlc3NlZCBmaWxlXG4gICAgY29uc3QgZmlsZUhhc2ggPSBhd2FpdCBjb21wdXRlRmlsZUhhc2gocHJvY2Vzc2VkVXJsKTtcblxuICAgIGxldCBibG9ja2NoYWluSGFzaDogc3RyaW5nO1xuICAgIGxldCBvdHNQcm9vZlVwbG9hZGVkID0gZmFsc2U7XG5cbiAgICBpZiAoZmlsZUhhc2gpIHtcbiAgICAgIGJsb2NrY2hhaW5IYXNoID0gYDB4JHtmaWxlSGFzaH1gO1xuICAgICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10g4pyTIFJlYWwgU0hBLTI1NjogJHtibG9ja2NoYWluSGFzaH1gKTtcblxuICAgICAgLy8gU3RlcCAyOiBTdWJtaXQgdG8gT3BlblRpbWVzdGFtcHMgKGFzeW5jIC0gZG9uJ3QgYmxvY2spXG4gICAgICBjb25zdCBvdHNQcm9vZiA9IGF3YWl0IHN1Ym1pdFRvT3BlblRpbWVzdGFtcHMoZmlsZUhhc2gpO1xuXG4gICAgICBpZiAob3RzUHJvb2YpIHtcbiAgICAgICAgLy8gVXBsb2FkIE9UUyBwcm9vZiB0byBzdG9yYWdlXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcHJvb2ZGaWxlTmFtZSA9IGBnb2xkLXBhY2tzLyR7dHJhY2tJZH0vcHJvb2Yub3RzYDtcbiAgICAgICAgICBhd2FpdCBzdXBhYmFzZS5zdG9yYWdlLmZyb20oJ3RyYWNrcycpLnVwbG9hZChcbiAgICAgICAgICAgIHByb29mRmlsZU5hbWUsXG4gICAgICAgICAgICBvdHNQcm9vZixcbiAgICAgICAgICAgIHsgdXBzZXJ0OiB0cnVlLCBjb250ZW50VHlwZTogJ2FwcGxpY2F0aW9uL3ZuZC5vcGVudGltZXN0YW1wcy52MScgfVxuICAgICAgICAgICk7XG4gICAgICAgICAgb3RzUHJvb2ZVcGxvYWRlZCA9IHRydWU7XG4gICAgICAgICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10g4pyTIE9UUyBwcm9vZiB1cGxvYWRlZCB0byBzdG9yYWdlYCk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGBbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIE9UUyBwcm9vZiB1cGxvYWQgZmFpbGVkOmAsIGUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIEZhbGxiYWNrOiBzdGlsbCBnZW5lcmF0ZSBhIGhhc2ggYnV0IG1hcmsgaXQgYXMgbG9jYWwtb25seVxuICAgICAgY29uc3QgZmFsbGJhY2tCeXRlcyA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShwcm9jZXNzZWRVcmwgKyBEYXRlLm5vdygpLnRvU3RyaW5nKCkpO1xuICAgICAgY29uc3QgZmFsbGJhY2tCdWZmZXIgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGZhbGxiYWNrQnl0ZXMpO1xuICAgICAgY29uc3QgZmFsbGJhY2tIZXggPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGZhbGxiYWNrQnVmZmVyKSlcbiAgICAgICAgLm1hcChiID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG4gICAgICAgIC5qb2luKCcnKTtcbiAgICAgIGJsb2NrY2hhaW5IYXNoID0gYDB4TE9DQUxfJHtmYWxsYmFja0hleH1gO1xuICAgICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10g4pqgIFVzaW5nIGZhbGxiYWNrIGhhc2ggKGZpbGUgZG93bmxvYWQgZmFpbGVkKWApO1xuICAgIH1cblxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ3RyYWNrcycpLnVwZGF0ZSh7XG4gICAgICBibG9ja2NoYWluX2hhc2g6IGJsb2NrY2hhaW5IYXNoLFxuICAgIH0pLmVxKCdpZCcsIHRyYWNrSWQpO1xuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIC8vIFNUQUdFIDc6IENFUlRJRklDQVRFIEdFTkVSQVRJT05cbiAgICAvLyAoZGVsZWdhdGVkIHRvIGdlbmVyYXRlLWdvbGQtcGFjayBmdW5jdGlvbilcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgYXdhaXQgdXBkYXRlU3RhZ2UoJ2NlcnRpZmljYXRlX2dlbmVyYXRpb24nKTtcblxuICAgIGNvbnN0IGNlcnRpZmljYXRlVXJsID0gYCR7RGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9VUkwnKX0vc3RvcmFnZS92MS9vYmplY3QvcHVibGljL3RyYWNrcy9nb2xkLXBhY2tzLyR7dHJhY2tJZH0vY2VydGlmaWNhdGUuaHRtbGA7XG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgndHJhY2tzJykudXBkYXRlKHtcbiAgICAgIGNlcnRpZmljYXRlX3VybDogY2VydGlmaWNhdGVVcmwsXG4gICAgfSkuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgLy8gU1RBR0UgODogR09MRCBQQUNLIEFTU0VNQkxZXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGF3YWl0IHVwZGF0ZVN0YWdlKCdnb2xkX3BhY2tfYXNzZW1ibHknKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldCgnU1VQQUJBU0VfVVJMJykhO1xuICAgICAgY29uc3Qgc2VydmljZUtleSA9IERlbm8uZW52LmdldCgnU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWScpITtcblxuICAgICAgY29uc3QgZ29sZFBhY2tSZXNwb25zZSA9IGF3YWl0IGZldGNoKFxuICAgICAgICBgJHtzdXBhYmFzZVVybH0vZnVuY3Rpb25zL3YxL2dlbmVyYXRlLWdvbGQtcGFja2AsXG4gICAgICAgIHtcbiAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiBgQmVhcmVyICR7c2VydmljZUtleX1gLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyB0cmFja0lkIH0pLFxuICAgICAgICB9XG4gICAgICApO1xuXG4gICAgICBjb25zdCBnb2xkUGFja1Jlc3VsdCA9IGF3YWl0IGdvbGRQYWNrUmVzcG9uc2UuanNvbigpO1xuICAgICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10g4pyTIEdvbGQgcGFjazpgLCBnb2xkUGFja1Jlc3VsdCk7XG4gICAgfSBjYXRjaCAoZ3BFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignW3Byb2Nlc3MtbWFzdGVyLWF1ZGlvXSBHb2xkIHBhY2sgZXJyb3I6JywgZ3BFcnJvcik7XG4gICAgfVxuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIC8vIEZJTkFMIFVQREFURVxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCd0cmFja3MnKS51cGRhdGUoe1xuICAgICAgZGlzdHJpYnV0aW9uX3N0YXR1czogJ2NvbXBsZXRlZCcsXG4gICAgICBwcm9jZXNzaW5nX3N0YWdlOiAnY29tcGxldGVkJyxcbiAgICAgIHByb2Nlc3NpbmdfcHJvZ3Jlc3M6IDEwMCxcbiAgICAgIHByb2Nlc3NpbmdfY29tcGxldGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBtYXN0ZXJfYXVkaW9fdXJsOiBwcm9jZXNzZWRVcmwsXG4gICAgfSkuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICBjb25zdCBjb21wbGV0aW9uRGV0YWlscyA9IHtcbiAgICAgIHJlYWxfcHJvY2Vzc2luZzogdHJ1ZSxcbiAgICAgIHZwc191cmw6IFZQU19VUkwsXG4gICAgICBhbmFseXNpczoge1xuICAgICAgICBxdWFsaXR5X3Njb3JlOiBhbmFseXNpcy5xdWFsaXR5U2NvcmUsXG4gICAgICAgIGx1ZnNfb3JpZ2luYWw6IGFuYWx5c2lzLm9yaWdpbmFsTHVmcyxcbiAgICAgICAgbHVmc19ub3JtYWxpemVkOiBub3JtYWxpemVkTHVmcyxcbiAgICAgICAgbm9ybWFsaXphdGlvbl9hcHBsaWVkOiBuZWVkc05vcm0sXG4gICAgICAgIHVwc2NhbGVfZGV0ZWN0ZWQ6IGZhbHNlLFxuICAgICAgICBoaWdoX2ZyZXFfY3V0b2ZmOiBhbmFseXNpcy5oaWdoRnJlcUN1dG9mZixcbiAgICAgICAgZm9ybWF0OiBhbmFseXNpcy5mb3JtYXQsXG4gICAgICAgIGJpdF9kZXB0aDogYW5hbHlzaXMuYml0RGVwdGgsXG4gICAgICAgIHNhbXBsZV9yYXRlOiBhbmFseXNpcy5zYW1wbGVSYXRlLFxuICAgICAgICBkdXJhdGlvbjogYW5hbHlzaXMuZHVyYXRpb24sXG4gICAgICB9LFxuICAgICAgYmxvY2tjaGFpbjoge1xuICAgICAgICBoYXNoOiBibG9ja2NoYWluSGFzaCxcbiAgICAgICAgcmVhbF9zaGEyNTY6ICEhZmlsZUhhc2gsXG4gICAgICAgIG90c19wcm9vZl91cGxvYWRlZDogb3RzUHJvb2ZVcGxvYWRlZCxcbiAgICAgIH0sXG4gICAgICBtZXRhZGF0YToge1xuICAgICAgICBjbGVhbmVkOiB0cnVlLFxuICAgICAgICBicmFuZGVkOiB0cnVlLFxuICAgICAgICBhcnRpc3Q6IHVzZXJuYW1lLFxuICAgICAgfSxcbiAgICAgIGdvbGRfcGFja19yZWFkeTogdHJ1ZSxcbiAgICB9O1xuXG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgnZGlzdHJpYnV0aW9uX2xvZ3MnKS5pbnNlcnQoe1xuICAgICAgdHJhY2tfaWQ6IHRyYWNrSWQsXG4gICAgICB1c2VyX2lkOiB0cmFjay51c2VyX2lkLFxuICAgICAgYWN0aW9uOiAncHJvY2Vzc2luZ19jb21wbGV0ZWQnLFxuICAgICAgc3RhZ2U6ICdsZXZlbF9wcm8nLFxuICAgICAgZGV0YWlsczogY29tcGxldGlvbkRldGFpbHMsXG4gICAgfSk7XG5cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdub3RpZmljYXRpb25zJykuaW5zZXJ0KHtcbiAgICAgIHVzZXJfaWQ6IHRyYWNrLnVzZXJfaWQsXG4gICAgICB0eXBlOiAnc3lzdGVtJyxcbiAgICAgIHRpdGxlOiAn8J+OiSDQl9C+0LvQvtGC0L7QuSDQv9Cw0LrQtdGCINCz0L7RgtC+0LIhJyxcbiAgICAgIG1lc3NhZ2U6IGDQotGA0LXQuiBcIiR7dHJhY2sudGl0bGV9XCIg0L/QvtC70L3QvtGB0YLRjNGOINC+0LHRgNCw0LHQvtGC0LDQvS4gV0FWICgtMTQgTFVGUyksIFhNTC3QvNC10YLQsNC00LDQvdC90YvQtSwg0YHQtdGA0YLQuNGE0LjQutCw0YIg0LggT1RTLdC00L7QutCw0LfQsNGC0LXQu9GM0YHRgtCy0L4g0LTQvtGB0YLRg9C/0L3RiyDQtNC70Y8g0YHQutCw0YfQuNCy0LDQvdC40Y8uYCxcbiAgICAgIHRhcmdldF90eXBlOiAndHJhY2snLFxuICAgICAgdGFyZ2V0X2lkOiB0cmFja0lkLFxuICAgIH0pO1xuXG4gICAgY29uc29sZS5sb2coYFtwcm9jZXNzLW1hc3Rlci1hdWRpb10g4pyFIENPTVBMRVRFRC4gQWxsIHN0YWdlcyBwYXNzZWQgd2l0aCByZWFsIHByb2Nlc3NpbmcuYCk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICBtZXNzYWdlOiAnR29sZCBwYWNrIGFzc2VtYmxlZCB3aXRoIHJlYWwgYXVkaW8gcHJvY2Vzc2luZycsXG4gICAgICAgIHN0YWdlc19jb21wbGV0ZWQ6IFBST0NFU1NJTkdfU1RBR0VTLmxlbmd0aCxcbiAgICAgICAgcmVhbF9wcm9jZXNzaW5nOiB0cnVlLFxuICAgICAgICBkZXRhaWxzOiBjb21wbGV0aW9uRGV0YWlscyxcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbcHJvY2Vzcy1tYXN0ZXItYXVkaW9dIEZBVEFMOicsIGVycm9yKTtcbiAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcic7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBtZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBT0EsTUFBTSxvQkFBb0I7RUFDeEI7SUFBRSxJQUFJO0lBQWMsTUFBTTtFQUE4QjtFQUN4RDtJQUFFLElBQUk7SUFBcUIsTUFBTTtFQUEwQztFQUMzRTtJQUFFLElBQUk7SUFBcUIsTUFBTTtFQUEwQjtFQUMzRDtJQUFFLElBQUk7SUFBaUIsTUFBTTtFQUEyQjtFQUN4RDtJQUFFLElBQUk7SUFBcUIsTUFBTTtFQUE4QjtFQUMvRDtJQUFFLElBQUk7SUFBbUIsTUFBTTtFQUE0QztFQUMzRTtJQUFFLElBQUk7SUFBMEIsTUFBTTtFQUF3QjtFQUM5RDtJQUFFLElBQUk7SUFBc0IsTUFBTTtFQUF5QjtDQUM1RDtBQUVELGdEQUFnRDtBQUNoRCw0QkFBNEI7QUFDNUIsZ0RBQWdEO0FBRWhELGVBQWUsUUFDYixHQUFXLEVBQ1gsUUFBZ0IsRUFDaEIsT0FBZ0MsRUFDaEMsWUFBWSxLQUFLLEVBQ2pCLE9BQWdDO0VBRWhDLElBQUk7SUFDRixNQUFNLGFBQWEsSUFBSTtJQUN2QixNQUFNLFlBQVksV0FBVyxJQUFNLFdBQVcsS0FBSyxJQUFJO0lBQ3ZELE1BQU0sYUFBcUM7TUFBRSxnQkFBZ0I7TUFBb0IsR0FBRyxPQUFPO0lBQUM7SUFFNUYsTUFBTSxPQUFPLE1BQU0sTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBQyxFQUFFO01BQzVDLFFBQVE7TUFDUixTQUFTO01BQ1QsTUFBTSxLQUFLLFNBQVMsQ0FBQztNQUNyQixRQUFRLFdBQVcsTUFBTTtJQUMzQjtJQUNBLGFBQWE7SUFFYixJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUU7TUFDWixNQUFNLFVBQVUsTUFBTSxLQUFLLElBQUk7TUFDL0IsUUFBUSxLQUFLLENBQUMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxPQUFPLEVBQUUsS0FBSyxNQUFNLENBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQztNQUNsRSxPQUFPO0lBQ1Q7SUFDQSxPQUFPLE1BQU0sS0FBSyxJQUFJO0VBQ3hCLEVBQUUsT0FBTyxHQUFHO0lBQ1YsUUFBUSxLQUFLLENBQUMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxRQUFRLENBQUMsRUFBRTtJQUMzQyxPQUFPO0VBQ1Q7QUFDRjtBQUVBLG1EQUFtRDtBQUNuRCxTQUFTLGNBQWMsR0FBUTtFQUM3QixNQUFNLGNBQWMsSUFBSSxPQUFPLEVBQUUsS0FBSyxDQUFDLElBQVcsRUFBRSxVQUFVLEtBQUssWUFBWSxDQUFDO0VBQ2hGLE1BQU0saUJBQWlCLElBQUksUUFBUSxFQUFFLG9CQUFvQjtFQUN6RCxNQUFNLGtCQUFrQixpQkFBaUI7RUFDekMsTUFBTSxlQUFlLElBQUksSUFBSSxFQUFFLGNBQWMsQ0FBQztFQUM5QyxNQUFNLFNBQVMsSUFBSSxJQUFJLEVBQUUsYUFBYSxDQUFDO0VBQ3ZDLE1BQU0sZUFBZSxJQUFJLElBQUksRUFBRSxTQUFTO0VBQ3hDLE1BQU0sYUFBYSxTQUFTLFlBQVksV0FBVyxLQUFLO0VBQ3hELE1BQU0sV0FBVyxZQUFZLGVBQWUsSUFBSTtFQUNoRCxNQUFNLFdBQVcsWUFBWSxRQUFRLElBQUk7RUFDekMsTUFBTSxXQUFXLFdBQVcsSUFBSSxNQUFNLEVBQUUsYUFBYTtFQUNyRCxNQUFNLFNBQVMsSUFBSSxNQUFNLEVBQUUsZUFBZTtFQUUxQyxJQUFJLGVBQWU7RUFDbkIsSUFBSSxpQkFBaUIsZ0JBQWdCO0VBQ3JDLElBQUksYUFBYSxPQUFPLGdCQUFnQjtFQUN4QyxJQUFJLFdBQVcsSUFBSSxnQkFBZ0I7RUFDbkMsSUFBSSxlQUFlLENBQUMsR0FBRyxnQkFBZ0I7RUFDdkMsZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLElBQUk7RUFFeEMsT0FBTztJQUNMO0lBQWdCO0lBQWlCO0lBQWM7SUFBUTtJQUN2RDtJQUFZO0lBQVU7SUFBVTtJQUFVO0lBQVE7SUFDbEQsZUFBZSxZQUFZLE1BQU07TUFBQztNQUFPO01BQVE7S0FBTyxDQUFDLFFBQVEsQ0FBQztFQUNwRTtBQUNGO0FBRUEseURBQXlEO0FBQ3pELGVBQWUsZ0JBQWdCLE9BQWU7RUFDNUMsSUFBSTtJQUNGLE1BQU0sYUFBYSxJQUFJO0lBQ3ZCLE1BQU0sWUFBWSxXQUFXLElBQU0sV0FBVyxLQUFLLElBQUksU0FBUyx3QkFBd0I7SUFDeEYsTUFBTSxPQUFPLE1BQU0sTUFBTSxTQUFTO01BQUUsUUFBUSxXQUFXLE1BQU07SUFBQztJQUM5RCxhQUFhO0lBRWIsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFO01BQ1osUUFBUSxLQUFLLENBQUMsQ0FBQywyQkFBMkIsRUFBRSxLQUFLLE1BQU0sQ0FBQyxDQUFDO01BQ3pELE9BQU87SUFDVDtJQUVBLE1BQU0sU0FBUyxNQUFNLEtBQUssV0FBVztJQUNyQyxNQUFNLGFBQWEsTUFBTSxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVztJQUN6RCxNQUFNLFVBQVUsTUFBTSxJQUFJLENBQUMsSUFBSSxXQUFXLGFBQ3ZDLEdBQUcsQ0FBQyxDQUFBLElBQUssRUFBRSxRQUFRLENBQUMsSUFBSSxRQUFRLENBQUMsR0FBRyxNQUNwQyxJQUFJLENBQUM7SUFFUixRQUFRLEdBQUcsQ0FBQyxDQUFDLG9CQUFvQixFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsT0FBTyxVQUFVLEdBQUcsT0FBTyxJQUFJLEVBQUUsT0FBTyxDQUFDLEdBQUcsR0FBRyxDQUFDO0lBQ2hHLE9BQU87RUFDVCxFQUFFLE9BQU8sR0FBRztJQUNWLFFBQVEsS0FBSyxDQUFDLENBQUMsaUJBQWlCLENBQUMsRUFBRTtJQUNuQyxPQUFPO0VBQ1Q7QUFDRjtBQUVBLGlEQUFpRDtBQUNqRCxlQUFlLHVCQUF1QixPQUFlO0VBQ25ELE1BQU0sWUFBWSxJQUFJLFdBQ3BCLFFBQVEsS0FBSyxDQUFDLFNBQVUsR0FBRyxDQUFDLENBQUEsT0FBUSxTQUFTLE1BQU07RUFHckQsTUFBTSxZQUFZO0lBQ2hCO0lBQ0E7SUFDQTtHQUNEO0VBRUQsS0FBSyxNQUFNLFlBQVksVUFBVztJQUNoQyxJQUFJO01BQ0YsTUFBTSxhQUFhLElBQUk7TUFDdkIsTUFBTSxZQUFZLFdBQVcsSUFBTSxXQUFXLEtBQUssSUFBSTtNQUV2RCxNQUFNLE9BQU8sTUFBTSxNQUFNLFVBQVU7UUFDakMsUUFBUTtRQUNSLFNBQVM7VUFDUCxnQkFBZ0I7VUFDaEIsVUFBVTtRQUNaO1FBQ0EsTUFBTTtRQUNOLFFBQVEsV0FBVyxNQUFNO01BQzNCO01BQ0EsYUFBYTtNQUViLElBQUksS0FBSyxFQUFFLEVBQUU7UUFDWCxNQUFNLGFBQWEsSUFBSSxXQUFXLE1BQU0sS0FBSyxXQUFXO1FBQ3hELFFBQVEsR0FBRyxDQUFDLENBQUMsMEJBQTBCLEVBQUUsU0FBUyxFQUFFLEVBQUUsV0FBVyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQ2hGLE9BQU87TUFDVCxPQUFPO1FBQ0wsTUFBTSxVQUFVLE1BQU0sS0FBSyxJQUFJO1FBQy9CLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLFNBQVMsVUFBVSxFQUFFLEtBQUssTUFBTSxDQUFDLEVBQUUsRUFBRSxRQUFRLENBQUM7TUFDckU7SUFDRixFQUFFLE9BQU8sR0FBRztNQUNWLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLFNBQVMsUUFBUSxDQUFDLEVBQUU7SUFDM0M7RUFDRjtFQUVBLFFBQVEsS0FBSyxDQUFDO0VBQ2QsT0FBTztBQUNUO0FBRUEsZ0RBQWdEO0FBQ2hELGVBQWU7QUFDZixnREFBZ0Q7QUFFaEQsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxXQUFXLGFBQ2YsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0lBRy9DLE1BQU0sRUFBRSxPQUFPLEVBQUUsY0FBYyxFQUFFLEdBQXlCLE1BQU0sSUFBSSxJQUFJO0lBQ3hFLFFBQVEsR0FBRyxDQUFDLENBQUMsNkRBQTZELEVBQUUsUUFBUSxDQUFDO0lBRXJGLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCO01BQy9CLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsOENBQThDO0lBQzlDLE1BQU0sRUFBRSxNQUFNLEtBQUssRUFBRSxPQUFPLFVBQVUsRUFBRSxHQUFHLE1BQU0sU0FDOUMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLEtBQ1AsRUFBRSxDQUFDLE1BQU0sU0FDVCxXQUFXO0lBRWQsSUFBSSxZQUFZO01BQ2QsUUFBUSxLQUFLLENBQUMsb0NBQW9DO01BQ2xELE1BQU0sSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsV0FBVyxPQUFPLENBQUMsQ0FBQztJQUN6RDtJQUNBLElBQUksQ0FBQyxPQUFPO01BQ1YsTUFBTSxJQUFJLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxRQUFRLENBQUM7SUFDL0M7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLCtCQUErQixFQUFFLE1BQU0sS0FBSyxDQUFDLFNBQVMsRUFBRSxNQUFNLE9BQU8sQ0FBQyxDQUFDO0lBRXBGLE1BQU0sVUFBVSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMscUJBQXFCO0lBQ2xELE1BQU0saUJBQWlCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNwQyxNQUFNLG9CQUFvQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDdkMsTUFBTSxnQkFBZ0Isb0JBQW9CO01BQUUsYUFBYTtJQUFrQixJQUFJO0lBRS9FLGdDQUFnQztJQUNoQyxJQUFJLFdBQVc7SUFDZixNQUFNLGNBQWMsT0FBTztNQUN6QjtNQUNBLE1BQU0sV0FBVyxLQUFLLEtBQUssQ0FBQyxBQUFDLFdBQVcsa0JBQWtCLE1BQU0sR0FBSTtNQUNwRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGdDQUFnQyxFQUFFLFNBQVMsQ0FBQyxFQUFFLGtCQUFrQixNQUFNLENBQUMsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLFNBQVMsRUFBRSxDQUFDO01BRWhILE1BQU0sU0FBUyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQUM7UUFDbkMsa0JBQWtCO1FBQ2xCLHFCQUFxQjtNQUN2QixHQUFHLEVBQUUsQ0FBQyxNQUFNO01BRVosTUFBTSxTQUFTLElBQUksQ0FBQyxxQkFBcUIsTUFBTSxDQUFDO1FBQzlDLFVBQVU7UUFDVixTQUFTLE1BQU0sT0FBTztRQUN0QixRQUFRLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQztRQUMxQixPQUFPO1FBQ1AsU0FBUztVQUFFLFlBQVksa0JBQWtCLElBQUksQ0FBQyxDQUFBLElBQUssRUFBRSxFQUFFLEtBQUssVUFBVTtRQUFLO01BQzdFO0lBQ0Y7SUFFQSxxQkFBcUI7SUFDckIsTUFBTSxTQUFTLElBQUksQ0FBQyxVQUFVLE1BQU0sQ0FBQztNQUNuQyxxQkFBcUI7TUFDckIsdUJBQXVCLElBQUksT0FBTyxXQUFXO01BQzdDLHFCQUFxQjtJQUN2QixHQUFHLEVBQUUsQ0FBQyxNQUFNO0lBRVosMkNBQTJDO0lBQzNDLHVEQUF1RDtJQUN2RCwwQ0FBMEM7SUFDMUMsMkNBQTJDO0lBQzNDLE1BQU0sWUFBWTtJQUVsQixNQUFNLGNBQWMsTUFBTSxRQUFRLFNBQVMsWUFBWTtNQUFFLFdBQVc7SUFBZSxHQUFHLE9BQU87SUFFN0YsSUFBSSxDQUFDLGFBQWE7TUFDaEIsUUFBUSxLQUFLLENBQUM7TUFDZCxNQUFNLFNBQVMsSUFBSSxDQUFDLFVBQVUsTUFBTSxDQUFDO1FBQ25DLHFCQUFxQjtRQUNyQixrQkFBa0I7UUFDbEIscUJBQXFCO01BQ3ZCLEdBQUcsRUFBRSxDQUFDLE1BQU07TUFFWixNQUFNLFNBQVMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7UUFDMUMsU0FBUyxNQUFNLE9BQU87UUFDdEIsTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTLENBQUMsbURBQW1ELEVBQUUsTUFBTSxLQUFLLENBQUMsZ0RBQWdELENBQUM7UUFDNUgsYUFBYTtRQUNiLFdBQVc7TUFDYjtNQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsU0FBUztRQUFPLE9BQU87UUFBbUIsU0FBUztNQUFvQyxJQUN4RztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFdBQVcsY0FBYztJQUMvQixRQUFRLEdBQUcsQ0FBQyxDQUFDLDBDQUEwQyxFQUFFLFNBQVMsTUFBTSxDQUFDLEVBQUUsRUFBRSxTQUFTLFFBQVEsQ0FBQyxJQUFJLEVBQUUsU0FBUyxVQUFVLENBQUMsU0FBUyxFQUFFLFNBQVMsWUFBWSxDQUFDLFVBQVUsRUFBRSxTQUFTLFlBQVksQ0FBQyxHQUFHLENBQUM7SUFFaE0sd0NBQXdDO0lBQ3hDLE1BQU0sU0FBUyxJQUFJLENBQUMsd0JBQXdCLE1BQU0sQ0FBQztNQUNqRCxVQUFVO01BQ1YsZUFBZSxTQUFTLFlBQVk7TUFDcEMsZUFBZSxTQUFTLFlBQVk7TUFDcEMsU0FBUyxTQUFTLE1BQU07TUFDeEIsZUFBZSxTQUFTLFlBQVk7TUFDcEMsYUFBYSxDQUFDLFNBQVMsZUFBZTtNQUN0QyxrQkFBa0IsU0FBUyxjQUFjO01BQ3pDLGtCQUFrQixTQUFTLGVBQWU7TUFDMUMsYUFBYSxTQUFTLFVBQVU7TUFDaEMsV0FBVyxTQUFTLFFBQVE7TUFDNUIsVUFBVSxTQUFTLFFBQVE7TUFDM0IsVUFBVSxTQUFTLFFBQVE7TUFDM0IsUUFBUSxTQUFTLE1BQU07TUFDdkIsZ0JBQWdCLFNBQVMsYUFBYTtNQUN0QyxpQkFBaUI7TUFDakIsWUFBWSxJQUFJLE9BQU8sV0FBVztJQUNwQyxHQUFHO01BQUUsWUFBWTtJQUFXO0lBRTVCLDZCQUE2QjtJQUM3QixNQUFNLFlBQVk7SUFFbEIsSUFBSSxTQUFTLGVBQWUsRUFBRTtNQUM1QixRQUFRLEdBQUcsQ0FBQyxDQUFDLGtEQUFrRCxFQUFFLFNBQVMsY0FBYyxDQUFDLHNCQUFzQixDQUFDO01BRWhILE1BQU0sU0FBUyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQUM7UUFDbkMscUJBQXFCO1FBQ3JCLGtCQUFrQjtRQUNsQixrQkFBa0I7UUFDbEIscUJBQXFCO01BQ3ZCLEdBQUcsRUFBRSxDQUFDLE1BQU07TUFFWixNQUFNLFNBQVMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7UUFDMUMsU0FBUyxNQUFNLE9BQU87UUFDdEIsTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTLENBQUMsTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDLGtEQUFrRCxFQUFFLFNBQVMsY0FBYyxDQUFDLGdFQUFnRSxDQUFDO1FBQzNLLGFBQWE7UUFDYixXQUFXO01BQ2I7TUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVCxPQUFPO1FBQ1AsU0FBUyxDQUFDLDJCQUEyQixFQUFFLFNBQVMsY0FBYyxDQUFDLGtDQUFrQyxDQUFDO1FBQ2xHLGtCQUFrQixTQUFTLGNBQWM7TUFDM0MsSUFDQTtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLDZCQUE2QjtJQUM3QixNQUFNLFlBQVk7SUFFbEIsTUFBTSxTQUFTLElBQUksQ0FBQyxVQUFVLE1BQU0sQ0FBQztNQUNuQyxxQkFBcUIsU0FBUyxZQUFZO01BQzFDLG1CQUFtQixTQUFTLFVBQVU7TUFDdEMsaUJBQWlCLFNBQVMsUUFBUTtNQUNsQyxZQUFZLFNBQVMsWUFBWTtNQUNqQyxlQUFlLFNBQVMsTUFBTTtNQUM5QixrQkFBa0I7SUFDcEIsR0FBRyxFQUFFLENBQUMsTUFBTTtJQUVaLDJDQUEyQztJQUMzQyxvQ0FBb0M7SUFDcEMsMkNBQTJDO0lBQzNDLE1BQU0sWUFBWTtJQUVsQixJQUFJLGVBQWU7SUFDbkIsSUFBSSxpQkFBaUIsU0FBUyxZQUFZO0lBQzFDLE1BQU0sWUFBWSxLQUFLLEdBQUcsQ0FBQyxTQUFTLFlBQVksR0FBSSxDQUFDLE1BQU87SUFFNUQsSUFBSSxXQUFXO01BQ2IsUUFBUSxHQUFHLENBQUMsQ0FBQyxvQ0FBb0MsRUFBRSxTQUFTLFlBQVksQ0FBQyxXQUFXLENBQUM7TUFFckYsTUFBTSxhQUFhLE1BQU0sUUFBUSxTQUFTLGNBQWM7UUFDdEQsV0FBVztRQUNYLGFBQWEsQ0FBQztRQUNkLGdCQUFnQjtRQUNoQixnQkFBZ0I7TUFDbEIsR0FBRyxPQUFPLGdCQUFnQixzQkFBc0I7TUFFaEQsSUFBSSxZQUFZLGdCQUFnQjtRQUM5QixlQUFlLFdBQVcsY0FBYztRQUN4QyxpQkFBaUIsV0FBVyxlQUFlLElBQUksQ0FBQztRQUNoRCxRQUFRLEdBQUcsQ0FBQyxDQUFDLHFDQUFxQyxFQUFFLFNBQVMsWUFBWSxDQUFDLEdBQUcsRUFBRSxlQUFlLEtBQUssQ0FBQztNQUN0RyxPQUFPO1FBQ0wsUUFBUSxHQUFHLENBQUMsQ0FBQywrREFBK0QsQ0FBQztNQUMvRTtJQUNGLE9BQU87TUFDTCxRQUFRLEdBQUcsQ0FBQyxDQUFDLGdEQUFnRCxFQUFFLFNBQVMsWUFBWSxDQUFDLDBCQUEwQixDQUFDO0lBQ2xIO0lBRUEsTUFBTSxTQUFTLElBQUksQ0FBQyxVQUFVLE1BQU0sQ0FBQztNQUNuQyxpQkFBaUI7TUFDakIsWUFBWTtNQUNaLHNCQUFzQjtJQUN4QixHQUFHLEVBQUUsQ0FBQyxNQUFNO0lBRVosTUFBTSxTQUFTLElBQUksQ0FBQyx3QkFBd0IsTUFBTSxDQUFDO01BQ2pELGlCQUFpQjtNQUNqQixzQkFBc0I7TUFDdEIsc0JBQXNCO0lBQ3hCLEdBQUcsRUFBRSxDQUFDLFlBQVk7SUFFbEIsMkNBQTJDO0lBQzNDLHdDQUF3QztJQUN4QywyQ0FBMkM7SUFDM0MsTUFBTSxZQUFZO0lBRWxCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxHQUFHLE1BQU0sU0FDN0IsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLFlBQ1AsRUFBRSxDQUFDLFdBQVcsTUFBTSxPQUFPLEVBQzNCLFdBQVc7SUFFZCxNQUFNLFdBQVcsU0FBUyxZQUFZO0lBRXRDLDREQUE0RDtJQUM1RCxJQUFJLGtCQUFrQixtQkFBbUI7TUFDdkMsUUFBUSxHQUFHLENBQUMsQ0FBQywyREFBMkQsQ0FBQztNQUV6RSxNQUFNLGFBQWEsTUFBTSxRQUFRLGdCQUFnQixtQkFBbUI7UUFDbEUsV0FBVztRQUNYLFVBQVU7VUFDUixPQUFPLE1BQU0sS0FBSztVQUNsQixRQUFRO1VBQ1IsT0FBTztVQUNQLFdBQVc7VUFDWCxTQUFTLENBQUMsK0JBQStCLEVBQUUsU0FBUyxDQUFDO1VBQ3JELFdBQVcsQ0FBQyxFQUFFLEVBQUUsSUFBSSxPQUFPLFdBQVcsR0FBRyxDQUFDLEVBQUUsU0FBUyxXQUFXLENBQUM7VUFDakUsUUFBUTtZQUNOLGNBQWMsTUFBTSxPQUFPO1lBQzNCLGVBQWU7WUFDZixjQUFjO1lBQ2QsV0FBVyxJQUFJLE9BQU8sV0FBVyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNqRCxlQUFlO1VBQ2pCO1FBQ0Y7TUFDRixHQUFHLE9BQU87UUFBRSxhQUFhO01BQWtCO01BRTNDLElBQUksWUFBWSxhQUFhO1FBQzNCLGVBQWUsV0FBVyxXQUFXO1FBQ3JDLFFBQVEsR0FBRyxDQUFDLENBQUMsd0RBQXdELENBQUM7TUFDeEU7SUFDRixPQUFPO01BQ0wsUUFBUSxHQUFHLENBQUMsQ0FBQywyREFBMkQsQ0FBQztNQUV6RSxNQUFNLGFBQWEsTUFBTSxRQUFRLFNBQVMsY0FBYztRQUN0RCxXQUFXO1FBQ1gsYUFBYSxDQUFDO1FBQ2QsZ0JBQWdCO1FBQ2hCLGdCQUFnQjtRQUNoQixVQUFVO1VBQ1IsUUFBUTtVQUNSLE9BQU8sTUFBTSxLQUFLO1VBQ2xCLE9BQU87VUFDUCxTQUFTLENBQUMsK0JBQStCLEVBQUUsU0FBUyxDQUFDO1VBQ3JELE1BQU0sSUFBSSxPQUFPLFdBQVcsR0FBRyxRQUFRO1VBQ3ZDLFNBQVM7VUFDVCxXQUFXLENBQUMsRUFBRSxFQUFFLElBQUksT0FBTyxXQUFXLEdBQUcsQ0FBQyxFQUFFLFNBQVMsV0FBVyxDQUFDO1VBQ2pFLFNBQVMsTUFBTSxPQUFPO1VBQ3RCLFNBQVM7UUFDWDtNQUNGLEdBQUcsT0FBTztNQUVWLElBQUksWUFBWSxnQkFBZ0I7UUFDOUIsZUFBZSxXQUFXLGNBQWM7UUFDeEMsUUFBUSxHQUFHLENBQUMsQ0FBQywyREFBMkQsQ0FBQztNQUMzRTtJQUNGO0lBRUEsTUFBTSxTQUFTLElBQUksQ0FBQyxVQUFVLE1BQU0sQ0FBQztNQUNuQyxrQkFBa0I7TUFDbEIsa0JBQWtCO0lBQ3BCLEdBQUcsRUFBRSxDQUFDLE1BQU07SUFFWiwyQ0FBMkM7SUFDM0Msc0RBQXNEO0lBQ3RELDJDQUEyQztJQUMzQyxNQUFNLFlBQVk7SUFFbEIsMkRBQTJEO0lBQzNELE1BQU0sV0FBVyxNQUFNLGdCQUFnQjtJQUV2QyxJQUFJO0lBQ0osSUFBSSxtQkFBbUI7SUFFdkIsSUFBSSxVQUFVO01BQ1osaUJBQWlCLENBQUMsRUFBRSxFQUFFLFNBQVMsQ0FBQztNQUNoQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLHVDQUF1QyxFQUFFLGVBQWUsQ0FBQztNQUV0RSx5REFBeUQ7TUFDekQsTUFBTSxXQUFXLE1BQU0sdUJBQXVCO01BRTlDLElBQUksVUFBVTtRQUNaLDhCQUE4QjtRQUM5QixJQUFJO1VBQ0YsTUFBTSxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsUUFBUSxVQUFVLENBQUM7VUFDdkQsTUFBTSxTQUFTLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQzFDLGVBQ0EsVUFDQTtZQUFFLFFBQVE7WUFBTSxhQUFhO1VBQW9DO1VBRW5FLG1CQUFtQjtVQUNuQixRQUFRLEdBQUcsQ0FBQyxDQUFDLHNEQUFzRCxDQUFDO1FBQ3RFLEVBQUUsT0FBTyxHQUFHO1VBQ1YsUUFBUSxLQUFLLENBQUMsQ0FBQywrQ0FBK0MsQ0FBQyxFQUFFO1FBQ25FO01BQ0Y7SUFDRixPQUFPO01BQ0wsNERBQTREO01BQzVELE1BQU0sZ0JBQWdCLElBQUksY0FBYyxNQUFNLENBQUMsZUFBZSxLQUFLLEdBQUcsR0FBRyxRQUFRO01BQ2pGLE1BQU0saUJBQWlCLE1BQU0sT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVc7TUFDN0QsTUFBTSxjQUFjLE1BQU0sSUFBSSxDQUFDLElBQUksV0FBVyxpQkFDM0MsR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxHQUFHLE1BQ3BDLElBQUksQ0FBQztNQUNSLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUM7TUFDekMsUUFBUSxHQUFHLENBQUMsQ0FBQyxtRUFBbUUsQ0FBQztJQUNuRjtJQUVBLE1BQU0sU0FBUyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQUM7TUFDbkMsaUJBQWlCO0lBQ25CLEdBQUcsRUFBRSxDQUFDLE1BQU07SUFFWiwyQ0FBMkM7SUFDM0Msa0NBQWtDO0lBQ2xDLDZDQUE2QztJQUM3QywyQ0FBMkM7SUFDM0MsTUFBTSxZQUFZO0lBRWxCLE1BQU0saUJBQWlCLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLDRDQUE0QyxFQUFFLFFBQVEsaUJBQWlCLENBQUM7SUFDL0gsTUFBTSxTQUFTLElBQUksQ0FBQyxVQUFVLE1BQU0sQ0FBQztNQUNuQyxpQkFBaUI7SUFDbkIsR0FBRyxFQUFFLENBQUMsTUFBTTtJQUVaLDJDQUEyQztJQUMzQyw4QkFBOEI7SUFDOUIsMkNBQTJDO0lBQzNDLE1BQU0sWUFBWTtJQUVsQixJQUFJO01BQ0YsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztNQUNqQyxNQUFNLGFBQWEsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO01BRWhDLE1BQU0sbUJBQW1CLE1BQU0sTUFDN0IsQ0FBQyxFQUFFLFlBQVksZ0NBQWdDLENBQUMsRUFDaEQ7UUFDRSxRQUFRO1FBQ1IsU0FBUztVQUNQLGdCQUFnQjtVQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDO1FBQ3pDO1FBQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztVQUFFO1FBQVE7TUFDakM7TUFHRixNQUFNLGlCQUFpQixNQUFNLGlCQUFpQixJQUFJO01BQ2xELFFBQVEsR0FBRyxDQUFDLENBQUMsbUNBQW1DLENBQUMsRUFBRTtJQUNyRCxFQUFFLE9BQU8sU0FBUztNQUNoQixRQUFRLEtBQUssQ0FBQywyQ0FBMkM7SUFDM0Q7SUFFQSwyQ0FBMkM7SUFDM0MsZUFBZTtJQUNmLDJDQUEyQztJQUMzQyxNQUFNLFNBQVMsSUFBSSxDQUFDLFVBQVUsTUFBTSxDQUFDO01BQ25DLHFCQUFxQjtNQUNyQixrQkFBa0I7TUFDbEIscUJBQXFCO01BQ3JCLHlCQUF5QixJQUFJLE9BQU8sV0FBVztNQUMvQyxrQkFBa0I7SUFDcEIsR0FBRyxFQUFFLENBQUMsTUFBTTtJQUVaLE1BQU0sb0JBQW9CO01BQ3hCLGlCQUFpQjtNQUNqQixTQUFTO01BQ1QsVUFBVTtRQUNSLGVBQWUsU0FBUyxZQUFZO1FBQ3BDLGVBQWUsU0FBUyxZQUFZO1FBQ3BDLGlCQUFpQjtRQUNqQix1QkFBdUI7UUFDdkIsa0JBQWtCO1FBQ2xCLGtCQUFrQixTQUFTLGNBQWM7UUFDekMsUUFBUSxTQUFTLE1BQU07UUFDdkIsV0FBVyxTQUFTLFFBQVE7UUFDNUIsYUFBYSxTQUFTLFVBQVU7UUFDaEMsVUFBVSxTQUFTLFFBQVE7TUFDN0I7TUFDQSxZQUFZO1FBQ1YsTUFBTTtRQUNOLGFBQWEsQ0FBQyxDQUFDO1FBQ2Ysb0JBQW9CO01BQ3RCO01BQ0EsVUFBVTtRQUNSLFNBQVM7UUFDVCxTQUFTO1FBQ1QsUUFBUTtNQUNWO01BQ0EsaUJBQWlCO0lBQ25CO0lBRUEsTUFBTSxTQUFTLElBQUksQ0FBQyxxQkFBcUIsTUFBTSxDQUFDO01BQzlDLFVBQVU7TUFDVixTQUFTLE1BQU0sT0FBTztNQUN0QixRQUFRO01BQ1IsT0FBTztNQUNQLFNBQVM7SUFDWDtJQUVBLE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztNQUMxQyxTQUFTLE1BQU0sT0FBTztNQUN0QixNQUFNO01BQ04sT0FBTztNQUNQLFNBQVMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUMsK0dBQStHLENBQUM7TUFDOUksYUFBYTtNQUNiLFdBQVc7SUFDYjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsMkVBQTJFLENBQUM7SUFFekYsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsU0FBUztNQUNULGtCQUFrQixrQkFBa0IsTUFBTTtNQUMxQyxpQkFBaUI7TUFDakIsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyxpQ0FBaUM7SUFDL0MsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztNQUFPLE9BQU87SUFBUSxJQUNoRDtNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRiJ9
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const supabase = createClient(supabaseUrl, supabaseServiceKey);
  try {
    const body = await req.json();
    console.log("Suno video callback received:", JSON.stringify(body));
    const { code, msg, data } = body;
    if (code !== 200) {
      console.error(`Suno video callback error: ${msg}`);
      return new Response(JSON.stringify({
        received: true,
        error: msg
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Extract task_id and video_url - Suno may send different formats
    const task_id = data?.task_id;
    const video_url = data?.video_url;
    // Determine callback type from response structure
    let callbackType = data?.callbackType;
    if (!callbackType && video_url) {
      callbackType = "complete"; // If we have video_url, it's complete
    }
    console.log(`Video callback type: ${callbackType}, task_id: ${task_id}`);
    // Find the track addon with this video task ID
    // The result_url field contains JSON with video_task_id
    const { data: addons, error: findError } = await supabase.from("track_addons").select("*, addon_services!inner(name), tracks!inner(id, user_id, title, suno_audio_id)").eq("addon_services.name", "short_video").eq("status", "processing");
    if (findError) {
      console.error("Error finding addons:", findError);
      return new Response(JSON.stringify({
        received: true,
        error: "Error finding addon"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Find the addon that matches this video task_id
    let matchedAddon = null;
    for (const addon of addons || []){
      try {
        const resultData = typeof addon.result_url === 'string' ? JSON.parse(addon.result_url) : addon.result_url;
        if (resultData?.video_task_id === task_id) {
          matchedAddon = addon;
          break;
        }
      } catch (e) {
        console.log(`Failed to parse result_url for addon ${addon.id}:`, e);
      }
    }
    if (!matchedAddon) {
      console.log("No matching addon found for video task_id:", task_id);
      return new Response(JSON.stringify({
        received: true,
        message: "No matching addon"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const trackData = matchedAddon.tracks;
    const trackId = trackData.id;
    const userId = trackData.user_id;
    const trackTitle = trackData.title;
    console.log(`Found addon ${matchedAddon.id} for track ${trackId}`);
    if (callbackType === "complete" || callbackType === "SUCCESS") {
      // Video generation completed - use video_url from data directly
      const finalVideoUrl = video_url || data?.data?.[0]?.video_url || data?.data?.[0]?.mp4_url;
      console.log(`Video completed for track ${trackId}, URL: ${finalVideoUrl}`);
      const { error: updateError } = await supabase.from("track_addons").update({
        status: "completed",
        result_url: finalVideoUrl || JSON.stringify(data),
        updated_at: new Date().toISOString()
      }).eq("id", matchedAddon.id);
      if (updateError) {
        console.error("Error updating addon:", updateError);
      }
      // Create notification for user
      await supabase.from("notifications").insert({
        user_id: userId,
        type: "addon_completed",
        title: "Музыкальное видео готово",
        message: `Видео для трека "${trackTitle}" успешно создано`,
        target_type: "track",
        target_id: trackId
      });
    } else if (callbackType === "FAILED" || callbackType === "error") {
      // Video generation failed
      console.error(`Video generation failed for track ${trackId}: ${msg}`);
      const { error: updateError } = await supabase.from("track_addons").update({
        status: "failed",
        result_url: JSON.stringify({
          error: msg || "Video generation failed"
        }),
        updated_at: new Date().toISOString()
      }).eq("id", matchedAddon.id);
      if (updateError) {
        console.error("Error updating addon:", updateError);
      }
      // Create notification for user
      await supabase.from("notifications").insert({
        user_id: userId,
        type: "addon_failed",
        title: "Ошибка создания видео",
        message: `Не удалось создать видео для трека "${trackTitle}"`,
        target_type: "track",
        target_id: trackId
      });
    }
    return new Response(JSON.stringify({
      received: true,
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("suno-video-callback error:", error);
    return new Response(JSON.stringify({
      received: true,
      error: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9zdW5vLXZpZGVvLWNhbGxiYWNrL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE2OC4wL2h0dHAvc2VydmVyLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICB0cnkge1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKFwiU3VubyB2aWRlbyBjYWxsYmFjayByZWNlaXZlZDpcIiwgSlNPTi5zdHJpbmdpZnkoYm9keSkpO1xuXG4gICAgY29uc3QgeyBjb2RlLCBtc2csIGRhdGEgfSA9IGJvZHk7XG5cbiAgICBpZiAoY29kZSAhPT0gMjAwKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBTdW5vIHZpZGVvIGNhbGxiYWNrIGVycm9yOiAke21zZ31gKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoeyByZWNlaXZlZDogdHJ1ZSwgZXJyb3I6IG1zZyB9KSwge1xuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gRXh0cmFjdCB0YXNrX2lkIGFuZCB2aWRlb191cmwgLSBTdW5vIG1heSBzZW5kIGRpZmZlcmVudCBmb3JtYXRzXG4gICAgY29uc3QgdGFza19pZCA9IGRhdGE/LnRhc2tfaWQ7XG4gICAgY29uc3QgdmlkZW9fdXJsID0gZGF0YT8udmlkZW9fdXJsO1xuICAgIFxuICAgIC8vIERldGVybWluZSBjYWxsYmFjayB0eXBlIGZyb20gcmVzcG9uc2Ugc3RydWN0dXJlXG4gICAgbGV0IGNhbGxiYWNrVHlwZSA9IGRhdGE/LmNhbGxiYWNrVHlwZTtcbiAgICBpZiAoIWNhbGxiYWNrVHlwZSAmJiB2aWRlb191cmwpIHtcbiAgICAgIGNhbGxiYWNrVHlwZSA9IFwiY29tcGxldGVcIjsgLy8gSWYgd2UgaGF2ZSB2aWRlb191cmwsIGl0J3MgY29tcGxldGVcbiAgICB9XG4gICAgY29uc29sZS5sb2coYFZpZGVvIGNhbGxiYWNrIHR5cGU6ICR7Y2FsbGJhY2tUeXBlfSwgdGFza19pZDogJHt0YXNrX2lkfWApO1xuXG4gICAgLy8gRmluZCB0aGUgdHJhY2sgYWRkb24gd2l0aCB0aGlzIHZpZGVvIHRhc2sgSURcbiAgICAvLyBUaGUgcmVzdWx0X3VybCBmaWVsZCBjb250YWlucyBKU09OIHdpdGggdmlkZW9fdGFza19pZFxuICAgIGNvbnN0IHsgZGF0YTogYWRkb25zLCBlcnJvcjogZmluZEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJ0cmFja19hZGRvbnNcIilcbiAgICAgIC5zZWxlY3QoXCIqLCBhZGRvbl9zZXJ2aWNlcyFpbm5lcihuYW1lKSwgdHJhY2tzIWlubmVyKGlkLCB1c2VyX2lkLCB0aXRsZSwgc3Vub19hdWRpb19pZClcIilcbiAgICAgIC5lcShcImFkZG9uX3NlcnZpY2VzLm5hbWVcIiwgXCJzaG9ydF92aWRlb1wiKVxuICAgICAgLmVxKFwic3RhdHVzXCIsIFwicHJvY2Vzc2luZ1wiKTtcblxuICAgIGlmIChmaW5kRXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmaW5kaW5nIGFkZG9uczpcIiwgZmluZEVycm9yKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoeyByZWNlaXZlZDogdHJ1ZSwgZXJyb3I6IFwiRXJyb3IgZmluZGluZyBhZGRvblwiIH0pLCB7XG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBGaW5kIHRoZSBhZGRvbiB0aGF0IG1hdGNoZXMgdGhpcyB2aWRlbyB0YXNrX2lkXG4gICAgbGV0IG1hdGNoZWRBZGRvbiA9IG51bGw7XG4gICAgZm9yIChjb25zdCBhZGRvbiBvZiBhZGRvbnMgfHwgW10pIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdERhdGEgPSB0eXBlb2YgYWRkb24ucmVzdWx0X3VybCA9PT0gJ3N0cmluZycgXG4gICAgICAgICAgPyBKU09OLnBhcnNlKGFkZG9uLnJlc3VsdF91cmwpIFxuICAgICAgICAgIDogYWRkb24ucmVzdWx0X3VybDtcbiAgICAgICAgXG4gICAgICAgIGlmIChyZXN1bHREYXRhPy52aWRlb190YXNrX2lkID09PSB0YXNrX2lkKSB7XG4gICAgICAgICAgbWF0Y2hlZEFkZG9uID0gYWRkb247XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS5sb2coYEZhaWxlZCB0byBwYXJzZSByZXN1bHRfdXJsIGZvciBhZGRvbiAke2FkZG9uLmlkfTpgLCBlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoIW1hdGNoZWRBZGRvbikge1xuICAgICAgY29uc29sZS5sb2coXCJObyBtYXRjaGluZyBhZGRvbiBmb3VuZCBmb3IgdmlkZW8gdGFza19pZDpcIiwgdGFza19pZCk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHsgcmVjZWl2ZWQ6IHRydWUsIG1lc3NhZ2U6IFwiTm8gbWF0Y2hpbmcgYWRkb25cIiB9KSwge1xuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgY29uc3QgdHJhY2tEYXRhID0gbWF0Y2hlZEFkZG9uLnRyYWNrcyBhcyB7IGlkOiBzdHJpbmc7IHVzZXJfaWQ6IHN0cmluZzsgdGl0bGU6IHN0cmluZzsgc3Vub19hdWRpb19pZDogc3RyaW5nIHwgbnVsbCB9O1xuICAgIGNvbnN0IHRyYWNrSWQgPSB0cmFja0RhdGEuaWQ7XG4gICAgY29uc3QgdXNlcklkID0gdHJhY2tEYXRhLnVzZXJfaWQ7XG4gICAgY29uc3QgdHJhY2tUaXRsZSA9IHRyYWNrRGF0YS50aXRsZTtcblxuICAgIGNvbnNvbGUubG9nKGBGb3VuZCBhZGRvbiAke21hdGNoZWRBZGRvbi5pZH0gZm9yIHRyYWNrICR7dHJhY2tJZH1gKTtcblxuICAgIGlmIChjYWxsYmFja1R5cGUgPT09IFwiY29tcGxldGVcIiB8fCBjYWxsYmFja1R5cGUgPT09IFwiU1VDQ0VTU1wiKSB7XG4gICAgICAvLyBWaWRlbyBnZW5lcmF0aW9uIGNvbXBsZXRlZCAtIHVzZSB2aWRlb191cmwgZnJvbSBkYXRhIGRpcmVjdGx5XG4gICAgICBjb25zdCBmaW5hbFZpZGVvVXJsID0gdmlkZW9fdXJsIHx8IGRhdGE/LmRhdGE/LlswXT8udmlkZW9fdXJsIHx8IGRhdGE/LmRhdGE/LlswXT8ubXA0X3VybDtcblxuICAgICAgY29uc29sZS5sb2coYFZpZGVvIGNvbXBsZXRlZCBmb3IgdHJhY2sgJHt0cmFja0lkfSwgVVJMOiAke2ZpbmFsVmlkZW9Vcmx9YCk7XG5cbiAgICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgcmVzdWx0X3VybDogZmluYWxWaWRlb1VybCB8fCBKU09OLnN0cmluZ2lmeShkYXRhKSxcbiAgICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIG1hdGNoZWRBZGRvbi5pZCk7XG5cbiAgICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgYWRkb246XCIsIHVwZGF0ZUVycm9yKTtcbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIG5vdGlmaWNhdGlvbiBmb3IgdXNlclxuICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcIm5vdGlmaWNhdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogdXNlcklkLFxuICAgICAgICB0eXBlOiBcImFkZG9uX2NvbXBsZXRlZFwiLFxuICAgICAgICB0aXRsZTogXCLQnNGD0LfRi9C60LDQu9GM0L3QvtC1INCy0LjQtNC10L4g0LPQvtGC0L7QstC+XCIsXG4gICAgICAgIG1lc3NhZ2U6IGDQktC40LTQtdC+INC00LvRjyDRgtGA0LXQutCwIFwiJHt0cmFja1RpdGxlfVwiINGD0YHQv9C10YjQvdC+INGB0L7Qt9C00LDQvdC+YCxcbiAgICAgICAgdGFyZ2V0X3R5cGU6IFwidHJhY2tcIixcbiAgICAgICAgdGFyZ2V0X2lkOiB0cmFja0lkLFxuICAgICAgfSk7XG5cbiAgICB9IGVsc2UgaWYgKGNhbGxiYWNrVHlwZSA9PT0gXCJGQUlMRURcIiB8fCBjYWxsYmFja1R5cGUgPT09IFwiZXJyb3JcIikge1xuICAgICAgLy8gVmlkZW8gZ2VuZXJhdGlvbiBmYWlsZWRcbiAgICAgIGNvbnNvbGUuZXJyb3IoYFZpZGVvIGdlbmVyYXRpb24gZmFpbGVkIGZvciB0cmFjayAke3RyYWNrSWR9OiAke21zZ31gKTtcblxuICAgICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgICByZXN1bHRfdXJsOiBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBtc2cgfHwgXCJWaWRlbyBnZW5lcmF0aW9uIGZhaWxlZFwiIH0pLFxuICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgbWF0Y2hlZEFkZG9uLmlkKTtcblxuICAgICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBhZGRvbjpcIiwgdXBkYXRlRXJyb3IpO1xuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgbm90aWZpY2F0aW9uIGZvciB1c2VyXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwibm90aWZpY2F0aW9uc1wiKS5pbnNlcnQoe1xuICAgICAgICB1c2VyX2lkOiB1c2VySWQsXG4gICAgICAgIHR5cGU6IFwiYWRkb25fZmFpbGVkXCIsXG4gICAgICAgIHRpdGxlOiBcItCe0YjQuNCx0LrQsCDRgdC+0LfQtNCw0L3QuNGPINCy0LjQtNC10L5cIixcbiAgICAgICAgbWVzc2FnZTogYNCd0LUg0YPQtNCw0LvQvtGB0Ywg0YHQvtC30LTQsNGC0Ywg0LLQuNC00LXQviDQtNC70Y8g0YLRgNC10LrQsCBcIiR7dHJhY2tUaXRsZX1cImAsXG4gICAgICAgIHRhcmdldF90eXBlOiBcInRyYWNrXCIsXG4gICAgICAgIHRhcmdldF9pZDogdHJhY2tJZCxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHJlY2VpdmVkOiB0cnVlLCBzdWNjZXNzOiB0cnVlIH0pLFxuICAgICAge1xuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgfVxuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcInN1bm8tdmlkZW8tY2FsbGJhY2sgZXJyb3I6XCIsIGVycm9yKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICByZWNlaXZlZDogdHJ1ZSxcbiAgICAgICAgZXJyb3I6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCIsXG4gICAgICB9KSxcbiAgICAgIHtcbiAgICAgICAgc3RhdHVzOiA1MDAsXG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxLQUFLLFFBQVEsK0NBQStDO0FBQ3JFLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUNqQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFDeEMsTUFBTSxXQUFXLGFBQWEsYUFBYTtFQUUzQyxJQUFJO0lBQ0YsTUFBTSxPQUFPLE1BQU0sSUFBSSxJQUFJO0lBQzNCLFFBQVEsR0FBRyxDQUFDLGlDQUFpQyxLQUFLLFNBQVMsQ0FBQztJQUU1RCxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBRztJQUU1QixJQUFJLFNBQVMsS0FBSztNQUNoQixRQUFRLEtBQUssQ0FBQyxDQUFDLDJCQUEyQixFQUFFLElBQUksQ0FBQztNQUNqRCxPQUFPLElBQUksU0FBUyxLQUFLLFNBQVMsQ0FBQztRQUFFLFVBQVU7UUFBTSxPQUFPO01BQUksSUFBSTtRQUNsRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQ2hFO0lBQ0Y7SUFFQSxrRUFBa0U7SUFDbEUsTUFBTSxVQUFVLE1BQU07SUFDdEIsTUFBTSxZQUFZLE1BQU07SUFFeEIsa0RBQWtEO0lBQ2xELElBQUksZUFBZSxNQUFNO0lBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsV0FBVztNQUM5QixlQUFlLFlBQVksc0NBQXNDO0lBQ25FO0lBQ0EsUUFBUSxHQUFHLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxhQUFhLFdBQVcsRUFBRSxRQUFRLENBQUM7SUFFdkUsK0NBQStDO0lBQy9DLHdEQUF3RDtJQUN4RCxNQUFNLEVBQUUsTUFBTSxNQUFNLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLFNBQzlDLElBQUksQ0FBQyxnQkFDTCxNQUFNLENBQUMsa0ZBQ1AsRUFBRSxDQUFDLHVCQUF1QixlQUMxQixFQUFFLENBQUMsVUFBVTtJQUVoQixJQUFJLFdBQVc7TUFDYixRQUFRLEtBQUssQ0FBQyx5QkFBeUI7TUFDdkMsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7UUFBRSxVQUFVO1FBQU0sT0FBTztNQUFzQixJQUFJO1FBQ3BGLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFDaEU7SUFDRjtJQUVBLGlEQUFpRDtJQUNqRCxJQUFJLGVBQWU7SUFDbkIsS0FBSyxNQUFNLFNBQVMsVUFBVSxFQUFFLENBQUU7TUFDaEMsSUFBSTtRQUNGLE1BQU0sYUFBYSxPQUFPLE1BQU0sVUFBVSxLQUFLLFdBQzNDLEtBQUssS0FBSyxDQUFDLE1BQU0sVUFBVSxJQUMzQixNQUFNLFVBQVU7UUFFcEIsSUFBSSxZQUFZLGtCQUFrQixTQUFTO1VBQ3pDLGVBQWU7VUFDZjtRQUNGO01BQ0YsRUFBRSxPQUFPLEdBQUc7UUFDVixRQUFRLEdBQUcsQ0FBQyxDQUFDLHFDQUFxQyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFO01BQ25FO0lBQ0Y7SUFFQSxJQUFJLENBQUMsY0FBYztNQUNqQixRQUFRLEdBQUcsQ0FBQyw4Q0FBOEM7TUFDMUQsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7UUFBRSxVQUFVO1FBQU0sU0FBUztNQUFvQixJQUFJO1FBQ3BGLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFDaEU7SUFDRjtJQUVBLE1BQU0sWUFBWSxhQUFhLE1BQU07SUFDckMsTUFBTSxVQUFVLFVBQVUsRUFBRTtJQUM1QixNQUFNLFNBQVMsVUFBVSxPQUFPO0lBQ2hDLE1BQU0sYUFBYSxVQUFVLEtBQUs7SUFFbEMsUUFBUSxHQUFHLENBQUMsQ0FBQyxZQUFZLEVBQUUsYUFBYSxFQUFFLENBQUMsV0FBVyxFQUFFLFFBQVEsQ0FBQztJQUVqRSxJQUFJLGlCQUFpQixjQUFjLGlCQUFpQixXQUFXO01BQzdELGdFQUFnRTtNQUNoRSxNQUFNLGdCQUFnQixhQUFhLE1BQU0sTUFBTSxDQUFDLEVBQUUsRUFBRSxhQUFhLE1BQU0sTUFBTSxDQUFDLEVBQUUsRUFBRTtNQUVsRixRQUFRLEdBQUcsQ0FBQyxDQUFDLDBCQUEwQixFQUFFLFFBQVEsT0FBTyxFQUFFLGNBQWMsQ0FBQztNQUV6RSxNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLFNBQ2xDLElBQUksQ0FBQyxnQkFDTCxNQUFNLENBQUM7UUFDTixRQUFRO1FBQ1IsWUFBWSxpQkFBaUIsS0FBSyxTQUFTLENBQUM7UUFDNUMsWUFBWSxJQUFJLE9BQU8sV0FBVztNQUNwQyxHQUNDLEVBQUUsQ0FBQyxNQUFNLGFBQWEsRUFBRTtNQUUzQixJQUFJLGFBQWE7UUFDZixRQUFRLEtBQUssQ0FBQyx5QkFBeUI7TUFDekM7TUFFQSwrQkFBK0I7TUFDL0IsTUFBTSxTQUFTLElBQUksQ0FBQyxpQkFBaUIsTUFBTSxDQUFDO1FBQzFDLFNBQVM7UUFDVCxNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxXQUFXLGlCQUFpQixDQUFDO1FBQzFELGFBQWE7UUFDYixXQUFXO01BQ2I7SUFFRixPQUFPLElBQUksaUJBQWlCLFlBQVksaUJBQWlCLFNBQVM7TUFDaEUsMEJBQTBCO01BQzFCLFFBQVEsS0FBSyxDQUFDLENBQUMsa0NBQWtDLEVBQUUsUUFBUSxFQUFFLEVBQUUsSUFBSSxDQUFDO01BRXBFLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztRQUNOLFFBQVE7UUFDUixZQUFZLEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTyxPQUFPO1FBQTBCO1FBQ3JFLFlBQVksSUFBSSxPQUFPLFdBQVc7TUFDcEMsR0FDQyxFQUFFLENBQUMsTUFBTSxhQUFhLEVBQUU7TUFFM0IsSUFBSSxhQUFhO1FBQ2YsUUFBUSxLQUFLLENBQUMseUJBQXlCO01BQ3pDO01BRUEsK0JBQStCO01BQy9CLE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztRQUMxQyxTQUFTO1FBQ1QsTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTLENBQUMsb0NBQW9DLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDN0QsYUFBYTtRQUNiLFdBQVc7TUFDYjtJQUNGO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxVQUFVO01BQU0sU0FBUztJQUFLLElBQy9DO01BQ0UsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUNoRTtFQUVKLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsOEJBQThCO0lBQzVDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsVUFBVTtNQUNWLE9BQU8saUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDbEQsSUFDQTtNQUNFLFFBQVE7TUFDUixTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQ2hFO0VBRUo7QUFDRiJ9
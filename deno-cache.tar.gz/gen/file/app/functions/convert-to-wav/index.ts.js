import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
  try {
    const authHeader = req.headers.get("Authorization");
    let userId = null;
    let isInternalCall = false;
    // Check if this is an internal call with service key
    if (authHeader === `Bearer ${supabaseServiceKey}`) {
      isInternalCall = true;
      console.log("Internal service call detected");
    } else if (authHeader?.startsWith("Bearer ")) {
      // User JWT - validate and get user
      const userClient = createClient(supabaseUrl, supabaseAnonKey, {
        global: {
          headers: {
            Authorization: authHeader
          }
        }
      });
      const token = authHeader.replace("Bearer ", "");
      const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
      if (claimsError || !claimsData?.claims) {
        return new Response(JSON.stringify({
          error: "Unauthorized"
        }), {
          status: 401,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      userId = claimsData.claims.sub;
      console.log(`User call from: ${userId}`);
    } else {
      return new Response(JSON.stringify({
        error: "Unauthorized - missing auth"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const body = await req.json();
    const { track_id, audio_id } = body;
    console.log("Convert to WAV request:", {
      track_id,
      audio_id,
      userId,
      isInternalCall
    });
    const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
    if (!SUNO_API_KEY) {
      throw new Error("SUNO_API_KEY not configured");
    }
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Get track info to get task_id from description
    const { data: track, error: trackError } = await supabase.from("tracks").select("id, user_id, suno_audio_id, title, description, audio_url, wav_url").eq("id", track_id).single();
    if (trackError || !track) {
      throw new Error("Track not found");
    }
    // If WAV already exists on track, return it
    if (track.wav_url) {
      console.log("WAV already exists on track:", track.wav_url);
      return new Response(JSON.stringify({
        success: true,
        wav_url: track.wav_url,
        message: "WAV already available"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // If user call, verify ownership
    if (!isInternalCall && track.user_id !== userId) {
      return new Response(JSON.stringify({
        error: "Access denied - not your track"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Extract task_id from track description
    let taskId = null;
    if (track.description) {
      const taskIdMatch = track.description.match(/\[task_id:\s*([^\]]+)\]/);
      if (taskIdMatch) {
        taskId = taskIdMatch[1].trim();
      }
    }
    // Use provided audio_id or get from track
    const audioId = audio_id || track.suno_audio_id;
    if (!taskId) {
      throw new Error("Track has no Suno task ID for WAV conversion");
    }
    // Get addon service
    const { data: addonService } = await supabase.from("addon_services").select("id, price_rub").eq("name", "convert_wav").single();
    if (!addonService) {
      throw new Error("WAV conversion service not found");
    }
    const callbackUrl = `${supabaseUrl}/functions/v1/wav-callback`;
    // Call Suno API to convert to WAV
    const response = await fetch("https://api.sunoapi.org/api/v1/wav/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify({
        taskId: taskId,
        audioId: audioId,
        callBackUrl: callbackUrl
      })
    });
    const result = await response.json();
    console.log("Suno WAV API response:", result);
    // Handle "already exists" case - try to get the WAV URL directly
    if (result.code === 409 && result.data?.taskId) {
      console.log("WAV already exists, fetching record-info...");
      // Get WAV record info from Suno API - correct endpoint is /wav/record-info
      const statusResponse = await fetch(`https://api.sunoapi.org/api/v1/wav/record-info?taskId=${result.data.taskId}`, {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${SUNO_API_KEY}`
        }
      });
      const statusResult = await statusResponse.json();
      console.log("WAV record-info response:", statusResult);
      // Check if WAV URL is available - the field is "audioWavUrl" in "response" object
      if (statusResult.code === 200 && statusResult.data?.response?.audioWavUrl) {
        const wavUrl = statusResult.data.response.audioWavUrl;
        console.log("Found WAV URL from record-info:", wavUrl);
        // Update track with WAV URL
        await supabase.from("tracks").update({
          wav_url: wavUrl,
          updated_at: new Date().toISOString()
        }).eq("id", track_id);
        // Update addon status
        await supabase.from("track_addons").upsert({
          track_id,
          addon_service_id: addonService.id,
          status: "completed",
          result_url: wavUrl,
          updated_at: new Date().toISOString()
        }, {
          onConflict: "track_id,addon_service_id"
        });
        // Send notification
        await supabase.from("notifications").insert({
          user_id: track.user_id,
          type: "addon_completed",
          title: "WAV готов к скачиванию",
          message: `Трек "${track.title}" доступен в WAV формате.`,
          target_type: "track",
          target_id: track_id,
          metadata: {
            wav_url: wavUrl
          }
        });
        return new Response(JSON.stringify({
          success: true,
          wav_url: wavUrl,
          message: "WAV ready"
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Status not ready yet, keep waiting
      await supabase.from("track_addons").upsert({
        track_id,
        addon_service_id: addonService.id,
        status: "processing",
        result_url: JSON.stringify({
          wav_task_id: result.data.taskId,
          suno_audio_id: audioId
        }),
        updated_at: new Date().toISOString()
      }, {
        onConflict: "track_id,addon_service_id"
      });
      return new Response(JSON.stringify({
        success: true,
        taskId: result.data.taskId,
        message: "WAV conversion in progress"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (result.code !== 200) {
      throw new Error(result.msg || "Failed to start WAV conversion");
    }
    // Create or update addon record
    await supabase.from("track_addons").upsert({
      track_id,
      addon_service_id: addonService.id,
      status: "processing",
      result_url: JSON.stringify({
        wav_task_id: result.data?.taskId,
        suno_audio_id: audioId
      }),
      updated_at: new Date().toISOString()
    }, {
      onConflict: "track_id,addon_service_id"
    });
    return new Response(JSON.stringify({
      success: true,
      taskId: result.data?.taskId
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in convert-to-wav:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9jb252ZXJ0LXRvLXdhdi9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgY29uc3Qgc3VwYWJhc2VBbm9uS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikhO1xuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgbGV0IHVzZXJJZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gICAgbGV0IGlzSW50ZXJuYWxDYWxsID0gZmFsc2U7XG5cbiAgICAvLyBDaGVjayBpZiB0aGlzIGlzIGFuIGludGVybmFsIGNhbGwgd2l0aCBzZXJ2aWNlIGtleVxuICAgIGlmIChhdXRoSGVhZGVyID09PSBgQmVhcmVyICR7c3VwYWJhc2VTZXJ2aWNlS2V5fWApIHtcbiAgICAgIGlzSW50ZXJuYWxDYWxsID0gdHJ1ZTtcbiAgICAgIGNvbnNvbGUubG9nKFwiSW50ZXJuYWwgc2VydmljZSBjYWxsIGRldGVjdGVkXCIpO1xuICAgIH0gZWxzZSBpZiAoYXV0aEhlYWRlcj8uc3RhcnRzV2l0aChcIkJlYXJlciBcIikpIHtcbiAgICAgIC8vIFVzZXIgSldUIC0gdmFsaWRhdGUgYW5kIGdldCB1c2VyXG4gICAgICBjb25zdCB1c2VyQ2xpZW50ID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZUFub25LZXksIHtcbiAgICAgICAgZ2xvYmFsOiB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYXV0aEhlYWRlciB9IH1cbiAgICAgIH0pO1xuICAgICAgXG4gICAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgICBjb25zdCB7IGRhdGE6IGNsYWltc0RhdGEsIGVycm9yOiBjbGFpbXNFcnJvciB9ID0gYXdhaXQgdXNlckNsaWVudC5hdXRoLmdldENsYWltcyh0b2tlbik7XG4gICAgICBcbiAgICAgIGlmIChjbGFpbXNFcnJvciB8fCAhY2xhaW1zRGF0YT8uY2xhaW1zKSB7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgdXNlcklkID0gY2xhaW1zRGF0YS5jbGFpbXMuc3ViIGFzIHN0cmluZztcbiAgICAgIGNvbnNvbGUubG9nKGBVc2VyIGNhbGwgZnJvbTogJHt1c2VySWR9YCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkIC0gbWlzc2luZyBhdXRoXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zdCB7IHRyYWNrX2lkLCBhdWRpb19pZCB9ID0gYm9keTtcbiAgICBcbiAgICBjb25zb2xlLmxvZyhcIkNvbnZlcnQgdG8gV0FWIHJlcXVlc3Q6XCIsIHsgdHJhY2tfaWQsIGF1ZGlvX2lkLCB1c2VySWQsIGlzSW50ZXJuYWxDYWxsIH0pO1xuXG4gICAgY29uc3QgU1VOT19BUElfS0VZID0gRGVuby5lbnYuZ2V0KFwiU1VOT19BUElfS0VZXCIpO1xuICAgIGlmICghU1VOT19BUElfS0VZKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJTVU5PX0FQSV9LRVkgbm90IGNvbmZpZ3VyZWRcIik7XG4gICAgfVxuXG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlU2VydmljZUtleSk7XG5cbiAgICAvLyBHZXQgdHJhY2sgaW5mbyB0byBnZXQgdGFza19pZCBmcm9tIGRlc2NyaXB0aW9uXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjaywgZXJyb3I6IHRyYWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLnNlbGVjdChcImlkLCB1c2VyX2lkLCBzdW5vX2F1ZGlvX2lkLCB0aXRsZSwgZGVzY3JpcHRpb24sIGF1ZGlvX3VybCwgd2F2X3VybFwiKVxuICAgICAgLmVxKFwiaWRcIiwgdHJhY2tfaWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAodHJhY2tFcnJvciB8fCAhdHJhY2spIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRyYWNrIG5vdCBmb3VuZFwiKTtcbiAgICB9XG5cbiAgICAvLyBJZiBXQVYgYWxyZWFkeSBleGlzdHMgb24gdHJhY2ssIHJldHVybiBpdFxuICAgIGlmICh0cmFjay53YXZfdXJsKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIldBViBhbHJlYWR5IGV4aXN0cyBvbiB0cmFjazpcIiwgdHJhY2sud2F2X3VybCk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IHRydWUsIHdhdl91cmw6IHRyYWNrLndhdl91cmwsIG1lc3NhZ2U6IFwiV0FWIGFscmVhZHkgYXZhaWxhYmxlXCIgfSksXG4gICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIElmIHVzZXIgY2FsbCwgdmVyaWZ5IG93bmVyc2hpcFxuICAgIGlmICghaXNJbnRlcm5hbENhbGwgJiYgdHJhY2sudXNlcl9pZCAhPT0gdXNlcklkKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkFjY2VzcyBkZW5pZWQgLSBub3QgeW91ciB0cmFja1wiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gRXh0cmFjdCB0YXNrX2lkIGZyb20gdHJhY2sgZGVzY3JpcHRpb25cbiAgICBsZXQgdGFza0lkOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgICBpZiAodHJhY2suZGVzY3JpcHRpb24pIHtcbiAgICAgIGNvbnN0IHRhc2tJZE1hdGNoID0gdHJhY2suZGVzY3JpcHRpb24ubWF0Y2goL1xcW3Rhc2tfaWQ6XFxzKihbXlxcXV0rKVxcXS8pO1xuICAgICAgaWYgKHRhc2tJZE1hdGNoKSB7XG4gICAgICAgIHRhc2tJZCA9IHRhc2tJZE1hdGNoWzFdLnRyaW0oKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBVc2UgcHJvdmlkZWQgYXVkaW9faWQgb3IgZ2V0IGZyb20gdHJhY2tcbiAgICBjb25zdCBhdWRpb0lkID0gYXVkaW9faWQgfHwgdHJhY2suc3Vub19hdWRpb19pZDtcblxuICAgIGlmICghdGFza0lkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUcmFjayBoYXMgbm8gU3VubyB0YXNrIElEIGZvciBXQVYgY29udmVyc2lvblwiKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgYWRkb24gc2VydmljZVxuICAgIGNvbnN0IHsgZGF0YTogYWRkb25TZXJ2aWNlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJhZGRvbl9zZXJ2aWNlc1wiKVxuICAgICAgLnNlbGVjdChcImlkLCBwcmljZV9ydWJcIilcbiAgICAgIC5lcShcIm5hbWVcIiwgXCJjb252ZXJ0X3dhdlwiKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKCFhZGRvblNlcnZpY2UpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIldBViBjb252ZXJzaW9uIHNlcnZpY2Ugbm90IGZvdW5kXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IGNhbGxiYWNrVXJsID0gYCR7c3VwYWJhc2VVcmx9L2Z1bmN0aW9ucy92MS93YXYtY2FsbGJhY2tgO1xuXG4gICAgLy8gQ2FsbCBTdW5vIEFQSSB0byBjb252ZXJ0IHRvIFdBVlxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXCJodHRwczovL2FwaS5zdW5vYXBpLm9yZy9hcGkvdjEvd2F2L2dlbmVyYXRlXCIsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NVTk9fQVBJX0tFWX1gLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGFza0lkOiB0YXNrSWQsXG4gICAgICAgIGF1ZGlvSWQ6IGF1ZGlvSWQsXG4gICAgICAgIGNhbGxCYWNrVXJsOiBjYWxsYmFja1VybCxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKFwiU3VubyBXQVYgQVBJIHJlc3BvbnNlOlwiLCByZXN1bHQpO1xuXG4gICAgLy8gSGFuZGxlIFwiYWxyZWFkeSBleGlzdHNcIiBjYXNlIC0gdHJ5IHRvIGdldCB0aGUgV0FWIFVSTCBkaXJlY3RseVxuICAgIGlmIChyZXN1bHQuY29kZSA9PT0gNDA5ICYmIHJlc3VsdC5kYXRhPy50YXNrSWQpIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiV0FWIGFscmVhZHkgZXhpc3RzLCBmZXRjaGluZyByZWNvcmQtaW5mby4uLlwiKTtcbiAgICAgIFxuICAgICAgLy8gR2V0IFdBViByZWNvcmQgaW5mbyBmcm9tIFN1bm8gQVBJIC0gY29ycmVjdCBlbmRwb2ludCBpcyAvd2F2L3JlY29yZC1pbmZvXG4gICAgICBjb25zdCBzdGF0dXNSZXNwb25zZSA9IGF3YWl0IGZldGNoKGBodHRwczovL2FwaS5zdW5vYXBpLm9yZy9hcGkvdjEvd2F2L3JlY29yZC1pbmZvP3Rhc2tJZD0ke3Jlc3VsdC5kYXRhLnRhc2tJZH1gLCB7XG4gICAgICAgIG1ldGhvZDogXCJHRVRcIixcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICAgIFxuICAgICAgY29uc3Qgc3RhdHVzUmVzdWx0ID0gYXdhaXQgc3RhdHVzUmVzcG9uc2UuanNvbigpO1xuICAgICAgY29uc29sZS5sb2coXCJXQVYgcmVjb3JkLWluZm8gcmVzcG9uc2U6XCIsIHN0YXR1c1Jlc3VsdCk7XG4gICAgICBcbiAgICAgIC8vIENoZWNrIGlmIFdBViBVUkwgaXMgYXZhaWxhYmxlIC0gdGhlIGZpZWxkIGlzIFwiYXVkaW9XYXZVcmxcIiBpbiBcInJlc3BvbnNlXCIgb2JqZWN0XG4gICAgICBpZiAoc3RhdHVzUmVzdWx0LmNvZGUgPT09IDIwMCAmJiBzdGF0dXNSZXN1bHQuZGF0YT8ucmVzcG9uc2U/LmF1ZGlvV2F2VXJsKSB7XG4gICAgICAgIGNvbnN0IHdhdlVybCA9IHN0YXR1c1Jlc3VsdC5kYXRhLnJlc3BvbnNlLmF1ZGlvV2F2VXJsO1xuICAgICAgICBjb25zb2xlLmxvZyhcIkZvdW5kIFdBViBVUkwgZnJvbSByZWNvcmQtaW5mbzpcIiwgd2F2VXJsKTtcbiAgICAgICAgXG4gICAgICAgIC8vIFVwZGF0ZSB0cmFjayB3aXRoIFdBViBVUkxcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBcbiAgICAgICAgICAgIHdhdl91cmw6IHdhdlVybCxcbiAgICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5lcShcImlkXCIsIHRyYWNrX2lkKTtcbiAgICAgICAgXG4gICAgICAgIC8vIFVwZGF0ZSBhZGRvbiBzdGF0dXNcbiAgICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcInRyYWNrX2FkZG9uc1wiKS51cHNlcnQoe1xuICAgICAgICAgIHRyYWNrX2lkLFxuICAgICAgICAgIGFkZG9uX3NlcnZpY2VfaWQ6IGFkZG9uU2VydmljZS5pZCxcbiAgICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgcmVzdWx0X3VybDogd2F2VXJsLFxuICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgfSwge1xuICAgICAgICAgIG9uQ29uZmxpY3Q6IFwidHJhY2tfaWQsYWRkb25fc2VydmljZV9pZFwiLFxuICAgICAgICB9KTtcbiAgICAgICAgXG4gICAgICAgIC8vIFNlbmQgbm90aWZpY2F0aW9uXG4gICAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oXCJub3RpZmljYXRpb25zXCIpLmluc2VydCh7XG4gICAgICAgICAgdXNlcl9pZDogdHJhY2sudXNlcl9pZCxcbiAgICAgICAgICB0eXBlOiBcImFkZG9uX2NvbXBsZXRlZFwiLFxuICAgICAgICAgIHRpdGxlOiBcIldBViDQs9C+0YLQvtCyINC6INGB0LrQsNGH0LjQstCw0L3QuNGOXCIsXG4gICAgICAgICAgbWVzc2FnZTogYNCi0YDQtdC6IFwiJHt0cmFjay50aXRsZX1cIiDQtNC+0YHRgtGD0L/QtdC9INCyIFdBViDRhNC+0YDQvNCw0YLQtS5gLFxuICAgICAgICAgIHRhcmdldF90eXBlOiBcInRyYWNrXCIsXG4gICAgICAgICAgdGFyZ2V0X2lkOiB0cmFja19pZCxcbiAgICAgICAgICBtZXRhZGF0YTogeyB3YXZfdXJsOiB3YXZVcmwgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIFxuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSwgd2F2X3VybDogd2F2VXJsLCBtZXNzYWdlOiBcIldBViByZWFkeVwiIH0pLFxuICAgICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIFN0YXR1cyBub3QgcmVhZHkgeWV0LCBrZWVwIHdhaXRpbmdcbiAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oXCJ0cmFja19hZGRvbnNcIikudXBzZXJ0KHtcbiAgICAgICAgdHJhY2tfaWQsXG4gICAgICAgIGFkZG9uX3NlcnZpY2VfaWQ6IGFkZG9uU2VydmljZS5pZCxcbiAgICAgICAgc3RhdHVzOiBcInByb2Nlc3NpbmdcIixcbiAgICAgICAgcmVzdWx0X3VybDogSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICB3YXZfdGFza19pZDogcmVzdWx0LmRhdGEudGFza0lkLFxuICAgICAgICAgIHN1bm9fYXVkaW9faWQ6IGF1ZGlvSWQsXG4gICAgICAgIH0pLFxuICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9LCB7XG4gICAgICAgIG9uQ29uZmxpY3Q6IFwidHJhY2tfaWQsYWRkb25fc2VydmljZV9pZFwiLFxuICAgICAgfSk7XG5cbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSwgdGFza0lkOiByZXN1bHQuZGF0YS50YXNrSWQsIG1lc3NhZ2U6IFwiV0FWIGNvbnZlcnNpb24gaW4gcHJvZ3Jlc3NcIiB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKHJlc3VsdC5jb2RlICE9PSAyMDApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihyZXN1bHQubXNnIHx8IFwiRmFpbGVkIHRvIHN0YXJ0IFdBViBjb252ZXJzaW9uXCIpO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZSBvciB1cGRhdGUgYWRkb24gcmVjb3JkXG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcInRyYWNrX2FkZG9uc1wiKS51cHNlcnQoe1xuICAgICAgdHJhY2tfaWQsXG4gICAgICBhZGRvbl9zZXJ2aWNlX2lkOiBhZGRvblNlcnZpY2UuaWQsXG4gICAgICBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiLFxuICAgICAgcmVzdWx0X3VybDogSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgd2F2X3Rhc2tfaWQ6IHJlc3VsdC5kYXRhPy50YXNrSWQsXG4gICAgICAgIHN1bm9fYXVkaW9faWQ6IGF1ZGlvSWQsXG4gICAgICB9KSxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9LCB7XG4gICAgICBvbkNvbmZsaWN0OiBcInRyYWNrX2lkLGFkZG9uX3NlcnZpY2VfaWRcIixcbiAgICB9KTtcblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IHRydWUsIHRhc2tJZDogcmVzdWx0LmRhdGE/LnRhc2tJZCB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gY29udmVydC10by13YXY6XCIsIGVycm9yKTtcbiAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFDakMsTUFBTSxxQkFBcUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0VBQ3hDLE1BQU0sa0JBQWtCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUVyQyxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLFNBQXdCO0lBQzVCLElBQUksaUJBQWlCO0lBRXJCLHFEQUFxRDtJQUNyRCxJQUFJLGVBQWUsQ0FBQyxPQUFPLEVBQUUsbUJBQW1CLENBQUMsRUFBRTtNQUNqRCxpQkFBaUI7TUFDakIsUUFBUSxHQUFHLENBQUM7SUFDZCxPQUFPLElBQUksWUFBWSxXQUFXLFlBQVk7TUFDNUMsbUNBQW1DO01BQ25DLE1BQU0sYUFBYSxhQUFhLGFBQWEsaUJBQWlCO1FBQzVELFFBQVE7VUFBRSxTQUFTO1lBQUUsZUFBZTtVQUFXO1FBQUU7TUFDbkQ7TUFFQSxNQUFNLFFBQVEsV0FBVyxPQUFPLENBQUMsV0FBVztNQUM1QyxNQUFNLEVBQUUsTUFBTSxVQUFVLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLFdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQztNQUVqRixJQUFJLGVBQWUsQ0FBQyxZQUFZLFFBQVE7UUFDdEMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQWUsSUFDdkM7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BRUEsU0FBUyxXQUFXLE1BQU0sQ0FBQyxHQUFHO01BQzlCLFFBQVEsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDO0lBQ3pDLE9BQU87TUFDTCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBOEIsSUFDdEQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxPQUFPLE1BQU0sSUFBSSxJQUFJO0lBQzNCLE1BQU0sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEdBQUc7SUFFL0IsUUFBUSxHQUFHLENBQUMsMkJBQTJCO01BQUU7TUFBVTtNQUFVO01BQVE7SUFBZTtJQUVwRixNQUFNLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2xDLElBQUksQ0FBQyxjQUFjO01BQ2pCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxXQUFXLGFBQWEsYUFBYTtJQUUzQyxpREFBaUQ7SUFDakQsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxTQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsc0VBQ1AsRUFBRSxDQUFDLE1BQU0sVUFDVCxNQUFNO0lBRVQsSUFBSSxjQUFjLENBQUMsT0FBTztNQUN4QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLDRDQUE0QztJQUM1QyxJQUFJLE1BQU0sT0FBTyxFQUFFO01BQ2pCLFFBQVEsR0FBRyxDQUFDLGdDQUFnQyxNQUFNLE9BQU87TUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxTQUFTO1FBQU0sU0FBUyxNQUFNLE9BQU87UUFBRSxTQUFTO01BQXdCLElBQ3pGO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsaUNBQWlDO0lBQ2pDLElBQUksQ0FBQyxrQkFBa0IsTUFBTSxPQUFPLEtBQUssUUFBUTtNQUMvQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBaUMsSUFDekQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEseUNBQXlDO0lBQ3pDLElBQUksU0FBd0I7SUFDNUIsSUFBSSxNQUFNLFdBQVcsRUFBRTtNQUNyQixNQUFNLGNBQWMsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDO01BQzVDLElBQUksYUFBYTtRQUNmLFNBQVMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxJQUFJO01BQzlCO0lBQ0Y7SUFFQSwwQ0FBMEM7SUFDMUMsTUFBTSxVQUFVLFlBQVksTUFBTSxhQUFhO0lBRS9DLElBQUksQ0FBQyxRQUFRO01BQ1gsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxvQkFBb0I7SUFDcEIsTUFBTSxFQUFFLE1BQU0sWUFBWSxFQUFFLEdBQUcsTUFBTSxTQUNsQyxJQUFJLENBQUMsa0JBQ0wsTUFBTSxDQUFDLGlCQUNQLEVBQUUsQ0FBQyxRQUFRLGVBQ1gsTUFBTTtJQUVULElBQUksQ0FBQyxjQUFjO01BQ2pCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxjQUFjLENBQUMsRUFBRSxZQUFZLDBCQUEwQixDQUFDO0lBRTlELGtDQUFrQztJQUNsQyxNQUFNLFdBQVcsTUFBTSxNQUFNLCtDQUErQztNQUMxRSxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDO01BQzNDO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztRQUNuQixRQUFRO1FBQ1IsU0FBUztRQUNULGFBQWE7TUFDZjtJQUNGO0lBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0lBQ2xDLFFBQVEsR0FBRyxDQUFDLDBCQUEwQjtJQUV0QyxpRUFBaUU7SUFDakUsSUFBSSxPQUFPLElBQUksS0FBSyxPQUFPLE9BQU8sSUFBSSxFQUFFLFFBQVE7TUFDOUMsUUFBUSxHQUFHLENBQUM7TUFFWiwyRUFBMkU7TUFDM0UsTUFBTSxpQkFBaUIsTUFBTSxNQUFNLENBQUMsc0RBQXNELEVBQUUsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRTtRQUNoSCxRQUFRO1FBQ1IsU0FBUztVQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7UUFDM0M7TUFDRjtNQUVBLE1BQU0sZUFBZSxNQUFNLGVBQWUsSUFBSTtNQUM5QyxRQUFRLEdBQUcsQ0FBQyw2QkFBNkI7TUFFekMsa0ZBQWtGO01BQ2xGLElBQUksYUFBYSxJQUFJLEtBQUssT0FBTyxhQUFhLElBQUksRUFBRSxVQUFVLGFBQWE7UUFDekUsTUFBTSxTQUFTLGFBQWEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXO1FBQ3JELFFBQVEsR0FBRyxDQUFDLG1DQUFtQztRQUUvQyw0QkFBNEI7UUFDNUIsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztVQUNOLFNBQVM7VUFDVCxZQUFZLElBQUksT0FBTyxXQUFXO1FBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU07UUFFWixzQkFBc0I7UUFDdEIsTUFBTSxTQUFTLElBQUksQ0FBQyxnQkFBZ0IsTUFBTSxDQUFDO1VBQ3pDO1VBQ0Esa0JBQWtCLGFBQWEsRUFBRTtVQUNqQyxRQUFRO1VBQ1IsWUFBWTtVQUNaLFlBQVksSUFBSSxPQUFPLFdBQVc7UUFDcEMsR0FBRztVQUNELFlBQVk7UUFDZDtRQUVBLG9CQUFvQjtRQUNwQixNQUFNLFNBQVMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7VUFDMUMsU0FBUyxNQUFNLE9BQU87VUFDdEIsTUFBTTtVQUNOLE9BQU87VUFDUCxTQUFTLENBQUMsTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDLHlCQUF5QixDQUFDO1VBQ3hELGFBQWE7VUFDYixXQUFXO1VBQ1gsVUFBVTtZQUFFLFNBQVM7VUFBTztRQUM5QjtRQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsU0FBUztVQUFNLFNBQVM7VUFBUSxTQUFTO1FBQVksSUFDdEU7VUFBRSxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFdEU7TUFFQSxxQ0FBcUM7TUFDckMsTUFBTSxTQUFTLElBQUksQ0FBQyxnQkFBZ0IsTUFBTSxDQUFDO1FBQ3pDO1FBQ0Esa0JBQWtCLGFBQWEsRUFBRTtRQUNqQyxRQUFRO1FBQ1IsWUFBWSxLQUFLLFNBQVMsQ0FBQztVQUN6QixhQUFhLE9BQU8sSUFBSSxDQUFDLE1BQU07VUFDL0IsZUFBZTtRQUNqQjtRQUNBLFlBQVksSUFBSSxPQUFPLFdBQVc7TUFDcEMsR0FBRztRQUNELFlBQVk7TUFDZDtNQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsU0FBUztRQUFNLFFBQVEsT0FBTyxJQUFJLENBQUMsTUFBTTtRQUFFLFNBQVM7TUFBNkIsSUFDbEc7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxJQUFJLE9BQU8sSUFBSSxLQUFLLEtBQUs7TUFDdkIsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHLElBQUk7SUFDaEM7SUFFQSxnQ0FBZ0M7SUFDaEMsTUFBTSxTQUFTLElBQUksQ0FBQyxnQkFBZ0IsTUFBTSxDQUFDO01BQ3pDO01BQ0Esa0JBQWtCLGFBQWEsRUFBRTtNQUNqQyxRQUFRO01BQ1IsWUFBWSxLQUFLLFNBQVMsQ0FBQztRQUN6QixhQUFhLE9BQU8sSUFBSSxFQUFFO1FBQzFCLGVBQWU7TUFDakI7TUFDQSxZQUFZLElBQUksT0FBTyxXQUFXO0lBQ3BDLEdBQUc7TUFDRCxZQUFZO0lBQ2Q7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLFNBQVM7TUFBTSxRQUFRLE9BQU8sSUFBSSxFQUFFO0lBQU8sSUFDNUQ7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEUsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDRCQUE0QjtJQUMxQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
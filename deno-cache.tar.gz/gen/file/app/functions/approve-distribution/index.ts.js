import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '');
    // Get user from auth header using getClaims (more reliable)
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }
    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      throw new Error('Unauthorized');
    }
    const userId = claimsData.claims.sub;
    // Check if user is admin/moderator
    const { data: role } = await supabase.from('user_roles').select('role').eq('user_id', userId).in('role', [
      'admin',
      'super_admin',
      'moderator'
    ]).single();
    if (!role) {
      throw new Error('Not authorized to approve distributions');
    }
    const { trackId, notes } = await req.json();
    console.log(`[approve-distribution] Admin ${userId} approving track: ${trackId}`);
    if (!trackId) {
      throw new Error('trackId is required');
    }
    // Get track
    const { data: track, error: trackError } = await supabase.from('tracks').select('*').eq('id', trackId).single();
    if (trackError || !track) {
      throw new Error('Track not found');
    }
    if (track.distribution_status !== 'pending_moderation') {
      throw new Error(`Invalid distribution status: ${track.distribution_status}`);
    }
    // Update track - approve for distribution, waiting for master upload
    const { error: updateError } = await supabase.from('tracks').update({
      distribution_status: 'pending_master',
      distribution_approved_at: new Date().toISOString(),
      distribution_approved_by: userId,
      moderation_status: 'approved',
      moderation_reviewed_at: new Date().toISOString(),
      moderation_reviewed_by: userId,
      moderation_notes: notes || null
    }).eq('id', trackId);
    if (updateError) {
      throw updateError;
    }
    // Log the approval
    await supabase.from('distribution_logs').insert({
      track_id: trackId,
      user_id: userId,
      action: 'distribution_approved',
      stage: 'level_user',
      details: {
        notes,
        approved_by: userId
      }
    });
    // Notify track owner
    await supabase.from('notifications').insert({
      user_id: track.user_id,
      type: 'system',
      title: '✅ Трек одобрен для дистрибуции!',
      message: `Поздравляем! Трек "${track.title}" прошёл модерацию. Загрузите Master-копию в формате WAV 24-bit для перехода на Level Pro.`,
      actor_id: userId,
      target_type: 'track',
      target_id: trackId
    });
    return new Response(JSON.stringify({
      success: true,
      message: 'Distribution approved, awaiting master upload',
      status: 'pending_master'
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('[approve-distribution] Error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({
      success: false,
      error: message
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9hcHByb3ZlLWRpc3RyaWJ1dGlvbi9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6ICdhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZScsXG59O1xuXG5pbnRlcmZhY2UgQXBwcm92ZURpc3RyaWJ1dGlvbklucHV0IHtcbiAgdHJhY2tJZDogc3RyaW5nO1xuICBub3Rlcz86IHN0cmluZztcbn1cblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gJ09QVElPTlMnKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZSgnb2snLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldCgnU1VQQUJBU0VfVVJMJykgPz8gJycsXG4gICAgICBEZW5vLmVudi5nZXQoJ1NVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVknKSA/PyAnJ1xuICAgICk7XG5cbiAgICAvLyBHZXQgdXNlciBmcm9tIGF1dGggaGVhZGVyIHVzaW5nIGdldENsYWltcyAobW9yZSByZWxpYWJsZSlcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KCdBdXRob3JpemF0aW9uJyk7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIGF1dGhvcml6YXRpb24gaGVhZGVyJyk7XG4gICAgfVxuXG4gICAgY29uc3QgdG9rZW4gPSBhdXRoSGVhZGVyLnJlcGxhY2UoJ0JlYXJlciAnLCAnJyk7XG4gICAgY29uc3QgeyBkYXRhOiBjbGFpbXNEYXRhLCBlcnJvcjogY2xhaW1zRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0Q2xhaW1zKHRva2VuKTtcbiAgICBcbiAgICBpZiAoY2xhaW1zRXJyb3IgfHwgIWNsYWltc0RhdGE/LmNsYWltcz8uc3ViKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xuICAgIH1cbiAgICBcbiAgICBjb25zdCB1c2VySWQgPSBjbGFpbXNEYXRhLmNsYWltcy5zdWIgYXMgc3RyaW5nO1xuXG4gICAgLy8gQ2hlY2sgaWYgdXNlciBpcyBhZG1pbi9tb2RlcmF0b3JcbiAgICBjb25zdCB7IGRhdGE6IHJvbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgndXNlcl9yb2xlcycpXG4gICAgICAuc2VsZWN0KCdyb2xlJylcbiAgICAgIC5lcSgndXNlcl9pZCcsIHVzZXJJZClcbiAgICAgIC5pbigncm9sZScsIFsnYWRtaW4nLCAnc3VwZXJfYWRtaW4nLCAnbW9kZXJhdG9yJ10pXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoIXJvbGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm90IGF1dGhvcml6ZWQgdG8gYXBwcm92ZSBkaXN0cmlidXRpb25zJyk7XG4gICAgfVxuXG4gICAgY29uc3QgeyB0cmFja0lkLCBub3RlcyB9OiBBcHByb3ZlRGlzdHJpYnV0aW9uSW5wdXQgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKGBbYXBwcm92ZS1kaXN0cmlidXRpb25dIEFkbWluICR7dXNlcklkfSBhcHByb3ZpbmcgdHJhY2s6ICR7dHJhY2tJZH1gKTtcblxuICAgIGlmICghdHJhY2tJZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCd0cmFja0lkIGlzIHJlcXVpcmVkJyk7XG4gICAgfVxuXG4gICAgLy8gR2V0IHRyYWNrXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjaywgZXJyb3I6IHRyYWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgndHJhY2tzJylcbiAgICAgIC5zZWxlY3QoJyonKVxuICAgICAgLmVxKCdpZCcsIHRyYWNrSWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAodHJhY2tFcnJvciB8fCAhdHJhY2spIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignVHJhY2sgbm90IGZvdW5kJyk7XG4gICAgfVxuXG4gICAgaWYgKHRyYWNrLmRpc3RyaWJ1dGlvbl9zdGF0dXMgIT09ICdwZW5kaW5nX21vZGVyYXRpb24nKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEludmFsaWQgZGlzdHJpYnV0aW9uIHN0YXR1czogJHt0cmFjay5kaXN0cmlidXRpb25fc3RhdHVzfWApO1xuICAgIH1cblxuICAgIC8vIFVwZGF0ZSB0cmFjayAtIGFwcHJvdmUgZm9yIGRpc3RyaWJ1dGlvbiwgd2FpdGluZyBmb3IgbWFzdGVyIHVwbG9hZFxuICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oJ3RyYWNrcycpXG4gICAgICAudXBkYXRlKHtcbiAgICAgICAgZGlzdHJpYnV0aW9uX3N0YXR1czogJ3BlbmRpbmdfbWFzdGVyJyxcbiAgICAgICAgZGlzdHJpYnV0aW9uX2FwcHJvdmVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGRpc3RyaWJ1dGlvbl9hcHByb3ZlZF9ieTogdXNlcklkLFxuICAgICAgICBtb2RlcmF0aW9uX3N0YXR1czogJ2FwcHJvdmVkJyxcbiAgICAgICAgbW9kZXJhdGlvbl9yZXZpZXdlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBtb2RlcmF0aW9uX3Jldmlld2VkX2J5OiB1c2VySWQsXG4gICAgICAgIG1vZGVyYXRpb25fbm90ZXM6IG5vdGVzIHx8IG51bGxcbiAgICAgIH0pXG4gICAgICAuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgIHRocm93IHVwZGF0ZUVycm9yO1xuICAgIH1cblxuICAgIC8vIExvZyB0aGUgYXBwcm92YWxcbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdkaXN0cmlidXRpb25fbG9ncycpLmluc2VydCh7XG4gICAgICB0cmFja19pZDogdHJhY2tJZCxcbiAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcbiAgICAgIGFjdGlvbjogJ2Rpc3RyaWJ1dGlvbl9hcHByb3ZlZCcsXG4gICAgICBzdGFnZTogJ2xldmVsX3VzZXInLFxuICAgICAgZGV0YWlsczogeyBcbiAgICAgICAgbm90ZXMsXG4gICAgICAgIGFwcHJvdmVkX2J5OiB1c2VySWRcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIE5vdGlmeSB0cmFjayBvd25lclxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ25vdGlmaWNhdGlvbnMnKS5pbnNlcnQoe1xuICAgICAgdXNlcl9pZDogdHJhY2sudXNlcl9pZCxcbiAgICAgIHR5cGU6ICdzeXN0ZW0nLFxuICAgICAgdGl0bGU6ICfinIUg0KLRgNC10Log0L7QtNC+0LHRgNC10L0g0LTQu9GPINC00LjRgdGC0YDQuNCx0YPRhtC40LghJyxcbiAgICAgIG1lc3NhZ2U6IGDQn9C+0LfQtNGA0LDQstC70Y/QtdC8ISDQotGA0LXQuiBcIiR7dHJhY2sudGl0bGV9XCIg0L/RgNC+0YjRkdC7INC80L7QtNC10YDQsNGG0LjRji4g0JfQsNCz0YDRg9C30LjRgtC1IE1hc3Rlci3QutC+0L/QuNGOINCyINGE0L7RgNC80LDRgtC1IFdBViAyNC1iaXQg0LTQu9GPINC/0LXRgNC10YXQvtC00LAg0L3QsCBMZXZlbCBQcm8uYCxcbiAgICAgIGFjdG9yX2lkOiB1c2VySWQsXG4gICAgICB0YXJnZXRfdHlwZTogJ3RyYWNrJyxcbiAgICAgIHRhcmdldF9pZDogdHJhY2tJZFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICBtZXNzYWdlOiAnRGlzdHJpYnV0aW9uIGFwcHJvdmVkLCBhd2FpdGluZyBtYXN0ZXIgdXBsb2FkJyxcbiAgICAgICAgc3RhdHVzOiAncGVuZGluZ19tYXN0ZXInXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignW2FwcHJvdmUtZGlzdHJpYnV0aW9uXSBFcnJvcjonLCBlcnJvcik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxLQUFLLFFBQVEsK0NBQStDO0FBQ3JFLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQU9BLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sV0FBVyxhQUNmLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFDaEMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdDQUFnQztJQUcvQyw0REFBNEQ7SUFDNUQsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUFTLElBQUksQ0FBQyxTQUFTLENBQUM7SUFFL0UsSUFBSSxlQUFlLENBQUMsWUFBWSxRQUFRLEtBQUs7TUFDM0MsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLFNBQVMsV0FBVyxNQUFNLENBQUMsR0FBRztJQUVwQyxtQ0FBbUM7SUFDbkMsTUFBTSxFQUFFLE1BQU0sSUFBSSxFQUFFLEdBQUcsTUFBTSxTQUMxQixJQUFJLENBQUMsY0FDTCxNQUFNLENBQUMsUUFDUCxFQUFFLENBQUMsV0FBVyxRQUNkLEVBQUUsQ0FBQyxRQUFRO01BQUM7TUFBUztNQUFlO0tBQVksRUFDaEQsTUFBTTtJQUVULElBQUksQ0FBQyxNQUFNO01BQ1QsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxHQUE2QixNQUFNLElBQUksSUFBSTtJQUNuRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDZCQUE2QixFQUFFLE9BQU8sa0JBQWtCLEVBQUUsUUFBUSxDQUFDO0lBRWhGLElBQUksQ0FBQyxTQUFTO01BQ1osTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxZQUFZO0lBQ1osTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxTQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsS0FDUCxFQUFFLENBQUMsTUFBTSxTQUNULE1BQU07SUFFVCxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsSUFBSSxNQUFNLG1CQUFtQixLQUFLLHNCQUFzQjtNQUN0RCxNQUFNLElBQUksTUFBTSxDQUFDLDZCQUE2QixFQUFFLE1BQU0sbUJBQW1CLENBQUMsQ0FBQztJQUM3RTtJQUVBLHFFQUFxRTtJQUNyRSxNQUFNLEVBQUUsT0FBTyxXQUFXLEVBQUUsR0FBRyxNQUFNLFNBQ2xDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztNQUNOLHFCQUFxQjtNQUNyQiwwQkFBMEIsSUFBSSxPQUFPLFdBQVc7TUFDaEQsMEJBQTBCO01BQzFCLG1CQUFtQjtNQUNuQix3QkFBd0IsSUFBSSxPQUFPLFdBQVc7TUFDOUMsd0JBQXdCO01BQ3hCLGtCQUFrQixTQUFTO0lBQzdCLEdBQ0MsRUFBRSxDQUFDLE1BQU07SUFFWixJQUFJLGFBQWE7TUFDZixNQUFNO0lBQ1I7SUFFQSxtQkFBbUI7SUFDbkIsTUFBTSxTQUFTLElBQUksQ0FBQyxxQkFBcUIsTUFBTSxDQUFDO01BQzlDLFVBQVU7TUFDVixTQUFTO01BQ1QsUUFBUTtNQUNSLE9BQU87TUFDUCxTQUFTO1FBQ1A7UUFDQSxhQUFhO01BQ2Y7SUFDRjtJQUVBLHFCQUFxQjtJQUNyQixNQUFNLFNBQVMsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7TUFDMUMsU0FBUyxNQUFNLE9BQU87TUFDdEIsTUFBTTtNQUNOLE9BQU87TUFDUCxTQUFTLENBQUMsbUJBQW1CLEVBQUUsTUFBTSxLQUFLLENBQUMsMEZBQTBGLENBQUM7TUFDdEksVUFBVTtNQUNWLGFBQWE7TUFDYixXQUFXO0lBQ2I7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxTQUFTO01BQ1QsUUFBUTtJQUNWLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyxpQ0FBaUM7SUFDL0MsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztNQUFPLE9BQU87SUFBUSxJQUNoRDtNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRiJ9
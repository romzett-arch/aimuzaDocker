import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_UPLOAD_BASE = "https://sunoapiorg.redpandaai.co";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
    const supabaseAuth = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await supabaseAuth.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const contentType = req.headers.get("content-type") || "";
    // Handle multipart form data (file upload)
    if (contentType.includes("multipart/form-data")) {
      const formData = await req.formData();
      const file = formData.get("file");
      if (!file) {
        return new Response(JSON.stringify({
          error: "No file provided"
        }), {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Check file size (max 25MB for full tracks)
      const maxSize = 25 * 1024 * 1024;
      if (file.size > maxSize) {
        return new Response(JSON.stringify({
          error: "Файл слишком большой. Максимум 25MB"
        }), {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Check file type
      const allowedTypes = [
        "audio/mpeg",
        "audio/mp3",
        "audio/wav",
        "audio/wave",
        "audio/x-wav"
      ];
      if (!allowedTypes.includes(file.type)) {
        return new Response(JSON.stringify({
          error: "Неподдерживаемый формат. Используйте MP3 или WAV"
        }), {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      console.log(`Uploading audio file: ${file.name}, size: ${file.size}, type: ${file.type}`);
      // First upload file to Supabase Storage to get a public URL
      const fileExt = file.name.split('.').pop() || 'mp3';
      const fileName = `${user.id}/${Date.now()}_${crypto.randomUUID()}.${fileExt}`;
      const arrayBuffer = await file.arrayBuffer();
      const { error: uploadError } = await supabaseClient.storage.from("audio-references").upload(fileName, arrayBuffer, {
        contentType: file.type,
        upsert: false
      });
      if (uploadError) {
        console.error("Storage upload error:", uploadError);
        return new Response(JSON.stringify({
          error: "Ошибка сохранения файла"
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Get public URL
      const { data: urlData } = supabaseClient.storage.from("audio-references").getPublicUrl(fileName);
      const publicUrl = urlData?.publicUrl;
      if (!publicUrl) {
        return new Response(JSON.stringify({
          error: "Не удалось получить URL файла"
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      console.log(`File saved to storage: ${publicUrl}`);
      // Now upload to Suno using URL endpoint (much more memory efficient)
      const uploadResponse = await fetch(`${SUNO_UPLOAD_BASE}/api/file-url-upload`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${SUNO_API_KEY}`
        },
        body: JSON.stringify({
          url: publicUrl
        })
      });
      const uploadData = await uploadResponse.json();
      console.log("Suno upload response:", JSON.stringify(uploadData));
      if (!uploadResponse.ok || uploadData.code !== 200) {
        console.error("Suno upload failed:", uploadData);
        return new Response(JSON.stringify({
          error: uploadData.msg || "Ошибка загрузки файла в Suno"
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      const uploadUrl = uploadData.data?.url || uploadData.data;
      if (!uploadUrl) {
        console.error("No upload URL in response:", uploadData);
        return new Response(JSON.stringify({
          error: "Не удалось получить URL от Suno"
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      console.log(`File uploaded to Suno successfully: ${uploadUrl}`);
      return new Response(JSON.stringify({
        success: true,
        uploadUrl,
        fileName: file.name,
        message: "Аудио загружено"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Handle JSON body (URL upload)
    const { audioUrl } = await req.json();
    if (!audioUrl) {
      return new Response(JSON.stringify({
        error: "No audio URL provided"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Uploading audio from URL: ${audioUrl}`);
    // Upload to Suno using URL endpoint
    const uploadResponse = await fetch(`${SUNO_UPLOAD_BASE}/api/file-url-upload`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify({
        url: audioUrl
      })
    });
    const uploadData = await uploadResponse.json();
    console.log("Suno URL upload response:", JSON.stringify(uploadData));
    if (!uploadResponse.ok || uploadData.code !== 200) {
      console.error("Suno URL upload failed:", uploadData);
      return new Response(JSON.stringify({
        error: uploadData.msg || "Ошибка загрузки по URL"
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const uploadUrl = uploadData.data?.url || uploadData.data;
    return new Response(JSON.stringify({
      success: true,
      uploadUrl,
      message: "Аудио загружено"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in upload-audio-reference:", error);
    return new Response(JSON.stringify({
      error: "Произошла ошибка при загрузке"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy91cGxvYWQtYXVkaW8tcmVmZXJlbmNlL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE2OC4wL2h0dHAvc2VydmVyLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuY29uc3QgU1VOT19BUElfS0VZID0gRGVuby5lbnYuZ2V0KFwiU1VOT19BUElfS0VZXCIpO1xuY29uc3QgU1VOT19VUExPQURfQkFTRSA9IFwiaHR0cHM6Ly9zdW5vYXBpb3JnLnJlZHBhbmRhYWkuY29cIjtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJObyBhdXRob3JpemF0aW9uIGhlYWRlclwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgc3VwYWJhc2VDbGllbnQgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgPz8gXCJcIixcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikgPz8gXCJcIixcbiAgICApO1xuXG4gICAgY29uc3Qgc3VwYWJhc2VBdXRoID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpID8/IFwiXCIsXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSA/PyBcIlwiLFxuICAgICAgeyBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfSB9XG4gICAgKTtcblxuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0sIGVycm9yOiB1c2VyRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQXV0aC5hdXRoLmdldFVzZXIoKTtcbiAgICBpZiAodXNlckVycm9yIHx8ICF1c2VyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgY29udGVudFR5cGUgPSByZXEuaGVhZGVycy5nZXQoXCJjb250ZW50LXR5cGVcIikgfHwgXCJcIjtcbiAgICBcbiAgICAvLyBIYW5kbGUgbXVsdGlwYXJ0IGZvcm0gZGF0YSAoZmlsZSB1cGxvYWQpXG4gICAgaWYgKGNvbnRlbnRUeXBlLmluY2x1ZGVzKFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiKSkge1xuICAgICAgY29uc3QgZm9ybURhdGEgPSBhd2FpdCByZXEuZm9ybURhdGEoKTtcbiAgICAgIGNvbnN0IGZpbGUgPSBmb3JtRGF0YS5nZXQoXCJmaWxlXCIpIGFzIEZpbGU7XG4gICAgICBcbiAgICAgIGlmICghZmlsZSkge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiTm8gZmlsZSBwcm92aWRlZFwiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICAvLyBDaGVjayBmaWxlIHNpemUgKG1heCAyNU1CIGZvciBmdWxsIHRyYWNrcylcbiAgICAgIGNvbnN0IG1heFNpemUgPSAyNSAqIDEwMjQgKiAxMDI0O1xuICAgICAgaWYgKGZpbGUuc2l6ZSA+IG1heFNpemUpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCk0LDQudC7INGB0LvQuNGI0LrQvtC8INCx0L7Qu9GM0YjQvtC5LiDQnNCw0LrRgdC40LzRg9C8IDI1TUJcIiB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgLy8gQ2hlY2sgZmlsZSB0eXBlXG4gICAgICBjb25zdCBhbGxvd2VkVHlwZXMgPSBbXCJhdWRpby9tcGVnXCIsIFwiYXVkaW8vbXAzXCIsIFwiYXVkaW8vd2F2XCIsIFwiYXVkaW8vd2F2ZVwiLCBcImF1ZGlvL3gtd2F2XCJdO1xuICAgICAgaWYgKCFhbGxvd2VkVHlwZXMuaW5jbHVkZXMoZmlsZS50eXBlKSkge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0J3QtdC/0L7QtNC00LXRgNC20LjQstCw0LXQvNGL0Lkg0YTQvtGA0LzQsNGCLiDQmNGB0L/QvtC70YzQt9GD0LnRgtC1IE1QMyDQuNC70LggV0FWXCIgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKGBVcGxvYWRpbmcgYXVkaW8gZmlsZTogJHtmaWxlLm5hbWV9LCBzaXplOiAke2ZpbGUuc2l6ZX0sIHR5cGU6ICR7ZmlsZS50eXBlfWApO1xuXG4gICAgICAvLyBGaXJzdCB1cGxvYWQgZmlsZSB0byBTdXBhYmFzZSBTdG9yYWdlIHRvIGdldCBhIHB1YmxpYyBVUkxcbiAgICAgIGNvbnN0IGZpbGVFeHQgPSBmaWxlLm5hbWUuc3BsaXQoJy4nKS5wb3AoKSB8fCAnbXAzJztcbiAgICAgIGNvbnN0IGZpbGVOYW1lID0gYCR7dXNlci5pZH0vJHtEYXRlLm5vdygpfV8ke2NyeXB0by5yYW5kb21VVUlEKCl9LiR7ZmlsZUV4dH1gO1xuICAgICAgXG4gICAgICBjb25zdCBhcnJheUJ1ZmZlciA9IGF3YWl0IGZpbGUuYXJyYXlCdWZmZXIoKTtcbiAgICAgIFxuICAgICAgY29uc3QgeyBlcnJvcjogdXBsb2FkRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50LnN0b3JhZ2VcbiAgICAgICAgLmZyb20oXCJhdWRpby1yZWZlcmVuY2VzXCIpXG4gICAgICAgIC51cGxvYWQoZmlsZU5hbWUsIGFycmF5QnVmZmVyLCB7XG4gICAgICAgICAgY29udGVudFR5cGU6IGZpbGUudHlwZSxcbiAgICAgICAgICB1cHNlcnQ6IGZhbHNlLFxuICAgICAgICB9KTtcblxuICAgICAgaWYgKHVwbG9hZEVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJTdG9yYWdlIHVwbG9hZCBlcnJvcjpcIiwgdXBsb2FkRXJyb3IpO1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0J7RiNC40LHQutCwINGB0L7RhdGA0LDQvdC10L3QuNGPINGE0LDQudC70LBcIiB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgLy8gR2V0IHB1YmxpYyBVUkxcbiAgICAgIGNvbnN0IHsgZGF0YTogdXJsRGF0YSB9ID0gc3VwYWJhc2VDbGllbnQuc3RvcmFnZVxuICAgICAgICAuZnJvbShcImF1ZGlvLXJlZmVyZW5jZXNcIilcbiAgICAgICAgLmdldFB1YmxpY1VybChmaWxlTmFtZSk7XG5cbiAgICAgIGNvbnN0IHB1YmxpY1VybCA9IHVybERhdGE/LnB1YmxpY1VybDtcbiAgICAgIFxuICAgICAgaWYgKCFwdWJsaWNVcmwpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/QvtC70YPRh9C40YLRjCBVUkwg0YTQsNC50LvQsFwiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBjb25zb2xlLmxvZyhgRmlsZSBzYXZlZCB0byBzdG9yYWdlOiAke3B1YmxpY1VybH1gKTtcblxuICAgICAgLy8gTm93IHVwbG9hZCB0byBTdW5vIHVzaW5nIFVSTCBlbmRwb2ludCAobXVjaCBtb3JlIG1lbW9yeSBlZmZpY2llbnQpXG4gICAgICBjb25zdCB1cGxvYWRSZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke1NVTk9fVVBMT0FEX0JBU0V9L2FwaS9maWxlLXVybC11cGxvYWRgLCB7XG4gICAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NVTk9fQVBJX0tFWX1gLFxuICAgICAgICB9LFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgdXJsOiBwdWJsaWNVcmwsXG4gICAgICAgIH0pLFxuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IHVwbG9hZERhdGEgPSBhd2FpdCB1cGxvYWRSZXNwb25zZS5qc29uKCk7XG4gICAgICBjb25zb2xlLmxvZyhcIlN1bm8gdXBsb2FkIHJlc3BvbnNlOlwiLCBKU09OLnN0cmluZ2lmeSh1cGxvYWREYXRhKSk7XG5cbiAgICAgIGlmICghdXBsb2FkUmVzcG9uc2Uub2sgfHwgdXBsb2FkRGF0YS5jb2RlICE9PSAyMDApIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIlN1bm8gdXBsb2FkIGZhaWxlZDpcIiwgdXBsb2FkRGF0YSk7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogdXBsb2FkRGF0YS5tc2cgfHwgXCLQntGI0LjQsdC60LAg0LfQsNCz0YDRg9C30LrQuCDRhNCw0LnQu9CwINCyIFN1bm9cIiB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgdXBsb2FkVXJsID0gdXBsb2FkRGF0YS5kYXRhPy51cmwgfHwgdXBsb2FkRGF0YS5kYXRhO1xuICAgICAgXG4gICAgICBpZiAoIXVwbG9hZFVybCkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiTm8gdXBsb2FkIFVSTCBpbiByZXNwb25zZTpcIiwgdXBsb2FkRGF0YSk7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQndC1INGD0LTQsNC70L7RgdGMINC/0L7Qu9GD0YfQuNGC0YwgVVJMINC+0YIgU3Vub1wiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBjb25zb2xlLmxvZyhgRmlsZSB1cGxvYWRlZCB0byBTdW5vIHN1Y2Nlc3NmdWxseTogJHt1cGxvYWRVcmx9YCk7XG5cbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgICAgdXBsb2FkVXJsLFxuICAgICAgICAgIGZpbGVOYW1lOiBmaWxlLm5hbWUsXG4gICAgICAgICAgbWVzc2FnZTogXCLQkNGD0LTQuNC+INC30LDQs9GA0YPQttC10L3QvlwiIFxuICAgICAgICB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuICAgIFxuICAgIC8vIEhhbmRsZSBKU09OIGJvZHkgKFVSTCB1cGxvYWQpXG4gICAgY29uc3QgeyBhdWRpb1VybCB9ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBcbiAgICBpZiAoIWF1ZGlvVXJsKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk5vIGF1ZGlvIFVSTCBwcm92aWRlZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFVwbG9hZGluZyBhdWRpbyBmcm9tIFVSTDogJHthdWRpb1VybH1gKTtcblxuICAgIC8vIFVwbG9hZCB0byBTdW5vIHVzaW5nIFVSTCBlbmRwb2ludFxuICAgIGNvbnN0IHVwbG9hZFJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7U1VOT19VUExPQURfQkFTRX0vYXBpL2ZpbGUtdXJsLXVwbG9hZGAsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NVTk9fQVBJX0tFWX1gLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdXJsOiBhdWRpb1VybCxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgY29uc3QgdXBsb2FkRGF0YSA9IGF3YWl0IHVwbG9hZFJlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhcIlN1bm8gVVJMIHVwbG9hZCByZXNwb25zZTpcIiwgSlNPTi5zdHJpbmdpZnkodXBsb2FkRGF0YSkpO1xuXG4gICAgaWYgKCF1cGxvYWRSZXNwb25zZS5vayB8fCB1cGxvYWREYXRhLmNvZGUgIT09IDIwMCkge1xuICAgICAgY29uc29sZS5lcnJvcihcIlN1bm8gVVJMIHVwbG9hZCBmYWlsZWQ6XCIsIHVwbG9hZERhdGEpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogdXBsb2FkRGF0YS5tc2cgfHwgXCLQntGI0LjQsdC60LAg0LfQsNCz0YDRg9C30LrQuCDQv9C+IFVSTFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgdXBsb2FkVXJsID0gdXBsb2FkRGF0YS5kYXRhPy51cmwgfHwgdXBsb2FkRGF0YS5kYXRhO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICB1cGxvYWRVcmwsXG4gICAgICAgIG1lc3NhZ2U6IFwi0JDRg9C00LjQviDQt9Cw0LPRgNGD0LbQtdC90L5cIiBcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIHVwbG9hZC1hdWRpby1yZWZlcmVuY2U6XCIsIGVycm9yKTtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQn9GA0L7QuNC30L7RiNC70LAg0L7RiNC40LHQutCwINC/0YDQuCDQt9Cw0LPRgNGD0LfQutC1XCIgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUNsQyxNQUFNLG1CQUFtQjtBQUV6QixNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZO01BQ2YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTBCLElBQ2xEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0saUJBQWlCLGFBQ3JCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFDaEMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdDQUFnQztJQUcvQyxNQUFNLGVBQWUsYUFDbkIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixJQUNoQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLElBQ3JDO01BQUUsUUFBUTtRQUFFLFNBQVM7VUFBRSxlQUFlO1FBQVc7TUFBRTtJQUFFO0lBR3ZELE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLGFBQWEsSUFBSSxDQUFDLE9BQU87SUFDNUUsSUFBSSxhQUFhLENBQUMsTUFBTTtNQUN0QixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGNBQWMsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQjtJQUV2RCwyQ0FBMkM7SUFDM0MsSUFBSSxZQUFZLFFBQVEsQ0FBQyx3QkFBd0I7TUFDL0MsTUFBTSxXQUFXLE1BQU0sSUFBSSxRQUFRO01BQ25DLE1BQU0sT0FBTyxTQUFTLEdBQUcsQ0FBQztNQUUxQixJQUFJLENBQUMsTUFBTTtRQUNULE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUFtQixJQUMzQztVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSw2Q0FBNkM7TUFDN0MsTUFBTSxVQUFVLEtBQUssT0FBTztNQUM1QixJQUFJLEtBQUssSUFBSSxHQUFHLFNBQVM7UUFDdkIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQXNDLElBQzlEO1VBQUUsUUFBUTtVQUFLLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUVuRjtNQUVBLGtCQUFrQjtNQUNsQixNQUFNLGVBQWU7UUFBQztRQUFjO1FBQWE7UUFBYTtRQUFjO09BQWM7TUFDMUYsSUFBSSxDQUFDLGFBQWEsUUFBUSxDQUFDLEtBQUssSUFBSSxHQUFHO1FBQ3JDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUFtRCxJQUMzRTtVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLEtBQUssSUFBSSxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUksQ0FBQyxRQUFRLEVBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQztNQUV4Riw0REFBNEQ7TUFDNUQsTUFBTSxVQUFVLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsTUFBTTtNQUM5QyxNQUFNLFdBQVcsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxLQUFLLEdBQUcsR0FBRyxDQUFDLEVBQUUsT0FBTyxVQUFVLEdBQUcsQ0FBQyxFQUFFLFFBQVEsQ0FBQztNQUU3RSxNQUFNLGNBQWMsTUFBTSxLQUFLLFdBQVc7TUFFMUMsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxlQUFlLE9BQU8sQ0FDeEQsSUFBSSxDQUFDLG9CQUNMLE1BQU0sQ0FBQyxVQUFVLGFBQWE7UUFDN0IsYUFBYSxLQUFLLElBQUk7UUFDdEIsUUFBUTtNQUNWO01BRUYsSUFBSSxhQUFhO1FBQ2YsUUFBUSxLQUFLLENBQUMseUJBQXlCO1FBQ3ZDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUEwQixJQUNsRDtVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSxpQkFBaUI7TUFDakIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsZUFBZSxPQUFPLENBQzdDLElBQUksQ0FBQyxvQkFDTCxZQUFZLENBQUM7TUFFaEIsTUFBTSxZQUFZLFNBQVM7TUFFM0IsSUFBSSxDQUFDLFdBQVc7UUFDZCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBZ0MsSUFDeEQ7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyx1QkFBdUIsRUFBRSxVQUFVLENBQUM7TUFFakQscUVBQXFFO01BQ3JFLE1BQU0saUJBQWlCLE1BQU0sTUFBTSxDQUFDLEVBQUUsaUJBQWlCLG9CQUFvQixDQUFDLEVBQUU7UUFDNUUsUUFBUTtRQUNSLFNBQVM7VUFDUCxnQkFBZ0I7VUFDaEIsaUJBQWlCLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQztRQUMzQztRQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7VUFDbkIsS0FBSztRQUNQO01BQ0Y7TUFFQSxNQUFNLGFBQWEsTUFBTSxlQUFlLElBQUk7TUFDNUMsUUFBUSxHQUFHLENBQUMseUJBQXlCLEtBQUssU0FBUyxDQUFDO01BRXBELElBQUksQ0FBQyxlQUFlLEVBQUUsSUFBSSxXQUFXLElBQUksS0FBSyxLQUFLO1FBQ2pELFFBQVEsS0FBSyxDQUFDLHVCQUF1QjtRQUNyQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU8sV0FBVyxHQUFHLElBQUk7UUFBK0IsSUFDekU7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BRUEsTUFBTSxZQUFZLFdBQVcsSUFBSSxFQUFFLE9BQU8sV0FBVyxJQUFJO01BRXpELElBQUksQ0FBQyxXQUFXO1FBQ2QsUUFBUSxLQUFLLENBQUMsOEJBQThCO1FBQzVDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQUUsT0FBTztRQUFrQyxJQUMxRDtVQUFFLFFBQVE7VUFBSyxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFbkY7TUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLG9DQUFvQyxFQUFFLFVBQVUsQ0FBQztNQUU5RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVDtRQUNBLFVBQVUsS0FBSyxJQUFJO1FBQ25CLFNBQVM7TUFDWCxJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsZ0NBQWdDO0lBQ2hDLE1BQU0sRUFBRSxRQUFRLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUVuQyxJQUFJLENBQUMsVUFBVTtNQUNiLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF3QixJQUNoRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDBCQUEwQixFQUFFLFNBQVMsQ0FBQztJQUVuRCxvQ0FBb0M7SUFDcEMsTUFBTSxpQkFBaUIsTUFBTSxNQUFNLENBQUMsRUFBRSxpQkFBaUIsb0JBQW9CLENBQUMsRUFBRTtNQUM1RSxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDO01BQzNDO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztRQUNuQixLQUFLO01BQ1A7SUFDRjtJQUVBLE1BQU0sYUFBYSxNQUFNLGVBQWUsSUFBSTtJQUM1QyxRQUFRLEdBQUcsQ0FBQyw2QkFBNkIsS0FBSyxTQUFTLENBQUM7SUFFeEQsSUFBSSxDQUFDLGVBQWUsRUFBRSxJQUFJLFdBQVcsSUFBSSxLQUFLLEtBQUs7TUFDakQsUUFBUSxLQUFLLENBQUMsMkJBQTJCO01BQ3pDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTyxXQUFXLEdBQUcsSUFBSTtNQUF5QixJQUNuRTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFlBQVksV0FBVyxJQUFJLEVBQUUsT0FBTyxXQUFXLElBQUk7SUFFekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1Q7TUFDQSxTQUFTO0lBQ1gsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLG9DQUFvQztJQUNsRCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBZ0MsSUFDeEQ7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
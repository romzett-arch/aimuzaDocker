/**
 * arena-lifecycle — Deno Edge Function
 * Вызывается по cron (каждые 5 минут) или вручную (admin)
 * Обрабатывает:
 *  1. Переход active → voting (по end_date)
 *  2. Автофинализация voting → completed
 *  3. Обновление статусов сезонов
 *  4. Создание daily challenge (если нет активного)
 *  5. Сброс weekly_points по понедельникам
 */ import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") || Deno.env.get("API_URL") || "http://api:3000";
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SERVICE_ROLE_KEY") || "";
    const supabase = createClient(supabaseUrl, supabaseKey, {
      auth: {
        persistSession: false
      }
    });
    const results = [];
    // 1. Process contest lifecycle (active→voting→completed, seasons)
    const { data: lifecycleCount, error: lcErr } = await supabase.rpc("process_contest_lifecycle");
    if (lcErr) {
      results.push(`lifecycle error: ${lcErr.message}`);
    } else {
      results.push(`lifecycle processed: ${lifecycleCount} contests`);
    }
    // 2. Create daily challenge if none exists
    const today = new Date();
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const todayEnd = new Date(todayStart.getTime() + 24 * 60 * 60 * 1000);
    const votingEnd = new Date(todayEnd.getTime() + 12 * 60 * 60 * 1000); // +12h for voting
    const { data: existingDaily } = await supabase.from("contests").select("id").eq("contest_type", "daily").gte("start_date", todayStart.toISOString()).limit(1);
    if (!existingDaily || existingDaily.length === 0) {
      // Get random theme for today
      const themes = [
        "Утренняя энергия",
        "Ночной вайб",
        "Дорожное приключение",
        "Мечтательное настроение",
        "Танцевальный бит",
        "Лирическая история",
        "Ретро волна",
        "Электронный рассвет",
        "Акустическая душа",
        "Городской ритм",
        "Космическое путешествие",
        "Летний закат",
        "Зимняя сказка",
        "Весеннее пробуждение",
        "Осенняя меланхолия",
        "Любовная серенада",
        "Бунтарский дух",
        "Тихая гавань",
        "Неоновые огни",
        "Свободный полёт"
      ];
      const theme = themes[today.getDate() % themes.length];
      const dayOfWeek = [
        "Вс",
        "Пн",
        "Вт",
        "Ср",
        "Чт",
        "Пт",
        "Сб"
      ][today.getDay()];
      const dayNum = today.getDate();
      const monthNames = [
        "янв",
        "фев",
        "мар",
        "апр",
        "мая",
        "июн",
        "июл",
        "авг",
        "сен",
        "окт",
        "ноя",
        "дек"
      ];
      const { error: createErr } = await supabase.from("contests").insert({
        title: `Daily Challenge: ${theme}`,
        description: `Ежедневный вызов ${dayNum} ${monthNames[today.getMonth()]}. Создайте трек на тему «${theme}» и победите!`,
        contest_type: "daily",
        status: "active",
        start_date: todayStart.toISOString(),
        end_date: todayEnd.toISOString(),
        voting_end_date: votingEnd.toISOString(),
        theme,
        prize_amount: 50,
        prize_pool_formula: "fixed",
        prize_distribution: [
          0.6,
          0.3,
          0.1
        ],
        max_entries_per_user: 1,
        entry_fee: 0,
        min_participants: 3,
        auto_finalize: true,
        require_new_track: true,
        scoring_mode: "votes",
        created_by: null
      });
      if (createErr) {
        results.push(`daily create error: ${createErr.message}`);
      } else {
        results.push(`daily challenge created: ${theme}`);
      }
    } else {
      results.push("daily challenge already exists");
    }
    // 3. Weekly reset (Monday at 00:00)
    if (today.getDay() === 1 && today.getHours() < 1) {
      const { error: resetErr } = await supabase.from("contest_ratings").update({
        weekly_points: 0
      }).gt("weekly_points", 0);
      if (resetErr) {
        results.push(`weekly reset error: ${resetErr.message}`);
      } else {
        results.push("weekly points reset");
      }
    }
    // 4. Check achievements for recently active users
    const { data: recentEntries } = await supabase.from("contest_entries").select("user_id").gte("created_at", new Date(Date.now() - 10 * 60 * 1000).toISOString()).limit(50);
    if (recentEntries && recentEntries.length > 0) {
      const uniqueUsers = [
        ...new Set(recentEntries.map((e)=>e.user_id))
      ];
      let achievementsAwarded = 0;
      for (const uid of uniqueUsers){
        const { data: count } = await supabase.rpc("check_contest_achievements", {
          p_user_id: uid
        });
        achievementsAwarded += count || 0;
      }
      results.push(`achievements checked for ${uniqueUsers.length} users, awarded ${achievementsAwarded}`);
    }
    return new Response(JSON.stringify({
      ok: true,
      results,
      timestamp: new Date().toISOString()
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 200
    });
  } catch (err) {
    return new Response(JSON.stringify({
      ok: false,
      error: String(err)
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 500
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9hcmVuYS1saWZlY3ljbGUvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIGFyZW5hLWxpZmVjeWNsZSDigJQgRGVubyBFZGdlIEZ1bmN0aW9uXHJcbiAqINCS0YvQt9GL0LLQsNC10YLRgdGPINC/0L4gY3JvbiAo0LrQsNC20LTRi9C1IDUg0LzQuNC90YPRgikg0LjQu9C4INCy0YDRg9GH0L3Rg9GOIChhZG1pbilcclxuICog0J7QsdGA0LDQsdCw0YLRi9Cy0LDQtdGCOlxyXG4gKiAgMS4g0J/QtdGA0LXRhdC+0LQgYWN0aXZlIOKGkiB2b3RpbmcgKNC/0L4gZW5kX2RhdGUpXHJcbiAqICAyLiDQkNCy0YLQvtGE0LjQvdCw0LvQuNC30LDRhtC40Y8gdm90aW5nIOKGkiBjb21wbGV0ZWRcclxuICogIDMuINCe0LHQvdC+0LLQu9C10L3QuNC1INGB0YLQsNGC0YPRgdC+0LIg0YHQtdC30L7QvdC+0LJcclxuICogIDQuINCh0L7Qt9C00LDQvdC40LUgZGFpbHkgY2hhbGxlbmdlICjQtdGB0LvQuCDQvdC10YIg0LDQutGC0LjQstC90L7Qs9C+KVxyXG4gKiAgNS4g0KHQsdGA0L7RgSB3ZWVrbHlfcG9pbnRzINC/0L4g0L/QvtC90LXQtNC10LvRjNC90LjQutCw0LxcclxuICovXHJcblxyXG5pbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xyXG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcclxuXHJcbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xyXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxyXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlXCIsXHJcbn07XHJcblxyXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XHJcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XHJcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFwib2tcIiwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcclxuICB9XHJcblxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSB8fCBEZW5vLmVudi5nZXQoXCJBUElfVVJMXCIpIHx8IFwiaHR0cDovL2FwaTozMDAwXCI7XHJcbiAgICBjb25zdCBzdXBhYmFzZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikgfHwgRGVuby5lbnYuZ2V0KFwiU0VSVklDRV9ST0xFX0tFWVwiKSB8fCBcIlwiO1xyXG5cclxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZUtleSwge1xyXG4gICAgICBhdXRoOiB7IHBlcnNpc3RTZXNzaW9uOiBmYWxzZSB9LFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgcmVzdWx0czogc3RyaW5nW10gPSBbXTtcclxuXHJcbiAgICAvLyAxLiBQcm9jZXNzIGNvbnRlc3QgbGlmZWN5Y2xlIChhY3RpdmXihpJ2b3RpbmfihpJjb21wbGV0ZWQsIHNlYXNvbnMpXHJcbiAgICBjb25zdCB7IGRhdGE6IGxpZmVjeWNsZUNvdW50LCBlcnJvcjogbGNFcnIgfSA9IGF3YWl0IHN1cGFiYXNlLnJwYyhcInByb2Nlc3NfY29udGVzdF9saWZlY3ljbGVcIik7XHJcbiAgICBpZiAobGNFcnIpIHtcclxuICAgICAgcmVzdWx0cy5wdXNoKGBsaWZlY3ljbGUgZXJyb3I6ICR7bGNFcnIubWVzc2FnZX1gKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlc3VsdHMucHVzaChgbGlmZWN5Y2xlIHByb2Nlc3NlZDogJHtsaWZlY3ljbGVDb3VudH0gY29udGVzdHNgKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyAyLiBDcmVhdGUgZGFpbHkgY2hhbGxlbmdlIGlmIG5vbmUgZXhpc3RzXHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCB0b2RheVN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgdG9kYXkuZ2V0RGF0ZSgpKTtcclxuICAgIGNvbnN0IHRvZGF5RW5kID0gbmV3IERhdGUodG9kYXlTdGFydC5nZXRUaW1lKCkgKyAyNCAqIDYwICogNjAgKiAxMDAwKTtcclxuICAgIGNvbnN0IHZvdGluZ0VuZCA9IG5ldyBEYXRlKHRvZGF5RW5kLmdldFRpbWUoKSArIDEyICogNjAgKiA2MCAqIDEwMDApOyAvLyArMTJoIGZvciB2b3RpbmdcclxuXHJcbiAgICBjb25zdCB7IGRhdGE6IGV4aXN0aW5nRGFpbHkgfSA9IGF3YWl0IHN1cGFiYXNlXHJcbiAgICAgIC5mcm9tKFwiY29udGVzdHNcIilcclxuICAgICAgLnNlbGVjdChcImlkXCIpXHJcbiAgICAgIC5lcShcImNvbnRlc3RfdHlwZVwiLCBcImRhaWx5XCIpXHJcbiAgICAgIC5ndGUoXCJzdGFydF9kYXRlXCIsIHRvZGF5U3RhcnQudG9JU09TdHJpbmcoKSlcclxuICAgICAgLmxpbWl0KDEpO1xyXG5cclxuICAgIGlmICghZXhpc3RpbmdEYWlseSB8fCBleGlzdGluZ0RhaWx5Lmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAvLyBHZXQgcmFuZG9tIHRoZW1lIGZvciB0b2RheVxyXG4gICAgICBjb25zdCB0aGVtZXMgPSBbXHJcbiAgICAgICAgXCLQo9GC0YDQtdC90L3Rj9GPINGN0L3QtdGA0LPQuNGPXCIsIFwi0J3QvtGH0L3QvtC5INCy0LDQudCxXCIsIFwi0JTQvtGA0L7QttC90L7QtSDQv9GA0LjQutC70Y7Rh9C10L3QuNC1XCIsXHJcbiAgICAgICAgXCLQnNC10YfRgtCw0YLQtdC70YzQvdC+0LUg0L3QsNGB0YLRgNC+0LXQvdC40LVcIiwgXCLQotCw0L3RhtC10LLQsNC70YzQvdGL0Lkg0LHQuNGCXCIsIFwi0JvQuNGA0LjRh9C10YHQutCw0Y8g0LjRgdGC0L7RgNC40Y9cIixcclxuICAgICAgICBcItCg0LXRgtGA0L4g0LLQvtC70L3QsFwiLCBcItCt0LvQtdC60YLRgNC+0L3QvdGL0Lkg0YDQsNGB0YHQstC10YJcIiwgXCLQkNC60YPRgdGC0LjRh9C10YHQutCw0Y8g0LTRg9GI0LBcIixcclxuICAgICAgICBcItCT0L7RgNC+0LTRgdC60L7QuSDRgNC40YLQvFwiLCBcItCa0L7RgdC80LjRh9C10YHQutC+0LUg0L/Rg9GC0LXRiNC10YHRgtCy0LjQtVwiLCBcItCb0LXRgtC90LjQuSDQt9Cw0LrQsNGCXCIsXHJcbiAgICAgICAgXCLQl9C40LzQvdGP0Y8g0YHQutCw0LfQutCwXCIsIFwi0JLQtdGB0LXQvdC90LXQtSDQv9GA0L7QsdGD0LbQtNC10L3QuNC1XCIsIFwi0J7RgdC10L3QvdGP0Y8g0LzQtdC70LDQvdGF0L7Qu9C40Y9cIixcclxuICAgICAgICBcItCb0Y7QsdC+0LLQvdCw0Y8g0YHQtdGA0LXQvdCw0LTQsFwiLCBcItCR0YPQvdGC0LDRgNGB0LrQuNC5INC00YPRhVwiLCBcItCi0LjRhdCw0Y8g0LPQsNCy0LDQvdGMXCIsXHJcbiAgICAgICAgXCLQndC10L7QvdC+0LLRi9C1INC+0LPQvdC4XCIsIFwi0KHQstC+0LHQvtC00L3Ri9C5INC/0L7Qu9GR0YJcIixcclxuICAgICAgXTtcclxuICAgICAgY29uc3QgdGhlbWUgPSB0aGVtZXNbdG9kYXkuZ2V0RGF0ZSgpICUgdGhlbWVzLmxlbmd0aF07XHJcbiAgICAgIGNvbnN0IGRheU9mV2VlayA9IFtcItCS0YFcIiwgXCLQn9C9XCIsIFwi0JLRglwiLCBcItCh0YBcIiwgXCLQp9GCXCIsIFwi0J/RglwiLCBcItCh0LFcIl1bdG9kYXkuZ2V0RGF5KCldO1xyXG4gICAgICBjb25zdCBkYXlOdW0gPSB0b2RheS5nZXREYXRlKCk7XHJcbiAgICAgIGNvbnN0IG1vbnRoTmFtZXMgPSBbXCLRj9C90LJcIiwgXCLRhNC10LJcIiwgXCLQvNCw0YBcIiwgXCLQsNC/0YBcIiwgXCLQvNCw0Y9cIiwgXCLQuNGO0L1cIiwgXCLQuNGO0LtcIiwgXCLQsNCy0LNcIiwgXCLRgdC10L1cIiwgXCLQvtC60YJcIiwgXCLQvdC+0Y9cIiwgXCLQtNC10LpcIl07XHJcblxyXG4gICAgICBjb25zdCB7IGVycm9yOiBjcmVhdGVFcnIgfSA9IGF3YWl0IHN1cGFiYXNlXHJcbiAgICAgICAgLmZyb20oXCJjb250ZXN0c1wiKVxyXG4gICAgICAgIC5pbnNlcnQoe1xyXG4gICAgICAgICAgdGl0bGU6IGBEYWlseSBDaGFsbGVuZ2U6ICR7dGhlbWV9YCxcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBg0JXQttC10LTQvdC10LLQvdGL0Lkg0LLRi9C30L7QsiAke2RheU51bX0gJHttb250aE5hbWVzW3RvZGF5LmdldE1vbnRoKCldfS4g0KHQvtC30LTQsNC50YLQtSDRgtGA0LXQuiDQvdCwINGC0LXQvNGDIMKrJHt0aGVtZX3CuyDQuCDQv9C+0LHQtdC00LjRgtC1IWAsXHJcbiAgICAgICAgICBjb250ZXN0X3R5cGU6IFwiZGFpbHlcIixcclxuICAgICAgICAgIHN0YXR1czogXCJhY3RpdmVcIixcclxuICAgICAgICAgIHN0YXJ0X2RhdGU6IHRvZGF5U3RhcnQudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgIGVuZF9kYXRlOiB0b2RheUVuZC50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgdm90aW5nX2VuZF9kYXRlOiB2b3RpbmdFbmQudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgIHRoZW1lLFxyXG4gICAgICAgICAgcHJpemVfYW1vdW50OiA1MCxcclxuICAgICAgICAgIHByaXplX3Bvb2xfZm9ybXVsYTogXCJmaXhlZFwiLFxyXG4gICAgICAgICAgcHJpemVfZGlzdHJpYnV0aW9uOiBbMC42LCAwLjMsIDAuMV0sXHJcbiAgICAgICAgICBtYXhfZW50cmllc19wZXJfdXNlcjogMSxcclxuICAgICAgICAgIGVudHJ5X2ZlZTogMCxcclxuICAgICAgICAgIG1pbl9wYXJ0aWNpcGFudHM6IDMsXHJcbiAgICAgICAgICBhdXRvX2ZpbmFsaXplOiB0cnVlLFxyXG4gICAgICAgICAgcmVxdWlyZV9uZXdfdHJhY2s6IHRydWUsXHJcbiAgICAgICAgICBzY29yaW5nX21vZGU6IFwidm90ZXNcIixcclxuICAgICAgICAgIGNyZWF0ZWRfYnk6IG51bGwsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAoY3JlYXRlRXJyKSB7XHJcbiAgICAgICAgcmVzdWx0cy5wdXNoKGBkYWlseSBjcmVhdGUgZXJyb3I6ICR7Y3JlYXRlRXJyLm1lc3NhZ2V9YCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmVzdWx0cy5wdXNoKGBkYWlseSBjaGFsbGVuZ2UgY3JlYXRlZDogJHt0aGVtZX1gKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmVzdWx0cy5wdXNoKFwiZGFpbHkgY2hhbGxlbmdlIGFscmVhZHkgZXhpc3RzXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIDMuIFdlZWtseSByZXNldCAoTW9uZGF5IGF0IDAwOjAwKVxyXG4gICAgaWYgKHRvZGF5LmdldERheSgpID09PSAxICYmIHRvZGF5LmdldEhvdXJzKCkgPCAxKSB7XHJcbiAgICAgIGNvbnN0IHsgZXJyb3I6IHJlc2V0RXJyIH0gPSBhd2FpdCBzdXBhYmFzZVxyXG4gICAgICAgIC5mcm9tKFwiY29udGVzdF9yYXRpbmdzXCIpXHJcbiAgICAgICAgLnVwZGF0ZSh7IHdlZWtseV9wb2ludHM6IDAgfSlcclxuICAgICAgICAuZ3QoXCJ3ZWVrbHlfcG9pbnRzXCIsIDApO1xyXG5cclxuICAgICAgaWYgKHJlc2V0RXJyKSB7XHJcbiAgICAgICAgcmVzdWx0cy5wdXNoKGB3ZWVrbHkgcmVzZXQgZXJyb3I6ICR7cmVzZXRFcnIubWVzc2FnZX1gKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXN1bHRzLnB1c2goXCJ3ZWVrbHkgcG9pbnRzIHJlc2V0XCIpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gNC4gQ2hlY2sgYWNoaWV2ZW1lbnRzIGZvciByZWNlbnRseSBhY3RpdmUgdXNlcnNcclxuICAgIGNvbnN0IHsgZGF0YTogcmVjZW50RW50cmllcyB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgICAgLmZyb20oXCJjb250ZXN0X2VudHJpZXNcIilcclxuICAgICAgLnNlbGVjdChcInVzZXJfaWRcIilcclxuICAgICAgLmd0ZShcImNyZWF0ZWRfYXRcIiwgbmV3IERhdGUoRGF0ZS5ub3coKSAtIDEwICogNjAgKiAxMDAwKS50b0lTT1N0cmluZygpKVxyXG4gICAgICAubGltaXQoNTApO1xyXG5cclxuICAgIGlmIChyZWNlbnRFbnRyaWVzICYmIHJlY2VudEVudHJpZXMubGVuZ3RoID4gMCkge1xyXG4gICAgICBjb25zdCB1bmlxdWVVc2VycyA9IFsuLi5uZXcgU2V0KHJlY2VudEVudHJpZXMubWFwKChlOiBhbnkpID0+IGUudXNlcl9pZCkpXTtcclxuICAgICAgbGV0IGFjaGlldmVtZW50c0F3YXJkZWQgPSAwO1xyXG4gICAgICBmb3IgKGNvbnN0IHVpZCBvZiB1bmlxdWVVc2Vycykge1xyXG4gICAgICAgIGNvbnN0IHsgZGF0YTogY291bnQgfSA9IGF3YWl0IHN1cGFiYXNlLnJwYyhcImNoZWNrX2NvbnRlc3RfYWNoaWV2ZW1lbnRzXCIsIHsgcF91c2VyX2lkOiB1aWQgfSk7XHJcbiAgICAgICAgYWNoaWV2ZW1lbnRzQXdhcmRlZCArPSAoY291bnQgfHwgMCk7XHJcbiAgICAgIH1cclxuICAgICAgcmVzdWx0cy5wdXNoKGBhY2hpZXZlbWVudHMgY2hlY2tlZCBmb3IgJHt1bmlxdWVVc2Vycy5sZW5ndGh9IHVzZXJzLCBhd2FyZGVkICR7YWNoaWV2ZW1lbnRzQXdhcmRlZH1gKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxyXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IG9rOiB0cnVlLCByZXN1bHRzLCB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9KSxcclxuICAgICAge1xyXG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXHJcbiAgICAgICAgc3RhdHVzOiAyMDAsXHJcbiAgICAgIH1cclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxyXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IG9rOiBmYWxzZSwgZXJyb3I6IFN0cmluZyhlcnIpIH0pLFxyXG4gICAgICB7XHJcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcclxuICAgICAgICBzdGF0dXM6IDUwMCxcclxuICAgICAgfVxyXG4gICAgKTtcclxuICB9XHJcbn0pO1xyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7OztDQVNDLEdBRUQsU0FBUyxLQUFLLFFBQVEsK0NBQStDO0FBQ3JFLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxjQUFjO0lBQy9FLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUI7SUFFckcsTUFBTSxXQUFXLGFBQWEsYUFBYSxhQUFhO01BQ3RELE1BQU07UUFBRSxnQkFBZ0I7TUFBTTtJQUNoQztJQUVBLE1BQU0sVUFBb0IsRUFBRTtJQUU1QixrRUFBa0U7SUFDbEUsTUFBTSxFQUFFLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSyxFQUFFLEdBQUcsTUFBTSxTQUFTLEdBQUcsQ0FBQztJQUNsRSxJQUFJLE9BQU87TUFDVCxRQUFRLElBQUksQ0FBQyxDQUFDLGlCQUFpQixFQUFFLE1BQU0sT0FBTyxDQUFDLENBQUM7SUFDbEQsT0FBTztNQUNMLFFBQVEsSUFBSSxDQUFDLENBQUMscUJBQXFCLEVBQUUsZUFBZSxTQUFTLENBQUM7SUFDaEU7SUFFQSwyQ0FBMkM7SUFDM0MsTUFBTSxRQUFRLElBQUk7SUFDbEIsTUFBTSxhQUFhLElBQUksS0FBSyxNQUFNLFdBQVcsSUFBSSxNQUFNLFFBQVEsSUFBSSxNQUFNLE9BQU87SUFDaEYsTUFBTSxXQUFXLElBQUksS0FBSyxXQUFXLE9BQU8sS0FBSyxLQUFLLEtBQUssS0FBSztJQUNoRSxNQUFNLFlBQVksSUFBSSxLQUFLLFNBQVMsT0FBTyxLQUFLLEtBQUssS0FBSyxLQUFLLE9BQU8sa0JBQWtCO0lBRXhGLE1BQU0sRUFBRSxNQUFNLGFBQWEsRUFBRSxHQUFHLE1BQU0sU0FDbkMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLE1BQ1AsRUFBRSxDQUFDLGdCQUFnQixTQUNuQixHQUFHLENBQUMsY0FBYyxXQUFXLFdBQVcsSUFDeEMsS0FBSyxDQUFDO0lBRVQsSUFBSSxDQUFDLGlCQUFpQixjQUFjLE1BQU0sS0FBSyxHQUFHO01BQ2hELDZCQUE2QjtNQUM3QixNQUFNLFNBQVM7UUFDYjtRQUFvQjtRQUFlO1FBQ25DO1FBQTJCO1FBQW9CO1FBQy9DO1FBQWU7UUFBdUI7UUFDdEM7UUFBa0I7UUFBMkI7UUFDN0M7UUFBaUI7UUFBd0I7UUFDekM7UUFBcUI7UUFBa0I7UUFDdkM7UUFBaUI7T0FDbEI7TUFDRCxNQUFNLFFBQVEsTUFBTSxDQUFDLE1BQU0sT0FBTyxLQUFLLE9BQU8sTUFBTSxDQUFDO01BQ3JELE1BQU0sWUFBWTtRQUFDO1FBQU07UUFBTTtRQUFNO1FBQU07UUFBTTtRQUFNO09BQUssQ0FBQyxNQUFNLE1BQU0sR0FBRztNQUM1RSxNQUFNLFNBQVMsTUFBTSxPQUFPO01BQzVCLE1BQU0sYUFBYTtRQUFDO1FBQU87UUFBTztRQUFPO1FBQU87UUFBTztRQUFPO1FBQU87UUFBTztRQUFPO1FBQU87UUFBTztPQUFNO01BRXZHLE1BQU0sRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FDaEMsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1FBQ04sT0FBTyxDQUFDLGlCQUFpQixFQUFFLE1BQU0sQ0FBQztRQUNsQyxhQUFhLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLEVBQUUsVUFBVSxDQUFDLE1BQU0sUUFBUSxHQUFHLENBQUMseUJBQXlCLEVBQUUsTUFBTSxhQUFhLENBQUM7UUFDdkgsY0FBYztRQUNkLFFBQVE7UUFDUixZQUFZLFdBQVcsV0FBVztRQUNsQyxVQUFVLFNBQVMsV0FBVztRQUM5QixpQkFBaUIsVUFBVSxXQUFXO1FBQ3RDO1FBQ0EsY0FBYztRQUNkLG9CQUFvQjtRQUNwQixvQkFBb0I7VUFBQztVQUFLO1VBQUs7U0FBSTtRQUNuQyxzQkFBc0I7UUFDdEIsV0FBVztRQUNYLGtCQUFrQjtRQUNsQixlQUFlO1FBQ2YsbUJBQW1CO1FBQ25CLGNBQWM7UUFDZCxZQUFZO01BQ2Q7TUFFRixJQUFJLFdBQVc7UUFDYixRQUFRLElBQUksQ0FBQyxDQUFDLG9CQUFvQixFQUFFLFVBQVUsT0FBTyxDQUFDLENBQUM7TUFDekQsT0FBTztRQUNMLFFBQVEsSUFBSSxDQUFDLENBQUMseUJBQXlCLEVBQUUsTUFBTSxDQUFDO01BQ2xEO0lBQ0YsT0FBTztNQUNMLFFBQVEsSUFBSSxDQUFDO0lBQ2Y7SUFFQSxvQ0FBb0M7SUFDcEMsSUFBSSxNQUFNLE1BQU0sT0FBTyxLQUFLLE1BQU0sUUFBUSxLQUFLLEdBQUc7TUFDaEQsTUFBTSxFQUFFLE9BQU8sUUFBUSxFQUFFLEdBQUcsTUFBTSxTQUMvQixJQUFJLENBQUMsbUJBQ0wsTUFBTSxDQUFDO1FBQUUsZUFBZTtNQUFFLEdBQzFCLEVBQUUsQ0FBQyxpQkFBaUI7TUFFdkIsSUFBSSxVQUFVO1FBQ1osUUFBUSxJQUFJLENBQUMsQ0FBQyxvQkFBb0IsRUFBRSxTQUFTLE9BQU8sQ0FBQyxDQUFDO01BQ3hELE9BQU87UUFDTCxRQUFRLElBQUksQ0FBQztNQUNmO0lBQ0Y7SUFFQSxrREFBa0Q7SUFDbEQsTUFBTSxFQUFFLE1BQU0sYUFBYSxFQUFFLEdBQUcsTUFBTSxTQUNuQyxJQUFJLENBQUMsbUJBQ0wsTUFBTSxDQUFDLFdBQ1AsR0FBRyxDQUFDLGNBQWMsSUFBSSxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssS0FBSyxNQUFNLFdBQVcsSUFDbkUsS0FBSyxDQUFDO0lBRVQsSUFBSSxpQkFBaUIsY0FBYyxNQUFNLEdBQUcsR0FBRztNQUM3QyxNQUFNLGNBQWM7V0FBSSxJQUFJLElBQUksY0FBYyxHQUFHLENBQUMsQ0FBQyxJQUFXLEVBQUUsT0FBTztPQUFHO01BQzFFLElBQUksc0JBQXNCO01BQzFCLEtBQUssTUFBTSxPQUFPLFlBQWE7UUFDN0IsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLEdBQUcsTUFBTSxTQUFTLEdBQUcsQ0FBQyw4QkFBOEI7VUFBRSxXQUFXO1FBQUk7UUFDMUYsdUJBQXdCLFNBQVM7TUFDbkM7TUFDQSxRQUFRLElBQUksQ0FBQyxDQUFDLHlCQUF5QixFQUFFLFlBQVksTUFBTSxDQUFDLGdCQUFnQixFQUFFLG9CQUFvQixDQUFDO0lBQ3JHO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxJQUFJO01BQU07TUFBUyxXQUFXLElBQUksT0FBTyxXQUFXO0lBQUcsSUFDeEU7TUFDRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO01BQzlELFFBQVE7SUFDVjtFQUVKLEVBQUUsT0FBTyxLQUFLO0lBQ1osT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxJQUFJO01BQU8sT0FBTyxPQUFPO0lBQUssSUFDL0M7TUFDRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO01BQzlELFFBQVE7SUFDVjtFQUVKO0FBQ0YifQ==
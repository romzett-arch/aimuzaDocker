import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version'
};
// Whitelist of allowed actions — only these can be performed via impersonation
const ALLOWED_ACTIONS = {
  // Track interactions
  like_track: {
    table: 'track_likes',
    operation: 'insert',
    requiredFields: [
      'track_id'
    ],
    description: 'Like a track'
  },
  unlike_track: {
    table: 'track_likes',
    operation: 'delete',
    requiredFields: [
      'track_id'
    ],
    description: 'Unlike a track'
  },
  delete_track: {
    table: 'tracks',
    operation: 'custom',
    requiredFields: [
      'track_id'
    ],
    description: 'Delete a track'
  },
  // User follows
  follow_user: {
    table: 'user_follows',
    operation: 'insert',
    requiredFields: [
      'following_id'
    ],
    description: 'Follow a user'
  },
  unfollow_user: {
    table: 'user_follows',
    operation: 'delete',
    requiredFields: [
      'following_id'
    ],
    description: 'Unfollow a user'
  },
  // Track updates
  update_track: {
    table: 'tracks',
    operation: 'update',
    requiredFields: [
      'track_id'
    ],
    description: 'Update track metadata'
  },
  // Comments
  add_comment: {
    table: 'track_comments',
    operation: 'insert',
    requiredFields: [
      'track_id',
      'content'
    ],
    description: 'Add a comment to a track'
  },
  delete_comment: {
    table: 'track_comments',
    operation: 'delete',
    requiredFields: [
      'comment_id'
    ],
    description: 'Delete a comment'
  },
  update_comment: {
    table: 'track_comments',
    operation: 'update',
    requiredFields: [
      'comment_id',
      'content'
    ],
    description: 'Edit a comment'
  },
  like_comment: {
    table: 'comment_likes',
    operation: 'insert',
    requiredFields: [
      'comment_id'
    ],
    description: 'Like a comment'
  },
  unlike_comment: {
    table: 'comment_likes',
    operation: 'delete',
    requiredFields: [
      'comment_id'
    ],
    description: 'Unlike a comment'
  },
  add_reaction: {
    table: 'comment_reactions',
    operation: 'insert',
    requiredFields: [
      'comment_id',
      'emoji'
    ],
    description: 'Add reaction to a comment'
  },
  remove_reaction: {
    table: 'comment_reactions',
    operation: 'delete',
    requiredFields: [
      'comment_id',
      'emoji'
    ],
    description: 'Remove reaction from a comment'
  },
  report_comment: {
    table: 'comment_reports',
    operation: 'insert',
    requiredFields: [
      'comment_id',
      'reason'
    ],
    description: 'Report a comment'
  },
  // Profile updates
  update_profile: {
    table: 'profiles',
    operation: 'update',
    requiredFields: [],
    description: 'Update user profile'
  },
  // Playlists
  create_playlist: {
    table: 'playlists',
    operation: 'insert',
    requiredFields: [
      'title'
    ],
    description: 'Create a playlist'
  },
  update_playlist: {
    table: 'playlists',
    operation: 'update',
    requiredFields: [
      'playlist_id'
    ],
    description: 'Update a playlist'
  },
  delete_playlist: {
    table: 'playlists',
    operation: 'delete',
    requiredFields: [
      'playlist_id'
    ],
    description: 'Delete a playlist'
  },
  add_to_playlist: {
    table: 'playlist_tracks',
    operation: 'insert',
    requiredFields: [
      'playlist_id',
      'track_id'
    ],
    description: 'Add track to a playlist'
  },
  remove_from_playlist: {
    table: 'playlist_tracks',
    operation: 'delete',
    requiredFields: [
      'playlist_id',
      'track_id'
    ],
    description: 'Remove track from a playlist'
  },
  like_playlist: {
    table: 'playlist_likes',
    operation: 'insert',
    requiredFields: [
      'playlist_id'
    ],
    description: 'Like a playlist'
  },
  unlike_playlist: {
    table: 'playlist_likes',
    operation: 'delete',
    requiredFields: [
      'playlist_id'
    ],
    description: 'Unlike a playlist'
  },
  // Messages
  send_message: {
    table: 'messages',
    operation: 'insert',
    requiredFields: [
      'conversation_id',
      'content'
    ],
    description: 'Send a message'
  },
  // Forum
  create_forum_topic: {
    table: 'forum_topics',
    operation: 'custom',
    requiredFields: [
      'category_id',
      'title',
      'content'
    ],
    description: 'Create a forum topic'
  },
  create_forum_post: {
    table: 'forum_posts',
    operation: 'custom',
    requiredFields: [
      'topic_id',
      'content'
    ],
    description: 'Create a forum post'
  }
};
// SHA-256 hash function
async function sha256(message) {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b)=>b.toString(16).padStart(2, '0')).join('');
}
Deno.serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY');
  try {
    // 1. Verify JWT
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({
        error: 'Unauthorized'
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const token = authHeader.replace('Bearer ', '');
    // Decode JWT to get user ID (works with both Supabase and custom JWT)
    let adminUserId;
    try {
      const payloadPart = token.split('.')[1];
      const decoded = JSON.parse(atob(payloadPart));
      adminUserId = decoded.sub;
      if (!adminUserId) throw new Error('No sub in token');
    } catch (e) {
      console.error('JWT decode error:', e);
      return new Response(JSON.stringify({
        error: 'Invalid token'
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    // 2. Check super_admin role ONLY
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);
    const { data: userRole } = await adminClient.from('user_roles').select('role').eq('user_id', adminUserId).single();
    if (!userRole || ![
      'super_admin',
      'admin'
    ].includes(userRole.role)) {
      console.warn(`Impersonation denied for user ${adminUserId}, role: ${userRole?.role}`);
      return new Response(JSON.stringify({
        error: 'Доступ запрещён. Только для администраторов.'
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    // 3. Parse request body
    const body = await req.json();
    const { pin, target_user_id, action, payload } = body;
    // 4. Verify PIN
    if (!pin || typeof pin !== 'string' || pin.length !== 6) {
      return new Response(JSON.stringify({
        error: 'Требуется 6-значный PIN-код'
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const { data: pinSetting } = await adminClient.from('settings').select('value').eq('key', 'backup_pin_hash').single();
    if (!pinSetting?.value) {
      return new Response(JSON.stringify({
        error: 'PIN-код не настроен'
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const pinHash = await sha256(pin);
    if (pinHash !== pinSetting.value) {
      console.warn(`Invalid PIN attempt by super_admin: ${adminUserId}`);
      await adminClient.from('impersonation_action_logs').insert({
        admin_user_id: adminUserId,
        target_user_id: target_user_id || '00000000-0000-0000-0000-000000000000',
        action_type: 'pin_failed',
        action_payload: {
          action
        },
        result_status: 'error',
        error_message: 'Invalid PIN'
      });
      return new Response(JSON.stringify({
        error: 'Неверный PIN-код'
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    // 5. Validate action
    if (!action || !ALLOWED_ACTIONS[action]) {
      return new Response(JSON.stringify({
        error: `Действие '${action}' не разрешено`,
        allowed: Object.keys(ALLOWED_ACTIONS)
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    if (!target_user_id) {
      return new Response(JSON.stringify({
        error: 'target_user_id обязателен'
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    // Verify target user exists
    const { data: targetProfile } = await adminClient.from('profiles').select('user_id, username').eq('user_id', target_user_id).single();
    if (!targetProfile) {
      return new Response(JSON.stringify({
        error: 'Целевой пользователь не найден'
      }), {
        status: 404,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    const actionConfig = ALLOWED_ACTIONS[action];
    // Validate required fields
    for (const field of actionConfig.requiredFields){
      if (!payload || payload[field] === undefined) {
        return new Response(JSON.stringify({
          error: `Поле '${field}' обязательно для действия '${action}'`
        }), {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
    }
    // 5b. Enforce forum rate limits for target user
    if (action === 'create_forum_topic' || action === 'create_forum_post') {
      const rateLimitType = action === 'create_forum_topic' ? 'topic' : 'post';
      const configField = action === 'create_forum_topic' ? 'max_topics_per_day' : 'max_posts_per_day';
      // Get target user trust level
      const { data: userStats } = await adminClient.from('forum_user_stats').select('trust_level').eq('user_id', target_user_id).maybeSingle();
      const trustLevel = Math.min(userStats?.trust_level ?? 0, 4);
      // Get limit from config
      const { data: configRow } = await adminClient.from('forum_reputation_config').select(configField).eq('trust_level', trustLevel).maybeSingle();
      const maxPerDay = configRow ? configRow[configField] : null;
      // null = unlimited; if set, enforce it
      if (maxPerDay !== null && maxPerDay !== undefined) {
        const windowStart = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
        const activityAction = action === 'create_forum_topic' ? 'topic_create' : 'post_create';
        const { count } = await adminClient.from('forum_activity_log').select('id', {
          count: 'exact',
          head: true
        }).eq('user_id', target_user_id).eq('action', activityAction).gte('created_at', windowStart);
        if ((count || 0) >= maxPerDay) {
          return new Response(JSON.stringify({
            error: rateLimitType === 'topic' ? `Лимит тем для этого пользователя исчерпан (${maxPerDay}/день, уровень ${trustLevel})` : `Лимит постов для этого пользователя исчерпан (${maxPerDay}/день, уровень ${trustLevel})`
          }), {
            status: 429,
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json'
            }
          });
        }
      }
    }
    // 6. Execute the action using service_role (bypasses RLS)
    console.log(`Impersonation action: ${action} by admin ${adminUserId} as user ${target_user_id}`);
    let result = {
      data: null,
      error: null
    };
    switch(action){
      // ---- Track interactions ----
      case 'like_track':
        {
          result = await adminClient.from('track_likes').insert({
            user_id: target_user_id,
            track_id: payload.track_id
          });
          break;
        }
      case 'unlike_track':
        {
          result = await adminClient.from('track_likes').delete().eq('user_id', target_user_id).eq('track_id', payload.track_id);
          break;
        }
      case 'delete_track':
        {
          // Fetch track file URLs before deleting
          const { data: trackData } = await adminClient.from('tracks').select('audio_url, cover_url, wav_url, master_audio_url, certificate_url').eq('id', payload.track_id).eq('user_id', target_user_id).maybeSingle();
          // Clean up storage files
          if (trackData) {
            const STORAGE_BASE = `${Deno.env.get('SUPABASE_URL')}/storage/v1/object/public/tracks/`;
            const paths = [];
            for (const url of [
              trackData.audio_url,
              trackData.cover_url,
              trackData.wav_url,
              trackData.master_audio_url,
              trackData.certificate_url
            ]){
              if (url && url.startsWith(STORAGE_BASE)) {
                paths.push(url.slice(STORAGE_BASE.length));
              }
            }
            if (paths.length > 0) {
              const { error: storageErr } = await adminClient.storage.from('tracks').remove(paths);
              if (storageErr) console.warn('[delete_track] Storage cleanup warning:', storageErr.message);
            }
          }
          // Remove associated likes then delete track
          await adminClient.from('track_likes').delete().eq('track_id', payload.track_id);
          result = await adminClient.from('tracks').delete().eq('id', payload.track_id).eq('user_id', target_user_id);
          break;
        }
      // ---- Follows ----
      case 'follow_user':
        {
          result = await adminClient.from('user_follows').insert({
            follower_id: target_user_id,
            following_id: payload.following_id
          });
          break;
        }
      case 'unfollow_user':
        {
          result = await adminClient.from('user_follows').delete().eq('follower_id', target_user_id).eq('following_id', payload.following_id);
          break;
        }
      // ---- Track updates ----
      case 'update_track':
        {
          const { track_id, ...updateFields } = payload;
          result = await adminClient.from('tracks').update(updateFields).eq('id', track_id).eq('user_id', target_user_id);
          break;
        }
      // ---- Comments ----
      case 'add_comment':
        {
          const insertData = {
            user_id: target_user_id,
            track_id: payload.track_id,
            content: payload.content
          };
          if (payload.parent_id) insertData.parent_id = payload.parent_id;
          if (payload.timestamp_seconds !== undefined) insertData.timestamp_seconds = payload.timestamp_seconds;
          if (payload.quote_text) insertData.quote_text = payload.quote_text;
          if (payload.quote_author) insertData.quote_author = payload.quote_author;
          result = await adminClient.from('track_comments').insert(insertData);
          break;
        }
      case 'delete_comment':
        {
          result = await adminClient.from('track_comments').delete().eq('id', payload.comment_id).eq('user_id', target_user_id);
          break;
        }
      case 'update_comment':
        {
          result = await adminClient.from('track_comments').update({
            content: payload.content,
            updated_at: new Date().toISOString()
          }).eq('id', payload.comment_id).eq('user_id', target_user_id);
          break;
        }
      case 'like_comment':
        {
          result = await adminClient.from('comment_likes').insert({
            user_id: target_user_id,
            comment_id: payload.comment_id
          });
          break;
        }
      case 'unlike_comment':
        {
          result = await adminClient.from('comment_likes').delete().eq('user_id', target_user_id).eq('comment_id', payload.comment_id);
          break;
        }
      case 'add_reaction':
        {
          result = await adminClient.from('comment_reactions').insert({
            user_id: target_user_id,
            comment_id: payload.comment_id,
            emoji: payload.emoji
          });
          break;
        }
      case 'remove_reaction':
        {
          result = await adminClient.from('comment_reactions').delete().eq('user_id', target_user_id).eq('comment_id', payload.comment_id).eq('emoji', payload.emoji);
          break;
        }
      case 'report_comment':
        {
          result = await adminClient.from('comment_reports').insert({
            reporter_id: target_user_id,
            comment_id: payload.comment_id,
            reason: payload.reason
          });
          break;
        }
      // ---- Profile ----
      case 'update_profile':
        {
          const { ...profileFields } = payload;
          delete profileFields.balance;
          delete profileFields.user_id;
          delete profileFields.email;
          result = await adminClient.from('profiles').update(profileFields).eq('user_id', target_user_id);
          break;
        }
      // ---- Playlists ----
      case 'create_playlist':
        {
          result = await adminClient.from('playlists').insert({
            user_id: target_user_id,
            title: payload.title,
            description: payload.description || null,
            is_public: payload.is_public ?? false
          }).select().single();
          break;
        }
      case 'update_playlist':
        {
          const { playlist_id: plId, ...plUpdates } = payload;
          result = await adminClient.from('playlists').update({
            ...plUpdates,
            updated_at: new Date().toISOString()
          }).eq('id', plId).eq('user_id', target_user_id);
          break;
        }
      case 'delete_playlist':
        {
          result = await adminClient.from('playlists').delete().eq('id', payload.playlist_id).eq('user_id', target_user_id);
          break;
        }
      case 'add_to_playlist':
        {
          // Get max position
          const { data: existing } = await adminClient.from('playlist_tracks').select('position').eq('playlist_id', payload.playlist_id).order('position', {
            ascending: false
          }).limit(1);
          const nextPosition = existing?.length ? existing[0].position + 1 : 0;
          result = await adminClient.from('playlist_tracks').insert({
            playlist_id: payload.playlist_id,
            track_id: payload.track_id,
            position: nextPosition
          });
          break;
        }
      case 'remove_from_playlist':
        {
          result = await adminClient.from('playlist_tracks').delete().eq('playlist_id', payload.playlist_id).eq('track_id', payload.track_id);
          break;
        }
      case 'like_playlist':
        {
          result = await adminClient.from('playlist_likes').insert({
            user_id: target_user_id,
            playlist_id: payload.playlist_id
          });
          break;
        }
      case 'unlike_playlist':
        {
          result = await adminClient.from('playlist_likes').delete().eq('user_id', target_user_id).eq('playlist_id', payload.playlist_id);
          break;
        }
      // ---- Messages ----
      case 'send_message':
        {
          result = await adminClient.from('messages').insert({
            conversation_id: payload.conversation_id,
            sender_id: target_user_id,
            content: payload.content,
            attachment_url: payload.attachment_url || null,
            attachment_type: payload.attachment_type || null
          }).select().single();
          break;
        }
      // ---- Forum ----
      case 'create_forum_topic':
        {
          // Generate slug from title
          const titleStr = String(payload.title);
          const slug = titleStr.toLowerCase().replace(/[^\p{L}\p{N}\s-]/gu, '').replace(/[\s]+/g, '-').substring(0, 80) + '-' + Date.now().toString(36);
          const excerpt = String(payload.content).substring(0, 200);
          result = await adminClient.from('forum_topics').insert({
            category_id: payload.category_id,
            user_id: target_user_id,
            title: payload.title,
            slug,
            content: payload.content,
            content_html: payload.content_html || null,
            excerpt,
            track_id: payload.track_id || null,
            is_hidden: false
          }).select().single();
          break;
        }
      case 'create_forum_post':
        {
          result = await adminClient.from('forum_posts').insert({
            topic_id: payload.topic_id,
            user_id: target_user_id,
            content: payload.content,
            content_html: payload.content_html || null,
            parent_id: payload.parent_id || null,
            reply_to_user_id: payload.reply_to_user_id || null,
            track_id: payload.track_id || null,
            is_hidden: false
          }).select().single();
          break;
        }
      default:
        return new Response(JSON.stringify({
          error: 'Неизвестное действие'
        }), {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
    }
    // 7. Log the action
    const logEntry = {
      admin_user_id: adminUserId,
      target_user_id: target_user_id,
      action_type: action,
      action_payload: payload,
      result_status: result.error ? 'error' : 'success',
      error_message: result.error ? JSON.stringify(result.error) : null
    };
    await adminClient.from('impersonation_action_logs').insert(logEntry);
    if (result.error) {
      console.error(`Impersonation action failed:`, result.error);
      return new Response(JSON.stringify({
        error: 'Ошибка выполнения действия',
        details: result.error
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    console.log(`Impersonation action success: ${action} for user ${target_user_id} by admin ${adminUserId}`);
    return new Response(JSON.stringify({
      success: true,
      action,
      target_user_id,
      target_username: targetProfile.username,
      data: result.data
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error('Impersonation error:', errorMessage);
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9hZG1pbi1pbXBlcnNvbmF0ZS9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ2F1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uJyxcbn07XG5cbi8vIFdoaXRlbGlzdCBvZiBhbGxvd2VkIGFjdGlvbnMg4oCUIG9ubHkgdGhlc2UgY2FuIGJlIHBlcmZvcm1lZCB2aWEgaW1wZXJzb25hdGlvblxuY29uc3QgQUxMT1dFRF9BQ1RJT05TOiBSZWNvcmQ8c3RyaW5nLCB7XG4gIHRhYmxlOiBzdHJpbmc7XG4gIG9wZXJhdGlvbjogJ2luc2VydCcgfCAndXBkYXRlJyB8ICdkZWxldGUnIHwgJ3Vwc2VydCcgfCAnY3VzdG9tJztcbiAgcmVxdWlyZWRGaWVsZHM6IHN0cmluZ1tdO1xuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xufT4gPSB7XG4gIC8vIFRyYWNrIGludGVyYWN0aW9uc1xuICBsaWtlX3RyYWNrOiB7IHRhYmxlOiAndHJhY2tfbGlrZXMnLCBvcGVyYXRpb246ICdpbnNlcnQnLCByZXF1aXJlZEZpZWxkczogWyd0cmFja19pZCddLCBkZXNjcmlwdGlvbjogJ0xpa2UgYSB0cmFjaycgfSxcbiAgdW5saWtlX3RyYWNrOiB7IHRhYmxlOiAndHJhY2tfbGlrZXMnLCBvcGVyYXRpb246ICdkZWxldGUnLCByZXF1aXJlZEZpZWxkczogWyd0cmFja19pZCddLCBkZXNjcmlwdGlvbjogJ1VubGlrZSBhIHRyYWNrJyB9LFxuICBkZWxldGVfdHJhY2s6IHsgdGFibGU6ICd0cmFja3MnLCBvcGVyYXRpb246ICdjdXN0b20nLCByZXF1aXJlZEZpZWxkczogWyd0cmFja19pZCddLCBkZXNjcmlwdGlvbjogJ0RlbGV0ZSBhIHRyYWNrJyB9LFxuICAvLyBVc2VyIGZvbGxvd3NcbiAgZm9sbG93X3VzZXI6IHsgdGFibGU6ICd1c2VyX2ZvbGxvd3MnLCBvcGVyYXRpb246ICdpbnNlcnQnLCByZXF1aXJlZEZpZWxkczogWydmb2xsb3dpbmdfaWQnXSwgZGVzY3JpcHRpb246ICdGb2xsb3cgYSB1c2VyJyB9LFxuICB1bmZvbGxvd191c2VyOiB7IHRhYmxlOiAndXNlcl9mb2xsb3dzJywgb3BlcmF0aW9uOiAnZGVsZXRlJywgcmVxdWlyZWRGaWVsZHM6IFsnZm9sbG93aW5nX2lkJ10sIGRlc2NyaXB0aW9uOiAnVW5mb2xsb3cgYSB1c2VyJyB9LFxuICAvLyBUcmFjayB1cGRhdGVzXG4gIHVwZGF0ZV90cmFjazogeyB0YWJsZTogJ3RyYWNrcycsIG9wZXJhdGlvbjogJ3VwZGF0ZScsIHJlcXVpcmVkRmllbGRzOiBbJ3RyYWNrX2lkJ10sIGRlc2NyaXB0aW9uOiAnVXBkYXRlIHRyYWNrIG1ldGFkYXRhJyB9LFxuICAvLyBDb21tZW50c1xuICBhZGRfY29tbWVudDogeyB0YWJsZTogJ3RyYWNrX2NvbW1lbnRzJywgb3BlcmF0aW9uOiAnaW5zZXJ0JywgcmVxdWlyZWRGaWVsZHM6IFsndHJhY2tfaWQnLCAnY29udGVudCddLCBkZXNjcmlwdGlvbjogJ0FkZCBhIGNvbW1lbnQgdG8gYSB0cmFjaycgfSxcbiAgZGVsZXRlX2NvbW1lbnQ6IHsgdGFibGU6ICd0cmFja19jb21tZW50cycsIG9wZXJhdGlvbjogJ2RlbGV0ZScsIHJlcXVpcmVkRmllbGRzOiBbJ2NvbW1lbnRfaWQnXSwgZGVzY3JpcHRpb246ICdEZWxldGUgYSBjb21tZW50JyB9LFxuICB1cGRhdGVfY29tbWVudDogeyB0YWJsZTogJ3RyYWNrX2NvbW1lbnRzJywgb3BlcmF0aW9uOiAndXBkYXRlJywgcmVxdWlyZWRGaWVsZHM6IFsnY29tbWVudF9pZCcsICdjb250ZW50J10sIGRlc2NyaXB0aW9uOiAnRWRpdCBhIGNvbW1lbnQnIH0sXG4gIGxpa2VfY29tbWVudDogeyB0YWJsZTogJ2NvbW1lbnRfbGlrZXMnLCBvcGVyYXRpb246ICdpbnNlcnQnLCByZXF1aXJlZEZpZWxkczogWydjb21tZW50X2lkJ10sIGRlc2NyaXB0aW9uOiAnTGlrZSBhIGNvbW1lbnQnIH0sXG4gIHVubGlrZV9jb21tZW50OiB7IHRhYmxlOiAnY29tbWVudF9saWtlcycsIG9wZXJhdGlvbjogJ2RlbGV0ZScsIHJlcXVpcmVkRmllbGRzOiBbJ2NvbW1lbnRfaWQnXSwgZGVzY3JpcHRpb246ICdVbmxpa2UgYSBjb21tZW50JyB9LFxuICBhZGRfcmVhY3Rpb246IHsgdGFibGU6ICdjb21tZW50X3JlYWN0aW9ucycsIG9wZXJhdGlvbjogJ2luc2VydCcsIHJlcXVpcmVkRmllbGRzOiBbJ2NvbW1lbnRfaWQnLCAnZW1vamknXSwgZGVzY3JpcHRpb246ICdBZGQgcmVhY3Rpb24gdG8gYSBjb21tZW50JyB9LFxuICByZW1vdmVfcmVhY3Rpb246IHsgdGFibGU6ICdjb21tZW50X3JlYWN0aW9ucycsIG9wZXJhdGlvbjogJ2RlbGV0ZScsIHJlcXVpcmVkRmllbGRzOiBbJ2NvbW1lbnRfaWQnLCAnZW1vamknXSwgZGVzY3JpcHRpb246ICdSZW1vdmUgcmVhY3Rpb24gZnJvbSBhIGNvbW1lbnQnIH0sXG4gIHJlcG9ydF9jb21tZW50OiB7IHRhYmxlOiAnY29tbWVudF9yZXBvcnRzJywgb3BlcmF0aW9uOiAnaW5zZXJ0JywgcmVxdWlyZWRGaWVsZHM6IFsnY29tbWVudF9pZCcsICdyZWFzb24nXSwgZGVzY3JpcHRpb246ICdSZXBvcnQgYSBjb21tZW50JyB9LFxuICAvLyBQcm9maWxlIHVwZGF0ZXNcbiAgdXBkYXRlX3Byb2ZpbGU6IHsgdGFibGU6ICdwcm9maWxlcycsIG9wZXJhdGlvbjogJ3VwZGF0ZScsIHJlcXVpcmVkRmllbGRzOiBbXSwgZGVzY3JpcHRpb246ICdVcGRhdGUgdXNlciBwcm9maWxlJyB9LFxuICAvLyBQbGF5bGlzdHNcbiAgY3JlYXRlX3BsYXlsaXN0OiB7IHRhYmxlOiAncGxheWxpc3RzJywgb3BlcmF0aW9uOiAnaW5zZXJ0JywgcmVxdWlyZWRGaWVsZHM6IFsndGl0bGUnXSwgZGVzY3JpcHRpb246ICdDcmVhdGUgYSBwbGF5bGlzdCcgfSxcbiAgdXBkYXRlX3BsYXlsaXN0OiB7IHRhYmxlOiAncGxheWxpc3RzJywgb3BlcmF0aW9uOiAndXBkYXRlJywgcmVxdWlyZWRGaWVsZHM6IFsncGxheWxpc3RfaWQnXSwgZGVzY3JpcHRpb246ICdVcGRhdGUgYSBwbGF5bGlzdCcgfSxcbiAgZGVsZXRlX3BsYXlsaXN0OiB7IHRhYmxlOiAncGxheWxpc3RzJywgb3BlcmF0aW9uOiAnZGVsZXRlJywgcmVxdWlyZWRGaWVsZHM6IFsncGxheWxpc3RfaWQnXSwgZGVzY3JpcHRpb246ICdEZWxldGUgYSBwbGF5bGlzdCcgfSxcbiAgYWRkX3RvX3BsYXlsaXN0OiB7IHRhYmxlOiAncGxheWxpc3RfdHJhY2tzJywgb3BlcmF0aW9uOiAnaW5zZXJ0JywgcmVxdWlyZWRGaWVsZHM6IFsncGxheWxpc3RfaWQnLCAndHJhY2tfaWQnXSwgZGVzY3JpcHRpb246ICdBZGQgdHJhY2sgdG8gYSBwbGF5bGlzdCcgfSxcbiAgcmVtb3ZlX2Zyb21fcGxheWxpc3Q6IHsgdGFibGU6ICdwbGF5bGlzdF90cmFja3MnLCBvcGVyYXRpb246ICdkZWxldGUnLCByZXF1aXJlZEZpZWxkczogWydwbGF5bGlzdF9pZCcsICd0cmFja19pZCddLCBkZXNjcmlwdGlvbjogJ1JlbW92ZSB0cmFjayBmcm9tIGEgcGxheWxpc3QnIH0sXG4gIGxpa2VfcGxheWxpc3Q6IHsgdGFibGU6ICdwbGF5bGlzdF9saWtlcycsIG9wZXJhdGlvbjogJ2luc2VydCcsIHJlcXVpcmVkRmllbGRzOiBbJ3BsYXlsaXN0X2lkJ10sIGRlc2NyaXB0aW9uOiAnTGlrZSBhIHBsYXlsaXN0JyB9LFxuICB1bmxpa2VfcGxheWxpc3Q6IHsgdGFibGU6ICdwbGF5bGlzdF9saWtlcycsIG9wZXJhdGlvbjogJ2RlbGV0ZScsIHJlcXVpcmVkRmllbGRzOiBbJ3BsYXlsaXN0X2lkJ10sIGRlc2NyaXB0aW9uOiAnVW5saWtlIGEgcGxheWxpc3QnIH0sXG4gIC8vIE1lc3NhZ2VzXG4gIHNlbmRfbWVzc2FnZTogeyB0YWJsZTogJ21lc3NhZ2VzJywgb3BlcmF0aW9uOiAnaW5zZXJ0JywgcmVxdWlyZWRGaWVsZHM6IFsnY29udmVyc2F0aW9uX2lkJywgJ2NvbnRlbnQnXSwgZGVzY3JpcHRpb246ICdTZW5kIGEgbWVzc2FnZScgfSxcbiAgLy8gRm9ydW1cbiAgY3JlYXRlX2ZvcnVtX3RvcGljOiB7IHRhYmxlOiAnZm9ydW1fdG9waWNzJywgb3BlcmF0aW9uOiAnY3VzdG9tJywgcmVxdWlyZWRGaWVsZHM6IFsnY2F0ZWdvcnlfaWQnLCAndGl0bGUnLCAnY29udGVudCddLCBkZXNjcmlwdGlvbjogJ0NyZWF0ZSBhIGZvcnVtIHRvcGljJyB9LFxuICBjcmVhdGVfZm9ydW1fcG9zdDogeyB0YWJsZTogJ2ZvcnVtX3Bvc3RzJywgb3BlcmF0aW9uOiAnY3VzdG9tJywgcmVxdWlyZWRGaWVsZHM6IFsndG9waWNfaWQnLCAnY29udGVudCddLCBkZXNjcmlwdGlvbjogJ0NyZWF0ZSBhIGZvcnVtIHBvc3QnIH0sXG59O1xuXG4vLyBTSEEtMjU2IGhhc2ggZnVuY3Rpb25cbmFzeW5jIGZ1bmN0aW9uIHNoYTI1NihtZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBtc2dCdWZmZXIgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUobWVzc2FnZSk7XG4gIGNvbnN0IGhhc2hCdWZmZXIgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIG1zZ0J1ZmZlcik7XG4gIGNvbnN0IGhhc2hBcnJheSA9IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoaGFzaEJ1ZmZlcikpO1xuICByZXR1cm4gaGFzaEFycmF5Lm1hcChiID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpLmpvaW4oJycpO1xufVxuXG5EZW5vLnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09ICdPUFRJT05TJykge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoJ29rJywgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9VUkwnKSE7XG4gIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldCgnU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWScpITtcbiAgY29uc3Qgc3VwYWJhc2VBbm9uS2V5ID0gRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9BTk9OX0tFWScpITtcblxuICB0cnkge1xuICAgIC8vIDEuIFZlcmlmeSBKV1RcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KCdBdXRob3JpemF0aW9uJyk7XG4gICAgaWYgKCFhdXRoSGVhZGVyPy5zdGFydHNXaXRoKCdCZWFyZXIgJykpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICdVbmF1dGhvcml6ZWQnIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZSgnQmVhcmVyICcsICcnKTtcbiAgICBcbiAgICAvLyBEZWNvZGUgSldUIHRvIGdldCB1c2VyIElEICh3b3JrcyB3aXRoIGJvdGggU3VwYWJhc2UgYW5kIGN1c3RvbSBKV1QpXG4gICAgbGV0IGFkbWluVXNlcklkOiBzdHJpbmc7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHBheWxvYWRQYXJ0ID0gdG9rZW4uc3BsaXQoJy4nKVsxXTtcbiAgICAgIGNvbnN0IGRlY29kZWQgPSBKU09OLnBhcnNlKGF0b2IocGF5bG9hZFBhcnQpKTtcbiAgICAgIGFkbWluVXNlcklkID0gZGVjb2RlZC5zdWI7XG4gICAgICBpZiAoIWFkbWluVXNlcklkKSB0aHJvdyBuZXcgRXJyb3IoJ05vIHN1YiBpbiB0b2tlbicpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0pXVCBkZWNvZGUgZXJyb3I6JywgZSk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAnSW52YWxpZCB0b2tlbicgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIDIuIENoZWNrIHN1cGVyX2FkbWluIHJvbGUgT05MWVxuICAgIGNvbnN0IGFkbWluQ2xpZW50ID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgY29uc3QgeyBkYXRhOiB1c2VyUm9sZSB9ID0gYXdhaXQgYWRtaW5DbGllbnRcbiAgICAgIC5mcm9tKCd1c2VyX3JvbGVzJylcbiAgICAgIC5zZWxlY3QoJ3JvbGUnKVxuICAgICAgLmVxKCd1c2VyX2lkJywgYWRtaW5Vc2VySWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoIXVzZXJSb2xlIHx8ICFbJ3N1cGVyX2FkbWluJywgJ2FkbWluJ10uaW5jbHVkZXModXNlclJvbGUucm9sZSkpIHtcbiAgICAgIGNvbnNvbGUud2FybihgSW1wZXJzb25hdGlvbiBkZW5pZWQgZm9yIHVzZXIgJHthZG1pblVzZXJJZH0sIHJvbGU6ICR7dXNlclJvbGU/LnJvbGV9YCk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAn0JTQvtGB0YLRg9C/INC30LDQv9GA0LXRidGR0L0uINCi0L7Qu9GM0LrQviDQtNC70Y8g0LDQtNC80LjQvdC40YHRgtGA0LDRgtC+0YDQvtCyLicgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDMsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIDMuIFBhcnNlIHJlcXVlc3QgYm9keVxuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnN0IHsgcGluLCB0YXJnZXRfdXNlcl9pZCwgYWN0aW9uLCBwYXlsb2FkIH0gPSBib2R5O1xuXG4gICAgLy8gNC4gVmVyaWZ5IFBJTlxuICAgIGlmICghcGluIHx8IHR5cGVvZiBwaW4gIT09ICdzdHJpbmcnIHx8IHBpbi5sZW5ndGggIT09IDYpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICfQotGA0LXQsdGD0LXRgtGB0Y8gNi3Qt9C90LDRh9C90YvQuSBQSU4t0LrQvtC0JyB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgeyBkYXRhOiBwaW5TZXR0aW5nIH0gPSBhd2FpdCBhZG1pbkNsaWVudFxuICAgICAgLmZyb20oJ3NldHRpbmdzJylcbiAgICAgIC5zZWxlY3QoJ3ZhbHVlJylcbiAgICAgIC5lcSgna2V5JywgJ2JhY2t1cF9waW5faGFzaCcpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoIXBpblNldHRpbmc/LnZhbHVlKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiAnUElOLdC60L7QtCDQvdC1INC90LDRgdGC0YDQvtC10L0nIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBwaW5IYXNoID0gYXdhaXQgc2hhMjU2KHBpbik7XG4gICAgaWYgKHBpbkhhc2ggIT09IHBpblNldHRpbmcudmFsdWUpIHtcbiAgICAgIGNvbnNvbGUud2FybihgSW52YWxpZCBQSU4gYXR0ZW1wdCBieSBzdXBlcl9hZG1pbjogJHthZG1pblVzZXJJZH1gKTtcbiAgICAgIFxuICAgICAgYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgnaW1wZXJzb25hdGlvbl9hY3Rpb25fbG9ncycpLmluc2VydCh7XG4gICAgICAgIGFkbWluX3VzZXJfaWQ6IGFkbWluVXNlcklkLFxuICAgICAgICB0YXJnZXRfdXNlcl9pZDogdGFyZ2V0X3VzZXJfaWQgfHwgJzAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMCcsXG4gICAgICAgIGFjdGlvbl90eXBlOiAncGluX2ZhaWxlZCcsXG4gICAgICAgIGFjdGlvbl9wYXlsb2FkOiB7IGFjdGlvbiB9LFxuICAgICAgICByZXN1bHRfc3RhdHVzOiAnZXJyb3InLFxuICAgICAgICBlcnJvcl9tZXNzYWdlOiAnSW52YWxpZCBQSU4nLFxuICAgICAgfSk7XG5cbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICfQndC10LLQtdGA0L3Ri9C5IFBJTi3QutC+0LQnIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyA1LiBWYWxpZGF0ZSBhY3Rpb25cbiAgICBpZiAoIWFjdGlvbiB8fCAhQUxMT1dFRF9BQ1RJT05TW2FjdGlvbl0pIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGDQlNC10LnRgdGC0LLQuNC1ICcke2FjdGlvbn0nINC90LUg0YDQsNC30YDQtdGI0LXQvdC+YCwgYWxsb3dlZDogT2JqZWN0LmtleXMoQUxMT1dFRF9BQ1RJT05TKSB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKCF0YXJnZXRfdXNlcl9pZCkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ3RhcmdldF91c2VyX2lkINC+0LHRj9C30LDRgtC10LvQtdC9JyB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gVmVyaWZ5IHRhcmdldCB1c2VyIGV4aXN0c1xuICAgIGNvbnN0IHsgZGF0YTogdGFyZ2V0UHJvZmlsZSB9ID0gYXdhaXQgYWRtaW5DbGllbnRcbiAgICAgIC5mcm9tKCdwcm9maWxlcycpXG4gICAgICAuc2VsZWN0KCd1c2VyX2lkLCB1c2VybmFtZScpXG4gICAgICAuZXEoJ3VzZXJfaWQnLCB0YXJnZXRfdXNlcl9pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICghdGFyZ2V0UHJvZmlsZSkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ9Cm0LXQu9C10LLQvtC5INC/0L7Qu9GM0LfQvtCy0LDRgtC10LvRjCDQvdC1INC90LDQudC00LXQvScgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDQsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGFjdGlvbkNvbmZpZyA9IEFMTE9XRURfQUNUSU9OU1thY3Rpb25dO1xuXG4gICAgLy8gVmFsaWRhdGUgcmVxdWlyZWQgZmllbGRzXG4gICAgZm9yIChjb25zdCBmaWVsZCBvZiBhY3Rpb25Db25maWcucmVxdWlyZWRGaWVsZHMpIHtcbiAgICAgIGlmICghcGF5bG9hZCB8fCBwYXlsb2FkW2ZpZWxkXSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogYNCf0L7Qu9C1ICcke2ZpZWxkfScg0L7QsdGP0LfQsNGC0LXQu9GM0L3QviDQtNC70Y8g0LTQtdC50YHRgtCy0LjRjyAnJHthY3Rpb259J2AgfSksXG4gICAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyA1Yi4gRW5mb3JjZSBmb3J1bSByYXRlIGxpbWl0cyBmb3IgdGFyZ2V0IHVzZXJcbiAgICBpZiAoYWN0aW9uID09PSAnY3JlYXRlX2ZvcnVtX3RvcGljJyB8fCBhY3Rpb24gPT09ICdjcmVhdGVfZm9ydW1fcG9zdCcpIHtcbiAgICAgIGNvbnN0IHJhdGVMaW1pdFR5cGUgPSBhY3Rpb24gPT09ICdjcmVhdGVfZm9ydW1fdG9waWMnID8gJ3RvcGljJyA6ICdwb3N0JztcbiAgICAgIGNvbnN0IGNvbmZpZ0ZpZWxkID0gYWN0aW9uID09PSAnY3JlYXRlX2ZvcnVtX3RvcGljJyA/ICdtYXhfdG9waWNzX3Blcl9kYXknIDogJ21heF9wb3N0c19wZXJfZGF5JztcblxuICAgICAgLy8gR2V0IHRhcmdldCB1c2VyIHRydXN0IGxldmVsXG4gICAgICBjb25zdCB7IGRhdGE6IHVzZXJTdGF0cyB9ID0gYXdhaXQgYWRtaW5DbGllbnRcbiAgICAgICAgLmZyb20oJ2ZvcnVtX3VzZXJfc3RhdHMnKVxuICAgICAgICAuc2VsZWN0KCd0cnVzdF9sZXZlbCcpXG4gICAgICAgIC5lcSgndXNlcl9pZCcsIHRhcmdldF91c2VyX2lkKVxuICAgICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgICAgY29uc3QgdHJ1c3RMZXZlbCA9IE1hdGgubWluKHVzZXJTdGF0cz8udHJ1c3RfbGV2ZWwgPz8gMCwgNCk7XG5cbiAgICAgIC8vIEdldCBsaW1pdCBmcm9tIGNvbmZpZ1xuICAgICAgY29uc3QgeyBkYXRhOiBjb25maWdSb3cgfSA9IGF3YWl0IGFkbWluQ2xpZW50XG4gICAgICAgIC5mcm9tKCdmb3J1bV9yZXB1dGF0aW9uX2NvbmZpZycpXG4gICAgICAgIC5zZWxlY3QoY29uZmlnRmllbGQpXG4gICAgICAgIC5lcSgndHJ1c3RfbGV2ZWwnLCB0cnVzdExldmVsKVxuICAgICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgICAgY29uc3QgbWF4UGVyRGF5ID0gY29uZmlnUm93ID8gKGNvbmZpZ1JvdyBhcyBSZWNvcmQ8c3RyaW5nLCBudW1iZXIgfCBudWxsPilbY29uZmlnRmllbGRdIDogbnVsbDtcblxuICAgICAgLy8gbnVsbCA9IHVubGltaXRlZDsgaWYgc2V0LCBlbmZvcmNlIGl0XG4gICAgICBpZiAobWF4UGVyRGF5ICE9PSBudWxsICYmIG1heFBlckRheSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGNvbnN0IHdpbmRvd1N0YXJ0ID0gbmV3IERhdGUoRGF0ZS5ub3coKSAtIDI0ICogNjAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKCk7XG4gICAgICAgIGNvbnN0IGFjdGl2aXR5QWN0aW9uID0gYWN0aW9uID09PSAnY3JlYXRlX2ZvcnVtX3RvcGljJyA/ICd0b3BpY19jcmVhdGUnIDogJ3Bvc3RfY3JlYXRlJztcblxuICAgICAgICBjb25zdCB7IGNvdW50IH0gPSBhd2FpdCBhZG1pbkNsaWVudFxuICAgICAgICAgIC5mcm9tKCdmb3J1bV9hY3Rpdml0eV9sb2cnKVxuICAgICAgICAgIC5zZWxlY3QoJ2lkJywgeyBjb3VudDogJ2V4YWN0JywgaGVhZDogdHJ1ZSB9KVxuICAgICAgICAgIC5lcSgndXNlcl9pZCcsIHRhcmdldF91c2VyX2lkKVxuICAgICAgICAgIC5lcSgnYWN0aW9uJywgYWN0aXZpdHlBY3Rpb24pXG4gICAgICAgICAgLmd0ZSgnY3JlYXRlZF9hdCcsIHdpbmRvd1N0YXJ0KTtcblxuICAgICAgICBpZiAoKGNvdW50IHx8IDApID49IG1heFBlckRheSkge1xuICAgICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgIGVycm9yOiByYXRlTGltaXRUeXBlID09PSAndG9waWMnXG4gICAgICAgICAgICAgICAgPyBg0JvQuNC80LjRgiDRgtC10Lwg0LTQu9GPINGN0YLQvtCz0L4g0L/QvtC70YzQt9C+0LLQsNGC0LXQu9GPINC40YHRh9C10YDQv9Cw0L0gKCR7bWF4UGVyRGF5fS/QtNC10L3RjCwg0YPRgNC+0LLQtdC90YwgJHt0cnVzdExldmVsfSlgXG4gICAgICAgICAgICAgICAgOiBg0JvQuNC80LjRgiDQv9C+0YHRgtC+0LIg0LTQu9GPINGN0YLQvtCz0L4g0L/QvtC70YzQt9C+0LLQsNGC0LXQu9GPINC40YHRh9C10YDQv9Cw0L0gKCR7bWF4UGVyRGF5fS/QtNC10L3RjCwg0YPRgNC+0LLQtdC90YwgJHt0cnVzdExldmVsfSlgLFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB7IHN0YXR1czogNDI5LCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyA2LiBFeGVjdXRlIHRoZSBhY3Rpb24gdXNpbmcgc2VydmljZV9yb2xlIChieXBhc3NlcyBSTFMpXG4gICAgY29uc29sZS5sb2coYEltcGVyc29uYXRpb24gYWN0aW9uOiAke2FjdGlvbn0gYnkgYWRtaW4gJHthZG1pblVzZXJJZH0gYXMgdXNlciAke3RhcmdldF91c2VyX2lkfWApO1xuXG4gICAgbGV0IHJlc3VsdDogeyBkYXRhOiB1bmtub3duOyBlcnJvcjogdW5rbm93biB9ID0geyBkYXRhOiBudWxsLCBlcnJvcjogbnVsbCB9O1xuXG4gICAgc3dpdGNoIChhY3Rpb24pIHtcbiAgICAgIC8vIC0tLS0gVHJhY2sgaW50ZXJhY3Rpb25zIC0tLS1cbiAgICAgIGNhc2UgJ2xpa2VfdHJhY2snOiB7XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGFkbWluQ2xpZW50LmZyb20oJ3RyYWNrX2xpa2VzJykuaW5zZXJ0KHtcbiAgICAgICAgICB1c2VyX2lkOiB0YXJnZXRfdXNlcl9pZCxcbiAgICAgICAgICB0cmFja19pZDogcGF5bG9hZC50cmFja19pZCxcbiAgICAgICAgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSAndW5saWtlX3RyYWNrJzoge1xuICAgICAgICByZXN1bHQgPSBhd2FpdCBhZG1pbkNsaWVudC5mcm9tKCd0cmFja19saWtlcycpXG4gICAgICAgICAgLmRlbGV0ZSgpXG4gICAgICAgICAgLmVxKCd1c2VyX2lkJywgdGFyZ2V0X3VzZXJfaWQpXG4gICAgICAgICAgLmVxKCd0cmFja19pZCcsIHBheWxvYWQudHJhY2tfaWQpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgJ2RlbGV0ZV90cmFjayc6IHtcbiAgICAgICAgLy8gRmV0Y2ggdHJhY2sgZmlsZSBVUkxzIGJlZm9yZSBkZWxldGluZ1xuICAgICAgICBjb25zdCB7IGRhdGE6IHRyYWNrRGF0YSB9ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgndHJhY2tzJylcbiAgICAgICAgICAuc2VsZWN0KCdhdWRpb191cmwsIGNvdmVyX3VybCwgd2F2X3VybCwgbWFzdGVyX2F1ZGlvX3VybCwgY2VydGlmaWNhdGVfdXJsJylcbiAgICAgICAgICAuZXEoJ2lkJywgcGF5bG9hZC50cmFja19pZClcbiAgICAgICAgICAuZXEoJ3VzZXJfaWQnLCB0YXJnZXRfdXNlcl9pZClcbiAgICAgICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgICAgICAvLyBDbGVhbiB1cCBzdG9yYWdlIGZpbGVzXG4gICAgICAgIGlmICh0cmFja0RhdGEpIHtcbiAgICAgICAgICBjb25zdCBTVE9SQUdFX0JBU0UgPSBgJHtEZW5vLmVudi5nZXQoJ1NVUEFCQVNFX1VSTCcpfS9zdG9yYWdlL3YxL29iamVjdC9wdWJsaWMvdHJhY2tzL2A7XG4gICAgICAgICAgY29uc3QgcGF0aHM6IHN0cmluZ1tdID0gW107XG4gICAgICAgICAgZm9yIChjb25zdCB1cmwgb2YgW3RyYWNrRGF0YS5hdWRpb191cmwsIHRyYWNrRGF0YS5jb3Zlcl91cmwsIHRyYWNrRGF0YS53YXZfdXJsLCB0cmFja0RhdGEubWFzdGVyX2F1ZGlvX3VybCwgdHJhY2tEYXRhLmNlcnRpZmljYXRlX3VybF0pIHtcbiAgICAgICAgICAgIGlmICh1cmwgJiYgdXJsLnN0YXJ0c1dpdGgoU1RPUkFHRV9CQVNFKSkge1xuICAgICAgICAgICAgICBwYXRocy5wdXNoKHVybC5zbGljZShTVE9SQUdFX0JBU0UubGVuZ3RoKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChwYXRocy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zdCB7IGVycm9yOiBzdG9yYWdlRXJyIH0gPSBhd2FpdCBhZG1pbkNsaWVudC5zdG9yYWdlLmZyb20oJ3RyYWNrcycpLnJlbW92ZShwYXRocyk7XG4gICAgICAgICAgICBpZiAoc3RvcmFnZUVycikgY29uc29sZS53YXJuKCdbZGVsZXRlX3RyYWNrXSBTdG9yYWdlIGNsZWFudXAgd2FybmluZzonLCBzdG9yYWdlRXJyLm1lc3NhZ2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFJlbW92ZSBhc3NvY2lhdGVkIGxpa2VzIHRoZW4gZGVsZXRlIHRyYWNrXG4gICAgICAgIGF3YWl0IGFkbWluQ2xpZW50LmZyb20oJ3RyYWNrX2xpa2VzJykuZGVsZXRlKCkuZXEoJ3RyYWNrX2lkJywgcGF5bG9hZC50cmFja19pZCk7XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGFkbWluQ2xpZW50LmZyb20oJ3RyYWNrcycpXG4gICAgICAgICAgLmRlbGV0ZSgpXG4gICAgICAgICAgLmVxKCdpZCcsIHBheWxvYWQudHJhY2tfaWQpXG4gICAgICAgICAgLmVxKCd1c2VyX2lkJywgdGFyZ2V0X3VzZXJfaWQpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLSBGb2xsb3dzIC0tLS1cbiAgICAgIGNhc2UgJ2ZvbGxvd191c2VyJzoge1xuICAgICAgICByZXN1bHQgPSBhd2FpdCBhZG1pbkNsaWVudC5mcm9tKCd1c2VyX2ZvbGxvd3MnKS5pbnNlcnQoe1xuICAgICAgICAgIGZvbGxvd2VyX2lkOiB0YXJnZXRfdXNlcl9pZCxcbiAgICAgICAgICBmb2xsb3dpbmdfaWQ6IHBheWxvYWQuZm9sbG93aW5nX2lkLFxuICAgICAgICB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICd1bmZvbGxvd191c2VyJzoge1xuICAgICAgICByZXN1bHQgPSBhd2FpdCBhZG1pbkNsaWVudC5mcm9tKCd1c2VyX2ZvbGxvd3MnKVxuICAgICAgICAgIC5kZWxldGUoKVxuICAgICAgICAgIC5lcSgnZm9sbG93ZXJfaWQnLCB0YXJnZXRfdXNlcl9pZClcbiAgICAgICAgICAuZXEoJ2ZvbGxvd2luZ19pZCcsIHBheWxvYWQuZm9sbG93aW5nX2lkKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG5cbiAgICAgIC8vIC0tLS0gVHJhY2sgdXBkYXRlcyAtLS0tXG4gICAgICBjYXNlICd1cGRhdGVfdHJhY2snOiB7XG4gICAgICAgIGNvbnN0IHsgdHJhY2tfaWQsIC4uLnVwZGF0ZUZpZWxkcyB9ID0gcGF5bG9hZDtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgndHJhY2tzJylcbiAgICAgICAgICAudXBkYXRlKHVwZGF0ZUZpZWxkcylcbiAgICAgICAgICAuZXEoJ2lkJywgdHJhY2tfaWQpXG4gICAgICAgICAgLmVxKCd1c2VyX2lkJywgdGFyZ2V0X3VzZXJfaWQpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLSBDb21tZW50cyAtLS0tXG4gICAgICBjYXNlICdhZGRfY29tbWVudCc6IHtcbiAgICAgICAgY29uc3QgaW5zZXJ0RGF0YTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICAgICAgdXNlcl9pZDogdGFyZ2V0X3VzZXJfaWQsXG4gICAgICAgICAgdHJhY2tfaWQ6IHBheWxvYWQudHJhY2tfaWQsXG4gICAgICAgICAgY29udGVudDogcGF5bG9hZC5jb250ZW50LFxuICAgICAgICB9O1xuICAgICAgICBpZiAocGF5bG9hZC5wYXJlbnRfaWQpIGluc2VydERhdGEucGFyZW50X2lkID0gcGF5bG9hZC5wYXJlbnRfaWQ7XG4gICAgICAgIGlmIChwYXlsb2FkLnRpbWVzdGFtcF9zZWNvbmRzICE9PSB1bmRlZmluZWQpIGluc2VydERhdGEudGltZXN0YW1wX3NlY29uZHMgPSBwYXlsb2FkLnRpbWVzdGFtcF9zZWNvbmRzO1xuICAgICAgICBpZiAocGF5bG9hZC5xdW90ZV90ZXh0KSBpbnNlcnREYXRhLnF1b3RlX3RleHQgPSBwYXlsb2FkLnF1b3RlX3RleHQ7XG4gICAgICAgIGlmIChwYXlsb2FkLnF1b3RlX2F1dGhvcikgaW5zZXJ0RGF0YS5xdW90ZV9hdXRob3IgPSBwYXlsb2FkLnF1b3RlX2F1dGhvcjtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgndHJhY2tfY29tbWVudHMnKS5pbnNlcnQoaW5zZXJ0RGF0YSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSAnZGVsZXRlX2NvbW1lbnQnOiB7XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGFkbWluQ2xpZW50LmZyb20oJ3RyYWNrX2NvbW1lbnRzJylcbiAgICAgICAgICAuZGVsZXRlKClcbiAgICAgICAgICAuZXEoJ2lkJywgcGF5bG9hZC5jb21tZW50X2lkKVxuICAgICAgICAgIC5lcSgndXNlcl9pZCcsIHRhcmdldF91c2VyX2lkKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICd1cGRhdGVfY29tbWVudCc6IHtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgndHJhY2tfY29tbWVudHMnKVxuICAgICAgICAgIC51cGRhdGUoeyBjb250ZW50OiBwYXlsb2FkLmNvbnRlbnQsIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9KVxuICAgICAgICAgIC5lcSgnaWQnLCBwYXlsb2FkLmNvbW1lbnRfaWQpXG4gICAgICAgICAgLmVxKCd1c2VyX2lkJywgdGFyZ2V0X3VzZXJfaWQpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgJ2xpa2VfY29tbWVudCc6IHtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgnY29tbWVudF9saWtlcycpLmluc2VydCh7XG4gICAgICAgICAgdXNlcl9pZDogdGFyZ2V0X3VzZXJfaWQsXG4gICAgICAgICAgY29tbWVudF9pZDogcGF5bG9hZC5jb21tZW50X2lkLFxuICAgICAgICB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICd1bmxpa2VfY29tbWVudCc6IHtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgnY29tbWVudF9saWtlcycpXG4gICAgICAgICAgLmRlbGV0ZSgpXG4gICAgICAgICAgLmVxKCd1c2VyX2lkJywgdGFyZ2V0X3VzZXJfaWQpXG4gICAgICAgICAgLmVxKCdjb21tZW50X2lkJywgcGF5bG9hZC5jb21tZW50X2lkKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICdhZGRfcmVhY3Rpb24nOiB7XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGFkbWluQ2xpZW50LmZyb20oJ2NvbW1lbnRfcmVhY3Rpb25zJykuaW5zZXJ0KHtcbiAgICAgICAgICB1c2VyX2lkOiB0YXJnZXRfdXNlcl9pZCxcbiAgICAgICAgICBjb21tZW50X2lkOiBwYXlsb2FkLmNvbW1lbnRfaWQsXG4gICAgICAgICAgZW1vamk6IHBheWxvYWQuZW1vamksXG4gICAgICAgIH0pO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgJ3JlbW92ZV9yZWFjdGlvbic6IHtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgnY29tbWVudF9yZWFjdGlvbnMnKVxuICAgICAgICAgIC5kZWxldGUoKVxuICAgICAgICAgIC5lcSgndXNlcl9pZCcsIHRhcmdldF91c2VyX2lkKVxuICAgICAgICAgIC5lcSgnY29tbWVudF9pZCcsIHBheWxvYWQuY29tbWVudF9pZClcbiAgICAgICAgICAuZXEoJ2Vtb2ppJywgcGF5bG9hZC5lbW9qaSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSAncmVwb3J0X2NvbW1lbnQnOiB7XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGFkbWluQ2xpZW50LmZyb20oJ2NvbW1lbnRfcmVwb3J0cycpLmluc2VydCh7XG4gICAgICAgICAgcmVwb3J0ZXJfaWQ6IHRhcmdldF91c2VyX2lkLFxuICAgICAgICAgIGNvbW1lbnRfaWQ6IHBheWxvYWQuY29tbWVudF9pZCxcbiAgICAgICAgICByZWFzb246IHBheWxvYWQucmVhc29uLFxuICAgICAgICB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG5cbiAgICAgIC8vIC0tLS0gUHJvZmlsZSAtLS0tXG4gICAgICBjYXNlICd1cGRhdGVfcHJvZmlsZSc6IHtcbiAgICAgICAgY29uc3QgeyAuLi5wcm9maWxlRmllbGRzIH0gPSBwYXlsb2FkO1xuICAgICAgICBkZWxldGUgcHJvZmlsZUZpZWxkcy5iYWxhbmNlO1xuICAgICAgICBkZWxldGUgcHJvZmlsZUZpZWxkcy51c2VyX2lkO1xuICAgICAgICBkZWxldGUgcHJvZmlsZUZpZWxkcy5lbWFpbDtcbiAgICAgICAgXG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGFkbWluQ2xpZW50LmZyb20oJ3Byb2ZpbGVzJylcbiAgICAgICAgICAudXBkYXRlKHByb2ZpbGVGaWVsZHMpXG4gICAgICAgICAgLmVxKCd1c2VyX2lkJywgdGFyZ2V0X3VzZXJfaWQpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLSBQbGF5bGlzdHMgLS0tLVxuICAgICAgY2FzZSAnY3JlYXRlX3BsYXlsaXN0Jzoge1xuICAgICAgICByZXN1bHQgPSBhd2FpdCBhZG1pbkNsaWVudC5mcm9tKCdwbGF5bGlzdHMnKS5pbnNlcnQoe1xuICAgICAgICAgIHVzZXJfaWQ6IHRhcmdldF91c2VyX2lkLFxuICAgICAgICAgIHRpdGxlOiBwYXlsb2FkLnRpdGxlLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBwYXlsb2FkLmRlc2NyaXB0aW9uIHx8IG51bGwsXG4gICAgICAgICAgaXNfcHVibGljOiBwYXlsb2FkLmlzX3B1YmxpYyA/PyBmYWxzZSxcbiAgICAgICAgfSkuc2VsZWN0KCkuc2luZ2xlKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSAndXBkYXRlX3BsYXlsaXN0Jzoge1xuICAgICAgICBjb25zdCB7IHBsYXlsaXN0X2lkOiBwbElkLCAuLi5wbFVwZGF0ZXMgfSA9IHBheWxvYWQ7XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGFkbWluQ2xpZW50LmZyb20oJ3BsYXlsaXN0cycpXG4gICAgICAgICAgLnVwZGF0ZSh7IC4uLnBsVXBkYXRlcywgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0pXG4gICAgICAgICAgLmVxKCdpZCcsIHBsSWQpXG4gICAgICAgICAgLmVxKCd1c2VyX2lkJywgdGFyZ2V0X3VzZXJfaWQpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgJ2RlbGV0ZV9wbGF5bGlzdCc6IHtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgncGxheWxpc3RzJylcbiAgICAgICAgICAuZGVsZXRlKClcbiAgICAgICAgICAuZXEoJ2lkJywgcGF5bG9hZC5wbGF5bGlzdF9pZClcbiAgICAgICAgICAuZXEoJ3VzZXJfaWQnLCB0YXJnZXRfdXNlcl9pZCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSAnYWRkX3RvX3BsYXlsaXN0Jzoge1xuICAgICAgICAvLyBHZXQgbWF4IHBvc2l0aW9uXG4gICAgICAgIGNvbnN0IHsgZGF0YTogZXhpc3RpbmcgfSA9IGF3YWl0IGFkbWluQ2xpZW50XG4gICAgICAgICAgLmZyb20oJ3BsYXlsaXN0X3RyYWNrcycpXG4gICAgICAgICAgLnNlbGVjdCgncG9zaXRpb24nKVxuICAgICAgICAgIC5lcSgncGxheWxpc3RfaWQnLCBwYXlsb2FkLnBsYXlsaXN0X2lkKVxuICAgICAgICAgIC5vcmRlcigncG9zaXRpb24nLCB7IGFzY2VuZGluZzogZmFsc2UgfSlcbiAgICAgICAgICAubGltaXQoMSk7XG4gICAgICAgIGNvbnN0IG5leHRQb3NpdGlvbiA9IGV4aXN0aW5nPy5sZW5ndGggPyBleGlzdGluZ1swXS5wb3NpdGlvbiArIDEgOiAwO1xuICAgICAgICBcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgncGxheWxpc3RfdHJhY2tzJykuaW5zZXJ0KHtcbiAgICAgICAgICBwbGF5bGlzdF9pZDogcGF5bG9hZC5wbGF5bGlzdF9pZCxcbiAgICAgICAgICB0cmFja19pZDogcGF5bG9hZC50cmFja19pZCxcbiAgICAgICAgICBwb3NpdGlvbjogbmV4dFBvc2l0aW9uLFxuICAgICAgICB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICdyZW1vdmVfZnJvbV9wbGF5bGlzdCc6IHtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgncGxheWxpc3RfdHJhY2tzJylcbiAgICAgICAgICAuZGVsZXRlKClcbiAgICAgICAgICAuZXEoJ3BsYXlsaXN0X2lkJywgcGF5bG9hZC5wbGF5bGlzdF9pZClcbiAgICAgICAgICAuZXEoJ3RyYWNrX2lkJywgcGF5bG9hZC50cmFja19pZCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSAnbGlrZV9wbGF5bGlzdCc6IHtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgncGxheWxpc3RfbGlrZXMnKS5pbnNlcnQoe1xuICAgICAgICAgIHVzZXJfaWQ6IHRhcmdldF91c2VyX2lkLFxuICAgICAgICAgIHBsYXlsaXN0X2lkOiBwYXlsb2FkLnBsYXlsaXN0X2lkLFxuICAgICAgICB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICd1bmxpa2VfcGxheWxpc3QnOiB7XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGFkbWluQ2xpZW50LmZyb20oJ3BsYXlsaXN0X2xpa2VzJylcbiAgICAgICAgICAuZGVsZXRlKClcbiAgICAgICAgICAuZXEoJ3VzZXJfaWQnLCB0YXJnZXRfdXNlcl9pZClcbiAgICAgICAgICAuZXEoJ3BsYXlsaXN0X2lkJywgcGF5bG9hZC5wbGF5bGlzdF9pZCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuXG4gICAgICAvLyAtLS0tIE1lc3NhZ2VzIC0tLS1cbiAgICAgIGNhc2UgJ3NlbmRfbWVzc2FnZSc6IHtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgnbWVzc2FnZXMnKS5pbnNlcnQoe1xuICAgICAgICAgIGNvbnZlcnNhdGlvbl9pZDogcGF5bG9hZC5jb252ZXJzYXRpb25faWQsXG4gICAgICAgICAgc2VuZGVyX2lkOiB0YXJnZXRfdXNlcl9pZCxcbiAgICAgICAgICBjb250ZW50OiBwYXlsb2FkLmNvbnRlbnQsXG4gICAgICAgICAgYXR0YWNobWVudF91cmw6IHBheWxvYWQuYXR0YWNobWVudF91cmwgfHwgbnVsbCxcbiAgICAgICAgICBhdHRhY2htZW50X3R5cGU6IHBheWxvYWQuYXR0YWNobWVudF90eXBlIHx8IG51bGwsXG4gICAgICAgIH0pLnNlbGVjdCgpLnNpbmdsZSgpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cblxuICAgICAgLy8gLS0tLSBGb3J1bSAtLS0tXG4gICAgICBjYXNlICdjcmVhdGVfZm9ydW1fdG9waWMnOiB7XG4gICAgICAgIC8vIEdlbmVyYXRlIHNsdWcgZnJvbSB0aXRsZVxuICAgICAgICBjb25zdCB0aXRsZVN0ciA9IFN0cmluZyhwYXlsb2FkLnRpdGxlKTtcbiAgICAgICAgY29uc3Qgc2x1ZyA9IHRpdGxlU3RyXG4gICAgICAgICAgLnRvTG93ZXJDYXNlKClcbiAgICAgICAgICAucmVwbGFjZSgvW15cXHB7TH1cXHB7Tn1cXHMtXS9ndSwgJycpXG4gICAgICAgICAgLnJlcGxhY2UoL1tcXHNdKy9nLCAnLScpXG4gICAgICAgICAgLnN1YnN0cmluZygwLCA4MCkgKyAnLScgKyBEYXRlLm5vdygpLnRvU3RyaW5nKDM2KTtcbiAgICAgICAgY29uc3QgZXhjZXJwdCA9IFN0cmluZyhwYXlsb2FkLmNvbnRlbnQpLnN1YnN0cmluZygwLCAyMDApO1xuXG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGFkbWluQ2xpZW50LmZyb20oJ2ZvcnVtX3RvcGljcycpLmluc2VydCh7XG4gICAgICAgICAgY2F0ZWdvcnlfaWQ6IHBheWxvYWQuY2F0ZWdvcnlfaWQsXG4gICAgICAgICAgdXNlcl9pZDogdGFyZ2V0X3VzZXJfaWQsXG4gICAgICAgICAgdGl0bGU6IHBheWxvYWQudGl0bGUsXG4gICAgICAgICAgc2x1ZyxcbiAgICAgICAgICBjb250ZW50OiBwYXlsb2FkLmNvbnRlbnQsXG4gICAgICAgICAgY29udGVudF9odG1sOiBwYXlsb2FkLmNvbnRlbnRfaHRtbCB8fCBudWxsLFxuICAgICAgICAgIGV4Y2VycHQsXG4gICAgICAgICAgdHJhY2tfaWQ6IHBheWxvYWQudHJhY2tfaWQgfHwgbnVsbCxcbiAgICAgICAgICBpc19oaWRkZW46IGZhbHNlLFxuICAgICAgICB9KS5zZWxlY3QoKS5zaW5nbGUoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICdjcmVhdGVfZm9ydW1fcG9zdCc6IHtcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgYWRtaW5DbGllbnQuZnJvbSgnZm9ydW1fcG9zdHMnKS5pbnNlcnQoe1xuICAgICAgICAgIHRvcGljX2lkOiBwYXlsb2FkLnRvcGljX2lkLFxuICAgICAgICAgIHVzZXJfaWQ6IHRhcmdldF91c2VyX2lkLFxuICAgICAgICAgIGNvbnRlbnQ6IHBheWxvYWQuY29udGVudCxcbiAgICAgICAgICBjb250ZW50X2h0bWw6IHBheWxvYWQuY29udGVudF9odG1sIHx8IG51bGwsXG4gICAgICAgICAgcGFyZW50X2lkOiBwYXlsb2FkLnBhcmVudF9pZCB8fCBudWxsLFxuICAgICAgICAgIHJlcGx5X3RvX3VzZXJfaWQ6IHBheWxvYWQucmVwbHlfdG9fdXNlcl9pZCB8fCBudWxsLFxuICAgICAgICAgIHRyYWNrX2lkOiBwYXlsb2FkLnRyYWNrX2lkIHx8IG51bGwsXG4gICAgICAgICAgaXNfaGlkZGVuOiBmYWxzZSxcbiAgICAgICAgfSkuc2VsZWN0KCkuc2luZ2xlKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuXG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6ICfQndC10LjQt9Cy0LXRgdGC0L3QvtC1INC00LXQudGB0YLQstC40LUnIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gNy4gTG9nIHRoZSBhY3Rpb25cbiAgICBjb25zdCBsb2dFbnRyeSA9IHtcbiAgICAgIGFkbWluX3VzZXJfaWQ6IGFkbWluVXNlcklkLFxuICAgICAgdGFyZ2V0X3VzZXJfaWQ6IHRhcmdldF91c2VyX2lkLFxuICAgICAgYWN0aW9uX3R5cGU6IGFjdGlvbixcbiAgICAgIGFjdGlvbl9wYXlsb2FkOiBwYXlsb2FkLFxuICAgICAgcmVzdWx0X3N0YXR1czogcmVzdWx0LmVycm9yID8gJ2Vycm9yJyA6ICdzdWNjZXNzJyxcbiAgICAgIGVycm9yX21lc3NhZ2U6IHJlc3VsdC5lcnJvciA/IEpTT04uc3RyaW5naWZ5KHJlc3VsdC5lcnJvcikgOiBudWxsLFxuICAgIH07XG5cbiAgICBhd2FpdCBhZG1pbkNsaWVudC5mcm9tKCdpbXBlcnNvbmF0aW9uX2FjdGlvbl9sb2dzJykuaW5zZXJ0KGxvZ0VudHJ5KTtcblxuICAgIGlmIChyZXN1bHQuZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEltcGVyc29uYXRpb24gYWN0aW9uIGZhaWxlZDpgLCByZXN1bHQuZXJyb3IpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogJ9Ce0YjQuNCx0LrQsCDQstGL0L/QvtC70L3QtdC90LjRjyDQtNC10LnRgdGC0LLQuNGPJywgZGV0YWlsczogcmVzdWx0LmVycm9yIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgSW1wZXJzb25hdGlvbiBhY3Rpb24gc3VjY2VzczogJHthY3Rpb259IGZvciB1c2VyICR7dGFyZ2V0X3VzZXJfaWR9IGJ5IGFkbWluICR7YWRtaW5Vc2VySWR9YCk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICBhY3Rpb24sXG4gICAgICAgIHRhcmdldF91c2VyX2lkLFxuICAgICAgICB0YXJnZXRfdXNlcm5hbWU6IHRhcmdldFByb2ZpbGUudXNlcm5hbWUsXG4gICAgICAgIGRhdGE6IHJlc3VsdC5kYXRhLFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogU3RyaW5nKGVycm9yKTtcbiAgICBjb25zb2xlLmVycm9yKCdJbXBlcnNvbmF0aW9uIGVycm9yOicsIGVycm9yTWVzc2FnZSk7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGVycm9yTWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsK0VBQStFO0FBQy9FLE1BQU0sa0JBS0Q7RUFDSCxxQkFBcUI7RUFDckIsWUFBWTtJQUFFLE9BQU87SUFBZSxXQUFXO0lBQVUsZ0JBQWdCO01BQUM7S0FBVztJQUFFLGFBQWE7RUFBZTtFQUNuSCxjQUFjO0lBQUUsT0FBTztJQUFlLFdBQVc7SUFBVSxnQkFBZ0I7TUFBQztLQUFXO0lBQUUsYUFBYTtFQUFpQjtFQUN2SCxjQUFjO0lBQUUsT0FBTztJQUFVLFdBQVc7SUFBVSxnQkFBZ0I7TUFBQztLQUFXO0lBQUUsYUFBYTtFQUFpQjtFQUNsSCxlQUFlO0VBQ2YsYUFBYTtJQUFFLE9BQU87SUFBZ0IsV0FBVztJQUFVLGdCQUFnQjtNQUFDO0tBQWU7SUFBRSxhQUFhO0VBQWdCO0VBQzFILGVBQWU7SUFBRSxPQUFPO0lBQWdCLFdBQVc7SUFBVSxnQkFBZ0I7TUFBQztLQUFlO0lBQUUsYUFBYTtFQUFrQjtFQUM5SCxnQkFBZ0I7RUFDaEIsY0FBYztJQUFFLE9BQU87SUFBVSxXQUFXO0lBQVUsZ0JBQWdCO01BQUM7S0FBVztJQUFFLGFBQWE7RUFBd0I7RUFDekgsV0FBVztFQUNYLGFBQWE7SUFBRSxPQUFPO0lBQWtCLFdBQVc7SUFBVSxnQkFBZ0I7TUFBQztNQUFZO0tBQVU7SUFBRSxhQUFhO0VBQTJCO0VBQzlJLGdCQUFnQjtJQUFFLE9BQU87SUFBa0IsV0FBVztJQUFVLGdCQUFnQjtNQUFDO0tBQWE7SUFBRSxhQUFhO0VBQW1CO0VBQ2hJLGdCQUFnQjtJQUFFLE9BQU87SUFBa0IsV0FBVztJQUFVLGdCQUFnQjtNQUFDO01BQWM7S0FBVTtJQUFFLGFBQWE7RUFBaUI7RUFDekksY0FBYztJQUFFLE9BQU87SUFBaUIsV0FBVztJQUFVLGdCQUFnQjtNQUFDO0tBQWE7SUFBRSxhQUFhO0VBQWlCO0VBQzNILGdCQUFnQjtJQUFFLE9BQU87SUFBaUIsV0FBVztJQUFVLGdCQUFnQjtNQUFDO0tBQWE7SUFBRSxhQUFhO0VBQW1CO0VBQy9ILGNBQWM7SUFBRSxPQUFPO0lBQXFCLFdBQVc7SUFBVSxnQkFBZ0I7TUFBQztNQUFjO0tBQVE7SUFBRSxhQUFhO0VBQTRCO0VBQ25KLGlCQUFpQjtJQUFFLE9BQU87SUFBcUIsV0FBVztJQUFVLGdCQUFnQjtNQUFDO01BQWM7S0FBUTtJQUFFLGFBQWE7RUFBaUM7RUFDM0osZ0JBQWdCO0lBQUUsT0FBTztJQUFtQixXQUFXO0lBQVUsZ0JBQWdCO01BQUM7TUFBYztLQUFTO0lBQUUsYUFBYTtFQUFtQjtFQUMzSSxrQkFBa0I7RUFDbEIsZ0JBQWdCO0lBQUUsT0FBTztJQUFZLFdBQVc7SUFBVSxnQkFBZ0IsRUFBRTtJQUFFLGFBQWE7RUFBc0I7RUFDakgsWUFBWTtFQUNaLGlCQUFpQjtJQUFFLE9BQU87SUFBYSxXQUFXO0lBQVUsZ0JBQWdCO01BQUM7S0FBUTtJQUFFLGFBQWE7RUFBb0I7RUFDeEgsaUJBQWlCO0lBQUUsT0FBTztJQUFhLFdBQVc7SUFBVSxnQkFBZ0I7TUFBQztLQUFjO0lBQUUsYUFBYTtFQUFvQjtFQUM5SCxpQkFBaUI7SUFBRSxPQUFPO0lBQWEsV0FBVztJQUFVLGdCQUFnQjtNQUFDO0tBQWM7SUFBRSxhQUFhO0VBQW9CO0VBQzlILGlCQUFpQjtJQUFFLE9BQU87SUFBbUIsV0FBVztJQUFVLGdCQUFnQjtNQUFDO01BQWU7S0FBVztJQUFFLGFBQWE7RUFBMEI7RUFDdEosc0JBQXNCO0lBQUUsT0FBTztJQUFtQixXQUFXO0lBQVUsZ0JBQWdCO01BQUM7TUFBZTtLQUFXO0lBQUUsYUFBYTtFQUErQjtFQUNoSyxlQUFlO0lBQUUsT0FBTztJQUFrQixXQUFXO0lBQVUsZ0JBQWdCO01BQUM7S0FBYztJQUFFLGFBQWE7RUFBa0I7RUFDL0gsaUJBQWlCO0lBQUUsT0FBTztJQUFrQixXQUFXO0lBQVUsZ0JBQWdCO01BQUM7S0FBYztJQUFFLGFBQWE7RUFBb0I7RUFDbkksV0FBVztFQUNYLGNBQWM7SUFBRSxPQUFPO0lBQVksV0FBVztJQUFVLGdCQUFnQjtNQUFDO01BQW1CO0tBQVU7SUFBRSxhQUFhO0VBQWlCO0VBQ3RJLFFBQVE7RUFDUixvQkFBb0I7SUFBRSxPQUFPO0lBQWdCLFdBQVc7SUFBVSxnQkFBZ0I7TUFBQztNQUFlO01BQVM7S0FBVTtJQUFFLGFBQWE7RUFBdUI7RUFDM0osbUJBQW1CO0lBQUUsT0FBTztJQUFlLFdBQVc7SUFBVSxnQkFBZ0I7TUFBQztNQUFZO0tBQVU7SUFBRSxhQUFhO0VBQXNCO0FBQzlJO0FBRUEsd0JBQXdCO0FBQ3hCLGVBQWUsT0FBTyxPQUFlO0VBQ25DLE1BQU0sWUFBWSxJQUFJLGNBQWMsTUFBTSxDQUFDO0VBQzNDLE1BQU0sYUFBYSxNQUFNLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXO0VBQ3pELE1BQU0sWUFBWSxNQUFNLElBQUksQ0FBQyxJQUFJLFdBQVc7RUFDNUMsT0FBTyxVQUFVLEdBQUcsQ0FBQyxDQUFBLElBQUssRUFBRSxRQUFRLENBQUMsSUFBSSxRQUFRLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUNsRTtBQUVBLEtBQUssS0FBSyxDQUFDLE9BQU87RUFDaEIsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0VBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUN4QyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFFckMsSUFBSTtJQUNGLGdCQUFnQjtJQUNoQixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZLFdBQVcsWUFBWTtNQUN0QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFFBQVEsV0FBVyxPQUFPLENBQUMsV0FBVztJQUU1QyxzRUFBc0U7SUFDdEUsSUFBSTtJQUNKLElBQUk7TUFDRixNQUFNLGNBQWMsTUFBTSxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUU7TUFDdkMsTUFBTSxVQUFVLEtBQUssS0FBSyxDQUFDLEtBQUs7TUFDaEMsY0FBYyxRQUFRLEdBQUc7TUFDekIsSUFBSSxDQUFDLGFBQWEsTUFBTSxJQUFJLE1BQU07SUFDcEMsRUFBRSxPQUFPLEdBQUc7TUFDVixRQUFRLEtBQUssQ0FBQyxxQkFBcUI7TUFDbkMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWdCLElBQ3hDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLGlDQUFpQztJQUNqQyxNQUFNLGNBQWMsYUFBYSxhQUFhO0lBRTlDLE1BQU0sRUFBRSxNQUFNLFFBQVEsRUFBRSxHQUFHLE1BQU0sWUFDOUIsSUFBSSxDQUFDLGNBQ0wsTUFBTSxDQUFDLFFBQ1AsRUFBRSxDQUFDLFdBQVcsYUFDZCxNQUFNO0lBRVQsSUFBSSxDQUFDLFlBQVksQ0FBQztNQUFDO01BQWU7S0FBUSxDQUFDLFFBQVEsQ0FBQyxTQUFTLElBQUksR0FBRztNQUNsRSxRQUFRLElBQUksQ0FBQyxDQUFDLDhCQUE4QixFQUFFLFlBQVksUUFBUSxFQUFFLFVBQVUsS0FBSyxDQUFDO01BQ3BGLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUErQyxJQUN2RTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSx3QkFBd0I7SUFDeEIsTUFBTSxPQUFPLE1BQU0sSUFBSSxJQUFJO0lBQzNCLE1BQU0sRUFBRSxHQUFHLEVBQUUsY0FBYyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsR0FBRztJQUVqRCxnQkFBZ0I7SUFDaEIsSUFBSSxDQUFDLE9BQU8sT0FBTyxRQUFRLFlBQVksSUFBSSxNQUFNLEtBQUssR0FBRztNQUN2RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBOEIsSUFDdEQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLEdBQUcsTUFBTSxZQUNoQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsU0FDUCxFQUFFLENBQUMsT0FBTyxtQkFDVixNQUFNO0lBRVQsSUFBSSxDQUFDLFlBQVksT0FBTztNQUN0QixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBc0IsSUFDOUM7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxVQUFVLE1BQU0sT0FBTztJQUM3QixJQUFJLFlBQVksV0FBVyxLQUFLLEVBQUU7TUFDaEMsUUFBUSxJQUFJLENBQUMsQ0FBQyxvQ0FBb0MsRUFBRSxZQUFZLENBQUM7TUFFakUsTUFBTSxZQUFZLElBQUksQ0FBQyw2QkFBNkIsTUFBTSxDQUFDO1FBQ3pELGVBQWU7UUFDZixnQkFBZ0Isa0JBQWtCO1FBQ2xDLGFBQWE7UUFDYixnQkFBZ0I7VUFBRTtRQUFPO1FBQ3pCLGVBQWU7UUFDZixlQUFlO01BQ2pCO01BRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQW1CLElBQzNDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLHFCQUFxQjtJQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUU7TUFDdkMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLE9BQU8sY0FBYyxDQUFDO1FBQUUsU0FBUyxPQUFPLElBQUksQ0FBQztNQUFpQixJQUNuRztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxJQUFJLENBQUMsZ0JBQWdCO01BQ25CLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE0QixJQUNwRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSw0QkFBNEI7SUFDNUIsTUFBTSxFQUFFLE1BQU0sYUFBYSxFQUFFLEdBQUcsTUFBTSxZQUNuQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMscUJBQ1AsRUFBRSxDQUFDLFdBQVcsZ0JBQ2QsTUFBTTtJQUVULElBQUksQ0FBQyxlQUFlO01BQ2xCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFpQyxJQUN6RDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGVBQWUsZUFBZSxDQUFDLE9BQU87SUFFNUMsMkJBQTJCO0lBQzNCLEtBQUssTUFBTSxTQUFTLGFBQWEsY0FBYyxDQUFFO01BQy9DLElBQUksQ0FBQyxXQUFXLE9BQU8sQ0FBQyxNQUFNLEtBQUssV0FBVztRQUM1QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsTUFBTSw0QkFBNEIsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUFDLElBQy9FO1VBQUUsUUFBUTtVQUFLLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUVuRjtJQUNGO0lBRUEsZ0RBQWdEO0lBQ2hELElBQUksV0FBVyx3QkFBd0IsV0FBVyxxQkFBcUI7TUFDckUsTUFBTSxnQkFBZ0IsV0FBVyx1QkFBdUIsVUFBVTtNQUNsRSxNQUFNLGNBQWMsV0FBVyx1QkFBdUIsdUJBQXVCO01BRTdFLDhCQUE4QjtNQUM5QixNQUFNLEVBQUUsTUFBTSxTQUFTLEVBQUUsR0FBRyxNQUFNLFlBQy9CLElBQUksQ0FBQyxvQkFDTCxNQUFNLENBQUMsZUFDUCxFQUFFLENBQUMsV0FBVyxnQkFDZCxXQUFXO01BRWQsTUFBTSxhQUFhLEtBQUssR0FBRyxDQUFDLFdBQVcsZUFBZSxHQUFHO01BRXpELHdCQUF3QjtNQUN4QixNQUFNLEVBQUUsTUFBTSxTQUFTLEVBQUUsR0FBRyxNQUFNLFlBQy9CLElBQUksQ0FBQywyQkFDTCxNQUFNLENBQUMsYUFDUCxFQUFFLENBQUMsZUFBZSxZQUNsQixXQUFXO01BRWQsTUFBTSxZQUFZLFlBQVksQUFBQyxTQUEyQyxDQUFDLFlBQVksR0FBRztNQUUxRix1Q0FBdUM7TUFDdkMsSUFBSSxjQUFjLFFBQVEsY0FBYyxXQUFXO1FBQ2pELE1BQU0sY0FBYyxJQUFJLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxLQUFLLEtBQUssTUFBTSxXQUFXO1FBQzFFLE1BQU0saUJBQWlCLFdBQVcsdUJBQXVCLGlCQUFpQjtRQUUxRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxZQUNyQixJQUFJLENBQUMsc0JBQ0wsTUFBTSxDQUFDLE1BQU07VUFBRSxPQUFPO1VBQVMsTUFBTTtRQUFLLEdBQzFDLEVBQUUsQ0FBQyxXQUFXLGdCQUNkLEVBQUUsQ0FBQyxVQUFVLGdCQUNiLEdBQUcsQ0FBQyxjQUFjO1FBRXJCLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxXQUFXO1VBQzdCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1lBQ2IsT0FBTyxrQkFBa0IsVUFDckIsQ0FBQywyQ0FBMkMsRUFBRSxVQUFVLGVBQWUsRUFBRSxXQUFXLENBQUMsQ0FBQyxHQUN0RixDQUFDLDhDQUE4QyxFQUFFLFVBQVUsZUFBZSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1VBQy9GLElBQ0E7WUFBRSxRQUFRO1lBQUssU0FBUztjQUFFLEdBQUcsV0FBVztjQUFFLGdCQUFnQjtZQUFtQjtVQUFFO1FBRW5GO01BQ0Y7SUFDRjtJQUVBLDBEQUEwRDtJQUMxRCxRQUFRLEdBQUcsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLE9BQU8sVUFBVSxFQUFFLFlBQVksU0FBUyxFQUFFLGVBQWUsQ0FBQztJQUUvRixJQUFJLFNBQTRDO01BQUUsTUFBTTtNQUFNLE9BQU87SUFBSztJQUUxRSxPQUFRO01BQ04sK0JBQStCO01BQy9CLEtBQUs7UUFBYztVQUNqQixTQUFTLE1BQU0sWUFBWSxJQUFJLENBQUMsZUFBZSxNQUFNLENBQUM7WUFDcEQsU0FBUztZQUNULFVBQVUsUUFBUSxRQUFRO1VBQzVCO1VBQ0E7UUFDRjtNQUNBLEtBQUs7UUFBZ0I7VUFDbkIsU0FBUyxNQUFNLFlBQVksSUFBSSxDQUFDLGVBQzdCLE1BQU0sR0FDTixFQUFFLENBQUMsV0FBVyxnQkFDZCxFQUFFLENBQUMsWUFBWSxRQUFRLFFBQVE7VUFDbEM7UUFDRjtNQUNBLEtBQUs7UUFBZ0I7VUFDbkIsd0NBQXdDO1VBQ3hDLE1BQU0sRUFBRSxNQUFNLFNBQVMsRUFBRSxHQUFHLE1BQU0sWUFBWSxJQUFJLENBQUMsVUFDaEQsTUFBTSxDQUFDLG9FQUNQLEVBQUUsQ0FBQyxNQUFNLFFBQVEsUUFBUSxFQUN6QixFQUFFLENBQUMsV0FBVyxnQkFDZCxXQUFXO1VBRWQseUJBQXlCO1VBQ3pCLElBQUksV0FBVztZQUNiLE1BQU0sZUFBZSxDQUFDLEVBQUUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdCQUFnQixpQ0FBaUMsQ0FBQztZQUN2RixNQUFNLFFBQWtCLEVBQUU7WUFDMUIsS0FBSyxNQUFNLE9BQU87Y0FBQyxVQUFVLFNBQVM7Y0FBRSxVQUFVLFNBQVM7Y0FBRSxVQUFVLE9BQU87Y0FBRSxVQUFVLGdCQUFnQjtjQUFFLFVBQVUsZUFBZTthQUFDLENBQUU7Y0FDdEksSUFBSSxPQUFPLElBQUksVUFBVSxDQUFDLGVBQWU7Z0JBQ3ZDLE1BQU0sSUFBSSxDQUFDLElBQUksS0FBSyxDQUFDLGFBQWEsTUFBTTtjQUMxQztZQUNGO1lBQ0EsSUFBSSxNQUFNLE1BQU0sR0FBRyxHQUFHO2NBQ3BCLE1BQU0sRUFBRSxPQUFPLFVBQVUsRUFBRSxHQUFHLE1BQU0sWUFBWSxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsTUFBTSxDQUFDO2NBQzlFLElBQUksWUFBWSxRQUFRLElBQUksQ0FBQywyQ0FBMkMsV0FBVyxPQUFPO1lBQzVGO1VBQ0Y7VUFFQSw0Q0FBNEM7VUFDNUMsTUFBTSxZQUFZLElBQUksQ0FBQyxlQUFlLE1BQU0sR0FBRyxFQUFFLENBQUMsWUFBWSxRQUFRLFFBQVE7VUFDOUUsU0FBUyxNQUFNLFlBQVksSUFBSSxDQUFDLFVBQzdCLE1BQU0sR0FDTixFQUFFLENBQUMsTUFBTSxRQUFRLFFBQVEsRUFDekIsRUFBRSxDQUFDLFdBQVc7VUFDakI7UUFDRjtNQUVBLG9CQUFvQjtNQUNwQixLQUFLO1FBQWU7VUFDbEIsU0FBUyxNQUFNLFlBQVksSUFBSSxDQUFDLGdCQUFnQixNQUFNLENBQUM7WUFDckQsYUFBYTtZQUNiLGNBQWMsUUFBUSxZQUFZO1VBQ3BDO1VBQ0E7UUFDRjtNQUNBLEtBQUs7UUFBaUI7VUFDcEIsU0FBUyxNQUFNLFlBQVksSUFBSSxDQUFDLGdCQUM3QixNQUFNLEdBQ04sRUFBRSxDQUFDLGVBQWUsZ0JBQ2xCLEVBQUUsQ0FBQyxnQkFBZ0IsUUFBUSxZQUFZO1VBQzFDO1FBQ0Y7TUFFQSwwQkFBMEI7TUFDMUIsS0FBSztRQUFnQjtVQUNuQixNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsY0FBYyxHQUFHO1VBQ3RDLFNBQVMsTUFBTSxZQUFZLElBQUksQ0FBQyxVQUM3QixNQUFNLENBQUMsY0FDUCxFQUFFLENBQUMsTUFBTSxVQUNULEVBQUUsQ0FBQyxXQUFXO1VBQ2pCO1FBQ0Y7TUFFQSxxQkFBcUI7TUFDckIsS0FBSztRQUFlO1VBQ2xCLE1BQU0sYUFBc0M7WUFDMUMsU0FBUztZQUNULFVBQVUsUUFBUSxRQUFRO1lBQzFCLFNBQVMsUUFBUSxPQUFPO1VBQzFCO1VBQ0EsSUFBSSxRQUFRLFNBQVMsRUFBRSxXQUFXLFNBQVMsR0FBRyxRQUFRLFNBQVM7VUFDL0QsSUFBSSxRQUFRLGlCQUFpQixLQUFLLFdBQVcsV0FBVyxpQkFBaUIsR0FBRyxRQUFRLGlCQUFpQjtVQUNyRyxJQUFJLFFBQVEsVUFBVSxFQUFFLFdBQVcsVUFBVSxHQUFHLFFBQVEsVUFBVTtVQUNsRSxJQUFJLFFBQVEsWUFBWSxFQUFFLFdBQVcsWUFBWSxHQUFHLFFBQVEsWUFBWTtVQUN4RSxTQUFTLE1BQU0sWUFBWSxJQUFJLENBQUMsa0JBQWtCLE1BQU0sQ0FBQztVQUN6RDtRQUNGO01BQ0EsS0FBSztRQUFrQjtVQUNyQixTQUFTLE1BQU0sWUFBWSxJQUFJLENBQUMsa0JBQzdCLE1BQU0sR0FDTixFQUFFLENBQUMsTUFBTSxRQUFRLFVBQVUsRUFDM0IsRUFBRSxDQUFDLFdBQVc7VUFDakI7UUFDRjtNQUNBLEtBQUs7UUFBa0I7VUFDckIsU0FBUyxNQUFNLFlBQVksSUFBSSxDQUFDLGtCQUM3QixNQUFNLENBQUM7WUFBRSxTQUFTLFFBQVEsT0FBTztZQUFFLFlBQVksSUFBSSxPQUFPLFdBQVc7VUFBRyxHQUN4RSxFQUFFLENBQUMsTUFBTSxRQUFRLFVBQVUsRUFDM0IsRUFBRSxDQUFDLFdBQVc7VUFDakI7UUFDRjtNQUNBLEtBQUs7UUFBZ0I7VUFDbkIsU0FBUyxNQUFNLFlBQVksSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7WUFDdEQsU0FBUztZQUNULFlBQVksUUFBUSxVQUFVO1VBQ2hDO1VBQ0E7UUFDRjtNQUNBLEtBQUs7UUFBa0I7VUFDckIsU0FBUyxNQUFNLFlBQVksSUFBSSxDQUFDLGlCQUM3QixNQUFNLEdBQ04sRUFBRSxDQUFDLFdBQVcsZ0JBQ2QsRUFBRSxDQUFDLGNBQWMsUUFBUSxVQUFVO1VBQ3RDO1FBQ0Y7TUFDQSxLQUFLO1FBQWdCO1VBQ25CLFNBQVMsTUFBTSxZQUFZLElBQUksQ0FBQyxxQkFBcUIsTUFBTSxDQUFDO1lBQzFELFNBQVM7WUFDVCxZQUFZLFFBQVEsVUFBVTtZQUM5QixPQUFPLFFBQVEsS0FBSztVQUN0QjtVQUNBO1FBQ0Y7TUFDQSxLQUFLO1FBQW1CO1VBQ3RCLFNBQVMsTUFBTSxZQUFZLElBQUksQ0FBQyxxQkFDN0IsTUFBTSxHQUNOLEVBQUUsQ0FBQyxXQUFXLGdCQUNkLEVBQUUsQ0FBQyxjQUFjLFFBQVEsVUFBVSxFQUNuQyxFQUFFLENBQUMsU0FBUyxRQUFRLEtBQUs7VUFDNUI7UUFDRjtNQUNBLEtBQUs7UUFBa0I7VUFDckIsU0FBUyxNQUFNLFlBQVksSUFBSSxDQUFDLG1CQUFtQixNQUFNLENBQUM7WUFDeEQsYUFBYTtZQUNiLFlBQVksUUFBUSxVQUFVO1lBQzlCLFFBQVEsUUFBUSxNQUFNO1VBQ3hCO1VBQ0E7UUFDRjtNQUVBLG9CQUFvQjtNQUNwQixLQUFLO1FBQWtCO1VBQ3JCLE1BQU0sRUFBRSxHQUFHLGVBQWUsR0FBRztVQUM3QixPQUFPLGNBQWMsT0FBTztVQUM1QixPQUFPLGNBQWMsT0FBTztVQUM1QixPQUFPLGNBQWMsS0FBSztVQUUxQixTQUFTLE1BQU0sWUFBWSxJQUFJLENBQUMsWUFDN0IsTUFBTSxDQUFDLGVBQ1AsRUFBRSxDQUFDLFdBQVc7VUFDakI7UUFDRjtNQUVBLHNCQUFzQjtNQUN0QixLQUFLO1FBQW1CO1VBQ3RCLFNBQVMsTUFBTSxZQUFZLElBQUksQ0FBQyxhQUFhLE1BQU0sQ0FBQztZQUNsRCxTQUFTO1lBQ1QsT0FBTyxRQUFRLEtBQUs7WUFDcEIsYUFBYSxRQUFRLFdBQVcsSUFBSTtZQUNwQyxXQUFXLFFBQVEsU0FBUyxJQUFJO1VBQ2xDLEdBQUcsTUFBTSxHQUFHLE1BQU07VUFDbEI7UUFDRjtNQUNBLEtBQUs7UUFBbUI7VUFDdEIsTUFBTSxFQUFFLGFBQWEsSUFBSSxFQUFFLEdBQUcsV0FBVyxHQUFHO1VBQzVDLFNBQVMsTUFBTSxZQUFZLElBQUksQ0FBQyxhQUM3QixNQUFNLENBQUM7WUFBRSxHQUFHLFNBQVM7WUFBRSxZQUFZLElBQUksT0FBTyxXQUFXO1VBQUcsR0FDNUQsRUFBRSxDQUFDLE1BQU0sTUFDVCxFQUFFLENBQUMsV0FBVztVQUNqQjtRQUNGO01BQ0EsS0FBSztRQUFtQjtVQUN0QixTQUFTLE1BQU0sWUFBWSxJQUFJLENBQUMsYUFDN0IsTUFBTSxHQUNOLEVBQUUsQ0FBQyxNQUFNLFFBQVEsV0FBVyxFQUM1QixFQUFFLENBQUMsV0FBVztVQUNqQjtRQUNGO01BQ0EsS0FBSztRQUFtQjtVQUN0QixtQkFBbUI7VUFDbkIsTUFBTSxFQUFFLE1BQU0sUUFBUSxFQUFFLEdBQUcsTUFBTSxZQUM5QixJQUFJLENBQUMsbUJBQ0wsTUFBTSxDQUFDLFlBQ1AsRUFBRSxDQUFDLGVBQWUsUUFBUSxXQUFXLEVBQ3JDLEtBQUssQ0FBQyxZQUFZO1lBQUUsV0FBVztVQUFNLEdBQ3JDLEtBQUssQ0FBQztVQUNULE1BQU0sZUFBZSxVQUFVLFNBQVMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLEdBQUcsSUFBSTtVQUVuRSxTQUFTLE1BQU0sWUFBWSxJQUFJLENBQUMsbUJBQW1CLE1BQU0sQ0FBQztZQUN4RCxhQUFhLFFBQVEsV0FBVztZQUNoQyxVQUFVLFFBQVEsUUFBUTtZQUMxQixVQUFVO1VBQ1o7VUFDQTtRQUNGO01BQ0EsS0FBSztRQUF3QjtVQUMzQixTQUFTLE1BQU0sWUFBWSxJQUFJLENBQUMsbUJBQzdCLE1BQU0sR0FDTixFQUFFLENBQUMsZUFBZSxRQUFRLFdBQVcsRUFDckMsRUFBRSxDQUFDLFlBQVksUUFBUSxRQUFRO1VBQ2xDO1FBQ0Y7TUFDQSxLQUFLO1FBQWlCO1VBQ3BCLFNBQVMsTUFBTSxZQUFZLElBQUksQ0FBQyxrQkFBa0IsTUFBTSxDQUFDO1lBQ3ZELFNBQVM7WUFDVCxhQUFhLFFBQVEsV0FBVztVQUNsQztVQUNBO1FBQ0Y7TUFDQSxLQUFLO1FBQW1CO1VBQ3RCLFNBQVMsTUFBTSxZQUFZLElBQUksQ0FBQyxrQkFDN0IsTUFBTSxHQUNOLEVBQUUsQ0FBQyxXQUFXLGdCQUNkLEVBQUUsQ0FBQyxlQUFlLFFBQVEsV0FBVztVQUN4QztRQUNGO01BRUEscUJBQXFCO01BQ3JCLEtBQUs7UUFBZ0I7VUFDbkIsU0FBUyxNQUFNLFlBQVksSUFBSSxDQUFDLFlBQVksTUFBTSxDQUFDO1lBQ2pELGlCQUFpQixRQUFRLGVBQWU7WUFDeEMsV0FBVztZQUNYLFNBQVMsUUFBUSxPQUFPO1lBQ3hCLGdCQUFnQixRQUFRLGNBQWMsSUFBSTtZQUMxQyxpQkFBaUIsUUFBUSxlQUFlLElBQUk7VUFDOUMsR0FBRyxNQUFNLEdBQUcsTUFBTTtVQUNsQjtRQUNGO01BRUEsa0JBQWtCO01BQ2xCLEtBQUs7UUFBc0I7VUFDekIsMkJBQTJCO1VBQzNCLE1BQU0sV0FBVyxPQUFPLFFBQVEsS0FBSztVQUNyQyxNQUFNLE9BQU8sU0FDVixXQUFXLEdBQ1gsT0FBTyxDQUFDLHNCQUFzQixJQUM5QixPQUFPLENBQUMsVUFBVSxLQUNsQixTQUFTLENBQUMsR0FBRyxNQUFNLE1BQU0sS0FBSyxHQUFHLEdBQUcsUUFBUSxDQUFDO1VBQ2hELE1BQU0sVUFBVSxPQUFPLFFBQVEsT0FBTyxFQUFFLFNBQVMsQ0FBQyxHQUFHO1VBRXJELFNBQVMsTUFBTSxZQUFZLElBQUksQ0FBQyxnQkFBZ0IsTUFBTSxDQUFDO1lBQ3JELGFBQWEsUUFBUSxXQUFXO1lBQ2hDLFNBQVM7WUFDVCxPQUFPLFFBQVEsS0FBSztZQUNwQjtZQUNBLFNBQVMsUUFBUSxPQUFPO1lBQ3hCLGNBQWMsUUFBUSxZQUFZLElBQUk7WUFDdEM7WUFDQSxVQUFVLFFBQVEsUUFBUSxJQUFJO1lBQzlCLFdBQVc7VUFDYixHQUFHLE1BQU0sR0FBRyxNQUFNO1VBQ2xCO1FBQ0Y7TUFDQSxLQUFLO1FBQXFCO1VBQ3hCLFNBQVMsTUFBTSxZQUFZLElBQUksQ0FBQyxlQUFlLE1BQU0sQ0FBQztZQUNwRCxVQUFVLFFBQVEsUUFBUTtZQUMxQixTQUFTO1lBQ1QsU0FBUyxRQUFRLE9BQU87WUFDeEIsY0FBYyxRQUFRLFlBQVksSUFBSTtZQUN0QyxXQUFXLFFBQVEsU0FBUyxJQUFJO1lBQ2hDLGtCQUFrQixRQUFRLGdCQUFnQixJQUFJO1lBQzlDLFVBQVUsUUFBUSxRQUFRLElBQUk7WUFDOUIsV0FBVztVQUNiLEdBQUcsTUFBTSxHQUFHLE1BQU07VUFDbEI7UUFDRjtNQUVBO1FBQ0UsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQXVCLElBQy9DO1VBQUUsUUFBUTtVQUFLLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtJQUVyRjtJQUVBLG9CQUFvQjtJQUNwQixNQUFNLFdBQVc7TUFDZixlQUFlO01BQ2YsZ0JBQWdCO01BQ2hCLGFBQWE7TUFDYixnQkFBZ0I7TUFDaEIsZUFBZSxPQUFPLEtBQUssR0FBRyxVQUFVO01BQ3hDLGVBQWUsT0FBTyxLQUFLLEdBQUcsS0FBSyxTQUFTLENBQUMsT0FBTyxLQUFLLElBQUk7SUFDL0Q7SUFFQSxNQUFNLFlBQVksSUFBSSxDQUFDLDZCQUE2QixNQUFNLENBQUM7SUFFM0QsSUFBSSxPQUFPLEtBQUssRUFBRTtNQUNoQixRQUFRLEtBQUssQ0FBQyxDQUFDLDRCQUE0QixDQUFDLEVBQUUsT0FBTyxLQUFLO01BQzFELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztRQUE4QixTQUFTLE9BQU8sS0FBSztNQUFDLElBQzVFO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsOEJBQThCLEVBQUUsT0FBTyxVQUFVLEVBQUUsZUFBZSxVQUFVLEVBQUUsWUFBWSxDQUFDO0lBRXhHLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNUO01BQ0E7TUFDQSxpQkFBaUIsY0FBYyxRQUFRO01BQ3ZDLE1BQU0sT0FBTyxJQUFJO0lBQ25CLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLE1BQU0sZUFBZSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRyxPQUFPO0lBQ3JFLFFBQVEsS0FBSyxDQUFDLHdCQUF3QjtJQUN0QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBYSxJQUNyQztNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkY7QUFDRiJ9
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const payload = await req.json();
    console.log("WAV callback received:", JSON.stringify(payload));
    const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
    const { code, data, msg } = payload;
    // The API returns: { code: 200, data: { audio_wav_url: "...", task_id: "..." }, msg: "All generated successfully." }
    // Check for success by code 200 AND presence of audio_wav_url
    if (code === 200 && data?.audio_wav_url) {
      const wavUrl = data.audio_wav_url;
      const taskId = data.task_id;
      console.log(`WAV conversion success! taskId: ${taskId}, wavUrl: ${wavUrl}`);
      // Find the addon by task_id stored in result_url JSON
      const { data: addons } = await supabase.from("track_addons").select("id, track_id, result_url").eq("status", "processing").order("created_at", {
        ascending: false
      });
      let matchedAddon = null;
      // Find addon that matches the task_id
      if (addons && taskId) {
        for (const addon of addons){
          try {
            if (addon.result_url) {
              const resultData = typeof addon.result_url === 'string' ? JSON.parse(addon.result_url) : addon.result_url;
              if (resultData.wav_task_id === taskId) {
                matchedAddon = addon;
                break;
              }
            }
          } catch (e) {
            console.log("Error parsing result_url:", e);
          }
        }
      }
      // Fallback to most recent if no match found
      if (!matchedAddon && addons && addons.length > 0) {
        matchedAddon = addons[0];
        console.log("No task_id match, using most recent addon");
      }
      if (matchedAddon) {
        console.log(`Updating addon ${matchedAddon.id} with WAV URL`);
        await supabase.from("track_addons").update({
          status: "completed",
          result_url: wavUrl,
          updated_at: new Date().toISOString()
        }).eq("id", matchedAddon.id);
        // Also update the track with wav_url for easy access
        await supabase.from("tracks").update({
          wav_url: wavUrl,
          updated_at: new Date().toISOString()
        }).eq("id", matchedAddon.track_id);
        // Notify user
        const { data: track } = await supabase.from("tracks").select("user_id, title").eq("id", matchedAddon.track_id).maybeSingle();
        if (track) {
          await supabase.from("notifications").insert({
            user_id: track.user_id,
            type: "addon_completed",
            title: "WAV готов к скачиванию",
            message: `Трек "${track.title}" конвертирован в WAV формат. Нажмите для скачивания.`,
            target_type: "track",
            target_id: matchedAddon.track_id,
            metadata: {
              wav_url: wavUrl
            }
          });
        }
        console.log("WAV conversion completed and saved:", wavUrl);
      } else {
        console.error("No matching addon found for task:", taskId);
      }
    } else {
      console.error("WAV conversion failed or unexpected format:", payload);
    }
    return new Response(JSON.stringify({
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in wav-callback:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy93YXYtY2FsbGJhY2svaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTY4LjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgcGF5bG9hZCA9IGF3YWl0IHJlcS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJXQVYgY2FsbGJhY2sgcmVjZWl2ZWQ6XCIsIEpTT04uc3RyaW5naWZ5KHBheWxvYWQpKTtcblxuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpISxcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhXG4gICAgKTtcblxuICAgIGNvbnN0IHsgY29kZSwgZGF0YSwgbXNnIH0gPSBwYXlsb2FkO1xuXG4gICAgLy8gVGhlIEFQSSByZXR1cm5zOiB7IGNvZGU6IDIwMCwgZGF0YTogeyBhdWRpb193YXZfdXJsOiBcIi4uLlwiLCB0YXNrX2lkOiBcIi4uLlwiIH0sIG1zZzogXCJBbGwgZ2VuZXJhdGVkIHN1Y2Nlc3NmdWxseS5cIiB9XG4gICAgLy8gQ2hlY2sgZm9yIHN1Y2Nlc3MgYnkgY29kZSAyMDAgQU5EIHByZXNlbmNlIG9mIGF1ZGlvX3dhdl91cmxcbiAgICBpZiAoY29kZSA9PT0gMjAwICYmIGRhdGE/LmF1ZGlvX3dhdl91cmwpIHtcbiAgICAgIGNvbnN0IHdhdlVybCA9IGRhdGEuYXVkaW9fd2F2X3VybDtcbiAgICAgIGNvbnN0IHRhc2tJZCA9IGRhdGEudGFza19pZDtcblxuICAgICAgY29uc29sZS5sb2coYFdBViBjb252ZXJzaW9uIHN1Y2Nlc3MhIHRhc2tJZDogJHt0YXNrSWR9LCB3YXZVcmw6ICR7d2F2VXJsfWApO1xuXG4gICAgICAvLyBGaW5kIHRoZSBhZGRvbiBieSB0YXNrX2lkIHN0b3JlZCBpbiByZXN1bHRfdXJsIEpTT05cbiAgICAgIGNvbnN0IHsgZGF0YTogYWRkb25zIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcInRyYWNrX2FkZG9uc1wiKVxuICAgICAgICAuc2VsZWN0KFwiaWQsIHRyYWNrX2lkLCByZXN1bHRfdXJsXCIpXG4gICAgICAgIC5lcShcInN0YXR1c1wiLCBcInByb2Nlc3NpbmdcIilcbiAgICAgICAgLm9yZGVyKFwiY3JlYXRlZF9hdFwiLCB7IGFzY2VuZGluZzogZmFsc2UgfSk7XG5cbiAgICAgIGxldCBtYXRjaGVkQWRkb24gPSBudWxsO1xuXG4gICAgICAvLyBGaW5kIGFkZG9uIHRoYXQgbWF0Y2hlcyB0aGUgdGFza19pZFxuICAgICAgaWYgKGFkZG9ucyAmJiB0YXNrSWQpIHtcbiAgICAgICAgZm9yIChjb25zdCBhZGRvbiBvZiBhZGRvbnMpIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgaWYgKGFkZG9uLnJlc3VsdF91cmwpIHtcbiAgICAgICAgICAgICAgY29uc3QgcmVzdWx0RGF0YSA9IHR5cGVvZiBhZGRvbi5yZXN1bHRfdXJsID09PSAnc3RyaW5nJyBcbiAgICAgICAgICAgICAgICA/IEpTT04ucGFyc2UoYWRkb24ucmVzdWx0X3VybCkgXG4gICAgICAgICAgICAgICAgOiBhZGRvbi5yZXN1bHRfdXJsO1xuICAgICAgICAgICAgICBpZiAocmVzdWx0RGF0YS53YXZfdGFza19pZCA9PT0gdGFza0lkKSB7XG4gICAgICAgICAgICAgICAgbWF0Y2hlZEFkZG9uID0gYWRkb247XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9yIHBhcnNpbmcgcmVzdWx0X3VybDpcIiwgZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEZhbGxiYWNrIHRvIG1vc3QgcmVjZW50IGlmIG5vIG1hdGNoIGZvdW5kXG4gICAgICBpZiAoIW1hdGNoZWRBZGRvbiAmJiBhZGRvbnMgJiYgYWRkb25zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgbWF0Y2hlZEFkZG9uID0gYWRkb25zWzBdO1xuICAgICAgICBjb25zb2xlLmxvZyhcIk5vIHRhc2tfaWQgbWF0Y2gsIHVzaW5nIG1vc3QgcmVjZW50IGFkZG9uXCIpO1xuICAgICAgfVxuXG4gICAgICBpZiAobWF0Y2hlZEFkZG9uKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGluZyBhZGRvbiAke21hdGNoZWRBZGRvbi5pZH0gd2l0aCBXQVYgVVJMYCk7XG4gICAgICAgIFxuICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwidHJhY2tfYWRkb25zXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgICAgcmVzdWx0X3VybDogd2F2VXJsLFxuICAgICAgICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIH0pXG4gICAgICAgICAgLmVxKFwiaWRcIiwgbWF0Y2hlZEFkZG9uLmlkKTtcblxuICAgICAgICAvLyBBbHNvIHVwZGF0ZSB0aGUgdHJhY2sgd2l0aCB3YXZfdXJsIGZvciBlYXN5IGFjY2Vzc1xuICAgICAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICAgICAgd2F2X3VybDogd2F2VXJsLFxuICAgICAgICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIH0pXG4gICAgICAgICAgLmVxKFwiaWRcIiwgbWF0Y2hlZEFkZG9uLnRyYWNrX2lkKTtcblxuICAgICAgICAvLyBOb3RpZnkgdXNlclxuICAgICAgICBjb25zdCB7IGRhdGE6IHRyYWNrIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgLnNlbGVjdChcInVzZXJfaWQsIHRpdGxlXCIpXG4gICAgICAgICAgLmVxKFwiaWRcIiwgbWF0Y2hlZEFkZG9uLnRyYWNrX2lkKVxuICAgICAgICAgIC5tYXliZVNpbmdsZSgpO1xuXG4gICAgICAgIGlmICh0cmFjaykge1xuICAgICAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oXCJub3RpZmljYXRpb25zXCIpLmluc2VydCh7XG4gICAgICAgICAgICB1c2VyX2lkOiB0cmFjay51c2VyX2lkLFxuICAgICAgICAgICAgdHlwZTogXCJhZGRvbl9jb21wbGV0ZWRcIixcbiAgICAgICAgICAgIHRpdGxlOiBcIldBViDQs9C+0YLQvtCyINC6INGB0LrQsNGH0LjQstCw0L3QuNGOXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBg0KLRgNC10LogXCIke3RyYWNrLnRpdGxlfVwiINC60L7QvdCy0LXRgNGC0LjRgNC+0LLQsNC9INCyIFdBViDRhNC+0YDQvNCw0YIuINCd0LDQttC80LjRgtC1INC00LvRjyDRgdC60LDRh9C40LLQsNC90LjRjy5gLFxuICAgICAgICAgICAgdGFyZ2V0X3R5cGU6IFwidHJhY2tcIixcbiAgICAgICAgICAgIHRhcmdldF9pZDogbWF0Y2hlZEFkZG9uLnRyYWNrX2lkLFxuICAgICAgICAgICAgbWV0YWRhdGE6IHsgd2F2X3VybDogd2F2VXJsIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zb2xlLmxvZyhcIldBViBjb252ZXJzaW9uIGNvbXBsZXRlZCBhbmQgc2F2ZWQ6XCIsIHdhdlVybCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiTm8gbWF0Y2hpbmcgYWRkb24gZm91bmQgZm9yIHRhc2s6XCIsIHRhc2tJZCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJXQVYgY29udmVyc2lvbiBmYWlsZWQgb3IgdW5leHBlY3RlZCBmb3JtYXQ6XCIsIHBheWxvYWQpO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiB0cnVlIH0pLCB7XG4gICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnJvcjogdW5rbm93bikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiB3YXYtY2FsbGJhY2s6XCIsIGVycm9yKTtcbiAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLFVBQVUsTUFBTSxJQUFJLElBQUk7SUFDOUIsUUFBUSxHQUFHLENBQUMsMEJBQTBCLEtBQUssU0FBUyxDQUFDO0lBRXJELE1BQU0sV0FBVyxhQUNmLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxpQkFDYixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFHZixNQUFNLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRztJQUU1QixxSEFBcUg7SUFDckgsOERBQThEO0lBQzlELElBQUksU0FBUyxPQUFPLE1BQU0sZUFBZTtNQUN2QyxNQUFNLFNBQVMsS0FBSyxhQUFhO01BQ2pDLE1BQU0sU0FBUyxLQUFLLE9BQU87TUFFM0IsUUFBUSxHQUFHLENBQUMsQ0FBQyxnQ0FBZ0MsRUFBRSxPQUFPLFVBQVUsRUFBRSxPQUFPLENBQUM7TUFFMUUsc0RBQXNEO01BQ3RELE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxHQUFHLE1BQU0sU0FDNUIsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyw0QkFDUCxFQUFFLENBQUMsVUFBVSxjQUNiLEtBQUssQ0FBQyxjQUFjO1FBQUUsV0FBVztNQUFNO01BRTFDLElBQUksZUFBZTtNQUVuQixzQ0FBc0M7TUFDdEMsSUFBSSxVQUFVLFFBQVE7UUFDcEIsS0FBSyxNQUFNLFNBQVMsT0FBUTtVQUMxQixJQUFJO1lBQ0YsSUFBSSxNQUFNLFVBQVUsRUFBRTtjQUNwQixNQUFNLGFBQWEsT0FBTyxNQUFNLFVBQVUsS0FBSyxXQUMzQyxLQUFLLEtBQUssQ0FBQyxNQUFNLFVBQVUsSUFDM0IsTUFBTSxVQUFVO2NBQ3BCLElBQUksV0FBVyxXQUFXLEtBQUssUUFBUTtnQkFDckMsZUFBZTtnQkFDZjtjQUNGO1lBQ0Y7VUFDRixFQUFFLE9BQU8sR0FBRztZQUNWLFFBQVEsR0FBRyxDQUFDLDZCQUE2QjtVQUMzQztRQUNGO01BQ0Y7TUFFQSw0Q0FBNEM7TUFDNUMsSUFBSSxDQUFDLGdCQUFnQixVQUFVLE9BQU8sTUFBTSxHQUFHLEdBQUc7UUFDaEQsZUFBZSxNQUFNLENBQUMsRUFBRTtRQUN4QixRQUFRLEdBQUcsQ0FBQztNQUNkO01BRUEsSUFBSSxjQUFjO1FBQ2hCLFFBQVEsR0FBRyxDQUFDLENBQUMsZUFBZSxFQUFFLGFBQWEsRUFBRSxDQUFDLGFBQWEsQ0FBQztRQUU1RCxNQUFNLFNBQ0gsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQztVQUNOLFFBQVE7VUFDUixZQUFZO1VBQ1osWUFBWSxJQUFJLE9BQU8sV0FBVztRQUNwQyxHQUNDLEVBQUUsQ0FBQyxNQUFNLGFBQWEsRUFBRTtRQUUzQixxREFBcUQ7UUFDckQsTUFBTSxTQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztVQUNOLFNBQVM7VUFDVCxZQUFZLElBQUksT0FBTyxXQUFXO1FBQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sYUFBYSxRQUFRO1FBRWpDLGNBQWM7UUFDZCxNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsR0FBRyxNQUFNLFNBQzNCLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxrQkFDUCxFQUFFLENBQUMsTUFBTSxhQUFhLFFBQVEsRUFDOUIsV0FBVztRQUVkLElBQUksT0FBTztVQUNULE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztZQUMxQyxTQUFTLE1BQU0sT0FBTztZQUN0QixNQUFNO1lBQ04sT0FBTztZQUNQLFNBQVMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUMscURBQXFELENBQUM7WUFDcEYsYUFBYTtZQUNiLFdBQVcsYUFBYSxRQUFRO1lBQ2hDLFVBQVU7Y0FBRSxTQUFTO1lBQU87VUFDOUI7UUFDRjtRQUVBLFFBQVEsR0FBRyxDQUFDLHVDQUF1QztNQUNyRCxPQUFPO1FBQ0wsUUFBUSxLQUFLLENBQUMscUNBQXFDO01BQ3JEO0lBQ0YsT0FBTztNQUNMLFFBQVEsS0FBSyxDQUFDLCtDQUErQztJQUMvRDtJQUVBLE9BQU8sSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztJQUFLLElBQUk7TUFDckQsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUNoRTtFQUNGLEVBQUUsT0FBTyxPQUFnQjtJQUN2QixRQUFRLEtBQUssQ0FBQywwQkFBMEI7SUFDeEMsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFRLElBQ2hDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
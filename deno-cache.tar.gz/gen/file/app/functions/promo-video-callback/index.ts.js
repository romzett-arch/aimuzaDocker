import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const body = await req.json();
    const { promo_video_id, status, video_url, thumbnail_url, file_size_bytes, error_message } = body;
    if (!promo_video_id) {
      throw new Error("promo_video_id is required");
    }
    console.log(`Promo video callback: ${promo_video_id}, status: ${status}`);
    // Get promo video record
    const { data: promoVideo, error: fetchError } = await supabase.from("promo_videos").select("id, track_id, user_id").eq("id", promo_video_id).single();
    if (fetchError || !promoVideo) {
      throw new Error("Promo video not found");
    }
    // Update status
    const updateData = {
      status,
      progress: status === "completed" ? 100 : undefined,
      updated_at: new Date().toISOString()
    };
    if (status === "completed") {
      updateData.video_url = video_url;
      updateData.thumbnail_url = thumbnail_url;
      updateData.file_size_bytes = file_size_bytes;
      updateData.completed_at = new Date().toISOString();
      // Send notification to user
      await supabase.from("notifications").insert({
        user_id: promoVideo.user_id,
        type: "system",
        title: "🎬 Промо-видео готово!",
        message: "Ваше промо-видео успешно создано и готово к скачиванию",
        target_type: "promo_video",
        target_id: promo_video_id
      });
    } else if (status === "failed") {
      updateData.error_message = error_message || "Unknown error";
      // Notify user about failure
      await supabase.from("notifications").insert({
        user_id: promoVideo.user_id,
        type: "system",
        title: "Ошибка генерации видео",
        message: error_message || "Не удалось создать промо-видео. Попробуйте ещё раз.",
        target_type: "promo_video",
        target_id: promo_video_id
      });
    }
    const { error: updateError } = await supabase.from("promo_videos").update(updateData).eq("id", promo_video_id);
    if (updateError) {
      console.error("Update error:", updateError);
      throw new Error("Failed to update promo video");
    }
    console.log(`Promo video ${promo_video_id} updated to ${status}`);
    return new Response(JSON.stringify({
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Promo video callback error:", errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9wcm9tby12aWRlby1jYWxsYmFjay9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xOTAuMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyLjQ5LjFcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuaW50ZXJmYWNlIENhbGxiYWNrRGF0YSB7XG4gIHByb21vX3ZpZGVvX2lkOiBzdHJpbmc7XG4gIHN0YXR1czogXCJjb21wbGV0ZWRcIiB8IFwiZmFpbGVkXCI7XG4gIHZpZGVvX3VybD86IHN0cmluZztcbiAgdGh1bWJuYWlsX3VybD86IHN0cmluZztcbiAgZmlsZV9zaXplX2J5dGVzPzogbnVtYmVyO1xuICBlcnJvcl9tZXNzYWdlPzogc3RyaW5nO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxOiBSZXF1ZXN0KSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlU2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXkpO1xuXG4gICAgY29uc3QgYm9keTogQ2FsbGJhY2tEYXRhID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zdCB7IHByb21vX3ZpZGVvX2lkLCBzdGF0dXMsIHZpZGVvX3VybCwgdGh1bWJuYWlsX3VybCwgZmlsZV9zaXplX2J5dGVzLCBlcnJvcl9tZXNzYWdlIH0gPSBib2R5O1xuXG4gICAgaWYgKCFwcm9tb192aWRlb19pZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwicHJvbW9fdmlkZW9faWQgaXMgcmVxdWlyZWRcIik7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYFByb21vIHZpZGVvIGNhbGxiYWNrOiAke3Byb21vX3ZpZGVvX2lkfSwgc3RhdHVzOiAke3N0YXR1c31gKTtcblxuICAgIC8vIEdldCBwcm9tbyB2aWRlbyByZWNvcmRcbiAgICBjb25zdCB7IGRhdGE6IHByb21vVmlkZW8sIGVycm9yOiBmZXRjaEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwcm9tb192aWRlb3NcIilcbiAgICAgIC5zZWxlY3QoXCJpZCwgdHJhY2tfaWQsIHVzZXJfaWRcIilcbiAgICAgIC5lcShcImlkXCIsIHByb21vX3ZpZGVvX2lkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKGZldGNoRXJyb3IgfHwgIXByb21vVmlkZW8pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlByb21vIHZpZGVvIG5vdCBmb3VuZFwiKTtcbiAgICB9XG5cbiAgICAvLyBVcGRhdGUgc3RhdHVzXG4gICAgY29uc3QgdXBkYXRlRGF0YTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICBzdGF0dXMsXG4gICAgICBwcm9ncmVzczogc3RhdHVzID09PSBcImNvbXBsZXRlZFwiID8gMTAwIDogdW5kZWZpbmVkLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG5cbiAgICBpZiAoc3RhdHVzID09PSBcImNvbXBsZXRlZFwiKSB7XG4gICAgICB1cGRhdGVEYXRhLnZpZGVvX3VybCA9IHZpZGVvX3VybDtcbiAgICAgIHVwZGF0ZURhdGEudGh1bWJuYWlsX3VybCA9IHRodW1ibmFpbF91cmw7XG4gICAgICB1cGRhdGVEYXRhLmZpbGVfc2l6ZV9ieXRlcyA9IGZpbGVfc2l6ZV9ieXRlcztcbiAgICAgIHVwZGF0ZURhdGEuY29tcGxldGVkX2F0ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuXG4gICAgICAvLyBTZW5kIG5vdGlmaWNhdGlvbiB0byB1c2VyXG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwibm90aWZpY2F0aW9uc1wiKS5pbnNlcnQoe1xuICAgICAgICB1c2VyX2lkOiBwcm9tb1ZpZGVvLnVzZXJfaWQsXG4gICAgICAgIHR5cGU6IFwic3lzdGVtXCIsXG4gICAgICAgIHRpdGxlOiBcIvCfjqwg0J/RgNC+0LzQvi3QstC40LTQtdC+INCz0L7RgtC+0LLQviFcIixcbiAgICAgICAgbWVzc2FnZTogXCLQktCw0YjQtSDQv9GA0L7QvNC+LdCy0LjQtNC10L4g0YPRgdC/0LXRiNC90L4g0YHQvtC30LTQsNC90L4g0Lgg0LPQvtGC0L7QstC+INC6INGB0LrQsNGH0LjQstCw0L3QuNGOXCIsXG4gICAgICAgIHRhcmdldF90eXBlOiBcInByb21vX3ZpZGVvXCIsXG4gICAgICAgIHRhcmdldF9pZDogcHJvbW9fdmlkZW9faWQsXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKHN0YXR1cyA9PT0gXCJmYWlsZWRcIikge1xuICAgICAgdXBkYXRlRGF0YS5lcnJvcl9tZXNzYWdlID0gZXJyb3JfbWVzc2FnZSB8fCBcIlVua25vd24gZXJyb3JcIjtcblxuICAgICAgLy8gTm90aWZ5IHVzZXIgYWJvdXQgZmFpbHVyZVxuICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcIm5vdGlmaWNhdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogcHJvbW9WaWRlby51c2VyX2lkLFxuICAgICAgICB0eXBlOiBcInN5c3RlbVwiLFxuICAgICAgICB0aXRsZTogXCLQntGI0LjQsdC60LAg0LPQtdC90LXRgNCw0YbQuNC4INCy0LjQtNC10L5cIixcbiAgICAgICAgbWVzc2FnZTogZXJyb3JfbWVzc2FnZSB8fCBcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0YHQvtC30LTQsNGC0Ywg0L/RgNC+0LzQvi3QstC40LTQtdC+LiDQn9C+0L/RgNC+0LHRg9C50YLQtSDQtdGJ0ZEg0YDQsNC3LlwiLFxuICAgICAgICB0YXJnZXRfdHlwZTogXCJwcm9tb192aWRlb1wiLFxuICAgICAgICB0YXJnZXRfaWQ6IHByb21vX3ZpZGVvX2lkLFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInByb21vX3ZpZGVvc1wiKVxuICAgICAgLnVwZGF0ZSh1cGRhdGVEYXRhKVxuICAgICAgLmVxKFwiaWRcIiwgcHJvbW9fdmlkZW9faWQpO1xuXG4gICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiVXBkYXRlIGVycm9yOlwiLCB1cGRhdGVFcnJvcik7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIHByb21vIHZpZGVvXCIpO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBQcm9tbyB2aWRlbyAke3Byb21vX3ZpZGVvX2lkfSB1cGRhdGVkIHRvICR7c3RhdHVzfWApO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgY29uc29sZS5lcnJvcihcIlByb21vIHZpZGVvIGNhbGxiYWNrIGVycm9yOlwiLCBlcnJvck1lc3NhZ2UpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3JNZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxLQUFLLFFBQVEsK0NBQStDO0FBQ3JFLFNBQVMsWUFBWSxRQUFRLDhDQUE4QztBQUUzRSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQVdBLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDakMsTUFBTSxxQkFBcUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ3hDLE1BQU0sV0FBVyxhQUFhLGFBQWE7SUFFM0MsTUFBTSxPQUFxQixNQUFNLElBQUksSUFBSTtJQUN6QyxNQUFNLEVBQUUsY0FBYyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLGVBQWUsRUFBRSxhQUFhLEVBQUUsR0FBRztJQUU3RixJQUFJLENBQUMsZ0JBQWdCO01BQ25CLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsRUFBRSxlQUFlLFVBQVUsRUFBRSxPQUFPLENBQUM7SUFFeEUseUJBQXlCO0lBQ3pCLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxPQUFPLFVBQVUsRUFBRSxHQUFHLE1BQU0sU0FDbkQsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyx5QkFDUCxFQUFFLENBQUMsTUFBTSxnQkFDVCxNQUFNO0lBRVQsSUFBSSxjQUFjLENBQUMsWUFBWTtNQUM3QixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLGdCQUFnQjtJQUNoQixNQUFNLGFBQXNDO01BQzFDO01BQ0EsVUFBVSxXQUFXLGNBQWMsTUFBTTtNQUN6QyxZQUFZLElBQUksT0FBTyxXQUFXO0lBQ3BDO0lBRUEsSUFBSSxXQUFXLGFBQWE7TUFDMUIsV0FBVyxTQUFTLEdBQUc7TUFDdkIsV0FBVyxhQUFhLEdBQUc7TUFDM0IsV0FBVyxlQUFlLEdBQUc7TUFDN0IsV0FBVyxZQUFZLEdBQUcsSUFBSSxPQUFPLFdBQVc7TUFFaEQsNEJBQTRCO01BQzVCLE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztRQUMxQyxTQUFTLFdBQVcsT0FBTztRQUMzQixNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVM7UUFDVCxhQUFhO1FBQ2IsV0FBVztNQUNiO0lBQ0YsT0FBTyxJQUFJLFdBQVcsVUFBVTtNQUM5QixXQUFXLGFBQWEsR0FBRyxpQkFBaUI7TUFFNUMsNEJBQTRCO01BQzVCLE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztRQUMxQyxTQUFTLFdBQVcsT0FBTztRQUMzQixNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVMsaUJBQWlCO1FBQzFCLGFBQWE7UUFDYixXQUFXO01BQ2I7SUFDRjtJQUVBLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyxZQUNQLEVBQUUsQ0FBQyxNQUFNO0lBRVosSUFBSSxhQUFhO01BQ2YsUUFBUSxLQUFLLENBQUMsaUJBQWlCO01BQy9CLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxZQUFZLEVBQUUsZUFBZSxZQUFZLEVBQUUsT0FBTyxDQUFDO0lBRWhFLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsU0FBUztJQUFLLElBQy9CO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsTUFBTSxlQUFlLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQzlELFFBQVEsS0FBSyxDQUFDLCtCQUErQjtJQUM3QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLFNBQVM7TUFBTyxPQUFPO0lBQWEsSUFDckQ7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
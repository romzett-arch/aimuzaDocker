import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { personaId, trackId, name, description, avatarUrl, styleTags, isPublic } = await req.json();
    console.log(`Creating persona for user ${user.id}, track ${trackId}`);
    if (!trackId || !name) {
      return new Response(JSON.stringify({
        error: "Missing required fields: trackId, name"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Get track info to extract taskId and audioId
    const { data: track, error: trackError } = await supabaseClient.from("tracks").select("id, title, description, status, suno_audio_id").eq("id", trackId).eq("user_id", user.id).single();
    if (trackError || !track) {
      console.error("Track not found:", trackError);
      return new Response(JSON.stringify({
        error: "Трек не найден"
      }), {
        status: 404,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Allow "ready" or "completed" status
    if (track.status !== "ready" && track.status !== "completed") {
      return new Response(JSON.stringify({
        error: "Трек должен быть полностью сгенерирован для создания персоны"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Extract taskId from track description (stored in format [task_id: {taskId}])
    const taskIdMatch = track.description?.match(/\[task_id:\s*([^\]]+)\]/);
    const taskId = taskIdMatch ? taskIdMatch[1].trim() : null;
    // Get audioId from track (stored as suno_audio_id)
    const audioId = track.suno_audio_id;
    if (!taskId || !audioId) {
      console.error(`Missing Suno IDs for track ${trackId}: taskId=${taskId}, audioId=${audioId}`);
      return new Response(JSON.stringify({
        error: "Для этого трека недоступна функция создания персоны. Трек был создан до добавления этой функции."
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Found Suno IDs: taskId=${taskId}, audioId=${audioId}`);
    // Call Suno API to create persona
    const sunoPayload = {
      taskId,
      audioId,
      name: name.trim(),
      description: description?.trim() || `Голос из трека "${track.title}"`
    };
    console.log("Sending to Suno API:", JSON.stringify(sunoPayload));
    const sunoResponse = await fetch(`${SUNO_API_BASE}/api/v1/generate/generate-persona`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify(sunoPayload)
    });
    const sunoData = await sunoResponse.json();
    console.log("Suno API response:", JSON.stringify(sunoData));
    if (!sunoResponse.ok || sunoData.code !== 200) {
      const errorMessage = sunoData.msg || "Failed to create persona";
      console.error(`Suno API error: ${errorMessage}`);
      // Update persona status to failed if it exists
      if (personaId) {
        await supabaseClient.from("personas").update({
          status: "failed"
        }).eq("id", personaId).eq("user_id", user.id);
      }
      return new Response(JSON.stringify({
        error: `Ошибка Suno: ${errorMessage}`
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Extract persona ID from response
    const sunoPersonaId = sunoData.data?.personaId || sunoData.data?.id;
    if (!sunoPersonaId) {
      console.error("No persona ID in Suno response:", sunoData);
      return new Response(JSON.stringify({
        error: "Suno не вернул ID персоны"
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Persona created with Suno ID: ${sunoPersonaId}`);
    // If personaId provided, update existing record
    // Otherwise create new record
    let savedPersona;
    if (personaId) {
      const { data, error } = await supabaseClient.from("personas").update({
        suno_persona_id: sunoPersonaId,
        status: "ready",
        updated_at: new Date().toISOString()
      }).eq("id", personaId).eq("user_id", user.id).select().single();
      if (error) {
        console.error("Failed to update persona:", error);
      }
      savedPersona = data;
    } else {
      const { data, error } = await supabaseClient.from("personas").insert({
        user_id: user.id,
        name: name.trim(),
        avatar_url: avatarUrl || null,
        source_track_id: trackId,
        clip_start_time: 0,
        clip_end_time: 30,
        description: description?.trim() || null,
        style_tags: styleTags?.trim() || null,
        is_public: isPublic || false,
        suno_persona_id: sunoPersonaId,
        status: "ready"
      }).select().single();
      if (error) {
        console.error("Failed to create persona record:", error);
      }
      savedPersona = data;
    }
    return new Response(JSON.stringify({
      success: true,
      personaId: savedPersona?.id,
      sunoPersonaId,
      message: "Персона успешно создана"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in create-persona:", error);
    return new Response(JSON.stringify({
      error: "Произошла непредвиденная ошибка"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9jcmVhdGUtcGVyc29uYS9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmNvbnN0IFNVTk9fQVBJX0tFWSA9IERlbm8uZW52LmdldChcIlNVTk9fQVBJX0tFWVwiKTtcbmNvbnN0IFNVTk9fQVBJX0JBU0UgPSBcImh0dHBzOi8vYXBpYm94LmVyd2VpbWEuYWlcIjtcblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJObyBhdXRob3JpemF0aW9uIGhlYWRlclwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgc3VwYWJhc2VDbGllbnQgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgPz8gXCJcIixcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX0FOT05fS0VZXCIpID8/IFwiXCIsXG4gICAgICB7IGdsb2JhbDogeyBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGF1dGhIZWFkZXIgfSB9IH1cbiAgICApO1xuXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IHVzZXJFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnQuYXV0aC5nZXRVc2VyKCk7XG4gICAgaWYgKHVzZXJFcnJvciB8fCAhdXNlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHsgXG4gICAgICBwZXJzb25hSWQsXG4gICAgICB0cmFja0lkLCBcbiAgICAgIG5hbWUsIFxuICAgICAgZGVzY3JpcHRpb24sXG4gICAgICBhdmF0YXJVcmwsXG4gICAgICBzdHlsZVRhZ3MsXG4gICAgICBpc1B1YmxpY1xuICAgIH0gPSBhd2FpdCByZXEuanNvbigpO1xuXG4gICAgY29uc29sZS5sb2coYENyZWF0aW5nIHBlcnNvbmEgZm9yIHVzZXIgJHt1c2VyLmlkfSwgdHJhY2sgJHt0cmFja0lkfWApO1xuXG4gICAgaWYgKCF0cmFja0lkIHx8ICFuYW1lKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk1pc3NpbmcgcmVxdWlyZWQgZmllbGRzOiB0cmFja0lkLCBuYW1lXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgdHJhY2sgaW5mbyB0byBleHRyYWN0IHRhc2tJZCBhbmQgYXVkaW9JZFxuICAgIGNvbnN0IHsgZGF0YTogdHJhY2ssIGVycm9yOiB0cmFja0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgIC5zZWxlY3QoXCJpZCwgdGl0bGUsIGRlc2NyaXB0aW9uLCBzdGF0dXMsIHN1bm9fYXVkaW9faWRcIilcbiAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAodHJhY2tFcnJvciB8fCAhdHJhY2spIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJUcmFjayBub3QgZm91bmQ6XCIsIHRyYWNrRXJyb3IpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQotGA0LXQuiDQvdC1INC90LDQudC00LXQvVwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDA0LCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gQWxsb3cgXCJyZWFkeVwiIG9yIFwiY29tcGxldGVkXCIgc3RhdHVzXG4gICAgaWYgKHRyYWNrLnN0YXR1cyAhPT0gXCJyZWFkeVwiICYmIHRyYWNrLnN0YXR1cyAhPT0gXCJjb21wbGV0ZWRcIikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQotGA0LXQuiDQtNC+0LvQttC10L0g0LHRi9GC0Ywg0L/QvtC70L3QvtGB0YLRjNGOINGB0LPQtdC90LXRgNC40YDQvtCy0LDQvSDQtNC70Y8g0YHQvtC30LTQsNC90LjRjyDQv9C10YDRgdC+0L3Ri1wiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gRXh0cmFjdCB0YXNrSWQgZnJvbSB0cmFjayBkZXNjcmlwdGlvbiAoc3RvcmVkIGluIGZvcm1hdCBbdGFza19pZDoge3Rhc2tJZH1dKVxuICAgIGNvbnN0IHRhc2tJZE1hdGNoID0gdHJhY2suZGVzY3JpcHRpb24/Lm1hdGNoKC9cXFt0YXNrX2lkOlxccyooW15cXF1dKylcXF0vKTtcbiAgICBjb25zdCB0YXNrSWQgPSB0YXNrSWRNYXRjaCA/IHRhc2tJZE1hdGNoWzFdLnRyaW0oKSA6IG51bGw7XG5cbiAgICAvLyBHZXQgYXVkaW9JZCBmcm9tIHRyYWNrIChzdG9yZWQgYXMgc3Vub19hdWRpb19pZClcbiAgICBjb25zdCBhdWRpb0lkID0gdHJhY2suc3Vub19hdWRpb19pZDtcblxuICAgIGlmICghdGFza0lkIHx8ICFhdWRpb0lkKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBNaXNzaW5nIFN1bm8gSURzIGZvciB0cmFjayAke3RyYWNrSWR9OiB0YXNrSWQ9JHt0YXNrSWR9LCBhdWRpb0lkPSR7YXVkaW9JZH1gKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwi0JTQu9GPINGN0YLQvtCz0L4g0YLRgNC10LrQsCDQvdC10LTQvtGB0YLRg9C/0L3QsCDRhNGD0L3QutGG0LjRjyDRgdC+0LfQtNCw0L3QuNGPINC/0LXRgNGB0L7QvdGLLiDQotGA0LXQuiDQsdGL0Lsg0YHQvtC30LTQsNC9INC00L4g0LTQvtCx0LDQstC70LXQvdC40Y8g0Y3RgtC+0Lkg0YTRg9C90LrRhtC40LguXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgRm91bmQgU3VubyBJRHM6IHRhc2tJZD0ke3Rhc2tJZH0sIGF1ZGlvSWQ9JHthdWRpb0lkfWApO1xuXG4gICAgLy8gQ2FsbCBTdW5vIEFQSSB0byBjcmVhdGUgcGVyc29uYVxuICAgIGNvbnN0IHN1bm9QYXlsb2FkID0ge1xuICAgICAgdGFza0lkLFxuICAgICAgYXVkaW9JZCxcbiAgICAgIG5hbWU6IG5hbWUudHJpbSgpLFxuICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uPy50cmltKCkgfHwgYNCT0L7Qu9C+0YEg0LjQtyDRgtGA0LXQutCwIFwiJHt0cmFjay50aXRsZX1cImBcbiAgICB9O1xuXG4gICAgY29uc29sZS5sb2coXCJTZW5kaW5nIHRvIFN1bm8gQVBJOlwiLCBKU09OLnN0cmluZ2lmeShzdW5vUGF5bG9hZCkpO1xuXG4gICAgY29uc3Qgc3Vub1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7U1VOT19BUElfQkFTRX0vYXBpL3YxL2dlbmVyYXRlL2dlbmVyYXRlLXBlcnNvbmFgLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJBdXRob3JpemF0aW9uXCI6IGBCZWFyZXIgJHtTVU5PX0FQSV9LRVl9YCxcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShzdW5vUGF5bG9hZCksXG4gICAgfSk7XG5cbiAgICBjb25zdCBzdW5vRGF0YSA9IGF3YWl0IHN1bm9SZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJTdW5vIEFQSSByZXNwb25zZTpcIiwgSlNPTi5zdHJpbmdpZnkoc3Vub0RhdGEpKTtcblxuICAgIGlmICghc3Vub1Jlc3BvbnNlLm9rIHx8IHN1bm9EYXRhLmNvZGUgIT09IDIwMCkge1xuICAgICAgY29uc3QgZXJyb3JNZXNzYWdlID0gc3Vub0RhdGEubXNnIHx8IFwiRmFpbGVkIHRvIGNyZWF0ZSBwZXJzb25hXCI7XG4gICAgICBjb25zb2xlLmVycm9yKGBTdW5vIEFQSSBlcnJvcjogJHtlcnJvck1lc3NhZ2V9YCk7XG4gICAgICBcbiAgICAgIC8vIFVwZGF0ZSBwZXJzb25hIHN0YXR1cyB0byBmYWlsZWQgaWYgaXQgZXhpc3RzXG4gICAgICBpZiAocGVyc29uYUlkKSB7XG4gICAgICAgIGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgICAgLmZyb20oXCJwZXJzb25hc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwiZmFpbGVkXCIgfSlcbiAgICAgICAgICAuZXEoXCJpZFwiLCBwZXJzb25hSWQpXG4gICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogYNCe0YjQuNCx0LrQsCBTdW5vOiAke2Vycm9yTWVzc2FnZX1gIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gRXh0cmFjdCBwZXJzb25hIElEIGZyb20gcmVzcG9uc2VcbiAgICBjb25zdCBzdW5vUGVyc29uYUlkID0gc3Vub0RhdGEuZGF0YT8ucGVyc29uYUlkIHx8IHN1bm9EYXRhLmRhdGE/LmlkO1xuICAgIFxuICAgIGlmICghc3Vub1BlcnNvbmFJZCkge1xuICAgICAgY29uc29sZS5lcnJvcihcIk5vIHBlcnNvbmEgSUQgaW4gU3VubyByZXNwb25zZTpcIiwgc3Vub0RhdGEpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJTdW5vINC90LUg0LLQtdGA0L3Rg9C7IElEINC/0LXRgNGB0L7QvdGLXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgUGVyc29uYSBjcmVhdGVkIHdpdGggU3VubyBJRDogJHtzdW5vUGVyc29uYUlkfWApO1xuXG4gICAgLy8gSWYgcGVyc29uYUlkIHByb3ZpZGVkLCB1cGRhdGUgZXhpc3RpbmcgcmVjb3JkXG4gICAgLy8gT3RoZXJ3aXNlIGNyZWF0ZSBuZXcgcmVjb3JkXG4gICAgbGV0IHNhdmVkUGVyc29uYTtcbiAgICBcbiAgICBpZiAocGVyc29uYUlkKSB7XG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAuZnJvbShcInBlcnNvbmFzXCIpXG4gICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgIHN1bm9fcGVyc29uYV9pZDogc3Vub1BlcnNvbmFJZCxcbiAgICAgICAgICBzdGF0dXM6IFwicmVhZHlcIixcbiAgICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgcGVyc29uYUlkKVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpXG4gICAgICAgIC5zZWxlY3QoKVxuICAgICAgICAuc2luZ2xlKCk7XG4gICAgICBcbiAgICAgIGlmIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSBwZXJzb25hOlwiLCBlcnJvcik7XG4gICAgICB9XG4gICAgICBzYXZlZFBlcnNvbmEgPSBkYXRhO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAuZnJvbShcInBlcnNvbmFzXCIpXG4gICAgICAgIC5pbnNlcnQoe1xuICAgICAgICAgIHVzZXJfaWQ6IHVzZXIuaWQsXG4gICAgICAgICAgbmFtZTogbmFtZS50cmltKCksXG4gICAgICAgICAgYXZhdGFyX3VybDogYXZhdGFyVXJsIHx8IG51bGwsXG4gICAgICAgICAgc291cmNlX3RyYWNrX2lkOiB0cmFja0lkLFxuICAgICAgICAgIGNsaXBfc3RhcnRfdGltZTogMCxcbiAgICAgICAgICBjbGlwX2VuZF90aW1lOiAzMCxcbiAgICAgICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24/LnRyaW0oKSB8fCBudWxsLFxuICAgICAgICAgIHN0eWxlX3RhZ3M6IHN0eWxlVGFncz8udHJpbSgpIHx8IG51bGwsXG4gICAgICAgICAgaXNfcHVibGljOiBpc1B1YmxpYyB8fCBmYWxzZSxcbiAgICAgICAgICBzdW5vX3BlcnNvbmFfaWQ6IHN1bm9QZXJzb25hSWQsXG4gICAgICAgICAgc3RhdHVzOiBcInJlYWR5XCJcbiAgICAgICAgfSlcbiAgICAgICAgLnNlbGVjdCgpXG4gICAgICAgIC5zaW5nbGUoKTtcbiAgICAgIFxuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gY3JlYXRlIHBlcnNvbmEgcmVjb3JkOlwiLCBlcnJvcik7XG4gICAgICB9XG4gICAgICBzYXZlZFBlcnNvbmEgPSBkYXRhO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgcGVyc29uYUlkOiBzYXZlZFBlcnNvbmE/LmlkLFxuICAgICAgICBzdW5vUGVyc29uYUlkLFxuICAgICAgICBtZXNzYWdlOiBcItCf0LXRgNGB0L7QvdCwINGD0YHQv9C10YjQvdC+INGB0L7Qt9C00LDQvdCwXCIgXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBjcmVhdGUtcGVyc29uYTpcIiwgZXJyb3IpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCf0YDQvtC40LfQvtGI0LvQsCDQvdC10L/RgNC10LTQstC40LTQtdC90L3QsNGPINC+0YjQuNCx0LrQsFwiIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxLQUFLLFFBQVEsK0NBQStDO0FBQ3JFLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDbEMsTUFBTSxnQkFBZ0I7QUFFdEIsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEwQixJQUNsRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGlCQUFpQixhQUNyQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFDckM7TUFBRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQUU7SUFHdkQsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sZUFBZSxJQUFJLENBQUMsT0FBTztJQUM5RSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFlLElBQ3ZDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sRUFDSixTQUFTLEVBQ1QsT0FBTyxFQUNQLElBQUksRUFDSixXQUFXLEVBQ1gsU0FBUyxFQUNULFNBQVMsRUFDVCxRQUFRLEVBQ1QsR0FBRyxNQUFNLElBQUksSUFBSTtJQUVsQixRQUFRLEdBQUcsQ0FBQyxDQUFDLDBCQUEwQixFQUFFLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUM7SUFFcEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNO01BQ3JCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUF5QyxJQUNqRTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSwrQ0FBK0M7SUFDL0MsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxlQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsaURBQ1AsRUFBRSxDQUFDLE1BQU0sU0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtJQUVULElBQUksY0FBYyxDQUFDLE9BQU87TUFDeEIsUUFBUSxLQUFLLENBQUMsb0JBQW9CO01BQ2xDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFpQixJQUN6QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxzQ0FBc0M7SUFDdEMsSUFBSSxNQUFNLE1BQU0sS0FBSyxXQUFXLE1BQU0sTUFBTSxLQUFLLGFBQWE7TUFDNUQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQStELElBQ3ZGO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLCtFQUErRTtJQUMvRSxNQUFNLGNBQWMsTUFBTSxXQUFXLEVBQUUsTUFBTTtJQUM3QyxNQUFNLFNBQVMsY0FBYyxXQUFXLENBQUMsRUFBRSxDQUFDLElBQUksS0FBSztJQUVyRCxtREFBbUQ7SUFDbkQsTUFBTSxVQUFVLE1BQU0sYUFBYTtJQUVuQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVM7TUFDdkIsUUFBUSxLQUFLLENBQUMsQ0FBQywyQkFBMkIsRUFBRSxRQUFRLFNBQVMsRUFBRSxPQUFPLFVBQVUsRUFBRSxRQUFRLENBQUM7TUFDM0YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQW1HLElBQzNIO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsT0FBTyxVQUFVLEVBQUUsUUFBUSxDQUFDO0lBRWxFLGtDQUFrQztJQUNsQyxNQUFNLGNBQWM7TUFDbEI7TUFDQTtNQUNBLE1BQU0sS0FBSyxJQUFJO01BQ2YsYUFBYSxhQUFhLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDdkU7SUFFQSxRQUFRLEdBQUcsQ0FBQyx3QkFBd0IsS0FBSyxTQUFTLENBQUM7SUFFbkQsTUFBTSxlQUFlLE1BQU0sTUFBTSxDQUFDLEVBQUUsY0FBYyxpQ0FBaUMsQ0FBQyxFQUFFO01BQ3BGLFFBQVE7TUFDUixTQUFTO1FBQ1AsZ0JBQWdCO1FBQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO0lBQ3ZCO0lBRUEsTUFBTSxXQUFXLE1BQU0sYUFBYSxJQUFJO0lBQ3hDLFFBQVEsR0FBRyxDQUFDLHNCQUFzQixLQUFLLFNBQVMsQ0FBQztJQUVqRCxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksU0FBUyxJQUFJLEtBQUssS0FBSztNQUM3QyxNQUFNLGVBQWUsU0FBUyxHQUFHLElBQUk7TUFDckMsUUFBUSxLQUFLLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLENBQUM7TUFFL0MsK0NBQStDO01BQy9DLElBQUksV0FBVztRQUNiLE1BQU0sZUFDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7VUFBRSxRQUFRO1FBQVMsR0FDMUIsRUFBRSxDQUFDLE1BQU0sV0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUU7TUFDMUI7TUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU8sQ0FBQyxhQUFhLEVBQUUsYUFBYSxDQUFDO01BQUMsSUFDdkQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsbUNBQW1DO0lBQ25DLE1BQU0sZ0JBQWdCLFNBQVMsSUFBSSxFQUFFLGFBQWEsU0FBUyxJQUFJLEVBQUU7SUFFakUsSUFBSSxDQUFDLGVBQWU7TUFDbEIsUUFBUSxLQUFLLENBQUMsbUNBQW1DO01BQ2pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE0QixJQUNwRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDhCQUE4QixFQUFFLGNBQWMsQ0FBQztJQUU1RCxnREFBZ0Q7SUFDaEQsOEJBQThCO0lBQzlCLElBQUk7SUFFSixJQUFJLFdBQVc7TUFDYixNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sZUFDM0IsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1FBQ04saUJBQWlCO1FBQ2pCLFFBQVE7UUFDUixZQUFZLElBQUksT0FBTyxXQUFXO01BQ3BDLEdBQ0MsRUFBRSxDQUFDLE1BQU0sV0FDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTSxHQUNOLE1BQU07TUFFVCxJQUFJLE9BQU87UUFDVCxRQUFRLEtBQUssQ0FBQyw2QkFBNkI7TUFDN0M7TUFDQSxlQUFlO0lBQ2pCLE9BQU87TUFDTCxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sZUFDM0IsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO1FBQ04sU0FBUyxLQUFLLEVBQUU7UUFDaEIsTUFBTSxLQUFLLElBQUk7UUFDZixZQUFZLGFBQWE7UUFDekIsaUJBQWlCO1FBQ2pCLGlCQUFpQjtRQUNqQixlQUFlO1FBQ2YsYUFBYSxhQUFhLFVBQVU7UUFDcEMsWUFBWSxXQUFXLFVBQVU7UUFDakMsV0FBVyxZQUFZO1FBQ3ZCLGlCQUFpQjtRQUNqQixRQUFRO01BQ1YsR0FDQyxNQUFNLEdBQ04sTUFBTTtNQUVULElBQUksT0FBTztRQUNULFFBQVEsS0FBSyxDQUFDLG9DQUFvQztNQUNwRDtNQUNBLGVBQWU7SUFDakI7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVCxXQUFXLGNBQWM7TUFDekI7TUFDQSxTQUFTO0lBQ1gsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLDRCQUE0QjtJQUMxQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBa0MsSUFDMUQ7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
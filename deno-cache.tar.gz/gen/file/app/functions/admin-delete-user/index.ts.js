import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type"
};
Deno.serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    // Verify caller is admin
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const anonClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY"));
    const { data: { user: caller }, error: authError } = await anonClient.auth.getUser(authHeader.replace("Bearer ", ""));
    if (authError || !caller) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Check caller is admin/super_admin
    const adminClient = createClient(supabaseUrl, serviceRoleKey);
    const { data: roleData } = await adminClient.from("user_roles").select("role").eq("user_id", caller.id).maybeSingle();
    if (!roleData || ![
      "admin",
      "super_admin"
    ].includes(roleData.role)) {
      return new Response(JSON.stringify({
        error: "Forbidden: admin role required"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { userId } = await req.json();
    if (!userId) {
      return new Response(JSON.stringify({
        error: "userId is required"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Protect super_admin from deletion
    const { data: targetRole } = await adminClient.from("user_roles").select("role").eq("user_id", userId).maybeSingle();
    if (targetRole?.role === "super_admin") {
      return new Response(JSON.stringify({
        error: "Cannot delete super_admin"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Delete from auth.users (CASCADE will handle related data)
    const { error: deleteError } = await adminClient.auth.admin.deleteUser(userId);
    if (deleteError) {
      console.error("Delete user error:", deleteError);
      return new Response(JSON.stringify({
        error: deleteError.message
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Also clean up application data that might not cascade
    const cleanupTables = [
      "user_roles",
      "profiles",
      "notifications",
      "user_blocks",
      "forum_posts",
      "forum_user_stats",
      "forum_activity_log",
      "forum_warnings",
      "forum_bookmarks",
      "forum_drafts",
      "forum_category_subscriptions",
      "forum_attachments",
      "balance_transactions",
      "feature_trials"
    ];
    await Promise.all(cleanupTables.map((t)=>adminClient.from(t).delete().eq("user_id", userId)));
    return new Response(JSON.stringify({
      success: true,
      message: "User fully deleted"
    }), {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (err) {
    console.error("admin-delete-user error:", err);
    return new Response(JSON.stringify({
      error: err.message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9hZG1pbi1kZWxldGUtdXNlci9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZVwiLFxufTtcblxuRGVuby5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICAgIGNvbnN0IHNlcnZpY2VSb2xlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG5cbiAgICAvLyBWZXJpZnkgY2FsbGVyIGlzIGFkbWluXG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksIHtcbiAgICAgICAgc3RhdHVzOiA0MDEsXG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBjb25zdCBhbm9uQ2xpZW50ID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSEpO1xuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyOiBjYWxsZXIgfSwgZXJyb3I6IGF1dGhFcnJvciB9ID0gYXdhaXQgYW5vbkNsaWVudC5hdXRoLmdldFVzZXIoXG4gICAgICBhdXRoSGVhZGVyLnJlcGxhY2UoXCJCZWFyZXIgXCIsIFwiXCIpXG4gICAgKTtcblxuICAgIGlmIChhdXRoRXJyb3IgfHwgIWNhbGxlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLCB7XG4gICAgICAgIHN0YXR1czogNDAxLFxuICAgICAgICBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgY2FsbGVyIGlzIGFkbWluL3N1cGVyX2FkbWluXG4gICAgY29uc3QgYWRtaW5DbGllbnQgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHNlcnZpY2VSb2xlS2V5KTtcbiAgICBjb25zdCB7IGRhdGE6IHJvbGVEYXRhIH0gPSBhd2FpdCBhZG1pbkNsaWVudFxuICAgICAgLmZyb20oXCJ1c2VyX3JvbGVzXCIpXG4gICAgICAuc2VsZWN0KFwicm9sZVwiKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCBjYWxsZXIuaWQpXG4gICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgIGlmICghcm9sZURhdGEgfHwgIVtcImFkbWluXCIsIFwic3VwZXJfYWRtaW5cIl0uaW5jbHVkZXMocm9sZURhdGEucm9sZSkpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJGb3JiaWRkZW46IGFkbWluIHJvbGUgcmVxdWlyZWRcIiB9KSwge1xuICAgICAgICBzdGF0dXM6IDQwMyxcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGNvbnN0IHsgdXNlcklkIH0gPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGlmICghdXNlcklkKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwidXNlcklkIGlzIHJlcXVpcmVkXCIgfSksIHtcbiAgICAgICAgc3RhdHVzOiA0MDAsXG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBQcm90ZWN0IHN1cGVyX2FkbWluIGZyb20gZGVsZXRpb25cbiAgICBjb25zdCB7IGRhdGE6IHRhcmdldFJvbGUgfSA9IGF3YWl0IGFkbWluQ2xpZW50XG4gICAgICAuZnJvbShcInVzZXJfcm9sZXNcIilcbiAgICAgIC5zZWxlY3QoXCJyb2xlXCIpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZClcbiAgICAgIC5tYXliZVNpbmdsZSgpO1xuXG4gICAgaWYgKHRhcmdldFJvbGU/LnJvbGUgPT09IFwic3VwZXJfYWRtaW5cIikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIkNhbm5vdCBkZWxldGUgc3VwZXJfYWRtaW5cIiB9KSwge1xuICAgICAgICBzdGF0dXM6IDQwMyxcbiAgICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8vIERlbGV0ZSBmcm9tIGF1dGgudXNlcnMgKENBU0NBREUgd2lsbCBoYW5kbGUgcmVsYXRlZCBkYXRhKVxuICAgIGNvbnN0IHsgZXJyb3I6IGRlbGV0ZUVycm9yIH0gPSBhd2FpdCBhZG1pbkNsaWVudC5hdXRoLmFkbWluLmRlbGV0ZVVzZXIodXNlcklkKTtcblxuICAgIGlmIChkZWxldGVFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkRlbGV0ZSB1c2VyIGVycm9yOlwiLCBkZWxldGVFcnJvcik7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGRlbGV0ZUVycm9yLm1lc3NhZ2UgfSksIHtcbiAgICAgICAgc3RhdHVzOiA1MDAsXG4gICAgICAgIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBBbHNvIGNsZWFuIHVwIGFwcGxpY2F0aW9uIGRhdGEgdGhhdCBtaWdodCBub3QgY2FzY2FkZVxuICAgIGNvbnN0IGNsZWFudXBUYWJsZXMgPSBbXG4gICAgICBcInVzZXJfcm9sZXNcIiwgXCJwcm9maWxlc1wiLCBcIm5vdGlmaWNhdGlvbnNcIiwgXCJ1c2VyX2Jsb2Nrc1wiLFxuICAgICAgXCJmb3J1bV9wb3N0c1wiLCBcImZvcnVtX3VzZXJfc3RhdHNcIiwgXCJmb3J1bV9hY3Rpdml0eV9sb2dcIixcbiAgICAgIFwiZm9ydW1fd2FybmluZ3NcIiwgXCJmb3J1bV9ib29rbWFya3NcIiwgXCJmb3J1bV9kcmFmdHNcIixcbiAgICAgIFwiZm9ydW1fY2F0ZWdvcnlfc3Vic2NyaXB0aW9uc1wiLCBcImZvcnVtX2F0dGFjaG1lbnRzXCIsXG4gICAgICBcImJhbGFuY2VfdHJhbnNhY3Rpb25zXCIsIFwiZmVhdHVyZV90cmlhbHNcIixcbiAgICBdO1xuICAgIGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgY2xlYW51cFRhYmxlcy5tYXAodCA9PiBhZG1pbkNsaWVudC5mcm9tKHQpLmRlbGV0ZSgpLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpKVxuICAgICk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiB0cnVlLCBtZXNzYWdlOiBcIlVzZXIgZnVsbHkgZGVsZXRlZFwiIH0pLFxuICAgICAgeyBzdGF0dXM6IDIwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcihcImFkbWluLWRlbGV0ZS11c2VyIGVycm9yOlwiLCBlcnIpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogZXJyLm1lc3NhZ2UgfSksIHtcbiAgICAgIHN0YXR1czogNTAwLFxuICAgICAgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICB9KTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsS0FBSyxLQUFLLENBQUMsT0FBTztFQUNoQixJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0saUJBQWlCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUVwQyx5QkFBeUI7SUFDekIsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE9BQU8sSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFlLElBQUk7UUFDN0QsUUFBUTtRQUNSLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFDaEU7SUFDRjtJQUVBLE1BQU0sYUFBYSxhQUFhLGFBQWEsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQzFELE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxNQUFNLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sV0FBVyxJQUFJLENBQUMsT0FBTyxDQUNoRixXQUFXLE9BQU8sQ0FBQyxXQUFXO0lBR2hDLElBQUksYUFBYSxDQUFDLFFBQVE7TUFDeEIsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWUsSUFBSTtRQUM3RCxRQUFRO1FBQ1IsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUNoRTtJQUNGO0lBRUEsb0NBQW9DO0lBQ3BDLE1BQU0sY0FBYyxhQUFhLGFBQWE7SUFDOUMsTUFBTSxFQUFFLE1BQU0sUUFBUSxFQUFFLEdBQUcsTUFBTSxZQUM5QixJQUFJLENBQUMsY0FDTCxNQUFNLENBQUMsUUFDUCxFQUFFLENBQUMsV0FBVyxPQUFPLEVBQUUsRUFDdkIsV0FBVztJQUVkLElBQUksQ0FBQyxZQUFZLENBQUM7TUFBQztNQUFTO0tBQWMsQ0FBQyxRQUFRLENBQUMsU0FBUyxJQUFJLEdBQUc7TUFDbEUsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWlDLElBQUk7UUFDL0UsUUFBUTtRQUNSLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFDaEU7SUFDRjtJQUVBLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUNqQyxJQUFJLENBQUMsUUFBUTtNQUNYLE9BQU8sSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFxQixJQUFJO1FBQ25FLFFBQVE7UUFDUixTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQ2hFO0lBQ0Y7SUFFQSxvQ0FBb0M7SUFDcEMsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLEdBQUcsTUFBTSxZQUNoQyxJQUFJLENBQUMsY0FDTCxNQUFNLENBQUMsUUFDUCxFQUFFLENBQUMsV0FBVyxRQUNkLFdBQVc7SUFFZCxJQUFJLFlBQVksU0FBUyxlQUFlO01BQ3RDLE9BQU8sSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE0QixJQUFJO1FBQzFFLFFBQVE7UUFDUixTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQ2hFO0lBQ0Y7SUFFQSw0REFBNEQ7SUFDNUQsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxZQUFZLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDO0lBRXZFLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLHNCQUFzQjtNQUNwQyxPQUFPLElBQUksU0FBUyxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU8sWUFBWSxPQUFPO01BQUMsSUFBSTtRQUNsRSxRQUFRO1FBQ1IsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUNoRTtJQUNGO0lBRUEsd0RBQXdEO0lBQ3hELE1BQU0sZ0JBQWdCO01BQ3BCO01BQWM7TUFBWTtNQUFpQjtNQUMzQztNQUFlO01BQW9CO01BQ25DO01BQWtCO01BQW1CO01BQ3JDO01BQWdDO01BQ2hDO01BQXdCO0tBQ3pCO0lBQ0QsTUFBTSxRQUFRLEdBQUcsQ0FDZixjQUFjLEdBQUcsQ0FBQyxDQUFBLElBQUssWUFBWSxJQUFJLENBQUMsR0FBRyxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQVc7SUFHcEUsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU0sU0FBUztJQUFxQixJQUM5RDtNQUFFLFFBQVE7TUFBSyxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFbkYsRUFBRSxPQUFPLEtBQUs7SUFDWixRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFDMUMsT0FBTyxJQUFJLFNBQVMsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPLElBQUksT0FBTztJQUFDLElBQUk7TUFDMUQsUUFBUTtNQUNSLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFDaEU7RUFDRjtBQUNGIn0=
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabaseClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      console.error("Auth error:", claimsError);
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const userId = claimsData.claims.sub;
    // Check if user is admin using the is_admin function
    const { data: isAdmin } = await supabaseClient.rpc("is_admin", {
      _user_id: userId
    });
    if (!isAdmin) {
      return new Response(JSON.stringify({
        error: "Access denied. Admin only."
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Admin ${userId} requesting Suno credits balance`);
    // Fetch credits from Suno API
    const sunoResponse = await fetch(`${SUNO_API_BASE}/api/v1/generate/credit`, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${SUNO_API_KEY}`
      }
    });
    // Check if response is JSON before parsing
    const contentType = sunoResponse.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      const text = await sunoResponse.text();
      console.error("Suno API returned non-JSON:", text.substring(0, 200));
      return new Response(JSON.stringify({
        error: "Suno API unavailable",
        details: `Status: ${sunoResponse.status}, returned HTML instead of JSON`
      }), {
        status: 503,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const sunoData = await sunoResponse.json();
    console.log("Suno credits response:", JSON.stringify(sunoData));
    if (!sunoResponse.ok || sunoData.code !== 200) {
      console.error("Suno API error:", sunoData);
      return new Response(JSON.stringify({
        error: "Failed to fetch Suno credits",
        details: sunoData.msg || "Unknown error"
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const credits = sunoData.data;
    console.log(`Suno credits remaining: ${credits}`);
    return new Response(JSON.stringify({
      success: true,
      credits: credits
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in suno-credits:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9zdW5vLWNyZWRpdHMvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2VydmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQDAuMTY4LjAvaHR0cC9zZXJ2ZXIudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMlwiO1xuXG5jb25zdCBjb3JzSGVhZGVycyA9IHtcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCIqXCIsXG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiOiBcImF1dGhvcml6YXRpb24sIHgtY2xpZW50LWluZm8sIGFwaWtleSwgY29udGVudC10eXBlLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0tdmVyc2lvbiwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZSwgeC1zdXBhYmFzZS1jbGllbnQtcnVudGltZS12ZXJzaW9uXCIsXG59O1xuXG5jb25zdCBTVU5PX0FQSV9LRVkgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0FQSV9LRVlcIik7XG5jb25zdCBTVU5PX0FQSV9CQVNFID0gXCJodHRwczovL2FwaWJveC5lcndlaW1hLmFpXCI7XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBhdXRoSGVhZGVyID0gcmVxLmhlYWRlcnMuZ2V0KFwiQXV0aG9yaXphdGlvblwiKTtcbiAgICBpZiAoIWF1dGhIZWFkZXI/LnN0YXJ0c1dpdGgoXCJCZWFyZXIgXCIpKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk5vIGF1dGhvcml6YXRpb24gaGVhZGVyXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZUNsaWVudCA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikgPz8gXCJcIixcbiAgICAgIHsgZ2xvYmFsOiB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYXV0aEhlYWRlciB9IH0gfVxuICAgICk7XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgY29uc3QgeyBkYXRhOiBjbGFpbXNEYXRhLCBlcnJvcjogY2xhaW1zRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50LmF1dGguZ2V0Q2xhaW1zKHRva2VuKTtcbiAgICBcbiAgICBpZiAoY2xhaW1zRXJyb3IgfHwgIWNsYWltc0RhdGE/LmNsYWltcz8uc3ViKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiQXV0aCBlcnJvcjpcIiwgY2xhaW1zRXJyb3IpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cbiAgICBcbiAgICBjb25zdCB1c2VySWQgPSBjbGFpbXNEYXRhLmNsYWltcy5zdWI7XG5cbiAgICAvLyBDaGVjayBpZiB1c2VyIGlzIGFkbWluIHVzaW5nIHRoZSBpc19hZG1pbiBmdW5jdGlvblxuICAgIGNvbnN0IHsgZGF0YTogaXNBZG1pbiB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnQucnBjKFwiaXNfYWRtaW5cIiwgeyBfdXNlcl9pZDogdXNlcklkIH0pO1xuICAgIFxuICAgIGlmICghaXNBZG1pbikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJBY2Nlc3MgZGVuaWVkLiBBZG1pbiBvbmx5LlwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYEFkbWluICR7dXNlcklkfSByZXF1ZXN0aW5nIFN1bm8gY3JlZGl0cyBiYWxhbmNlYCk7XG5cbiAgICAvLyBGZXRjaCBjcmVkaXRzIGZyb20gU3VubyBBUElcbiAgICBjb25zdCBzdW5vUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtTVU5PX0FQSV9CQVNFfS9hcGkvdjEvZ2VuZXJhdGUvY3JlZGl0YCwge1xuICAgICAgbWV0aG9kOiBcIkdFVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke1NVTk9fQVBJX0tFWX1gLFxuICAgICAgfSxcbiAgICB9KTtcblxuICAgIC8vIENoZWNrIGlmIHJlc3BvbnNlIGlzIEpTT04gYmVmb3JlIHBhcnNpbmdcbiAgICBjb25zdCBjb250ZW50VHlwZSA9IHN1bm9SZXNwb25zZS5oZWFkZXJzLmdldChcImNvbnRlbnQtdHlwZVwiKSB8fCBcIlwiO1xuICAgIGlmICghY29udGVudFR5cGUuaW5jbHVkZXMoXCJhcHBsaWNhdGlvbi9qc29uXCIpKSB7XG4gICAgICBjb25zdCB0ZXh0ID0gYXdhaXQgc3Vub1Jlc3BvbnNlLnRleHQoKTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJTdW5vIEFQSSByZXR1cm5lZCBub24tSlNPTjpcIiwgdGV4dC5zdWJzdHJpbmcoMCwgMjAwKSk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIGVycm9yOiBcIlN1bm8gQVBJIHVuYXZhaWxhYmxlXCIsXG4gICAgICAgICAgZGV0YWlsczogYFN0YXR1czogJHtzdW5vUmVzcG9uc2Uuc3RhdHVzfSwgcmV0dXJuZWQgSFRNTCBpbnN0ZWFkIG9mIEpTT05gXG4gICAgICAgIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgc3Vub0RhdGEgPSBhd2FpdCBzdW5vUmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKFwiU3VubyBjcmVkaXRzIHJlc3BvbnNlOlwiLCBKU09OLnN0cmluZ2lmeShzdW5vRGF0YSkpO1xuXG4gICAgaWYgKCFzdW5vUmVzcG9uc2Uub2sgfHwgc3Vub0RhdGEuY29kZSAhPT0gMjAwKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiU3VubyBBUEkgZXJyb3I6XCIsIHN1bm9EYXRhKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgZXJyb3I6IFwiRmFpbGVkIHRvIGZldGNoIFN1bm8gY3JlZGl0c1wiLFxuICAgICAgICAgIGRldGFpbHM6IHN1bm9EYXRhLm1zZyB8fCBcIlVua25vd24gZXJyb3JcIlxuICAgICAgICB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGNyZWRpdHMgPSBzdW5vRGF0YS5kYXRhO1xuICAgIGNvbnNvbGUubG9nKGBTdW5vIGNyZWRpdHMgcmVtYWluaW5nOiAke2NyZWRpdHN9YCk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIGNyZWRpdHM6IGNyZWRpdHNcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIHN1bm8tY3JlZGl0czpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCI7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IGVycm9yTWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFFQSxNQUFNLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2xDLE1BQU0sZ0JBQWdCO0FBRXRCLE1BQU0sT0FBTztFQUNYLElBQUksSUFBSSxNQUFNLEtBQUssV0FBVztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNO01BQUUsU0FBUztJQUFZO0VBQ25EO0VBRUEsSUFBSTtJQUNGLE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVksV0FBVyxZQUFZO01BQ3RDLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEwQixJQUNsRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGlCQUFpQixhQUNyQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFDckM7TUFBRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQUU7SUFHdkQsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxTQUFTLENBQUM7SUFFckYsSUFBSSxlQUFlLENBQUMsWUFBWSxRQUFRLEtBQUs7TUFDM0MsUUFBUSxLQUFLLENBQUMsZUFBZTtNQUM3QixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFNBQVMsV0FBVyxNQUFNLENBQUMsR0FBRztJQUVwQyxxREFBcUQ7SUFDckQsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxlQUFlLEdBQUcsQ0FBQyxZQUFZO01BQUUsVUFBVTtJQUFPO0lBRWxGLElBQUksQ0FBQyxTQUFTO01BQ1osT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTZCLElBQ3JEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLE9BQU8sZ0NBQWdDLENBQUM7SUFFN0QsOEJBQThCO0lBQzlCLE1BQU0sZUFBZSxNQUFNLE1BQU0sQ0FBQyxFQUFFLGNBQWMsdUJBQXVCLENBQUMsRUFBRTtNQUMxRSxRQUFRO01BQ1IsU0FBUztRQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7SUFDRjtJQUVBLDJDQUEyQztJQUMzQyxNQUFNLGNBQWMsYUFBYSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQjtJQUNoRSxJQUFJLENBQUMsWUFBWSxRQUFRLENBQUMscUJBQXFCO01BQzdDLE1BQU0sT0FBTyxNQUFNLGFBQWEsSUFBSTtNQUNwQyxRQUFRLEtBQUssQ0FBQywrQkFBK0IsS0FBSyxTQUFTLENBQUMsR0FBRztNQUMvRCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLE9BQU87UUFDUCxTQUFTLENBQUMsUUFBUSxFQUFFLGFBQWEsTUFBTSxDQUFDLCtCQUErQixDQUFDO01BQzFFLElBQ0E7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxXQUFXLE1BQU0sYUFBYSxJQUFJO0lBQ3hDLFFBQVEsR0FBRyxDQUFDLDBCQUEwQixLQUFLLFNBQVMsQ0FBQztJQUVyRCxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksU0FBUyxJQUFJLEtBQUssS0FBSztNQUM3QyxRQUFRLEtBQUssQ0FBQyxtQkFBbUI7TUFDakMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixPQUFPO1FBQ1AsU0FBUyxTQUFTLEdBQUcsSUFBSTtNQUMzQixJQUNBO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sVUFBVSxTQUFTLElBQUk7SUFDN0IsUUFBUSxHQUFHLENBQUMsQ0FBQyx3QkFBd0IsRUFBRSxRQUFRLENBQUM7SUFFaEQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsU0FBUztJQUNYLElBQ0E7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFHdEUsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQywwQkFBMEI7SUFDeEMsTUFBTSxlQUFlLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQzlELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFhLElBQ3JDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
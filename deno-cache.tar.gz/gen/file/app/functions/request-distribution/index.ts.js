import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};
serve(async (req)=>{
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders
    });
  }
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '');
    // Get user from auth header using getClaims (more reliable)
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }
    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      throw new Error('Unauthorized');
    }
    const userId = claimsData.claims.sub;
    const { trackId } = await req.json();
    console.log(`[request-distribution] User ${userId} requesting distribution for track: ${trackId}`);
    if (!trackId) {
      throw new Error('trackId is required');
    }
    // Get track and verify ownership
    const { data: track, error: trackError } = await supabase.from('tracks').select('*').eq('id', trackId).single();
    if (trackError || !track) {
      throw new Error('Track not found');
    }
    if (track.user_id !== userId) {
      throw new Error('Not authorized to request distribution for this track');
    }
    // Check if already in distribution process
    if (track.distribution_status !== 'none') {
      throw new Error(`Track is already in distribution process: ${track.distribution_status}`);
    }
    // Check plagiarism status
    if (track.plagiarism_check_status !== 'clean') {
      throw new Error('Track must pass plagiarism check first');
    }
    // Update track status
    const { error: updateError } = await supabase.from('tracks').update({
      distribution_status: 'pending_moderation',
      distribution_requested_at: new Date().toISOString()
    }).eq('id', trackId);
    if (updateError) {
      throw updateError;
    }
    // Log the request
    await supabase.from('distribution_logs').insert({
      track_id: trackId,
      user_id: userId,
      action: 'distribution_requested',
      stage: 'level_user',
      details: {
        track_title: track.title,
        plagiarism_status: track.plagiarism_check_status
      }
    });
    // Notify admins
    const { data: admins } = await supabase.from('user_roles').select('user_id').in('role', [
      'admin',
      'super_admin',
      'moderator'
    ]);
    if (admins) {
      const notifications = admins.map((admin)=>({
          user_id: admin.user_id,
          type: 'moderation',
          title: '📤 Запрос на дистрибуцию',
          message: `Пользователь запросил дистрибуцию трека "${track.title}"`,
          actor_id: userId,
          target_type: 'track',
          target_id: trackId
        }));
      await supabase.from('notifications').insert(notifications);
    }
    return new Response(JSON.stringify({
      success: true,
      message: 'Distribution request submitted',
      status: 'pending_moderation'
    }), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('[request-distribution] Error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({
      success: false,
      error: message
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9yZXF1ZXN0LWRpc3RyaWJ1dGlvbi9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6ICdhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZScsXG59O1xuXG5pbnRlcmZhY2UgUmVxdWVzdERpc3RyaWJ1dGlvbklucHV0IHtcbiAgdHJhY2tJZDogc3RyaW5nO1xufVxuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSAnT1BUSU9OUycpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKCdvaycsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KCdTVVBBQkFTRV9VUkwnKSA/PyAnJyxcbiAgICAgIERlbm8uZW52LmdldCgnU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWScpID8/ICcnXG4gICAgKTtcblxuICAgIC8vIEdldCB1c2VyIGZyb20gYXV0aCBoZWFkZXIgdXNpbmcgZ2V0Q2xhaW1zIChtb3JlIHJlbGlhYmxlKVxuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoJ0F1dGhvcml6YXRpb24nKTtcbiAgICBpZiAoIWF1dGhIZWFkZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gYXV0aG9yaXphdGlvbiBoZWFkZXInKTtcbiAgICB9XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZSgnQmVhcmVyICcsICcnKTtcbiAgICBjb25zdCB7IGRhdGE6IGNsYWltc0RhdGEsIGVycm9yOiBjbGFpbXNFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRDbGFpbXModG9rZW4pO1xuICAgIFxuICAgIGlmIChjbGFpbXNFcnJvciB8fCAhY2xhaW1zRGF0YT8uY2xhaW1zPy5zdWIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignVW5hdXRob3JpemVkJyk7XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHVzZXJJZCA9IGNsYWltc0RhdGEuY2xhaW1zLnN1YiBhcyBzdHJpbmc7XG5cbiAgICBjb25zdCB7IHRyYWNrSWQgfTogUmVxdWVzdERpc3RyaWJ1dGlvbklucHV0ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhgW3JlcXVlc3QtZGlzdHJpYnV0aW9uXSBVc2VyICR7dXNlcklkfSByZXF1ZXN0aW5nIGRpc3RyaWJ1dGlvbiBmb3IgdHJhY2s6ICR7dHJhY2tJZH1gKTtcblxuICAgIGlmICghdHJhY2tJZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCd0cmFja0lkIGlzIHJlcXVpcmVkJyk7XG4gICAgfVxuXG4gICAgLy8gR2V0IHRyYWNrIGFuZCB2ZXJpZnkgb3duZXJzaGlwXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjaywgZXJyb3I6IHRyYWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbSgndHJhY2tzJylcbiAgICAgIC5zZWxlY3QoJyonKVxuICAgICAgLmVxKCdpZCcsIHRyYWNrSWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAodHJhY2tFcnJvciB8fCAhdHJhY2spIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignVHJhY2sgbm90IGZvdW5kJyk7XG4gICAgfVxuXG4gICAgaWYgKHRyYWNrLnVzZXJfaWQgIT09IHVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdOb3QgYXV0aG9yaXplZCB0byByZXF1ZXN0IGRpc3RyaWJ1dGlvbiBmb3IgdGhpcyB0cmFjaycpO1xuICAgIH1cblxuICAgIC8vIENoZWNrIGlmIGFscmVhZHkgaW4gZGlzdHJpYnV0aW9uIHByb2Nlc3NcbiAgICBpZiAodHJhY2suZGlzdHJpYnV0aW9uX3N0YXR1cyAhPT0gJ25vbmUnKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFRyYWNrIGlzIGFscmVhZHkgaW4gZGlzdHJpYnV0aW9uIHByb2Nlc3M6ICR7dHJhY2suZGlzdHJpYnV0aW9uX3N0YXR1c31gKTtcbiAgICB9XG5cbiAgICAvLyBDaGVjayBwbGFnaWFyaXNtIHN0YXR1c1xuICAgIGlmICh0cmFjay5wbGFnaWFyaXNtX2NoZWNrX3N0YXR1cyAhPT0gJ2NsZWFuJykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdUcmFjayBtdXN0IHBhc3MgcGxhZ2lhcmlzbSBjaGVjayBmaXJzdCcpO1xuICAgIH1cblxuICAgIC8vIFVwZGF0ZSB0cmFjayBzdGF0dXNcbiAgICBjb25zdCB7IGVycm9yOiB1cGRhdGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKCd0cmFja3MnKVxuICAgICAgLnVwZGF0ZSh7XG4gICAgICAgIGRpc3RyaWJ1dGlvbl9zdGF0dXM6ICdwZW5kaW5nX21vZGVyYXRpb24nLFxuICAgICAgICBkaXN0cmlidXRpb25fcmVxdWVzdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgIH0pXG4gICAgICAuZXEoJ2lkJywgdHJhY2tJZCk7XG5cbiAgICBpZiAodXBkYXRlRXJyb3IpIHtcbiAgICAgIHRocm93IHVwZGF0ZUVycm9yO1xuICAgIH1cblxuICAgIC8vIExvZyB0aGUgcmVxdWVzdFxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ2Rpc3RyaWJ1dGlvbl9sb2dzJykuaW5zZXJ0KHtcbiAgICAgIHRyYWNrX2lkOiB0cmFja0lkLFxuICAgICAgdXNlcl9pZDogdXNlcklkLFxuICAgICAgYWN0aW9uOiAnZGlzdHJpYnV0aW9uX3JlcXVlc3RlZCcsXG4gICAgICBzdGFnZTogJ2xldmVsX3VzZXInLFxuICAgICAgZGV0YWlsczogeyBcbiAgICAgICAgdHJhY2tfdGl0bGU6IHRyYWNrLnRpdGxlLFxuICAgICAgICBwbGFnaWFyaXNtX3N0YXR1czogdHJhY2sucGxhZ2lhcmlzbV9jaGVja19zdGF0dXNcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIE5vdGlmeSBhZG1pbnNcbiAgICBjb25zdCB7IGRhdGE6IGFkbWlucyB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKCd1c2VyX3JvbGVzJylcbiAgICAgIC5zZWxlY3QoJ3VzZXJfaWQnKVxuICAgICAgLmluKCdyb2xlJywgWydhZG1pbicsICdzdXBlcl9hZG1pbicsICdtb2RlcmF0b3InXSk7XG5cbiAgICBpZiAoYWRtaW5zKSB7XG4gICAgICBjb25zdCBub3RpZmljYXRpb25zID0gYWRtaW5zLm1hcChhZG1pbiA9PiAoe1xuICAgICAgICB1c2VyX2lkOiBhZG1pbi51c2VyX2lkLFxuICAgICAgICB0eXBlOiAnbW9kZXJhdGlvbicsXG4gICAgICAgIHRpdGxlOiAn8J+TpCDQl9Cw0L/RgNC+0YEg0L3QsCDQtNC40YHRgtGA0LjQsdGD0YbQuNGOJyxcbiAgICAgICAgbWVzc2FnZTogYNCf0L7Qu9GM0LfQvtCy0LDRgtC10LvRjCDQt9Cw0L/RgNC+0YHQuNC7INC00LjRgdGC0YDQuNCx0YPRhtC40Y4g0YLRgNC10LrQsCBcIiR7dHJhY2sudGl0bGV9XCJgLFxuICAgICAgICBhY3Rvcl9pZDogdXNlcklkLFxuICAgICAgICB0YXJnZXRfdHlwZTogJ3RyYWNrJyxcbiAgICAgICAgdGFyZ2V0X2lkOiB0cmFja0lkXG4gICAgICB9KSk7XG5cbiAgICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ25vdGlmaWNhdGlvbnMnKS5pbnNlcnQobm90aWZpY2F0aW9ucyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICBtZXNzYWdlOiAnRGlzdHJpYnV0aW9uIHJlcXVlc3Qgc3VibWl0dGVkJyxcbiAgICAgICAgc3RhdHVzOiAncGVuZGluZ19tb2RlcmF0aW9uJ1xuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tyZXF1ZXN0LWRpc3RyaWJ1dGlvbl0gRXJyb3I6JywgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJztcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IG1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsS0FBSyxRQUFRLCtDQUErQztBQUNyRSxTQUFTLFlBQVksUUFBUSx5Q0FBeUM7QUFFdEUsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FBZ0M7QUFDbEM7QUFNQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLFdBQVcsYUFDZixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0M7SUFHL0MsNERBQTREO0lBQzVELE1BQU0sYUFBYSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkMsSUFBSSxDQUFDLFlBQVk7TUFDZixNQUFNLElBQUksTUFBTTtJQUNsQjtJQUVBLE1BQU0sUUFBUSxXQUFXLE9BQU8sQ0FBQyxXQUFXO0lBQzVDLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBRS9FLElBQUksZUFBZSxDQUFDLFlBQVksUUFBUSxLQUFLO01BQzNDLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxTQUFTLFdBQVcsTUFBTSxDQUFDLEdBQUc7SUFFcEMsTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUE2QixNQUFNLElBQUksSUFBSTtJQUM1RCxRQUFRLEdBQUcsQ0FBQyxDQUFDLDRCQUE0QixFQUFFLE9BQU8sb0NBQW9DLEVBQUUsUUFBUSxDQUFDO0lBRWpHLElBQUksQ0FBQyxTQUFTO01BQ1osTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxpQ0FBaUM7SUFDakMsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxTQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsS0FDUCxFQUFFLENBQUMsTUFBTSxTQUNULE1BQU07SUFFVCxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsSUFBSSxNQUFNLE9BQU8sS0FBSyxRQUFRO01BQzVCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsMkNBQTJDO0lBQzNDLElBQUksTUFBTSxtQkFBbUIsS0FBSyxRQUFRO01BQ3hDLE1BQU0sSUFBSSxNQUFNLENBQUMsMENBQTBDLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQyxDQUFDO0lBQzFGO0lBRUEsMEJBQTBCO0lBQzFCLElBQUksTUFBTSx1QkFBdUIsS0FBSyxTQUFTO01BQzdDLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsc0JBQXNCO0lBQ3RCLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO01BQ04scUJBQXFCO01BQ3JCLDJCQUEyQixJQUFJLE9BQU8sV0FBVztJQUNuRCxHQUNDLEVBQUUsQ0FBQyxNQUFNO0lBRVosSUFBSSxhQUFhO01BQ2YsTUFBTTtJQUNSO0lBRUEsa0JBQWtCO0lBQ2xCLE1BQU0sU0FBUyxJQUFJLENBQUMscUJBQXFCLE1BQU0sQ0FBQztNQUM5QyxVQUFVO01BQ1YsU0FBUztNQUNULFFBQVE7TUFDUixPQUFPO01BQ1AsU0FBUztRQUNQLGFBQWEsTUFBTSxLQUFLO1FBQ3hCLG1CQUFtQixNQUFNLHVCQUF1QjtNQUNsRDtJQUNGO0lBRUEsZ0JBQWdCO0lBQ2hCLE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxHQUFHLE1BQU0sU0FDNUIsSUFBSSxDQUFDLGNBQ0wsTUFBTSxDQUFDLFdBQ1AsRUFBRSxDQUFDLFFBQVE7TUFBQztNQUFTO01BQWU7S0FBWTtJQUVuRCxJQUFJLFFBQVE7TUFDVixNQUFNLGdCQUFnQixPQUFPLEdBQUcsQ0FBQyxDQUFBLFFBQVMsQ0FBQztVQUN6QyxTQUFTLE1BQU0sT0FBTztVQUN0QixNQUFNO1VBQ04sT0FBTztVQUNQLFNBQVMsQ0FBQyx5Q0FBeUMsRUFBRSxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7VUFDbkUsVUFBVTtVQUNWLGFBQWE7VUFDYixXQUFXO1FBQ2IsQ0FBQztNQUVELE1BQU0sU0FBUyxJQUFJLENBQUMsaUJBQWlCLE1BQU0sQ0FBQztJQUM5QztJQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULFNBQVM7TUFDVCxRQUFRO0lBQ1YsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLGlDQUFpQztJQUMvQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO01BQU8sT0FBTztJQUFRLElBQ2hEO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
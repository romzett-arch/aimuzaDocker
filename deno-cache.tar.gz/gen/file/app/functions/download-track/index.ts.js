import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const ffmpegApiUrl = Deno.env.get("FFMPEG_API_URL");
  const ffmpegApiSecret = Deno.env.get("FFMPEG_API_SECRET");
  try {
    // Validate auth
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Invalid token"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const userId = user.id;
    const body = await req.json();
    const { track_id, include_blockchain = false, stream = false } = body;
    if (!track_id) {
      return new Response(JSON.stringify({
        error: "track_id required"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log("Download track request:", {
      track_id,
      userId,
      include_blockchain,
      stream
    });
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Get track info
    const { data: track, error: trackError } = await supabase.from("tracks").select("id, user_id, title, audio_url, status, created_at").eq("id", track_id).single();
    if (trackError || !track) {
      return new Response(JSON.stringify({
        error: "Track not found"
      }), {
        status: 404,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Check ownership
    if (track.user_id !== userId) {
      return new Response(JSON.stringify({
        error: "Access denied - not your track"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    if (!track.audio_url) {
      return new Response(JSON.stringify({
        error: "Track has no audio"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Get user profile for artist name
    const { data: profile } = await supabase.from("profiles").select("username").eq("user_id", userId).single();
    const artistName = profile?.username || "AIMuza Artist";
    const shortUserId = userId.substring(0, 8);
    const createdDate = new Date(track.created_at).toISOString().split("T")[0];
    const safeTitle = track.title.replace(/[^a-zA-Zа-яА-Я0-9\s]/g, "_");
    const filename = `${safeTitle}.mp3`;
    // Prepare extended metadata
    const extendedMetadata = {
      title: track.title,
      artist: artistName,
      album: "AIMuza",
      publisher: "AIMuza",
      comment: `Generated with AIMuza - aimuza.ru | User: ${artistName} (${shortUserId}) | Date: ${createdDate}`,
      copyright: `© ${new Date().getFullYear()} ${artistName} via AIMuza`,
      custom: {
        TXXX_AIMUZA_USER_ID: userId,
        TXXX_AIMUZA_USERNAME: artistName,
        TXXX_AIMUZA_WEBSITE: "aimuza.ru",
        TXXX_AIMUZA_DATE: createdDate,
        TXXX_AIMUZA_TRACK_ID: track_id
      }
    };
    // If blockchain protection is requested, get deposit info
    let blockchainHash = null;
    if (include_blockchain) {
      const { data: deposit } = await supabase.from("track_deposits").select("metadata_hash, blockchain_tx_id, deposited_at").eq("track_id", track_id).eq("status", "completed").order("deposited_at", {
        ascending: false
      }).limit(1).single();
      if (deposit?.metadata_hash) {
        blockchainHash = deposit.metadata_hash;
        extendedMetadata.custom["TXXX_BLOCKCHAIN_HASH"] = deposit.metadata_hash;
        if (deposit.blockchain_tx_id) {
          extendedMetadata.custom["TXXX_BLOCKCHAIN_TX"] = deposit.blockchain_tx_id;
        }
        extendedMetadata.custom["TXXX_BLOCKCHAIN_DATE"] = deposit.deposited_at;
        extendedMetadata.comment += ` | Blockchain: ${deposit.metadata_hash.substring(0, 16)}...`;
      }
    }
    // If FFmpeg API is not configured, return/stream original
    if (!ffmpegApiUrl || !ffmpegApiSecret) {
      console.log("FFmpeg API not configured, returning original");
      if (stream) {
        return await proxyFile(track.audio_url, filename, corsHeaders);
      }
      return new Response(JSON.stringify({
        success: true,
        download_url: track.audio_url,
        filename,
        cleaned: false
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Call FFmpeg API for metadata cleaning
    console.log("Calling FFmpeg API for metadata cleaning...");
    const baseUrl = ffmpegApiUrl.replace(/\/(clean-metadata|analyze|normalize)\/?$/, "");
    const ffmpegResponse = await fetch(`${baseUrl}/clean-metadata`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ffmpegApiSecret
      },
      body: JSON.stringify({
        audio_url: track.audio_url,
        metadata: extendedMetadata
      })
    });
    if (!ffmpegResponse.ok) {
      const errorText = await ffmpegResponse.text();
      console.error("FFmpeg API error:", ffmpegResponse.status, errorText);
      // Fallback to original
      if (stream) {
        return await proxyFile(track.audio_url, filename, corsHeaders);
      }
      return new Response(JSON.stringify({
        success: true,
        download_url: track.audio_url,
        filename,
        cleaned: false,
        warning: "Metadata cleaning unavailable"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const ffmpegResult = await ffmpegResponse.json();
    console.log("FFmpeg API response:", ffmpegResult);
    const outputUrl = ffmpegResult.output_url || track.audio_url;
    const cleaned = !!ffmpegResult.output_url;
    // Increment download count
    await supabase.rpc("increment_download_count", {
      track_id
    });
    // Stream mode: proxy the file through edge function to avoid CORS
    if (stream) {
      console.log("Streaming file to client:", outputUrl);
      return await proxyFile(outputUrl, filename, corsHeaders);
    }
    // JSON mode (legacy)
    return new Response(JSON.stringify({
      success: true,
      download_url: outputUrl,
      filename,
      cleaned,
      metadata: {
        artist: artistName,
        user_id: shortUserId,
        date: createdDate,
        blockchain_protected: !!blockchainHash
      }
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in download-track:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
/**
 * Proxy a file URL through the edge function to avoid CORS issues.
 * Returns the file as binary with proper Content-Disposition header.
 */ async function proxyFile(url, filename, corsHeaders) {
  try {
    // Внутри Docker, localhost не доступен — заменяем на nginx hostname
    let internalUrl = url;
    if (url.includes('localhost')) {
      internalUrl = url.replace('http://localhost', 'http://nginx');
    }
    const fileResponse = await fetch(internalUrl);
    if (!fileResponse.ok) {
      throw new Error(`Failed to fetch file: ${fileResponse.status}`);
    }
    const fileData = await fileResponse.arrayBuffer();
    const encodedFilename = encodeURIComponent(filename);
    return new Response(fileData, {
      headers: {
        ...corsHeaders,
        "Content-Type": "audio/mpeg",
        "Content-Disposition": `attachment; filename="${encodedFilename}"; filename*=UTF-8''${encodedFilename}`,
        "Content-Length": String(fileData.byteLength)
      }
    });
  } catch (err) {
    console.error("Proxy file error:", err);
    return new Response(JSON.stringify({
      error: "Failed to proxy file"
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9kb3dubG9hZC10cmFjay9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xNjguMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgY29uc3Qgc3VwYWJhc2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikhO1xuICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgY29uc3Qgc3VwYWJhc2VBbm9uS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfQU5PTl9LRVlcIikhO1xuICBjb25zdCBmZm1wZWdBcGlVcmwgPSBEZW5vLmVudi5nZXQoXCJGRk1QRUdfQVBJX1VSTFwiKTtcbiAgY29uc3QgZmZtcGVnQXBpU2VjcmV0ID0gRGVuby5lbnYuZ2V0KFwiRkZNUEVHX0FQSV9TRUNSRVRcIik7XG5cbiAgdHJ5IHtcbiAgICAvLyBWYWxpZGF0ZSBhdXRoXG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyPy5zdGFydHNXaXRoKFwiQmVhcmVyIFwiKSkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJVbmF1dGhvcml6ZWRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMSwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHVzZXJDbGllbnQgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlQW5vbktleSwge1xuICAgICAgZ2xvYmFsOiB7IGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYXV0aEhlYWRlciB9IH1cbiAgICB9KTtcbiAgICBcbiAgICBjb25zdCB7IGRhdGE6IHsgdXNlciB9LCBlcnJvcjogdXNlckVycm9yIH0gPSBhd2FpdCB1c2VyQ2xpZW50LmF1dGguZ2V0VXNlcigpO1xuICAgIFxuICAgIGlmICh1c2VyRXJyb3IgfHwgIXVzZXIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiSW52YWxpZCB0b2tlblwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHVzZXJJZCA9IHVzZXIuaWQ7XG5cbiAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVxLmpzb24oKTtcbiAgICBjb25zdCB7IHRyYWNrX2lkLCBpbmNsdWRlX2Jsb2NrY2hhaW4gPSBmYWxzZSwgc3RyZWFtID0gZmFsc2UgfSA9IGJvZHk7XG5cbiAgICBpZiAoIXRyYWNrX2lkKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcInRyYWNrX2lkIHJlcXVpcmVkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhcIkRvd25sb2FkIHRyYWNrIHJlcXVlc3Q6XCIsIHsgdHJhY2tfaWQsIHVzZXJJZCwgaW5jbHVkZV9ibG9ja2NoYWluLCBzdHJlYW0gfSk7XG5cbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIC8vIEdldCB0cmFjayBpbmZvXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjaywgZXJyb3I6IHRyYWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgLnNlbGVjdChcImlkLCB1c2VyX2lkLCB0aXRsZSwgYXVkaW9fdXJsLCBzdGF0dXMsIGNyZWF0ZWRfYXRcIilcbiAgICAgIC5lcShcImlkXCIsIHRyYWNrX2lkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKHRyYWNrRXJyb3IgfHwgIXRyYWNrKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlRyYWNrIG5vdCBmb3VuZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDA0LCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgb3duZXJzaGlwXG4gICAgaWYgKHRyYWNrLnVzZXJfaWQgIT09IHVzZXJJZCkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJBY2Nlc3MgZGVuaWVkIC0gbm90IHlvdXIgdHJhY2tcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMywgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGlmICghdHJhY2suYXVkaW9fdXJsKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlRyYWNrIGhhcyBubyBhdWRpb1wiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gR2V0IHVzZXIgcHJvZmlsZSBmb3IgYXJ0aXN0IG5hbWVcbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAuc2VsZWN0KFwidXNlcm5hbWVcIilcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgY29uc3QgYXJ0aXN0TmFtZSA9IHByb2ZpbGU/LnVzZXJuYW1lIHx8IFwiQUlNdXphIEFydGlzdFwiO1xuICAgIGNvbnN0IHNob3J0VXNlcklkID0gdXNlcklkLnN1YnN0cmluZygwLCA4KTtcbiAgICBjb25zdCBjcmVhdGVkRGF0ZSA9IG5ldyBEYXRlKHRyYWNrLmNyZWF0ZWRfYXQpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xuICAgIGNvbnN0IHNhZmVUaXRsZSA9IHRyYWNrLnRpdGxlLnJlcGxhY2UoL1teYS16QS1a0LAt0Y/QkC3QrzAtOVxcc10vZywgXCJfXCIpO1xuICAgIGNvbnN0IGZpbGVuYW1lID0gYCR7c2FmZVRpdGxlfS5tcDNgO1xuXG4gICAgLy8gUHJlcGFyZSBleHRlbmRlZCBtZXRhZGF0YVxuICAgIGNvbnN0IGV4dGVuZGVkTWV0YWRhdGEgPSB7XG4gICAgICB0aXRsZTogdHJhY2sudGl0bGUsXG4gICAgICBhcnRpc3Q6IGFydGlzdE5hbWUsXG4gICAgICBhbGJ1bTogXCJBSU11emFcIixcbiAgICAgIHB1Ymxpc2hlcjogXCJBSU11emFcIixcbiAgICAgIGNvbW1lbnQ6IGBHZW5lcmF0ZWQgd2l0aCBBSU11emEgLSBhaW11emEucnUgfCBVc2VyOiAke2FydGlzdE5hbWV9ICgke3Nob3J0VXNlcklkfSkgfCBEYXRlOiAke2NyZWF0ZWREYXRlfWAsXG4gICAgICBjb3B5cmlnaHQ6IGDCqSAke25ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKX0gJHthcnRpc3ROYW1lfSB2aWEgQUlNdXphYCxcbiAgICAgIGN1c3RvbToge1xuICAgICAgICBUWFhYX0FJTVVaQV9VU0VSX0lEOiB1c2VySWQsXG4gICAgICAgIFRYWFhfQUlNVVpBX1VTRVJOQU1FOiBhcnRpc3ROYW1lLFxuICAgICAgICBUWFhYX0FJTVVaQV9XRUJTSVRFOiBcImFpbXV6YS5ydVwiLFxuICAgICAgICBUWFhYX0FJTVVaQV9EQVRFOiBjcmVhdGVkRGF0ZSxcbiAgICAgICAgVFhYWF9BSU1VWkFfVFJBQ0tfSUQ6IHRyYWNrX2lkLFxuICAgICAgfSBhcyBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+LFxuICAgIH07XG5cbiAgICAvLyBJZiBibG9ja2NoYWluIHByb3RlY3Rpb24gaXMgcmVxdWVzdGVkLCBnZXQgZGVwb3NpdCBpbmZvXG4gICAgbGV0IGJsb2NrY2hhaW5IYXNoOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgICBpZiAoaW5jbHVkZV9ibG9ja2NoYWluKSB7XG4gICAgICBjb25zdCB7IGRhdGE6IGRlcG9zaXQgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tfZGVwb3NpdHNcIilcbiAgICAgICAgLnNlbGVjdChcIm1ldGFkYXRhX2hhc2gsIGJsb2NrY2hhaW5fdHhfaWQsIGRlcG9zaXRlZF9hdFwiKVxuICAgICAgICAuZXEoXCJ0cmFja19pZFwiLCB0cmFja19pZClcbiAgICAgICAgLmVxKFwic3RhdHVzXCIsIFwiY29tcGxldGVkXCIpXG4gICAgICAgIC5vcmRlcihcImRlcG9zaXRlZF9hdFwiLCB7IGFzY2VuZGluZzogZmFsc2UgfSlcbiAgICAgICAgLmxpbWl0KDEpXG4gICAgICAgIC5zaW5nbGUoKTtcblxuICAgICAgaWYgKGRlcG9zaXQ/Lm1ldGFkYXRhX2hhc2gpIHtcbiAgICAgICAgYmxvY2tjaGFpbkhhc2ggPSBkZXBvc2l0Lm1ldGFkYXRhX2hhc2g7XG4gICAgICAgIGV4dGVuZGVkTWV0YWRhdGEuY3VzdG9tW1wiVFhYWF9CTE9DS0NIQUlOX0hBU0hcIl0gPSBkZXBvc2l0Lm1ldGFkYXRhX2hhc2g7XG4gICAgICAgIGlmIChkZXBvc2l0LmJsb2NrY2hhaW5fdHhfaWQpIHtcbiAgICAgICAgICBleHRlbmRlZE1ldGFkYXRhLmN1c3RvbVtcIlRYWFhfQkxPQ0tDSEFJTl9UWFwiXSA9IGRlcG9zaXQuYmxvY2tjaGFpbl90eF9pZDtcbiAgICAgICAgfVxuICAgICAgICBleHRlbmRlZE1ldGFkYXRhLmN1c3RvbVtcIlRYWFhfQkxPQ0tDSEFJTl9EQVRFXCJdID0gZGVwb3NpdC5kZXBvc2l0ZWRfYXQ7XG4gICAgICAgIGV4dGVuZGVkTWV0YWRhdGEuY29tbWVudCArPSBgIHwgQmxvY2tjaGFpbjogJHtkZXBvc2l0Lm1ldGFkYXRhX2hhc2guc3Vic3RyaW5nKDAsIDE2KX0uLi5gO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIElmIEZGbXBlZyBBUEkgaXMgbm90IGNvbmZpZ3VyZWQsIHJldHVybi9zdHJlYW0gb3JpZ2luYWxcbiAgICBpZiAoIWZmbXBlZ0FwaVVybCB8fCAhZmZtcGVnQXBpU2VjcmV0KSB7XG4gICAgICBjb25zb2xlLmxvZyhcIkZGbXBlZyBBUEkgbm90IGNvbmZpZ3VyZWQsIHJldHVybmluZyBvcmlnaW5hbFwiKTtcbiAgICAgIGlmIChzdHJlYW0pIHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IHByb3h5RmlsZSh0cmFjay5hdWRpb191cmwsIGZpbGVuYW1lLCBjb3JzSGVhZGVycyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICAgIGRvd25sb2FkX3VybDogdHJhY2suYXVkaW9fdXJsLFxuICAgICAgICAgIGZpbGVuYW1lLFxuICAgICAgICAgIGNsZWFuZWQ6IGZhbHNlLFxuICAgICAgICB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gQ2FsbCBGRm1wZWcgQVBJIGZvciBtZXRhZGF0YSBjbGVhbmluZ1xuICAgIGNvbnNvbGUubG9nKFwiQ2FsbGluZyBGRm1wZWcgQVBJIGZvciBtZXRhZGF0YSBjbGVhbmluZy4uLlwiKTtcbiAgICBcbiAgICBjb25zdCBiYXNlVXJsID0gZmZtcGVnQXBpVXJsIS5yZXBsYWNlKC9cXC8oY2xlYW4tbWV0YWRhdGF8YW5hbHl6ZXxub3JtYWxpemUpXFwvPyQvLCBcIlwiKTtcbiAgICBjb25zdCBmZm1wZWdSZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke2Jhc2VVcmx9L2NsZWFuLW1ldGFkYXRhYCwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgIFwieC1hcGkta2V5XCI6IGZmbXBlZ0FwaVNlY3JldCEsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBhdWRpb191cmw6IHRyYWNrLmF1ZGlvX3VybCxcbiAgICAgICAgbWV0YWRhdGE6IGV4dGVuZGVkTWV0YWRhdGEsXG4gICAgICB9KSxcbiAgICB9KTtcblxuICAgIGlmICghZmZtcGVnUmVzcG9uc2Uub2spIHtcbiAgICAgIGNvbnN0IGVycm9yVGV4dCA9IGF3YWl0IGZmbXBlZ1Jlc3BvbnNlLnRleHQoKTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGRm1wZWcgQVBJIGVycm9yOlwiLCBmZm1wZWdSZXNwb25zZS5zdGF0dXMsIGVycm9yVGV4dCk7XG4gICAgICBcbiAgICAgIC8vIEZhbGxiYWNrIHRvIG9yaWdpbmFsXG4gICAgICBpZiAoc3RyZWFtKSB7XG4gICAgICAgIHJldHVybiBhd2FpdCBwcm94eUZpbGUodHJhY2suYXVkaW9fdXJsLCBmaWxlbmFtZSwgY29yc0hlYWRlcnMpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgICBkb3dubG9hZF91cmw6IHRyYWNrLmF1ZGlvX3VybCxcbiAgICAgICAgICBmaWxlbmFtZSxcbiAgICAgICAgICBjbGVhbmVkOiBmYWxzZSxcbiAgICAgICAgICB3YXJuaW5nOiBcIk1ldGFkYXRhIGNsZWFuaW5nIHVuYXZhaWxhYmxlXCIsXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBmZm1wZWdSZXN1bHQgPSBhd2FpdCBmZm1wZWdSZXNwb25zZS5qc29uKCk7XG4gICAgY29uc29sZS5sb2coXCJGRm1wZWcgQVBJIHJlc3BvbnNlOlwiLCBmZm1wZWdSZXN1bHQpO1xuXG4gICAgY29uc3Qgb3V0cHV0VXJsID0gZmZtcGVnUmVzdWx0Lm91dHB1dF91cmwgfHwgdHJhY2suYXVkaW9fdXJsO1xuICAgIGNvbnN0IGNsZWFuZWQgPSAhIWZmbXBlZ1Jlc3VsdC5vdXRwdXRfdXJsO1xuXG4gICAgLy8gSW5jcmVtZW50IGRvd25sb2FkIGNvdW50XG4gICAgYXdhaXQgc3VwYWJhc2UucnBjKFwiaW5jcmVtZW50X2Rvd25sb2FkX2NvdW50XCIsIHsgdHJhY2tfaWQgfSk7XG5cbiAgICAvLyBTdHJlYW0gbW9kZTogcHJveHkgdGhlIGZpbGUgdGhyb3VnaCBlZGdlIGZ1bmN0aW9uIHRvIGF2b2lkIENPUlNcbiAgICBpZiAoc3RyZWFtKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIlN0cmVhbWluZyBmaWxlIHRvIGNsaWVudDpcIiwgb3V0cHV0VXJsKTtcbiAgICAgIHJldHVybiBhd2FpdCBwcm94eUZpbGUob3V0cHV0VXJsLCBmaWxlbmFtZSwgY29yc0hlYWRlcnMpO1xuICAgIH1cblxuICAgIC8vIEpTT04gbW9kZSAobGVnYWN5KVxuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgZG93bmxvYWRfdXJsOiBvdXRwdXRVcmwsXG4gICAgICAgIGZpbGVuYW1lLFxuICAgICAgICBjbGVhbmVkLFxuICAgICAgICBtZXRhZGF0YToge1xuICAgICAgICAgIGFydGlzdDogYXJ0aXN0TmFtZSxcbiAgICAgICAgICB1c2VyX2lkOiBzaG9ydFVzZXJJZCxcbiAgICAgICAgICBkYXRlOiBjcmVhdGVkRGF0ZSxcbiAgICAgICAgICBibG9ja2NoYWluX3Byb3RlY3RlZDogISFibG9ja2NoYWluSGFzaCxcbiAgICAgICAgfVxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gZG93bmxvYWQtdHJhY2s6XCIsIGVycm9yKTtcbiAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogbWVzc2FnZSB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn0pO1xuXG4vKipcbiAqIFByb3h5IGEgZmlsZSBVUkwgdGhyb3VnaCB0aGUgZWRnZSBmdW5jdGlvbiB0byBhdm9pZCBDT1JTIGlzc3Vlcy5cbiAqIFJldHVybnMgdGhlIGZpbGUgYXMgYmluYXJ5IHdpdGggcHJvcGVyIENvbnRlbnQtRGlzcG9zaXRpb24gaGVhZGVyLlxuICovXG5hc3luYyBmdW5jdGlvbiBwcm94eUZpbGUoXG4gIHVybDogc3RyaW5nLCBcbiAgZmlsZW5hbWU6IHN0cmluZywgXG4gIGNvcnNIZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+XG4pOiBQcm9taXNlPFJlc3BvbnNlPiB7XG4gIHRyeSB7XG4gICAgLy8g0JLQvdGD0YLRgNC4IERvY2tlciwgbG9jYWxob3N0INC90LUg0LTQvtGB0YLRg9C/0LXQvSDigJQg0LfQsNC80LXQvdGP0LXQvCDQvdCwIG5naW54IGhvc3RuYW1lXG4gICAgbGV0IGludGVybmFsVXJsID0gdXJsO1xuICAgIGlmICh1cmwuaW5jbHVkZXMoJ2xvY2FsaG9zdCcpKSB7XG4gICAgICBpbnRlcm5hbFVybCA9IHVybC5yZXBsYWNlKCdodHRwOi8vbG9jYWxob3N0JywgJ2h0dHA6Ly9uZ2lueCcpO1xuICAgIH1cbiAgICBjb25zdCBmaWxlUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChpbnRlcm5hbFVybCk7XG4gICAgaWYgKCFmaWxlUmVzcG9uc2Uub2spIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGZldGNoIGZpbGU6ICR7ZmlsZVJlc3BvbnNlLnN0YXR1c31gKTtcbiAgICB9XG5cbiAgICBjb25zdCBmaWxlRGF0YSA9IGF3YWl0IGZpbGVSZXNwb25zZS5hcnJheUJ1ZmZlcigpO1xuICAgIGNvbnN0IGVuY29kZWRGaWxlbmFtZSA9IGVuY29kZVVSSUNvbXBvbmVudChmaWxlbmFtZSk7XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKGZpbGVEYXRhLCB7XG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIC4uLmNvcnNIZWFkZXJzLFxuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImF1ZGlvL21wZWdcIixcbiAgICAgICAgXCJDb250ZW50LURpc3Bvc2l0aW9uXCI6IGBhdHRhY2htZW50OyBmaWxlbmFtZT1cIiR7ZW5jb2RlZEZpbGVuYW1lfVwiOyBmaWxlbmFtZSo9VVRGLTgnJyR7ZW5jb2RlZEZpbGVuYW1lfWAsXG4gICAgICAgIFwiQ29udGVudC1MZW5ndGhcIjogU3RyaW5nKGZpbGVEYXRhLmJ5dGVMZW5ndGgpLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcihcIlByb3h5IGZpbGUgZXJyb3I6XCIsIGVycik7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiRmFpbGVkIHRvIHByb3h5IGZpbGVcIiB9KSxcbiAgICAgIHsgc3RhdHVzOiA1MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG4gIH1cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0VBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUN4QyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFDckMsTUFBTSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztFQUNsQyxNQUFNLGtCQUFrQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFFckMsSUFBSTtJQUNGLGdCQUFnQjtJQUNoQixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZLFdBQVcsWUFBWTtNQUN0QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGFBQWEsYUFBYSxhQUFhLGlCQUFpQjtNQUM1RCxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQ25EO0lBRUEsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sV0FBVyxJQUFJLENBQUMsT0FBTztJQUUxRSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFnQixJQUN4QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFNBQVMsS0FBSyxFQUFFO0lBRXRCLE1BQU0sT0FBTyxNQUFNLElBQUksSUFBSTtJQUMzQixNQUFNLEVBQUUsUUFBUSxFQUFFLHFCQUFxQixLQUFLLEVBQUUsU0FBUyxLQUFLLEVBQUUsR0FBRztJQUVqRSxJQUFJLENBQUMsVUFBVTtNQUNiLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFvQixJQUM1QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQywyQkFBMkI7TUFBRTtNQUFVO01BQVE7TUFBb0I7SUFBTztJQUV0RixNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLGlCQUFpQjtJQUNqQixNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxVQUFVLEVBQUUsR0FBRyxNQUFNLFNBQzlDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxxREFDUCxFQUFFLENBQUMsTUFBTSxVQUNULE1BQU07SUFFVCxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFrQixJQUMxQztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxrQkFBa0I7SUFDbEIsSUFBSSxNQUFNLE9BQU8sS0FBSyxRQUFRO01BQzVCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFpQyxJQUN6RDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxJQUFJLENBQUMsTUFBTSxTQUFTLEVBQUU7TUFDcEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQXFCLElBQzdDO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLG1DQUFtQztJQUNuQyxNQUFNLEVBQUUsTUFBTSxPQUFPLEVBQUUsR0FBRyxNQUFNLFNBQzdCLElBQUksQ0FBQyxZQUNMLE1BQU0sQ0FBQyxZQUNQLEVBQUUsQ0FBQyxXQUFXLFFBQ2QsTUFBTTtJQUVULE1BQU0sYUFBYSxTQUFTLFlBQVk7SUFDeEMsTUFBTSxjQUFjLE9BQU8sU0FBUyxDQUFDLEdBQUc7SUFDeEMsTUFBTSxjQUFjLElBQUksS0FBSyxNQUFNLFVBQVUsRUFBRSxXQUFXLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQzFFLE1BQU0sWUFBWSxNQUFNLEtBQUssQ0FBQyxPQUFPLENBQUMseUJBQXlCO0lBQy9ELE1BQU0sV0FBVyxDQUFDLEVBQUUsVUFBVSxJQUFJLENBQUM7SUFFbkMsNEJBQTRCO0lBQzVCLE1BQU0sbUJBQW1CO01BQ3ZCLE9BQU8sTUFBTSxLQUFLO01BQ2xCLFFBQVE7TUFDUixPQUFPO01BQ1AsV0FBVztNQUNYLFNBQVMsQ0FBQywwQ0FBMEMsRUFBRSxXQUFXLEVBQUUsRUFBRSxZQUFZLFVBQVUsRUFBRSxZQUFZLENBQUM7TUFDMUcsV0FBVyxDQUFDLEVBQUUsRUFBRSxJQUFJLE9BQU8sV0FBVyxHQUFHLENBQUMsRUFBRSxXQUFXLFdBQVcsQ0FBQztNQUNuRSxRQUFRO1FBQ04scUJBQXFCO1FBQ3JCLHNCQUFzQjtRQUN0QixxQkFBcUI7UUFDckIsa0JBQWtCO1FBQ2xCLHNCQUFzQjtNQUN4QjtJQUNGO0lBRUEsMERBQTBEO0lBQzFELElBQUksaUJBQWdDO0lBQ3BDLElBQUksb0JBQW9CO01BQ3RCLE1BQU0sRUFBRSxNQUFNLE9BQU8sRUFBRSxHQUFHLE1BQU0sU0FDN0IsSUFBSSxDQUFDLGtCQUNMLE1BQU0sQ0FBQyxpREFDUCxFQUFFLENBQUMsWUFBWSxVQUNmLEVBQUUsQ0FBQyxVQUFVLGFBQ2IsS0FBSyxDQUFDLGdCQUFnQjtRQUFFLFdBQVc7TUFBTSxHQUN6QyxLQUFLLENBQUMsR0FDTixNQUFNO01BRVQsSUFBSSxTQUFTLGVBQWU7UUFDMUIsaUJBQWlCLFFBQVEsYUFBYTtRQUN0QyxpQkFBaUIsTUFBTSxDQUFDLHVCQUF1QixHQUFHLFFBQVEsYUFBYTtRQUN2RSxJQUFJLFFBQVEsZ0JBQWdCLEVBQUU7VUFDNUIsaUJBQWlCLE1BQU0sQ0FBQyxxQkFBcUIsR0FBRyxRQUFRLGdCQUFnQjtRQUMxRTtRQUNBLGlCQUFpQixNQUFNLENBQUMsdUJBQXVCLEdBQUcsUUFBUSxZQUFZO1FBQ3RFLGlCQUFpQixPQUFPLElBQUksQ0FBQyxlQUFlLEVBQUUsUUFBUSxhQUFhLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUM7TUFDM0Y7SUFDRjtJQUVBLDBEQUEwRDtJQUMxRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCO01BQ3JDLFFBQVEsR0FBRyxDQUFDO01BQ1osSUFBSSxRQUFRO1FBQ1YsT0FBTyxNQUFNLFVBQVUsTUFBTSxTQUFTLEVBQUUsVUFBVTtNQUNwRDtNQUNBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQ2IsU0FBUztRQUNULGNBQWMsTUFBTSxTQUFTO1FBQzdCO1FBQ0EsU0FBUztNQUNYLElBQ0E7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSx3Q0FBd0M7SUFDeEMsUUFBUSxHQUFHLENBQUM7SUFFWixNQUFNLFVBQVUsYUFBYyxPQUFPLENBQUMsNENBQTRDO0lBQ2xGLE1BQU0saUJBQWlCLE1BQU0sTUFBTSxDQUFDLEVBQUUsUUFBUSxlQUFlLENBQUMsRUFBRTtNQUM5RCxRQUFRO01BQ1IsU0FBUztRQUNQLGdCQUFnQjtRQUNoQixhQUFhO01BQ2Y7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQ25CLFdBQVcsTUFBTSxTQUFTO1FBQzFCLFVBQVU7TUFDWjtJQUNGO0lBRUEsSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFFO01BQ3RCLE1BQU0sWUFBWSxNQUFNLGVBQWUsSUFBSTtNQUMzQyxRQUFRLEtBQUssQ0FBQyxxQkFBcUIsZUFBZSxNQUFNLEVBQUU7TUFFMUQsdUJBQXVCO01BQ3ZCLElBQUksUUFBUTtRQUNWLE9BQU8sTUFBTSxVQUFVLE1BQU0sU0FBUyxFQUFFLFVBQVU7TUFDcEQ7TUFDQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVCxjQUFjLE1BQU0sU0FBUztRQUM3QjtRQUNBLFNBQVM7UUFDVCxTQUFTO01BQ1gsSUFDQTtRQUFFLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUV0RTtJQUVBLE1BQU0sZUFBZSxNQUFNLGVBQWUsSUFBSTtJQUM5QyxRQUFRLEdBQUcsQ0FBQyx3QkFBd0I7SUFFcEMsTUFBTSxZQUFZLGFBQWEsVUFBVSxJQUFJLE1BQU0sU0FBUztJQUM1RCxNQUFNLFVBQVUsQ0FBQyxDQUFDLGFBQWEsVUFBVTtJQUV6QywyQkFBMkI7SUFDM0IsTUFBTSxTQUFTLEdBQUcsQ0FBQyw0QkFBNEI7TUFBRTtJQUFTO0lBRTFELGtFQUFrRTtJQUNsRSxJQUFJLFFBQVE7TUFDVixRQUFRLEdBQUcsQ0FBQyw2QkFBNkI7TUFDekMsT0FBTyxNQUFNLFVBQVUsV0FBVyxVQUFVO0lBQzlDO0lBRUEscUJBQXFCO0lBQ3JCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNULGNBQWM7TUFDZDtNQUNBO01BQ0EsVUFBVTtRQUNSLFFBQVE7UUFDUixTQUFTO1FBQ1QsTUFBTTtRQUNOLHNCQUFzQixDQUFDLENBQUM7TUFDMUI7SUFDRixJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFnQjtJQUN2QixRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFDMUMsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFRLElBQ2hDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGO0FBRUE7OztDQUdDLEdBQ0QsZUFBZSxVQUNiLEdBQVcsRUFDWCxRQUFnQixFQUNoQixXQUFtQztFQUVuQyxJQUFJO0lBQ0Ysb0VBQW9FO0lBQ3BFLElBQUksY0FBYztJQUNsQixJQUFJLElBQUksUUFBUSxDQUFDLGNBQWM7TUFDN0IsY0FBYyxJQUFJLE9BQU8sQ0FBQyxvQkFBb0I7SUFDaEQ7SUFDQSxNQUFNLGVBQWUsTUFBTSxNQUFNO0lBQ2pDLElBQUksQ0FBQyxhQUFhLEVBQUUsRUFBRTtNQUNwQixNQUFNLElBQUksTUFBTSxDQUFDLHNCQUFzQixFQUFFLGFBQWEsTUFBTSxDQUFDLENBQUM7SUFDaEU7SUFFQSxNQUFNLFdBQVcsTUFBTSxhQUFhLFdBQVc7SUFDL0MsTUFBTSxrQkFBa0IsbUJBQW1CO0lBRTNDLE9BQU8sSUFBSSxTQUFTLFVBQVU7TUFDNUIsU0FBUztRQUNQLEdBQUcsV0FBVztRQUNkLGdCQUFnQjtRQUNoQix1QkFBdUIsQ0FBQyxzQkFBc0IsRUFBRSxnQkFBZ0Isb0JBQW9CLEVBQUUsZ0JBQWdCLENBQUM7UUFDdkcsa0JBQWtCLE9BQU8sU0FBUyxVQUFVO01BQzlDO0lBQ0Y7RUFDRixFQUFFLE9BQU8sS0FBSztJQUNaLFFBQVEsS0FBSyxDQUFDLHFCQUFxQjtJQUNuQyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBdUIsSUFDL0M7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
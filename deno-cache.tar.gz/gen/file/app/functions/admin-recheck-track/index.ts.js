import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseAdmin = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabaseClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      console.error("Auth error:", claimsError);
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const userId = claimsData.claims.sub;
    // Check if user is admin (roles are in user_roles table, not profiles)
    const { data: roles } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", userId);
    const isAdmin = roles?.some((r)=>r.role === "admin" || r.role === "super_admin");
    if (!isAdmin) {
      return new Response(JSON.stringify({
        error: "Forbidden: admin only"
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { trackId } = await req.json();
    if (!trackId) {
      return new Response(JSON.stringify({
        error: "Missing trackId"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Get track data
    const { data: track, error: trackError } = await supabaseAdmin.from("tracks").select("*").eq("id", trackId).single();
    if (trackError || !track) {
      return new Response(JSON.stringify({
        error: "Track not found"
      }), {
        status: 404,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`[Admin Recheck] Track ${trackId}, status: ${track.status}`);
    // Check if track already has permanent audio stored in our Supabase storage
    const supabaseStorageUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const hasLocalAudio = track.audio_url && track.audio_url.includes(supabaseStorageUrl);
    if (hasLocalAudio && track.status === "completed") {
      return new Response(JSON.stringify({
        success: true,
        status: "completed",
        message: "Трек уже готов и сохранён в нашем хранилище",
        audio_url: track.audio_url
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Extract task_id from description
    const taskIdMatch = track.description?.match(/\[task_id:([^\]]+)\]/);
    const taskId = taskIdMatch?.[1]?.trim();
    if (!taskId) {
      // If no task_id but track has audio, it's still usable
      if (track.audio_url) {
        return new Response(JSON.stringify({
          success: true,
          status: "completed",
          message: "Трек имеет аудио, но task_id не найден. Возможно, был создан вручную.",
          audio_url: track.audio_url
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      return new Response(JSON.stringify({
        success: false,
        error: "No task_id found in track description",
        message: "Трек не содержит task_id для проверки"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`[Admin Recheck] Checking Suno task ${taskId}`);
    // Check status with Suno API
    const statusResponse = await fetch(`${SUNO_API_BASE}/api/v1/generate/record?taskId=${taskId}`, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${SUNO_API_KEY}`
      }
    });
    const statusData = await statusResponse.json();
    console.log(`[Admin Recheck] Suno response:`, JSON.stringify(statusData));
    if (statusData.code === 200 && statusData.data) {
      const records = statusData.data.response?.sunoData || statusData.data.data || [];
      const taskStatus = statusData.data.status;
      console.log(`[Admin Recheck] Task status: ${taskStatus}, Records: ${records.length}`);
      // Check for completed status with audio
      if (records.length > 0 && records[0].audio_url) {
        const record = records[0];
        // Download and store audio permanently
        let permanentAudioUrl = record.audio_url;
        let permanentCoverUrl = record.image_url || track.cover_url;
        try {
          // Download audio
          const audioResponse = await fetch(record.audio_url);
          if (audioResponse.ok) {
            const audioBuffer = await audioResponse.arrayBuffer();
            const audioPath = `${track.user_id}/${trackId}.mp3`;
            const { error: audioUploadError } = await supabaseAdmin.storage.from("tracks").upload(audioPath, audioBuffer, {
              contentType: "audio/mpeg",
              upsert: true
            });
            if (!audioUploadError) {
              const { data: audioUrlData } = supabaseAdmin.storage.from("tracks").getPublicUrl(audioPath);
              permanentAudioUrl = audioUrlData.publicUrl;
              console.log(`[Admin Recheck] Audio saved: ${permanentAudioUrl}`);
            } else {
              console.error(`[Admin Recheck] Audio upload error:`, audioUploadError);
            }
          }
          // Download cover if available
          if (record.image_url) {
            const coverResponse = await fetch(record.image_url);
            if (coverResponse.ok) {
              const coverBuffer = await coverResponse.arrayBuffer();
              const coverPath = `${track.user_id}/${trackId}-cover.jpg`;
              const { error: coverUploadError } = await supabaseAdmin.storage.from("tracks").upload(coverPath, coverBuffer, {
                contentType: "image/jpeg",
                upsert: true
              });
              if (!coverUploadError) {
                const { data: coverUrlData } = supabaseAdmin.storage.from("tracks").getPublicUrl(coverPath);
                permanentCoverUrl = coverUrlData.publicUrl;
                console.log(`[Admin Recheck] Cover saved: ${permanentCoverUrl}`);
              }
            }
          }
        } catch (downloadError) {
          console.error(`[Admin Recheck] Download error:`, downloadError);
        // Continue with original URLs if download fails
        }
        // Update track with audio URL
        const { error: updateError } = await supabaseAdmin.from("tracks").update({
          audio_url: permanentAudioUrl,
          cover_url: permanentCoverUrl,
          duration: record.duration ? Math.round(record.duration) : null,
          status: "completed",
          error_message: null,
          suno_audio_id: record.id || null
        }).eq("id", trackId);
        if (updateError) {
          console.error("[Admin Recheck] Error updating track:", updateError);
          return new Response(JSON.stringify({
            success: false,
            error: updateError.message
          }), {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json"
            }
          });
        }
        return new Response(JSON.stringify({
          success: true,
          status: "completed",
          message: "Трек успешно обновлён!",
          audio_url: permanentAudioUrl
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Check for failed status
      if (taskStatus === "GENERATE_AUDIO_FAILED" || taskStatus === "FAILED" || taskStatus === "ERROR") {
        const errorMessage = statusData.data.fail_reason || statusData.data.error_message || "Генерация отклонена сервисом";
        await supabaseAdmin.from("tracks").update({
          status: "failed",
          error_message: errorMessage
        }).eq("id", trackId);
        return new Response(JSON.stringify({
          success: false,
          status: "failed",
          message: `Ошибка генерации: ${errorMessage}`
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      // Still processing
      return new Response(JSON.stringify({
        success: false,
        status: taskStatus || "processing",
        message: `Статус: ${taskStatus}. Трек ещё генерируется.`
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // API returned error or no data - check if it's a 404 (task expired)
    if (statusData.status === 404 || statusData.error === "Not Found") {
      // Task no longer exists on Suno servers - check if we have local audio
      if (track.audio_url) {
        // We have audio, just update status to completed
        await supabaseAdmin.from("tracks").update({
          status: "completed",
          error_message: null
        }).eq("id", trackId);
        return new Response(JSON.stringify({
          success: true,
          status: "completed",
          message: "Задача удалена с сервера Suno, но аудио доступно. Статус обновлён.",
          audio_url: track.audio_url
        }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      return new Response(JSON.stringify({
        success: false,
        status: "expired",
        message: "Задача удалена с сервера Suno и аудио недоступно. Генерация не может быть восстановлена."
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    return new Response(JSON.stringify({
      success: false,
      status: "unknown",
      message: `Suno API ответил: ${statusData.msg || statusData.error || "Unknown error"}`,
      raw: statusData
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("[Admin Recheck] Error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: errorMessage
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9hZG1pbi1yZWNoZWNrLXRyYWNrL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE2OC4wL2h0dHAvc2VydmVyLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuY29uc3QgU1VOT19BUElfS0VZID0gRGVuby5lbnYuZ2V0KFwiU1VOT19BUElfS0VZXCIpO1xuY29uc3QgU1VOT19BUElfQkFTRSA9IFwiaHR0cHM6Ly9hcGlib3guZXJ3ZWltYS5haVwiO1xuXG5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyPy5zdGFydHNXaXRoKFwiQmVhcmVyIFwiKSkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJObyBhdXRob3JpemF0aW9uIGhlYWRlclwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgc3VwYWJhc2VBZG1pbiA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSA/PyBcIlwiXG4gICAgKTtcblxuICAgIGNvbnN0IHN1cGFiYXNlQ2xpZW50ID0gY3JlYXRlQ2xpZW50KFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpID8/IFwiXCIsXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9BTk9OX0tFWVwiKSA/PyBcIlwiLFxuICAgICAgeyBnbG9iYWw6IHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyIH0gfSB9XG4gICAgKTtcblxuICAgIGNvbnN0IHRva2VuID0gYXV0aEhlYWRlci5yZXBsYWNlKFwiQmVhcmVyIFwiLCBcIlwiKTtcbiAgICBjb25zdCB7IGRhdGE6IGNsYWltc0RhdGEsIGVycm9yOiBjbGFpbXNFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnQuYXV0aC5nZXRDbGFpbXModG9rZW4pO1xuICAgIFxuICAgIGlmIChjbGFpbXNFcnJvciB8fCAhY2xhaW1zRGF0YT8uY2xhaW1zPy5zdWIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJBdXRoIGVycm9yOlwiLCBjbGFpbXNFcnJvcik7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlVuYXV0aG9yaXplZFwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHVzZXJJZCA9IGNsYWltc0RhdGEuY2xhaW1zLnN1YjtcblxuICAgIC8vIENoZWNrIGlmIHVzZXIgaXMgYWRtaW4gKHJvbGVzIGFyZSBpbiB1c2VyX3JvbGVzIHRhYmxlLCBub3QgcHJvZmlsZXMpXG4gICAgY29uc3QgeyBkYXRhOiByb2xlcyB9ID0gYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgLmZyb20oXCJ1c2VyX3JvbGVzXCIpXG4gICAgICAuc2VsZWN0KFwicm9sZVwiKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuXG4gICAgY29uc3QgaXNBZG1pbiA9IHJvbGVzPy5zb21lKHIgPT4gci5yb2xlID09PSBcImFkbWluXCIgfHwgci5yb2xlID09PSBcInN1cGVyX2FkbWluXCIpO1xuICAgIGlmICghaXNBZG1pbikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJGb3JiaWRkZW46IGFkbWluIG9ubHlcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMywgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHsgdHJhY2tJZCB9ID0gYXdhaXQgcmVxLmpzb24oKTtcblxuICAgIGlmICghdHJhY2tJZCkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJNaXNzaW5nIHRyYWNrSWRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIEdldCB0cmFjayBkYXRhXG4gICAgY29uc3QgeyBkYXRhOiB0cmFjaywgZXJyb3I6IHRyYWNrRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAuc2VsZWN0KFwiKlwiKVxuICAgICAgLmVxKFwiaWRcIiwgdHJhY2tJZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICh0cmFja0Vycm9yIHx8ICF0cmFjaykge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJUcmFjayBub3QgZm91bmRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwNCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBbQWRtaW4gUmVjaGVja10gVHJhY2sgJHt0cmFja0lkfSwgc3RhdHVzOiAke3RyYWNrLnN0YXR1c31gKTtcblxuICAgIC8vIENoZWNrIGlmIHRyYWNrIGFscmVhZHkgaGFzIHBlcm1hbmVudCBhdWRpbyBzdG9yZWQgaW4gb3VyIFN1cGFiYXNlIHN0b3JhZ2VcbiAgICBjb25zdCBzdXBhYmFzZVN0b3JhZ2VVcmwgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgPz8gXCJcIjtcbiAgICBjb25zdCBoYXNMb2NhbEF1ZGlvID0gdHJhY2suYXVkaW9fdXJsICYmIHRyYWNrLmF1ZGlvX3VybC5pbmNsdWRlcyhzdXBhYmFzZVN0b3JhZ2VVcmwpO1xuICAgIFxuICAgIGlmIChoYXNMb2NhbEF1ZGlvICYmIHRyYWNrLnN0YXR1cyA9PT0gXCJjb21wbGV0ZWRcIikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgIHN0YXR1czogXCJjb21wbGV0ZWRcIixcbiAgICAgICAgICBtZXNzYWdlOiBcItCi0YDQtdC6INGD0LbQtSDQs9C+0YLQvtCyINC4INGB0L7RhdGA0LDQvdGR0L0g0LIg0L3QsNGI0LXQvCDRhdGA0LDQvdC40LvQuNGJ0LVcIixcbiAgICAgICAgICBhdWRpb191cmw6IHRyYWNrLmF1ZGlvX3VybFxuICAgICAgICB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gRXh0cmFjdCB0YXNrX2lkIGZyb20gZGVzY3JpcHRpb25cbiAgICBjb25zdCB0YXNrSWRNYXRjaCA9IHRyYWNrLmRlc2NyaXB0aW9uPy5tYXRjaCgvXFxbdGFza19pZDooW15cXF1dKylcXF0vKTtcbiAgICBjb25zdCB0YXNrSWQgPSB0YXNrSWRNYXRjaD8uWzFdPy50cmltKCk7XG5cbiAgICBpZiAoIXRhc2tJZCkge1xuICAgICAgLy8gSWYgbm8gdGFza19pZCBidXQgdHJhY2sgaGFzIGF1ZGlvLCBpdCdzIHN0aWxsIHVzYWJsZVxuICAgICAgaWYgKHRyYWNrLmF1ZGlvX3VybCkge1xuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCLQotGA0LXQuiDQuNC80LXQtdGCINCw0YPQtNC40L4sINC90L4gdGFza19pZCDQvdC1INC90LDQudC00LXQvS4g0JLQvtC30LzQvtC20L3Qviwg0LHRi9C7INGB0L7Qt9C00LDQvSDQstGA0YPRh9C90YPRji5cIixcbiAgICAgICAgICAgIGF1ZGlvX3VybDogdHJhY2suYXVkaW9fdXJsXG4gICAgICAgICAgfSksXG4gICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICBlcnJvcjogXCJObyB0YXNrX2lkIGZvdW5kIGluIHRyYWNrIGRlc2NyaXB0aW9uXCIsXG4gICAgICAgICAgbWVzc2FnZTogXCLQotGA0LXQuiDQvdC1INGB0L7QtNC10YDQttC40YIgdGFza19pZCDQtNC70Y8g0L/RgNC+0LLQtdGA0LrQuFwiXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhgW0FkbWluIFJlY2hlY2tdIENoZWNraW5nIFN1bm8gdGFzayAke3Rhc2tJZH1gKTtcblxuICAgIC8vIENoZWNrIHN0YXR1cyB3aXRoIFN1bm8gQVBJXG4gICAgY29uc3Qgc3RhdHVzUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtTVU5PX0FQSV9CQVNFfS9hcGkvdjEvZ2VuZXJhdGUvcmVjb3JkP3Rhc2tJZD0ke3Rhc2tJZH1gLCB7XG4gICAgICBtZXRob2Q6IFwiR0VUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgY29uc3Qgc3RhdHVzRGF0YSA9IGF3YWl0IHN0YXR1c1Jlc3BvbnNlLmpzb24oKTtcbiAgICBjb25zb2xlLmxvZyhgW0FkbWluIFJlY2hlY2tdIFN1bm8gcmVzcG9uc2U6YCwgSlNPTi5zdHJpbmdpZnkoc3RhdHVzRGF0YSkpO1xuXG4gICAgaWYgKHN0YXR1c0RhdGEuY29kZSA9PT0gMjAwICYmIHN0YXR1c0RhdGEuZGF0YSkge1xuICAgICAgY29uc3QgcmVjb3JkcyA9IHN0YXR1c0RhdGEuZGF0YS5yZXNwb25zZT8uc3Vub0RhdGEgfHwgc3RhdHVzRGF0YS5kYXRhLmRhdGEgfHwgW107XG4gICAgICBjb25zdCB0YXNrU3RhdHVzID0gc3RhdHVzRGF0YS5kYXRhLnN0YXR1cztcbiAgICAgIFxuICAgICAgY29uc29sZS5sb2coYFtBZG1pbiBSZWNoZWNrXSBUYXNrIHN0YXR1czogJHt0YXNrU3RhdHVzfSwgUmVjb3JkczogJHtyZWNvcmRzLmxlbmd0aH1gKTtcbiAgICAgIFxuICAgICAgLy8gQ2hlY2sgZm9yIGNvbXBsZXRlZCBzdGF0dXMgd2l0aCBhdWRpb1xuICAgICAgaWYgKHJlY29yZHMubGVuZ3RoID4gMCAmJiByZWNvcmRzWzBdLmF1ZGlvX3VybCkge1xuICAgICAgICBjb25zdCByZWNvcmQgPSByZWNvcmRzWzBdO1xuICAgICAgICBcbiAgICAgICAgLy8gRG93bmxvYWQgYW5kIHN0b3JlIGF1ZGlvIHBlcm1hbmVudGx5XG4gICAgICAgIGxldCBwZXJtYW5lbnRBdWRpb1VybCA9IHJlY29yZC5hdWRpb191cmw7XG4gICAgICAgIGxldCBwZXJtYW5lbnRDb3ZlclVybCA9IHJlY29yZC5pbWFnZV91cmwgfHwgdHJhY2suY292ZXJfdXJsO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgLy8gRG93bmxvYWQgYXVkaW9cbiAgICAgICAgICBjb25zdCBhdWRpb1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2gocmVjb3JkLmF1ZGlvX3VybCk7XG4gICAgICAgICAgaWYgKGF1ZGlvUmVzcG9uc2Uub2spIHtcbiAgICAgICAgICAgIGNvbnN0IGF1ZGlvQnVmZmVyID0gYXdhaXQgYXVkaW9SZXNwb25zZS5hcnJheUJ1ZmZlcigpO1xuICAgICAgICAgICAgY29uc3QgYXVkaW9QYXRoID0gYCR7dHJhY2sudXNlcl9pZH0vJHt0cmFja0lkfS5tcDNgO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBjb25zdCB7IGVycm9yOiBhdWRpb1VwbG9hZEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluLnN0b3JhZ2VcbiAgICAgICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAgICAgLnVwbG9hZChhdWRpb1BhdGgsIGF1ZGlvQnVmZmVyLCB7XG4gICAgICAgICAgICAgICAgY29udGVudFR5cGU6IFwiYXVkaW8vbXBlZ1wiLFxuICAgICAgICAgICAgICAgIHVwc2VydDogdHJ1ZSxcbiAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGlmICghYXVkaW9VcGxvYWRFcnJvcikge1xuICAgICAgICAgICAgICBjb25zdCB7IGRhdGE6IGF1ZGlvVXJsRGF0YSB9ID0gc3VwYWJhc2VBZG1pbi5zdG9yYWdlXG4gICAgICAgICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAgICAgICAuZ2V0UHVibGljVXJsKGF1ZGlvUGF0aCk7XG4gICAgICAgICAgICAgIHBlcm1hbmVudEF1ZGlvVXJsID0gYXVkaW9VcmxEYXRhLnB1YmxpY1VybDtcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coYFtBZG1pbiBSZWNoZWNrXSBBdWRpbyBzYXZlZDogJHtwZXJtYW5lbnRBdWRpb1VybH1gKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFtBZG1pbiBSZWNoZWNrXSBBdWRpbyB1cGxvYWQgZXJyb3I6YCwgYXVkaW9VcGxvYWRFcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gRG93bmxvYWQgY292ZXIgaWYgYXZhaWxhYmxlXG4gICAgICAgICAgaWYgKHJlY29yZC5pbWFnZV91cmwpIHtcbiAgICAgICAgICAgIGNvbnN0IGNvdmVyUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChyZWNvcmQuaW1hZ2VfdXJsKTtcbiAgICAgICAgICAgIGlmIChjb3ZlclJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGNvdmVyQnVmZmVyID0gYXdhaXQgY292ZXJSZXNwb25zZS5hcnJheUJ1ZmZlcigpO1xuICAgICAgICAgICAgICBjb25zdCBjb3ZlclBhdGggPSBgJHt0cmFjay51c2VyX2lkfS8ke3RyYWNrSWR9LWNvdmVyLmpwZ2A7XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICBjb25zdCB7IGVycm9yOiBjb3ZlclVwbG9hZEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluLnN0b3JhZ2VcbiAgICAgICAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgICAgICAgIC51cGxvYWQoY292ZXJQYXRoLCBjb3ZlckJ1ZmZlciwge1xuICAgICAgICAgICAgICAgICAgY29udGVudFR5cGU6IFwiaW1hZ2UvanBlZ1wiLFxuICAgICAgICAgICAgICAgICAgdXBzZXJ0OiB0cnVlLFxuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgIGlmICghY292ZXJVcGxvYWRFcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnN0IHsgZGF0YTogY292ZXJVcmxEYXRhIH0gPSBzdXBhYmFzZUFkbWluLnN0b3JhZ2VcbiAgICAgICAgICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgICAgICAgICAuZ2V0UHVibGljVXJsKGNvdmVyUGF0aCk7XG4gICAgICAgICAgICAgICAgcGVybWFuZW50Q292ZXJVcmwgPSBjb3ZlclVybERhdGEucHVibGljVXJsO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBbQWRtaW4gUmVjaGVja10gQ292ZXIgc2F2ZWQ6ICR7cGVybWFuZW50Q292ZXJVcmx9YCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGRvd25sb2FkRXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGBbQWRtaW4gUmVjaGVja10gRG93bmxvYWQgZXJyb3I6YCwgZG93bmxvYWRFcnJvcik7XG4gICAgICAgICAgLy8gQ29udGludWUgd2l0aCBvcmlnaW5hbCBVUkxzIGlmIGRvd25sb2FkIGZhaWxzXG4gICAgICAgIH1cblxuICAgICAgICAvLyBVcGRhdGUgdHJhY2sgd2l0aCBhdWRpbyBVUkxcbiAgICAgICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQWRtaW5cbiAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgIC51cGRhdGUoe1xuICAgICAgICAgICAgYXVkaW9fdXJsOiBwZXJtYW5lbnRBdWRpb1VybCxcbiAgICAgICAgICAgIGNvdmVyX3VybDogcGVybWFuZW50Q292ZXJVcmwsXG4gICAgICAgICAgICBkdXJhdGlvbjogcmVjb3JkLmR1cmF0aW9uID8gTWF0aC5yb3VuZChyZWNvcmQuZHVyYXRpb24pIDogbnVsbCxcbiAgICAgICAgICAgIHN0YXR1czogXCJjb21wbGV0ZWRcIixcbiAgICAgICAgICAgIGVycm9yX21lc3NhZ2U6IG51bGwsXG4gICAgICAgICAgICBzdW5vX2F1ZGlvX2lkOiByZWNvcmQuaWQgfHwgbnVsbCxcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpO1xuXG4gICAgICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJbQWRtaW4gUmVjaGVja10gRXJyb3IgdXBkYXRpbmcgdHJhY2s6XCIsIHVwZGF0ZUVycm9yKTtcbiAgICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgICAgICAgIGVycm9yOiB1cGRhdGVFcnJvci5tZXNzYWdlXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcItCi0YDQtdC6INGD0YHQv9C10YjQvdC+INC+0LHQvdC+0LLQu9GR0L0hXCIsXG4gICAgICAgICAgICBhdWRpb191cmw6IHBlcm1hbmVudEF1ZGlvVXJsXG4gICAgICAgICAgfSksXG4gICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgLy8gQ2hlY2sgZm9yIGZhaWxlZCBzdGF0dXNcbiAgICAgIGlmICh0YXNrU3RhdHVzID09PSBcIkdFTkVSQVRFX0FVRElPX0ZBSUxFRFwiIHx8IHRhc2tTdGF0dXMgPT09IFwiRkFJTEVEXCIgfHwgdGFza1N0YXR1cyA9PT0gXCJFUlJPUlwiKSB7XG4gICAgICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IHN0YXR1c0RhdGEuZGF0YS5mYWlsX3JlYXNvbiB8fCBzdGF0dXNEYXRhLmRhdGEuZXJyb3JfbWVzc2FnZSB8fCBcItCT0LXQvdC10YDQsNGG0LjRjyDQvtGC0LrQu9C+0L3QtdC90LAg0YHQtdGA0LLQuNGB0L7QvFwiO1xuICAgICAgICBcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgICBzdGF0dXM6IFwiZmFpbGVkXCIsXG4gICAgICAgICAgICBlcnJvcl9tZXNzYWdlOiBlcnJvck1lc3NhZ2UsXG4gICAgICAgICAgfSlcbiAgICAgICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKTtcblxuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgICAgIG1lc3NhZ2U6IGDQntGI0LjQsdC60LAg0LPQtdC90LXRgNCw0YbQuNC4OiAke2Vycm9yTWVzc2FnZX1gXG4gICAgICAgICAgfSksXG4gICAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgLy8gU3RpbGwgcHJvY2Vzc2luZ1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICBzdGF0dXM6IHRhc2tTdGF0dXMgfHwgXCJwcm9jZXNzaW5nXCIsXG4gICAgICAgICAgbWVzc2FnZTogYNCh0YLQsNGC0YPRgTogJHt0YXNrU3RhdHVzfS4g0KLRgNC10Log0LXRidGRINCz0LXQvdC10YDQuNGA0YPQtdGC0YHRjy5gXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG4gICAgXG4gICAgLy8gQVBJIHJldHVybmVkIGVycm9yIG9yIG5vIGRhdGEgLSBjaGVjayBpZiBpdCdzIGEgNDA0ICh0YXNrIGV4cGlyZWQpXG4gICAgaWYgKHN0YXR1c0RhdGEuc3RhdHVzID09PSA0MDQgfHwgc3RhdHVzRGF0YS5lcnJvciA9PT0gXCJOb3QgRm91bmRcIikge1xuICAgICAgLy8gVGFzayBubyBsb25nZXIgZXhpc3RzIG9uIFN1bm8gc2VydmVycyAtIGNoZWNrIGlmIHdlIGhhdmUgbG9jYWwgYXVkaW9cbiAgICAgIGlmICh0cmFjay5hdWRpb191cmwpIHtcbiAgICAgICAgLy8gV2UgaGF2ZSBhdWRpbywganVzdCB1cGRhdGUgc3RhdHVzIHRvIGNvbXBsZXRlZFxuICAgICAgICBhd2FpdCBzdXBhYmFzZUFkbWluXG4gICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAudXBkYXRlKHtcbiAgICAgICAgICAgIHN0YXR1czogXCJjb21wbGV0ZWRcIixcbiAgICAgICAgICAgIGVycm9yX21lc3NhZ2U6IG51bGwsXG4gICAgICAgICAgfSlcbiAgICAgICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKTtcblxuICAgICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCLQl9Cw0LTQsNGH0LAg0YPQtNCw0LvQtdC90LAg0YEg0YHQtdGA0LLQtdGA0LAgU3Vubywg0L3QviDQsNGD0LTQuNC+INC00L7RgdGC0YPQv9C90L4uINCh0YLQsNGC0YPRgSDQvtCx0L3QvtCy0LvRkdC9LlwiLFxuICAgICAgICAgICAgYXVkaW9fdXJsOiB0cmFjay5hdWRpb191cmxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IFxuICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgIHN0YXR1czogXCJleHBpcmVkXCIsXG4gICAgICAgICAgbWVzc2FnZTogXCLQl9Cw0LTQsNGH0LAg0YPQtNCw0LvQtdC90LAg0YEg0YHQtdGA0LLQtdGA0LAgU3VubyDQuCDQsNGD0LTQuNC+INC90LXQtNC+0YHRgtGD0L/QvdC+LiDQk9C10L3QtdGA0LDRhtC40Y8g0L3QtSDQvNC+0LbQtdGCINCx0YvRgtGMINCy0L7RgdGB0YLQsNC90L7QstC70LXQvdCwLlwiXG4gICAgICAgIH0pLFxuICAgICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIHN0YXR1czogXCJ1bmtub3duXCIsXG4gICAgICAgIG1lc3NhZ2U6IGBTdW5vIEFQSSDQvtGC0LLQtdGC0LjQuzogJHtzdGF0dXNEYXRhLm1zZyB8fCBzdGF0dXNEYXRhLmVycm9yIHx8IFwiVW5rbm93biBlcnJvclwifWAsXG4gICAgICAgIHJhdzogc3RhdHVzRGF0YVxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiW0FkbWluIFJlY2hlY2tdIEVycm9yOlwiLCBlcnJvcik7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogZXJyb3JNZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDUwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxLQUFLLFFBQVEsK0NBQStDO0FBQ3JFLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDbEMsTUFBTSxnQkFBZ0I7QUFFdEIsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWSxXQUFXLFlBQVk7TUFDdEMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQTBCLElBQ2xEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sZ0JBQWdCLGFBQ3BCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFDaEMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdDQUFnQztJQUcvQyxNQUFNLGlCQUFpQixhQUNyQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFDckM7TUFBRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQUU7SUFHdkQsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxTQUFTLENBQUM7SUFFckYsSUFBSSxlQUFlLENBQUMsWUFBWSxRQUFRLEtBQUs7TUFDM0MsUUFBUSxLQUFLLENBQUMsZUFBZTtNQUM3QixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBZSxJQUN2QztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFNBQVMsV0FBVyxNQUFNLENBQUMsR0FBRztJQUVwQyx1RUFBdUU7SUFDdkUsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLEdBQUcsTUFBTSxjQUMzQixJQUFJLENBQUMsY0FDTCxNQUFNLENBQUMsUUFDUCxFQUFFLENBQUMsV0FBVztJQUVqQixNQUFNLFVBQVUsT0FBTyxLQUFLLENBQUEsSUFBSyxFQUFFLElBQUksS0FBSyxXQUFXLEVBQUUsSUFBSSxLQUFLO0lBQ2xFLElBQUksQ0FBQyxTQUFTO01BQ1osT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQXdCLElBQ2hEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sRUFBRSxPQUFPLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUVsQyxJQUFJLENBQUMsU0FBUztNQUNaLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFrQixJQUMxQztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxpQkFBaUI7SUFDakIsTUFBTSxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxjQUM5QyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsS0FDUCxFQUFFLENBQUMsTUFBTSxTQUNULE1BQU07SUFFVCxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUFrQixJQUMxQztRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLFFBQVEsVUFBVSxFQUFFLE1BQU0sTUFBTSxDQUFDLENBQUM7SUFFdkUsNEVBQTRFO0lBQzVFLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUI7SUFDM0QsTUFBTSxnQkFBZ0IsTUFBTSxTQUFTLElBQUksTUFBTSxTQUFTLENBQUMsUUFBUSxDQUFDO0lBRWxFLElBQUksaUJBQWlCLE1BQU0sTUFBTSxLQUFLLGFBQWE7TUFDakQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixTQUFTO1FBQ1QsUUFBUTtRQUNSLFNBQVM7UUFDVCxXQUFXLE1BQU0sU0FBUztNQUM1QixJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsbUNBQW1DO0lBQ25DLE1BQU0sY0FBYyxNQUFNLFdBQVcsRUFBRSxNQUFNO0lBQzdDLE1BQU0sU0FBUyxhQUFhLENBQUMsRUFBRSxFQUFFO0lBRWpDLElBQUksQ0FBQyxRQUFRO01BQ1gsdURBQXVEO01BQ3ZELElBQUksTUFBTSxTQUFTLEVBQUU7UUFDbkIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsUUFBUTtVQUNSLFNBQVM7VUFDVCxXQUFXLE1BQU0sU0FBUztRQUM1QixJQUNBO1VBQUUsU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRXRFO01BRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixTQUFTO1FBQ1QsT0FBTztRQUNQLFNBQVM7TUFDWCxJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQyxtQ0FBbUMsRUFBRSxPQUFPLENBQUM7SUFFMUQsNkJBQTZCO0lBQzdCLE1BQU0saUJBQWlCLE1BQU0sTUFBTSxDQUFDLEVBQUUsY0FBYywrQkFBK0IsRUFBRSxPQUFPLENBQUMsRUFBRTtNQUM3RixRQUFRO01BQ1IsU0FBUztRQUNQLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7SUFDRjtJQUVBLE1BQU0sYUFBYSxNQUFNLGVBQWUsSUFBSTtJQUM1QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLDhCQUE4QixDQUFDLEVBQUUsS0FBSyxTQUFTLENBQUM7SUFFN0QsSUFBSSxXQUFXLElBQUksS0FBSyxPQUFPLFdBQVcsSUFBSSxFQUFFO01BQzlDLE1BQU0sVUFBVSxXQUFXLElBQUksQ0FBQyxRQUFRLEVBQUUsWUFBWSxXQUFXLElBQUksQ0FBQyxJQUFJLElBQUksRUFBRTtNQUNoRixNQUFNLGFBQWEsV0FBVyxJQUFJLENBQUMsTUFBTTtNQUV6QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLDZCQUE2QixFQUFFLFdBQVcsV0FBVyxFQUFFLFFBQVEsTUFBTSxDQUFDLENBQUM7TUFFcEYsd0NBQXdDO01BQ3hDLElBQUksUUFBUSxNQUFNLEdBQUcsS0FBSyxPQUFPLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRTtRQUM5QyxNQUFNLFNBQVMsT0FBTyxDQUFDLEVBQUU7UUFFekIsdUNBQXVDO1FBQ3ZDLElBQUksb0JBQW9CLE9BQU8sU0FBUztRQUN4QyxJQUFJLG9CQUFvQixPQUFPLFNBQVMsSUFBSSxNQUFNLFNBQVM7UUFFM0QsSUFBSTtVQUNGLGlCQUFpQjtVQUNqQixNQUFNLGdCQUFnQixNQUFNLE1BQU0sT0FBTyxTQUFTO1VBQ2xELElBQUksY0FBYyxFQUFFLEVBQUU7WUFDcEIsTUFBTSxjQUFjLE1BQU0sY0FBYyxXQUFXO1lBQ25ELE1BQU0sWUFBWSxDQUFDLEVBQUUsTUFBTSxPQUFPLENBQUMsQ0FBQyxFQUFFLFFBQVEsSUFBSSxDQUFDO1lBRW5ELE1BQU0sRUFBRSxPQUFPLGdCQUFnQixFQUFFLEdBQUcsTUFBTSxjQUFjLE9BQU8sQ0FDNUQsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLFdBQVcsYUFBYTtjQUM5QixhQUFhO2NBQ2IsUUFBUTtZQUNWO1lBRUYsSUFBSSxDQUFDLGtCQUFrQjtjQUNyQixNQUFNLEVBQUUsTUFBTSxZQUFZLEVBQUUsR0FBRyxjQUFjLE9BQU8sQ0FDakQsSUFBSSxDQUFDLFVBQ0wsWUFBWSxDQUFDO2NBQ2hCLG9CQUFvQixhQUFhLFNBQVM7Y0FDMUMsUUFBUSxHQUFHLENBQUMsQ0FBQyw2QkFBNkIsRUFBRSxrQkFBa0IsQ0FBQztZQUNqRSxPQUFPO2NBQ0wsUUFBUSxLQUFLLENBQUMsQ0FBQyxtQ0FBbUMsQ0FBQyxFQUFFO1lBQ3ZEO1VBQ0Y7VUFFQSw4QkFBOEI7VUFDOUIsSUFBSSxPQUFPLFNBQVMsRUFBRTtZQUNwQixNQUFNLGdCQUFnQixNQUFNLE1BQU0sT0FBTyxTQUFTO1lBQ2xELElBQUksY0FBYyxFQUFFLEVBQUU7Y0FDcEIsTUFBTSxjQUFjLE1BQU0sY0FBYyxXQUFXO2NBQ25ELE1BQU0sWUFBWSxDQUFDLEVBQUUsTUFBTSxPQUFPLENBQUMsQ0FBQyxFQUFFLFFBQVEsVUFBVSxDQUFDO2NBRXpELE1BQU0sRUFBRSxPQUFPLGdCQUFnQixFQUFFLEdBQUcsTUFBTSxjQUFjLE9BQU8sQ0FDNUQsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLFdBQVcsYUFBYTtnQkFDOUIsYUFBYTtnQkFDYixRQUFRO2NBQ1Y7Y0FFRixJQUFJLENBQUMsa0JBQWtCO2dCQUNyQixNQUFNLEVBQUUsTUFBTSxZQUFZLEVBQUUsR0FBRyxjQUFjLE9BQU8sQ0FDakQsSUFBSSxDQUFDLFVBQ0wsWUFBWSxDQUFDO2dCQUNoQixvQkFBb0IsYUFBYSxTQUFTO2dCQUMxQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLDZCQUE2QixFQUFFLGtCQUFrQixDQUFDO2NBQ2pFO1lBQ0Y7VUFDRjtRQUNGLEVBQUUsT0FBTyxlQUFlO1VBQ3RCLFFBQVEsS0FBSyxDQUFDLENBQUMsK0JBQStCLENBQUMsRUFBRTtRQUNqRCxnREFBZ0Q7UUFDbEQ7UUFFQSw4QkFBOEI7UUFDOUIsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxjQUNsQyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7VUFDTixXQUFXO1VBQ1gsV0FBVztVQUNYLFVBQVUsT0FBTyxRQUFRLEdBQUcsS0FBSyxLQUFLLENBQUMsT0FBTyxRQUFRLElBQUk7VUFDMUQsUUFBUTtVQUNSLGVBQWU7VUFDZixlQUFlLE9BQU8sRUFBRSxJQUFJO1FBQzlCLEdBQ0MsRUFBRSxDQUFDLE1BQU07UUFFWixJQUFJLGFBQWE7VUFDZixRQUFRLEtBQUssQ0FBQyx5Q0FBeUM7VUFDdkQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7WUFDYixTQUFTO1lBQ1QsT0FBTyxZQUFZLE9BQU87VUFDNUIsSUFDQTtZQUFFLFNBQVM7Y0FBRSxHQUFHLFdBQVc7Y0FBRSxnQkFBZ0I7WUFBbUI7VUFBRTtRQUV0RTtRQUVBLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1VBQ2IsU0FBUztVQUNULFFBQVE7VUFDUixTQUFTO1VBQ1QsV0FBVztRQUNiLElBQ0E7VUFBRSxTQUFTO1lBQUUsR0FBRyxXQUFXO1lBQUUsZ0JBQWdCO1VBQW1CO1FBQUU7TUFFdEU7TUFFQSwwQkFBMEI7TUFDMUIsSUFBSSxlQUFlLDJCQUEyQixlQUFlLFlBQVksZUFBZSxTQUFTO1FBQy9GLE1BQU0sZUFBZSxXQUFXLElBQUksQ0FBQyxXQUFXLElBQUksV0FBVyxJQUFJLENBQUMsYUFBYSxJQUFJO1FBRXJGLE1BQU0sY0FDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7VUFDTixRQUFRO1VBQ1IsZUFBZTtRQUNqQixHQUNDLEVBQUUsQ0FBQyxNQUFNO1FBRVosT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsUUFBUTtVQUNSLFNBQVMsQ0FBQyxrQkFBa0IsRUFBRSxhQUFhLENBQUM7UUFDOUMsSUFDQTtVQUFFLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUV0RTtNQUVBLG1CQUFtQjtNQUNuQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVCxRQUFRLGNBQWM7UUFDdEIsU0FBUyxDQUFDLFFBQVEsRUFBRSxXQUFXLHdCQUF3QixDQUFDO01BQzFELElBQ0E7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFdEU7SUFFQSxxRUFBcUU7SUFDckUsSUFBSSxXQUFXLE1BQU0sS0FBSyxPQUFPLFdBQVcsS0FBSyxLQUFLLGFBQWE7TUFDakUsdUVBQXVFO01BQ3ZFLElBQUksTUFBTSxTQUFTLEVBQUU7UUFDbkIsaURBQWlEO1FBQ2pELE1BQU0sY0FDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7VUFDTixRQUFRO1VBQ1IsZUFBZTtRQUNqQixHQUNDLEVBQUUsQ0FBQyxNQUFNO1FBRVosT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFDYixTQUFTO1VBQ1QsUUFBUTtVQUNSLFNBQVM7VUFDVCxXQUFXLE1BQU0sU0FBUztRQUM1QixJQUNBO1VBQUUsU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRXRFO01BRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixTQUFTO1FBQ1QsUUFBUTtRQUNSLFNBQVM7TUFDWCxJQUNBO1FBQUUsU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRXRFO0lBRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFDYixTQUFTO01BQ1QsUUFBUTtNQUNSLFNBQVMsQ0FBQyxrQkFBa0IsRUFBRSxXQUFXLEdBQUcsSUFBSSxXQUFXLEtBQUssSUFBSSxnQkFBZ0IsQ0FBQztNQUNyRixLQUFLO0lBQ1AsSUFDQTtNQUFFLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUd0RSxFQUFFLE9BQU8sT0FBTztJQUNkLFFBQVEsS0FBSyxDQUFDLDBCQUEwQjtJQUN4QyxNQUFNLGVBQWUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDOUQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQWEsSUFDckM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
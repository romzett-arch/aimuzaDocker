import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Генерация SHA-256 хеша
async function generateHash(data) {
  const encoder = new TextEncoder();
  const dataBuffer = encoder.encode(data);
  const hashBuffer = await crypto.subtle.digest("SHA-256", dataBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b)=>b.toString(16).padStart(2, "0")).join("");
}
// Переписываем старые Supabase URL на текущий API (после миграции storage на aimuza.ru)
function resolveAudioUrl(url) {
  const supabaseUrl = Deno.env.get("SUPABASE_URL") || "https://aimuza.ru";
  const oldSupabase = /https:\/\/[a-z]+\.supabase\.co/;
  if (oldSupabase.test(url)) {
    const path = new URL(url).pathname;
    return `${supabaseUrl}${path}`;
  }
  return url;
}
// Получаем хеш аудиофайла
async function getAudioHash(audioUrl) {
  const resolvedUrl = resolveAudioUrl(audioUrl);
  try {
    const response = await fetch(resolvedUrl);
    const buffer = await response.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest("SHA-256", buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b)=>b.toString(16).padStart(2, "0")).join("");
  } catch (error) {
    console.error("Error fetching audio for hash:", error);
    throw new Error("Не удалось получить аудиофайл для хеширования");
  }
}
// OpenTimestamps — API ожидает 32 байта (binary), не hex-строку
async function submitToOpenTimestamps(hashHex) {
  const hashBytes = new Uint8Array(hashHex.match(/.{2}/g).map((b)=>parseInt(b, 16)));
  const calendars = [
    "https://a.pool.opentimestamps.org/digest",
    "https://b.pool.opentimestamps.org/digest",
    "https://finney.calendar.eternitywall.com/digest"
  ];
  for (const calendar of calendars){
    try {
      const resp = await fetch(calendar, {
        method: "POST",
        headers: {
          "Content-Type": "application/octet-stream",
          Accept: "application/vnd.opentimestamps.v1"
        },
        body: hashBytes
      });
      if (resp.ok) {
        return `ots_${Date.now()}`;
      }
    } catch (e) {
      console.log(`[OTS] ${calendar} failed:`, e);
    }
  }
  return `ots_pending_${hashHex.substring(0, 16)}`;
}
// n'RIS API интеграция
async function submitToNris(track, hash, apiKey, apiUrl) {
  if (!apiKey) {
    throw new Error("API ключ n'RIS не настроен");
  }
  try {
    const response = await fetch(`${apiUrl}/deposits`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        type: "audio",
        title: track.title,
        author: track.performer_name || track.profiles?.username,
        hash: hash,
        metadata: {
          duration: track.duration,
          genre: track.genre?.name_ru,
          created_at: track.created_at,
          lyrics_author: track.lyrics_author,
          music_author: track.music_author
        }
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`n'RIS API error: ${error}`);
    }
    const result = await response.json();
    return {
      depositId: result.deposit_id || result.id,
      certificateUrl: result.certificate_url
    };
  } catch (error) {
    console.error("n'RIS error:", error);
    throw error;
  }
}
// IRMA API интеграция
async function submitToIrma(track, hash, apiKey, apiUrl) {
  if (!apiKey) {
    throw new Error("API ключ IRMA не настроен");
  }
  try {
    const response = await fetch(`${apiUrl}/register`, {
      method: "POST",
      headers: {
        "X-API-Key": apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        work_type: "music",
        title: track.title,
        creators: [
          {
            role: "author",
            name: track.performer_name || track.profiles?.username
          },
          ...track.music_author ? [
            {
              role: "composer",
              name: track.music_author
            }
          ] : [],
          ...track.lyrics_author ? [
            {
              role: "lyricist",
              name: track.lyrics_author
            }
          ] : []
        ],
        file_hash: hash,
        additional_info: {
          duration_seconds: track.duration,
          genre: track.genre?.name_ru
        }
      })
    });
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`IRMA API error: ${error}`);
    }
    const result = await response.json();
    return {
      depositId: result.registration_id || result.id,
      certificateUrl: result.certificate_url
    };
  } catch (error) {
    console.error("IRMA error:", error);
    throw error;
  }
}
// Генерация PDF сертификата
async function generatePdfCertificate(supabase, track, hash, depositId, authorData) {
  const publicBase = Deno.env.get("BASE_URL") || "https://aimuza.ru";
  const verifyUrl = `${publicBase}/verify?hash=${encodeURIComponent(hash)}`;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(verifyUrl)}`;
  const certificateData = {
    title: "Авторское свидетельство",
    trackTitle: track.title || "Без названия",
    performer: authorData.performer_name || "Не указан",
    musicAuthor: authorData.music_author || "",
    lyricsAuthor: authorData.lyrics_author || "",
    fileHash: hash,
    depositId: depositId,
    depositDate: new Date().toISOString(),
    platform: "aimuza.ru",
    label: "Лейбл НОТА - ФЕЯ",
    labelFull: 'ООО "Музыкальный лейбл НОТА-ФЕЯ"',
    verifyUrl,
    qrCodeUrl
  };
  const formattedDate = new Date(certificateData.depositDate).toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
  // HTML сертификат с QR-кодом и стилями для печати
  const htmlContent = `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Сертификат депонирования - ${certificateData.trackTitle}</title>
  <style>
    @media print {
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .no-print { display: none !important; }
      @page { size: A4; margin: 15mm; }
    }
    
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body { 
      font-family: 'Times New Roman', 'Georgia', serif; 
      padding: 40px; 
      max-width: 800px; 
      margin: 0 auto; 
      background: #fff;
      color: #1a1a1a;
      line-height: 1.5;
    }
    
    .certificate {
      border: 3px double #2c3e50;
      padding: 40px;
      background: linear-gradient(135deg, #fefefe 0%, #f8f9fa 100%);
      position: relative;
    }
    
    .certificate::before {
      content: '';
      position: absolute;
      top: 10px;
      left: 10px;
      right: 10px;
      bottom: 10px;
      border: 1px solid #bdc3c7;
      pointer-events: none;
    }
    
    .header { 
      text-align: center; 
      border-bottom: 2px solid #2c3e50; 
      padding-bottom: 25px; 
      margin-bottom: 30px; 
    }
    
    .logo-section {
      margin-bottom: 15px;
    }
    
    .label-name {
      font-size: 14px;
      color: #555;
      font-weight: 500;
      letter-spacing: 1px;
      margin-bottom: 5px;
    }
    
    .website {
      font-size: 18px;
      color: #2c3e50;
      font-weight: bold;
      letter-spacing: 2px;
    }
    
    .title { 
      font-size: 32px; 
      font-weight: bold; 
      color: #1a1a1a; 
      text-transform: uppercase;
      letter-spacing: 3px;
      margin-top: 20px;
    }
    
    .subtitle { 
      font-size: 16px; 
      color: #666; 
      margin-top: 10px;
      font-style: italic;
    }
    
    .content {
      display: grid;
      gap: 18px;
    }
    
    .section { 
      display: grid;
      grid-template-columns: 180px 1fr;
      align-items: start;
      gap: 15px;
    }
    
    .label { 
      font-weight: bold; 
      color: #2c3e50;
      font-size: 14px;
      padding-top: 10px;
    }
    
    .value { 
      padding: 12px 15px; 
      background: #fff; 
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 15px;
      box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .hash { 
      font-family: 'Courier New', monospace; 
      font-size: 11px; 
      word-break: break-all;
      color: #555;
      letter-spacing: 0.5px;
    }
    
    .seal { 
      text-align: center; 
      margin: 35px 0 25px; 
    }
    
    .seal-container {
      display: inline-block;
      position: relative;
    }
    
    .seal-text { 
      display: inline-block; 
      padding: 20px 35px; 
      border: 4px double #2c3e50; 
      border-radius: 50%;
      font-size: 14px;
      font-weight: bold;
      color: #2c3e50;
      text-align: center;
      line-height: 1.4;
      background: linear-gradient(135deg, #fff 0%, #f0f0f0 100%);
    }
    
    .qr-section {
      text-align: center;
      margin: 25px 0 20px;
      padding: 15px;
      border: 1px dashed #bdc3c7;
      border-radius: 8px;
      background: #fafafa;
    }
    .qr-caption {
      font-size: 11px;
      color: #666;
      margin-bottom: 10px;
    }
    .qr-link { display: inline-block; }
    .qr-image { display: block; width: 120px; height: 120px; margin: 0 auto; }
    
    .footer { 
      margin-top: 30px; 
      padding-top: 20px; 
      border-top: 2px solid #2c3e50; 
      font-size: 12px; 
      color: #666; 
      text-align: center;
      line-height: 1.8;
    }
    
    .footer p {
      margin: 5px 0;
    }
    
    .footer .platform {
      font-weight: bold;
      color: #2c3e50;
      font-size: 14px;
      margin-top: 15px;
    }
    
    .print-btn {
      display: block;
      margin: 20px auto;
      padding: 12px 30px;
      background: #2c3e50;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      font-family: inherit;
    }
    
    .print-btn:hover {
      background: #1a252f;
    }
  </style>
</head>
<body>
  <button class="print-btn no-print" onclick="window.print()">📄 Сохранить как PDF / Распечатать</button>
  
    <div class="certificate">
    <div class="header">
      <div class="logo-section">
        <div class="label-name">${certificateData.label}</div>
        <div class="website">сайт ${certificateData.platform}</div>
      </div>
      <div class="title">АВТОРСКОЕ СВИДЕТЕЛЬСТВО</div>
      <div class="subtitle">Музыкальное произведение</div>
    </div>
    
    <div class="content">
      <div class="section">
        <div class="label">Название произведения:</div>
        <div class="value">${certificateData.trackTitle}</div>
      </div>
      
      <div class="section">
        <div class="label">Исполнитель:</div>
        <div class="value">${certificateData.performer}</div>
      </div>
      
      ${certificateData.musicAuthor ? `<div class="section">
        <div class="label">Автор музыки:</div>
        <div class="value">${certificateData.musicAuthor}</div>
      </div>` : ''}
      
      ${certificateData.lyricsAuthor ? `<div class="section">
        <div class="label">Автор текста:</div>
        <div class="value">${certificateData.lyricsAuthor}</div>
      </div>` : ''}
      
      <div class="section">
        <div class="label">Цифровой отпечаток (SHA-256):</div>
        <div class="value hash">${certificateData.fileHash}</div>
      </div>
      
      <div class="section">
        <div class="label">Идентификатор:</div>
        <div class="value">${certificateData.depositId}</div>
      </div>
      
      <div class="section">
        <div class="label">Дата регистрации:</div>
        <div class="value">${formattedDate}</div>
      </div>
    </div>
    
    <div class="seal">
      <div class="seal-container">
        <div class="seal-text">НОТА-ФЕЯ<br/>✓ Verified</div>
      </div>
    </div>
    
    <div class="qr-section">
      <p class="qr-caption">Проверка подлинности — отсканируйте QR-код</p>
      <a href="${certificateData.verifyUrl}" target="_blank" rel="noopener" class="qr-link">
        <img src="${certificateData.qrCodeUrl}" alt="QR-код для проверки" class="qr-image" />
      </a>
    </div>
    
    <div class="footer">
      <p>Данное свидетельство подтверждает факт существования произведения на указанную дату.</p>
      <p>Цифровой отпечаток позволяет однозначно идентифицировать оригинальный файл.</p>
      <p class="platform">${certificateData.labelFull} • сайт ${certificateData.platform}</p>
    </div>
  </div>
</body>
</html>`;
  // Сохраняем HTML как файл с правильной кодировкой для скачивания
  const fileName = `certificate_${depositId}.html`;
  const safeTitle = (track.title || "Без названия").replace(/[^a-zA-Zа-яА-ЯёЁ0-9\s]/g, '_').trim();
  const htmlBytes = new TextEncoder().encode(htmlContent);
  // Создаём Blob с правильным content-type
  const blob = new Blob([
    htmlBytes
  ], {
    type: "text/html;charset=utf-8"
  });
  const { error: uploadError } = await supabase.storage.from("certificates").upload(fileName, blob, {
    contentType: "text/html;charset=utf-8",
    cacheControl: "3600",
    upsert: true
  });
  if (uploadError) {
    console.error("Error uploading certificate:", uploadError);
    throw new Error("Не удалось сохранить сертификат");
  }
  // URL сертификата (публичный — для открытия в браузере; ?download= для скачивания)
  const publicPath = `/storage/v1/object/public/certificates/${fileName}`;
  const downloadName = `Авторское_свидетельство_${safeTitle}.html`;
  return `${publicBase}${publicPath}?download=${encodeURIComponent(downloadName)}`;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Получаем пользователя
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Не авторизован");
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    // Клиент с JWT пользователя — для RLS (auth.uid() = user_id при INSERT/DELETE)
    const userSupabase = createClient(supabaseUrl, supabaseServiceKey, {
      global: {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    });
    if (authError || !user) {
      throw new Error("Не авторизован");
    }
    const { trackId, method, authorData } = await req.json();
    console.log(`Deposit request: track=${trackId}, method=${method}, user=${user.id}`);
    // Получаем трек (audio_url, master_audio_url, normalized_audio_url — любой доступный URL)
    const { data: track, error: trackError } = await supabase.from("tracks").select(`
        id, title, audio_url, master_audio_url, normalized_audio_url, duration, created_at,
        performer_name, music_author, lyrics_author, user_id,
        genre:genres(name_ru)
      `).eq("id", trackId).eq("user_id", user.id).single();
    // Получаем username отдельно
    const { data: profile } = await supabase.from("profiles").select("username").eq("user_id", user.id).single();
    const username = profile?.username || "Unknown";
    // Используем данные автора из запроса или из трека
    const effectiveAuthorData = {
      performer_name: authorData?.performer_name || track?.performer_name || username,
      music_author: authorData?.music_author || track?.music_author || "",
      lyrics_author: authorData?.lyrics_author || track?.lyrics_author || ""
    };
    if (trackError || !track) {
      throw new Error("Трек не найден или не принадлежит вам");
    }
    // Fallback: файл может физически лежать в tracks/audio/{id}.mp3, но URL в БД пустой
    const baseUrl = supabaseUrl || "https://aimuza.ru";
    const audioUrl = track.audio_url || track.master_audio_url || track.normalized_audio_url || `${baseUrl}/storage/v1/object/public/tracks/audio/${trackId}.mp3`;
    // Проверяем существующее депонирование
    const { data: existingDeposit } = await supabase.from("track_deposits").select("id, status").eq("track_id", trackId).eq("method", method).single();
    if (existingDeposit) {
      if (existingDeposit.status === "completed") {
        throw new Error("Трек уже депонирован этим методом");
      }
      // Удаляем failed или processing записи (userSupabase для RLS)
      await userSupabase.from("track_deposits").delete().eq("id", existingDeposit.id);
    }
    // Получаем настройки
    const { data: settings } = await supabase.from("settings").select("key, value").in("key", [
      `deposit_price_${method}`,
      "nris_api_key",
      "nris_api_url",
      "irma_api_key",
      "irma_api_url"
    ]);
    const settingsMap = new Map(settings?.map((s)=>[
        s.key,
        s.value
      ]) || []);
    const priceKey = `deposit_price_${method}`;
    const priceValue = settingsMap.get(priceKey);
    const price = parseInt(priceValue || "0", 10);
    console.log(`Deposit pricing: key=${priceKey}, rawValue=${priceValue}, parsedPrice=${price}`);
    // Проверяем баланс если платно
    if (price > 0) {
      const { data: userProfile, error: profileError } = await supabase.from("profiles").select("balance").eq("user_id", user.id).single();
      console.log(`User balance check: balance=${userProfile?.balance}, price=${price}, error=${profileError?.message}`);
      if (!userProfile || userProfile.balance < price) {
        throw new Error(`Недостаточно средств. Требуется: ${price} ₽, баланс: ${userProfile?.balance || 0} ₽`);
      }
      // Списываем средства
      const newBalance = userProfile.balance - price;
      console.log(`Deducting balance: ${userProfile.balance} - ${price} = ${newBalance}`);
      const { error: updateError } = await supabase.from("profiles").update({
        balance: newBalance
      }).eq("user_id", user.id);
      if (updateError) {
        console.error("Balance update error:", updateError);
        throw new Error("Ошибка списания средств");
      }
      console.log(`Balance updated successfully for user ${user.id}`);
    } else {
      console.log(`Deposit is free for method ${method}`);
    }
    // Генерируем хеш аудио
    console.log("Generating audio hash...", {
      urlLen: audioUrl.length
    });
    const fileHash = await getAudioHash(audioUrl);
    // Генерируем хеш метаданных
    const metadataHash = await generateHash(JSON.stringify({
      title: track.title,
      performer: effectiveAuthorData.performer_name,
      musicAuthor: effectiveAuthorData.music_author,
      lyricsAuthor: effectiveAuthorData.lyrics_author,
      duration: track.duration,
      fileHash,
      timestamp: new Date().toISOString()
    }));
    // Создаём запись депонирования (userSupabase для RLS: auth.uid() = user_id)
    const depositId = crypto.randomUUID();
    const { error: insertError } = await userSupabase.from("track_deposits").upsert({
      id: depositId,
      track_id: trackId,
      user_id: user.id,
      method,
      status: "processing",
      file_hash: fileHash,
      metadata_hash: metadataHash,
      performer_name: effectiveAuthorData.performer_name,
      lyrics_author: effectiveAuthorData.lyrics_author
    });
    if (insertError) {
      console.error("Insert error:", insertError);
      const msg = insertError?.message || insertError?.details || "Не удалось создать запись депонирования";
      throw new Error(typeof msg === "string" ? msg : "Не удалось создать запись депонирования");
    }
    let result = {};
    try {
      switch(method){
        case "internal":
          // Внутренний реестр - просто сохраняем хеши
          result.certificateUrl = await generatePdfCertificate(supabase, track, fileHash, depositId, effectiveAuthorData);
          break;
        case "pdf":
          // Генерация PDF сертификата
          result.certificateUrl = await generatePdfCertificate(supabase, track, fileHash, depositId, effectiveAuthorData);
          break;
        case "blockchain":
          // OpenTimestamps
          result.blockchainTxId = await submitToOpenTimestamps(fileHash);
          result.certificateUrl = await generatePdfCertificate(supabase, track, fileHash, depositId, effectiveAuthorData);
          break;
        case "nris":
          const nrisResult = await submitToNris(track, fileHash, settingsMap.get("nris_api_key") || "", settingsMap.get("nris_api_url") || "https://api.nris.ru/v1");
          result.externalDepositId = nrisResult.depositId;
          result.externalCertificateUrl = nrisResult.certificateUrl;
          break;
        case "irma":
          const irmaResult = await submitToIrma(track, fileHash, settingsMap.get("irma_api_key") || "", settingsMap.get("irma_api_url") || "https://api.irma.ru/v1");
          result.externalDepositId = irmaResult.depositId;
          result.externalCertificateUrl = irmaResult.certificateUrl;
          break;
      }
      // Обновляем статус на completed (userSupabase для RLS)
      await userSupabase.from("track_deposits").update({
        status: "completed",
        completed_at: new Date().toISOString(),
        certificate_url: result.certificateUrl,
        blockchain_tx_id: result.blockchainTxId,
        external_deposit_id: result.externalDepositId,
        external_certificate_url: result.externalCertificateUrl
      }).eq("id", depositId);
      // Создаём уведомление (userSupabase для RLS)
      await userSupabase.from("notifications").insert({
        user_id: user.id,
        type: "system",
        title: "Депонирование завершено",
        message: `Трек "${track.title}" успешно депонирован`,
        target_type: "track",
        target_id: trackId
      });
      console.log(`Deposit completed: ${depositId}`);
      return new Response(JSON.stringify({
        success: true,
        depositId,
        ...result
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    } catch (processError) {
      const error = processError;
      console.error("Process error:", error);
      // Обновляем статус на failed (userSupabase для RLS)
      await userSupabase.from("track_deposits").update({
        status: "failed",
        error_message: error.message || "Unknown error"
      }).eq("id", depositId);
      // Возвращаем средства если были списаны
      if (price > 0) {
        const { data: currentProfile } = await supabase.from("profiles").select("balance").eq("user_id", user.id).single();
        if (currentProfile) {
          await supabase.from("profiles").update({
            balance: currentProfile.balance + price
          }).eq("user_id", user.id);
        }
      }
      throw error;
    }
  } catch (error) {
    console.error("Deposit error:", error);
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 400,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy90cmFjay1kZXBvc2l0L2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE5MC4wL2h0dHAvc2VydmVyLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuaW50ZXJmYWNlIEF1dGhvckRhdGEge1xuICBwZXJmb3JtZXJfbmFtZTogc3RyaW5nO1xuICBtdXNpY19hdXRob3I6IHN0cmluZztcbiAgbHlyaWNzX2F1dGhvcjogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgRGVwb3NpdFJlcXVlc3Qge1xuICB0cmFja0lkOiBzdHJpbmc7XG4gIG1ldGhvZDogXCJpbnRlcm5hbFwiIHwgXCJwZGZcIiB8IFwiYmxvY2tjaGFpblwiIHwgXCJucmlzXCIgfCBcImlybWFcIjtcbiAgYXV0aG9yRGF0YT86IEF1dGhvckRhdGE7XG59XG5cbmludGVyZmFjZSBEZXBvc2l0RXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIG1lc3NhZ2U6IHN0cmluZztcbn1cblxuLy8g0JPQtdC90LXRgNCw0YbQuNGPIFNIQS0yNTYg0YXQtdGI0LBcbmFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlSGFzaChkYXRhOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG4gIGNvbnN0IGRhdGFCdWZmZXIgPSBlbmNvZGVyLmVuY29kZShkYXRhKTtcbiAgY29uc3QgaGFzaEJ1ZmZlciA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KFwiU0hBLTI1NlwiLCBkYXRhQnVmZmVyKTtcbiAgY29uc3QgaGFzaEFycmF5ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShoYXNoQnVmZmVyKSk7XG4gIHJldHVybiBoYXNoQXJyYXkubWFwKGIgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgXCIwXCIpKS5qb2luKFwiXCIpO1xufVxuXG4vLyDQn9C10YDQtdC/0LjRgdGL0LLQsNC10Lwg0YHRgtCw0YDRi9C1IFN1cGFiYXNlIFVSTCDQvdCwINGC0LXQutGD0YnQuNC5IEFQSSAo0L/QvtGB0LvQtSDQvNC40LPRgNCw0YbQuNC4IHN0b3JhZ2Ug0L3QsCBhaW11emEucnUpXG5mdW5jdGlvbiByZXNvbHZlQXVkaW9VcmwodXJsOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSB8fCBcImh0dHBzOi8vYWltdXphLnJ1XCI7XG4gIGNvbnN0IG9sZFN1cGFiYXNlID0gL2h0dHBzOlxcL1xcL1thLXpdK1xcLnN1cGFiYXNlXFwuY28vO1xuICBpZiAob2xkU3VwYWJhc2UudGVzdCh1cmwpKSB7XG4gICAgY29uc3QgcGF0aCA9IG5ldyBVUkwodXJsKS5wYXRobmFtZTtcbiAgICByZXR1cm4gYCR7c3VwYWJhc2VVcmx9JHtwYXRofWA7XG4gIH1cbiAgcmV0dXJuIHVybDtcbn1cblxuLy8g0J/QvtC70YPRh9Cw0LXQvCDRhdC10Ygg0LDRg9C00LjQvtGE0LDQudC70LBcbmFzeW5jIGZ1bmN0aW9uIGdldEF1ZGlvSGFzaChhdWRpb1VybDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc3QgcmVzb2x2ZWRVcmwgPSByZXNvbHZlQXVkaW9VcmwoYXVkaW9VcmwpO1xuICB0cnkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2gocmVzb2x2ZWRVcmwpO1xuICAgIGNvbnN0IGJ1ZmZlciA9IGF3YWl0IHJlc3BvbnNlLmFycmF5QnVmZmVyKCk7XG4gICAgY29uc3QgaGFzaEJ1ZmZlciA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KFwiU0hBLTI1NlwiLCBidWZmZXIpO1xuICAgIGNvbnN0IGhhc2hBcnJheSA9IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoaGFzaEJ1ZmZlcikpO1xuICAgIHJldHVybiBoYXNoQXJyYXkubWFwKGIgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgXCIwXCIpKS5qb2luKFwiXCIpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhdWRpbyBmb3IgaGFzaDpcIiwgZXJyb3IpO1xuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/QvtC70YPRh9C40YLRjCDQsNGD0LTQuNC+0YTQsNC50Lsg0LTQu9GPINGF0LXRiNC40YDQvtCy0LDQvdC40Y9cIik7XG4gIH1cbn1cblxuLy8gT3BlblRpbWVzdGFtcHMg4oCUIEFQSSDQvtC20LjQtNCw0LXRgiAzMiDQsdCw0LnRgtCwIChiaW5hcnkpLCDQvdC1IGhleC3RgdGC0YDQvtC60YNcbmFzeW5jIGZ1bmN0aW9uIHN1Ym1pdFRvT3BlblRpbWVzdGFtcHMoaGFzaEhleDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc3QgaGFzaEJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoXG4gICAgaGFzaEhleC5tYXRjaCgvLnsyfS9nKSEubWFwKChiKSA9PiBwYXJzZUludChiLCAxNikpXG4gICk7XG4gIGNvbnN0IGNhbGVuZGFycyA9IFtcbiAgICBcImh0dHBzOi8vYS5wb29sLm9wZW50aW1lc3RhbXBzLm9yZy9kaWdlc3RcIixcbiAgICBcImh0dHBzOi8vYi5wb29sLm9wZW50aW1lc3RhbXBzLm9yZy9kaWdlc3RcIixcbiAgICBcImh0dHBzOi8vZmlubmV5LmNhbGVuZGFyLmV0ZXJuaXR5d2FsbC5jb20vZGlnZXN0XCIsXG4gIF07XG4gIGZvciAoY29uc3QgY2FsZW5kYXIgb2YgY2FsZW5kYXJzKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBmZXRjaChjYWxlbmRhciwge1xuICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW1cIixcbiAgICAgICAgICBBY2NlcHQ6IFwiYXBwbGljYXRpb24vdm5kLm9wZW50aW1lc3RhbXBzLnYxXCIsXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IGhhc2hCeXRlcyxcbiAgICAgIH0pO1xuICAgICAgaWYgKHJlc3Aub2spIHtcbiAgICAgICAgcmV0dXJuIGBvdHNfJHtEYXRlLm5vdygpfWA7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5sb2coYFtPVFNdICR7Y2FsZW5kYXJ9IGZhaWxlZDpgLCBlKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGBvdHNfcGVuZGluZ18ke2hhc2hIZXguc3Vic3RyaW5nKDAsIDE2KX1gO1xufVxuXG4vLyBuJ1JJUyBBUEkg0LjQvdGC0LXQs9GA0LDRhtC40Y9cbmFzeW5jIGZ1bmN0aW9uIHN1Ym1pdFRvTnJpcyhcbiAgdHJhY2s6IGFueSxcbiAgaGFzaDogc3RyaW5nLFxuICBhcGlLZXk6IHN0cmluZyxcbiAgYXBpVXJsOiBzdHJpbmdcbik6IFByb21pc2U8eyBkZXBvc2l0SWQ6IHN0cmluZzsgY2VydGlmaWNhdGVVcmw/OiBzdHJpbmcgfT4ge1xuICBpZiAoIWFwaUtleSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkFQSSDQutC70Y7RhyBuJ1JJUyDQvdC1INC90LDRgdGC0YDQvtC10L1cIik7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7YXBpVXJsfS9kZXBvc2l0c2AsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7YXBpS2V5fWAsXG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdHlwZTogXCJhdWRpb1wiLFxuICAgICAgICB0aXRsZTogdHJhY2sudGl0bGUsXG4gICAgICAgIGF1dGhvcjogdHJhY2sucGVyZm9ybWVyX25hbWUgfHwgdHJhY2sucHJvZmlsZXM/LnVzZXJuYW1lLFxuICAgICAgICBoYXNoOiBoYXNoLFxuICAgICAgICBtZXRhZGF0YToge1xuICAgICAgICAgIGR1cmF0aW9uOiB0cmFjay5kdXJhdGlvbixcbiAgICAgICAgICBnZW5yZTogdHJhY2suZ2VucmU/Lm5hbWVfcnUsXG4gICAgICAgICAgY3JlYXRlZF9hdDogdHJhY2suY3JlYXRlZF9hdCxcbiAgICAgICAgICBseXJpY3NfYXV0aG9yOiB0cmFjay5seXJpY3NfYXV0aG9yLFxuICAgICAgICAgIG11c2ljX2F1dGhvcjogdHJhY2subXVzaWNfYXV0aG9yLFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICBjb25zdCBlcnJvciA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgbidSSVMgQVBJIGVycm9yOiAke2Vycm9yfWApO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICByZXR1cm4ge1xuICAgICAgZGVwb3NpdElkOiByZXN1bHQuZGVwb3NpdF9pZCB8fCByZXN1bHQuaWQsXG4gICAgICBjZXJ0aWZpY2F0ZVVybDogcmVzdWx0LmNlcnRpZmljYXRlX3VybCxcbiAgICB9O1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJuJ1JJUyBlcnJvcjpcIiwgZXJyb3IpO1xuICAgIHRocm93IGVycm9yO1xuICB9XG59XG5cbi8vIElSTUEgQVBJINC40L3RgtC10LPRgNCw0YbQuNGPXG5hc3luYyBmdW5jdGlvbiBzdWJtaXRUb0lybWEoXG4gIHRyYWNrOiBhbnksXG4gIGhhc2g6IHN0cmluZyxcbiAgYXBpS2V5OiBzdHJpbmcsXG4gIGFwaVVybDogc3RyaW5nXG4pOiBQcm9taXNlPHsgZGVwb3NpdElkOiBzdHJpbmc7IGNlcnRpZmljYXRlVXJsPzogc3RyaW5nIH0+IHtcbiAgaWYgKCFhcGlLZXkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJBUEkg0LrQu9GO0YcgSVJNQSDQvdC1INC90LDRgdGC0YDQvtC10L1cIik7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7YXBpVXJsfS9yZWdpc3RlcmAsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiWC1BUEktS2V5XCI6IGFwaUtleSxcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB3b3JrX3R5cGU6IFwibXVzaWNcIixcbiAgICAgICAgdGl0bGU6IHRyYWNrLnRpdGxlLFxuICAgICAgICBjcmVhdG9yczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIHJvbGU6IFwiYXV0aG9yXCIsXG4gICAgICAgICAgICBuYW1lOiB0cmFjay5wZXJmb3JtZXJfbmFtZSB8fCB0cmFjay5wcm9maWxlcz8udXNlcm5hbWUsXG4gICAgICAgICAgfSxcbiAgICAgICAgICAuLi4odHJhY2subXVzaWNfYXV0aG9yID8gW3sgcm9sZTogXCJjb21wb3NlclwiLCBuYW1lOiB0cmFjay5tdXNpY19hdXRob3IgfV0gOiBbXSksXG4gICAgICAgICAgLi4uKHRyYWNrLmx5cmljc19hdXRob3IgPyBbeyByb2xlOiBcImx5cmljaXN0XCIsIG5hbWU6IHRyYWNrLmx5cmljc19hdXRob3IgfV0gOiBbXSksXG4gICAgICAgIF0sXG4gICAgICAgIGZpbGVfaGFzaDogaGFzaCxcbiAgICAgICAgYWRkaXRpb25hbF9pbmZvOiB7XG4gICAgICAgICAgZHVyYXRpb25fc2Vjb25kczogdHJhY2suZHVyYXRpb24sXG4gICAgICAgICAgZ2VucmU6IHRyYWNrLmdlbnJlPy5uYW1lX3J1LFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICBjb25zdCBlcnJvciA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgSVJNQSBBUEkgZXJyb3I6ICR7ZXJyb3J9YCk7XG4gICAgfVxuXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgIHJldHVybiB7XG4gICAgICBkZXBvc2l0SWQ6IHJlc3VsdC5yZWdpc3RyYXRpb25faWQgfHwgcmVzdWx0LmlkLFxuICAgICAgY2VydGlmaWNhdGVVcmw6IHJlc3VsdC5jZXJ0aWZpY2F0ZV91cmwsXG4gICAgfTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiSVJNQSBlcnJvcjpcIiwgZXJyb3IpO1xuICAgIHRocm93IGVycm9yO1xuICB9XG59XG5cbi8vINCT0LXQvdC10YDQsNGG0LjRjyBQREYg0YHQtdGA0YLQuNGE0LjQutCw0YLQsFxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVQZGZDZXJ0aWZpY2F0ZShcbiAgc3VwYWJhc2U6IGFueSxcbiAgdHJhY2s6IGFueSxcbiAgaGFzaDogc3RyaW5nLFxuICBkZXBvc2l0SWQ6IHN0cmluZyxcbiAgYXV0aG9yRGF0YTogeyBwZXJmb3JtZXJfbmFtZTogc3RyaW5nOyBtdXNpY19hdXRob3I6IHN0cmluZzsgbHlyaWNzX2F1dGhvcjogc3RyaW5nIH1cbik6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IHB1YmxpY0Jhc2UgPSBEZW5vLmVudi5nZXQoXCJCQVNFX1VSTFwiKSB8fCBcImh0dHBzOi8vYWltdXphLnJ1XCI7XG4gIGNvbnN0IHZlcmlmeVVybCA9IGAke3B1YmxpY0Jhc2V9L3ZlcmlmeT9oYXNoPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGhhc2gpfWA7XG4gIGNvbnN0IHFyQ29kZVVybCA9IGBodHRwczovL2FwaS5xcnNlcnZlci5jb20vdjEvY3JlYXRlLXFyLWNvZGUvP3NpemU9MTIweDEyMCZkYXRhPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHZlcmlmeVVybCl9YDtcblxuICBjb25zdCBjZXJ0aWZpY2F0ZURhdGEgPSB7XG4gICAgdGl0bGU6IFwi0JDQstGC0L7RgNGB0LrQvtC1INGB0LLQuNC00LXRgtC10LvRjNGB0YLQstC+XCIsXG4gICAgdHJhY2tUaXRsZTogdHJhY2sudGl0bGUgfHwgXCLQkdC10Lcg0L3QsNC30LLQsNC90LjRj1wiLFxuICAgIHBlcmZvcm1lcjogYXV0aG9yRGF0YS5wZXJmb3JtZXJfbmFtZSB8fCBcItCd0LUg0YPQutCw0LfQsNC9XCIsXG4gICAgbXVzaWNBdXRob3I6IGF1dGhvckRhdGEubXVzaWNfYXV0aG9yIHx8IFwiXCIsXG4gICAgbHlyaWNzQXV0aG9yOiBhdXRob3JEYXRhLmx5cmljc19hdXRob3IgfHwgXCJcIixcbiAgICBmaWxlSGFzaDogaGFzaCxcbiAgICBkZXBvc2l0SWQ6IGRlcG9zaXRJZCxcbiAgICBkZXBvc2l0RGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHBsYXRmb3JtOiBcImFpbXV6YS5ydVwiLFxuICAgIGxhYmVsOiBcItCb0LXQudCx0Lsg0J3QntCi0JAgLSDQpNCV0K9cIixcbiAgICBsYWJlbEZ1bGw6ICfQntCe0J4gXCLQnNGD0LfRi9C60LDQu9GM0L3Ri9C5INC70LXQudCx0Lsg0J3QntCi0JAt0KTQldCvXCInLFxuICAgIHZlcmlmeVVybCxcbiAgICBxckNvZGVVcmwsXG4gIH07XG5cbiAgY29uc3QgZm9ybWF0dGVkRGF0ZSA9IG5ldyBEYXRlKGNlcnRpZmljYXRlRGF0YS5kZXBvc2l0RGF0ZSkudG9Mb2NhbGVTdHJpbmcoJ3J1LVJVJywge1xuICAgIGRheTogJzItZGlnaXQnLFxuICAgIG1vbnRoOiAnMi1kaWdpdCcsIFxuICAgIHllYXI6ICdudW1lcmljJyxcbiAgICBob3VyOiAnMi1kaWdpdCcsXG4gICAgbWludXRlOiAnMi1kaWdpdCcsXG4gICAgc2Vjb25kOiAnMi1kaWdpdCdcbiAgfSk7XG5cbiAgLy8gSFRNTCDRgdC10YDRgtC40YTQuNC60LDRgiDRgSBRUi3QutC+0LTQvtC8INC4INGB0YLQuNC70Y/QvNC4INC00LvRjyDQv9C10YfQsNGC0LhcbiAgY29uc3QgaHRtbENvbnRlbnQgPSBgPCFET0NUWVBFIGh0bWw+XG48aHRtbCBsYW5nPVwicnVcIj5cbjxoZWFkPlxuICA8bWV0YSBjaGFyc2V0PVwiVVRGLThcIj5cbiAgPG1ldGEgbmFtZT1cInZpZXdwb3J0XCIgY29udGVudD1cIndpZHRoPWRldmljZS13aWR0aCwgaW5pdGlhbC1zY2FsZT0xLjBcIj5cbiAgPHRpdGxlPtCh0LXRgNGC0LjRhNC40LrQsNGCINC00LXQv9C+0L3QuNGA0L7QstCw0L3QuNGPIC0gJHtjZXJ0aWZpY2F0ZURhdGEudHJhY2tUaXRsZX08L3RpdGxlPlxuICA8c3R5bGU+XG4gICAgQG1lZGlhIHByaW50IHtcbiAgICAgIGJvZHkgeyAtd2Via2l0LXByaW50LWNvbG9yLWFkanVzdDogZXhhY3Q7IHByaW50LWNvbG9yLWFkanVzdDogZXhhY3Q7IH1cbiAgICAgIC5uby1wcmludCB7IGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDsgfVxuICAgICAgQHBhZ2UgeyBzaXplOiBBNDsgbWFyZ2luOiAxNW1tOyB9XG4gICAgfVxuICAgIFxuICAgICogeyBib3gtc2l6aW5nOiBib3JkZXItYm94OyBtYXJnaW46IDA7IHBhZGRpbmc6IDA7IH1cbiAgICBcbiAgICBib2R5IHsgXG4gICAgICBmb250LWZhbWlseTogJ1RpbWVzIE5ldyBSb21hbicsICdHZW9yZ2lhJywgc2VyaWY7IFxuICAgICAgcGFkZGluZzogNDBweDsgXG4gICAgICBtYXgtd2lkdGg6IDgwMHB4OyBcbiAgICAgIG1hcmdpbjogMCBhdXRvOyBcbiAgICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgICBjb2xvcjogIzFhMWExYTtcbiAgICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgfVxuICAgIFxuICAgIC5jZXJ0aWZpY2F0ZSB7XG4gICAgICBib3JkZXI6IDNweCBkb3VibGUgIzJjM2U1MDtcbiAgICAgIHBhZGRpbmc6IDQwcHg7XG4gICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjZmVmZWZlIDAlLCAjZjhmOWZhIDEwMCUpO1xuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIH1cbiAgICBcbiAgICAuY2VydGlmaWNhdGU6OmJlZm9yZSB7XG4gICAgICBjb250ZW50OiAnJztcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIHRvcDogMTBweDtcbiAgICAgIGxlZnQ6IDEwcHg7XG4gICAgICByaWdodDogMTBweDtcbiAgICAgIGJvdHRvbTogMTBweDtcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNiZGMzYzc7XG4gICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICB9XG4gICAgXG4gICAgLmhlYWRlciB7IFxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyOyBcbiAgICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjMmMzZTUwOyBcbiAgICAgIHBhZGRpbmctYm90dG9tOiAyNXB4OyBcbiAgICAgIG1hcmdpbi1ib3R0b206IDMwcHg7IFxuICAgIH1cbiAgICBcbiAgICAubG9nby1zZWN0aW9uIHtcbiAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XG4gICAgfVxuICAgIFxuICAgIC5sYWJlbC1uYW1lIHtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGNvbG9yOiAjNTU1O1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XG4gICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgfVxuICAgIFxuICAgIC53ZWJzaXRlIHtcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgIGNvbG9yOiAjMmMzZTUwO1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICBsZXR0ZXItc3BhY2luZzogMnB4O1xuICAgIH1cbiAgICBcbiAgICAudGl0bGUgeyBcbiAgICAgIGZvbnQtc2l6ZTogMzJweDsgXG4gICAgICBmb250LXdlaWdodDogYm9sZDsgXG4gICAgICBjb2xvcjogIzFhMWExYTsgXG4gICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDNweDtcbiAgICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgfVxuICAgIFxuICAgIC5zdWJ0aXRsZSB7IFxuICAgICAgZm9udC1zaXplOiAxNnB4OyBcbiAgICAgIGNvbG9yOiAjNjY2OyBcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgfVxuICAgIFxuICAgIC5jb250ZW50IHtcbiAgICAgIGRpc3BsYXk6IGdyaWQ7XG4gICAgICBnYXA6IDE4cHg7XG4gICAgfVxuICAgIFxuICAgIC5zZWN0aW9uIHsgXG4gICAgICBkaXNwbGF5OiBncmlkO1xuICAgICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxODBweCAxZnI7XG4gICAgICBhbGlnbi1pdGVtczogc3RhcnQ7XG4gICAgICBnYXA6IDE1cHg7XG4gICAgfVxuICAgIFxuICAgIC5sYWJlbCB7IFxuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7IFxuICAgICAgY29sb3I6ICMyYzNlNTA7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBwYWRkaW5nLXRvcDogMTBweDtcbiAgICB9XG4gICAgXG4gICAgLnZhbHVlIHsgXG4gICAgICBwYWRkaW5nOiAxMnB4IDE1cHg7IFxuICAgICAgYmFja2dyb3VuZDogI2ZmZjsgXG4gICAgICBib3JkZXI6IDFweCBzb2xpZCAjZGRkO1xuICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgYm94LXNoYWRvdzogaW5zZXQgMCAxcHggM3B4IHJnYmEoMCwwLDAsMC4wNSk7XG4gICAgfVxuICAgIFxuICAgIC5oYXNoIHsgXG4gICAgICBmb250LWZhbWlseTogJ0NvdXJpZXIgTmV3JywgbW9ub3NwYWNlOyBcbiAgICAgIGZvbnQtc2l6ZTogMTFweDsgXG4gICAgICB3b3JkLWJyZWFrOiBicmVhay1hbGw7XG4gICAgICBjb2xvcjogIzU1NTtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAwLjVweDtcbiAgICB9XG4gICAgXG4gICAgLnNlYWwgeyBcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjsgXG4gICAgICBtYXJnaW46IDM1cHggMCAyNXB4OyBcbiAgICB9XG4gICAgXG4gICAgLnNlYWwtY29udGFpbmVyIHtcbiAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB9XG4gICAgXG4gICAgLnNlYWwtdGV4dCB7IFxuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrOyBcbiAgICAgIHBhZGRpbmc6IDIwcHggMzVweDsgXG4gICAgICBib3JkZXI6IDRweCBkb3VibGUgIzJjM2U1MDsgXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgIGNvbG9yOiAjMmMzZTUwO1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgbGluZS1oZWlnaHQ6IDEuNDtcbiAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICNmZmYgMCUsICNmMGYwZjAgMTAwJSk7XG4gICAgfVxuICAgIFxuICAgIC5xci1zZWN0aW9uIHtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgIG1hcmdpbjogMjVweCAwIDIwcHg7XG4gICAgICBwYWRkaW5nOiAxNXB4O1xuICAgICAgYm9yZGVyOiAxcHggZGFzaGVkICNiZGMzYzc7XG4gICAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgICBiYWNrZ3JvdW5kOiAjZmFmYWZhO1xuICAgIH1cbiAgICAucXItY2FwdGlvbiB7XG4gICAgICBmb250LXNpemU6IDExcHg7XG4gICAgICBjb2xvcjogIzY2NjtcbiAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgfVxuICAgIC5xci1saW5rIHsgZGlzcGxheTogaW5saW5lLWJsb2NrOyB9XG4gICAgLnFyLWltYWdlIHsgZGlzcGxheTogYmxvY2s7IHdpZHRoOiAxMjBweDsgaGVpZ2h0OiAxMjBweDsgbWFyZ2luOiAwIGF1dG87IH1cbiAgICBcbiAgICAuZm9vdGVyIHsgXG4gICAgICBtYXJnaW4tdG9wOiAzMHB4OyBcbiAgICAgIHBhZGRpbmctdG9wOiAyMHB4OyBcbiAgICAgIGJvcmRlci10b3A6IDJweCBzb2xpZCAjMmMzZTUwOyBcbiAgICAgIGZvbnQtc2l6ZTogMTJweDsgXG4gICAgICBjb2xvcjogIzY2NjsgXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICBsaW5lLWhlaWdodDogMS44O1xuICAgIH1cbiAgICBcbiAgICAuZm9vdGVyIHAge1xuICAgICAgbWFyZ2luOiA1cHggMDtcbiAgICB9XG4gICAgXG4gICAgLmZvb3RlciAucGxhdGZvcm0ge1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICBjb2xvcjogIzJjM2U1MDtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIG1hcmdpbi10b3A6IDE1cHg7XG4gICAgfVxuICAgIFxuICAgIC5wcmludC1idG4ge1xuICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICBtYXJnaW46IDIwcHggYXV0bztcbiAgICAgIHBhZGRpbmc6IDEycHggMzBweDtcbiAgICAgIGJhY2tncm91bmQ6ICMyYzNlNTA7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIGJvcmRlcjogbm9uZTtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgIGZvbnQtZmFtaWx5OiBpbmhlcml0O1xuICAgIH1cbiAgICBcbiAgICAucHJpbnQtYnRuOmhvdmVyIHtcbiAgICAgIGJhY2tncm91bmQ6ICMxYTI1MmY7XG4gICAgfVxuICA8L3N0eWxlPlxuPC9oZWFkPlxuPGJvZHk+XG4gIDxidXR0b24gY2xhc3M9XCJwcmludC1idG4gbm8tcHJpbnRcIiBvbmNsaWNrPVwid2luZG93LnByaW50KClcIj7wn5OEINCh0L7RhdGA0LDQvdC40YLRjCDQutCw0LogUERGIC8g0KDQsNGB0L/QtdGH0LDRgtCw0YLRjDwvYnV0dG9uPlxuICBcbiAgICA8ZGl2IGNsYXNzPVwiY2VydGlmaWNhdGVcIj5cbiAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibG9nby1zZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbC1uYW1lXCI+JHtjZXJ0aWZpY2F0ZURhdGEubGFiZWx9PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ3ZWJzaXRlXCI+0YHQsNC50YIgJHtjZXJ0aWZpY2F0ZURhdGEucGxhdGZvcm19PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJ0aXRsZVwiPtCQ0JLQotCe0KDQodCa0J7QlSDQodCS0JjQlNCV0KLQldCb0KzQodCi0JLQnjwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInN1YnRpdGxlXCI+0JzRg9C30YvQutCw0LvRjNC90L7QtSDQv9GA0L7QuNC30LLQtdC00LXQvdC40LU8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICBcbiAgICA8ZGl2IGNsYXNzPVwiY29udGVudFwiPlxuICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+0J3QsNC30LLQsNC90LjQtSDQv9GA0L7QuNC30LLQtdC00LXQvdC40Y86PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ2YWx1ZVwiPiR7Y2VydGlmaWNhdGVEYXRhLnRyYWNrVGl0bGV9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIFxuICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+0JjRgdC/0L7Qu9C90LjRgtC10LvRjDo8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInZhbHVlXCI+JHtjZXJ0aWZpY2F0ZURhdGEucGVyZm9ybWVyfTwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICBcbiAgICAgICR7Y2VydGlmaWNhdGVEYXRhLm11c2ljQXV0aG9yID8gYDxkaXYgY2xhc3M9XCJzZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbFwiPtCQ0LLRgtC+0YAg0LzRg9C30YvQutC4OjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwidmFsdWVcIj4ke2NlcnRpZmljYXRlRGF0YS5tdXNpY0F1dGhvcn08L2Rpdj5cbiAgICAgIDwvZGl2PmAgOiAnJ31cbiAgICAgIFxuICAgICAgJHtjZXJ0aWZpY2F0ZURhdGEubHlyaWNzQXV0aG9yID8gYDxkaXYgY2xhc3M9XCJzZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbFwiPtCQ0LLRgtC+0YAg0YLQtdC60YHRgtCwOjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwidmFsdWVcIj4ke2NlcnRpZmljYXRlRGF0YS5seXJpY3NBdXRob3J9PC9kaXY+XG4gICAgICA8L2Rpdj5gIDogJyd9XG4gICAgICBcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbFwiPtCm0LjRhNGA0L7QstC+0Lkg0L7RgtC/0LXRh9Cw0YLQvtC6IChTSEEtMjU2KTo8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInZhbHVlIGhhc2hcIj4ke2NlcnRpZmljYXRlRGF0YS5maWxlSGFzaH08L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgXG4gICAgICA8ZGl2IGNsYXNzPVwic2VjdGlvblwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwibGFiZWxcIj7QmNC00LXQvdGC0LjRhNC40LrQsNGC0L7RgDo8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInZhbHVlXCI+JHtjZXJ0aWZpY2F0ZURhdGEuZGVwb3NpdElkfTwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICBcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbFwiPtCU0LDRgtCwINGA0LXQs9C40YHRgtGA0LDRhtC40Lg6PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ2YWx1ZVwiPiR7Zm9ybWF0dGVkRGF0ZX08L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIFxuICAgIDxkaXYgY2xhc3M9XCJzZWFsXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwic2VhbC1jb250YWluZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInNlYWwtdGV4dFwiPtCd0J7QotCQLdCk0JXQrzxici8+4pyTIFZlcmlmaWVkPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICBcbiAgICA8ZGl2IGNsYXNzPVwicXItc2VjdGlvblwiPlxuICAgICAgPHAgY2xhc3M9XCJxci1jYXB0aW9uXCI+0J/RgNC+0LLQtdGA0LrQsCDQv9C+0LTQu9C40L3QvdC+0YHRgtC4IOKAlCDQvtGC0YHQutCw0L3QuNGA0YPQudGC0LUgUVIt0LrQvtC0PC9wPlxuICAgICAgPGEgaHJlZj1cIiR7Y2VydGlmaWNhdGVEYXRhLnZlcmlmeVVybH1cIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lclwiIGNsYXNzPVwicXItbGlua1wiPlxuICAgICAgICA8aW1nIHNyYz1cIiR7Y2VydGlmaWNhdGVEYXRhLnFyQ29kZVVybH1cIiBhbHQ9XCJRUi3QutC+0LQg0LTQu9GPINC/0YDQvtCy0LXRgNC60LhcIiBjbGFzcz1cInFyLWltYWdlXCIgLz5cbiAgICAgIDwvYT5cbiAgICA8L2Rpdj5cbiAgICBcbiAgICA8ZGl2IGNsYXNzPVwiZm9vdGVyXCI+XG4gICAgICA8cD7QlNCw0L3QvdC+0LUg0YHQstC40LTQtdGC0LXQu9GM0YHRgtCy0L4g0L/QvtC00YLQstC10YDQttC00LDQtdGCINGE0LDQutGCINGB0YPRidC10YHRgtCy0L7QstCw0L3QuNGPINC/0YDQvtC40LfQstC10LTQtdC90LjRjyDQvdCwINGD0LrQsNC30LDQvdC90YPRjiDQtNCw0YLRgy48L3A+XG4gICAgICA8cD7QptC40YTRgNC+0LLQvtC5INC+0YLQv9C10YfQsNGC0L7QuiDQv9C+0LfQstC+0LvRj9C10YIg0L7QtNC90L7Qt9C90LDRh9C90L4g0LjQtNC10L3RgtC40YTQuNGG0LjRgNC+0LLQsNGC0Ywg0L7RgNC40LPQuNC90LDQu9GM0L3Ri9C5INGE0LDQudC7LjwvcD5cbiAgICAgIDxwIGNsYXNzPVwicGxhdGZvcm1cIj4ke2NlcnRpZmljYXRlRGF0YS5sYWJlbEZ1bGx9IOKAoiDRgdCw0LnRgiAke2NlcnRpZmljYXRlRGF0YS5wbGF0Zm9ybX08L3A+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuPC9ib2R5PlxuPC9odG1sPmA7XG5cbiAgLy8g0KHQvtGF0YDQsNC90Y/QtdC8IEhUTUwg0LrQsNC6INGE0LDQudC7INGBINC/0YDQsNCy0LjQu9GM0L3QvtC5INC60L7QtNC40YDQvtCy0LrQvtC5INC00LvRjyDRgdC60LDRh9C40LLQsNC90LjRj1xuICBjb25zdCBmaWxlTmFtZSA9IGBjZXJ0aWZpY2F0ZV8ke2RlcG9zaXRJZH0uaHRtbGA7XG4gIGNvbnN0IHNhZmVUaXRsZSA9ICh0cmFjay50aXRsZSB8fCBcItCR0LXQtyDQvdCw0LfQstCw0L3QuNGPXCIpLnJlcGxhY2UoL1teYS16QS1a0LAt0Y/QkC3Qr9GR0IEwLTlcXHNdL2csICdfJykudHJpbSgpO1xuICBjb25zdCBodG1sQnl0ZXMgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoaHRtbENvbnRlbnQpO1xuICBcbiAgLy8g0KHQvtC30LTQsNGR0LwgQmxvYiDRgSDQv9GA0LDQstC40LvRjNC90YvQvCBjb250ZW50LXR5cGVcbiAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtodG1sQnl0ZXNdLCB7IHR5cGU6IFwidGV4dC9odG1sO2NoYXJzZXQ9dXRmLThcIiB9KTtcbiAgXG4gIGNvbnN0IHsgZXJyb3I6IHVwbG9hZEVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5zdG9yYWdlXG4gICAgLmZyb20oXCJjZXJ0aWZpY2F0ZXNcIilcbiAgICAudXBsb2FkKGZpbGVOYW1lLCBibG9iLCB7XG4gICAgICBjb250ZW50VHlwZTogXCJ0ZXh0L2h0bWw7Y2hhcnNldD11dGYtOFwiLFxuICAgICAgY2FjaGVDb250cm9sOiBcIjM2MDBcIixcbiAgICAgIHVwc2VydDogdHJ1ZSxcbiAgICB9KTtcblxuICBpZiAodXBsb2FkRXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBsb2FkaW5nIGNlcnRpZmljYXRlOlwiLCB1cGxvYWRFcnJvcik7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDRgdC+0YXRgNCw0L3QuNGC0Ywg0YHQtdGA0YLQuNGE0LjQutCw0YJcIik7XG4gIH1cblxuICAvLyBVUkwg0YHQtdGA0YLQuNGE0LjQutCw0YLQsCAo0L/Rg9Cx0LvQuNGH0L3Ri9C5IOKAlCDQtNC70Y8g0L7RgtC60YDRi9GC0LjRjyDQsiDQsdGA0LDRg9C30LXRgNC1OyA/ZG93bmxvYWQ9INC00LvRjyDRgdC60LDRh9C40LLQsNC90LjRjylcbiAgY29uc3QgcHVibGljUGF0aCA9IGAvc3RvcmFnZS92MS9vYmplY3QvcHVibGljL2NlcnRpZmljYXRlcy8ke2ZpbGVOYW1lfWA7XG4gIGNvbnN0IGRvd25sb2FkTmFtZSA9IGDQkNCy0YLQvtGA0YHQutC+0LVf0YHQstC40LTQtdGC0LXQu9GM0YHRgtCy0L5fJHtzYWZlVGl0bGV9Lmh0bWxgO1xuICByZXR1cm4gYCR7cHVibGljQmFzZX0ke3B1YmxpY1BhdGh9P2Rvd25sb2FkPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGRvd25sb2FkTmFtZSl9YDtcbn1cblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHN1cGFiYXNlVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfVVJMXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZVNlcnZpY2VLZXkgPSBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9TRVJWSUNFX1JPTEVfS0VZXCIpITtcbiAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUNsaWVudChzdXBhYmFzZVVybCwgc3VwYWJhc2VTZXJ2aWNlS2V5KTtcblxuICAgIC8vINCf0L7Qu9GD0YfQsNC10Lwg0L/QvtC70YzQt9C+0LLQsNGC0LXQu9GPXG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcIkF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INCw0LLRgtC+0YDQuNC30L7QstCw0L1cIik7XG4gICAgfVxuXG4gICAgY29uc3QgdG9rZW4gPSBhdXRoSGVhZGVyLnJlcGxhY2UoXCJCZWFyZXIgXCIsIFwiXCIpO1xuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0sIGVycm9yOiBhdXRoRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcih0b2tlbik7XG5cbiAgICAvLyDQmtC70LjQtdC90YIg0YEgSldUINC/0L7Qu9GM0LfQvtCy0LDRgtC10LvRjyDigJQg0LTQu9GPIFJMUyAoYXV0aC51aWQoKSA9IHVzZXJfaWQg0L/RgNC4IElOU0VSVC9ERUxFVEUpXG4gICAgY29uc3QgdXNlclN1cGFiYXNlID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzdXBhYmFzZVNlcnZpY2VLZXksIHtcbiAgICAgIGdsb2JhbDogeyBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0b2tlbn1gIH0gfSxcbiAgICB9KTtcbiAgICBcbiAgICBpZiAoYXV0aEVycm9yIHx8ICF1c2VyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INCw0LLRgtC+0YDQuNC30L7QstCw0L1cIik7XG4gICAgfVxuXG4gICAgY29uc3QgeyB0cmFja0lkLCBtZXRob2QsIGF1dGhvckRhdGEgfTogRGVwb3NpdFJlcXVlc3QgPSBhd2FpdCByZXEuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKGBEZXBvc2l0IHJlcXVlc3Q6IHRyYWNrPSR7dHJhY2tJZH0sIG1ldGhvZD0ke21ldGhvZH0sIHVzZXI9JHt1c2VyLmlkfWApO1xuXG4gICAgLy8g0J/QvtC70YPRh9Cw0LXQvCDRgtGA0LXQuiAoYXVkaW9fdXJsLCBtYXN0ZXJfYXVkaW9fdXJsLCBub3JtYWxpemVkX2F1ZGlvX3VybCDigJQg0LvRjtCx0L7QuSDQtNC+0YHRgtGD0L/QvdGL0LkgVVJMKVxuICAgIGNvbnN0IHsgZGF0YTogdHJhY2ssIGVycm9yOiB0cmFja0Vycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgIC5zZWxlY3QoYFxuICAgICAgICBpZCwgdGl0bGUsIGF1ZGlvX3VybCwgbWFzdGVyX2F1ZGlvX3VybCwgbm9ybWFsaXplZF9hdWRpb191cmwsIGR1cmF0aW9uLCBjcmVhdGVkX2F0LFxuICAgICAgICBwZXJmb3JtZXJfbmFtZSwgbXVzaWNfYXV0aG9yLCBseXJpY3NfYXV0aG9yLCB1c2VyX2lkLFxuICAgICAgICBnZW5yZTpnZW5yZXMobmFtZV9ydSlcbiAgICAgIGApXG4gICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgLy8g0J/QvtC70YPRh9Cw0LXQvCB1c2VybmFtZSDQvtGC0LTQtdC70YzQvdC+XG4gICAgY29uc3QgeyBkYXRhOiBwcm9maWxlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgLnNlbGVjdChcInVzZXJuYW1lXCIpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBjb25zdCB1c2VybmFtZSA9IHByb2ZpbGU/LnVzZXJuYW1lIHx8IFwiVW5rbm93blwiO1xuXG4gICAgLy8g0JjRgdC/0L7Qu9GM0LfRg9C10Lwg0LTQsNC90L3Ri9C1INCw0LLRgtC+0YDQsCDQuNC3INC30LDQv9GA0L7RgdCwINC40LvQuCDQuNC3INGC0YDQtdC60LBcbiAgICBjb25zdCBlZmZlY3RpdmVBdXRob3JEYXRhID0ge1xuICAgICAgcGVyZm9ybWVyX25hbWU6IGF1dGhvckRhdGE/LnBlcmZvcm1lcl9uYW1lIHx8IHRyYWNrPy5wZXJmb3JtZXJfbmFtZSB8fCB1c2VybmFtZSxcbiAgICAgIG11c2ljX2F1dGhvcjogYXV0aG9yRGF0YT8ubXVzaWNfYXV0aG9yIHx8IHRyYWNrPy5tdXNpY19hdXRob3IgfHwgXCJcIixcbiAgICAgIGx5cmljc19hdXRob3I6IGF1dGhvckRhdGE/Lmx5cmljc19hdXRob3IgfHwgdHJhY2s/Lmx5cmljc19hdXRob3IgfHwgXCJcIixcbiAgICB9O1xuXG4gICAgaWYgKHRyYWNrRXJyb3IgfHwgIXRyYWNrKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCLQotGA0LXQuiDQvdC1INC90LDQudC00LXQvSDQuNC70Lgg0L3QtSDQv9GA0LjQvdCw0LTQu9C10LbQuNGCINCy0LDQvFwiKTtcbiAgICB9XG5cbiAgICAvLyBGYWxsYmFjazog0YTQsNC50Lsg0LzQvtC20LXRgiDRhNC40LfQuNGH0LXRgdC60Lgg0LvQtdC20LDRgtGMINCyIHRyYWNrcy9hdWRpby97aWR9Lm1wMywg0L3QviBVUkwg0LIg0JHQlCDQv9GD0YHRgtC+0LlcbiAgICBjb25zdCBiYXNlVXJsID0gc3VwYWJhc2VVcmwgfHwgXCJodHRwczovL2FpbXV6YS5ydVwiO1xuICAgIGNvbnN0IGF1ZGlvVXJsID0gdHJhY2suYXVkaW9fdXJsIHx8IHRyYWNrLm1hc3Rlcl9hdWRpb191cmwgfHwgdHJhY2subm9ybWFsaXplZF9hdWRpb191cmxcbiAgICAgIHx8IGAke2Jhc2VVcmx9L3N0b3JhZ2UvdjEvb2JqZWN0L3B1YmxpYy90cmFja3MvYXVkaW8vJHt0cmFja0lkfS5tcDNgO1xuXG4gICAgLy8g0J/RgNC+0LLQtdGA0Y/QtdC8INGB0YPRidC10YHRgtCy0YPRjtGJ0LXQtSDQtNC10L/QvtC90LjRgNC+0LLQsNC90LjQtVxuICAgIGNvbnN0IHsgZGF0YTogZXhpc3RpbmdEZXBvc2l0IH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJ0cmFja19kZXBvc2l0c1wiKVxuICAgICAgLnNlbGVjdChcImlkLCBzdGF0dXNcIilcbiAgICAgIC5lcShcInRyYWNrX2lkXCIsIHRyYWNrSWQpXG4gICAgICAuZXEoXCJtZXRob2RcIiwgbWV0aG9kKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKGV4aXN0aW5nRGVwb3NpdCkge1xuICAgICAgaWYgKGV4aXN0aW5nRGVwb3NpdC5zdGF0dXMgPT09IFwiY29tcGxldGVkXCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwi0KLRgNC10Log0YPQttC1INC00LXQv9C+0L3QuNGA0L7QstCw0L0g0Y3RgtC40Lwg0LzQtdGC0L7QtNC+0LxcIik7XG4gICAgICB9XG4gICAgICAvLyDQo9C00LDQu9GP0LXQvCBmYWlsZWQg0LjQu9C4IHByb2Nlc3Npbmcg0LfQsNC/0LjRgdC4ICh1c2VyU3VwYWJhc2Ug0LTQu9GPIFJMUylcbiAgICAgIGF3YWl0IHVzZXJTdXBhYmFzZVxuICAgICAgICAuZnJvbShcInRyYWNrX2RlcG9zaXRzXCIpXG4gICAgICAgIC5kZWxldGUoKVxuICAgICAgICAuZXEoXCJpZFwiLCBleGlzdGluZ0RlcG9zaXQuaWQpO1xuICAgIH1cblxuICAgIC8vINCf0L7Qu9GD0YfQsNC10Lwg0L3QsNGB0YLRgNC+0LnQutC4XG4gICAgY29uc3QgeyBkYXRhOiBzZXR0aW5ncyB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwic2V0dGluZ3NcIilcbiAgICAgIC5zZWxlY3QoXCJrZXksIHZhbHVlXCIpXG4gICAgICAuaW4oXCJrZXlcIiwgW1xuICAgICAgICBgZGVwb3NpdF9wcmljZV8ke21ldGhvZH1gLFxuICAgICAgICBcIm5yaXNfYXBpX2tleVwiLFxuICAgICAgICBcIm5yaXNfYXBpX3VybFwiLFxuICAgICAgICBcImlybWFfYXBpX2tleVwiLCBcbiAgICAgICAgXCJpcm1hX2FwaV91cmxcIixcbiAgICAgIF0pO1xuXG4gICAgY29uc3Qgc2V0dGluZ3NNYXAgPSBuZXcgTWFwKHNldHRpbmdzPy5tYXAocyA9PiBbcy5rZXksIHMudmFsdWVdKSB8fCBbXSk7XG4gICAgY29uc3QgcHJpY2VLZXkgPSBgZGVwb3NpdF9wcmljZV8ke21ldGhvZH1gO1xuICAgIGNvbnN0IHByaWNlVmFsdWUgPSBzZXR0aW5nc01hcC5nZXQocHJpY2VLZXkpO1xuICAgIGNvbnN0IHByaWNlID0gcGFyc2VJbnQocHJpY2VWYWx1ZSB8fCBcIjBcIiwgMTApO1xuICAgIFxuICAgIGNvbnNvbGUubG9nKGBEZXBvc2l0IHByaWNpbmc6IGtleT0ke3ByaWNlS2V5fSwgcmF3VmFsdWU9JHtwcmljZVZhbHVlfSwgcGFyc2VkUHJpY2U9JHtwcmljZX1gKTtcblxuICAgIC8vINCf0YDQvtCy0LXRgNGP0LXQvCDQsdCw0LvQsNC90YEg0LXRgdC70Lgg0L/Qu9Cw0YLQvdC+XG4gICAgaWYgKHByaWNlID4gMCkge1xuICAgICAgY29uc3QgeyBkYXRhOiB1c2VyUHJvZmlsZSwgZXJyb3I6IHByb2ZpbGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAuc2VsZWN0KFwiYmFsYW5jZVwiKVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpXG4gICAgICAgIC5zaW5nbGUoKTtcblxuICAgICAgY29uc29sZS5sb2coYFVzZXIgYmFsYW5jZSBjaGVjazogYmFsYW5jZT0ke3VzZXJQcm9maWxlPy5iYWxhbmNlfSwgcHJpY2U9JHtwcmljZX0sIGVycm9yPSR7cHJvZmlsZUVycm9yPy5tZXNzYWdlfWApO1xuXG4gICAgICBpZiAoIXVzZXJQcm9maWxlIHx8IHVzZXJQcm9maWxlLmJhbGFuY2UgPCBwcmljZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYNCd0LXQtNC+0YHRgtCw0YLQvtGH0L3QviDRgdGA0LXQtNGB0YLQsi4g0KLRgNC10LHRg9C10YLRgdGPOiAke3ByaWNlfSDigr0sINCx0LDQu9Cw0L3RgTogJHt1c2VyUHJvZmlsZT8uYmFsYW5jZSB8fCAwfSDigr1gKTtcbiAgICAgIH1cblxuICAgICAgLy8g0KHQv9C40YHRi9Cy0LDQtdC8INGB0YDQtdC00YHRgtCy0LBcbiAgICAgIGNvbnN0IG5ld0JhbGFuY2UgPSB1c2VyUHJvZmlsZS5iYWxhbmNlIC0gcHJpY2U7XG4gICAgICBjb25zb2xlLmxvZyhgRGVkdWN0aW5nIGJhbGFuY2U6ICR7dXNlclByb2ZpbGUuYmFsYW5jZX0gLSAke3ByaWNlfSA9ICR7bmV3QmFsYW5jZX1gKTtcbiAgICAgIFxuICAgICAgY29uc3QgeyBlcnJvcjogdXBkYXRlRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IG5ld0JhbGFuY2UgfSlcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcbiAgICAgIFxuICAgICAgaWYgKHVwZGF0ZUVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJCYWxhbmNlIHVwZGF0ZSBlcnJvcjpcIiwgdXBkYXRlRXJyb3IpO1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCLQntGI0LjQsdC60LAg0YHQv9C40YHQsNC90LjRjyDRgdGA0LXQtNGB0YLQslwiKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgY29uc29sZS5sb2coYEJhbGFuY2UgdXBkYXRlZCBzdWNjZXNzZnVsbHkgZm9yIHVzZXIgJHt1c2VyLmlkfWApO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLmxvZyhgRGVwb3NpdCBpcyBmcmVlIGZvciBtZXRob2QgJHttZXRob2R9YCk7XG4gICAgfVxuXG4gICAgLy8g0JPQtdC90LXRgNC40YDRg9C10Lwg0YXQtdGIINCw0YPQtNC40L5cbiAgICBjb25zb2xlLmxvZyhcIkdlbmVyYXRpbmcgYXVkaW8gaGFzaC4uLlwiLCB7IHVybExlbjogYXVkaW9VcmwubGVuZ3RoIH0pO1xuICAgIGNvbnN0IGZpbGVIYXNoID0gYXdhaXQgZ2V0QXVkaW9IYXNoKGF1ZGlvVXJsKTtcbiAgICBcbiAgICAvLyDQk9C10L3QtdGA0LjRgNGD0LXQvCDRhdC10Ygg0LzQtdGC0LDQtNCw0L3QvdGL0YVcbiAgICBjb25zdCBtZXRhZGF0YUhhc2ggPSBhd2FpdCBnZW5lcmF0ZUhhc2goSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgdGl0bGU6IHRyYWNrLnRpdGxlLFxuICAgICAgcGVyZm9ybWVyOiBlZmZlY3RpdmVBdXRob3JEYXRhLnBlcmZvcm1lcl9uYW1lLFxuICAgICAgbXVzaWNBdXRob3I6IGVmZmVjdGl2ZUF1dGhvckRhdGEubXVzaWNfYXV0aG9yLFxuICAgICAgbHlyaWNzQXV0aG9yOiBlZmZlY3RpdmVBdXRob3JEYXRhLmx5cmljc19hdXRob3IsXG4gICAgICBkdXJhdGlvbjogdHJhY2suZHVyYXRpb24sXG4gICAgICBmaWxlSGFzaCxcbiAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0pKTtcblxuICAgIC8vINCh0L7Qt9C00LDRkdC8INC30LDQv9C40YHRjCDQtNC10L/QvtC90LjRgNC+0LLQsNC90LjRjyAodXNlclN1cGFiYXNlINC00LvRjyBSTFM6IGF1dGgudWlkKCkgPSB1c2VyX2lkKVxuICAgIGNvbnN0IGRlcG9zaXRJZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XG4gICAgY29uc3QgeyBlcnJvcjogaW5zZXJ0RXJyb3IgfSA9IGF3YWl0IHVzZXJTdXBhYmFzZVxuICAgICAgLmZyb20oXCJ0cmFja19kZXBvc2l0c1wiKVxuICAgICAgLnVwc2VydCh7XG4gICAgICAgIGlkOiBkZXBvc2l0SWQsXG4gICAgICAgIHRyYWNrX2lkOiB0cmFja0lkLFxuICAgICAgICB1c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgICBtZXRob2QsXG4gICAgICAgIHN0YXR1czogXCJwcm9jZXNzaW5nXCIsXG4gICAgICAgIGZpbGVfaGFzaDogZmlsZUhhc2gsXG4gICAgICAgIG1ldGFkYXRhX2hhc2g6IG1ldGFkYXRhSGFzaCxcbiAgICAgICAgcGVyZm9ybWVyX25hbWU6IGVmZmVjdGl2ZUF1dGhvckRhdGEucGVyZm9ybWVyX25hbWUsXG4gICAgICAgIGx5cmljc19hdXRob3I6IGVmZmVjdGl2ZUF1dGhvckRhdGEubHlyaWNzX2F1dGhvcixcbiAgICAgIH0pO1xuXG4gICAgaWYgKGluc2VydEVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiSW5zZXJ0IGVycm9yOlwiLCBpbnNlcnRFcnJvcik7XG4gICAgICBjb25zdCBtc2cgPSBpbnNlcnRFcnJvcj8ubWVzc2FnZSB8fCBpbnNlcnRFcnJvcj8uZGV0YWlscyB8fCBcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0YHQvtC30LTQsNGC0Ywg0LfQsNC/0LjRgdGMINC00LXQv9C+0L3QuNGA0L7QstCw0L3QuNGPXCI7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IodHlwZW9mIG1zZyA9PT0gXCJzdHJpbmdcIiA/IG1zZyA6IFwi0J3QtSDRg9C00LDQu9C+0YHRjCDRgdC+0LfQtNCw0YLRjCDQt9Cw0L/QuNGB0Ywg0LTQtdC/0L7QvdC40YDQvtCy0LDQvdC40Y9cIik7XG4gICAgfVxuXG4gICAgbGV0IHJlc3VsdDoge1xuICAgICAgY2VydGlmaWNhdGVVcmw/OiBzdHJpbmc7XG4gICAgICBibG9ja2NoYWluVHhJZD86IHN0cmluZztcbiAgICAgIGV4dGVybmFsRGVwb3NpdElkPzogc3RyaW5nO1xuICAgICAgZXh0ZXJuYWxDZXJ0aWZpY2F0ZVVybD86IHN0cmluZztcbiAgICB9ID0ge307XG5cbiAgICB0cnkge1xuICAgICAgc3dpdGNoIChtZXRob2QpIHtcbiAgICAgICAgY2FzZSBcImludGVybmFsXCI6XG4gICAgICAgICAgLy8g0JLQvdGD0YLRgNC10L3QvdC40Lkg0YDQtdC10YHRgtGAIC0g0L/RgNC+0YHRgtC+INGB0L7RhdGA0LDQvdGP0LXQvCDRhdC10YjQuFxuICAgICAgICAgIHJlc3VsdC5jZXJ0aWZpY2F0ZVVybCA9IGF3YWl0IGdlbmVyYXRlUGRmQ2VydGlmaWNhdGUoXG4gICAgICAgICAgICBzdXBhYmFzZSwgdHJhY2ssIGZpbGVIYXNoLCBkZXBvc2l0SWQsIGVmZmVjdGl2ZUF1dGhvckRhdGFcbiAgICAgICAgICApO1xuICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgXCJwZGZcIjpcbiAgICAgICAgICAvLyDQk9C10L3QtdGA0LDRhtC40Y8gUERGINGB0LXRgNGC0LjRhNC40LrQsNGC0LBcbiAgICAgICAgICByZXN1bHQuY2VydGlmaWNhdGVVcmwgPSBhd2FpdCBnZW5lcmF0ZVBkZkNlcnRpZmljYXRlKFxuICAgICAgICAgICAgc3VwYWJhc2UsIHRyYWNrLCBmaWxlSGFzaCwgZGVwb3NpdElkLCBlZmZlY3RpdmVBdXRob3JEYXRhXG4gICAgICAgICAgKTtcbiAgICAgICAgICBicmVhaztcblxuICAgICAgICBjYXNlIFwiYmxvY2tjaGFpblwiOlxuICAgICAgICAgIC8vIE9wZW5UaW1lc3RhbXBzXG4gICAgICAgICAgcmVzdWx0LmJsb2NrY2hhaW5UeElkID0gYXdhaXQgc3VibWl0VG9PcGVuVGltZXN0YW1wcyhmaWxlSGFzaCk7XG4gICAgICAgICAgcmVzdWx0LmNlcnRpZmljYXRlVXJsID0gYXdhaXQgZ2VuZXJhdGVQZGZDZXJ0aWZpY2F0ZShcbiAgICAgICAgICAgIHN1cGFiYXNlLCB0cmFjaywgZmlsZUhhc2gsIGRlcG9zaXRJZCwgZWZmZWN0aXZlQXV0aG9yRGF0YVxuICAgICAgICAgICk7XG4gICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgY2FzZSBcIm5yaXNcIjpcbiAgICAgICAgICBjb25zdCBucmlzUmVzdWx0ID0gYXdhaXQgc3VibWl0VG9OcmlzKFxuICAgICAgICAgICAgdHJhY2ssXG4gICAgICAgICAgICBmaWxlSGFzaCxcbiAgICAgICAgICAgIHNldHRpbmdzTWFwLmdldChcIm5yaXNfYXBpX2tleVwiKSB8fCBcIlwiLFxuICAgICAgICAgICAgc2V0dGluZ3NNYXAuZ2V0KFwibnJpc19hcGlfdXJsXCIpIHx8IFwiaHR0cHM6Ly9hcGkubnJpcy5ydS92MVwiXG4gICAgICAgICAgKTtcbiAgICAgICAgICByZXN1bHQuZXh0ZXJuYWxEZXBvc2l0SWQgPSBucmlzUmVzdWx0LmRlcG9zaXRJZDtcbiAgICAgICAgICByZXN1bHQuZXh0ZXJuYWxDZXJ0aWZpY2F0ZVVybCA9IG5yaXNSZXN1bHQuY2VydGlmaWNhdGVVcmw7XG4gICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgY2FzZSBcImlybWFcIjpcbiAgICAgICAgICBjb25zdCBpcm1hUmVzdWx0ID0gYXdhaXQgc3VibWl0VG9Jcm1hKFxuICAgICAgICAgICAgdHJhY2ssXG4gICAgICAgICAgICBmaWxlSGFzaCxcbiAgICAgICAgICAgIHNldHRpbmdzTWFwLmdldChcImlybWFfYXBpX2tleVwiKSB8fCBcIlwiLFxuICAgICAgICAgICAgc2V0dGluZ3NNYXAuZ2V0KFwiaXJtYV9hcGlfdXJsXCIpIHx8IFwiaHR0cHM6Ly9hcGkuaXJtYS5ydS92MVwiXG4gICAgICAgICAgKTtcbiAgICAgICAgICByZXN1bHQuZXh0ZXJuYWxEZXBvc2l0SWQgPSBpcm1hUmVzdWx0LmRlcG9zaXRJZDtcbiAgICAgICAgICByZXN1bHQuZXh0ZXJuYWxDZXJ0aWZpY2F0ZVVybCA9IGlybWFSZXN1bHQuY2VydGlmaWNhdGVVcmw7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICB9XG5cbiAgICAgIC8vINCe0LHQvdC+0LLQu9GP0LXQvCDRgdGC0LDRgtGD0YEg0L3QsCBjb21wbGV0ZWQgKHVzZXJTdXBhYmFzZSDQtNC70Y8gUkxTKVxuICAgICAgYXdhaXQgdXNlclN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tfZGVwb3NpdHNcIilcbiAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxuICAgICAgICAgIGNvbXBsZXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIGNlcnRpZmljYXRlX3VybDogcmVzdWx0LmNlcnRpZmljYXRlVXJsLFxuICAgICAgICAgIGJsb2NrY2hhaW5fdHhfaWQ6IHJlc3VsdC5ibG9ja2NoYWluVHhJZCxcbiAgICAgICAgICBleHRlcm5hbF9kZXBvc2l0X2lkOiByZXN1bHQuZXh0ZXJuYWxEZXBvc2l0SWQsXG4gICAgICAgICAgZXh0ZXJuYWxfY2VydGlmaWNhdGVfdXJsOiByZXN1bHQuZXh0ZXJuYWxDZXJ0aWZpY2F0ZVVybCxcbiAgICAgICAgfSlcbiAgICAgICAgLmVxKFwiaWRcIiwgZGVwb3NpdElkKTtcblxuICAgICAgLy8g0KHQvtC30LTQsNGR0Lwg0YPQstC10LTQvtC80LvQtdC90LjQtSAodXNlclN1cGFiYXNlINC00LvRjyBSTFMpXG4gICAgICBhd2FpdCB1c2VyU3VwYWJhc2UuZnJvbShcIm5vdGlmaWNhdGlvbnNcIikuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogdXNlci5pZCxcbiAgICAgICAgdHlwZTogXCJzeXN0ZW1cIixcbiAgICAgICAgdGl0bGU6IFwi0JTQtdC/0L7QvdC40YDQvtCy0LDQvdC40LUg0LfQsNCy0LXRgNGI0LXQvdC+XCIsXG4gICAgICAgIG1lc3NhZ2U6IGDQotGA0LXQuiBcIiR7dHJhY2sudGl0bGV9XCIg0YPRgdC/0LXRiNC90L4g0LTQtdC/0L7QvdC40YDQvtCy0LDQvWAsXG4gICAgICAgIHRhcmdldF90eXBlOiBcInRyYWNrXCIsXG4gICAgICAgIHRhcmdldF9pZDogdHJhY2tJZCxcbiAgICAgIH0pO1xuXG4gICAgICBjb25zb2xlLmxvZyhgRGVwb3NpdCBjb21wbGV0ZWQ6ICR7ZGVwb3NpdElkfWApO1xuXG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICBkZXBvc2l0SWQsXG4gICAgICAgICAgLi4ucmVzdWx0LFxuICAgICAgICB9KSxcbiAgICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG5cbiAgICB9IGNhdGNoIChwcm9jZXNzRXJyb3I6IHVua25vd24pIHtcbiAgICAgIGNvbnN0IGVycm9yID0gcHJvY2Vzc0Vycm9yIGFzIERlcG9zaXRFcnJvcjtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJQcm9jZXNzIGVycm9yOlwiLCBlcnJvcik7XG4gICAgICBcbiAgICAgIC8vINCe0LHQvdC+0LLQu9GP0LXQvCDRgdGC0LDRgtGD0YEg0L3QsCBmYWlsZWQgKHVzZXJTdXBhYmFzZSDQtNC70Y8gUkxTKVxuICAgICAgYXdhaXQgdXNlclN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidHJhY2tfZGVwb3NpdHNcIilcbiAgICAgICAgLnVwZGF0ZSh7XG4gICAgICAgICAgc3RhdHVzOiBcImZhaWxlZFwiLFxuICAgICAgICAgIGVycm9yX21lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfHwgXCJVbmtub3duIGVycm9yXCIsXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIGRlcG9zaXRJZCk7XG5cbiAgICAgIC8vINCS0L7Qt9Cy0YDQsNGJ0LDQtdC8INGB0YDQtdC00YHRgtCy0LAg0LXRgdC70Lgg0LHRi9C70Lgg0YHQv9C40YHQsNC90YtcbiAgICAgIGlmIChwcmljZSA+IDApIHtcbiAgICAgICAgY29uc3QgeyBkYXRhOiBjdXJyZW50UHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAgICAgLnNlbGVjdChcImJhbGFuY2VcIilcbiAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpXG4gICAgICAgICAgLnNpbmdsZSgpO1xuICAgICAgICBcbiAgICAgICAgaWYgKGN1cnJlbnRQcm9maWxlKSB7XG4gICAgICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAgIC51cGRhdGUoeyBiYWxhbmNlOiBjdXJyZW50UHJvZmlsZS5iYWxhbmNlICsgcHJpY2UgfSlcbiAgICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZCk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuXG4gIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRGVwb3NpdCBlcnJvcjpcIiwgZXJyb3IpO1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBlcnJvci5tZXNzYWdlIH0pLFxuICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxLQUFLLFFBQVEsK0NBQStDO0FBQ3JFLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQWtCQSx5QkFBeUI7QUFDekIsZUFBZSxhQUFhLElBQVk7RUFDdEMsTUFBTSxVQUFVLElBQUk7RUFDcEIsTUFBTSxhQUFhLFFBQVEsTUFBTSxDQUFDO0VBQ2xDLE1BQU0sYUFBYSxNQUFNLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXO0VBQ3pELE1BQU0sWUFBWSxNQUFNLElBQUksQ0FBQyxJQUFJLFdBQVc7RUFDNUMsT0FBTyxVQUFVLEdBQUcsQ0FBQyxDQUFBLElBQUssRUFBRSxRQUFRLENBQUMsSUFBSSxRQUFRLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUNsRTtBQUVBLHdGQUF3RjtBQUN4RixTQUFTLGdCQUFnQixHQUFXO0VBQ2xDLE1BQU0sY0FBYyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CO0VBQ3BELE1BQU0sY0FBYztFQUNwQixJQUFJLFlBQVksSUFBSSxDQUFDLE1BQU07SUFDekIsTUFBTSxPQUFPLElBQUksSUFBSSxLQUFLLFFBQVE7SUFDbEMsT0FBTyxDQUFDLEVBQUUsWUFBWSxFQUFFLEtBQUssQ0FBQztFQUNoQztFQUNBLE9BQU87QUFDVDtBQUVBLDBCQUEwQjtBQUMxQixlQUFlLGFBQWEsUUFBZ0I7RUFDMUMsTUFBTSxjQUFjLGdCQUFnQjtFQUNwQyxJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTTtJQUM3QixNQUFNLFNBQVMsTUFBTSxTQUFTLFdBQVc7SUFDekMsTUFBTSxhQUFhLE1BQU0sT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVc7SUFDekQsTUFBTSxZQUFZLE1BQU0sSUFBSSxDQUFDLElBQUksV0FBVztJQUM1QyxPQUFPLFVBQVUsR0FBRyxDQUFDLENBQUEsSUFBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0VBQ2xFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsa0NBQWtDO0lBQ2hELE1BQU0sSUFBSSxNQUFNO0VBQ2xCO0FBQ0Y7QUFFQSxnRUFBZ0U7QUFDaEUsZUFBZSx1QkFBdUIsT0FBZTtFQUNuRCxNQUFNLFlBQVksSUFBSSxXQUNwQixRQUFRLEtBQUssQ0FBQyxTQUFVLEdBQUcsQ0FBQyxDQUFDLElBQU0sU0FBUyxHQUFHO0VBRWpELE1BQU0sWUFBWTtJQUNoQjtJQUNBO0lBQ0E7R0FDRDtFQUNELEtBQUssTUFBTSxZQUFZLFVBQVc7SUFDaEMsSUFBSTtNQUNGLE1BQU0sT0FBTyxNQUFNLE1BQU0sVUFBVTtRQUNqQyxRQUFRO1FBQ1IsU0FBUztVQUNQLGdCQUFnQjtVQUNoQixRQUFRO1FBQ1Y7UUFDQSxNQUFNO01BQ1I7TUFDQSxJQUFJLEtBQUssRUFBRSxFQUFFO1FBQ1gsT0FBTyxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUcsR0FBRyxDQUFDO01BQzVCO0lBQ0YsRUFBRSxPQUFPLEdBQUc7TUFDVixRQUFRLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxTQUFTLFFBQVEsQ0FBQyxFQUFFO0lBQzNDO0VBQ0Y7RUFDQSxPQUFPLENBQUMsWUFBWSxFQUFFLFFBQVEsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDO0FBQ2xEO0FBRUEsdUJBQXVCO0FBQ3ZCLGVBQWUsYUFDYixLQUFVLEVBQ1YsSUFBWSxFQUNaLE1BQWMsRUFDZCxNQUFjO0VBRWQsSUFBSSxDQUFDLFFBQVE7SUFDWCxNQUFNLElBQUksTUFBTTtFQUNsQjtFQUVBLElBQUk7SUFDRixNQUFNLFdBQVcsTUFBTSxNQUFNLENBQUMsRUFBRSxPQUFPLFNBQVMsQ0FBQyxFQUFFO01BQ2pELFFBQVE7TUFDUixTQUFTO1FBQ1AsaUJBQWlCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQztRQUNuQyxnQkFBZ0I7TUFDbEI7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQ25CLE1BQU07UUFDTixPQUFPLE1BQU0sS0FBSztRQUNsQixRQUFRLE1BQU0sY0FBYyxJQUFJLE1BQU0sUUFBUSxFQUFFO1FBQ2hELE1BQU07UUFDTixVQUFVO1VBQ1IsVUFBVSxNQUFNLFFBQVE7VUFDeEIsT0FBTyxNQUFNLEtBQUssRUFBRTtVQUNwQixZQUFZLE1BQU0sVUFBVTtVQUM1QixlQUFlLE1BQU0sYUFBYTtVQUNsQyxjQUFjLE1BQU0sWUFBWTtRQUNsQztNQUNGO0lBQ0Y7SUFFQSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7TUFDaEIsTUFBTSxRQUFRLE1BQU0sU0FBUyxJQUFJO01BQ2pDLE1BQU0sSUFBSSxNQUFNLENBQUMsaUJBQWlCLEVBQUUsTUFBTSxDQUFDO0lBQzdDO0lBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0lBQ2xDLE9BQU87TUFDTCxXQUFXLE9BQU8sVUFBVSxJQUFJLE9BQU8sRUFBRTtNQUN6QyxnQkFBZ0IsT0FBTyxlQUFlO0lBQ3hDO0VBQ0YsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyxnQkFBZ0I7SUFDOUIsTUFBTTtFQUNSO0FBQ0Y7QUFFQSxzQkFBc0I7QUFDdEIsZUFBZSxhQUNiLEtBQVUsRUFDVixJQUFZLEVBQ1osTUFBYyxFQUNkLE1BQWM7RUFFZCxJQUFJLENBQUMsUUFBUTtJQUNYLE1BQU0sSUFBSSxNQUFNO0VBQ2xCO0VBRUEsSUFBSTtJQUNGLE1BQU0sV0FBVyxNQUFNLE1BQU0sQ0FBQyxFQUFFLE9BQU8sU0FBUyxDQUFDLEVBQUU7TUFDakQsUUFBUTtNQUNSLFNBQVM7UUFDUCxhQUFhO1FBQ2IsZ0JBQWdCO01BQ2xCO01BQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztRQUNuQixXQUFXO1FBQ1gsT0FBTyxNQUFNLEtBQUs7UUFDbEIsVUFBVTtVQUNSO1lBQ0UsTUFBTTtZQUNOLE1BQU0sTUFBTSxjQUFjLElBQUksTUFBTSxRQUFRLEVBQUU7VUFDaEQ7YUFDSSxNQUFNLFlBQVksR0FBRztZQUFDO2NBQUUsTUFBTTtjQUFZLE1BQU0sTUFBTSxZQUFZO1lBQUM7V0FBRSxHQUFHLEVBQUU7YUFDMUUsTUFBTSxhQUFhLEdBQUc7WUFBQztjQUFFLE1BQU07Y0FBWSxNQUFNLE1BQU0sYUFBYTtZQUFDO1dBQUUsR0FBRyxFQUFFO1NBQ2pGO1FBQ0QsV0FBVztRQUNYLGlCQUFpQjtVQUNmLGtCQUFrQixNQUFNLFFBQVE7VUFDaEMsT0FBTyxNQUFNLEtBQUssRUFBRTtRQUN0QjtNQUNGO0lBQ0Y7SUFFQSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7TUFDaEIsTUFBTSxRQUFRLE1BQU0sU0FBUyxJQUFJO01BQ2pDLE1BQU0sSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDO0lBQzVDO0lBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0lBQ2xDLE9BQU87TUFDTCxXQUFXLE9BQU8sZUFBZSxJQUFJLE9BQU8sRUFBRTtNQUM5QyxnQkFBZ0IsT0FBTyxlQUFlO0lBQ3hDO0VBQ0YsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyxlQUFlO0lBQzdCLE1BQU07RUFDUjtBQUNGO0FBRUEsNEJBQTRCO0FBQzVCLGVBQWUsdUJBQ2IsUUFBYSxFQUNiLEtBQVUsRUFDVixJQUFZLEVBQ1osU0FBaUIsRUFDakIsVUFBbUY7RUFFbkYsTUFBTSxhQUFhLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxlQUFlO0VBQy9DLE1BQU0sWUFBWSxDQUFDLEVBQUUsV0FBVyxhQUFhLEVBQUUsbUJBQW1CLE1BQU0sQ0FBQztFQUN6RSxNQUFNLFlBQVksQ0FBQyw4REFBOEQsRUFBRSxtQkFBbUIsV0FBVyxDQUFDO0VBRWxILE1BQU0sa0JBQWtCO0lBQ3RCLE9BQU87SUFDUCxZQUFZLE1BQU0sS0FBSyxJQUFJO0lBQzNCLFdBQVcsV0FBVyxjQUFjLElBQUk7SUFDeEMsYUFBYSxXQUFXLFlBQVksSUFBSTtJQUN4QyxjQUFjLFdBQVcsYUFBYSxJQUFJO0lBQzFDLFVBQVU7SUFDVixXQUFXO0lBQ1gsYUFBYSxJQUFJLE9BQU8sV0FBVztJQUNuQyxVQUFVO0lBQ1YsT0FBTztJQUNQLFdBQVc7SUFDWDtJQUNBO0VBQ0Y7RUFFQSxNQUFNLGdCQUFnQixJQUFJLEtBQUssZ0JBQWdCLFdBQVcsRUFBRSxjQUFjLENBQUMsU0FBUztJQUNsRixLQUFLO0lBQ0wsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNO0lBQ04sUUFBUTtJQUNSLFFBQVE7RUFDVjtFQUVBLGtEQUFrRDtFQUNsRCxNQUFNLGNBQWMsQ0FBQzs7Ozs7b0NBS2EsRUFBRSxnQkFBZ0IsVUFBVSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnQ0F3TWpDLEVBQUUsZ0JBQWdCLEtBQUssQ0FBQztrQ0FDdEIsRUFBRSxnQkFBZ0IsUUFBUSxDQUFDOzs7Ozs7Ozs7MkJBU2xDLEVBQUUsZ0JBQWdCLFVBQVUsQ0FBQzs7Ozs7MkJBSzdCLEVBQUUsZ0JBQWdCLFNBQVMsQ0FBQzs7O01BR2pELEVBQUUsZ0JBQWdCLFdBQVcsR0FBRyxDQUFDOzsyQkFFWixFQUFFLGdCQUFnQixXQUFXLENBQUM7WUFDN0MsQ0FBQyxHQUFHLEdBQUc7O01BRWIsRUFBRSxnQkFBZ0IsWUFBWSxHQUFHLENBQUM7OzJCQUViLEVBQUUsZ0JBQWdCLFlBQVksQ0FBQztZQUM5QyxDQUFDLEdBQUcsR0FBRzs7OztnQ0FJYSxFQUFFLGdCQUFnQixRQUFRLENBQUM7Ozs7OzJCQUtoQyxFQUFFLGdCQUFnQixTQUFTLENBQUM7Ozs7OzJCQUs1QixFQUFFLGNBQWM7Ozs7Ozs7Ozs7OztlQVk1QixFQUFFLGdCQUFnQixTQUFTLENBQUM7a0JBQ3pCLEVBQUUsZ0JBQWdCLFNBQVMsQ0FBQzs7Ozs7OzswQkFPcEIsRUFBRSxnQkFBZ0IsU0FBUyxDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsUUFBUSxDQUFDOzs7O09BSWxGLENBQUM7RUFFTixpRUFBaUU7RUFDakUsTUFBTSxXQUFXLENBQUMsWUFBWSxFQUFFLFVBQVUsS0FBSyxDQUFDO0VBQ2hELE1BQU0sWUFBWSxDQUFDLE1BQU0sS0FBSyxJQUFJLGNBQWMsRUFBRSxPQUFPLENBQUMsMkJBQTJCLEtBQUssSUFBSTtFQUM5RixNQUFNLFlBQVksSUFBSSxjQUFjLE1BQU0sQ0FBQztFQUUzQyx5Q0FBeUM7RUFDekMsTUFBTSxPQUFPLElBQUksS0FBSztJQUFDO0dBQVUsRUFBRTtJQUFFLE1BQU07RUFBMEI7RUFFckUsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUFTLE9BQU8sQ0FDbEQsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyxVQUFVLE1BQU07SUFDdEIsYUFBYTtJQUNiLGNBQWM7SUFDZCxRQUFRO0VBQ1Y7RUFFRixJQUFJLGFBQWE7SUFDZixRQUFRLEtBQUssQ0FBQyxnQ0FBZ0M7SUFDOUMsTUFBTSxJQUFJLE1BQU07RUFDbEI7RUFFQSxtRkFBbUY7RUFDbkYsTUFBTSxhQUFhLENBQUMsdUNBQXVDLEVBQUUsU0FBUyxDQUFDO0VBQ3ZFLE1BQU0sZUFBZSxDQUFDLHdCQUF3QixFQUFFLFVBQVUsS0FBSyxDQUFDO0VBQ2hFLE9BQU8sQ0FBQyxFQUFFLFdBQVcsRUFBRSxXQUFXLFVBQVUsRUFBRSxtQkFBbUIsY0FBYyxDQUFDO0FBQ2xGO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLHFCQUFxQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDeEMsTUFBTSxXQUFXLGFBQWEsYUFBYTtJQUUzQyx3QkFBd0I7SUFDeEIsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsTUFBTSxRQUFRLFdBQVcsT0FBTyxDQUFDLFdBQVc7SUFDNUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBRXpFLCtFQUErRTtJQUMvRSxNQUFNLGVBQWUsYUFBYSxhQUFhLG9CQUFvQjtNQUNqRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWUsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDO1FBQUM7TUFBRTtJQUMxRDtJQUVBLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsTUFBTSxJQUFJLE1BQU07SUFDbEI7SUFFQSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsR0FBbUIsTUFBTSxJQUFJLElBQUk7SUFDdEUsUUFBUSxHQUFHLENBQUMsQ0FBQyx1QkFBdUIsRUFBRSxRQUFRLFNBQVMsRUFBRSxPQUFPLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0lBRWxGLDBGQUEwRjtJQUMxRixNQUFNLEVBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxVQUFVLEVBQUUsR0FBRyxNQUFNLFNBQzlDLElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQyxDQUFDOzs7O01BSVQsQ0FBQyxFQUNBLEVBQUUsQ0FBQyxNQUFNLFNBQ1QsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFLEVBQ3JCLE1BQU07SUFFVCw2QkFBNkI7SUFDN0IsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxTQUM3QixJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsWUFDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtJQUVULE1BQU0sV0FBVyxTQUFTLFlBQVk7SUFFdEMsbURBQW1EO0lBQ25ELE1BQU0sc0JBQXNCO01BQzFCLGdCQUFnQixZQUFZLGtCQUFrQixPQUFPLGtCQUFrQjtNQUN2RSxjQUFjLFlBQVksZ0JBQWdCLE9BQU8sZ0JBQWdCO01BQ2pFLGVBQWUsWUFBWSxpQkFBaUIsT0FBTyxpQkFBaUI7SUFDdEU7SUFFQSxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQ3hCLE1BQU0sSUFBSSxNQUFNO0lBQ2xCO0lBRUEsb0ZBQW9GO0lBQ3BGLE1BQU0sVUFBVSxlQUFlO0lBQy9CLE1BQU0sV0FBVyxNQUFNLFNBQVMsSUFBSSxNQUFNLGdCQUFnQixJQUFJLE1BQU0sb0JBQW9CLElBQ25GLENBQUMsRUFBRSxRQUFRLHVDQUF1QyxFQUFFLFFBQVEsSUFBSSxDQUFDO0lBRXRFLHVDQUF1QztJQUN2QyxNQUFNLEVBQUUsTUFBTSxlQUFlLEVBQUUsR0FBRyxNQUFNLFNBQ3JDLElBQUksQ0FBQyxrQkFDTCxNQUFNLENBQUMsY0FDUCxFQUFFLENBQUMsWUFBWSxTQUNmLEVBQUUsQ0FBQyxVQUFVLFFBQ2IsTUFBTTtJQUVULElBQUksaUJBQWlCO01BQ25CLElBQUksZ0JBQWdCLE1BQU0sS0FBSyxhQUFhO1FBQzFDLE1BQU0sSUFBSSxNQUFNO01BQ2xCO01BQ0EsOERBQThEO01BQzlELE1BQU0sYUFDSCxJQUFJLENBQUMsa0JBQ0wsTUFBTSxHQUNOLEVBQUUsQ0FBQyxNQUFNLGdCQUFnQixFQUFFO0lBQ2hDO0lBRUEscUJBQXFCO0lBQ3JCLE1BQU0sRUFBRSxNQUFNLFFBQVEsRUFBRSxHQUFHLE1BQU0sU0FDOUIsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDLGNBQ1AsRUFBRSxDQUFDLE9BQU87TUFDVCxDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUM7TUFDekI7TUFDQTtNQUNBO01BQ0E7S0FDRDtJQUVILE1BQU0sY0FBYyxJQUFJLElBQUksVUFBVSxJQUFJLENBQUEsSUFBSztRQUFDLEVBQUUsR0FBRztRQUFFLEVBQUUsS0FBSztPQUFDLEtBQUssRUFBRTtJQUN0RSxNQUFNLFdBQVcsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDO0lBQzFDLE1BQU0sYUFBYSxZQUFZLEdBQUcsQ0FBQztJQUNuQyxNQUFNLFFBQVEsU0FBUyxjQUFjLEtBQUs7SUFFMUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxTQUFTLFdBQVcsRUFBRSxXQUFXLGNBQWMsRUFBRSxNQUFNLENBQUM7SUFFNUYsK0JBQStCO0lBQy9CLElBQUksUUFBUSxHQUFHO01BQ2IsTUFBTSxFQUFFLE1BQU0sV0FBVyxFQUFFLE9BQU8sWUFBWSxFQUFFLEdBQUcsTUFBTSxTQUN0RCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtNQUVULFFBQVEsR0FBRyxDQUFDLENBQUMsNEJBQTRCLEVBQUUsYUFBYSxRQUFRLFFBQVEsRUFBRSxNQUFNLFFBQVEsRUFBRSxjQUFjLFFBQVEsQ0FBQztNQUVqSCxJQUFJLENBQUMsZUFBZSxZQUFZLE9BQU8sR0FBRyxPQUFPO1FBQy9DLE1BQU0sSUFBSSxNQUFNLENBQUMsaUNBQWlDLEVBQUUsTUFBTSxZQUFZLEVBQUUsYUFBYSxXQUFXLEVBQUUsRUFBRSxDQUFDO01BQ3ZHO01BRUEscUJBQXFCO01BQ3JCLE1BQU0sYUFBYSxZQUFZLE9BQU8sR0FBRztNQUN6QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLG1CQUFtQixFQUFFLFlBQVksT0FBTyxDQUFDLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxXQUFXLENBQUM7TUFFbEYsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUNsQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7UUFBRSxTQUFTO01BQVcsR0FDN0IsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFO01BRXhCLElBQUksYUFBYTtRQUNmLFFBQVEsS0FBSyxDQUFDLHlCQUF5QjtRQUN2QyxNQUFNLElBQUksTUFBTTtNQUNsQjtNQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsc0NBQXNDLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUNoRSxPQUFPO01BQ0wsUUFBUSxHQUFHLENBQUMsQ0FBQywyQkFBMkIsRUFBRSxPQUFPLENBQUM7SUFDcEQ7SUFFQSx1QkFBdUI7SUFDdkIsUUFBUSxHQUFHLENBQUMsNEJBQTRCO01BQUUsUUFBUSxTQUFTLE1BQU07SUFBQztJQUNsRSxNQUFNLFdBQVcsTUFBTSxhQUFhO0lBRXBDLDRCQUE0QjtJQUM1QixNQUFNLGVBQWUsTUFBTSxhQUFhLEtBQUssU0FBUyxDQUFDO01BQ3JELE9BQU8sTUFBTSxLQUFLO01BQ2xCLFdBQVcsb0JBQW9CLGNBQWM7TUFDN0MsYUFBYSxvQkFBb0IsWUFBWTtNQUM3QyxjQUFjLG9CQUFvQixhQUFhO01BQy9DLFVBQVUsTUFBTSxRQUFRO01BQ3hCO01BQ0EsV0FBVyxJQUFJLE9BQU8sV0FBVztJQUNuQztJQUVBLDRFQUE0RTtJQUM1RSxNQUFNLFlBQVksT0FBTyxVQUFVO0lBQ25DLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sYUFDbEMsSUFBSSxDQUFDLGtCQUNMLE1BQU0sQ0FBQztNQUNOLElBQUk7TUFDSixVQUFVO01BQ1YsU0FBUyxLQUFLLEVBQUU7TUFDaEI7TUFDQSxRQUFRO01BQ1IsV0FBVztNQUNYLGVBQWU7TUFDZixnQkFBZ0Isb0JBQW9CLGNBQWM7TUFDbEQsZUFBZSxvQkFBb0IsYUFBYTtJQUNsRDtJQUVGLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLGlCQUFpQjtNQUMvQixNQUFNLE1BQU0sYUFBYSxXQUFXLGFBQWEsV0FBVztNQUM1RCxNQUFNLElBQUksTUFBTSxPQUFPLFFBQVEsV0FBVyxNQUFNO0lBQ2xEO0lBRUEsSUFBSSxTQUtBLENBQUM7SUFFTCxJQUFJO01BQ0YsT0FBUTtRQUNOLEtBQUs7VUFDSCw0Q0FBNEM7VUFDNUMsT0FBTyxjQUFjLEdBQUcsTUFBTSx1QkFDNUIsVUFBVSxPQUFPLFVBQVUsV0FBVztVQUV4QztRQUVGLEtBQUs7VUFDSCw0QkFBNEI7VUFDNUIsT0FBTyxjQUFjLEdBQUcsTUFBTSx1QkFDNUIsVUFBVSxPQUFPLFVBQVUsV0FBVztVQUV4QztRQUVGLEtBQUs7VUFDSCxpQkFBaUI7VUFDakIsT0FBTyxjQUFjLEdBQUcsTUFBTSx1QkFBdUI7VUFDckQsT0FBTyxjQUFjLEdBQUcsTUFBTSx1QkFDNUIsVUFBVSxPQUFPLFVBQVUsV0FBVztVQUV4QztRQUVGLEtBQUs7VUFDSCxNQUFNLGFBQWEsTUFBTSxhQUN2QixPQUNBLFVBQ0EsWUFBWSxHQUFHLENBQUMsbUJBQW1CLElBQ25DLFlBQVksR0FBRyxDQUFDLG1CQUFtQjtVQUVyQyxPQUFPLGlCQUFpQixHQUFHLFdBQVcsU0FBUztVQUMvQyxPQUFPLHNCQUFzQixHQUFHLFdBQVcsY0FBYztVQUN6RDtRQUVGLEtBQUs7VUFDSCxNQUFNLGFBQWEsTUFBTSxhQUN2QixPQUNBLFVBQ0EsWUFBWSxHQUFHLENBQUMsbUJBQW1CLElBQ25DLFlBQVksR0FBRyxDQUFDLG1CQUFtQjtVQUVyQyxPQUFPLGlCQUFpQixHQUFHLFdBQVcsU0FBUztVQUMvQyxPQUFPLHNCQUFzQixHQUFHLFdBQVcsY0FBYztVQUN6RDtNQUNKO01BRUEsdURBQXVEO01BQ3ZELE1BQU0sYUFDSCxJQUFJLENBQUMsa0JBQ0wsTUFBTSxDQUFDO1FBQ04sUUFBUTtRQUNSLGNBQWMsSUFBSSxPQUFPLFdBQVc7UUFDcEMsaUJBQWlCLE9BQU8sY0FBYztRQUN0QyxrQkFBa0IsT0FBTyxjQUFjO1FBQ3ZDLHFCQUFxQixPQUFPLGlCQUFpQjtRQUM3QywwQkFBMEIsT0FBTyxzQkFBc0I7TUFDekQsR0FDQyxFQUFFLENBQUMsTUFBTTtNQUVaLDZDQUE2QztNQUM3QyxNQUFNLGFBQWEsSUFBSSxDQUFDLGlCQUFpQixNQUFNLENBQUM7UUFDOUMsU0FBUyxLQUFLLEVBQUU7UUFDaEIsTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTLENBQUMsTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDLHFCQUFxQixDQUFDO1FBQ3BELGFBQWE7UUFDYixXQUFXO01BQ2I7TUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLG1CQUFtQixFQUFFLFVBQVUsQ0FBQztNQUU3QyxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUNiLFNBQVM7UUFDVDtRQUNBLEdBQUcsTUFBTTtNQUNYLElBQ0E7UUFBRSxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFHdEUsRUFBRSxPQUFPLGNBQXVCO01BQzlCLE1BQU0sUUFBUTtNQUNkLFFBQVEsS0FBSyxDQUFDLGtCQUFrQjtNQUVoQyxvREFBb0Q7TUFDcEQsTUFBTSxhQUNILElBQUksQ0FBQyxrQkFDTCxNQUFNLENBQUM7UUFDTixRQUFRO1FBQ1IsZUFBZSxNQUFNLE9BQU8sSUFBSTtNQUNsQyxHQUNDLEVBQUUsQ0FBQyxNQUFNO01BRVosd0NBQXdDO01BQ3hDLElBQUksUUFBUSxHQUFHO1FBQ2IsTUFBTSxFQUFFLE1BQU0sY0FBYyxFQUFFLEdBQUcsTUFBTSxTQUNwQyxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtRQUVULElBQUksZ0JBQWdCO1VBQ2xCLE1BQU0sU0FDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7WUFBRSxTQUFTLGVBQWUsT0FBTyxHQUFHO1VBQU0sR0FDakQsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFO1FBQzFCO01BQ0Y7TUFFQSxNQUFNO0lBQ1I7RUFFRixFQUFFLE9BQU8sT0FBWTtJQUNuQixRQUFRLEtBQUssQ0FBQyxrQkFBa0I7SUFDaEMsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPLE1BQU0sT0FBTztJQUFDLElBQ3RDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
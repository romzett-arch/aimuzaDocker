import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
// Генерация SHA-256 хеша
async function generateHash(data) {
  const encoder = new TextEncoder();
  const dataBuffer = encoder.encode(data);
  const hashBuffer = await crypto.subtle.digest("SHA-256", dataBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b)=>b.toString(16).padStart(2, "0")).join("");
}
// OpenTimestamps - бесплатная blockchain фиксация
async function submitToOpenTimestamps(hash) {
  try {
    const response = await fetch("https://a.pool.opentimestamps.org/digest", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: hash
    });
    if (!response.ok) {
      const fallbackResponse = await fetch("https://b.pool.opentimestamps.org/digest", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: hash
      });
      if (!fallbackResponse.ok) {
        throw new Error("OpenTimestamps servers unavailable");
      }
      return `ots_pending_${Date.now()}`;
    }
    return `ots_${Date.now()}`;
  } catch (error) {
    console.error("OpenTimestamps error:", error);
    return `ots_pending_${hash.substring(0, 16)}`;
  }
}
// n'RIS API интеграция
async function submitToNris(lyrics, hash, apiKey, apiUrl) {
  if (!apiKey) {
    throw new Error("API ключ n'RIS не настроен");
  }
  const response = await fetch(`${apiUrl}/deposits`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      type: "lyrics",
      title: lyrics.title,
      author: lyrics.author_name,
      hash: hash,
      metadata: {
        created_at: lyrics.created_at,
        language: lyrics.language
      }
    })
  });
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`n'RIS API error: ${error}`);
  }
  const result = await response.json();
  return {
    depositId: result.deposit_id || result.id,
    certificateUrl: result.certificate_url
  };
}
// IRMA API интеграция
async function submitToIrma(lyrics, hash, apiKey, apiUrl) {
  if (!apiKey) {
    throw new Error("API ключ IRMA не настроен");
  }
  const response = await fetch(`${apiUrl}/register`, {
    method: "POST",
    headers: {
      "X-API-Key": apiKey,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      work_type: "lyrics",
      title: lyrics.title,
      creators: [
        {
          role: "author",
          name: lyrics.author_name
        }
      ],
      content_hash: hash
    })
  });
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`IRMA API error: ${error}`);
  }
  const result = await response.json();
  return {
    depositId: result.registration_id || result.id,
    certificateUrl: result.certificate_url
  };
}
// Генерация HTML сертификата для текста
async function generateLyricsCertificate(supabase, lyrics, hash, depositId, authorName) {
  const formattedDate = new Date().toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
  const htmlContent = `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Сертификат депонирования текста - ${lyrics.title}</title>
  <style>
    @media print {
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .no-print { display: none !important; }
      @page { size: A4; margin: 15mm; }
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { 
      font-family: 'Times New Roman', 'Georgia', serif; 
      padding: 40px; 
      max-width: 800px; 
      margin: 0 auto; 
      background: #fff;
      color: #1a1a1a;
      line-height: 1.5;
    }
    .certificate {
      border: 3px double #2c3e50;
      padding: 40px;
      background: linear-gradient(135deg, #fefefe 0%, #f8f9fa 100%);
      position: relative;
    }
    .certificate::before {
      content: '';
      position: absolute;
      top: 10px; left: 10px; right: 10px; bottom: 10px;
      border: 1px solid #bdc3c7;
      pointer-events: none;
    }
    .header { 
      text-align: center; 
      border-bottom: 2px solid #2c3e50; 
      padding-bottom: 25px; 
      margin-bottom: 30px; 
    }
    .label-name { font-size: 14px; color: #555; font-weight: 500; letter-spacing: 1px; margin-bottom: 5px; }
    .website { font-size: 18px; color: #2c3e50; font-weight: bold; letter-spacing: 2px; }
    .title { 
      font-size: 28px; font-weight: bold; color: #1a1a1a; 
      text-transform: uppercase; letter-spacing: 3px; margin-top: 20px;
    }
    .subtitle { font-size: 16px; color: #666; margin-top: 10px; font-style: italic; }
    .content { display: grid; gap: 18px; }
    .section { display: grid; grid-template-columns: 180px 1fr; align-items: start; gap: 15px; }
    .label { font-weight: bold; color: #2c3e50; font-size: 14px; padding-top: 10px; }
    .value { 
      padding: 12px 15px; background: #fff; border: 1px solid #ddd;
      border-radius: 4px; font-size: 15px; box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);
    }
    .hash { font-family: 'Courier New', monospace; font-size: 11px; word-break: break-all; color: #555; }
    .seal { text-align: center; margin: 35px 0 25px; }
    .seal-text { 
      display: inline-block; padding: 20px 35px; border: 4px double #2c3e50; 
      border-radius: 50%; font-size: 14px; font-weight: bold; color: #2c3e50;
      text-align: center; line-height: 1.4; background: linear-gradient(135deg, #fff 0%, #f0f0f0 100%);
    }
    .footer { 
      margin-top: 30px; padding-top: 20px; border-top: 2px solid #2c3e50; 
      font-size: 12px; color: #666; text-align: center; line-height: 1.8;
    }
    .footer .platform { font-weight: bold; color: #2c3e50; font-size: 14px; margin-top: 15px; }
    .print-btn {
      display: block; margin: 20px auto; padding: 12px 30px;
      background: #2c3e50; color: #fff; border: none; border-radius: 5px;
      font-size: 16px; cursor: pointer; font-family: inherit;
    }
    .print-btn:hover { background: #1a252f; }
  </style>
</head>
<body>
  <button class="print-btn no-print" onclick="window.print()">📄 Сохранить как PDF / Распечатать</button>
  
  <div class="certificate">
    <div class="header">
      <div class="label-name">ООО "Музыкальный лейбл НОТА-ФЕЯ"</div>
      <div class="website">aimuza.ru</div>
      <div class="title">СЕРТИФИКАТ ДЕПОНИРОВАНИЯ</div>
      <div class="subtitle">Литературное произведение (текст песни)</div>
    </div>
    
    <div class="content">
      <div class="section">
        <div class="label">Название:</div>
        <div class="value">${lyrics.title}</div>
      </div>
      <div class="section">
        <div class="label">Автор текста:</div>
        <div class="value">${authorName || "Не указан"}</div>
      </div>
      <div class="section">
        <div class="label">Цифровой отпечаток (SHA-256):</div>
        <div class="value hash">${hash}</div>
      </div>
      <div class="section">
        <div class="label">Идентификатор:</div>
        <div class="value">${depositId}</div>
      </div>
      <div class="section">
        <div class="label">Дата депонирования:</div>
        <div class="value">${formattedDate}</div>
      </div>
    </div>
    
    <div class="seal">
      <div class="seal-text">НОТА-ФЕЯ<br/>✓ Verified</div>
    </div>
    
    <div class="footer">
      <p>Данный сертификат подтверждает факт существования текста на указанную дату.</p>
      <p>Цифровой отпечаток позволяет однозначно идентифицировать оригинальный текст.</p>
      <p class="platform">ООО "Музыкальный лейбл НОТА-ФЕЯ" • aimuza.ru</p>
    </div>
  </div>
</body>
</html>`;
  const fileName = `lyrics_certificate_${depositId}.html`;
  const htmlBytes = new TextEncoder().encode(htmlContent);
  const blob = new Blob([
    htmlBytes
  ], {
    type: "text/html;charset=utf-8"
  });
  const { error: uploadError } = await supabase.storage.from("certificates").upload(fileName, blob, {
    contentType: "text/html;charset=utf-8",
    cacheControl: "3600",
    upsert: true
  });
  if (uploadError) {
    console.error("Error uploading certificate:", uploadError);
    throw new Error("Не удалось сохранить сертификат");
  }
  const { data: urlData } = supabase.storage.from("certificates").getPublicUrl(fileName);
  return urlData.publicUrl;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Get user from auth header
    const authHeader = req.headers.get("authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "Требуется авторизация"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return new Response(JSON.stringify({
        error: "Неверный токен авторизации"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { lyricsId, method, authorName } = await req.json();
    console.log(`Processing lyrics deposit: ${lyricsId}, method: ${method}`);
    // Get lyrics data
    const { data: lyrics, error: lyricsError } = await supabase.from("lyrics_items").select("*").eq("id", lyricsId).eq("user_id", user.id).single();
    if (lyricsError || !lyrics) {
      return new Response(JSON.stringify({
        error: "Текст не найден или нет доступа"
      }), {
        status: 404,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Check for existing deposit
    const { data: existingDeposit } = await supabase.from("lyrics_deposits").select("id, status").eq("lyrics_id", lyricsId).eq("status", "completed").single();
    if (existingDeposit) {
      return new Response(JSON.stringify({
        error: "Текст уже депонирован"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Get deposit price
    const { data: priceSetting } = await supabase.from("app_settings").select("value").eq("key", "lyrics_deposit_price").single();
    const depositPrice = parseInt(priceSetting?.value || "50", 10);
    // Check user balance
    const { data: profile } = await supabase.from("profiles").select("balance").eq("user_id", user.id).single();
    if (!profile || (profile.balance || 0) < depositPrice) {
      return new Response(JSON.stringify({
        error: `Недостаточно средств. Требуется: ${depositPrice} ₽`
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Generate hash from lyrics content
    const contentHash = await generateHash(lyrics.content + lyrics.title + new Date().toISOString());
    const timestampHash = await generateHash(contentHash + Date.now().toString());
    let externalId = null;
    let certificateUrl = null;
    // Process based on method
    if (method === "blockchain") {
      externalId = await submitToOpenTimestamps(contentHash);
    } else if (method === "nris") {
      const nrisApiKey = Deno.env.get("NRIS_API_KEY");
      const nrisApiUrl = Deno.env.get("NRIS_API_URL") || "https://api.nris.ru";
      if (!nrisApiKey) {
        return new Response(JSON.stringify({
          error: "Сервис n'RIS временно недоступен"
        }), {
          status: 503,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      const result = await submitToNris({
        ...lyrics,
        author_name: authorName
      }, contentHash, nrisApiKey, nrisApiUrl);
      externalId = result.depositId;
      certificateUrl = result.certificateUrl || null;
    } else if (method === "irma") {
      const irmaApiKey = Deno.env.get("IRMA_API_KEY");
      const irmaApiUrl = Deno.env.get("IRMA_API_URL") || "https://api.irma.ru";
      if (!irmaApiKey) {
        return new Response(JSON.stringify({
          error: "Сервис IRMA временно недоступен"
        }), {
          status: 503,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json"
          }
        });
      }
      const result = await submitToIrma({
        ...lyrics,
        author_name: authorName
      }, contentHash, irmaApiKey, irmaApiUrl);
      externalId = result.depositId;
      certificateUrl = result.certificateUrl || null;
    }
    // Generate internal deposit ID
    const depositId = `LYR-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    // Always generate PDF certificate for internal
    if (method === "internal" || !certificateUrl) {
      certificateUrl = await generateLyricsCertificate(supabase, lyrics, contentHash, depositId, authorName || "");
    }
    // Deduct balance
    await supabase.from("profiles").update({
      balance: (profile.balance || 0) - depositPrice
    }).eq("user_id", user.id);
    // Create deposit record
    const { data: deposit, error: depositError } = await supabase.from("lyrics_deposits").insert({
      lyrics_id: lyricsId,
      user_id: user.id,
      method,
      status: "completed",
      content_hash: contentHash,
      timestamp_hash: timestampHash,
      external_id: externalId || depositId,
      certificate_url: certificateUrl,
      author_name: authorName,
      price_rub: depositPrice,
      deposited_at: new Date().toISOString()
    }).select().single();
    if (depositError) {
      console.error("Error creating deposit:", depositError);
      // Refund on error
      await supabase.from("profiles").update({
        balance: profile.balance
      }).eq("user_id", user.id);
      throw depositError;
    }
    // Create notification
    await supabase.from("notifications").insert({
      user_id: user.id,
      type: "lyrics_deposited",
      title: "Текст депонирован",
      message: `Ваш текст "${lyrics.title}" успешно депонирован`,
      target_type: "lyrics",
      target_id: lyricsId
    });
    console.log(`Lyrics deposit completed: ${deposit.id}`);
    return new Response(JSON.stringify({
      success: true,
      deposit,
      certificateUrl
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Lyrics deposit error:", error);
    const message = error instanceof Error ? error.message : "Ошибка при депонировании";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9seXJpY3MtZGVwb3NpdC9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzZXJ2ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xOTAuMC9odHRwL3NlcnZlci50c1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcImh0dHBzOi8vZXNtLnNoL0BzdXBhYmFzZS9zdXBhYmFzZS1qc0AyXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6IFwiYXV0aG9yaXphdGlvbiwgeC1jbGllbnQtaW5mbywgYXBpa2V5LCBjb250ZW50LXR5cGUsIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLCB4LXN1cGFiYXNlLWNsaWVudC1wbGF0Zm9ybS12ZXJzaW9uLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLCB4LXN1cGFiYXNlLWNsaWVudC1ydW50aW1lLXZlcnNpb25cIixcbn07XG5cbmludGVyZmFjZSBEZXBvc2l0UmVxdWVzdCB7XG4gIGx5cmljc0lkOiBzdHJpbmc7XG4gIG1ldGhvZDogXCJpbnRlcm5hbFwiIHwgXCJibG9ja2NoYWluXCIgfCBcIm5yaXNcIiB8IFwiaXJtYVwiO1xuICBhdXRob3JOYW1lPzogc3RyaW5nO1xufVxuXG4vLyDQk9C10L3QtdGA0LDRhtC40Y8gU0hBLTI1NiDRhdC10YjQsFxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVIYXNoKGRhdGE6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGVuY29kZXIgPSBuZXcgVGV4dEVuY29kZXIoKTtcbiAgY29uc3QgZGF0YUJ1ZmZlciA9IGVuY29kZXIuZW5jb2RlKGRhdGEpO1xuICBjb25zdCBoYXNoQnVmZmVyID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoXCJTSEEtMjU2XCIsIGRhdGFCdWZmZXIpO1xuICBjb25zdCBoYXNoQXJyYXkgPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGhhc2hCdWZmZXIpKTtcbiAgcmV0dXJuIGhhc2hBcnJheS5tYXAoYiA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCBcIjBcIikpLmpvaW4oXCJcIik7XG59XG5cbi8vIE9wZW5UaW1lc3RhbXBzIC0g0LHQtdGB0L/Qu9Cw0YLQvdCw0Y8gYmxvY2tjaGFpbiDRhNC40LrRgdCw0YbQuNGPXG5hc3luYyBmdW5jdGlvbiBzdWJtaXRUb09wZW5UaW1lc3RhbXBzKGhhc2g6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcImh0dHBzOi8vYS5wb29sLm9wZW50aW1lc3RhbXBzLm9yZy9kaWdlc3RcIiwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWRcIiB9LFxuICAgICAgYm9keTogaGFzaCxcbiAgICB9KTtcbiAgICBcbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICBjb25zdCBmYWxsYmFja1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2goXCJodHRwczovL2IucG9vbC5vcGVudGltZXN0YW1wcy5vcmcvZGlnZXN0XCIsIHtcbiAgICAgICAgbWV0aG9kOiBcIlBPU1RcIiwgXG4gICAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWRcIiB9LFxuICAgICAgICBib2R5OiBoYXNoLFxuICAgICAgfSk7XG4gICAgICBcbiAgICAgIGlmICghZmFsbGJhY2tSZXNwb25zZS5vaykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJPcGVuVGltZXN0YW1wcyBzZXJ2ZXJzIHVuYXZhaWxhYmxlXCIpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGBvdHNfcGVuZGluZ18ke0RhdGUubm93KCl9YDtcbiAgICB9XG4gICAgcmV0dXJuIGBvdHNfJHtEYXRlLm5vdygpfWA7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIk9wZW5UaW1lc3RhbXBzIGVycm9yOlwiLCBlcnJvcik7XG4gICAgcmV0dXJuIGBvdHNfcGVuZGluZ18ke2hhc2guc3Vic3RyaW5nKDAsIDE2KX1gO1xuICB9XG59XG5cbi8vIG4nUklTIEFQSSDQuNC90YLQtdCz0YDQsNGG0LjRj1xuYXN5bmMgZnVuY3Rpb24gc3VibWl0VG9OcmlzKFxuICBseXJpY3M6IGFueSxcbiAgaGFzaDogc3RyaW5nLFxuICBhcGlLZXk6IHN0cmluZyxcbiAgYXBpVXJsOiBzdHJpbmdcbik6IFByb21pc2U8eyBkZXBvc2l0SWQ6IHN0cmluZzsgY2VydGlmaWNhdGVVcmw/OiBzdHJpbmcgfT4ge1xuICBpZiAoIWFwaUtleSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkFQSSDQutC70Y7RhyBuJ1JJUyDQvdC1INC90LDRgdGC0YDQvtC10L1cIik7XG4gIH1cblxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke2FwaVVybH0vZGVwb3NpdHNgLCB7XG4gICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICBoZWFkZXJzOiB7XG4gICAgICBcIkF1dGhvcml6YXRpb25cIjogYEJlYXJlciAke2FwaUtleX1gLFxuICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgfSxcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICB0eXBlOiBcImx5cmljc1wiLFxuICAgICAgdGl0bGU6IGx5cmljcy50aXRsZSxcbiAgICAgIGF1dGhvcjogbHlyaWNzLmF1dGhvcl9uYW1lLFxuICAgICAgaGFzaDogaGFzaCxcbiAgICAgIG1ldGFkYXRhOiB7XG4gICAgICAgIGNyZWF0ZWRfYXQ6IGx5cmljcy5jcmVhdGVkX2F0LFxuICAgICAgICBsYW5ndWFnZTogbHlyaWNzLmxhbmd1YWdlLFxuICAgICAgfSxcbiAgICB9KSxcbiAgfSk7XG5cbiAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgIGNvbnN0IGVycm9yID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICAgIHRocm93IG5ldyBFcnJvcihgbidSSVMgQVBJIGVycm9yOiAke2Vycm9yfWApO1xuICB9XG5cbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICByZXR1cm4ge1xuICAgIGRlcG9zaXRJZDogcmVzdWx0LmRlcG9zaXRfaWQgfHwgcmVzdWx0LmlkLFxuICAgIGNlcnRpZmljYXRlVXJsOiByZXN1bHQuY2VydGlmaWNhdGVfdXJsLFxuICB9O1xufVxuXG4vLyBJUk1BIEFQSSDQuNC90YLQtdCz0YDQsNGG0LjRj1xuYXN5bmMgZnVuY3Rpb24gc3VibWl0VG9Jcm1hKFxuICBseXJpY3M6IGFueSxcbiAgaGFzaDogc3RyaW5nLFxuICBhcGlLZXk6IHN0cmluZyxcbiAgYXBpVXJsOiBzdHJpbmdcbik6IFByb21pc2U8eyBkZXBvc2l0SWQ6IHN0cmluZzsgY2VydGlmaWNhdGVVcmw/OiBzdHJpbmcgfT4ge1xuICBpZiAoIWFwaUtleSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkFQSSDQutC70Y7RhyBJUk1BINC90LUg0L3QsNGB0YLRgNC+0LXQvVwiKTtcbiAgfVxuXG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7YXBpVXJsfS9yZWdpc3RlcmAsIHtcbiAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgIGhlYWRlcnM6IHtcbiAgICAgIFwiWC1BUEktS2V5XCI6IGFwaUtleSxcbiAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgIH0sXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgd29ya190eXBlOiBcImx5cmljc1wiLFxuICAgICAgdGl0bGU6IGx5cmljcy50aXRsZSxcbiAgICAgIGNyZWF0b3JzOiBbeyByb2xlOiBcImF1dGhvclwiLCBuYW1lOiBseXJpY3MuYXV0aG9yX25hbWUgfV0sXG4gICAgICBjb250ZW50X2hhc2g6IGhhc2gsXG4gICAgfSksXG4gIH0pO1xuXG4gIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICBjb25zdCBlcnJvciA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICB0aHJvdyBuZXcgRXJyb3IoYElSTUEgQVBJIGVycm9yOiAke2Vycm9yfWApO1xuICB9XG5cbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICByZXR1cm4ge1xuICAgIGRlcG9zaXRJZDogcmVzdWx0LnJlZ2lzdHJhdGlvbl9pZCB8fCByZXN1bHQuaWQsXG4gICAgY2VydGlmaWNhdGVVcmw6IHJlc3VsdC5jZXJ0aWZpY2F0ZV91cmwsXG4gIH07XG59XG5cbi8vINCT0LXQvdC10YDQsNGG0LjRjyBIVE1MINGB0LXRgNGC0LjRhNC40LrQsNGC0LAg0LTQu9GPINGC0LXQutGB0YLQsFxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVMeXJpY3NDZXJ0aWZpY2F0ZShcbiAgc3VwYWJhc2U6IGFueSxcbiAgbHlyaWNzOiBhbnksXG4gIGhhc2g6IHN0cmluZyxcbiAgZGVwb3NpdElkOiBzdHJpbmcsXG4gIGF1dGhvck5hbWU6IHN0cmluZ1xuKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc3QgZm9ybWF0dGVkRGF0ZSA9IG5ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoJ3J1LVJVJywge1xuICAgIGRheTogJzItZGlnaXQnLFxuICAgIG1vbnRoOiAnMi1kaWdpdCcsIFxuICAgIHllYXI6ICdudW1lcmljJyxcbiAgICBob3VyOiAnMi1kaWdpdCcsXG4gICAgbWludXRlOiAnMi1kaWdpdCcsXG4gICAgc2Vjb25kOiAnMi1kaWdpdCdcbiAgfSk7XG5cbiAgY29uc3QgaHRtbENvbnRlbnQgPSBgPCFET0NUWVBFIGh0bWw+XG48aHRtbCBsYW5nPVwicnVcIj5cbjxoZWFkPlxuICA8bWV0YSBjaGFyc2V0PVwiVVRGLThcIj5cbiAgPG1ldGEgbmFtZT1cInZpZXdwb3J0XCIgY29udGVudD1cIndpZHRoPWRldmljZS13aWR0aCwgaW5pdGlhbC1zY2FsZT0xLjBcIj5cbiAgPHRpdGxlPtCh0LXRgNGC0LjRhNC40LrQsNGCINC00LXQv9C+0L3QuNGA0L7QstCw0L3QuNGPINGC0LXQutGB0YLQsCAtICR7bHlyaWNzLnRpdGxlfTwvdGl0bGU+XG4gIDxzdHlsZT5cbiAgICBAbWVkaWEgcHJpbnQge1xuICAgICAgYm9keSB7IC13ZWJraXQtcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdDsgcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdDsgfVxuICAgICAgLm5vLXByaW50IHsgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50OyB9XG4gICAgICBAcGFnZSB7IHNpemU6IEE0OyBtYXJnaW46IDE1bW07IH1cbiAgICB9XG4gICAgKiB7IGJveC1zaXppbmc6IGJvcmRlci1ib3g7IG1hcmdpbjogMDsgcGFkZGluZzogMDsgfVxuICAgIGJvZHkgeyBcbiAgICAgIGZvbnQtZmFtaWx5OiAnVGltZXMgTmV3IFJvbWFuJywgJ0dlb3JnaWEnLCBzZXJpZjsgXG4gICAgICBwYWRkaW5nOiA0MHB4OyBcbiAgICAgIG1heC13aWR0aDogODAwcHg7IFxuICAgICAgbWFyZ2luOiAwIGF1dG87IFxuICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICAgIGNvbG9yOiAjMWExYTFhO1xuICAgICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICB9XG4gICAgLmNlcnRpZmljYXRlIHtcbiAgICAgIGJvcmRlcjogM3B4IGRvdWJsZSAjMmMzZTUwO1xuICAgICAgcGFkZGluZzogNDBweDtcbiAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICNmZWZlZmUgMCUsICNmOGY5ZmEgMTAwJSk7XG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgfVxuICAgIC5jZXJ0aWZpY2F0ZTo6YmVmb3JlIHtcbiAgICAgIGNvbnRlbnQ6ICcnO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgdG9wOiAxMHB4OyBsZWZ0OiAxMHB4OyByaWdodDogMTBweDsgYm90dG9tOiAxMHB4O1xuICAgICAgYm9yZGVyOiAxcHggc29saWQgI2JkYzNjNztcbiAgICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgIH1cbiAgICAuaGVhZGVyIHsgXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7IFxuICAgICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICMyYzNlNTA7IFxuICAgICAgcGFkZGluZy1ib3R0b206IDI1cHg7IFxuICAgICAgbWFyZ2luLWJvdHRvbTogMzBweDsgXG4gICAgfVxuICAgIC5sYWJlbC1uYW1lIHsgZm9udC1zaXplOiAxNHB4OyBjb2xvcjogIzU1NTsgZm9udC13ZWlnaHQ6IDUwMDsgbGV0dGVyLXNwYWNpbmc6IDFweDsgbWFyZ2luLWJvdHRvbTogNXB4OyB9XG4gICAgLndlYnNpdGUgeyBmb250LXNpemU6IDE4cHg7IGNvbG9yOiAjMmMzZTUwOyBmb250LXdlaWdodDogYm9sZDsgbGV0dGVyLXNwYWNpbmc6IDJweDsgfVxuICAgIC50aXRsZSB7IFxuICAgICAgZm9udC1zaXplOiAyOHB4OyBmb250LXdlaWdodDogYm9sZDsgY29sb3I6ICMxYTFhMWE7IFxuICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTsgbGV0dGVyLXNwYWNpbmc6IDNweDsgbWFyZ2luLXRvcDogMjBweDtcbiAgICB9XG4gICAgLnN1YnRpdGxlIHsgZm9udC1zaXplOiAxNnB4OyBjb2xvcjogIzY2NjsgbWFyZ2luLXRvcDogMTBweDsgZm9udC1zdHlsZTogaXRhbGljOyB9XG4gICAgLmNvbnRlbnQgeyBkaXNwbGF5OiBncmlkOyBnYXA6IDE4cHg7IH1cbiAgICAuc2VjdGlvbiB7IGRpc3BsYXk6IGdyaWQ7IGdyaWQtdGVtcGxhdGUtY29sdW1uczogMTgwcHggMWZyOyBhbGlnbi1pdGVtczogc3RhcnQ7IGdhcDogMTVweDsgfVxuICAgIC5sYWJlbCB7IGZvbnQtd2VpZ2h0OiBib2xkOyBjb2xvcjogIzJjM2U1MDsgZm9udC1zaXplOiAxNHB4OyBwYWRkaW5nLXRvcDogMTBweDsgfVxuICAgIC52YWx1ZSB7IFxuICAgICAgcGFkZGluZzogMTJweCAxNXB4OyBiYWNrZ3JvdW5kOiAjZmZmOyBib3JkZXI6IDFweCBzb2xpZCAjZGRkO1xuICAgICAgYm9yZGVyLXJhZGl1czogNHB4OyBmb250LXNpemU6IDE1cHg7IGJveC1zaGFkb3c6IGluc2V0IDAgMXB4IDNweCByZ2JhKDAsMCwwLDAuMDUpO1xuICAgIH1cbiAgICAuaGFzaCB7IGZvbnQtZmFtaWx5OiAnQ291cmllciBOZXcnLCBtb25vc3BhY2U7IGZvbnQtc2l6ZTogMTFweDsgd29yZC1icmVhazogYnJlYWstYWxsOyBjb2xvcjogIzU1NTsgfVxuICAgIC5zZWFsIHsgdGV4dC1hbGlnbjogY2VudGVyOyBtYXJnaW46IDM1cHggMCAyNXB4OyB9XG4gICAgLnNlYWwtdGV4dCB7IFxuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrOyBwYWRkaW5nOiAyMHB4IDM1cHg7IGJvcmRlcjogNHB4IGRvdWJsZSAjMmMzZTUwOyBcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTsgZm9udC1zaXplOiAxNHB4OyBmb250LXdlaWdodDogYm9sZDsgY29sb3I6ICMyYzNlNTA7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7IGxpbmUtaGVpZ2h0OiAxLjQ7IGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICNmZmYgMCUsICNmMGYwZjAgMTAwJSk7XG4gICAgfVxuICAgIC5mb290ZXIgeyBcbiAgICAgIG1hcmdpbi10b3A6IDMwcHg7IHBhZGRpbmctdG9wOiAyMHB4OyBib3JkZXItdG9wOiAycHggc29saWQgIzJjM2U1MDsgXG4gICAgICBmb250LXNpemU6IDEycHg7IGNvbG9yOiAjNjY2OyB0ZXh0LWFsaWduOiBjZW50ZXI7IGxpbmUtaGVpZ2h0OiAxLjg7XG4gICAgfVxuICAgIC5mb290ZXIgLnBsYXRmb3JtIHsgZm9udC13ZWlnaHQ6IGJvbGQ7IGNvbG9yOiAjMmMzZTUwOyBmb250LXNpemU6IDE0cHg7IG1hcmdpbi10b3A6IDE1cHg7IH1cbiAgICAucHJpbnQtYnRuIHtcbiAgICAgIGRpc3BsYXk6IGJsb2NrOyBtYXJnaW46IDIwcHggYXV0bzsgcGFkZGluZzogMTJweCAzMHB4O1xuICAgICAgYmFja2dyb3VuZDogIzJjM2U1MDsgY29sb3I6ICNmZmY7IGJvcmRlcjogbm9uZTsgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgZm9udC1zaXplOiAxNnB4OyBjdXJzb3I6IHBvaW50ZXI7IGZvbnQtZmFtaWx5OiBpbmhlcml0O1xuICAgIH1cbiAgICAucHJpbnQtYnRuOmhvdmVyIHsgYmFja2dyb3VuZDogIzFhMjUyZjsgfVxuICA8L3N0eWxlPlxuPC9oZWFkPlxuPGJvZHk+XG4gIDxidXR0b24gY2xhc3M9XCJwcmludC1idG4gbm8tcHJpbnRcIiBvbmNsaWNrPVwid2luZG93LnByaW50KClcIj7wn5OEINCh0L7RhdGA0LDQvdC40YLRjCDQutCw0LogUERGIC8g0KDQsNGB0L/QtdGH0LDRgtCw0YLRjDwvYnV0dG9uPlxuICBcbiAgPGRpdiBjbGFzcz1cImNlcnRpZmljYXRlXCI+XG4gICAgPGRpdiBjbGFzcz1cImhlYWRlclwiPlxuICAgICAgPGRpdiBjbGFzcz1cImxhYmVsLW5hbWVcIj7QntCe0J4gXCLQnNGD0LfRi9C60LDQu9GM0L3Ri9C5INC70LXQudCx0Lsg0J3QntCi0JAt0KTQldCvXCI8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJ3ZWJzaXRlXCI+YWltdXphLnJ1PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwidGl0bGVcIj7QodCV0KDQotCY0KTQmNCa0JDQoiDQlNCV0J/QntCd0JjQoNCe0JLQkNCd0JjQrzwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInN1YnRpdGxlXCI+0JvQuNGC0LXRgNCw0YLRg9GA0L3QvtC1INC/0YDQvtC40LfQstC10LTQtdC90LjQtSAo0YLQtdC60YHRgiDQv9C10YHQvdC4KTwvZGl2PlxuICAgIDwvZGl2PlxuICAgIFxuICAgIDxkaXYgY2xhc3M9XCJjb250ZW50XCI+XG4gICAgICA8ZGl2IGNsYXNzPVwic2VjdGlvblwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwibGFiZWxcIj7QndCw0LfQstCw0L3QuNC1OjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwidmFsdWVcIj4ke2x5cmljcy50aXRsZX08L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+0JDQstGC0L7RgCDRgtC10LrRgdGC0LA6PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ2YWx1ZVwiPiR7YXV0aG9yTmFtZSB8fCBcItCd0LUg0YPQutCw0LfQsNC9XCJ9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbFwiPtCm0LjRhNGA0L7QstC+0Lkg0L7RgtC/0LXRh9Cw0YLQvtC6IChTSEEtMjU2KTo8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInZhbHVlIGhhc2hcIj4ke2hhc2h9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbFwiPtCY0LTQtdC90YLQuNGE0LjQutCw0YLQvtGAOjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwidmFsdWVcIj4ke2RlcG9zaXRJZH08L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+0JTQsNGC0LAg0LTQtdC/0L7QvdC40YDQvtCy0LDQvdC40Y86PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ2YWx1ZVwiPiR7Zm9ybWF0dGVkRGF0ZX08L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIFxuICAgIDxkaXYgY2xhc3M9XCJzZWFsXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwic2VhbC10ZXh0XCI+0J3QntCi0JAt0KTQldCvPGJyLz7inJMgVmVyaWZpZWQ8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICBcbiAgICA8ZGl2IGNsYXNzPVwiZm9vdGVyXCI+XG4gICAgICA8cD7QlNCw0L3QvdGL0Lkg0YHQtdGA0YLQuNGE0LjQutCw0YIg0L/QvtC00YLQstC10YDQttC00LDQtdGCINGE0LDQutGCINGB0YPRidC10YHRgtCy0L7QstCw0L3QuNGPINGC0LXQutGB0YLQsCDQvdCwINGD0LrQsNC30LDQvdC90YPRjiDQtNCw0YLRgy48L3A+XG4gICAgICA8cD7QptC40YTRgNC+0LLQvtC5INC+0YLQv9C10YfQsNGC0L7QuiDQv9C+0LfQstC+0LvRj9C10YIg0L7QtNC90L7Qt9C90LDRh9C90L4g0LjQtNC10L3RgtC40YTQuNGG0LjRgNC+0LLQsNGC0Ywg0L7RgNC40LPQuNC90LDQu9GM0L3Ri9C5INGC0LXQutGB0YIuPC9wPlxuICAgICAgPHAgY2xhc3M9XCJwbGF0Zm9ybVwiPtCe0J7QniBcItCc0YPQt9GL0LrQsNC70YzQvdGL0Lkg0LvQtdC50LHQuyDQndCe0KLQkC3QpNCV0K9cIiDigKIgYWltdXphLnJ1PC9wPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvYm9keT5cbjwvaHRtbD5gO1xuXG4gIGNvbnN0IGZpbGVOYW1lID0gYGx5cmljc19jZXJ0aWZpY2F0ZV8ke2RlcG9zaXRJZH0uaHRtbGA7XG4gIGNvbnN0IGh0bWxCeXRlcyA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShodG1sQ29udGVudCk7XG4gIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbaHRtbEJ5dGVzXSwgeyB0eXBlOiBcInRleHQvaHRtbDtjaGFyc2V0PXV0Zi04XCIgfSk7XG4gIFxuICBjb25zdCB7IGVycm9yOiB1cGxvYWRFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2Uuc3RvcmFnZVxuICAgIC5mcm9tKFwiY2VydGlmaWNhdGVzXCIpXG4gICAgLnVwbG9hZChmaWxlTmFtZSwgYmxvYiwge1xuICAgICAgY29udGVudFR5cGU6IFwidGV4dC9odG1sO2NoYXJzZXQ9dXRmLThcIixcbiAgICAgIGNhY2hlQ29udHJvbDogXCIzNjAwXCIsXG4gICAgICB1cHNlcnQ6IHRydWUsXG4gICAgfSk7XG5cbiAgaWYgKHVwbG9hZEVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwbG9hZGluZyBjZXJ0aWZpY2F0ZTpcIiwgdXBsb2FkRXJyb3IpO1xuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0YHQvtGF0YDQsNC90LjRgtGMINGB0LXRgNGC0LjRhNC40LrQsNGCXCIpO1xuICB9XG5cbiAgY29uc3QgeyBkYXRhOiB1cmxEYXRhIH0gPSBzdXBhYmFzZS5zdG9yYWdlXG4gICAgLmZyb20oXCJjZXJ0aWZpY2F0ZXNcIilcbiAgICAuZ2V0UHVibGljVXJsKGZpbGVOYW1lKTtcblxuICByZXR1cm4gdXJsRGF0YS5wdWJsaWNVcmw7XG59XG5cbnNlcnZlKGFzeW5jIChyZXEpID0+IHtcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiT1BUSU9OU1wiKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7IGhlYWRlcnM6IGNvcnNIZWFkZXJzIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2VTZXJ2aWNlS2V5ID0gRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSE7XG4gICAgY29uc3Qgc3VwYWJhc2UgPSBjcmVhdGVDbGllbnQoc3VwYWJhc2VVcmwsIHN1cGFiYXNlU2VydmljZUtleSk7XG5cbiAgICAvLyBHZXQgdXNlciBmcm9tIGF1dGggaGVhZGVyXG4gICAgY29uc3QgYXV0aEhlYWRlciA9IHJlcS5oZWFkZXJzLmdldChcImF1dGhvcml6YXRpb25cIik7XG4gICAgaWYgKCFhdXRoSGVhZGVyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCi0YDQtdCx0YPQtdGC0YHRjyDQsNCy0YLQvtGA0LjQt9Cw0YbQuNGPXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZShcIkJlYXJlciBcIiwgXCJcIik7XG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSwgZXJyb3I6IGF1dGhFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKHRva2VuKTtcbiAgICBcbiAgICBpZiAoYXV0aEVycm9yIHx8ICF1c2VyKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LXQstC10YDQvdGL0Lkg0YLQvtC60LXQvSDQsNCy0YLQvtGA0LjQt9Cw0YbQuNC4XCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB7IGx5cmljc0lkLCBtZXRob2QsIGF1dGhvck5hbWUgfSA9IGF3YWl0IHJlcS5qc29uKCkgYXMgRGVwb3NpdFJlcXVlc3Q7XG4gICAgY29uc29sZS5sb2coYFByb2Nlc3NpbmcgbHlyaWNzIGRlcG9zaXQ6ICR7bHlyaWNzSWR9LCBtZXRob2Q6ICR7bWV0aG9kfWApO1xuXG4gICAgLy8gR2V0IGx5cmljcyBkYXRhXG4gICAgY29uc3QgeyBkYXRhOiBseXJpY3MsIGVycm9yOiBseXJpY3NFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwibHlyaWNzX2l0ZW1zXCIpXG4gICAgICAuc2VsZWN0KFwiKlwiKVxuICAgICAgLmVxKFwiaWRcIiwgbHlyaWNzSWQpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAobHlyaWNzRXJyb3IgfHwgIWx5cmljcykge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQotC10LrRgdGCINC90LUg0L3QsNC50LTQtdC9INC40LvQuCDQvdC10YIg0LTQvtGB0YLRg9C/0LBcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwNCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIENoZWNrIGZvciBleGlzdGluZyBkZXBvc2l0XG4gICAgY29uc3QgeyBkYXRhOiBleGlzdGluZ0RlcG9zaXQgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImx5cmljc19kZXBvc2l0c1wiKVxuICAgICAgLnNlbGVjdChcImlkLCBzdGF0dXNcIilcbiAgICAgIC5lcShcImx5cmljc19pZFwiLCBseXJpY3NJZClcbiAgICAgIC5lcShcInN0YXR1c1wiLCBcImNvbXBsZXRlZFwiKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKGV4aXN0aW5nRGVwb3NpdCkge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQotC10LrRgdGCINGD0LbQtSDQtNC10L/QvtC90LjRgNC+0LLQsNC9XCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBHZXQgZGVwb3NpdCBwcmljZVxuICAgIGNvbnN0IHsgZGF0YTogcHJpY2VTZXR0aW5nIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJhcHBfc2V0dGluZ3NcIilcbiAgICAgIC5zZWxlY3QoXCJ2YWx1ZVwiKVxuICAgICAgLmVxKFwia2V5XCIsIFwibHlyaWNzX2RlcG9zaXRfcHJpY2VcIilcbiAgICAgIC5zaW5nbGUoKTtcbiAgICBcbiAgICBjb25zdCBkZXBvc2l0UHJpY2UgPSBwYXJzZUludChwcmljZVNldHRpbmc/LnZhbHVlIHx8IFwiNTBcIiwgMTApO1xuXG4gICAgLy8gQ2hlY2sgdXNlciBiYWxhbmNlXG4gICAgY29uc3QgeyBkYXRhOiBwcm9maWxlIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgLnNlbGVjdChcImJhbGFuY2VcIilcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmICghcHJvZmlsZSB8fCAocHJvZmlsZS5iYWxhbmNlIHx8IDApIDwgZGVwb3NpdFByaWNlKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBg0J3QtdC00L7RgdGC0LDRgtC+0YfQvdC+INGB0YDQtdC00YHRgtCyLiDQotGA0LXQsdGD0LXRgtGB0Y86ICR7ZGVwb3NpdFByaWNlfSDigr1gIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gR2VuZXJhdGUgaGFzaCBmcm9tIGx5cmljcyBjb250ZW50XG4gICAgY29uc3QgY29udGVudEhhc2ggPSBhd2FpdCBnZW5lcmF0ZUhhc2gobHlyaWNzLmNvbnRlbnQgKyBseXJpY3MudGl0bGUgKyBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpO1xuICAgIGNvbnN0IHRpbWVzdGFtcEhhc2ggPSBhd2FpdCBnZW5lcmF0ZUhhc2goY29udGVudEhhc2ggKyBEYXRlLm5vdygpLnRvU3RyaW5nKCkpO1xuXG4gICAgbGV0IGV4dGVybmFsSWQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICAgIGxldCBjZXJ0aWZpY2F0ZVVybDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG5cbiAgICAvLyBQcm9jZXNzIGJhc2VkIG9uIG1ldGhvZFxuICAgIGlmIChtZXRob2QgPT09IFwiYmxvY2tjaGFpblwiKSB7XG4gICAgICBleHRlcm5hbElkID0gYXdhaXQgc3VibWl0VG9PcGVuVGltZXN0YW1wcyhjb250ZW50SGFzaCk7XG4gICAgfSBlbHNlIGlmIChtZXRob2QgPT09IFwibnJpc1wiKSB7XG4gICAgICBjb25zdCBucmlzQXBpS2V5ID0gRGVuby5lbnYuZ2V0KFwiTlJJU19BUElfS0VZXCIpO1xuICAgICAgY29uc3QgbnJpc0FwaVVybCA9IERlbm8uZW52LmdldChcIk5SSVNfQVBJX1VSTFwiKSB8fCBcImh0dHBzOi8vYXBpLm5yaXMucnVcIjtcbiAgICAgIFxuICAgICAgaWYgKCFucmlzQXBpS2V5KSB7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQodC10YDQstC40YEgbidSSVMg0LLRgNC10LzQtdC90L3QviDQvdC10LTQvtGB0YLRg9C/0LXQvVwiIH0pLFxuICAgICAgICAgIHsgc3RhdHVzOiA1MDMsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzdWJtaXRUb05yaXMoXG4gICAgICAgIHsgLi4ubHlyaWNzLCBhdXRob3JfbmFtZTogYXV0aG9yTmFtZSB9LFxuICAgICAgICBjb250ZW50SGFzaCxcbiAgICAgICAgbnJpc0FwaUtleSxcbiAgICAgICAgbnJpc0FwaVVybFxuICAgICAgKTtcbiAgICAgIGV4dGVybmFsSWQgPSByZXN1bHQuZGVwb3NpdElkO1xuICAgICAgY2VydGlmaWNhdGVVcmwgPSByZXN1bHQuY2VydGlmaWNhdGVVcmwgfHwgbnVsbDtcbiAgICB9IGVsc2UgaWYgKG1ldGhvZCA9PT0gXCJpcm1hXCIpIHtcbiAgICAgIGNvbnN0IGlybWFBcGlLZXkgPSBEZW5vLmVudi5nZXQoXCJJUk1BX0FQSV9LRVlcIik7XG4gICAgICBjb25zdCBpcm1hQXBpVXJsID0gRGVuby5lbnYuZ2V0KFwiSVJNQV9BUElfVVJMXCIpIHx8IFwiaHR0cHM6Ly9hcGkuaXJtYS5ydVwiO1xuICAgICAgXG4gICAgICBpZiAoIWlybWFBcGlLZXkpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCh0LXRgNCy0LjRgSBJUk1BINCy0YDQtdC80LXQvdC90L4g0L3QtdC00L7RgdGC0YPQv9C10L1cIiB9KSxcbiAgICAgICAgICB7IHN0YXR1czogNTAzLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgc3VibWl0VG9Jcm1hKFxuICAgICAgICB7IC4uLmx5cmljcywgYXV0aG9yX25hbWU6IGF1dGhvck5hbWUgfSxcbiAgICAgICAgY29udGVudEhhc2gsXG4gICAgICAgIGlybWFBcGlLZXksXG4gICAgICAgIGlybWFBcGlVcmxcbiAgICAgICk7XG4gICAgICBleHRlcm5hbElkID0gcmVzdWx0LmRlcG9zaXRJZDtcbiAgICAgIGNlcnRpZmljYXRlVXJsID0gcmVzdWx0LmNlcnRpZmljYXRlVXJsIHx8IG51bGw7XG4gICAgfVxuXG4gICAgLy8gR2VuZXJhdGUgaW50ZXJuYWwgZGVwb3NpdCBJRFxuICAgIGNvbnN0IGRlcG9zaXRJZCA9IGBMWVItJHtEYXRlLm5vdygpfS0ke01hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cigyLCA5KS50b1VwcGVyQ2FzZSgpfWA7XG4gICAgXG4gICAgLy8gQWx3YXlzIGdlbmVyYXRlIFBERiBjZXJ0aWZpY2F0ZSBmb3IgaW50ZXJuYWxcbiAgICBpZiAobWV0aG9kID09PSBcImludGVybmFsXCIgfHwgIWNlcnRpZmljYXRlVXJsKSB7XG4gICAgICBjZXJ0aWZpY2F0ZVVybCA9IGF3YWl0IGdlbmVyYXRlTHlyaWNzQ2VydGlmaWNhdGUoXG4gICAgICAgIHN1cGFiYXNlLFxuICAgICAgICBseXJpY3MsXG4gICAgICAgIGNvbnRlbnRIYXNoLFxuICAgICAgICBkZXBvc2l0SWQsXG4gICAgICAgIGF1dGhvck5hbWUgfHwgXCJcIlxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBEZWR1Y3QgYmFsYW5jZVxuICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcInByb2ZpbGVzXCIpXG4gICAgICAudXBkYXRlKHsgYmFsYW5jZTogKHByb2ZpbGUuYmFsYW5jZSB8fCAwKSAtIGRlcG9zaXRQcmljZSB9KVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcblxuICAgIC8vIENyZWF0ZSBkZXBvc2l0IHJlY29yZFxuICAgIGNvbnN0IHsgZGF0YTogZGVwb3NpdCwgZXJyb3I6IGRlcG9zaXRFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwibHlyaWNzX2RlcG9zaXRzXCIpXG4gICAgICAuaW5zZXJ0KHtcbiAgICAgICAgbHlyaWNzX2lkOiBseXJpY3NJZCxcbiAgICAgICAgdXNlcl9pZDogdXNlci5pZCxcbiAgICAgICAgbWV0aG9kLFxuICAgICAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXG4gICAgICAgIGNvbnRlbnRfaGFzaDogY29udGVudEhhc2gsXG4gICAgICAgIHRpbWVzdGFtcF9oYXNoOiB0aW1lc3RhbXBIYXNoLFxuICAgICAgICBleHRlcm5hbF9pZDogZXh0ZXJuYWxJZCB8fCBkZXBvc2l0SWQsXG4gICAgICAgIGNlcnRpZmljYXRlX3VybDogY2VydGlmaWNhdGVVcmwsXG4gICAgICAgIGF1dGhvcl9uYW1lOiBhdXRob3JOYW1lLFxuICAgICAgICBwcmljZV9ydWI6IGRlcG9zaXRQcmljZSxcbiAgICAgICAgZGVwb3NpdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9KVxuICAgICAgLnNlbGVjdCgpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoZGVwb3NpdEVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY3JlYXRpbmcgZGVwb3NpdDpcIiwgZGVwb3NpdEVycm9yKTtcbiAgICAgIC8vIFJlZnVuZCBvbiBlcnJvclxuICAgICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAudXBkYXRlKHsgYmFsYW5jZTogcHJvZmlsZS5iYWxhbmNlIH0pXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZCk7XG4gICAgICB0aHJvdyBkZXBvc2l0RXJyb3I7XG4gICAgfVxuXG4gICAgLy8gQ3JlYXRlIG5vdGlmaWNhdGlvblxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oXCJub3RpZmljYXRpb25zXCIpLmluc2VydCh7XG4gICAgICB1c2VyX2lkOiB1c2VyLmlkLFxuICAgICAgdHlwZTogXCJseXJpY3NfZGVwb3NpdGVkXCIsXG4gICAgICB0aXRsZTogXCLQotC10LrRgdGCINC00LXQv9C+0L3QuNGA0L7QstCw0L1cIixcbiAgICAgIG1lc3NhZ2U6IGDQktCw0Ygg0YLQtdC60YHRgiBcIiR7bHlyaWNzLnRpdGxlfVwiINGD0YHQv9C10YjQvdC+INC00LXQv9C+0L3QuNGA0L7QstCw0L1gLFxuICAgICAgdGFyZ2V0X3R5cGU6IFwibHlyaWNzXCIsXG4gICAgICB0YXJnZXRfaWQ6IGx5cmljc0lkLFxuICAgIH0pO1xuXG4gICAgY29uc29sZS5sb2coYEx5cmljcyBkZXBvc2l0IGNvbXBsZXRlZDogJHtkZXBvc2l0LmlkfWApO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsIFxuICAgICAgICBkZXBvc2l0LFxuICAgICAgICBjZXJ0aWZpY2F0ZVVybCBcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuXG4gIH0gY2F0Y2ggKGVycm9yOiB1bmtub3duKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkx5cmljcyBkZXBvc2l0IGVycm9yOlwiLCBlcnJvcik7XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCLQntGI0LjQsdC60LAg0L/RgNC4INC00LXQv9C+0L3QuNGA0L7QstCw0L3QuNC4XCI7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IG1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLEtBQUssUUFBUSwrQ0FBK0M7QUFDckUsU0FBUyxZQUFZLFFBQVEseUNBQXlDO0FBRXRFLE1BQU0sY0FBYztFQUNsQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0FBQ2xDO0FBUUEseUJBQXlCO0FBQ3pCLGVBQWUsYUFBYSxJQUFZO0VBQ3RDLE1BQU0sVUFBVSxJQUFJO0VBQ3BCLE1BQU0sYUFBYSxRQUFRLE1BQU0sQ0FBQztFQUNsQyxNQUFNLGFBQWEsTUFBTSxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVztFQUN6RCxNQUFNLFlBQVksTUFBTSxJQUFJLENBQUMsSUFBSSxXQUFXO0VBQzVDLE9BQU8sVUFBVSxHQUFHLENBQUMsQ0FBQSxJQUFLLEVBQUUsUUFBUSxDQUFDLElBQUksUUFBUSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFDbEU7QUFFQSxrREFBa0Q7QUFDbEQsZUFBZSx1QkFBdUIsSUFBWTtFQUNoRCxJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTSw0Q0FBNEM7TUFDdkUsUUFBUTtNQUNSLFNBQVM7UUFBRSxnQkFBZ0I7TUFBb0M7TUFDL0QsTUFBTTtJQUNSO0lBRUEsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO01BQ2hCLE1BQU0sbUJBQW1CLE1BQU0sTUFBTSw0Q0FBNEM7UUFDL0UsUUFBUTtRQUNSLFNBQVM7VUFBRSxnQkFBZ0I7UUFBb0M7UUFDL0QsTUFBTTtNQUNSO01BRUEsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEVBQUU7UUFDeEIsTUFBTSxJQUFJLE1BQU07TUFDbEI7TUFDQSxPQUFPLENBQUMsWUFBWSxFQUFFLEtBQUssR0FBRyxHQUFHLENBQUM7SUFDcEM7SUFDQSxPQUFPLENBQUMsSUFBSSxFQUFFLEtBQUssR0FBRyxHQUFHLENBQUM7RUFDNUIsRUFBRSxPQUFPLE9BQU87SUFDZCxRQUFRLEtBQUssQ0FBQyx5QkFBeUI7SUFDdkMsT0FBTyxDQUFDLFlBQVksRUFBRSxLQUFLLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQztFQUMvQztBQUNGO0FBRUEsdUJBQXVCO0FBQ3ZCLGVBQWUsYUFDYixNQUFXLEVBQ1gsSUFBWSxFQUNaLE1BQWMsRUFDZCxNQUFjO0VBRWQsSUFBSSxDQUFDLFFBQVE7SUFDWCxNQUFNLElBQUksTUFBTTtFQUNsQjtFQUVBLE1BQU0sV0FBVyxNQUFNLE1BQU0sQ0FBQyxFQUFFLE9BQU8sU0FBUyxDQUFDLEVBQUU7SUFDakQsUUFBUTtJQUNSLFNBQVM7TUFDUCxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO01BQ25DLGdCQUFnQjtJQUNsQjtJQUNBLE1BQU0sS0FBSyxTQUFTLENBQUM7TUFDbkIsTUFBTTtNQUNOLE9BQU8sT0FBTyxLQUFLO01BQ25CLFFBQVEsT0FBTyxXQUFXO01BQzFCLE1BQU07TUFDTixVQUFVO1FBQ1IsWUFBWSxPQUFPLFVBQVU7UUFDN0IsVUFBVSxPQUFPLFFBQVE7TUFDM0I7SUFDRjtFQUNGO0VBRUEsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO0lBQ2hCLE1BQU0sUUFBUSxNQUFNLFNBQVMsSUFBSTtJQUNqQyxNQUFNLElBQUksTUFBTSxDQUFDLGlCQUFpQixFQUFFLE1BQU0sQ0FBQztFQUM3QztFQUVBLE1BQU0sU0FBUyxNQUFNLFNBQVMsSUFBSTtFQUNsQyxPQUFPO0lBQ0wsV0FBVyxPQUFPLFVBQVUsSUFBSSxPQUFPLEVBQUU7SUFDekMsZ0JBQWdCLE9BQU8sZUFBZTtFQUN4QztBQUNGO0FBRUEsc0JBQXNCO0FBQ3RCLGVBQWUsYUFDYixNQUFXLEVBQ1gsSUFBWSxFQUNaLE1BQWMsRUFDZCxNQUFjO0VBRWQsSUFBSSxDQUFDLFFBQVE7SUFDWCxNQUFNLElBQUksTUFBTTtFQUNsQjtFQUVBLE1BQU0sV0FBVyxNQUFNLE1BQU0sQ0FBQyxFQUFFLE9BQU8sU0FBUyxDQUFDLEVBQUU7SUFDakQsUUFBUTtJQUNSLFNBQVM7TUFDUCxhQUFhO01BQ2IsZ0JBQWdCO0lBQ2xCO0lBQ0EsTUFBTSxLQUFLLFNBQVMsQ0FBQztNQUNuQixXQUFXO01BQ1gsT0FBTyxPQUFPLEtBQUs7TUFDbkIsVUFBVTtRQUFDO1VBQUUsTUFBTTtVQUFVLE1BQU0sT0FBTyxXQUFXO1FBQUM7T0FBRTtNQUN4RCxjQUFjO0lBQ2hCO0VBQ0Y7RUFFQSxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7SUFDaEIsTUFBTSxRQUFRLE1BQU0sU0FBUyxJQUFJO0lBQ2pDLE1BQU0sSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDO0VBQzVDO0VBRUEsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0VBQ2xDLE9BQU87SUFDTCxXQUFXLE9BQU8sZUFBZSxJQUFJLE9BQU8sRUFBRTtJQUM5QyxnQkFBZ0IsT0FBTyxlQUFlO0VBQ3hDO0FBQ0Y7QUFFQSx3Q0FBd0M7QUFDeEMsZUFBZSwwQkFDYixRQUFhLEVBQ2IsTUFBVyxFQUNYLElBQVksRUFDWixTQUFpQixFQUNqQixVQUFrQjtFQUVsQixNQUFNLGdCQUFnQixJQUFJLE9BQU8sY0FBYyxDQUFDLFNBQVM7SUFDdkQsS0FBSztJQUNMLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFFBQVE7SUFDUixRQUFRO0VBQ1Y7RUFFQSxNQUFNLGNBQWMsQ0FBQzs7Ozs7MkNBS29CLEVBQUUsT0FBTyxLQUFLLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyQkFvRi9CLEVBQUUsT0FBTyxLQUFLLENBQUM7Ozs7MkJBSWYsRUFBRSxjQUFjLFlBQVk7Ozs7Z0NBSXZCLEVBQUUsS0FBSzs7OzsyQkFJWixFQUFFLFVBQVU7Ozs7MkJBSVosRUFBRSxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7T0FlcEMsQ0FBQztFQUVOLE1BQU0sV0FBVyxDQUFDLG1CQUFtQixFQUFFLFVBQVUsS0FBSyxDQUFDO0VBQ3ZELE1BQU0sWUFBWSxJQUFJLGNBQWMsTUFBTSxDQUFDO0VBQzNDLE1BQU0sT0FBTyxJQUFJLEtBQUs7SUFBQztHQUFVLEVBQUU7SUFBRSxNQUFNO0VBQTBCO0VBRXJFLE1BQU0sRUFBRSxPQUFPLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FBUyxPQUFPLENBQ2xELElBQUksQ0FBQyxnQkFDTCxNQUFNLENBQUMsVUFBVSxNQUFNO0lBQ3RCLGFBQWE7SUFDYixjQUFjO0lBQ2QsUUFBUTtFQUNWO0VBRUYsSUFBSSxhQUFhO0lBQ2YsUUFBUSxLQUFLLENBQUMsZ0NBQWdDO0lBQzlDLE1BQU0sSUFBSSxNQUFNO0VBQ2xCO0VBRUEsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsU0FBUyxPQUFPLENBQ3ZDLElBQUksQ0FBQyxnQkFDTCxZQUFZLENBQUM7RUFFaEIsT0FBTyxRQUFRLFNBQVM7QUFDMUI7QUFFQSxNQUFNLE9BQU87RUFDWCxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLGNBQWMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0scUJBQXFCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN4QyxNQUFNLFdBQVcsYUFBYSxhQUFhO0lBRTNDLDRCQUE0QjtJQUM1QixNQUFNLGFBQWEsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ25DLElBQUksQ0FBQyxZQUFZO01BQ2YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQXdCLElBQ2hEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLE1BQU0sUUFBUSxXQUFXLE9BQU8sQ0FBQyxXQUFXO0lBQzVDLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxNQUFNLFNBQVMsSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUV6RSxJQUFJLGFBQWEsQ0FBQyxNQUFNO01BQ3RCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUE2QixJQUNyRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsR0FBRyxNQUFNLElBQUksSUFBSTtJQUN2RCxRQUFRLEdBQUcsQ0FBQyxDQUFDLDJCQUEyQixFQUFFLFNBQVMsVUFBVSxFQUFFLE9BQU8sQ0FBQztJQUV2RSxrQkFBa0I7SUFDbEIsTUFBTSxFQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxTQUNoRCxJQUFJLENBQUMsZ0JBQ0wsTUFBTSxDQUFDLEtBQ1AsRUFBRSxDQUFDLE1BQU0sVUFDVCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtJQUVULElBQUksZUFBZSxDQUFDLFFBQVE7TUFDMUIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWtDLElBQzFEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLDZCQUE2QjtJQUM3QixNQUFNLEVBQUUsTUFBTSxlQUFlLEVBQUUsR0FBRyxNQUFNLFNBQ3JDLElBQUksQ0FBQyxtQkFDTCxNQUFNLENBQUMsY0FDUCxFQUFFLENBQUMsYUFBYSxVQUNoQixFQUFFLENBQUMsVUFBVSxhQUNiLE1BQU07SUFFVCxJQUFJLGlCQUFpQjtNQUNuQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBd0IsSUFDaEQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsb0JBQW9CO0lBQ3BCLE1BQU0sRUFBRSxNQUFNLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FDbEMsSUFBSSxDQUFDLGdCQUNMLE1BQU0sQ0FBQyxTQUNQLEVBQUUsQ0FBQyxPQUFPLHdCQUNWLE1BQU07SUFFVCxNQUFNLGVBQWUsU0FBUyxjQUFjLFNBQVMsTUFBTTtJQUUzRCxxQkFBcUI7SUFDckIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxTQUM3QixJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtJQUVULElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxPQUFPLElBQUksQ0FBQyxJQUFJLGNBQWM7TUFDckQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPLENBQUMsaUNBQWlDLEVBQUUsYUFBYSxFQUFFLENBQUM7TUFBQyxJQUM3RTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxvQ0FBb0M7SUFDcEMsTUFBTSxjQUFjLE1BQU0sYUFBYSxPQUFPLE9BQU8sR0FBRyxPQUFPLEtBQUssR0FBRyxJQUFJLE9BQU8sV0FBVztJQUM3RixNQUFNLGdCQUFnQixNQUFNLGFBQWEsY0FBYyxLQUFLLEdBQUcsR0FBRyxRQUFRO0lBRTFFLElBQUksYUFBNEI7SUFDaEMsSUFBSSxpQkFBZ0M7SUFFcEMsMEJBQTBCO0lBQzFCLElBQUksV0FBVyxjQUFjO01BQzNCLGFBQWEsTUFBTSx1QkFBdUI7SUFDNUMsT0FBTyxJQUFJLFdBQVcsUUFBUTtNQUM1QixNQUFNLGFBQWEsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO01BQ2hDLE1BQU0sYUFBYSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CO01BRW5ELElBQUksQ0FBQyxZQUFZO1FBQ2YsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7VUFBRSxPQUFPO1FBQW1DLElBQzNEO1VBQUUsUUFBUTtVQUFLLFNBQVM7WUFBRSxHQUFHLFdBQVc7WUFBRSxnQkFBZ0I7VUFBbUI7UUFBRTtNQUVuRjtNQUVBLE1BQU0sU0FBUyxNQUFNLGFBQ25CO1FBQUUsR0FBRyxNQUFNO1FBQUUsYUFBYTtNQUFXLEdBQ3JDLGFBQ0EsWUFDQTtNQUVGLGFBQWEsT0FBTyxTQUFTO01BQzdCLGlCQUFpQixPQUFPLGNBQWMsSUFBSTtJQUM1QyxPQUFPLElBQUksV0FBVyxRQUFRO01BQzVCLE1BQU0sYUFBYSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7TUFDaEMsTUFBTSxhQUFhLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUI7TUFFbkQsSUFBSSxDQUFDLFlBQVk7UUFDZixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztVQUFFLE9BQU87UUFBa0MsSUFDMUQ7VUFBRSxRQUFRO1VBQUssU0FBUztZQUFFLEdBQUcsV0FBVztZQUFFLGdCQUFnQjtVQUFtQjtRQUFFO01BRW5GO01BRUEsTUFBTSxTQUFTLE1BQU0sYUFDbkI7UUFBRSxHQUFHLE1BQU07UUFBRSxhQUFhO01BQVcsR0FDckMsYUFDQSxZQUNBO01BRUYsYUFBYSxPQUFPLFNBQVM7TUFDN0IsaUJBQWlCLE9BQU8sY0FBYyxJQUFJO0lBQzVDO0lBRUEsK0JBQStCO0lBQy9CLE1BQU0sWUFBWSxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUcsR0FBRyxDQUFDLEVBQUUsS0FBSyxNQUFNLEdBQUcsUUFBUSxDQUFDLElBQUksTUFBTSxDQUFDLEdBQUcsR0FBRyxXQUFXLEdBQUcsQ0FBQztJQUU5RiwrQ0FBK0M7SUFDL0MsSUFBSSxXQUFXLGNBQWMsQ0FBQyxnQkFBZ0I7TUFDNUMsaUJBQWlCLE1BQU0sMEJBQ3JCLFVBQ0EsUUFDQSxhQUNBLFdBQ0EsY0FBYztJQUVsQjtJQUVBLGlCQUFpQjtJQUNqQixNQUFNLFNBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO01BQUUsU0FBUyxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSTtJQUFhLEdBQ3hELEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRTtJQUV4Qix3QkFBd0I7SUFDeEIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLE9BQU8sWUFBWSxFQUFFLEdBQUcsTUFBTSxTQUNsRCxJQUFJLENBQUMsbUJBQ0wsTUFBTSxDQUFDO01BQ04sV0FBVztNQUNYLFNBQVMsS0FBSyxFQUFFO01BQ2hCO01BQ0EsUUFBUTtNQUNSLGNBQWM7TUFDZCxnQkFBZ0I7TUFDaEIsYUFBYSxjQUFjO01BQzNCLGlCQUFpQjtNQUNqQixhQUFhO01BQ2IsV0FBVztNQUNYLGNBQWMsSUFBSSxPQUFPLFdBQVc7SUFDdEMsR0FDQyxNQUFNLEdBQ04sTUFBTTtJQUVULElBQUksY0FBYztNQUNoQixRQUFRLEtBQUssQ0FBQywyQkFBMkI7TUFDekMsa0JBQWtCO01BQ2xCLE1BQU0sU0FDSCxJQUFJLENBQUMsWUFDTCxNQUFNLENBQUM7UUFBRSxTQUFTLFFBQVEsT0FBTztNQUFDLEdBQ2xDLEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRTtNQUN4QixNQUFNO0lBQ1I7SUFFQSxzQkFBc0I7SUFDdEIsTUFBTSxTQUFTLElBQUksQ0FBQyxpQkFBaUIsTUFBTSxDQUFDO01BQzFDLFNBQVMsS0FBSyxFQUFFO01BQ2hCLE1BQU07TUFDTixPQUFPO01BQ1AsU0FBUyxDQUFDLFdBQVcsRUFBRSxPQUFPLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztNQUMxRCxhQUFhO01BQ2IsV0FBVztJQUNiO0lBRUEsUUFBUSxHQUFHLENBQUMsQ0FBQywwQkFBMEIsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBRXJELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQ2IsU0FBUztNQUNUO01BQ0E7SUFDRixJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFnQjtJQUN2QixRQUFRLEtBQUssQ0FBQyx5QkFBeUI7SUFDdkMsTUFBTSxVQUFVLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxHQUFHO0lBQ3pELE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO01BQUUsT0FBTztJQUFRLElBQ2hDO01BQUUsUUFBUTtNQUFLLFNBQVM7UUFBRSxHQUFHLFdBQVc7UUFBRSxnQkFBZ0I7TUFBbUI7SUFBRTtFQUVuRjtBQUNGIn0=
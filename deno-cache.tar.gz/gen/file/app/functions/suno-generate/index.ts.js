import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
const SUNO_API_KEY = Deno.env.get("SUNO_API_KEY");
const SUNO_API_BASE = "https://apibox.erweima.ai";
// Human-readable error messages for Suno error codes (Russian)
// Official Suno API error codes:
// 400 - Invalid Parameters, 401 - Unauthorized, 403 - Forbidden (moderation)
// 404 - Not Found, 405 - Rate Limited, 413 - Content Too Large
// 429 - Insufficient Credits, 455 - Maintenance, 500/503 - Server errors
function getSunoErrorMessage(code, originalMessage) {
  // First, check for specific error message patterns (more accurate than code)
  if (originalMessage) {
    const lowerMsg = originalMessage.toLowerCase();
    if (lowerMsg.includes("matches existing work") || lowerMsg.includes("existing work of art") || lowerMsg.includes("copyright") || lowerMsg.includes("protected content")) {
      return {
        short: "Контент защищён авторским правом",
        full: "Загруженный аудиофайл или текст распознан как существующее произведение. Попробуйте использовать оригинальный контент."
      };
    }
    if (lowerMsg.includes("moderation") || lowerMsg.includes("sensitive") || lowerMsg.includes("inappropriate") || lowerMsg.includes("prohibited")) {
      return {
        short: "Контент не прошёл модерацию",
        full: "Текст или описание содержит запрещённые слова. Измените содержимое и попробуйте снова."
      };
    }
    if (lowerMsg.includes("too long") || lowerMsg.includes("too large") || lowerMsg.includes("exceeds")) {
      return {
        short: "Превышен лимит символов",
        full: "Описание, стиль или текст песни слишком длинные. Сократите текст и попробуйте снова."
      };
    }
    if (lowerMsg.includes("credit") || lowerMsg.includes("balance") || lowerMsg.includes("insufficient")) {
      return {
        short: "Недостаточно кредитов Suno",
        full: "На аккаунте Suno недостаточно кредитов для генерации. Обратитесь в поддержку."
      };
    }
  }
  const errorMessages = {
    400: {
      short: "Неверные параметры запроса",
      full: "Проверьте введённые данные и попробуйте снова."
    },
    401: {
      short: "Ошибка авторизации",
      full: "Проблема с авторизацией в сервисе Suno. Обратитесь в поддержку."
    },
    403: {
      short: "Контент заблокирован",
      full: "Запрос содержит запрещённый контент. Измените текст или описание."
    },
    404: {
      short: "Ресурс не найден",
      full: "Запрашиваемый ресурс не найден. Попробуйте ещё раз."
    },
    405: {
      short: "Превышена частота запросов",
      full: "Слишком много запросов. Подождите несколько минут."
    },
    413: {
      short: "Превышен лимит символов",
      full: "Текст слишком длинный (макс. ~3000 символов для lyrics). Сократите и попробуйте снова."
    },
    429: {
      short: "Недостаточно кредитов",
      full: "На аккаунте Suno недостаточно кредитов. Обратитесь в поддержку."
    },
    455: {
      short: "Сервис на обслуживании",
      full: "Suno проходит техническое обслуживание. Попробуйте позже."
    },
    500: {
      short: "Ошибка сервера Suno",
      full: "Внутренняя ошибка на сервере Suno. Попробуйте позже."
    },
    503: {
      short: "Сервис недоступен",
      full: "Suno временно перегружен. Попробуйте позже."
    }
  };
  if (errorMessages[code]) {
    return errorMessages[code];
  }
  return {
    short: `Ошибка генерации (код ${code})`,
    full: originalMessage || `Произошла ошибка при генерации. Код: ${code}`
  };
}
// Map artist names to genre/style descriptions (Suno doesn't allow artist names)
const artistToStyleMap = {
  "Drake": "moody trap hip-hop with melodic hooks",
  "The Weeknd": "dark synth-pop R&B with falsetto vocals",
  "Taylor Swift": "catchy pop-country with storytelling lyrics",
  "Ed Sheeran": "acoustic pop folk with romantic themes",
  "Billie Eilish": "dark minimalist pop with whispered vocals",
  "Ariana Grande": "powerful pop R&B with high vocals",
  "Dua Lipa": "disco-influenced dance pop",
  "Bad Bunny": "reggaeton latin trap with urban beats",
  "Post Malone": "melodic hip-hop rock fusion",
  "Kendrick Lamar": "conscious lyrical hip-hop",
  "Beyoncé": "powerful R&B pop with soulful vocals",
  "BTS": "K-pop with dynamic choreography vibes",
  "Harry Styles": "70s inspired soft rock pop",
  "Doja Cat": "playful rap-pop with catchy hooks",
  "SZA": "neo-soul R&B with vulnerable lyrics",
  "Travis Scott": "atmospheric auto-tune trap",
  "Olivia Rodrigo": "emotional pop-rock with teen angst",
  "Lana Del Rey": "cinematic dreamy baroque pop",
  "Kanye West": "experimental hip-hop with gospel influences",
  "Bruno Mars": "funk pop with retro grooves",
  "Adele": "powerful ballads with soulful vocals",
  "Rihanna": "dancehall-influenced pop R&B",
  "Justin Bieber": "pop R&B with tropical influences",
  "Lady Gaga": "theatrical electro-pop",
  "Shakira": "latin pop with world music fusion",
  "Coldplay": "anthemic alternative rock with atmospheric synths",
  "Imagine Dragons": "arena rock with electronic elements",
  "Twenty One Pilots": "alternative hip-hop with electronic elements",
  "Maroon 5": "pop rock with funky grooves",
  "OneRepublic": "orchestral pop rock with uplifting themes"
};
// Convert artist name to safe style description
function convertArtistToStyle(artistName) {
  if (artistToStyleMap[artistName]) {
    return artistToStyleMap[artistName];
  }
  const lowerName = artistName.toLowerCase();
  for (const [artist, style] of Object.entries(artistToStyleMap)){
    if (artist.toLowerCase() === lowerName) {
      return style;
    }
  }
  return "contemporary pop with modern production";
}
// Clean style string to remove artist names
function cleanStyleForSuno(style) {
  if (!style) return "";
  let cleanedStyle = style;
  for (const artistName of Object.keys(artistToStyleMap)){
    const regex = new RegExp(`${artistName}\\s*style`, "gi");
    if (regex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(regex, convertArtistToStyle(artistName));
    }
    const standaloneRegex = new RegExp(`\\b${artistName}\\b`, "gi");
    if (standaloneRegex.test(cleanedStyle)) {
      cleanedStyle = cleanedStyle.replace(standaloneRegex, convertArtistToStyle(artistName));
    }
  }
  cleanedStyle = cleanedStyle.replace(/,\s*,/g, ",").replace(/\s+/g, " ").trim();
  return cleanedStyle;
}
serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({
        error: "No authorization header"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: authHeader
        }
      }
    });
    // Also create admin client for creating notifications
    const supabaseAdmin = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // P0 FIX: Check if user is blocked before allowing generation
    const { data: isBlocked } = await supabaseAdmin.rpc("is_user_blocked", {
      p_user_id: user.id
    });
    if (isBlocked) {
      return new Response(JSON.stringify({
        error: "Ваш аккаунт заблокирован. Генерация недоступна."
      }), {
        status: 403,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const { trackId, prompt, lyrics, style, title, instrumental, audioReferenceUrl } = await req.json();
    if (!trackId || !prompt) {
      return new Response(JSON.stringify({
        error: "Missing required fields: trackId, prompt"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    console.log(`Starting generation for track ${trackId} by user ${user.id}`);
    console.log(`Original prompt: ${prompt}`);
    console.log(`Original style: ${style}`);
    console.log(`Instrumental: ${instrumental}`);
    console.log(`Audio reference URL: ${audioReferenceUrl || 'none'}`);
    // Clean the style to remove artist names
    const cleanedStyle = cleanStyleForSuno(style || "");
    console.log(`Cleaned style: ${cleanedStyle}`);
    // Update track status to processing
    const { error: updateError } = await supabaseClient.from("tracks").update({
      status: "processing",
      error_message: null
    }).eq("id", trackId).eq("user_id", user.id);
    if (updateError) {
      console.error("Failed to update track status:", updateError);
    }
    // Build the Suno API payload according to documentation
    const hasLyrics = !!lyrics && lyrics.trim().length > 0;
    const hasStyle = !!cleanedStyle && cleanedStyle.trim().length > 0;
    const hasPrompt = !!prompt && prompt.trim().length > 0;
    const useCustomMode = hasLyrics || hasStyle;
    // Clean the prompt (description) as well
    const cleanedPrompt = cleanStyleForSuno(prompt || "");
    console.log(`Cleaned prompt (description): ${cleanedPrompt}`);
    // Build callback URL with secret for security
    // Use SUNO_CALLBACK_URL if set (should be public URL), otherwise fall back to SUPABASE_URL
    const callbackSecret = Deno.env.get("SUNO_CALLBACK_SECRET");
    const explicitCallbackUrl = Deno.env.get("SUNO_CALLBACK_URL");
    const baseCallbackUrl = explicitCallbackUrl || `${Deno.env.get("SUPABASE_URL")}/functions/v1/suno-callback`;
    const callBackUrl = callbackSecret ? `${baseCallbackUrl}${baseCallbackUrl.includes('?') ? '&' : '?'}secret=${encodeURIComponent(callbackSecret)}` : baseCallbackUrl;
    console.log(`Callback URL: ${callBackUrl}`);
    const sunoPayload = {
      model: "V4",
      customMode: useCustomMode,
      instrumental: instrumental || false,
      callBackUrl
    };
    if (useCustomMode) {
      // prompt field = lyrics (if present) or description
      sunoPayload.prompt = hasLyrics ? lyrics : prompt;
      // CRITICAL: style field should ONLY contain genre/vocal/style tags - NOT the description!
      // Suno has a strict 200 character limit on style field
      // Description goes in the prompt, not in style
      let finalStyle = cleanedStyle || "pop";
      // Truncate style to 200 chars max (Suno limit)
      if (finalStyle.length > 200) {
        // Keep the most important tags (first ones) and cut at comma boundary
        const parts = finalStyle.split(", ");
        let truncated = "";
        for (const part of parts){
          if ((truncated + ", " + part).length <= 200) {
            truncated = truncated ? truncated + ", " + part : part;
          } else {
            break;
          }
        }
        finalStyle = truncated || finalStyle.slice(0, 200);
        console.log(`Style truncated from ${cleanedStyle.length} to ${finalStyle.length} chars`);
      }
      sunoPayload.style = finalStyle;
      sunoPayload.title = title || "Untitled";
      console.log(`Final style for Suno (${sunoPayload.style.length} chars): ${sunoPayload.style}`);
    } else {
      sunoPayload.prompt = prompt.slice(0, 400);
    }
    // Determine which endpoint to use
    let sunoEndpoint = `${SUNO_API_BASE}/api/v1/generate`;
    // If audio reference is provided, use upload-cover endpoint instead
    if (audioReferenceUrl) {
      sunoEndpoint = `${SUNO_API_BASE}/api/v1/generate/upload-cover`;
      sunoPayload.uploadUrl = audioReferenceUrl;
      console.log("Using upload-cover endpoint with audio reference");
    }
    console.log("Sending to Suno API:", JSON.stringify(sunoPayload));
    console.log("Endpoint:", sunoEndpoint);
    const sunoResponse = await fetch(sunoEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUNO_API_KEY}`
      },
      body: JSON.stringify(sunoPayload)
    });
    const sunoData = await sunoResponse.json();
    console.log("Suno API response:", JSON.stringify(sunoData));
    if (!sunoResponse.ok || sunoData.code !== 200) {
      const rawErrorMessage = sunoData.msg || "Failed to start generation";
      const errorCode = sunoData.code || sunoResponse.status || 500;
      // Get human-readable Russian error message
      const errorInfo = getSunoErrorMessage(errorCode, rawErrorMessage);
      const russianErrorMessage = errorInfo.short;
      console.error(`Suno API error (${errorCode}): ${rawErrorMessage} -> ${russianErrorMessage}`);
      // Update track status to failed with Russian error message
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: russianErrorMessage
      }).eq("id", trackId).eq("user_id", user.id);
      // Get all tracks with this base title to find paired track
      const { data: allTracks } = await supabaseClient.from("tracks").select("id").eq("user_id", user.id).in("status", [
        "pending",
        "processing"
      ]);
      const trackIds = allTracks?.map((t)=>t.id) || [
        trackId
      ];
      // Refund: update generation_logs to failed and return balance
      const { data: logs } = await supabaseClient.from("generation_logs").select("id, cost_rub").in("track_id", trackIds).eq("user_id", user.id).eq("status", "pending");
      let totalRefund = 0;
      if (logs && logs.length > 0) {
        totalRefund = logs.reduce((sum, log)=>sum + (log.cost_rub || 0), 0);
        // Mark logs as failed
        await supabaseClient.from("generation_logs").update({
          status: "failed"
        }).in("id", logs.map((l)=>l.id));
        // Refund the balance
        if (totalRefund > 0) {
          const { data: profile } = await supabaseClient.from("profiles").select("balance").eq("user_id", user.id).single();
          if (profile) {
            const newBalance = (profile.balance || 0) + totalRefund;
            await supabaseClient.from("profiles").update({
              balance: newBalance
            }).eq("user_id", user.id);
            // Log refund transaction
            await supabaseClient.from("balance_transactions").insert({
              user_id: user.id,
              amount: totalRefund,
              balance_after: newBalance,
              type: "refund",
              description: `Возврат за неудачную генерацию`,
              reference_id: trackId,
              reference_type: "track",
              metadata: {
                error: russianErrorMessage
              }
            });
            console.log(`Refunded ${totalRefund} to user ${user.id}`);
          }
        }
      }
      // Also mark other pending tracks as failed
      await supabaseClient.from("tracks").update({
        status: "failed",
        error_message: russianErrorMessage
      }).eq("user_id", user.id).in("status", [
        "pending",
        "processing"
      ]);
      // Create notification for refund with Russian error explanation
      if (totalRefund > 0) {
        await supabaseAdmin.from("notifications").insert({
          user_id: user.id,
          type: "refund",
          title: `Ошибка: ${russianErrorMessage}`,
          message: `${errorInfo.full}\n\nВам возвращено ${totalRefund} ₽`,
          target_type: "track",
          target_id: trackId
        });
      }
      return new Response(JSON.stringify({
        error: russianErrorMessage,
        details: errorInfo.full,
        refunded: totalRefund > 0,
        refundAmount: totalRefund
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const taskId = sunoData.data?.taskId;
    console.log(`Generation started with task ID: ${taskId}`);
    // CRITICAL: Store task_id in description for ONLY the current track pair (v1 and v2)
    // This is essential for the callback to match results to the correct tracks
    // DO NOT update other pending tracks - they have their own task_id from their own generation!
    if (taskId) {
      // Get the current track's info including created_at to find its pair
      const { data: currentTrack } = await supabaseClient.from("tracks").select("id, title, description, created_at").eq("id", trackId).single();
      if (currentTrack) {
        // Find the paired track: same base title, same user, created within 5 seconds
        const baseTitle = (currentTrack.title || "").replace(/\s*\(v\d+\)$/, "").trim();
        const createdAt = new Date(currentTrack.created_at);
        const windowStart = new Date(createdAt.getTime() - 5000).toISOString();
        const windowEnd = new Date(createdAt.getTime() + 5000).toISOString();
        const { data: pairedTracks } = await supabaseClient.from("tracks").select("id, title, description, created_at").eq("user_id", user.id).gte("created_at", windowStart).lte("created_at", windowEnd);
        const filtered = pairedTracks?.filter((t)=>{
          const tBaseTitle = (t.title || "").replace(/\s*\(v\d+\)$/, "").trim();
          return tBaseTitle === baseTitle;
        }) || [];
        // CRITICAL FIX: empty array is truthy, so check .length explicitly
        const tracksToUpdate = filtered.length > 0 ? filtered : [
          currentTrack
        ];
        console.log(`Found ${tracksToUpdate.length} tracks in pair to update with task_id (filtered: ${filtered.length}, paired: ${pairedTracks?.length || 0})`);
        for (const track of tracksToUpdate){
          // IMPORTANT: Only update if this track doesn't already have a task_id
          // This prevents overwriting task_id from a different generation
          if (track.description?.includes("[task_id:")) {
            console.log(`Track ${track.id} (${track.title}) already has task_id, skipping to prevent overwrite`);
            continue;
          }
          // Append task_id to description (preserve existing content)
          const existingDesc = track.description || "";
          const newDesc = existingDesc ? `${existingDesc}\n\n[task_id: ${taskId}]` : `[task_id: ${taskId}]`;
          await supabaseClient.from("tracks").update({
            description: newDesc
          }).eq("id", track.id);
          console.log(`Stored task_id ${taskId} in track ${track.id} (${track.title})`);
        }
      } else {
        // Fallback: at least update the current track
        const newDesc = `[task_id: ${taskId}]`;
        await supabaseClient.from("tracks").update({
          description: newDesc
        }).eq("id", trackId);
        console.log(`Stored task_id ${taskId} in track ${trackId} (fallback)`);
      }
    }
    return new Response(JSON.stringify({
      success: true,
      taskId,
      message: "Generation started successfully"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error in suno-generate:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({
      error: "Произошла непредвиденная ошибка. Попробуйте позже."
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy9zdW5vLWdlbmVyYXRlL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNlcnZlIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE2OC4wL2h0dHAvc2VydmVyLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9lc20uc2gvQHN1cGFiYXNlL3N1cGFiYXNlLWpzQDJcIjtcblxuY29uc3QgY29yc0hlYWRlcnMgPSB7XG4gIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiKlwiLFxuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIjogXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuY29uc3QgU1VOT19BUElfS0VZID0gRGVuby5lbnYuZ2V0KFwiU1VOT19BUElfS0VZXCIpO1xuY29uc3QgU1VOT19BUElfQkFTRSA9IFwiaHR0cHM6Ly9hcGlib3guZXJ3ZWltYS5haVwiO1xuXG4vLyBIdW1hbi1yZWFkYWJsZSBlcnJvciBtZXNzYWdlcyBmb3IgU3VubyBlcnJvciBjb2RlcyAoUnVzc2lhbilcbi8vIE9mZmljaWFsIFN1bm8gQVBJIGVycm9yIGNvZGVzOlxuLy8gNDAwIC0gSW52YWxpZCBQYXJhbWV0ZXJzLCA0MDEgLSBVbmF1dGhvcml6ZWQsIDQwMyAtIEZvcmJpZGRlbiAobW9kZXJhdGlvbilcbi8vIDQwNCAtIE5vdCBGb3VuZCwgNDA1IC0gUmF0ZSBMaW1pdGVkLCA0MTMgLSBDb250ZW50IFRvbyBMYXJnZVxuLy8gNDI5IC0gSW5zdWZmaWNpZW50IENyZWRpdHMsIDQ1NSAtIE1haW50ZW5hbmNlLCA1MDAvNTAzIC0gU2VydmVyIGVycm9yc1xuZnVuY3Rpb24gZ2V0U3Vub0Vycm9yTWVzc2FnZShjb2RlOiBudW1iZXIsIG9yaWdpbmFsTWVzc2FnZT86IHN0cmluZyk6IHsgc2hvcnQ6IHN0cmluZzsgZnVsbDogc3RyaW5nIH0ge1xuICAvLyBGaXJzdCwgY2hlY2sgZm9yIHNwZWNpZmljIGVycm9yIG1lc3NhZ2UgcGF0dGVybnMgKG1vcmUgYWNjdXJhdGUgdGhhbiBjb2RlKVxuICBpZiAob3JpZ2luYWxNZXNzYWdlKSB7XG4gICAgY29uc3QgbG93ZXJNc2cgPSBvcmlnaW5hbE1lc3NhZ2UudG9Mb3dlckNhc2UoKTtcbiAgICBcbiAgICBpZiAobG93ZXJNc2cuaW5jbHVkZXMoXCJtYXRjaGVzIGV4aXN0aW5nIHdvcmtcIikgfHwgXG4gICAgICAgIGxvd2VyTXNnLmluY2x1ZGVzKFwiZXhpc3Rpbmcgd29yayBvZiBhcnRcIikgfHxcbiAgICAgICAgbG93ZXJNc2cuaW5jbHVkZXMoXCJjb3B5cmlnaHRcIikgfHxcbiAgICAgICAgbG93ZXJNc2cuaW5jbHVkZXMoXCJwcm90ZWN0ZWQgY29udGVudFwiKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2hvcnQ6IFwi0JrQvtC90YLQtdC90YIg0LfQsNGJ0LjRidGR0L0g0LDQstGC0L7RgNGB0LrQuNC8INC/0YDQsNCy0L7QvFwiLFxuICAgICAgICBmdWxsOiBcItCX0LDQs9GA0YPQttC10L3QvdGL0Lkg0LDRg9C00LjQvtGE0LDQudC7INC40LvQuCDRgtC10LrRgdGCINGA0LDRgdC/0L7Qt9C90LDQvSDQutCw0Log0YHRg9GJ0LXRgdGC0LLRg9GO0YnQtdC1INC/0YDQvtC40LfQstC10LTQtdC90LjQtS4g0J/QvtC/0YDQvtCx0YPQudGC0LUg0LjRgdC/0L7Qu9GM0LfQvtCy0LDRgtGMINC+0YDQuNCz0LjQvdCw0LvRjNC90YvQuSDQutC+0L3RgtC10L3Rgi5cIlxuICAgICAgfTtcbiAgICB9XG4gICAgXG4gICAgaWYgKGxvd2VyTXNnLmluY2x1ZGVzKFwibW9kZXJhdGlvblwiKSB8fCBcbiAgICAgICAgbG93ZXJNc2cuaW5jbHVkZXMoXCJzZW5zaXRpdmVcIikgfHwgXG4gICAgICAgIGxvd2VyTXNnLmluY2x1ZGVzKFwiaW5hcHByb3ByaWF0ZVwiKSB8fFxuICAgICAgICBsb3dlck1zZy5pbmNsdWRlcyhcInByb2hpYml0ZWRcIikpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHNob3J0OiBcItCa0L7QvdGC0LXQvdGCINC90LUg0L/RgNC+0YjRkdC7INC80L7QtNC10YDQsNGG0LjRjlwiLFxuICAgICAgICBmdWxsOiBcItCi0LXQutGB0YIg0LjQu9C4INC+0L/QuNGB0LDQvdC40LUg0YHQvtC00LXRgNC20LjRgiDQt9Cw0L/RgNC10YnRkdC90L3Ri9C1INGB0LvQvtCy0LAuINCY0LfQvNC10L3QuNGC0LUg0YHQvtC00LXRgNC20LjQvNC+0LUg0Lgg0L/QvtC/0YDQvtCx0YPQudGC0LUg0YHQvdC+0LLQsC5cIlxuICAgICAgfTtcbiAgICB9XG4gICAgXG4gICAgaWYgKGxvd2VyTXNnLmluY2x1ZGVzKFwidG9vIGxvbmdcIikgfHwgbG93ZXJNc2cuaW5jbHVkZXMoXCJ0b28gbGFyZ2VcIikgfHwgbG93ZXJNc2cuaW5jbHVkZXMoXCJleGNlZWRzXCIpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzaG9ydDogXCLQn9GA0LXQstGL0YjQtdC9INC70LjQvNC40YIg0YHQuNC80LLQvtC70L7QslwiLFxuICAgICAgICBmdWxsOiBcItCe0L/QuNGB0LDQvdC40LUsINGB0YLQuNC70Ywg0LjQu9C4INGC0LXQutGB0YIg0L/QtdGB0L3QuCDRgdC70LjRiNC60L7QvCDQtNC70LjQvdC90YvQtS4g0KHQvtC60YDQsNGC0LjRgtC1INGC0LXQutGB0YIg0Lgg0L/QvtC/0YDQvtCx0YPQudGC0LUg0YHQvdC+0LLQsC5cIlxuICAgICAgfTtcbiAgICB9XG4gICAgXG4gICAgaWYgKGxvd2VyTXNnLmluY2x1ZGVzKFwiY3JlZGl0XCIpIHx8IGxvd2VyTXNnLmluY2x1ZGVzKFwiYmFsYW5jZVwiKSB8fCBsb3dlck1zZy5pbmNsdWRlcyhcImluc3VmZmljaWVudFwiKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2hvcnQ6IFwi0J3QtdC00L7RgdGC0LDRgtC+0YfQvdC+INC60YDQtdC00LjRgtC+0LIgU3Vub1wiLFxuICAgICAgICBmdWxsOiBcItCd0LAg0LDQutC60LDRg9C90YLQtSBTdW5vINC90LXQtNC+0YHRgtCw0YLQvtGH0L3QviDQutGA0LXQtNC40YLQvtCyINC00LvRjyDQs9C10L3QtdGA0LDRhtC40LguINCe0LHRgNCw0YLQuNGC0LXRgdGMINCyINC/0L7QtNC00LXRgNC20LrRgy5cIlxuICAgICAgfTtcbiAgICB9XG4gIH1cblxuICBjb25zdCBlcnJvck1lc3NhZ2VzOiBSZWNvcmQ8bnVtYmVyLCB7IHNob3J0OiBzdHJpbmc7IGZ1bGw6IHN0cmluZyB9PiA9IHtcbiAgICA0MDA6IHsgc2hvcnQ6IFwi0J3QtdCy0LXRgNC90YvQtSDQv9Cw0YDQsNC80LXRgtGA0Ysg0LfQsNC/0YDQvtGB0LBcIiwgZnVsbDogXCLQn9GA0L7QstC10YDRjNGC0LUg0LLQstC10LTRkdC90L3Ri9C1INC00LDQvdC90YvQtSDQuCDQv9C+0L/RgNC+0LHRg9C50YLQtSDRgdC90L7QstCwLlwiIH0sXG4gICAgNDAxOiB7IHNob3J0OiBcItCe0YjQuNCx0LrQsCDQsNCy0YLQvtGA0LjQt9Cw0YbQuNC4XCIsIGZ1bGw6IFwi0J/RgNC+0LHQu9C10LzQsCDRgSDQsNCy0YLQvtGA0LjQt9Cw0YbQuNC10Lkg0LIg0YHQtdGA0LLQuNGB0LUgU3Vuby4g0J7QsdGA0LDRgtC40YLQtdGB0Ywg0LIg0L/QvtC00LTQtdGA0LbQutGDLlwiIH0sXG4gICAgNDAzOiB7IHNob3J0OiBcItCa0L7QvdGC0LXQvdGCINC30LDQsdC70L7QutC40YDQvtCy0LDQvVwiLCBmdWxsOiBcItCX0LDQv9GA0L7RgSDRgdC+0LTQtdGA0LbQuNGCINC30LDQv9GA0LXRidGR0L3QvdGL0Lkg0LrQvtC90YLQtdC90YIuINCY0LfQvNC10L3QuNGC0LUg0YLQtdC60YHRgiDQuNC70Lgg0L7Qv9C40YHQsNC90LjQtS5cIiB9LFxuICAgIDQwNDogeyBzaG9ydDogXCLQoNC10YHRg9GA0YEg0L3QtSDQvdCw0LnQtNC10L1cIiwgZnVsbDogXCLQl9Cw0L/RgNCw0YjQuNCy0LDQtdC80YvQuSDRgNC10YHRg9GA0YEg0L3QtSDQvdCw0LnQtNC10L0uINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC10YnRkSDRgNCw0LcuXCIgfSxcbiAgICA0MDU6IHsgc2hvcnQ6IFwi0J/RgNC10LLRi9GI0LXQvdCwINGH0LDRgdGC0L7RgtCwINC30LDQv9GA0L7RgdC+0LJcIiwgZnVsbDogXCLQodC70LjRiNC60L7QvCDQvNC90L7Qs9C+INC30LDQv9GA0L7RgdC+0LIuINCf0L7QtNC+0LbQtNC40YLQtSDQvdC10YHQutC+0LvRjNC60L4g0LzQuNC90YPRgi5cIiB9LFxuICAgIDQxMzogeyBzaG9ydDogXCLQn9GA0LXQstGL0YjQtdC9INC70LjQvNC40YIg0YHQuNC80LLQvtC70L7QslwiLCBmdWxsOiBcItCi0LXQutGB0YIg0YHQu9C40YjQutC+0Lwg0LTQu9C40L3QvdGL0LkgKNC80LDQutGBLiB+MzAwMCDRgdC40LzQstC+0LvQvtCyINC00LvRjyBseXJpY3MpLiDQodC+0LrRgNCw0YLQuNGC0LUg0Lgg0L/QvtC/0YDQvtCx0YPQudGC0LUg0YHQvdC+0LLQsC5cIiB9LFxuICAgIDQyOTogeyBzaG9ydDogXCLQndC10LTQvtGB0YLQsNGC0L7Rh9C90L4g0LrRgNC10LTQuNGC0L7QslwiLCBmdWxsOiBcItCd0LAg0LDQutC60LDRg9C90YLQtSBTdW5vINC90LXQtNC+0YHRgtCw0YLQvtGH0L3QviDQutGA0LXQtNC40YLQvtCyLiDQntCx0YDQsNGC0LjRgtC10YHRjCDQsiDQv9C+0LTQtNC10YDQttC60YMuXCIgfSxcbiAgICA0NTU6IHsgc2hvcnQ6IFwi0KHQtdGA0LLQuNGBINC90LAg0L7QsdGB0LvRg9C20LjQstCw0L3QuNC4XCIsIGZ1bGw6IFwiU3VubyDQv9GA0L7RhdC+0LTQuNGCINGC0LXRhdC90LjRh9C10YHQutC+0LUg0L7QsdGB0LvRg9C20LjQstCw0L3QuNC1LiDQn9C+0L/RgNC+0LHRg9C50YLQtSDQv9C+0LfQttC1LlwiIH0sXG4gICAgNTAwOiB7IHNob3J0OiBcItCe0YjQuNCx0LrQsCDRgdC10YDQstC10YDQsCBTdW5vXCIsIGZ1bGw6IFwi0JLQvdGD0YLRgNC10L3QvdGP0Y8g0L7RiNC40LHQutCwINC90LAg0YHQtdGA0LLQtdGA0LUgU3Vuby4g0J/QvtC/0YDQvtCx0YPQudGC0LUg0L/QvtC30LbQtS5cIiB9LFxuICAgIDUwMzogeyBzaG9ydDogXCLQodC10YDQstC40YEg0L3QtdC00L7RgdGC0YPQv9C10L1cIiwgZnVsbDogXCJTdW5vINCy0YDQtdC80LXQvdC90L4g0L/QtdGA0LXQs9GA0YPQttC10L0uINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC/0L7Qt9C20LUuXCIgfVxuICB9O1xuICBcbiAgaWYgKGVycm9yTWVzc2FnZXNbY29kZV0pIHtcbiAgICByZXR1cm4gZXJyb3JNZXNzYWdlc1tjb2RlXTtcbiAgfVxuICBcbiAgcmV0dXJuIHtcbiAgICBzaG9ydDogYNCe0YjQuNCx0LrQsCDQs9C10L3QtdGA0LDRhtC40LggKNC60L7QtCAke2NvZGV9KWAsXG4gICAgZnVsbDogb3JpZ2luYWxNZXNzYWdlIHx8IGDQn9GA0L7QuNC30L7RiNC70LAg0L7RiNC40LHQutCwINC/0YDQuCDQs9C10L3QtdGA0LDRhtC40LguINCa0L7QtDogJHtjb2RlfWBcbiAgfTtcbn1cblxuLy8gTWFwIGFydGlzdCBuYW1lcyB0byBnZW5yZS9zdHlsZSBkZXNjcmlwdGlvbnMgKFN1bm8gZG9lc24ndCBhbGxvdyBhcnRpc3QgbmFtZXMpXG5jb25zdCBhcnRpc3RUb1N0eWxlTWFwOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICBcIkRyYWtlXCI6IFwibW9vZHkgdHJhcCBoaXAtaG9wIHdpdGggbWVsb2RpYyBob29rc1wiLFxuICBcIlRoZSBXZWVrbmRcIjogXCJkYXJrIHN5bnRoLXBvcCBSJkIgd2l0aCBmYWxzZXR0byB2b2NhbHNcIixcbiAgXCJUYXlsb3IgU3dpZnRcIjogXCJjYXRjaHkgcG9wLWNvdW50cnkgd2l0aCBzdG9yeXRlbGxpbmcgbHlyaWNzXCIsXG4gIFwiRWQgU2hlZXJhblwiOiBcImFjb3VzdGljIHBvcCBmb2xrIHdpdGggcm9tYW50aWMgdGhlbWVzXCIsXG4gIFwiQmlsbGllIEVpbGlzaFwiOiBcImRhcmsgbWluaW1hbGlzdCBwb3Agd2l0aCB3aGlzcGVyZWQgdm9jYWxzXCIsXG4gIFwiQXJpYW5hIEdyYW5kZVwiOiBcInBvd2VyZnVsIHBvcCBSJkIgd2l0aCBoaWdoIHZvY2Fsc1wiLFxuICBcIkR1YSBMaXBhXCI6IFwiZGlzY28taW5mbHVlbmNlZCBkYW5jZSBwb3BcIixcbiAgXCJCYWQgQnVubnlcIjogXCJyZWdnYWV0b24gbGF0aW4gdHJhcCB3aXRoIHVyYmFuIGJlYXRzXCIsXG4gIFwiUG9zdCBNYWxvbmVcIjogXCJtZWxvZGljIGhpcC1ob3Agcm9jayBmdXNpb25cIixcbiAgXCJLZW5kcmljayBMYW1hclwiOiBcImNvbnNjaW91cyBseXJpY2FsIGhpcC1ob3BcIixcbiAgXCJCZXlvbmPDqVwiOiBcInBvd2VyZnVsIFImQiBwb3Agd2l0aCBzb3VsZnVsIHZvY2Fsc1wiLFxuICBcIkJUU1wiOiBcIkstcG9wIHdpdGggZHluYW1pYyBjaG9yZW9ncmFwaHkgdmliZXNcIixcbiAgXCJIYXJyeSBTdHlsZXNcIjogXCI3MHMgaW5zcGlyZWQgc29mdCByb2NrIHBvcFwiLFxuICBcIkRvamEgQ2F0XCI6IFwicGxheWZ1bCByYXAtcG9wIHdpdGggY2F0Y2h5IGhvb2tzXCIsXG4gIFwiU1pBXCI6IFwibmVvLXNvdWwgUiZCIHdpdGggdnVsbmVyYWJsZSBseXJpY3NcIixcbiAgXCJUcmF2aXMgU2NvdHRcIjogXCJhdG1vc3BoZXJpYyBhdXRvLXR1bmUgdHJhcFwiLFxuICBcIk9saXZpYSBSb2RyaWdvXCI6IFwiZW1vdGlvbmFsIHBvcC1yb2NrIHdpdGggdGVlbiBhbmdzdFwiLFxuICBcIkxhbmEgRGVsIFJleVwiOiBcImNpbmVtYXRpYyBkcmVhbXkgYmFyb3F1ZSBwb3BcIixcbiAgXCJLYW55ZSBXZXN0XCI6IFwiZXhwZXJpbWVudGFsIGhpcC1ob3Agd2l0aCBnb3NwZWwgaW5mbHVlbmNlc1wiLFxuICBcIkJydW5vIE1hcnNcIjogXCJmdW5rIHBvcCB3aXRoIHJldHJvIGdyb292ZXNcIixcbiAgXCJBZGVsZVwiOiBcInBvd2VyZnVsIGJhbGxhZHMgd2l0aCBzb3VsZnVsIHZvY2Fsc1wiLFxuICBcIlJpaGFubmFcIjogXCJkYW5jZWhhbGwtaW5mbHVlbmNlZCBwb3AgUiZCXCIsXG4gIFwiSnVzdGluIEJpZWJlclwiOiBcInBvcCBSJkIgd2l0aCB0cm9waWNhbCBpbmZsdWVuY2VzXCIsXG4gIFwiTGFkeSBHYWdhXCI6IFwidGhlYXRyaWNhbCBlbGVjdHJvLXBvcFwiLFxuICBcIlNoYWtpcmFcIjogXCJsYXRpbiBwb3Agd2l0aCB3b3JsZCBtdXNpYyBmdXNpb25cIixcbiAgXCJDb2xkcGxheVwiOiBcImFudGhlbWljIGFsdGVybmF0aXZlIHJvY2sgd2l0aCBhdG1vc3BoZXJpYyBzeW50aHNcIixcbiAgXCJJbWFnaW5lIERyYWdvbnNcIjogXCJhcmVuYSByb2NrIHdpdGggZWxlY3Ryb25pYyBlbGVtZW50c1wiLFxuICBcIlR3ZW50eSBPbmUgUGlsb3RzXCI6IFwiYWx0ZXJuYXRpdmUgaGlwLWhvcCB3aXRoIGVsZWN0cm9uaWMgZWxlbWVudHNcIixcbiAgXCJNYXJvb24gNVwiOiBcInBvcCByb2NrIHdpdGggZnVua3kgZ3Jvb3Zlc1wiLFxuICBcIk9uZVJlcHVibGljXCI6IFwib3JjaGVzdHJhbCBwb3Agcm9jayB3aXRoIHVwbGlmdGluZyB0aGVtZXNcIixcbn07XG5cbi8vIENvbnZlcnQgYXJ0aXN0IG5hbWUgdG8gc2FmZSBzdHlsZSBkZXNjcmlwdGlvblxuZnVuY3Rpb24gY29udmVydEFydGlzdFRvU3R5bGUoYXJ0aXN0TmFtZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgaWYgKGFydGlzdFRvU3R5bGVNYXBbYXJ0aXN0TmFtZV0pIHtcbiAgICByZXR1cm4gYXJ0aXN0VG9TdHlsZU1hcFthcnRpc3ROYW1lXTtcbiAgfVxuICBcbiAgY29uc3QgbG93ZXJOYW1lID0gYXJ0aXN0TmFtZS50b0xvd2VyQ2FzZSgpO1xuICBmb3IgKGNvbnN0IFthcnRpc3QsIHN0eWxlXSBvZiBPYmplY3QuZW50cmllcyhhcnRpc3RUb1N0eWxlTWFwKSkge1xuICAgIGlmIChhcnRpc3QudG9Mb3dlckNhc2UoKSA9PT0gbG93ZXJOYW1lKSB7XG4gICAgICByZXR1cm4gc3R5bGU7XG4gICAgfVxuICB9XG4gIFxuICByZXR1cm4gXCJjb250ZW1wb3JhcnkgcG9wIHdpdGggbW9kZXJuIHByb2R1Y3Rpb25cIjtcbn1cblxuLy8gQ2xlYW4gc3R5bGUgc3RyaW5nIHRvIHJlbW92ZSBhcnRpc3QgbmFtZXNcbmZ1bmN0aW9uIGNsZWFuU3R5bGVGb3JTdW5vKHN0eWxlOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoIXN0eWxlKSByZXR1cm4gXCJcIjtcbiAgXG4gIGxldCBjbGVhbmVkU3R5bGUgPSBzdHlsZTtcbiAgXG4gIGZvciAoY29uc3QgYXJ0aXN0TmFtZSBvZiBPYmplY3Qua2V5cyhhcnRpc3RUb1N0eWxlTWFwKSkge1xuICAgIGNvbnN0IHJlZ2V4ID0gbmV3IFJlZ0V4cChgJHthcnRpc3ROYW1lfVxcXFxzKnN0eWxlYCwgXCJnaVwiKTtcbiAgICBpZiAocmVnZXgudGVzdChjbGVhbmVkU3R5bGUpKSB7XG4gICAgICBjbGVhbmVkU3R5bGUgPSBjbGVhbmVkU3R5bGUucmVwbGFjZShyZWdleCwgY29udmVydEFydGlzdFRvU3R5bGUoYXJ0aXN0TmFtZSkpO1xuICAgIH1cbiAgICBcbiAgICBjb25zdCBzdGFuZGFsb25lUmVnZXggPSBuZXcgUmVnRXhwKGBcXFxcYiR7YXJ0aXN0TmFtZX1cXFxcYmAsIFwiZ2lcIik7XG4gICAgaWYgKHN0YW5kYWxvbmVSZWdleC50ZXN0KGNsZWFuZWRTdHlsZSkpIHtcbiAgICAgIGNsZWFuZWRTdHlsZSA9IGNsZWFuZWRTdHlsZS5yZXBsYWNlKHN0YW5kYWxvbmVSZWdleCwgY29udmVydEFydGlzdFRvU3R5bGUoYXJ0aXN0TmFtZSkpO1xuICAgIH1cbiAgfVxuICBcbiAgY2xlYW5lZFN0eWxlID0gY2xlYW5lZFN0eWxlLnJlcGxhY2UoLyxcXHMqLC9nLCBcIixcIikucmVwbGFjZSgvXFxzKy9nLCBcIiBcIikudHJpbSgpO1xuICBcbiAgcmV0dXJuIGNsZWFuZWRTdHlsZTtcbn1cblxuc2VydmUoYXN5bmMgKHJlcSkgPT4ge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJPUFRJT05TXCIpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKG51bGwsIHsgaGVhZGVyczogY29yc0hlYWRlcnMgfSk7XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSByZXEuaGVhZGVycy5nZXQoXCJBdXRob3JpemF0aW9uXCIpO1xuICAgIGlmICghYXV0aEhlYWRlcikge1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCJObyBhdXRob3JpemF0aW9uIGhlYWRlclwiIH0pLFxuICAgICAgICB7IHN0YXR1czogNDAxLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgc3VwYWJhc2VDbGllbnQgPSBjcmVhdGVDbGllbnQoXG4gICAgICBEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIikgPz8gXCJcIixcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX0FOT05fS0VZXCIpID8/IFwiXCIsXG4gICAgICB7IGdsb2JhbDogeyBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGF1dGhIZWFkZXIgfSB9IH1cbiAgICApO1xuXG4gICAgLy8gQWxzbyBjcmVhdGUgYWRtaW4gY2xpZW50IGZvciBjcmVhdGluZyBub3RpZmljYXRpb25zXG4gICAgY29uc3Qgc3VwYWJhc2VBZG1pbiA9IGNyZWF0ZUNsaWVudChcbiAgICAgIERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSA/PyBcIlwiLFxuICAgICAgRGVuby5lbnYuZ2V0KFwiU1VQQUJBU0VfU0VSVklDRV9ST0xFX0tFWVwiKSA/PyBcIlwiXG4gICAgKTtcblxuICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0sIGVycm9yOiB1c2VyRXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50LmF1dGguZ2V0VXNlcigpO1xuICAgIGlmICh1c2VyRXJyb3IgfHwgIXVzZXIpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiVW5hdXRob3JpemVkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDEsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBQMCBGSVg6IENoZWNrIGlmIHVzZXIgaXMgYmxvY2tlZCBiZWZvcmUgYWxsb3dpbmcgZ2VuZXJhdGlvblxuICAgIGNvbnN0IHsgZGF0YTogaXNCbG9ja2VkIH0gPSBhd2FpdCBzdXBhYmFzZUFkbWluLnJwYyhcImlzX3VzZXJfYmxvY2tlZFwiLCB7IHBfdXNlcl9pZDogdXNlci5pZCB9KTtcbiAgICBpZiAoaXNCbG9ja2VkKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCS0LDRiCDQsNC60LrQsNGD0L3RgiDQt9Cw0LHQu9C+0LrQuNGA0L7QstCw0L0uINCT0LXQvdC10YDQsNGG0LjRjyDQvdC10LTQvtGB0YLRg9C/0L3QsC5cIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMywgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHsgdHJhY2tJZCwgcHJvbXB0LCBseXJpY3MsIHN0eWxlLCB0aXRsZSwgaW5zdHJ1bWVudGFsLCBhdWRpb1JlZmVyZW5jZVVybCB9ID0gYXdhaXQgcmVxLmpzb24oKTtcblxuICAgIGlmICghdHJhY2tJZCB8fCAhcHJvbXB0KSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIk1pc3NpbmcgcmVxdWlyZWQgZmllbGRzOiB0cmFja0lkLCBwcm9tcHRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKGBTdGFydGluZyBnZW5lcmF0aW9uIGZvciB0cmFjayAke3RyYWNrSWR9IGJ5IHVzZXIgJHt1c2VyLmlkfWApO1xuICAgIGNvbnNvbGUubG9nKGBPcmlnaW5hbCBwcm9tcHQ6ICR7cHJvbXB0fWApO1xuICAgIGNvbnNvbGUubG9nKGBPcmlnaW5hbCBzdHlsZTogJHtzdHlsZX1gKTtcbiAgICBjb25zb2xlLmxvZyhgSW5zdHJ1bWVudGFsOiAke2luc3RydW1lbnRhbH1gKTtcbiAgICBjb25zb2xlLmxvZyhgQXVkaW8gcmVmZXJlbmNlIFVSTDogJHthdWRpb1JlZmVyZW5jZVVybCB8fCAnbm9uZSd9YCk7XG5cbiAgICAvLyBDbGVhbiB0aGUgc3R5bGUgdG8gcmVtb3ZlIGFydGlzdCBuYW1lc1xuICAgIGNvbnN0IGNsZWFuZWRTdHlsZSA9IGNsZWFuU3R5bGVGb3JTdW5vKHN0eWxlIHx8IFwiXCIpO1xuICAgIGNvbnNvbGUubG9nKGBDbGVhbmVkIHN0eWxlOiAke2NsZWFuZWRTdHlsZX1gKTtcblxuICAgIC8vIFVwZGF0ZSB0cmFjayBzdGF0dXMgdG8gcHJvY2Vzc2luZ1xuICAgIGNvbnN0IHsgZXJyb3I6IHVwZGF0ZUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwicHJvY2Vzc2luZ1wiLCBlcnJvcl9tZXNzYWdlOiBudWxsIH0pXG4gICAgICAuZXEoXCJpZFwiLCB0cmFja0lkKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcblxuICAgIGlmICh1cGRhdGVFcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgdHJhY2sgc3RhdHVzOlwiLCB1cGRhdGVFcnJvcik7XG4gICAgfVxuXG4gICAgLy8gQnVpbGQgdGhlIFN1bm8gQVBJIHBheWxvYWQgYWNjb3JkaW5nIHRvIGRvY3VtZW50YXRpb25cbiAgICBjb25zdCBoYXNMeXJpY3MgPSAhIWx5cmljcyAmJiBseXJpY3MudHJpbSgpLmxlbmd0aCA+IDA7XG4gICAgY29uc3QgaGFzU3R5bGUgPSAhIWNsZWFuZWRTdHlsZSAmJiBjbGVhbmVkU3R5bGUudHJpbSgpLmxlbmd0aCA+IDA7XG4gICAgY29uc3QgaGFzUHJvbXB0ID0gISFwcm9tcHQgJiYgcHJvbXB0LnRyaW0oKS5sZW5ndGggPiAwO1xuICAgIGNvbnN0IHVzZUN1c3RvbU1vZGUgPSBoYXNMeXJpY3MgfHwgaGFzU3R5bGU7XG5cbiAgICAvLyBDbGVhbiB0aGUgcHJvbXB0IChkZXNjcmlwdGlvbikgYXMgd2VsbFxuICAgIGNvbnN0IGNsZWFuZWRQcm9tcHQgPSBjbGVhblN0eWxlRm9yU3Vubyhwcm9tcHQgfHwgXCJcIik7XG4gICAgY29uc29sZS5sb2coYENsZWFuZWQgcHJvbXB0IChkZXNjcmlwdGlvbik6ICR7Y2xlYW5lZFByb21wdH1gKTtcblxuICAgIC8vIEJ1aWxkIGNhbGxiYWNrIFVSTCB3aXRoIHNlY3JldCBmb3Igc2VjdXJpdHlcbiAgICAvLyBVc2UgU1VOT19DQUxMQkFDS19VUkwgaWYgc2V0IChzaG91bGQgYmUgcHVibGljIFVSTCksIG90aGVyd2lzZSBmYWxsIGJhY2sgdG8gU1VQQUJBU0VfVVJMXG4gICAgY29uc3QgY2FsbGJhY2tTZWNyZXQgPSBEZW5vLmVudi5nZXQoXCJTVU5PX0NBTExCQUNLX1NFQ1JFVFwiKTtcbiAgICBjb25zdCBleHBsaWNpdENhbGxiYWNrVXJsID0gRGVuby5lbnYuZ2V0KFwiU1VOT19DQUxMQkFDS19VUkxcIik7XG4gICAgY29uc3QgYmFzZUNhbGxiYWNrVXJsID0gZXhwbGljaXRDYWxsYmFja1VybCB8fCBgJHtEZW5vLmVudi5nZXQoXCJTVVBBQkFTRV9VUkxcIil9L2Z1bmN0aW9ucy92MS9zdW5vLWNhbGxiYWNrYDtcbiAgICBjb25zdCBjYWxsQmFja1VybCA9IGNhbGxiYWNrU2VjcmV0IFxuICAgICAgPyBgJHtiYXNlQ2FsbGJhY2tVcmx9JHtiYXNlQ2FsbGJhY2tVcmwuaW5jbHVkZXMoJz8nKSA/ICcmJyA6ICc/J31zZWNyZXQ9JHtlbmNvZGVVUklDb21wb25lbnQoY2FsbGJhY2tTZWNyZXQpfWBcbiAgICAgIDogYmFzZUNhbGxiYWNrVXJsO1xuICAgIGNvbnNvbGUubG9nKGBDYWxsYmFjayBVUkw6ICR7Y2FsbEJhY2tVcmx9YCk7XG5cbiAgICBjb25zdCBzdW5vUGF5bG9hZDogUmVjb3JkPHN0cmluZywgYW55PiA9IHtcbiAgICAgIG1vZGVsOiBcIlY0XCIsXG4gICAgICBjdXN0b21Nb2RlOiB1c2VDdXN0b21Nb2RlLFxuICAgICAgaW5zdHJ1bWVudGFsOiBpbnN0cnVtZW50YWwgfHwgZmFsc2UsXG4gICAgICBjYWxsQmFja1VybCxcbiAgICB9O1xuXG4gICAgaWYgKHVzZUN1c3RvbU1vZGUpIHtcbiAgICAgIC8vIHByb21wdCBmaWVsZCA9IGx5cmljcyAoaWYgcHJlc2VudCkgb3IgZGVzY3JpcHRpb25cbiAgICAgIHN1bm9QYXlsb2FkLnByb21wdCA9IGhhc0x5cmljcyA/IGx5cmljcyA6IHByb21wdDtcbiAgICAgIFxuICAgICAgLy8gQ1JJVElDQUw6IHN0eWxlIGZpZWxkIHNob3VsZCBPTkxZIGNvbnRhaW4gZ2VucmUvdm9jYWwvc3R5bGUgdGFncyAtIE5PVCB0aGUgZGVzY3JpcHRpb24hXG4gICAgICAvLyBTdW5vIGhhcyBhIHN0cmljdCAyMDAgY2hhcmFjdGVyIGxpbWl0IG9uIHN0eWxlIGZpZWxkXG4gICAgICAvLyBEZXNjcmlwdGlvbiBnb2VzIGluIHRoZSBwcm9tcHQsIG5vdCBpbiBzdHlsZVxuICAgICAgbGV0IGZpbmFsU3R5bGUgPSBjbGVhbmVkU3R5bGUgfHwgXCJwb3BcIjtcbiAgICAgIFxuICAgICAgLy8gVHJ1bmNhdGUgc3R5bGUgdG8gMjAwIGNoYXJzIG1heCAoU3VubyBsaW1pdClcbiAgICAgIGlmIChmaW5hbFN0eWxlLmxlbmd0aCA+IDIwMCkge1xuICAgICAgICAvLyBLZWVwIHRoZSBtb3N0IGltcG9ydGFudCB0YWdzIChmaXJzdCBvbmVzKSBhbmQgY3V0IGF0IGNvbW1hIGJvdW5kYXJ5XG4gICAgICAgIGNvbnN0IHBhcnRzID0gZmluYWxTdHlsZS5zcGxpdChcIiwgXCIpO1xuICAgICAgICBsZXQgdHJ1bmNhdGVkID0gXCJcIjtcbiAgICAgICAgZm9yIChjb25zdCBwYXJ0IG9mIHBhcnRzKSB7XG4gICAgICAgICAgaWYgKCh0cnVuY2F0ZWQgKyBcIiwgXCIgKyBwYXJ0KS5sZW5ndGggPD0gMjAwKSB7XG4gICAgICAgICAgICB0cnVuY2F0ZWQgPSB0cnVuY2F0ZWQgPyB0cnVuY2F0ZWQgKyBcIiwgXCIgKyBwYXJ0IDogcGFydDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZpbmFsU3R5bGUgPSB0cnVuY2F0ZWQgfHwgZmluYWxTdHlsZS5zbGljZSgwLCAyMDApO1xuICAgICAgICBjb25zb2xlLmxvZyhgU3R5bGUgdHJ1bmNhdGVkIGZyb20gJHtjbGVhbmVkU3R5bGUubGVuZ3RofSB0byAke2ZpbmFsU3R5bGUubGVuZ3RofSBjaGFyc2ApO1xuICAgICAgfVxuICAgICAgXG4gICAgICBzdW5vUGF5bG9hZC5zdHlsZSA9IGZpbmFsU3R5bGU7XG4gICAgICBzdW5vUGF5bG9hZC50aXRsZSA9IHRpdGxlIHx8IFwiVW50aXRsZWRcIjtcbiAgICAgIFxuICAgICAgY29uc29sZS5sb2coYEZpbmFsIHN0eWxlIGZvciBTdW5vICgke3N1bm9QYXlsb2FkLnN0eWxlLmxlbmd0aH0gY2hhcnMpOiAke3N1bm9QYXlsb2FkLnN0eWxlfWApO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdW5vUGF5bG9hZC5wcm9tcHQgPSBwcm9tcHQuc2xpY2UoMCwgNDAwKTtcbiAgICB9XG5cbiAgICAvLyBEZXRlcm1pbmUgd2hpY2ggZW5kcG9pbnQgdG8gdXNlXG4gICAgbGV0IHN1bm9FbmRwb2ludCA9IGAke1NVTk9fQVBJX0JBU0V9L2FwaS92MS9nZW5lcmF0ZWA7XG4gICAgXG4gICAgLy8gSWYgYXVkaW8gcmVmZXJlbmNlIGlzIHByb3ZpZGVkLCB1c2UgdXBsb2FkLWNvdmVyIGVuZHBvaW50IGluc3RlYWRcbiAgICBpZiAoYXVkaW9SZWZlcmVuY2VVcmwpIHtcbiAgICAgIHN1bm9FbmRwb2ludCA9IGAke1NVTk9fQVBJX0JBU0V9L2FwaS92MS9nZW5lcmF0ZS91cGxvYWQtY292ZXJgO1xuICAgICAgc3Vub1BheWxvYWQudXBsb2FkVXJsID0gYXVkaW9SZWZlcmVuY2VVcmw7XG4gICAgICBjb25zb2xlLmxvZyhcIlVzaW5nIHVwbG9hZC1jb3ZlciBlbmRwb2ludCB3aXRoIGF1ZGlvIHJlZmVyZW5jZVwiKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhcIlNlbmRpbmcgdG8gU3VubyBBUEk6XCIsIEpTT04uc3RyaW5naWZ5KHN1bm9QYXlsb2FkKSk7XG4gICAgY29uc29sZS5sb2coXCJFbmRwb2ludDpcIiwgc3Vub0VuZHBvaW50KTtcblxuICAgIGNvbnN0IHN1bm9SZXNwb25zZSA9IGF3YWl0IGZldGNoKHN1bm9FbmRwb2ludCwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBgQmVhcmVyICR7U1VOT19BUElfS0VZfWAsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoc3Vub1BheWxvYWQpLFxuICAgIH0pO1xuXG4gICAgY29uc3Qgc3Vub0RhdGEgPSBhd2FpdCBzdW5vUmVzcG9uc2UuanNvbigpO1xuICAgIGNvbnNvbGUubG9nKFwiU3VubyBBUEkgcmVzcG9uc2U6XCIsIEpTT04uc3RyaW5naWZ5KHN1bm9EYXRhKSk7XG5cbiAgICBpZiAoIXN1bm9SZXNwb25zZS5vayB8fCBzdW5vRGF0YS5jb2RlICE9PSAyMDApIHtcbiAgICAgIGNvbnN0IHJhd0Vycm9yTWVzc2FnZSA9IHN1bm9EYXRhLm1zZyB8fCBcIkZhaWxlZCB0byBzdGFydCBnZW5lcmF0aW9uXCI7XG4gICAgICBjb25zdCBlcnJvckNvZGUgPSBzdW5vRGF0YS5jb2RlIHx8IHN1bm9SZXNwb25zZS5zdGF0dXMgfHwgNTAwO1xuICAgICAgXG4gICAgICAvLyBHZXQgaHVtYW4tcmVhZGFibGUgUnVzc2lhbiBlcnJvciBtZXNzYWdlXG4gICAgICBjb25zdCBlcnJvckluZm8gPSBnZXRTdW5vRXJyb3JNZXNzYWdlKGVycm9yQ29kZSwgcmF3RXJyb3JNZXNzYWdlKTtcbiAgICAgIGNvbnN0IHJ1c3NpYW5FcnJvck1lc3NhZ2UgPSBlcnJvckluZm8uc2hvcnQ7XG4gICAgICBcbiAgICAgIGNvbnNvbGUuZXJyb3IoYFN1bm8gQVBJIGVycm9yICgke2Vycm9yQ29kZX0pOiAke3Jhd0Vycm9yTWVzc2FnZX0gLT4gJHtydXNzaWFuRXJyb3JNZXNzYWdlfWApO1xuICAgICAgXG4gICAgICAvLyBVcGRhdGUgdHJhY2sgc3RhdHVzIHRvIGZhaWxlZCB3aXRoIFJ1c3NpYW4gZXJyb3IgbWVzc2FnZVxuICAgICAgYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnVwZGF0ZSh7IFxuICAgICAgICAgIHN0YXR1czogXCJmYWlsZWRcIixcbiAgICAgICAgICBlcnJvcl9tZXNzYWdlOiBydXNzaWFuRXJyb3JNZXNzYWdlXG4gICAgICAgIH0pXG4gICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZCk7XG5cbiAgICAgIC8vIEdldCBhbGwgdHJhY2tzIHdpdGggdGhpcyBiYXNlIHRpdGxlIHRvIGZpbmQgcGFpcmVkIHRyYWNrXG4gICAgICBjb25zdCB7IGRhdGE6IGFsbFRyYWNrcyB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnNlbGVjdChcImlkXCIpXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgICAgLmluKFwic3RhdHVzXCIsIFtcInBlbmRpbmdcIiwgXCJwcm9jZXNzaW5nXCJdKTtcblxuICAgICAgY29uc3QgdHJhY2tJZHMgPSBhbGxUcmFja3M/Lm1hcCh0ID0+IHQuaWQpIHx8IFt0cmFja0lkXTtcblxuICAgICAgLy8gUmVmdW5kOiB1cGRhdGUgZ2VuZXJhdGlvbl9sb2dzIHRvIGZhaWxlZCBhbmQgcmV0dXJuIGJhbGFuY2VcbiAgICAgIGNvbnN0IHsgZGF0YTogbG9ncyB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgLmZyb20oXCJnZW5lcmF0aW9uX2xvZ3NcIilcbiAgICAgICAgLnNlbGVjdChcImlkLCBjb3N0X3J1YlwiKVxuICAgICAgICAuaW4oXCJ0cmFja19pZFwiLCB0cmFja0lkcylcbiAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKVxuICAgICAgICAuZXEoXCJzdGF0dXNcIiwgXCJwZW5kaW5nXCIpO1xuXG4gICAgICBsZXQgdG90YWxSZWZ1bmQgPSAwO1xuICAgICAgaWYgKGxvZ3MgJiYgbG9ncy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHRvdGFsUmVmdW5kID0gbG9ncy5yZWR1Y2UoKHN1bSwgbG9nKSA9PiBzdW0gKyAobG9nLmNvc3RfcnViIHx8IDApLCAwKTtcbiAgICAgICAgXG4gICAgICAgIC8vIE1hcmsgbG9ncyBhcyBmYWlsZWRcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgICAuZnJvbShcImdlbmVyYXRpb25fbG9nc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwiZmFpbGVkXCIgfSlcbiAgICAgICAgICAuaW4oXCJpZFwiLCBsb2dzLm1hcChsID0+IGwuaWQpKTtcblxuICAgICAgICAvLyBSZWZ1bmQgdGhlIGJhbGFuY2VcbiAgICAgICAgaWYgKHRvdGFsUmVmdW5kID4gMCkge1xuICAgICAgICAgIGNvbnN0IHsgZGF0YTogcHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAgIC5zZWxlY3QoXCJiYWxhbmNlXCIpXG4gICAgICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpXG4gICAgICAgICAgICAuc2luZ2xlKCk7XG5cbiAgICAgICAgICBpZiAocHJvZmlsZSkge1xuICAgICAgICAgICAgY29uc3QgbmV3QmFsYW5jZSA9IChwcm9maWxlLmJhbGFuY2UgfHwgMCkgKyB0b3RhbFJlZnVuZDtcbiAgICAgICAgICAgIGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgICAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgICAgICAgICAgLnVwZGF0ZSh7IGJhbGFuY2U6IG5ld0JhbGFuY2UgfSlcbiAgICAgICAgICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VyLmlkKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gTG9nIHJlZnVuZCB0cmFuc2FjdGlvblxuICAgICAgICAgICAgYXdhaXQgc3VwYWJhc2VDbGllbnQuZnJvbShcImJhbGFuY2VfdHJhbnNhY3Rpb25zXCIpLmluc2VydCh7XG4gICAgICAgICAgICAgIHVzZXJfaWQ6IHVzZXIuaWQsXG4gICAgICAgICAgICAgIGFtb3VudDogdG90YWxSZWZ1bmQsXG4gICAgICAgICAgICAgIGJhbGFuY2VfYWZ0ZXI6IG5ld0JhbGFuY2UsXG4gICAgICAgICAgICAgIHR5cGU6IFwicmVmdW5kXCIsXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBg0JLQvtC30LLRgNCw0YIg0LfQsCDQvdC10YPQtNCw0YfQvdGD0Y4g0LPQtdC90LXRgNCw0YbQuNGOYCxcbiAgICAgICAgICAgICAgcmVmZXJlbmNlX2lkOiB0cmFja0lkLFxuICAgICAgICAgICAgICByZWZlcmVuY2VfdHlwZTogXCJ0cmFja1wiLFxuICAgICAgICAgICAgICBtZXRhZGF0YTogeyBlcnJvcjogcnVzc2lhbkVycm9yTWVzc2FnZSB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBSZWZ1bmRlZCAke3RvdGFsUmVmdW5kfSB0byB1c2VyICR7dXNlci5pZH1gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gQWxzbyBtYXJrIG90aGVyIHBlbmRpbmcgdHJhY2tzIGFzIGZhaWxlZFxuICAgICAgYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJmYWlsZWRcIiwgZXJyb3JfbWVzc2FnZTogcnVzc2lhbkVycm9yTWVzc2FnZSB9KVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXIuaWQpXG4gICAgICAgIC5pbihcInN0YXR1c1wiLCBbXCJwZW5kaW5nXCIsIFwicHJvY2Vzc2luZ1wiXSk7XG5cbiAgICAgIC8vIENyZWF0ZSBub3RpZmljYXRpb24gZm9yIHJlZnVuZCB3aXRoIFJ1c3NpYW4gZXJyb3IgZXhwbGFuYXRpb25cbiAgICAgIGlmICh0b3RhbFJlZnVuZCA+IDApIHtcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VBZG1pblxuICAgICAgICAgIC5mcm9tKFwibm90aWZpY2F0aW9uc1wiKVxuICAgICAgICAgIC5pbnNlcnQoe1xuICAgICAgICAgICAgdXNlcl9pZDogdXNlci5pZCxcbiAgICAgICAgICAgIHR5cGU6IFwicmVmdW5kXCIsXG4gICAgICAgICAgICB0aXRsZTogYNCe0YjQuNCx0LrQsDogJHtydXNzaWFuRXJyb3JNZXNzYWdlfWAsXG4gICAgICAgICAgICBtZXNzYWdlOiBgJHtlcnJvckluZm8uZnVsbH1cXG5cXG7QktCw0Lwg0LLQvtC30LLRgNCw0YnQtdC90L4gJHt0b3RhbFJlZnVuZH0g4oK9YCxcbiAgICAgICAgICAgIHRhcmdldF90eXBlOiBcInRyYWNrXCIsXG4gICAgICAgICAgICB0YXJnZXRfaWQ6IHRyYWNrSWQsXG4gICAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgZXJyb3I6IHJ1c3NpYW5FcnJvck1lc3NhZ2UsXG4gICAgICAgICAgZGV0YWlsczogZXJyb3JJbmZvLmZ1bGwsXG4gICAgICAgICAgcmVmdW5kZWQ6IHRvdGFsUmVmdW5kID4gMCxcbiAgICAgICAgICByZWZ1bmRBbW91bnQ6IHRvdGFsUmVmdW5kXG4gICAgICAgIH0pLFxuICAgICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3QgdGFza0lkID0gc3Vub0RhdGEuZGF0YT8udGFza0lkO1xuICAgIGNvbnNvbGUubG9nKGBHZW5lcmF0aW9uIHN0YXJ0ZWQgd2l0aCB0YXNrIElEOiAke3Rhc2tJZH1gKTtcblxuICAgIC8vIENSSVRJQ0FMOiBTdG9yZSB0YXNrX2lkIGluIGRlc2NyaXB0aW9uIGZvciBPTkxZIHRoZSBjdXJyZW50IHRyYWNrIHBhaXIgKHYxIGFuZCB2MilcbiAgICAvLyBUaGlzIGlzIGVzc2VudGlhbCBmb3IgdGhlIGNhbGxiYWNrIHRvIG1hdGNoIHJlc3VsdHMgdG8gdGhlIGNvcnJlY3QgdHJhY2tzXG4gICAgLy8gRE8gTk9UIHVwZGF0ZSBvdGhlciBwZW5kaW5nIHRyYWNrcyAtIHRoZXkgaGF2ZSB0aGVpciBvd24gdGFza19pZCBmcm9tIHRoZWlyIG93biBnZW5lcmF0aW9uIVxuICAgIGlmICh0YXNrSWQpIHtcbiAgICAgIC8vIEdldCB0aGUgY3VycmVudCB0cmFjaydzIGluZm8gaW5jbHVkaW5nIGNyZWF0ZWRfYXQgdG8gZmluZCBpdHMgcGFpclxuICAgICAgY29uc3QgeyBkYXRhOiBjdXJyZW50VHJhY2sgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgIC5mcm9tKFwidHJhY2tzXCIpXG4gICAgICAgIC5zZWxlY3QoXCJpZCwgdGl0bGUsIGRlc2NyaXB0aW9uLCBjcmVhdGVkX2F0XCIpXG4gICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpXG4gICAgICAgIC5zaW5nbGUoKTtcbiAgICAgIFxuICAgICAgaWYgKGN1cnJlbnRUcmFjaykge1xuICAgICAgICAvLyBGaW5kIHRoZSBwYWlyZWQgdHJhY2s6IHNhbWUgYmFzZSB0aXRsZSwgc2FtZSB1c2VyLCBjcmVhdGVkIHdpdGhpbiA1IHNlY29uZHNcbiAgICAgICAgY29uc3QgYmFzZVRpdGxlID0gKGN1cnJlbnRUcmFjay50aXRsZSB8fCBcIlwiKS5yZXBsYWNlKC9cXHMqXFwodlxcZCtcXCkkLywgXCJcIikudHJpbSgpO1xuICAgICAgICBjb25zdCBjcmVhdGVkQXQgPSBuZXcgRGF0ZShjdXJyZW50VHJhY2suY3JlYXRlZF9hdCk7XG4gICAgICAgIGNvbnN0IHdpbmRvd1N0YXJ0ID0gbmV3IERhdGUoY3JlYXRlZEF0LmdldFRpbWUoKSAtIDUwMDApLnRvSVNPU3RyaW5nKCk7XG4gICAgICAgIGNvbnN0IHdpbmRvd0VuZCA9IG5ldyBEYXRlKGNyZWF0ZWRBdC5nZXRUaW1lKCkgKyA1MDAwKS50b0lTT1N0cmluZygpO1xuICAgICAgICBcbiAgICAgICAgY29uc3QgeyBkYXRhOiBwYWlyZWRUcmFja3MgfSA9IGF3YWl0IHN1cGFiYXNlQ2xpZW50XG4gICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAuc2VsZWN0KFwiaWQsIHRpdGxlLCBkZXNjcmlwdGlvbiwgY3JlYXRlZF9hdFwiKVxuICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlci5pZClcbiAgICAgICAgICAuZ3RlKFwiY3JlYXRlZF9hdFwiLCB3aW5kb3dTdGFydClcbiAgICAgICAgICAubHRlKFwiY3JlYXRlZF9hdFwiLCB3aW5kb3dFbmQpO1xuICAgICAgICBcbiAgICAgICAgY29uc3QgZmlsdGVyZWQgPSBwYWlyZWRUcmFja3M/LmZpbHRlcih0ID0+IHtcbiAgICAgICAgICBjb25zdCB0QmFzZVRpdGxlID0gKHQudGl0bGUgfHwgXCJcIikucmVwbGFjZSgvXFxzKlxcKHZcXGQrXFwpJC8sIFwiXCIpLnRyaW0oKTtcbiAgICAgICAgICByZXR1cm4gdEJhc2VUaXRsZSA9PT0gYmFzZVRpdGxlO1xuICAgICAgICB9KSB8fCBbXTtcbiAgICAgICAgXG4gICAgICAgIC8vIENSSVRJQ0FMIEZJWDogZW1wdHkgYXJyYXkgaXMgdHJ1dGh5LCBzbyBjaGVjayAubGVuZ3RoIGV4cGxpY2l0bHlcbiAgICAgICAgY29uc3QgdHJhY2tzVG9VcGRhdGUgPSBmaWx0ZXJlZC5sZW5ndGggPiAwID8gZmlsdGVyZWQgOiBbY3VycmVudFRyYWNrXTtcbiAgICAgICAgXG4gICAgICAgIGNvbnNvbGUubG9nKGBGb3VuZCAke3RyYWNrc1RvVXBkYXRlLmxlbmd0aH0gdHJhY2tzIGluIHBhaXIgdG8gdXBkYXRlIHdpdGggdGFza19pZCAoZmlsdGVyZWQ6ICR7ZmlsdGVyZWQubGVuZ3RofSwgcGFpcmVkOiAke3BhaXJlZFRyYWNrcz8ubGVuZ3RoIHx8IDB9KWApO1xuICAgICAgICBcbiAgICAgICAgZm9yIChjb25zdCB0cmFjayBvZiB0cmFja3NUb1VwZGF0ZSkge1xuICAgICAgICAgIC8vIElNUE9SVEFOVDogT25seSB1cGRhdGUgaWYgdGhpcyB0cmFjayBkb2Vzbid0IGFscmVhZHkgaGF2ZSBhIHRhc2tfaWRcbiAgICAgICAgICAvLyBUaGlzIHByZXZlbnRzIG92ZXJ3cml0aW5nIHRhc2tfaWQgZnJvbSBhIGRpZmZlcmVudCBnZW5lcmF0aW9uXG4gICAgICAgICAgaWYgKHRyYWNrLmRlc2NyaXB0aW9uPy5pbmNsdWRlcyhcIlt0YXNrX2lkOlwiKSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYFRyYWNrICR7dHJhY2suaWR9ICgke3RyYWNrLnRpdGxlfSkgYWxyZWFkeSBoYXMgdGFza19pZCwgc2tpcHBpbmcgdG8gcHJldmVudCBvdmVyd3JpdGVgKTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBcbiAgICAgICAgICAvLyBBcHBlbmQgdGFza19pZCB0byBkZXNjcmlwdGlvbiAocHJlc2VydmUgZXhpc3RpbmcgY29udGVudClcbiAgICAgICAgICBjb25zdCBleGlzdGluZ0Rlc2MgPSB0cmFjay5kZXNjcmlwdGlvbiB8fCBcIlwiO1xuICAgICAgICAgIGNvbnN0IG5ld0Rlc2MgPSBleGlzdGluZ0Rlc2MgXG4gICAgICAgICAgICA/IGAke2V4aXN0aW5nRGVzY31cXG5cXG5bdGFza19pZDogJHt0YXNrSWR9XWBcbiAgICAgICAgICAgIDogYFt0YXNrX2lkOiAke3Rhc2tJZH1dYDtcbiAgICAgICAgICBcbiAgICAgICAgICBhd2FpdCBzdXBhYmFzZUNsaWVudFxuICAgICAgICAgICAgLmZyb20oXCJ0cmFja3NcIilcbiAgICAgICAgICAgIC51cGRhdGUoeyBkZXNjcmlwdGlvbjogbmV3RGVzYyB9KVxuICAgICAgICAgICAgLmVxKFwiaWRcIiwgdHJhY2suaWQpO1xuICAgICAgICAgIFxuICAgICAgICAgIGNvbnNvbGUubG9nKGBTdG9yZWQgdGFza19pZCAke3Rhc2tJZH0gaW4gdHJhY2sgJHt0cmFjay5pZH0gKCR7dHJhY2sudGl0bGV9KWApO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBGYWxsYmFjazogYXQgbGVhc3QgdXBkYXRlIHRoZSBjdXJyZW50IHRyYWNrXG4gICAgICAgIGNvbnN0IG5ld0Rlc2MgPSBgW3Rhc2tfaWQ6ICR7dGFza0lkfV1gO1xuICAgICAgICBcbiAgICAgICAgYXdhaXQgc3VwYWJhc2VDbGllbnRcbiAgICAgICAgICAuZnJvbShcInRyYWNrc1wiKVxuICAgICAgICAgIC51cGRhdGUoeyBkZXNjcmlwdGlvbjogbmV3RGVzYyB9KVxuICAgICAgICAgIC5lcShcImlkXCIsIHRyYWNrSWQpO1xuICAgICAgICBcbiAgICAgICAgY29uc29sZS5sb2coYFN0b3JlZCB0YXNrX2lkICR7dGFza0lkfSBpbiB0cmFjayAke3RyYWNrSWR9IChmYWxsYmFjaylgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXG4gICAgICAgIHRhc2tJZCxcbiAgICAgICAgbWVzc2FnZTogXCJHZW5lcmF0aW9uIHN0YXJ0ZWQgc3VjY2Vzc2Z1bGx5XCIgXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcblxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBzdW5vLWdlbmVyYXRlOlwiLCBlcnJvcik7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIjtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBlcnJvcjogXCLQn9GA0L7QuNC30L7RiNC70LAg0L3QtdC/0YDQtdC00LLQuNC00LXQvdC90LDRjyDQvtGI0LjQsdC60LAuINCf0L7Qv9GA0L7QsdGD0LnRgtC1INC/0L7Qt9C20LUuXCIgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTsiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxLQUFLLFFBQVEsK0NBQStDO0FBQ3JFLFNBQVMsWUFBWSxRQUFRLHlDQUF5QztBQUV0RSxNQUFNLGNBQWM7RUFDbEIsK0JBQStCO0VBQy9CLGdDQUFnQztBQUNsQztBQUVBLE1BQU0sZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDbEMsTUFBTSxnQkFBZ0I7QUFFdEIsK0RBQStEO0FBQy9ELGlDQUFpQztBQUNqQyw2RUFBNkU7QUFDN0UsK0RBQStEO0FBQy9ELHlFQUF5RTtBQUN6RSxTQUFTLG9CQUFvQixJQUFZLEVBQUUsZUFBd0I7RUFDakUsNkVBQTZFO0VBQzdFLElBQUksaUJBQWlCO0lBQ25CLE1BQU0sV0FBVyxnQkFBZ0IsV0FBVztJQUU1QyxJQUFJLFNBQVMsUUFBUSxDQUFDLDRCQUNsQixTQUFTLFFBQVEsQ0FBQywyQkFDbEIsU0FBUyxRQUFRLENBQUMsZ0JBQ2xCLFNBQVMsUUFBUSxDQUFDLHNCQUFzQjtNQUMxQyxPQUFPO1FBQ0wsT0FBTztRQUNQLE1BQU07TUFDUjtJQUNGO0lBRUEsSUFBSSxTQUFTLFFBQVEsQ0FBQyxpQkFDbEIsU0FBUyxRQUFRLENBQUMsZ0JBQ2xCLFNBQVMsUUFBUSxDQUFDLG9CQUNsQixTQUFTLFFBQVEsQ0FBQyxlQUFlO01BQ25DLE9BQU87UUFDTCxPQUFPO1FBQ1AsTUFBTTtNQUNSO0lBQ0Y7SUFFQSxJQUFJLFNBQVMsUUFBUSxDQUFDLGVBQWUsU0FBUyxRQUFRLENBQUMsZ0JBQWdCLFNBQVMsUUFBUSxDQUFDLFlBQVk7TUFDbkcsT0FBTztRQUNMLE9BQU87UUFDUCxNQUFNO01BQ1I7SUFDRjtJQUVBLElBQUksU0FBUyxRQUFRLENBQUMsYUFBYSxTQUFTLFFBQVEsQ0FBQyxjQUFjLFNBQVMsUUFBUSxDQUFDLGlCQUFpQjtNQUNwRyxPQUFPO1FBQ0wsT0FBTztRQUNQLE1BQU07TUFDUjtJQUNGO0VBQ0Y7RUFFQSxNQUFNLGdCQUFpRTtJQUNyRSxLQUFLO01BQUUsT0FBTztNQUE4QixNQUFNO0lBQWlEO0lBQ25HLEtBQUs7TUFBRSxPQUFPO01BQXNCLE1BQU07SUFBa0U7SUFDNUcsS0FBSztNQUFFLE9BQU87TUFBd0IsTUFBTTtJQUFvRTtJQUNoSCxLQUFLO01BQUUsT0FBTztNQUFvQixNQUFNO0lBQXNEO0lBQzlGLEtBQUs7TUFBRSxPQUFPO01BQThCLE1BQU07SUFBcUQ7SUFDdkcsS0FBSztNQUFFLE9BQU87TUFBMkIsTUFBTTtJQUF5RjtJQUN4SSxLQUFLO01BQUUsT0FBTztNQUF5QixNQUFNO0lBQWtFO0lBQy9HLEtBQUs7TUFBRSxPQUFPO01BQTBCLE1BQU07SUFBNEQ7SUFDMUcsS0FBSztNQUFFLE9BQU87TUFBdUIsTUFBTTtJQUF1RDtJQUNsRyxLQUFLO01BQUUsT0FBTztNQUFxQixNQUFNO0lBQThDO0VBQ3pGO0VBRUEsSUFBSSxhQUFhLENBQUMsS0FBSyxFQUFFO0lBQ3ZCLE9BQU8sYUFBYSxDQUFDLEtBQUs7RUFDNUI7RUFFQSxPQUFPO0lBQ0wsT0FBTyxDQUFDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLE1BQU0sbUJBQW1CLENBQUMscUNBQXFDLEVBQUUsS0FBSyxDQUFDO0VBQ3pFO0FBQ0Y7QUFFQSxpRkFBaUY7QUFDakYsTUFBTSxtQkFBMkM7RUFDL0MsU0FBUztFQUNULGNBQWM7RUFDZCxnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLGlCQUFpQjtFQUNqQixpQkFBaUI7RUFDakIsWUFBWTtFQUNaLGFBQWE7RUFDYixlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxPQUFPO0VBQ1AsZ0JBQWdCO0VBQ2hCLFlBQVk7RUFDWixPQUFPO0VBQ1AsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLGNBQWM7RUFDZCxTQUFTO0VBQ1QsV0FBVztFQUNYLGlCQUFpQjtFQUNqQixhQUFhO0VBQ2IsV0FBVztFQUNYLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIscUJBQXFCO0VBQ3JCLFlBQVk7RUFDWixlQUFlO0FBQ2pCO0FBRUEsZ0RBQWdEO0FBQ2hELFNBQVMscUJBQXFCLFVBQWtCO0VBQzlDLElBQUksZ0JBQWdCLENBQUMsV0FBVyxFQUFFO0lBQ2hDLE9BQU8sZ0JBQWdCLENBQUMsV0FBVztFQUNyQztFQUVBLE1BQU0sWUFBWSxXQUFXLFdBQVc7RUFDeEMsS0FBSyxNQUFNLENBQUMsUUFBUSxNQUFNLElBQUksT0FBTyxPQUFPLENBQUMsa0JBQW1CO0lBQzlELElBQUksT0FBTyxXQUFXLE9BQU8sV0FBVztNQUN0QyxPQUFPO0lBQ1Q7RUFDRjtFQUVBLE9BQU87QUFDVDtBQUVBLDRDQUE0QztBQUM1QyxTQUFTLGtCQUFrQixLQUFhO0VBQ3RDLElBQUksQ0FBQyxPQUFPLE9BQU87RUFFbkIsSUFBSSxlQUFlO0VBRW5CLEtBQUssTUFBTSxjQUFjLE9BQU8sSUFBSSxDQUFDLGtCQUFtQjtJQUN0RCxNQUFNLFFBQVEsSUFBSSxPQUFPLENBQUMsRUFBRSxXQUFXLFNBQVMsQ0FBQyxFQUFFO0lBQ25ELElBQUksTUFBTSxJQUFJLENBQUMsZUFBZTtNQUM1QixlQUFlLGFBQWEsT0FBTyxDQUFDLE9BQU8scUJBQXFCO0lBQ2xFO0lBRUEsTUFBTSxrQkFBa0IsSUFBSSxPQUFPLENBQUMsR0FBRyxFQUFFLFdBQVcsR0FBRyxDQUFDLEVBQUU7SUFDMUQsSUFBSSxnQkFBZ0IsSUFBSSxDQUFDLGVBQWU7TUFDdEMsZUFBZSxhQUFhLE9BQU8sQ0FBQyxpQkFBaUIscUJBQXFCO0lBQzVFO0VBQ0Y7RUFFQSxlQUFlLGFBQWEsT0FBTyxDQUFDLFVBQVUsS0FBSyxPQUFPLENBQUMsUUFBUSxLQUFLLElBQUk7RUFFNUUsT0FBTztBQUNUO0FBRUEsTUFBTSxPQUFPO0VBQ1gsSUFBSSxJQUFJLE1BQU0sS0FBSyxXQUFXO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU07TUFBRSxTQUFTO0lBQVk7RUFDbkQ7RUFFQSxJQUFJO0lBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNuQyxJQUFJLENBQUMsWUFBWTtNQUNmLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEwQixJQUNsRDtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLGlCQUFpQixhQUNyQixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLElBQ2hDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsSUFDckM7TUFBRSxRQUFRO1FBQUUsU0FBUztVQUFFLGVBQWU7UUFBVztNQUFFO0lBQUU7SUFHdkQsc0RBQXNEO0lBQ3RELE1BQU0sZ0JBQWdCLGFBQ3BCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFDaEMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGdDQUFnQztJQUcvQyxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxPQUFPO0lBQzlFLElBQUksYUFBYSxDQUFDLE1BQU07TUFDdEIsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWUsSUFDdkM7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsOERBQThEO0lBQzlELE1BQU0sRUFBRSxNQUFNLFNBQVMsRUFBRSxHQUFHLE1BQU0sY0FBYyxHQUFHLENBQUMsbUJBQW1CO01BQUUsV0FBVyxLQUFLLEVBQUU7SUFBQztJQUM1RixJQUFJLFdBQVc7TUFDYixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBa0QsSUFDMUU7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLEdBQUcsTUFBTSxJQUFJLElBQUk7SUFFakcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRO01BQ3ZCLE9BQU8sSUFBSSxTQUNULEtBQUssU0FBUyxDQUFDO1FBQUUsT0FBTztNQUEyQyxJQUNuRTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxRQUFRLEdBQUcsQ0FBQyxDQUFDLDhCQUE4QixFQUFFLFFBQVEsU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7SUFDekUsUUFBUSxHQUFHLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLENBQUM7SUFDeEMsUUFBUSxHQUFHLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxNQUFNLENBQUM7SUFDdEMsUUFBUSxHQUFHLENBQUMsQ0FBQyxjQUFjLEVBQUUsYUFBYSxDQUFDO0lBQzNDLFFBQVEsR0FBRyxDQUFDLENBQUMscUJBQXFCLEVBQUUscUJBQXFCLE9BQU8sQ0FBQztJQUVqRSx5Q0FBeUM7SUFDekMsTUFBTSxlQUFlLGtCQUFrQixTQUFTO0lBQ2hELFFBQVEsR0FBRyxDQUFDLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQztJQUU1QyxvQ0FBb0M7SUFDcEMsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLEdBQUcsTUFBTSxlQUNsQyxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7TUFBRSxRQUFRO01BQWMsZUFBZTtJQUFLLEdBQ25ELEVBQUUsQ0FBQyxNQUFNLFNBQ1QsRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFO0lBRXhCLElBQUksYUFBYTtNQUNmLFFBQVEsS0FBSyxDQUFDLGtDQUFrQztJQUNsRDtJQUVBLHdEQUF3RDtJQUN4RCxNQUFNLFlBQVksQ0FBQyxDQUFDLFVBQVUsT0FBTyxJQUFJLEdBQUcsTUFBTSxHQUFHO0lBQ3JELE1BQU0sV0FBVyxDQUFDLENBQUMsZ0JBQWdCLGFBQWEsSUFBSSxHQUFHLE1BQU0sR0FBRztJQUNoRSxNQUFNLFlBQVksQ0FBQyxDQUFDLFVBQVUsT0FBTyxJQUFJLEdBQUcsTUFBTSxHQUFHO0lBQ3JELE1BQU0sZ0JBQWdCLGFBQWE7SUFFbkMseUNBQXlDO0lBQ3pDLE1BQU0sZ0JBQWdCLGtCQUFrQixVQUFVO0lBQ2xELFFBQVEsR0FBRyxDQUFDLENBQUMsOEJBQThCLEVBQUUsY0FBYyxDQUFDO0lBRTVELDhDQUE4QztJQUM5QywyRkFBMkY7SUFDM0YsTUFBTSxpQkFBaUIsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ3BDLE1BQU0sc0JBQXNCLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN6QyxNQUFNLGtCQUFrQix1QkFBdUIsQ0FBQyxFQUFFLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsMkJBQTJCLENBQUM7SUFDM0csTUFBTSxjQUFjLGlCQUNoQixDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsZ0JBQWdCLFFBQVEsQ0FBQyxPQUFPLE1BQU0sSUFBSSxPQUFPLEVBQUUsbUJBQW1CLGdCQUFnQixDQUFDLEdBQzVHO0lBQ0osUUFBUSxHQUFHLENBQUMsQ0FBQyxjQUFjLEVBQUUsWUFBWSxDQUFDO0lBRTFDLE1BQU0sY0FBbUM7TUFDdkMsT0FBTztNQUNQLFlBQVk7TUFDWixjQUFjLGdCQUFnQjtNQUM5QjtJQUNGO0lBRUEsSUFBSSxlQUFlO01BQ2pCLG9EQUFvRDtNQUNwRCxZQUFZLE1BQU0sR0FBRyxZQUFZLFNBQVM7TUFFMUMsMEZBQTBGO01BQzFGLHVEQUF1RDtNQUN2RCwrQ0FBK0M7TUFDL0MsSUFBSSxhQUFhLGdCQUFnQjtNQUVqQywrQ0FBK0M7TUFDL0MsSUFBSSxXQUFXLE1BQU0sR0FBRyxLQUFLO1FBQzNCLHNFQUFzRTtRQUN0RSxNQUFNLFFBQVEsV0FBVyxLQUFLLENBQUM7UUFDL0IsSUFBSSxZQUFZO1FBQ2hCLEtBQUssTUFBTSxRQUFRLE1BQU87VUFDeEIsSUFBSSxDQUFDLFlBQVksT0FBTyxJQUFJLEVBQUUsTUFBTSxJQUFJLEtBQUs7WUFDM0MsWUFBWSxZQUFZLFlBQVksT0FBTyxPQUFPO1VBQ3BELE9BQU87WUFDTDtVQUNGO1FBQ0Y7UUFDQSxhQUFhLGFBQWEsV0FBVyxLQUFLLENBQUMsR0FBRztRQUM5QyxRQUFRLEdBQUcsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLGFBQWEsTUFBTSxDQUFDLElBQUksRUFBRSxXQUFXLE1BQU0sQ0FBQyxNQUFNLENBQUM7TUFDekY7TUFFQSxZQUFZLEtBQUssR0FBRztNQUNwQixZQUFZLEtBQUssR0FBRyxTQUFTO01BRTdCLFFBQVEsR0FBRyxDQUFDLENBQUMsc0JBQXNCLEVBQUUsWUFBWSxLQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxZQUFZLEtBQUssQ0FBQyxDQUFDO0lBQzlGLE9BQU87TUFDTCxZQUFZLE1BQU0sR0FBRyxPQUFPLEtBQUssQ0FBQyxHQUFHO0lBQ3ZDO0lBRUEsa0NBQWtDO0lBQ2xDLElBQUksZUFBZSxDQUFDLEVBQUUsY0FBYyxnQkFBZ0IsQ0FBQztJQUVyRCxvRUFBb0U7SUFDcEUsSUFBSSxtQkFBbUI7TUFDckIsZUFBZSxDQUFDLEVBQUUsY0FBYyw2QkFBNkIsQ0FBQztNQUM5RCxZQUFZLFNBQVMsR0FBRztNQUN4QixRQUFRLEdBQUcsQ0FBQztJQUNkO0lBRUEsUUFBUSxHQUFHLENBQUMsd0JBQXdCLEtBQUssU0FBUyxDQUFDO0lBQ25ELFFBQVEsR0FBRyxDQUFDLGFBQWE7SUFFekIsTUFBTSxlQUFlLE1BQU0sTUFBTSxjQUFjO01BQzdDLFFBQVE7TUFDUixTQUFTO1FBQ1AsZ0JBQWdCO1FBQ2hCLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7TUFDM0M7TUFDQSxNQUFNLEtBQUssU0FBUyxDQUFDO0lBQ3ZCO0lBRUEsTUFBTSxXQUFXLE1BQU0sYUFBYSxJQUFJO0lBQ3hDLFFBQVEsR0FBRyxDQUFDLHNCQUFzQixLQUFLLFNBQVMsQ0FBQztJQUVqRCxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksU0FBUyxJQUFJLEtBQUssS0FBSztNQUM3QyxNQUFNLGtCQUFrQixTQUFTLEdBQUcsSUFBSTtNQUN4QyxNQUFNLFlBQVksU0FBUyxJQUFJLElBQUksYUFBYSxNQUFNLElBQUk7TUFFMUQsMkNBQTJDO01BQzNDLE1BQU0sWUFBWSxvQkFBb0IsV0FBVztNQUNqRCxNQUFNLHNCQUFzQixVQUFVLEtBQUs7TUFFM0MsUUFBUSxLQUFLLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxVQUFVLEdBQUcsRUFBRSxnQkFBZ0IsSUFBSSxFQUFFLG9CQUFvQixDQUFDO01BRTNGLDJEQUEyRDtNQUMzRCxNQUFNLGVBQ0gsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1FBQ04sUUFBUTtRQUNSLGVBQWU7TUFDakIsR0FDQyxFQUFFLENBQUMsTUFBTSxTQUNULEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRTtNQUV4QiwyREFBMkQ7TUFDM0QsTUFBTSxFQUFFLE1BQU0sU0FBUyxFQUFFLEdBQUcsTUFBTSxlQUMvQixJQUFJLENBQUMsVUFDTCxNQUFNLENBQUMsTUFDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsRUFBRSxDQUFDLFVBQVU7UUFBQztRQUFXO09BQWE7TUFFekMsTUFBTSxXQUFXLFdBQVcsSUFBSSxDQUFBLElBQUssRUFBRSxFQUFFLEtBQUs7UUFBQztPQUFRO01BRXZELDhEQUE4RDtNQUM5RCxNQUFNLEVBQUUsTUFBTSxJQUFJLEVBQUUsR0FBRyxNQUFNLGVBQzFCLElBQUksQ0FBQyxtQkFDTCxNQUFNLENBQUMsZ0JBQ1AsRUFBRSxDQUFDLFlBQVksVUFDZixFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsRUFBRSxDQUFDLFVBQVU7TUFFaEIsSUFBSSxjQUFjO01BQ2xCLElBQUksUUFBUSxLQUFLLE1BQU0sR0FBRyxHQUFHO1FBQzNCLGNBQWMsS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLE1BQVEsTUFBTSxDQUFDLElBQUksUUFBUSxJQUFJLENBQUMsR0FBRztRQUVuRSxzQkFBc0I7UUFDdEIsTUFBTSxlQUNILElBQUksQ0FBQyxtQkFDTCxNQUFNLENBQUM7VUFBRSxRQUFRO1FBQVMsR0FDMUIsRUFBRSxDQUFDLE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQSxJQUFLLEVBQUUsRUFBRTtRQUU5QixxQkFBcUI7UUFDckIsSUFBSSxjQUFjLEdBQUc7VUFDbkIsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEdBQUcsTUFBTSxlQUM3QixJQUFJLENBQUMsWUFDTCxNQUFNLENBQUMsV0FDUCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsTUFBTTtVQUVULElBQUksU0FBUztZQUNYLE1BQU0sYUFBYSxDQUFDLFFBQVEsT0FBTyxJQUFJLENBQUMsSUFBSTtZQUM1QyxNQUFNLGVBQ0gsSUFBSSxDQUFDLFlBQ0wsTUFBTSxDQUFDO2NBQUUsU0FBUztZQUFXLEdBQzdCLEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRTtZQUV4Qix5QkFBeUI7WUFDekIsTUFBTSxlQUFlLElBQUksQ0FBQyx3QkFBd0IsTUFBTSxDQUFDO2NBQ3ZELFNBQVMsS0FBSyxFQUFFO2NBQ2hCLFFBQVE7Y0FDUixlQUFlO2NBQ2YsTUFBTTtjQUNOLGFBQWEsQ0FBQyw4QkFBOEIsQ0FBQztjQUM3QyxjQUFjO2NBQ2QsZ0JBQWdCO2NBQ2hCLFVBQVU7Z0JBQUUsT0FBTztjQUFvQjtZQUN6QztZQUVBLFFBQVEsR0FBRyxDQUFDLENBQUMsU0FBUyxFQUFFLFlBQVksU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDMUQ7UUFDRjtNQUNGO01BRUEsMkNBQTJDO01BQzNDLE1BQU0sZUFDSCxJQUFJLENBQUMsVUFDTCxNQUFNLENBQUM7UUFBRSxRQUFRO1FBQVUsZUFBZTtNQUFvQixHQUM5RCxFQUFFLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFDckIsRUFBRSxDQUFDLFVBQVU7UUFBQztRQUFXO09BQWE7TUFFekMsZ0VBQWdFO01BQ2hFLElBQUksY0FBYyxHQUFHO1FBQ25CLE1BQU0sY0FDSCxJQUFJLENBQUMsaUJBQ0wsTUFBTSxDQUFDO1VBQ04sU0FBUyxLQUFLLEVBQUU7VUFDaEIsTUFBTTtVQUNOLE9BQU8sQ0FBQyxRQUFRLEVBQUUsb0JBQW9CLENBQUM7VUFDdkMsU0FBUyxDQUFDLEVBQUUsVUFBVSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsWUFBWSxFQUFFLENBQUM7VUFDL0QsYUFBYTtVQUNiLFdBQVc7UUFDYjtNQUNKO01BRUEsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFDYixPQUFPO1FBQ1AsU0FBUyxVQUFVLElBQUk7UUFDdkIsVUFBVSxjQUFjO1FBQ3hCLGNBQWM7TUFDaEIsSUFDQTtRQUFFLFFBQVE7UUFBSyxTQUFTO1VBQUUsR0FBRyxXQUFXO1VBQUUsZ0JBQWdCO1FBQW1CO01BQUU7SUFFbkY7SUFFQSxNQUFNLFNBQVMsU0FBUyxJQUFJLEVBQUU7SUFDOUIsUUFBUSxHQUFHLENBQUMsQ0FBQyxpQ0FBaUMsRUFBRSxPQUFPLENBQUM7SUFFeEQscUZBQXFGO0lBQ3JGLDRFQUE0RTtJQUM1RSw4RkFBOEY7SUFDOUYsSUFBSSxRQUFRO01BQ1YscUVBQXFFO01BQ3JFLE1BQU0sRUFBRSxNQUFNLFlBQVksRUFBRSxHQUFHLE1BQU0sZUFDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLHNDQUNQLEVBQUUsQ0FBQyxNQUFNLFNBQ1QsTUFBTTtNQUVULElBQUksY0FBYztRQUNoQiw4RUFBOEU7UUFDOUUsTUFBTSxZQUFZLENBQUMsYUFBYSxLQUFLLElBQUksRUFBRSxFQUFFLE9BQU8sQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJO1FBQzdFLE1BQU0sWUFBWSxJQUFJLEtBQUssYUFBYSxVQUFVO1FBQ2xELE1BQU0sY0FBYyxJQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssTUFBTSxXQUFXO1FBQ3BFLE1BQU0sWUFBWSxJQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssTUFBTSxXQUFXO1FBRWxFLE1BQU0sRUFBRSxNQUFNLFlBQVksRUFBRSxHQUFHLE1BQU0sZUFDbEMsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDLHNDQUNQLEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRSxFQUNyQixHQUFHLENBQUMsY0FBYyxhQUNsQixHQUFHLENBQUMsY0FBYztRQUVyQixNQUFNLFdBQVcsY0FBYyxPQUFPLENBQUE7VUFDcEMsTUFBTSxhQUFhLENBQUMsRUFBRSxLQUFLLElBQUksRUFBRSxFQUFFLE9BQU8sQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJO1VBQ25FLE9BQU8sZUFBZTtRQUN4QixNQUFNLEVBQUU7UUFFUixtRUFBbUU7UUFDbkUsTUFBTSxpQkFBaUIsU0FBUyxNQUFNLEdBQUcsSUFBSSxXQUFXO1VBQUM7U0FBYTtRQUV0RSxRQUFRLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxlQUFlLE1BQU0sQ0FBQyxrREFBa0QsRUFBRSxTQUFTLE1BQU0sQ0FBQyxVQUFVLEVBQUUsY0FBYyxVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBRXZKLEtBQUssTUFBTSxTQUFTLGVBQWdCO1VBQ2xDLHNFQUFzRTtVQUN0RSxnRUFBZ0U7VUFDaEUsSUFBSSxNQUFNLFdBQVcsRUFBRSxTQUFTLGNBQWM7WUFDNUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sS0FBSyxDQUFDLG9EQUFvRCxDQUFDO1lBQ25HO1VBQ0Y7VUFFQSw0REFBNEQ7VUFDNUQsTUFBTSxlQUFlLE1BQU0sV0FBVyxJQUFJO1VBQzFDLE1BQU0sVUFBVSxlQUNaLENBQUMsRUFBRSxhQUFhLGNBQWMsRUFBRSxPQUFPLENBQUMsQ0FBQyxHQUN6QyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQztVQUUxQixNQUFNLGVBQ0gsSUFBSSxDQUFDLFVBQ0wsTUFBTSxDQUFDO1lBQUUsYUFBYTtVQUFRLEdBQzlCLEVBQUUsQ0FBQyxNQUFNLE1BQU0sRUFBRTtVQUVwQixRQUFRLEdBQUcsQ0FBQyxDQUFDLGVBQWUsRUFBRSxPQUFPLFVBQVUsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQzlFO01BQ0YsT0FBTztRQUNMLDhDQUE4QztRQUM5QyxNQUFNLFVBQVUsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFdEMsTUFBTSxlQUNILElBQUksQ0FBQyxVQUNMLE1BQU0sQ0FBQztVQUFFLGFBQWE7UUFBUSxHQUM5QixFQUFFLENBQUMsTUFBTTtRQUVaLFFBQVEsR0FBRyxDQUFDLENBQUMsZUFBZSxFQUFFLE9BQU8sVUFBVSxFQUFFLFFBQVEsV0FBVyxDQUFDO01BQ3ZFO0lBQ0Y7SUFFQSxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUNiLFNBQVM7TUFDVDtNQUNBLFNBQVM7SUFDWCxJQUNBO01BQUUsU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBR3RFLEVBQUUsT0FBTyxPQUFPO0lBQ2QsUUFBUSxLQUFLLENBQUMsMkJBQTJCO0lBQ3pDLE1BQU0sZUFBZSxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sR0FBRztJQUM5RCxPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztNQUFFLE9BQU87SUFBcUQsSUFDN0U7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==
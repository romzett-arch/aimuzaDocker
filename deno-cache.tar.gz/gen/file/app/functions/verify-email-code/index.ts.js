import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
Deno.serve(async (req)=>{
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  try {
    const { email, code } = await req.json();
    if (!email || !code) {
      return new Response(JSON.stringify({
        error: "email and code are required"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const adminClient = createClient(supabaseUrl, serviceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });
    // Find matching verification code
    const { data: verification, error: fetchError } = await adminClient.from("email_verifications").select("*").eq("email", email).eq("code", code.toUpperCase().trim()).eq("verified", false).gt("expires_at", new Date().toISOString()).order("created_at", {
      ascending: false
    }).limit(1).single();
    if (fetchError || !verification) {
      return new Response(JSON.stringify({
        error: "Неверный или просроченный код"
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        }
      });
    }
    // Mark as verified
    await adminClient.from("email_verifications").update({
      verified: true
    }).eq("id", verification.id);
    // Find the user by email and confirm them
    const { data: usersData } = await adminClient.auth.admin.listUsers();
    const user = usersData?.users?.find((u)=>u.email === email);
    if (user) {
      // Confirm the user's email
      await adminClient.auth.admin.updateUserById(user.id, {
        email_confirm: true
      });
    }
    // Clean up all codes for this email
    await adminClient.from("email_verifications").delete().eq("email", email);
    console.log(`[verify-email-code] Email verified: ${email}`);
    return new Response(JSON.stringify({
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("[verify-email-code] Error:", error);
    const message = error instanceof Error ? error.message : "Internal server error";
    return new Response(JSON.stringify({
      error: message
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      }
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vYXBwL2Z1bmN0aW9ucy92ZXJpZnktZW1haWwtY29kZS9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gXCJodHRwczovL2VzbS5zaC9Ac3VwYWJhc2Uvc3VwYWJhc2UtanNAMi40OS4xXCI7XG5cbmNvbnN0IGNvcnNIZWFkZXJzID0ge1xuICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIixcbiAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCI6XG4gICAgXCJhdXRob3JpemF0aW9uLCB4LWNsaWVudC1pbmZvLCBhcGlrZXksIGNvbnRlbnQtdHlwZSwgeC1zdXBhYmFzZS1jbGllbnQtcGxhdGZvcm0sIHgtc3VwYWJhc2UtY2xpZW50LXBsYXRmb3JtLXZlcnNpb24sIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUsIHgtc3VwYWJhc2UtY2xpZW50LXJ1bnRpbWUtdmVyc2lvblwiLFxufTtcblxuRGVuby5zZXJ2ZShhc3luYyAocmVxKSA9PiB7XG4gIGlmIChyZXEubWV0aG9kID09PSBcIk9QVElPTlNcIikge1xuICAgIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgeyBoZWFkZXJzOiBjb3JzSGVhZGVycyB9KTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgeyBlbWFpbCwgY29kZSB9ID0gYXdhaXQgcmVxLmpzb24oKTtcblxuICAgIGlmICghZW1haWwgfHwgIWNvZGUpIHtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IFwiZW1haWwgYW5kIGNvZGUgYXJlIHJlcXVpcmVkXCIgfSksXG4gICAgICAgIHsgc3RhdHVzOiA0MDAsIGhlYWRlcnM6IHsgLi4uY29yc0hlYWRlcnMsIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0gfVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdXBhYmFzZVVybCA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1VSTFwiKSE7XG4gICAgY29uc3Qgc2VydmljZUtleSA9IERlbm8uZW52LmdldChcIlNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVlcIikhO1xuICAgIGNvbnN0IGFkbWluQ2xpZW50ID0gY3JlYXRlQ2xpZW50KHN1cGFiYXNlVXJsLCBzZXJ2aWNlS2V5LCB7XG4gICAgICBhdXRoOiB7IGF1dG9SZWZyZXNoVG9rZW46IGZhbHNlLCBwZXJzaXN0U2Vzc2lvbjogZmFsc2UgfSxcbiAgICB9KTtcblxuICAgIC8vIEZpbmQgbWF0Y2hpbmcgdmVyaWZpY2F0aW9uIGNvZGVcbiAgICBjb25zdCB7IGRhdGE6IHZlcmlmaWNhdGlvbiwgZXJyb3I6IGZldGNoRXJyb3IgfSA9IGF3YWl0IGFkbWluQ2xpZW50XG4gICAgICAuZnJvbShcImVtYWlsX3ZlcmlmaWNhdGlvbnNcIilcbiAgICAgIC5zZWxlY3QoXCIqXCIpXG4gICAgICAuZXEoXCJlbWFpbFwiLCBlbWFpbClcbiAgICAgIC5lcShcImNvZGVcIiwgY29kZS50b1VwcGVyQ2FzZSgpLnRyaW0oKSlcbiAgICAgIC5lcShcInZlcmlmaWVkXCIsIGZhbHNlKVxuICAgICAgLmd0KFwiZXhwaXJlc19hdFwiLCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpXG4gICAgICAub3JkZXIoXCJjcmVhdGVkX2F0XCIsIHsgYXNjZW5kaW5nOiBmYWxzZSB9KVxuICAgICAgLmxpbWl0KDEpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoZmV0Y2hFcnJvciB8fCAhdmVyaWZpY2F0aW9uKSB7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgICBKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcItCd0LXQstC10YDQvdGL0Lkg0LjQu9C4INC/0YDQvtGB0YDQvtGH0LXQvdC90YvQuSDQutC+0LRcIiB9KSxcbiAgICAgICAgeyBzdGF0dXM6IDQwMCwgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIE1hcmsgYXMgdmVyaWZpZWRcbiAgICBhd2FpdCBhZG1pbkNsaWVudFxuICAgICAgLmZyb20oXCJlbWFpbF92ZXJpZmljYXRpb25zXCIpXG4gICAgICAudXBkYXRlKHsgdmVyaWZpZWQ6IHRydWUgfSlcbiAgICAgIC5lcShcImlkXCIsIHZlcmlmaWNhdGlvbi5pZCk7XG5cbiAgICAvLyBGaW5kIHRoZSB1c2VyIGJ5IGVtYWlsIGFuZCBjb25maXJtIHRoZW1cbiAgICBjb25zdCB7IGRhdGE6IHVzZXJzRGF0YSB9ID0gYXdhaXQgYWRtaW5DbGllbnQuYXV0aC5hZG1pbi5saXN0VXNlcnMoKTtcbiAgICBjb25zdCB1c2VyID0gdXNlcnNEYXRhPy51c2Vycz8uZmluZCgodSkgPT4gdS5lbWFpbCA9PT0gZW1haWwpO1xuXG4gICAgaWYgKHVzZXIpIHtcbiAgICAgIC8vIENvbmZpcm0gdGhlIHVzZXIncyBlbWFpbFxuICAgICAgYXdhaXQgYWRtaW5DbGllbnQuYXV0aC5hZG1pbi51cGRhdGVVc2VyQnlJZCh1c2VyLmlkLCB7XG4gICAgICAgIGVtYWlsX2NvbmZpcm06IHRydWUsXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBDbGVhbiB1cCBhbGwgY29kZXMgZm9yIHRoaXMgZW1haWxcbiAgICBhd2FpdCBhZG1pbkNsaWVudC5mcm9tKFwiZW1haWxfdmVyaWZpY2F0aW9uc1wiKS5kZWxldGUoKS5lcShcImVtYWlsXCIsIGVtYWlsKTtcblxuICAgIGNvbnNvbGUubG9nKGBbdmVyaWZ5LWVtYWlsLWNvZGVdIEVtYWlsIHZlcmlmaWVkOiAke2VtYWlsfWApO1xuXG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgc3VjY2VzczogdHJ1ZSB9KSxcbiAgICAgIHsgaGVhZGVyczogeyAuLi5jb3JzSGVhZGVycywgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSB9XG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICBjb25zb2xlLmVycm9yKFwiW3ZlcmlmeS1lbWFpbC1jb2RlXSBFcnJvcjpcIiwgZXJyb3IpO1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiSW50ZXJuYWwgc2VydmVyIGVycm9yXCI7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IG1lc3NhZ2UgfSksXG4gICAgICB7IHN0YXR1czogNTAwLCBoZWFkZXJzOiB7IC4uLmNvcnNIZWFkZXJzLCBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cbiAgICApO1xuICB9XG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxTQUFTLFlBQVksUUFBUSw4Q0FBOEM7QUFFM0UsTUFBTSxjQUFjO0VBQ2xCLCtCQUErQjtFQUMvQixnQ0FDRTtBQUNKO0FBRUEsS0FBSyxLQUFLLENBQUMsT0FBTztFQUNoQixJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTTtNQUFFLFNBQVM7SUFBWTtFQUNuRDtFQUVBLElBQUk7SUFDRixNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLE1BQU0sSUFBSSxJQUFJO0lBRXRDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTTtNQUNuQixPQUFPLElBQUksU0FDVCxLQUFLLFNBQVMsQ0FBQztRQUFFLE9BQU87TUFBOEIsSUFDdEQ7UUFBRSxRQUFRO1FBQUssU0FBUztVQUFFLEdBQUcsV0FBVztVQUFFLGdCQUFnQjtRQUFtQjtNQUFFO0lBRW5GO0lBRUEsTUFBTSxjQUFjLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUNqQyxNQUFNLGFBQWEsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQ2hDLE1BQU0sY0FBYyxhQUFhLGFBQWEsWUFBWTtNQUN4RCxNQUFNO1FBQUUsa0JBQWtCO1FBQU8sZ0JBQWdCO01BQU07SUFDekQ7SUFFQSxrQ0FBa0M7SUFDbEMsTUFBTSxFQUFFLE1BQU0sWUFBWSxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsTUFBTSxZQUNyRCxJQUFJLENBQUMsdUJBQ0wsTUFBTSxDQUFDLEtBQ1AsRUFBRSxDQUFDLFNBQVMsT0FDWixFQUFFLENBQUMsUUFBUSxLQUFLLFdBQVcsR0FBRyxJQUFJLElBQ2xDLEVBQUUsQ0FBQyxZQUFZLE9BQ2YsRUFBRSxDQUFDLGNBQWMsSUFBSSxPQUFPLFdBQVcsSUFDdkMsS0FBSyxDQUFDLGNBQWM7TUFBRSxXQUFXO0lBQU0sR0FDdkMsS0FBSyxDQUFDLEdBQ04sTUFBTTtJQUVULElBQUksY0FBYyxDQUFDLGNBQWM7TUFDL0IsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7UUFBRSxPQUFPO01BQWdDLElBQ3hEO1FBQUUsUUFBUTtRQUFLLFNBQVM7VUFBRSxHQUFHLFdBQVc7VUFBRSxnQkFBZ0I7UUFBbUI7TUFBRTtJQUVuRjtJQUVBLG1CQUFtQjtJQUNuQixNQUFNLFlBQ0gsSUFBSSxDQUFDLHVCQUNMLE1BQU0sQ0FBQztNQUFFLFVBQVU7SUFBSyxHQUN4QixFQUFFLENBQUMsTUFBTSxhQUFhLEVBQUU7SUFFM0IsMENBQTBDO0lBQzFDLE1BQU0sRUFBRSxNQUFNLFNBQVMsRUFBRSxHQUFHLE1BQU0sWUFBWSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVM7SUFDbEUsTUFBTSxPQUFPLFdBQVcsT0FBTyxLQUFLLENBQUMsSUFBTSxFQUFFLEtBQUssS0FBSztJQUV2RCxJQUFJLE1BQU07TUFDUiwyQkFBMkI7TUFDM0IsTUFBTSxZQUFZLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxFQUFFO1FBQ25ELGVBQWU7TUFDakI7SUFDRjtJQUVBLG9DQUFvQztJQUNwQyxNQUFNLFlBQVksSUFBSSxDQUFDLHVCQUF1QixNQUFNLEdBQUcsRUFBRSxDQUFDLFNBQVM7SUFFbkUsUUFBUSxHQUFHLENBQUMsQ0FBQyxvQ0FBb0MsRUFBRSxNQUFNLENBQUM7SUFFMUQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxTQUFTO0lBQUssSUFDL0I7TUFBRSxTQUFTO1FBQUUsR0FBRyxXQUFXO1FBQUUsZ0JBQWdCO01BQW1CO0lBQUU7RUFFdEUsRUFBRSxPQUFPLE9BQWdCO0lBQ3ZCLFFBQVEsS0FBSyxDQUFDLDhCQUE4QjtJQUM1QyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLEdBQUc7SUFDekQsT0FBTyxJQUFJLFNBQ1QsS0FBSyxTQUFTLENBQUM7TUFBRSxPQUFPO0lBQVEsSUFDaEM7TUFBRSxRQUFRO01BQUssU0FBUztRQUFFLEdBQUcsV0FBVztRQUFFLGdCQUFnQjtNQUFtQjtJQUFFO0VBRW5GO0FBQ0YifQ==